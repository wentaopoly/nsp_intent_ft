var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpBgpEvpnEthernetSegment() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    var parseTarget =  new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var savedObjects;
    var currentObjects;
    var isAudit = false;

    this.synchronize = function(input, result,intentTypeName,parentXpath, initialPropertyName,uniqueIdentifier)
    {
        // code to handle delete
        if (input.getNetworkState().name() == "delete")
        {
            return this.syncDelete(input, result);
        }

        var savedTopology = input.getCurrentTopology();
        logger.info(savedTopology);
        savedObjects = {};
        currentObjects = {};
        //loading the saved objects from topology
        this.loadSavedObjectsFromTopology(savedTopology);
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        //intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
        if(!intentConfig)
        {
            intentConfig = Object.create({});
        }
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target ethernet segment name = " + intentConfig[uniqueIdentifier]);

        this.createOrModify(target, uniqueIdentifier, intentConfig);
        var currentTopo = this.loadCurrentObjectsToTopology(target);

        return util.setSuccessResult(result, currentTopo);
    }

    this.createOrModify = function (target, uniqueIdentifier, intentConfig)
    {
        var bgpEvpnEthernetSegmentPayload = this.createBgpEvpnEthernetSegmentPayLoad(target, uniqueIdentifier, intentConfig);
        // removing the delete objects
        this.deleteRemovedObjects(target);

        var result = this.modifyRequest(target, bgpEvpnEthernetSegmentPayload);

        return result;

    }

    this.modifyRequest = function (target, payload)
    {

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;

    }

    this.createBgpEvpnEthernetSegmentPayLoad = function (target, uniqueIdentifier, intentConfig)
    {
        // full class name for port and ethernet are same
        var fullClassName = "svr.BgpEvpnEthernetSegment";

        var fdn = "network:" + target;
        if (target && String(target).indexOf(':') !== -1) {
             fdn = util.modifyNeIdForIpV6(fdn, target);
        }
        // objectFullName is same as fdn for port level
        var objectFullName = "network:" + target + ":es-" + intentConfig[uniqueIdentifier];
        if (target && String(target).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
        }
        var properties = {};

        var hasESI = false;
        var hasMultiHoming = false;
        var hasPortOrLagAssociated = false;

        properties['ethSegEsName'] = intentConfig[uniqueIdentifier];
        if(intentConfig['esi'])
        {
            var esiValue = intentConfig['esi'];
            esiValue = esiValue.trim();
            if(isAudit == true)
            {
                esiValue = esiValue.replaceAll(" ", ":");
                esiValue = esiValue.replaceAll("-", ":");
                esiValue = esiValue.toLowerCase();
            }
            properties['ethSegEsiValue'] = esiValue;
            hasESI = true;
        }
        if(intentConfig['multi-homing-mode'])
        {
            hasMultiHoming = true;
            if(intentConfig['multi-homing-mode'] == "none")
            {
                properties['ethSegMultiHoming'] = "disabled";
                hasMultiHoming = false;
            }
            else if(intentConfig['multi-homing-mode'] == "single-active")
            {
                properties['ethSegMultiHoming'] = "singleActive";
            }
            else if(intentConfig['multi-homing-mode'] == "single-active-no-esi-label")
            {
                properties['ethSegMultiHoming'] = "singleActiveNoEsiLabel";
            }
            else if(intentConfig['multi-homing-mode'] == "all-active")
            {
                properties['ethSegMultiHoming'] = "allActive";
            }
        }
        if(intentConfig["admin-state"])
        {
            if(intentConfig["admin-state"] == "enable")
            {
                properties['ethSegAdminState'] = "enabled";
            }
            else if(intentConfig["admin-state"] == "disable")
            {
                properties['ethSegAdminState'] = "disabled";
            }
        }

        if(intentConfig['df-election'] && intentConfig['df-election']['es-activation-timer'])
        {
            properties['ethSegEsActivationTimer'] = intentConfig['df-election']['es-activation-timer'];
        }

        if(intentConfig['association'])
        {
            if(intentConfig['association']['type'])
            {
                if(intentConfig['association']['type'] === "port")
                {
                    if(intentConfig['association']['port'])
                    {
                        if (!Array.isArray(intentConfig['association']['port']))
                        {
                            intentConfig['association']['port'] = [intentConfig['association']['port']];
                        }
                        properties['ethSegPortIdPointer'] = util.getBaseFdnForPort(target, intentConfig['association']['port'][0]['port-id']);
                        hasPortOrLagAssociated = true;
                    }
                    else
                    {
                        properties['ethSegPortIdPointer'] = "";
                    }
                }
                else if(intentConfig['association']['type'] === "lag")
                {
                    if(intentConfig['association']['lag'])
                    {
                        if (!Array.isArray(intentConfig['association']['lag']))
                        {
                            intentConfig['association']['lag'] = [intentConfig['association']['lag']];
                        }
                        properties['ethSegLagIdPointer'] = util.getBaseFdnForLag(target, intentConfig['association']['lag'][0]['lag-name']);
                        hasPortOrLagAssociated = true;
                    }
                    else
                    {
                        properties['ethSegLagIdPointer'] = "";
                    }
                }
            }
        }

        if((!hasESI || !hasMultiHoming || !hasPortOrLagAssociated) && intentConfig["admin-state"] === "enable")
        {
            throw new RuntimeException("ESI, Muti-homing and Port/LAG association are required for the ethernetsegment to make administratively UP");
        }

        var bgpEvpnESPayload = util.editPayload(fdn, properties, fullClassName, objectFullName);
        return bgpEvpnESPayload;
    }

    this.audit = function(target, config, svcTopo, adminState, auditReport,intentTypeName,parentXpath, initialPropertyName,uniqueIdentifier)
    {
        // code to handle audit
        var savedTopology = svcTopo;
        savedObjects = {};
        currentObjects = {};
        isAudit = true;
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        //intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
        if(!intentConfig)
        {
            intentConfig = Object.create({});
        }
        // Ethernet Segment Name is part of the target-component
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        var target = parseTarget.getNeIdFromTarget(target);
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target ethernet segment name = " + intentConfig[uniqueIdentifier]);

        if (intentConfig) {
            this.auditAndCompare(target, uniqueIdentifier, intentConfig, auditReport);
        } else {
            throw "configuration not available in the intent";
        }

        return auditReport
    }

    this.auditAndCompare = function (target, uniqueIdentifier, intentConfig, auditReport)
    {
        var bgpEvpnEthernetSegmentPayload = this.createBgpEvpnEthernetSegmentPayLoad(target, uniqueIdentifier, intentConfig);
        var result = this.auditRequest(target, bgpEvpnEthernetSegmentPayload);
        auditReport = util.reportMisaligned(target, result, auditReport);
        return auditReport;
    }

    this.auditRequest = function (target, payload)
    {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.preDelete = function (target, uniqueIdentifier)
    {
        var fullClassName = "svr.BgpEvpnEthernetSegment";

        var fdn = "network:" + target;
        if (target && String(target).indexOf(':') !== -1) {
            fdn = util.modifyNeIdForIpV6(fdn, target);
        }
        // objectFullName is same as fdn for port level
        var objectFullName = "network:" + target + ":es-" + uniqueIdentifier;
        if (target && String(target).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
        }
        var properties = {};

        properties['ethSegPortIdPointer'] = "";
        properties['ethSegLagIdPointer'] = "";
        properties['ethSegAdminState'] = "disabled";

        var bgpEvpnESPayload = util.editPayload(fdn, properties, fullClassName, objectFullName);

        logger.info("NFMP-BGP-EVPN-ETHERNET-SEGMENT: Clearing the lag/port pointer in the ethernet segment before deleting it");
        var result = this.modifyRequest(target, bgpEvpnESPayload);

        return result;
    }

    this.syncDelete = function (input, result)
    {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var ethernetSegment = parseTarget.getUniqueIdentifier(input.getTarget());
        var objectFullName = "network:" + neId + ":es-" + ethernetSegment;
        if (neId && String(neId).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        }
        this.preDelete(neId, ethernetSegment)
        logger.info("Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }

    this.xml2object = function (xmlElement)
    {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }

    this.loadSavedObjectsFromTopology = function (savedTopology)
    {
        if (savedTopology)
        {
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0)
            {
                topoObjects.forEach(function (topoObject)
                {
                    mapFwk.set(savedObjects, topoObject.getObjectType(), topoObject.getObjectRelativeObjectID());
                });
            }
        }
    }

    this.deleteRemovedObjects = function (target)
    {
        if (Object.keys(savedObjects).length > 0)
        {
            for (var key in savedObjects)
            {
                var value = mapFwk.get(currentObjects, key);
                if (value == undefined || value == "undefined" || value == null)
                {
                    logger.info("To be Deleted " + key);
                    var objectFullName = key;
                    if (target && String(target).indexOf(':') !== -1) {
                        objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
                    }
                    var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

                    if (!deleteResult.success) {
                        throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
                    }
                }
            }
        }
    }

    this.loadCurrentObjectsToTopology = function (target)
    {
        var currentTopo = topologyFactory.createServiceTopology();
        if (Object.keys(currentObjects).length)
        {
            for (var key in currentObjects)
            {
                objectId = mapFwk.get(currentObjects, key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key, objectId, "INFRASTRUCTURE", target, ""));
            }
        }
        return currentTopo;
    }

    this.removeEmptyContainers = function (prop, intentJson, path, target)
    {
        if (Array.isArray(intentJson))
        {
            var object = [];
            for (var prop in intentJson)
            {
                var value = this.removeEmptyContainers(prop, intentJson[prop], path, target);
                if (value)
                {
                    object.push(value);
                }

            }
            if (Object.keys(object).length !== 0)
            {
                return object;
            }
        }
        else if (typeof intentJson == 'object')
        {
            var object = {};
            for (var prop in intentJson)
            {
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop, intentJson[prop], pPath, target);
                if ((value && value !== null) || value == 0)
                {
                    object[prop] = value;
                }
            }
            if (Object.keys(object).length !== 0)
            {
                return object;
            }
        }
        else
        {
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if (intentJson !== undefined && intentJson !== "")
            {
                return intentJson;
            }
            return null;
        }
    }
}
