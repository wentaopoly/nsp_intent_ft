var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function(target, initialPropertyName) {

        let neId = parseTarget.getNeIdFromTarget(target);
        let accPolicyId = util.getAccountingPolicyId(target);

        let accountingPolicyConfig = this.getAccountingPolicyConfiguration(neId,accPolicyId);
        let filePolicyId = accountingPolicyConfig['accounting.Policy']['fileId'];
        let filePolicyConfig
        if(filePolicyId != null){
            filePolicyConfig = this.getFilePolicyConfiguration(neId,filePolicyId);
        }else{
            throw new RuntimeException("There is no file policy with associated with this accounting Policy.");
        }

        let deviceConfig = {
            "accountingPolicyConfig": accountingPolicyConfig,
            "filePolicyConfig": filePolicyConfig
        };
        logger.info("*********************************deviceConfigSTART*************************************");
        logger.info(JSON.stringify(deviceConfig));
        logger.info("*********************************deviceConfigEND*************************************");
        return deviceConfig;
    }

    this.getAccountingPolicyConfiguration = function (neId, policyId) {
        let jsonPayLoad = {
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "id",
                            "value": policyId
                        }
                    ]
                }
            },
            "fullClassName": "accounting.Policy"
        };

        let searchResponse = nfmpFwk.post("/v3/search", jsonPayLoad);
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                throw new RuntimeException("Failed to get Accounting Policy info from nfm-p for Ne " + neId + " and Policy Id: " + policyId);
            if(JSON.parse(searchResponse["response"]).length === 0)
                throw new RuntimeException("There is no Accounting Policy with Id:"+policyId);
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse;
    }

    this.getFilePolicyConfiguration = function (neId, policyId) {
        let jsonPayLoad = {
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "id",
                            "value": policyId
                        }
                    ]
                }
            },
            "fullClassName": "file.Policy"
        };

        let searchResponse = nfmpFwk.post("/v3/search", jsonPayLoad);
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                throw new RuntimeException("Failed to get File Policy info from nfm-p for Ne " + neId + " and Policy Id: " + policyId);
            if(JSON.parse(searchResponse["response"]).length === 0)
                throw new RuntimeException("There is no File Policy with Id:"+policyId);
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse;
    }

    this.extractDeviceConfig = function(defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        let filePolicyConfig = deviceConfig['filePolicyConfig']['file.Policy'];
        let accountingPolicyConfig = deviceConfig['accountingPolicyConfig']['accounting.Policy'];
        if (null !== filePolicyConfig)
        {
            this.extractFilePolicyProperties(parsedDefaultTargetData, filePolicyConfig);
        }

        if (null !== accountingPolicyConfig){
            this.extractAccountingPolicyProperties(parsedDefaultTargetData, accountingPolicyConfig);
        }

        let childrenConfig = accountingPolicyConfig["children-Set"];
        if (undefined !== childrenConfig && null !== childrenConfig && childrenConfig.length !== 0) {
            //customRecord, ref-queue, ref-policer
            if(childrenConfig["accounting.CustomRecord"]!== null && typeof childrenConfig["accounting.CustomRecord"] === 'object'){
                let customRecordData = parsedDefaultTargetData['log']['accounting-policy']['custom-record'];
                if (customRecordData !== null && customRecordData !== undefined ) {
                    let customRecordConfig = this.extractCustomRecordProperties(customRecordData, childrenConfig["accounting.CustomRecord"]);
                    parsedDefaultTargetData['log']['accounting-policy']['custom-record'] = customRecordConfig;
                }
            }
            else{
                delete parsedDefaultTargetData['log']['accounting-policy']['custom-record'];
            }

            //QueueConfig
            if(childrenConfig["accounting.CustomQueueConfig"]!== null && childrenConfig["accounting.CustomQueueConfig"]!== undefined && childrenConfig["accounting.CustomQueueConfig"].length !== 0){
                let customRecordQueueData = parsedDefaultTargetData['log']['accounting-policy']['custom-record']['queue'];
                if (customRecordQueueData !== null && customRecordQueueData.length !== 0) {
                    let customRecordQueueArray = this.extractCustomRecordQueueProperties(customRecordQueueData, childrenConfig["accounting.CustomQueueConfig"]);
                    parsedDefaultTargetData['log']['accounting-policy']['custom-record']['queue'] = customRecordQueueArray;
                }
            }
            else{
                delete parsedDefaultTargetData['log']['accounting-policy']['custom-record']['queue'];
            }

            //PolicerConfig
            if(childrenConfig["accounting.Policer"]!== null && childrenConfig["accounting.Policer"]!== undefined && childrenConfig["accounting.Policer"].length !== 0){
                let customRecordPolicerData = parsedDefaultTargetData['log']['accounting-policy']['custom-record']['policer'];
                if (customRecordPolicerData !== null && customRecordPolicerData.length !== 0) {
                    let customRecordPolicerArray = this.extractCustomRecordPolicerProperties(customRecordPolicerData, childrenConfig["accounting.Policer"]);
                    parsedDefaultTargetData['log']['accounting-policy']['custom-record']['policer'] = customRecordPolicerArray;
                }
            }
            else{
                delete parsedDefaultTargetData['log']['accounting-policy']['custom-record']['policer'];
            }

            //AA-specific Config
            if(childrenConfig["accounting.CustomAAConfig"]!== null && typeof childrenConfig["accounting.CustomAAConfig"] === 'object'){
                let customAAConfigData = parsedDefaultTargetData['log']['accounting-policy']['custom-record']['aa-specific'];
                if (customAAConfigData !== null && customAAConfigData !== undefined ) {
                    let customAAConfig = this.extractCustomAAConfigProperties(customAAConfigData, childrenConfig["accounting.CustomAAConfig"]);
                    parsedDefaultTargetData['log']['accounting-policy']['custom-record']['aa-specific'] = customAAConfig;
                }
            }
            else{
                delete parsedDefaultTargetData['log']['accounting-policy']['custom-record']['aa-specific'];
            }
        }
        else{
            delete parsedDefaultTargetData['log']['accounting-policy']['custom-record'];
        }

        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData))
        return parsedDefaultTargetData;
    }

    this.extractCustomAAConfigProperties = function (customAAConfigData, customAADeviceConfig){
        customAAConfigData = JSON.parse(JSON.stringify(customAAConfigData));
        //aa-sub-counters
        customAAConfigData['aa-sub-counters']['long-duration-flow-count'] = (customAADeviceConfig['applicationAssuranceCounter'].indexOf("ldf") > -1) ? true : false;
        customAAConfigData['aa-sub-counters']['medium-duration-flow-count'] = (customAADeviceConfig['applicationAssuranceCounter'].indexOf("mdf") > -1) ? true : false;
        customAAConfigData['aa-sub-counters']['short-duration-flow-count'] = (customAADeviceConfig['applicationAssuranceCounter'].indexOf("sdf") > -1) ? true : false;
        customAAConfigData['aa-sub-counters']['total-flow-duration'] = (customAADeviceConfig['applicationAssuranceCounter'].indexOf("tfd") > -1) ? true : false;
        customAAConfigData['aa-sub-counters']['total-flows-completed-count'] = (customAADeviceConfig['applicationAssuranceCounter'].indexOf("tfc") > -1) ? true : false;
        //from-aa-sub-counters
        customAAConfigData['from-aa-sub-counters']['flows-active-count'] = (customAADeviceConfig['fromSubCounter'].indexOf("saf") > -1) ? true : false;
        customAAConfigData['from-aa-sub-counters']['flows-admitted-count'] = (customAADeviceConfig['fromSubCounter'].indexOf("sfa") > -1) ? true : false;
        customAAConfigData['from-aa-sub-counters']['flows-denied-count'] = (customAADeviceConfig['fromSubCounter'].indexOf("sfd") > -1) ? true : false;
        customAAConfigData['from-aa-sub-counters']['forwarding-class'] = (customAADeviceConfig['fromSubCounter'].indexOf("sfc") > -1) ? true : false;
        customAAConfigData['from-aa-sub-counters']['max-throughput-octet-count'] = (customAADeviceConfig['fromSubCounter'].indexOf("sbm") > -1) ? true : false;
        customAAConfigData['from-aa-sub-counters']['max-throughput-packet-count'] = (customAADeviceConfig['fromSubCounter'].indexOf("spm") > -1) ? true : false;
        customAAConfigData['from-aa-sub-counters']['max-throughput-timestamp'] = (customAADeviceConfig['fromSubCounter'].indexOf("smt") > -1) ? true : false;
        customAAConfigData['from-aa-sub-counters']['octets-admitted-count'] = (customAADeviceConfig['fromSubCounter'].indexOf("sba") > -1) ? true : false;
        customAAConfigData['from-aa-sub-counters']['octets-denied-count'] = (customAADeviceConfig['fromSubCounter'].indexOf("sbd") > -1) ? true : false;
        customAAConfigData['from-aa-sub-counters']['packets-admitted-count'] = (customAADeviceConfig['fromSubCounter'].indexOf("spa") > -1) ? true : false;
        customAAConfigData['from-aa-sub-counters']['packets-denied-count'] = (customAADeviceConfig['fromSubCounter'].indexOf("spd") > -1) ? true : false;
        //aa-sub-attributes
        customAAConfigData['aa-sub-attributes']['app-profile'] = (customAADeviceConfig['optionalAttributes'].indexOf("appProfile") > -1) ? true : false;
        customAAConfigData['aa-sub-attributes']['app-service-options'] = (customAADeviceConfig['optionalAttributes'].indexOf("appServiceOption") > -1) ? true : false;
        //to-aa-sub-counters
        customAAConfigData['to-aa-sub-counters']['flows-active-count'] = (customAADeviceConfig['toSubCounter'].indexOf("naf") > -1) ? true : false;
        customAAConfigData['to-aa-sub-counters']['flows-admitted-count'] = (customAADeviceConfig['toSubCounter'].indexOf("nfa") > -1) ? true : false;
        customAAConfigData['to-aa-sub-counters']['flows-denied-count'] = (customAADeviceConfig['toSubCounter'].indexOf("nfd") > -1) ? true : false;
        customAAConfigData['to-aa-sub-counters']['forwarding-class'] = (customAADeviceConfig['toSubCounter'].indexOf("nfc") > -1) ? true : false;
        customAAConfigData['to-aa-sub-counters']['max-throughput-octet-count'] = (customAADeviceConfig['toSubCounter'].indexOf("nbm") > -1) ? true : false;
        customAAConfigData['to-aa-sub-counters']['max-throughput-packet-count'] = (customAADeviceConfig['toSubCounter'].indexOf("npm") > -1) ? true : false;
        customAAConfigData['to-aa-sub-counters']['max-throughput-timestamp'] = (customAADeviceConfig['toSubCounter'].indexOf("nmt") > -1) ? true : false;
        customAAConfigData['to-aa-sub-counters']['octets-admitted-count'] = (customAADeviceConfig['toSubCounter'].indexOf("nba") > -1) ? true : false;
        customAAConfigData['to-aa-sub-counters']['octets-denied-count'] = (customAADeviceConfig['toSubCounter'].indexOf("nbd") > -1) ? true : false;
        customAAConfigData['to-aa-sub-counters']['packets-admitted-count'] = (customAADeviceConfig['toSubCounter'].indexOf("npa") > -1) ? true : false;
        customAAConfigData['to-aa-sub-counters']['packets-denied-count'] = (customAADeviceConfig['toSubCounter'].indexOf("npd") > -1) ? true : false;

        return customAAConfigData;
    }

    this.extractCustomRecordPolicerProperties = function (customRecordPolicerData, customPolicerDeviceConfig){
        let customRecordPolicerDefaults = customRecordPolicerData[0];
        let customRecordPolicerArray = [];
        if (Array.isArray(customPolicerDeviceConfig)) {
            for (let i = 0; i < customPolicerDeviceConfig.length; i++) {
                let policerConfig = customPolicerDeviceConfig[i];
                let customRecordPolicerConfig = this.customRecordPolicerData(customRecordPolicerDefaults, policerConfig);
                customRecordPolicerArray.push(customRecordPolicerConfig);
            }
        } else {
            let policerConfig = customPolicerDeviceConfig;
            let customRecordPolicerConfig = this.customRecordPolicerData(customRecordPolicerDefaults, policerConfig);
            customRecordPolicerArray.push(customRecordPolicerConfig);

        }
        return customRecordPolicerArray;
    }

    this.customRecordPolicerData = function (customRecordPolicerDefaults, policerConfig){
        let customRecordPolicerData = JSON.parse(JSON.stringify(customRecordPolicerDefaults));
        customRecordPolicerData['id'] = policerConfig['id'];
        //i-counters
        customRecordPolicerData['i-counters']['in-profile-octets-discarded-count'] = (policerConfig['ingressCounter'].indexOf("hod") > -1) ? true : false;
        customRecordPolicerData['i-counters']['in-profile-octets-offered-count'] = (policerConfig['ingressCounter'].indexOf("hoo") > -1) ? true : false;
        customRecordPolicerData['i-counters']['in-profile-packets-discarded-count'] = (policerConfig['ingressCounter'].indexOf("hpd") > -1) ? true : false;
        customRecordPolicerData['i-counters']['in-profile-packets-offered-count'] = (policerConfig['ingressCounter'].indexOf("hpo") > -1) ? true : false;
        customRecordPolicerData['i-counters']['in-profile-octets-forwarded-count'] = (policerConfig['ingressCounter'].indexOf("iof") > -1) ? true : false;
        customRecordPolicerData['i-counters']['in-profile-packets-forwarded-count'] = (policerConfig['ingressCounter'].indexOf("ipf") > -1) ? true : false;
        customRecordPolicerData['i-counters']['out-profile-octets-discarded-count'] = (policerConfig['ingressCounter'].indexOf("lod") > -1) ? true : false;
        customRecordPolicerData['i-counters']['out-profile-octets-offered-count'] = (policerConfig['ingressCounter'].indexOf("loo") > -1) ? true : false;
        customRecordPolicerData['i-counters']['out-profile-packets-discarded-count'] = (policerConfig['ingressCounter'].indexOf("lpd") > -1) ? true : false;
        customRecordPolicerData['i-counters']['out-profile-packets-offered-count'] = (policerConfig['ingressCounter'].indexOf("lpo") > -1) ? true : false;
        customRecordPolicerData['i-counters']['out-profile-octets-forwarded-count'] = (policerConfig['ingressCounter'].indexOf("oof") > -1) ? true : false;
        customRecordPolicerData['i-counters']['out-profile-packets-forwarded-count'] = (policerConfig['ingressCounter'].indexOf("opf") > -1) ? true : false;
        customRecordPolicerData['i-counters']['uncoloured-octets-offered-count'] = (policerConfig['ingressCounter'].indexOf("uco") > -1) ? true : false;
        customRecordPolicerData['i-counters']['uncoloured-packets-offered-count'] = (policerConfig['ingressCounter'].indexOf("ucp") > -1) ? true : false;
        //e-counters
        customRecordPolicerData['e-counters']['in-profile-octets-discarded-count'] = (policerConfig['egressCounter'].indexOf("hod") > -1) ? true : false;
        customRecordPolicerData['e-counters']['in-profile-octets-offered-count'] = (policerConfig['egressCounter'].indexOf("hoo") > -1) ? true : false;
        customRecordPolicerData['e-counters']['in-profile-packets-discarded-count'] = (policerConfig['egressCounter'].indexOf("hpd") > -1) ? true : false;
        customRecordPolicerData['e-counters']['in-profile-packets-offered-count'] = (policerConfig['egressCounter'].indexOf("hpo") > -1) ? true : false;
        customRecordPolicerData['e-counters']['in-profile-octets-forwarded-count'] = (policerConfig['egressCounter'].indexOf("iof") > -1) ? true : false;
        customRecordPolicerData['e-counters']['in-profile-packets-forwarded-count'] = (policerConfig['egressCounter'].indexOf("ipf") > -1) ? true : false;
        customRecordPolicerData['e-counters']['out-profile-octets-discarded-count'] = (policerConfig['egressCounter'].indexOf("lod") > -1) ? true : false;
        customRecordPolicerData['e-counters']['out-profile-octets-offered-count'] = (policerConfig['egressCounter'].indexOf("loo") > -1) ? true : false;
        customRecordPolicerData['e-counters']['out-profile-packets-discarded-count'] = (policerConfig['egressCounter'].indexOf("lpd") > -1) ? true : false;
        customRecordPolicerData['e-counters']['out-profile-packets-offered-count'] = (policerConfig['egressCounter'].indexOf("lpo") > -1) ? true : false;
        customRecordPolicerData['e-counters']['out-profile-octets-forwarded-count'] = (policerConfig['egressCounter'].indexOf("oof") > -1) ? true : false;
        customRecordPolicerData['e-counters']['out-profile-packets-forwarded-count'] = (policerConfig['egressCounter'].indexOf("opf") > -1) ? true : false;
        customRecordPolicerData['e-counters']['uncoloured-octets-offered-count'] = (policerConfig['egressCounter'].indexOf("uco") > -1) ? true : false;
        customRecordPolicerData['e-counters']['uncoloured-packets-offered-count'] = (policerConfig['egressCounter'].indexOf("ucp") > -1) ? true : false;
        customRecordPolicerData['e-counters']['exceed-profile-octets-discarded-count'] = (policerConfig['egressCounter'].indexOf("xod") > -1) ? true : false;
        customRecordPolicerData['e-counters']['exceed-profile-octets-forwarded-count'] = (policerConfig['egressCounter'].indexOf("xof") > -1) ? true : false;
        customRecordPolicerData['e-counters']['exceed-profile-octets-offered-count'] = (policerConfig['egressCounter'].indexOf("xoo") > -1) ? true : false;
        customRecordPolicerData['e-counters']['exceed-profile-packets-discarded-count'] = (policerConfig['egressCounter'].indexOf("xpd") > -1) ? true : false;
        customRecordPolicerData['e-counters']['exceed-profile-packets-forwarded-count'] = (policerConfig['egressCounter'].indexOf("xpf") > -1) ? true : false;
        customRecordPolicerData['e-counters']['exceed-profile-packets-offered-count'] = (policerConfig['egressCounter'].indexOf("xpo") > -1) ? true : false;
        customRecordPolicerData['e-counters']['in-plus-profile-octets-discarded-count'] = (policerConfig['egressCounter'].indexOf("pod") > -1) ? true : false;
        customRecordPolicerData['e-counters']['in-plus-profile-octets-forwarded-count'] = (policerConfig['egressCounter'].indexOf("pof") > -1) ? true : false;
        customRecordPolicerData['e-counters']['in-plus-profile-octets-offered-count'] = (policerConfig['egressCounter'].indexOf("poo") > -1) ? true : false;
        customRecordPolicerData['e-counters']['in-plus-profile-packets-discarded-count'] = (policerConfig['egressCounter'].indexOf("ppd") > -1) ? true : false;
        customRecordPolicerData['e-counters']['in-plus-profile-packets-forwarded-count'] = (policerConfig['egressCounter'].indexOf("ppf") > -1) ? true : false;
        customRecordPolicerData['e-counters']['in-plus-profile-packets-offered-count'] = (policerConfig['egressCounter'].indexOf("ppo") > -1) ? true : false;

        return customRecordPolicerData;
    }

    this.extractCustomRecordQueueProperties = function (customRecordQueueData, customQueueDeviceConfig){
        let customRecordQueueDefaults = customRecordQueueData[0];
        let customRecordQueueArray = [];
        if (Array.isArray(customQueueDeviceConfig)) {
            for (let i = 0; i < customQueueDeviceConfig.length; i++) {
                let queueConfig = customQueueDeviceConfig[i];
                let customRecordQueueConfig = this.customRecordQueueData(customRecordQueueDefaults, queueConfig);
                customRecordQueueArray.push(customRecordQueueConfig);
            }
        } else {
            let queueConfig = customQueueDeviceConfig;
            let customRecordQueueConfig = this.customRecordQueueData(customRecordQueueDefaults, queueConfig);
            customRecordQueueArray.push(customRecordQueueConfig);

        }
        return customRecordQueueArray;
    }

    this.customRecordQueueData = function (customRecordQueueDefaults, queueConfig){
        let customRecordQueueData = JSON.parse(JSON.stringify(customRecordQueueDefaults));
        customRecordQueueData['id'] = queueConfig['id'];
        //i-counters
        customRecordQueueData['i-counters']['all-octets-offered-count'] = (queueConfig['ingressCounter'].indexOf("aoo") > -1) ? true : false;
        customRecordQueueData['i-counters']['all-packets-offered-count'] = (queueConfig['ingressCounter'].indexOf("apo") > -1) ? true : false;
        customRecordQueueData['i-counters']['high-octets-discarded-count'] = (queueConfig['ingressCounter'].indexOf("hod") > -1) ? true : false;
        customRecordQueueData['i-counters']['high-packets-discarded-count'] = (queueConfig['ingressCounter'].indexOf("hpd") > -1) ? true : false;
        customRecordQueueData['i-counters']['in-profile-octets-forwarded-count'] = (queueConfig['ingressCounter'].indexOf("iof") > -1) ? true : false;
        customRecordQueueData['i-counters']['in-profile-packets-forwarded-count'] = (queueConfig['ingressCounter'].indexOf("ipf") > -1) ? true : false;
        customRecordQueueData['i-counters']['low-octets-discarded-count'] = (queueConfig['ingressCounter'].indexOf("lod") > -1) ? true : false;
        customRecordQueueData['i-counters']['low-packets-discarded-count'] = (queueConfig['ingressCounter'].indexOf("lpd") > -1) ? true : false;
        customRecordQueueData['i-counters']['out-profile-octets-forwarded-count'] = (queueConfig['ingressCounter'].indexOf("oof") > -1) ? true : false;
        customRecordQueueData['i-counters']['out-profile-packets-forwarded-count'] = (queueConfig['ingressCounter'].indexOf("opf") > -1) ? true : false;
        customRecordQueueData['i-counters']['high-octets-offered-count'] = (queueConfig['ingressCounter'].indexOf("hoo") > -1) ? true : false;
        customRecordQueueData['i-counters']['high-packets-offered-count'] = (queueConfig['ingressCounter'].indexOf("hpo") > -1) ? true : false;
        customRecordQueueData['i-counters']['low-octets-offered-count'] = (queueConfig['ingressCounter'].indexOf("loo") > -1) ? true : false;
        customRecordQueueData['i-counters']['low-packets-offered-count'] = (queueConfig['ingressCounter'].indexOf("lpo") > -1) ? true : false;
        customRecordQueueData['i-counters']['uncoloured-octets-offered-count'] = (queueConfig['ingressCounter'].indexOf("uco") > -1) ? true : false;
        customRecordQueueData['i-counters']['uncoloured-packets-offered-count'] = (queueConfig['ingressCounter'].indexOf("ucp") > -1) ? true : false;
        //e-counters
        customRecordQueueData['e-counters']['in-profile-octets-discarded-count'] = (queueConfig['egressCounter'].indexOf("lod") > -1) ? true : false;
        customRecordQueueData['e-counters']['in-profile-octets-forwarded-count'] = (queueConfig['egressCounter'].indexOf("iof") > -1) ? true : false;
        customRecordQueueData['e-counters']['in-profile-packets-discarded-count'] = (queueConfig['egressCounter'].indexOf("ipd") > -1) ? true : false;
        customRecordQueueData['e-counters']['in-profile-packets-forwarded-count'] = (queueConfig['egressCounter'].indexOf("ipf") > -1) ? true : false;
        customRecordQueueData['e-counters']['out-profile-octets-discarded-count'] = (queueConfig['egressCounter'].indexOf("ood") > -1) ? true : false;
        customRecordQueueData['e-counters']['out-profile-octets-forwarded-count'] = (queueConfig['egressCounter'].indexOf("oof") > -1) ? true : false;
        customRecordQueueData['e-counters']['out-profile-packets-discarded-count'] = (queueConfig['egressCounter'].indexOf("opd") > -1) ? true : false;
        customRecordQueueData['e-counters']['out-profile-packets-forwarded-count'] = (queueConfig['egressCounter'].indexOf("opf") > -1) ? true : false;

        return customRecordQueueData;
    }

    this.extractCustomRecordProperties = function (customRecordData, customRecordDeviceConfig){
        customRecordData = JSON.parse(JSON.stringify(customRecordData));
        customRecordData['significant-change'] = customRecordDeviceConfig['delta'];
        customRecordData["ref-aa-specific-counter"]["any"] = (customRecordDeviceConfig['significantApplicationAssuranceCounter'].indexOf("any") > -1) ? true : false;
        //ref-queue
        delete customRecordData["ref-queue"]["queue"];
        if(customRecordDeviceConfig["allQueues"] == "true"){
            customRecordData["ref-queue"]["all"] = [null];
            delete customRecordData["ref-queue"]["id"];
        }else{
            delete customRecordData["ref-queue"]["all"];
            if (customRecordDeviceConfig['queuePointer'] != ""){
                customRecordData["ref-queue"]["id"] = parseInt(customRecordDeviceConfig['queuePointer'].split(':QId-')[1]);
            }
            else{
                delete customRecordData["ref-queue"]["id"]
            }
        }
        customRecordData["ref-queue"]["i-counters"]['all-octets-offered-count'] = (customRecordDeviceConfig['significantIngressQueueCounter'].indexOf("aoo") > -1) ? true : false;
        customRecordData["ref-queue"]["i-counters"]['all-packets-offered-count'] = (customRecordDeviceConfig['significantIngressQueueCounter'].indexOf("apo") > -1) ? true : false;
        customRecordData["ref-queue"]["i-counters"]['high-octets-discarded-count'] = (customRecordDeviceConfig['significantIngressQueueCounter'].indexOf("hod") > -1) ? true : false;
        customRecordData["ref-queue"]["i-counters"]['high-packets-discarded-count'] = (customRecordDeviceConfig['significantIngressQueueCounter'].indexOf("hpd") > -1) ? true : false;
        customRecordData["ref-queue"]["i-counters"]['in-profile-octets-forwarded-count'] = (customRecordDeviceConfig['significantIngressQueueCounter'].indexOf("iof") > -1) ? true : false;
        customRecordData["ref-queue"]["i-counters"]['in-profile-packets-forwarded-count'] = (customRecordDeviceConfig['significantIngressQueueCounter'].indexOf("ipf") > -1) ? true : false;
        customRecordData["ref-queue"]["i-counters"]['low-octets-discarded-count'] = (customRecordDeviceConfig['significantIngressQueueCounter'].indexOf("lod") > -1) ? true : false;
        customRecordData["ref-queue"]["i-counters"]['low-packets-discarded-count'] = (customRecordDeviceConfig['significantIngressQueueCounter'].indexOf("lpd") > -1) ? true : false;
        customRecordData["ref-queue"]["i-counters"]['out-profile-octets-forwarded-count'] = (customRecordDeviceConfig['significantIngressQueueCounter'].indexOf("oof") > -1) ? true : false;
        customRecordData["ref-queue"]["i-counters"]['out-profile-packets-forwarded-count'] = (customRecordDeviceConfig['significantIngressQueueCounter'].indexOf("opf") > -1) ? true : false;
        customRecordData["ref-queue"]["i-counters"]['high-octets-offered-count'] = (customRecordDeviceConfig['significantIngressQueueCounter'].indexOf("hoo") > -1) ? true : false;
        customRecordData["ref-queue"]["i-counters"]['high-packets-offered-count'] = (customRecordDeviceConfig['significantIngressQueueCounter'].indexOf("hpo") > -1) ? true : false;
        customRecordData["ref-queue"]["i-counters"]['low-octets-offered-count'] = (customRecordDeviceConfig['significantIngressQueueCounter'].indexOf("loo") > -1) ? true : false;
        customRecordData["ref-queue"]["i-counters"]['low-packets-offered-count'] = (customRecordDeviceConfig['significantIngressQueueCounter'].indexOf("lpo") > -1) ? true : false;
        customRecordData["ref-queue"]["i-counters"]['uncoloured-octets-offered-count'] = (customRecordDeviceConfig['significantIngressQueueCounter'].indexOf("uco") > -1) ? true : false;
        customRecordData["ref-queue"]["i-counters"]['uncoloured-packets-offered-count'] = (customRecordDeviceConfig['significantIngressQueueCounter'].indexOf("ucp") > -1) ? true : false;
        customRecordData["ref-queue"]["e-counters"]['in-profile-octets-discarded-count'] = (customRecordDeviceConfig['significantEgressQueueCounter'].indexOf("lod") > -1) ? true : false;
        customRecordData["ref-queue"]["e-counters"]['in-profile-octets-forwarded-count'] = (customRecordDeviceConfig['significantEgressQueueCounter'].indexOf("iof") > -1) ? true : false;
        customRecordData["ref-queue"]["e-counters"]['in-profile-packets-discarded-count'] = (customRecordDeviceConfig['significantEgressQueueCounter'].indexOf("ipd") > -1) ? true : false;
        customRecordData["ref-queue"]["e-counters"]['in-profile-packets-forwarded-count'] = (customRecordDeviceConfig['significantEgressQueueCounter'].indexOf("ipf") > -1) ? true : false;
        customRecordData["ref-queue"]["e-counters"]['out-profile-octets-discarded-count'] = (customRecordDeviceConfig['significantEgressQueueCounter'].indexOf("ood") > -1) ? true : false;
        customRecordData["ref-queue"]["e-counters"]['out-profile-octets-forwarded-count'] = (customRecordDeviceConfig['significantEgressQueueCounter'].indexOf("oof") > -1) ? true : false;
        customRecordData["ref-queue"]["e-counters"]['out-profile-packets-discarded-count'] = (customRecordDeviceConfig['significantEgressQueueCounter'].indexOf("opd") > -1) ? true : false;
        customRecordData["ref-queue"]["e-counters"]['out-profile-packets-forwarded-count'] = (customRecordDeviceConfig['significantEgressQueueCounter'].indexOf("opf") > -1) ? true : false;
        //ref-policer
        delete customRecordData["ref-policer"]["policer"];
        if(customRecordDeviceConfig["allPolicers"] == "true"){
            customRecordData["ref-policer"]["all"] = [null];
            delete customRecordData["ref-policer"]["id"];
        }else{
            delete customRecordData["ref-policer"]["all"];
            if (customRecordDeviceConfig['policerPointer'] != ""){
                customRecordData["ref-policer"]["id"] = parseInt(customRecordDeviceConfig['policerPointer'].split(':Policer-')[1]);
            }
            else{
                delete customRecordData["ref-policer"]["id"];
            }
        }
        //customRecordData["ref-policer"]["all"] = customRecordDeviceConfig['allPolicers'];
        customRecordData["ref-policer"]["i-counters"]['in-profile-octets-discarded-count'] = (customRecordDeviceConfig['significantIngressPolicerCounter'].indexOf("hod") > -1) ? true : false;
        customRecordData["ref-policer"]["i-counters"]['in-profile-octets-offered-count'] = (customRecordDeviceConfig['significantIngressPolicerCounter'].indexOf("hoo") > -1) ? true : false;
        customRecordData["ref-policer"]["i-counters"]['in-profile-packets-discarded-count'] = (customRecordDeviceConfig['significantIngressPolicerCounter'].indexOf("hpd") > -1) ? true : false;
        customRecordData["ref-policer"]["i-counters"]['in-profile-packets-offered-count'] = (customRecordDeviceConfig['significantIngressPolicerCounter'].indexOf("hpo") > -1) ? true : false;
        customRecordData["ref-policer"]["i-counters"]['in-profile-octets-forwarded-count'] = (customRecordDeviceConfig['significantIngressPolicerCounter'].indexOf("iof") > -1) ? true : false;
        customRecordData["ref-policer"]["i-counters"]['in-profile-packets-forwarded-count'] = (customRecordDeviceConfig['significantIngressPolicerCounter'].indexOf("ipf") > -1) ? true : false;
        customRecordData["ref-policer"]["i-counters"]['out-profile-octets-discarded-count'] = (customRecordDeviceConfig['significantIngressPolicerCounter'].indexOf("lod") > -1) ? true : false;
        customRecordData["ref-policer"]["i-counters"]['out-profile-octets-offered-count'] = (customRecordDeviceConfig['significantIngressPolicerCounter'].indexOf("loo") > -1) ? true : false;
        customRecordData["ref-policer"]["i-counters"]['out-profile-packets-discarded-count'] = (customRecordDeviceConfig['significantIngressPolicerCounter'].indexOf("lpd") > -1) ? true : false;
        customRecordData["ref-policer"]["i-counters"]['out-profile-packets-offered-count'] = (customRecordDeviceConfig['significantIngressPolicerCounter'].indexOf("lpo") > -1) ? true : false;
        customRecordData["ref-policer"]["i-counters"]['out-profile-octets-forwarded-count'] = (customRecordDeviceConfig['significantIngressPolicerCounter'].indexOf("oof") > -1) ? true : false;
        customRecordData["ref-policer"]["i-counters"]['out-profile-packets-forwarded-count'] = (customRecordDeviceConfig['significantIngressPolicerCounter'].indexOf("opf") > -1) ? true : false;
        customRecordData["ref-policer"]["i-counters"]['uncoloured-octets-offered-count'] = (customRecordDeviceConfig['significantIngressPolicerCounter'].indexOf("uco") > -1) ? true : false;
        customRecordData["ref-policer"]["i-counters"]['uncoloured-packets-offered-count'] = (customRecordDeviceConfig['significantIngressPolicerCounter'].indexOf("ucp") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['in-profile-octets-discarded-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("hod") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['in-profile-octets-offered-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("hoo") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['in-profile-packets-discarded-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("hpd") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['in-profile-packets-offered-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("hpo") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['in-profile-octets-forwarded-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("iof") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['in-profile-packets-forwarded-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("ipf") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['out-profile-octets-discarded-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("lod") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['out-profile-octets-offered-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("loo") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['out-profile-packets-discarded-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("lpd") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['out-profile-packets-offered-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("lpo") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['out-profile-octets-forwarded-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("oof") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['out-profile-packets-forwarded-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("opf") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['uncoloured-octets-offered-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("uco") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['uncoloured-packets-offered-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("ucp") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['exceed-profile-octets-discarded-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("xod") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['exceed-profile-octets-forwarded-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("xof") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['exceed-profile-octets-offered-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("xoo") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['exceed-profile-packets-discarded-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("xpd") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['exceed-profile-packets-forwarded-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("xpf") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['exceed-profile-packets-offered-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("xpo") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['in-plus-profile-octets-discarded-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("pod") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['in-plus-profile-octets-forwarded-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("pof") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['in-plus-profile-octets-offered-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("poo") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['in-plus-profile-packets-discarded-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("ppd") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['in-plus-profile-packets-forwarded-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("ppf") > -1) ? true : false;
        customRecordData["ref-policer"]["e-counters"]['in-plus-profile-packets-offered-count'] = (customRecordDeviceConfig['significantEgressPolicerCounter'].indexOf("ppo") > -1) ? true : false;

        return customRecordData;
    }

    this.extractFilePolicyProperties = function (defaultTargetData, filePolicyConfig) {
        let targetKey = "log.file";//keys[i];
        let targetObj = defaultTargetData['log']['file'];//defaultTargetData[targetKey];
        if (targetObj !== null && typeof targetObj === 'object') {
            let mappings = modelDeviceMapping.getFilePolicyMapping();
            this.traverseAndUpdateFileConfig(targetKey, targetObj, filePolicyConfig, mappings);
        }
    }

    this.traverseAndUpdateFileConfig = function (objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (value != null && typeof value === 'object') {
                this.traverseAndUpdateFileConfig(mappedKey, value, parsedDeviceConfig, mappings);
            } else {
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
            }
        }
        return obj;
    }

    this.extractAccountingPolicyProperties = function (defaultTargetData, accountingPolicyConfig) {
        let targetKey = "log.accounting-policy";
        let targetObj = defaultTargetData['log']['accounting-policy'];
        if (targetObj !== null && typeof targetObj === 'object') {
            let mappings = modelDeviceMapping.getAccountingPolicyMapping();
            this.traverseAndUpdateAccountingConfig(targetKey, targetObj, accountingPolicyConfig, mappings);
        }
    }

    this.traverseAndUpdateAccountingConfig = function (objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "log.accounting-policy.custom-record") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateAccountingConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, deviceConfig) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = deviceConfig[nfmpKey];
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);
    }

    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue !== null)
        {
            switch (mappedKey)
            {
                case "log.file.compact-flash-location.primary":
                    deviceValue = util.transformToIntentPrimary(deviceValue);
                    break;
                case "log.file.compact-flash-location.backup":
                    deviceValue = util.transformToIntentPrimary(deviceValue);
                    break;
                case "log.accounting-policy.admin-state":
                    deviceValue = util.transformToIntentAdminState(deviceValue);
                    break;
                case "log.accounting-policy.record":
                    deviceValue = util.transformToIntentRecord(deviceValue);
                    break;
            }
            return deviceValue;
        }
    }
}
