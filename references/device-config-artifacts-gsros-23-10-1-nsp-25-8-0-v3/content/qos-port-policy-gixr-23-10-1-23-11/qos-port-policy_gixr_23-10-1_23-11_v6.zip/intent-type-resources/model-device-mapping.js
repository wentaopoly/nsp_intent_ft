function ModelDeviceMapping() {

    this.getMapping = function (type) {
        switch (type) {
            case "port-qos":
                return this.getPortQosPolicyNonChildMapping();
            case "fc":
                return this.getPortQosFcMapping();
            case "wrr-weights":
                return this.getPortQosWrrWeightsMapping();
            case "queue":
                return this.getPortQosQueueMapping();
            default:
                logger.info(LOG_PREFIX + "getMapping() mapping not specified - " + type);
        }
    }

    this.getPortQosPolicyNonChildMapping = function () {
        var mapping = {};
        mapping["port-qos.description"] = "description";
        mapping["port-qos.scope"] = "scope";
        mapping["port-qos.packet-byte-offset"] = "packetByteOffset";
        return mapping;
    }

    this.getPortQosFcMapping = function () {
        var mapping = {};
        mapping["fc.fc-name"] = "forwardingClass";
        mapping["fc.queue"] = "queueId";
        return mapping;
    }

    this.getPortQosWrrWeightsMapping = function () {
        var mapping = {};
        mapping["wrr-weights.wrr-weights-id"] = "id";
        mapping["wrr-weights.uc-weight"] = "ucWeight";
        mapping["wrr-weights.mc-weight"] = "mcWeight";
        return mapping;
    }

    this.getPortQosQueueMapping = function () {
        var mapping = {};
        mapping["queue.queue-id"] = "id";
        mapping["queue.queue-mgmt"] = "queueMgmtPolicy";
        mapping["queue.scheduler-mode"] = "schedulerMode";
        mapping["queue.scheduler-mode.wfq.percent-rate.pir"] = "pirPercent";
        mapping["queue.scheduler-mode.wfq.percent-rate.cir"] = "cirPercent";
        mapping["queue.scheduler-mode.wfq.pir-weight"] = "pirWeight";
        mapping["queue.adaptation-rule.pir"] = "pirAdaptation";
        mapping["queue.adaptation-rule.cir"] = "cirAdaptation";
        mapping["queue.wrr-weights"] = "wrrWeight";
        mapping["queue.low-latency"] = "lowLatency";
        return mapping;
    }
}
