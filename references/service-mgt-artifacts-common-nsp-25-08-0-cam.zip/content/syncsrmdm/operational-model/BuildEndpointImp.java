package com.nokia.nsp.mdt.intents.ibsf.resync.mdc;


import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

import com.alu.nms.common.util.model.ModelFdn;
import com.nokia.nsp.md.common.IExecutionContext;
import com.nokia.nsp.md.common.IYangObject;
import com.nokia.nsp.md.common.YangObject;
import com.nokia.nsp.md.db.yang.api.ExecutionContext;
import com.nokia.nsp.md.db.yang.api.QueryParameters;
import com.nokia.nsp.md.db.yang.util.XPathUtil;
import com.nokia.nsp.md.ifg.yang.api.Field;
import com.nokia.nsp.md.ifg.yang.api.Fields;
import com.nokia.nsp.md.resync.api.IMdResyncFw;
import com.nokia.nsp.md.resync.plugin.common.IBuildObjectFromAssociatedObject;
import com.nokia.nspos.model.domain.common.types.SourceType;
import com.nokia.nspos.persistence.impl.db.transaction.Transactor;
import com.nokia.nspos.persistence.impl.db.transaction.TxPhase;
import com.nokia.nspos.persistence.yang.api.IYangDB;
import com.nokia.nspos.persistence.yang.api.SourceData;
import javax.persistence.FlushModeType;

import org.jaxen.expr.XPathExpr;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;


@SuppressFBWarnings("RCN_REDUNDANT_NULLCHECK_WOULD_HAVE_BEEN_A_NPE")
public class BuildEndpointImp implements IBuildObjectFromAssociatedObject
{
    private static final Logger logger = LoggerFactory.getLogger(BuildEndpointImp.class.getName() + ".buildChild");
    static ThreadLocal<Map<String,EquipmentCache>> portLagCache=new ThreadLocal<>();
    static ThreadLocal<Map<String, String>> neNameCache = new ThreadLocal<>();
    static ThreadLocal<Map<String, String>> tenantIdSiteCache = new ThreadLocal<>();
    public IYangObject buildChild(Map<String, Object> aInDeviceObject,String aInNspClassId,QueryParameters aInQueryParameters,IYangObject aInParentObject,Map<String, Object> aInConvertedNspObjectFromDevice, IYangObject aInAssociatedObject, String aInNeId, IMdResyncFw aInMdResyncFw,String aInNodeType,String aInNodeVersion)
    {
        if(logger.isDebugEnabled())
        {
            logger.debug("Service object : aInQueryParameters=" + aInQueryParameters + ", aInNspClassId=" + aInNspClassId + ", aInParentObject=" + aInParentObject + ", aInDeviceObject=" + aInDeviceObject + ", aInConvertedNspObjectFromDevice=" + aInConvertedNspObjectFromDevice + ", aInAssociatedObject=" + aInAssociatedObject + ", aInNeId=" + aInNeId);
        }

        IYangObject lYoCreated = createEndpoint(aInParentObject,aInDeviceObject, aInConvertedNspObjectFromDevice, aInAssociatedObject, aInNeId, aInMdResyncFw, aInQueryParameters);
        updateEndpointsInSite(lYoCreated, aInAssociatedObject, aInMdResyncFw, aInQueryParameters);
        return lYoCreated;
    }

    private IYangObject createEndpoint(IYangObject aInParentObject,Map<String, Object> aInDeviceObject,
                                       Map<String, Object> aInConvertedNspObjectFromDevice, IYangObject aInAssociatedObject, String aInNeId, IMdResyncFw aInMdResyncFw,QueryParameters aInQueryParameters)
    {
        YangObject lEndpointYo = new YangObject(aInConvertedNspObjectFromDevice);
        String lClassId=aInParentObject.getClassId() +"/nsp-service:endpoint";
        lEndpointYo.setClassId(lClassId);
        Object lSourceObj = lEndpointYo.getExtraData("sources");
        String lSapName = "";
        String lFdn = null;
        if (lSourceObj != null && lSourceObj instanceof ArrayList) {
            ArrayList lSources = (ArrayList) lSourceObj;
            for (Object lSource : lSources) { //loop sources to find one with sap-id for l3
                if ((lSource.toString().contains("state") || lSource.toString().contains("configure")) && lSource.toString().contains("sap-id")) {
                    lFdn = lSource.toString();
                    break;
                }
            }
            if (lFdn == null) {
                for (Object lSource : lSources) { //loop sources to find one with sap-id for l3
                    if ((lSource.toString().contains("state") || lSource.toString().contains("configure")) && lSource.toString().contains("interface")) {
                        lFdn = lSource.toString();
                        break;
                    }
                }
            }
            if (lFdn == null) {
                lFdn = (String) lSources.get(0);
            }
            String lNeServiceId = null;
            if (lFdn.contains("service-name") && (lFdn.contains("interface-name") || lFdn.contains("sap-id"))) {


                if (aInAssociatedObject.hasProperty("ipservice-site-detail") &&
                    aInAssociatedObject.get("ipservice-site-detail") != null ) {

                    if (aInAssociatedObject.get("ipservice-site-detail") instanceof HashMap && !((HashMap) aInAssociatedObject.get("ipservice-site-detail")).isEmpty()) {
                        HashMap lIpSvcSiteDetailObj = (HashMap) aInAssociatedObject.get("ipservice-site-detail");
                        if (lIpSvcSiteDetailObj.containsKey("ne-service-id") && lIpSvcSiteDetailObj.get("ne-service-id") != null)
                            lNeServiceId = (String) lIpSvcSiteDetailObj.get("ne-service-id");

                    } else if (aInAssociatedObject.get("ipservice-site-detail") instanceof IYangObject) {
                        IYangObject lIpSvcSiteYangObj = (IYangObject) aInAssociatedObject.get("ipservice-site-detail");
                        if (lIpSvcSiteYangObj.hasProperty("ne-service-id") && lIpSvcSiteYangObj.get("ne-service-id") != null)
                            lNeServiceId = (String)lIpSvcSiteYangObj.get("ne-service-id");
                    }
                }
                if(lNeServiceId==null && aInParentObject!=null && aInParentObject.hasProperty("ne-service-id")){
                    lNeServiceId=(String)aInParentObject.get("ne-service-id");
                }
                if (lNeServiceId == null) {
                    XPathExpr lEpXpathExpr = XPathUtil.parse(lFdn.replaceFirst(".*?\\/", "/"));

                    Map<String, Object> lEpXpathSteps = new HashMap();
                    List<Map<String, Object>> lDeviceSvc = new ArrayList<>();
                    XPathUtil.processSteps(lEpXpathExpr, LinkedList::new, (nStep, out) -> {
                        if (out.size() == 2) {
                            lDeviceSvc.add(XPathUtil.simpleXpathValueLookup(nStep));
                        }
                        out.add(nStep);
                        lEpXpathSteps.put(nStep.getLocalName(), XPathUtil.simpleXpathValueLookup(nStep));
                        return out;
                    });
                    if (lDeviceSvc.size() == 1 && lDeviceSvc.get(0).containsKey("service-name") && lDeviceSvc.get(0).get("service-name") != null &&
                            ((String) lDeviceSvc.get(0).get("service-name")).matches("\\d+")) {
                        lNeServiceId = (String) lDeviceSvc.get(0).get("service-name");
                    }
                }

                String lSvcName = (lNeServiceId != null) ? "service-id='" + lNeServiceId + "'" : null;
                if (lFdn.contains("interface-name")) {
                    if (lSvcName != null) {
                        String lInterfaceFdn = "fdn:app:mdm-ami-cmodel:" + aInNeId + ":service:Endpoint:/service[" + lSvcName + "]" + lFdn.substring(lFdn.lastIndexOf("/interface"), lFdn.length()).replaceAll("\\/sap.*", "");
                        lSources.add(lInterfaceFdn);
                    }
                    if (aInDeviceObject.containsKey("sap")) {
                        Object lSapArrObj = aInDeviceObject.get("sap");
                        if (lSapArrObj instanceof ArrayList && ((ArrayList) lSapArrObj).size() == 1) {
                            Object lSapObj = ((ArrayList) lSapArrObj).get(0);
                            if (lSapObj instanceof HashMap) {
                                HashMap lMap = (HashMap) lSapObj;
                                if (lMap.containsKey("sap-id")) {
                                    lSapName = (String) lMap.get("sap-id");
                                    if (!lFdn.contains("/sap")) {
                                        lFdn += "/sap[sap-id='" + lSapName + "']";
                                    }
                                    if (lSvcName != null) {
                                        String lMdmAmiModelObj = "fdn:app:mdm-ami-cmodel:" + aInNeId + ":service:Endpoint:/service[" + lSvcName + "]/sap[sap-id='" + lSapName + "']";
                                        lSources.add(lMdmAmiModelObj);
                                    }
                                }
                            }
                        }
                    }

                } else {
                    lSapName = lFdn.substring(lFdn.lastIndexOf("[") + 1, lFdn.lastIndexOf("]"));
                    if (lSvcName != null) {
                        String lMdmAmiModelObj = "fdn:app:mdm-ami-cmodel:" + aInNeId + ":service:Endpoint:/service[" + lSvcName + "]/sap[" + lSapName + "]";
                        lSources.add(lMdmAmiModelObj);
                    }
                }

                if (lFdn.contains("interface-name")) {//l3vpn/ies only
                    //make sure 4 fdns are there int (conf/state) sap (conf/state)
                    String lIntSapConfFdn = lFdn.replace("state", "configure");
                    List<String> listFdns = new ArrayList();
                    listFdns.add(lIntSapConfFdn);
                    listFdns.add(lIntSapConfFdn.replace("configure", "state"));
                    String lIntConfFdn = lIntSapConfFdn.replaceAll("\\/sap.*", "");
                    listFdns.add(lIntConfFdn);
                    listFdns.add(lIntConfFdn.replace("configure", "state"));

                    for (String fdnToAdd : listFdns) {
                        if (!lSources.contains(fdnToAdd)) {
                            lSources.add(fdnToAdd);
                        }
                    }
                }
            }

            if (lFdn.contains("state")) {
                String fdnToAdd = lFdn.replace("state", "configure");
                if (!lSources.contains(fdnToAdd)) {
                    lSources.add(fdnToAdd);
                }
            } else if (lFdn.contains("configure")) {
                String fdnToAdd = lFdn.replace("configure", "state");
                if (!lSources.contains(fdnToAdd)) {
                    lSources.add(fdnToAdd);
                }
            }else{
                logger.error("fdn from nsp-model:sources should include state/configure. fdn="+lFdn);
            }
        } else{
            logger.error("aInDeviceObject doesn't include nsp-model:sources. aInDeviceObject="+aInConvertedNspObjectFromDevice);
        }

        QueryParameters lQueryParameters = new QueryParameters();
        lQueryParameters.setDepth(3);
        lQueryParameters.setLimit(2);
        lQueryParameters.setFields(Fields.parse("name;port-details/port-mode"));
        IYangDB lYangDb = aInMdResyncFw.getIYangDB();
        if(null != lEndpointYo.get("name") && !lSapName.equals("")) {
            //String lPortName = (String) lEndpointYo.get("name");
            //String lPortId = lPortName.split(":")[0];
            String lPortId = lSapName.split(":")[0];
            if(lPortId.contains("='")){
                lPortId = lPortId.split("='")[1].replaceAll("\'$","");
            }
            Map<String,EquipmentCache> lPortLagCache=portLagCache.get();
            if(null == lPortLagCache)
            {
                lPortLagCache=new HashMap<>();
                portLagCache.set(lPortLagCache);
                Transactor.getContext().addEventHandler(TxPhase.FINAL,(p,c) -> {
                    portLagCache.remove();
                });
            }
            EquipmentCache lFoundClassType=lPortLagCache.get(lPortId);
            if(null == lFoundClassType)
            {
                String lportFdn = "/nsp-equipment:network/network-element[ne-id='" + aInNeId + "']/hardware-component/port[name='" + lPortId + "']";
                String lClassName="equipment.Equipment";
                List<IYangObject> lYangList = new ArrayList<>();
                if(Transactor.isInTransaction()) {
                    FlushModeType lPreFlushModeType = Transactor.getContext().getEntityManager().getFlushMode();
                    Transactor.getContext().getEntityManager().setFlushMode(FlushModeType.COMMIT);
                    lYangList = lYangDb.getMany(lportFdn, lQueryParameters);
                    if (lPreFlushModeType.equals(FlushModeType.AUTO)) {
                        Transactor.getContext().getEntityManager().setFlushMode(FlushModeType.AUTO);
                    }
                }else{
                    lYangList =  lYangDb.getMany(lportFdn, lQueryParameters);
                }

                if (lYangList == null || lYangList.size() < 1) {
                    lportFdn = "/nsp-equipment:network/network-element[ne-id='" + aInNeId + "']/lag[lag-id='" + lPortId.replaceAll("(?i)^LAG","lag") + "']";
                    lClassName="equipment.Lag";
                    lQueryParameters.setFields(Fields.parse("name;lag-mode"));
                    lQueryParameters.setDepth(2);
                    if(Transactor.isInTransaction()) {
                        FlushModeType lFlushModeType = Transactor.getContext().getEntityManager().getFlushMode();
                        Transactor.getContext().getEntityManager().setFlushMode(FlushModeType.COMMIT);

                        lYangList = lYangDb.getMany(lportFdn, lQueryParameters);
                        if (lFlushModeType.equals(FlushModeType.AUTO)) {
                            Transactor.getContext().getEntityManager().setFlushMode(FlushModeType.AUTO);
                        }
                    }
                    else {
                        lYangList = lYangDb.getMany(lportFdn, lQueryParameters);
                    }
                }
                // logger.info("Port fdn: "+lportFdn);
                if (lYangList != null && lYangList.size() == 1) {
                    IYangObject lPortYangObj = lYangList.get(0);
                    String lPortName = lPortYangObj.getProperty("name").toString();
                    String portMode=null;
                    if(lPortYangObj.hasProperty("port-details") && lPortYangObj.get("port-details")!=null && ((LinkedList)lPortYangObj.get("port-details")).size()>0 && ((IYangObject)((LinkedList)lPortYangObj.get("port-details")).get(0)).hasProperty("port-mode")){
                        portMode = ((IYangObject)((LinkedList)lPortYangObj.get("port-details")).get(0)).get("port-mode").toString();
                    }
                    else if(lPortYangObj.hasProperty("lag-mode")) {
                        portMode = lPortYangObj.get("lag-mode").toString();
                    }
                    lFoundClassType=new EquipmentCache(lClassName,lPortYangObj.getIdentifier(), lPortName, portMode);
                    lPortLagCache.put(lPortId,lFoundClassType);
                }
            }

            // logger.info("Port fdn: "+lportFdn);
            if (null != lFoundClassType) {
                HashMap lPortBdgMap = new HashMap();
                lPortBdgMap.put("name", lFoundClassType.getName());
                lPortBdgMap.put("resource",lFoundClassType.getXpath() );
                lPortBdgMap.put("class-name", lFoundClassType.getClassName());
                Collection lCollection = new ArrayList();
                lCollection.add(lPortBdgMap);
                lEndpointYo.setProperty("port-bindings", lCollection);
                if(lEndpointYo.hasProperty("ipservice-endpoint-detail")==false){
                    lEndpointYo.setProperty("ipservice-endpoint-detail", new HashMap<>());
                }
                ((Map)lEndpointYo.get("ipservice-endpoint-detail")).put("port-mode",lFoundClassType.getPortMode());
            }
        }

        lEndpointYo.setProperty("site", aInAssociatedObject.getIdentifier());
        lEndpointYo.setProperty("site-id", aInNeId);
        lEndpointYo.setProperty("site-name", aInAssociatedObject.getProperty("name"));
        lEndpointYo.setProperty("service", aInParentObject.getIdentifier());
        lEndpointYo.setProperty("service-name", aInParentObject.getProperty("name"));
        lEndpointYo.setProperty("type","service-access-point" );

        //Build imp runs once on create
        if (aInDeviceObject.containsKey("_classId_") && aInDeviceObject.get("_classId_") != null && ((String) aInDeviceObject.get("_classId_")).startsWith("nokia-conf")) {
            //explicit admin-state gets set by json on conf. If not set default
            if (!(aInDeviceObject.containsKey("admin-state") && aInDeviceObject.get("admin-state") != null)) {
                lEndpointYo.setProperty("admin-state", "unlocked");
            }
            //Setting oper-state will mean create kafka event doesn't need to update ep
            lEndpointYo.setProperty("oper-state", "unknown");
        } else {
            //on state set admin-state to unknown
            lEndpointYo.setProperty("admin-state", "unknown");
        }

        final SourceData sourceData = new SourceData(SourceType.other, ModelFdn.decode("fdn:app:resync"));

        String lServiceExtensionEndpoint = getSvcExtensionEndpoint(lEndpointYo.getClassId());
        if(lServiceExtensionEndpoint != null){
            HashMap lEndPointExtensionMap = (lEndpointYo.hasProperty(lServiceExtensionEndpoint)) ? lEndpointYo.getProperty(lServiceExtensionEndpoint) : new HashMap();
            String lEndPointExtensionSources=(lFdn!=null) ? lFdn.replace("state","configure") : null;
            /*String lEndPointExtensionSources=null;
            if((lEndpointYo.hasProperty(lServiceExtensionEndpoint))) {
                lEndPointExtensionSources = (String) ((ArrayList) ((HashMap) lEndPointExtensionMap.get("@")).get("nsp-model:sources")).toArray()[0];
            } else {
                if (lSourceObj != null && lSourceObj instanceof ArrayList) {
                    ArrayList<String> lSources = (ArrayList) lSourceObj;
                    for(String lSource:lSources) {
                        if((lSource.contains("configure") || lSource.contains("state")) && lSource.contains("sap")) {
                            lEndPointExtensionSources = lSource.replace("state","configure");
                            break;
                        }
                    }
                }
            }*/
            String lServiceExtensionSite=lServiceExtensionEndpoint.replaceAll("endpoint","site");

            String lTenantId = null;
            String lNeName = null;
            if (aInAssociatedObject != null && aInAssociatedObject.hasProperty(lServiceExtensionSite) && aInAssociatedObject.get(lServiceExtensionSite) != null) {
                Map lSiteExt = (aInAssociatedObject.get(lServiceExtensionSite) instanceof IYangObject) ? ((IYangObject) (aInAssociatedObject.get(lServiceExtensionSite))).asMap() : (HashMap) aInAssociatedObject.get(lServiceExtensionSite);
                if (lSiteExt.containsKey("tenant-id") && lSiteExt.get("tenant-id") != null) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("found tenant from association");
                    }
                    lTenantId = (String) lSiteExt.get("tenant-id");
                }
                if (lSiteExt.containsKey("ne-name") && lSiteExt.get("ne-name") != null) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("found ne-name from association");
                    }
                    lNeName = (String) lSiteExt.get("ne-name");
                }
            }
            if (lTenantId == null) {
                //lookup tenant id from site query and cache
                QueryParameters lQpTenantIdSite = new QueryParameters();
                IExecutionContext lExecutionContext = new ExecutionContext(null, null, false, false, false);
                lQpTenantIdSite.setIExecutionContext(lExecutionContext);
                lQpTenantIdSite.setFields(Fields.parse("tenant-id"));
                lQpTenantIdSite.setLimit(2);
                lTenantId = getTenantIdFromSiteCache(aInAssociatedObject.getIdentifier() + "/" + lServiceExtensionSite, lQpTenantIdSite, lYangDb);
            }
            if (lNeName == null) {
                QueryParameters lQpNeName = new QueryParameters();
                IExecutionContext lExecutionContext = new ExecutionContext(null, null, false, false, false);
                lQpNeName.setIExecutionContext(lExecutionContext);
                lQpNeName.setFields(Fields.parse("ne-name"));
                lQpNeName.setDepth(2);
                lNeName = getNeNameByIdFromCache(aInNeId, lQpNeName, lYangDb);
            }

            if (lTenantId != null) {
                lEndPointExtensionMap.put("tenant-id", lTenantId);
                lEndpointYo.setProperty(lServiceExtensionEndpoint, lEndPointExtensionMap);
            }

            if (lNeName != null) {
                lEndPointExtensionMap.put("ne-name", lNeName);
                lEndpointYo.setProperty(lServiceExtensionEndpoint, lEndPointExtensionMap);
            }

            if(!lEndPointExtensionMap.containsKey("ingress")){
                //svc-endpoint/ingress/qos/sap-ingress
                HashMap lEndPointExtIngressSapIngress = new HashMap();
                HashMap lEndPointExtIngressSapIngressAt = new HashMap();
                ArrayList lSourceEndPointExtSapIngressList = new ArrayList();
                lSourceEndPointExtSapIngressList.add(lEndPointExtensionSources+"/ingress/qos/sap-ingress");
                lEndPointExtIngressSapIngressAt.put("nsp-model:sources",lSourceEndPointExtSapIngressList );
                lEndPointExtIngressSapIngress.put("policy-name", "default");
                lEndPointExtIngressSapIngress.put("@", lEndPointExtIngressSapIngressAt);

                //svc-endpoint/ingress/qos
                HashMap lEndPointExtIngressQos = new HashMap();
                HashMap lEndPointExtIngressQosAt = new HashMap();
                ArrayList lSourceEndPointExtIngressQosSrcList = new ArrayList();
                lSourceEndPointExtIngressQosSrcList.add(lEndPointExtensionSources+"/ingress/qos");
                lEndPointExtIngressQosAt.put("nsp-model:sources",lSourceEndPointExtIngressQosSrcList );
                lEndPointExtIngressQos.put("@", lEndPointExtIngressQosAt);
                lEndPointExtIngressQos.put("sap-ingress",lEndPointExtIngressSapIngress);

                //svc-endpoint/ingress
                HashMap lEndPointExtIngress = new HashMap();
                HashMap lEndPointExtIngressAt = new HashMap();
                ArrayList lSourceEndPointExtIngressSrcList = new ArrayList();
                lSourceEndPointExtIngressSrcList.add(lEndPointExtensionSources+"/ingress");
                lEndPointExtIngressAt.put("nsp-model:sources", lSourceEndPointExtIngressSrcList);
                lEndPointExtIngress.put("@", lEndPointExtIngressAt);
                lEndPointExtIngress.put("qos",lEndPointExtIngressQos );

                lEndPointExtensionMap.put("ingress", lEndPointExtIngress);
                lEndpointYo.setProperty(lServiceExtensionEndpoint,lEndPointExtensionMap );
            }
            if(!lEndPointExtensionMap.containsKey("egress")){
                //svc-endpoint/egress/qos/sap-egress
                HashMap lEndPointExtEgressSapEgress = new HashMap();
                HashMap lEndPointExtEgressSapEgressAt = new HashMap();
                ArrayList lSourceEndPointExtSapEgressList = new ArrayList();
                lSourceEndPointExtSapEgressList.add(lEndPointExtensionSources+"/egress/qos/sap-egress");
                lEndPointExtEgressSapEgressAt.put("nsp-model:sources",lSourceEndPointExtSapEgressList );
                lEndPointExtEgressSapEgress.put("policy-name", "default");
                lEndPointExtEgressSapEgress.put("@", lEndPointExtEgressSapEgressAt);

                //svc-endpoint/egress/qos
                HashMap lEndPointExtIngressQos = new HashMap();
                HashMap lEndPointExtIngressQosAt = new HashMap();
                ArrayList lSourceEndPointExtIngressQosSrcList = new ArrayList();
                lSourceEndPointExtIngressQosSrcList.add(lEndPointExtensionSources+"/egress/qos");
                lEndPointExtIngressQosAt.put("nsp-model:sources",lSourceEndPointExtIngressQosSrcList );
                lEndPointExtIngressQos.put("@", lEndPointExtIngressQosAt);
                lEndPointExtIngressQos.put("sap-egress",lEndPointExtEgressSapEgress);

                //svc-endpoint/egress
                HashMap lEndPointExtIngress = new HashMap();
                HashMap lEndPointExtIngressAt = new HashMap();
                ArrayList lSourceEndPointExtIngressSrcList = new ArrayList();
                lSourceEndPointExtIngressSrcList.add(lEndPointExtensionSources+"/egress");
                lEndPointExtIngressAt.put("nsp-model:sources", lSourceEndPointExtIngressSrcList);
                lEndPointExtIngress.put("@", lEndPointExtIngressAt);
                lEndPointExtIngress.put("qos",lEndPointExtIngressQos );

                lEndPointExtensionMap.put("egress", lEndPointExtIngress);
                lEndpointYo.setProperty(lServiceExtensionEndpoint,lEndPointExtensionMap );
            }
        }

        aInQueryParameters.setParentId(((YangObject) aInParentObject).getExtraData());
        aInQueryParameters.getIExecutionContext().addExtraParameter("return-light-data", true);
        aInQueryParameters.getIExecutionContext().addExtraParameter("db-id:" + aInParentObject.getIdentifier(), ((YangObject) aInParentObject).getExtraData());
        aInQueryParameters.getIExecutionContext().addExtraParameter("db-id:" + aInAssociatedObject.getIdentifier(), ((YangObject) aInAssociatedObject).getExtraData());
        IYangObject lYoCreated = aInMdResyncFw.getIYangDB().createChild(aInParentObject.getIdentifier(),"endpoint",lEndpointYo,sourceData,aInQueryParameters) ;
        aInQueryParameters.setParentId(null);
        aInQueryParameters.getIExecutionContext().extraFlags().remove("return-light-data");
        return lYoCreated;
    }

    private void updateEndpointsInSite(IYangObject aInEndpoint, IYangObject aInAssociatedObject, IMdResyncFw aInMdResyncFw,QueryParameters aInQueryParameters)
    {
        ArrayList lEndpoints = new ArrayList<>();
        lEndpoints.add(aInEndpoint.getIdentifier());
        Object lEndpointObj=aInAssociatedObject.getProperty("endpoint");
        if(lEndpointObj!=null && lEndpointObj instanceof ArrayList){
            lEndpoints.addAll(((ArrayList)lEndpointObj));
        }
        IYangObject lSiteUpdateYo = new YangObject();
        lSiteUpdateYo.setProperty("endpoint",lEndpoints);
        aInMdResyncFw.getIYangDB().update(aInAssociatedObject.getIdentifier(),lSiteUpdateYo, aInQueryParameters);
    }

    private String getSvcExtensionEndpoint(String aInClassId){
        if(aInClassId.contains("eline"))
            return "service-extension:eline-endpoint";
        else if (aInClassId.contains("elan"))
            return "service-extension:elan-endpoint";
        else if (aInClassId.contains("l3vpn"))
            return "service-extension:l3vpn-endpoint";
        else if (aInClassId.contains("cline"))
            return "service-extension:cline-endpoint";
        else if (aInClassId.contains("ies"))
            return "service-extension:ies-endpoint";
        return null;
    }

    public static class EquipmentCache
    {
        protected String className;
        protected String xpath;
        protected String name;
        protected String portMode;

        public EquipmentCache(String aInClassName, String aInXpath, String aInName, String aInPortmode)
        {
            className = aInClassName;
            xpath = aInXpath;
            name = aInName;
            portMode = aInPortmode;
        }

        public String getClassName() {
            return className;
        }

        public String getXpath() {
            return xpath;
        }

        public String getName() {
            return name;
        }

        public String getPortMode() {
            if(null != portMode && portMode.equals("trunk"))
                return "network";
            return portMode;
        }
    }


    private String getNeNameByIdFromCache(String aInNeId, QueryParameters aInQueryParameters, IYangDB aInYangDb) {
        Map<String, String> lNeNameCache = neNameCache.get();
        if (null == lNeNameCache) {
            lNeNameCache = new HashMap<>();
            neNameCache.set(lNeNameCache);
            Transactor.getContext().addEventHandler(TxPhase.FINAL, (p, c) -> {
                neNameCache.remove();
            });
        }

        String lFoundNeName = lNeNameCache.get(aInNeId);
        if (null == lFoundNeName) {
            if (logger.isDebugEnabled()) {
                logger.debug("Querying db for ne-name for ne {}", aInNeId);
            }
            String lportFdn = "/nsp-equipment:network/network-element[ne-id='" + aInNeId + "']";
            FlushModeType lPreFlushModeType=Transactor.getContext().getEntityManager().getFlushMode();
            Transactor.getContext().getEntityManager().setFlushMode(FlushModeType.COMMIT);
            IYangObject lNeYangObj = aInYangDb.getSingle(lportFdn, aInQueryParameters);
            if(lPreFlushModeType.equals(FlushModeType.AUTO))
            {
                Transactor.getContext().getEntityManager().setFlushMode(FlushModeType.AUTO);
            }
            if (lNeYangObj != null && lNeYangObj.hasProperty("ne-name")) {
                lFoundNeName = (String) lNeYangObj.getProperty("ne-name");
            } else {
                lFoundNeName = "";
            }
            lNeNameCache.put(aInNeId, lFoundNeName);
        } else {
            if (logger.isDebugEnabled()) {
                logger.debug("Found ne-name for ne {} in cache", aInNeId);
            }
        }
        return lFoundNeName;
    }

    private String getTenantIdFromSiteCache(String aInSiteXpath, QueryParameters aInQueryParameters, IYangDB aInYangDb) {
        Map<String, String> ltenantIdSiteCache = tenantIdSiteCache.get();
        if (null == ltenantIdSiteCache) {
            ltenantIdSiteCache = new HashMap<>();
            tenantIdSiteCache.set(ltenantIdSiteCache);
            Transactor.getContext().addEventHandler(TxPhase.FINAL, (p, c) -> {
                tenantIdSiteCache.remove();
            });
        }

        String lSvcAndSiteKey=aInSiteXpath.replaceAll(".*service-layer/","").replaceAll("/service-extension.*","");

        String lFoundTenantId = ltenantIdSiteCache.get(lSvcAndSiteKey);
        if (null == lFoundTenantId) {
            if (logger.isDebugEnabled()) {
                logger.debug("Querying db for tenant id. key {} url {}", lSvcAndSiteKey, aInSiteXpath);
            }
            FlushModeType lPreFlushModeType=Transactor.getContext().getEntityManager().getFlushMode();
            Transactor.getContext().getEntityManager().setFlushMode(FlushModeType.COMMIT);
            List<IYangObject> lCusts = aInYangDb.getMany(aInSiteXpath, aInQueryParameters);
            if(lPreFlushModeType.equals(FlushModeType.AUTO))
            {
                Transactor.getContext().getEntityManager().setFlushMode(FlushModeType.AUTO);
            }
            if (lCusts.size() > 0 && lCusts.get(0).hasProperty("tenant-id") && lCusts.get(0).get("tenant-id")!=null) {
                lFoundTenantId = lCusts.get(0).get("tenant-id").toString();
                ltenantIdSiteCache.put(lSvcAndSiteKey, lFoundTenantId);
            }
        } else {
            if (logger.isDebugEnabled()) {
                logger.debug("Found tenant id for key {}", lSvcAndSiteKey);
            }
        }
        return lFoundTenantId;
    }

}