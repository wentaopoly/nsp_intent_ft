load({script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk'});

function TraverseFwk() {
    var mapFwk = new MapFwk();
    var createRequestsMap;
    var createRequests;
    var deleteRequests;
    var deviceType;
    var metaData;
    var currentObjects;
    var nodeCheckSums;
    var intentCheckSums;
    var savedObjects;
    var editIdValue;
    var pParentPath;
    var presenceContainers;

    this.traverse = function (target, intentConfig, savedTopology, report, parentPath, initialProperty) {
        var mdcFwk = new MdcFwk();

        // current topolgy
        var currentTopo = topologyFactory.createServiceTopology();

        // Array of create Requests
        this.createRequests = [];

        // Array of delete Requests
        this.deleteRequests = [];

        editIdValue = 0;
        // Array of audit
        // var audit = [];
        // initializing the checksums
        metaData = {};
        nodeCheckSums = {};
        intentCheckSums = {};
        currentObjects = {};
        savedObjects = {};
        createRequestsMap = {};
        var absoluteParentPath = parentPath;
        var pathObjs = parentPath.split("/");
        var tempParentPath = pathObjs[0];
        for (var index = 1; index < pathObjs.length; index++)
        {
            tempParentPath = tempParentPath + "/" + pathObjs[index].split('=')[0];
        }
        parentPath =tempParentPath;

        var url = "";
        if (parentPath !== "" && parentPath !== null) {
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + target + "/root/nokia-conf:/" + absoluteParentPath + "/" + initialProperty;
            this.pParentPath = parentPath + "/" + initialProperty;
        } else {
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + target + "/root/nokia-conf:/" + initialProperty;
            this.pParentPath = initialProperty;
        }
        var path = "";
        var absolutePath = "";
        if (parentPath !== null && parentPath !== "") {
            path = "/" + parentPath + "/" + initialProperty;
            absolutePath = "/" + absoluteParentPath + "/" + initialProperty;
        } else {
            path = parentPath + "/" + initialProperty;
            absolutePath = absoluteParentPath + "/" + initialProperty;
        }

        var key = this.checkPathIsArray(path, target);
        if (key !== null && key !== "" && key !== undefined) {
            if(intentConfig[key])
            {
                url = url + "=" + this.cipherSpecialCharacterInKey(intentConfig[key].toString());
            }
        }

        var configFromDevice = [];
        if (report == null || report == 'undefined') {
            report = auditFactory.createAuditReport(null, null);
        } else {
            var getResult = mdcFwk.fetch(target, url);
            configFromDevice = getResult.msg["nokia-conf:" + initialProperty];
            if (configFromDevice == undefined) {
                throw "cannot get configuration from device"
            }
        }

        // loading the checksums from topology
        this.loadMetaDataFromSavedTopology(savedTopology);
        this.loadAllCheckSums(savedTopology);

        // removing the empty containers in the intent config ( need to be replaced later)
        intentConfig = this.removeEmptyContainers("", intentConfig, "", target);

        this.compare(path, absolutePath, initialProperty, intentConfig, configFromDevice, target, report);

        currentTopo = this.loadCurrentObjectsToTopology(target);

        // to add the delete requests
        this.removeDeletedObjectsFromTopo(target);

        this.addCreateRequestsToArray();

        return currentTopo;
    }

    this.compare = function (parentPath, absolutePath, propertyName, intentJson, targetJson, target, report) {
        var currentIntentChecksum;
        var currentNodeChecksum;
        if (Array.isArray(intentJson)) {
            logger.info("Array Type Json Object = " + parentPath);
            logger.info("Absolute Path of the Object = " + absolutePath);
            var key = this.checkPathIsArray(parentPath, target);
            if (key === null || key === "" || key === undefined) {
                // its a leaf list attribute
                intentJson = intentJson.sort();
                targetJson = targetJson.sort();
                for (var leafListPro in intentJson) {
                    var leafListPath = absolutePath + "=" + intentJson[leafListPro];
                    this.addNewObjectsToTopo(parentPath, leafListPath, "", intentJson[leafListPro], target);
                }
                var leafListpath = absolutePath.replace(propertyName, "");
                this.handleLeafAttribute(parentPath, absolutePath, propertyName, intentJson, targetJson, target, report);
            } else {
                for (var intentPro in intentJson) {
                    key = this.checkPathIsArray(parentPath, target);
                    if (key !== null && key !== "undefined" && key !== "") {
                        var keyValue = this.checkIfMultipleKey(key, intentJson[intentPro]);
                        var path = absolutePath + "=" + this.cipherSpecialCharacterInKey(keyValue).toString();
                        var arrayElement;
                        logger.info("Adding to Topology " + path);
                        this.addToCurrentObjects(path, "Array");

                        logger.info("getting the array element from node json");
                        if ((intentJson[intentPro] !== "undefined") && (intentJson[intentPro] !== null)) {
                            arrayElement = this.getElementFromArray(key, keyValue, targetJson);

                        }
                        //need to change the logic of checksum
                        currentIntentChecksum = JSON.stringify(intentJson[intentPro]).hashCode().toString();
                        currentNodeChecksum = (arrayElement) ? JSON.stringify(arrayElement).hashCode().toString() : undefined;
                        if (this.validateBothCheckSums(currentIntentChecksum, currentNodeChecksum, path)) {
                            if ((arrayElement !== null) && (arrayElement !== "undefined") && (intentJson[intentPro][key] == arrayElement[key])) {
                                this.compare(parentPath, path, "", intentJson[intentPro], arrayElement, target, report);
                            } else {
                                logger.info("Adding to sync request");
                                this.createSyncOperations(path, intentJson[intentPro]);
                                // adding miss alligned array object

                                if (report !== null && report !== undefined) {
                                    var atrName = this.decipherSpecialCharacterInKey(path);
                                    report.addMisAlignedObject(auditFactory.createMisAlignedObject(atrName, false));
                                }
                                // adding the new objects to topo
                                this.addNewObjectsToTopo(parentPath, path, "", intentJson[intentPro], target);
                            }
                        } else {
                            logger.info(path + " has not changed");
                            // adding all the child objects to currentTopo
                            this.addChildObjects(path);
                        }
                    }
                }
            }
        } else if (typeof intentJson == 'object') {
            // below code is for array with single element as container
            // starts here
            var key = this.checkPathIsArray(parentPath, target);
            if (key !== null && key !== "" && Array.isArray(targetJson)) {
                logger.info("ConatinerArray Type Json Object = " + parentPath);
                logger.info("Absolute Path of the Object = " + absolutePath);
                intentJson = [intentJson];
                // checksum will be validated while validating the array
                this.compare(parentPath, absolutePath, propertyName, intentJson, targetJson, target, report);
            } else {
                logger.info("Conatiner Type Json Object = " + parentPath);
                logger.info("Absolute Path of the Object = " + absolutePath);
                for (var prop in intentJson) {
                    var abPath = absolutePath + "/" + prop;
                    var pPath = parentPath + "/" + prop;

                    if (targetJson[prop] !== null && targetJson[prop] !== undefined && typeof intentJson[prop] == 'object' && (!this.isEmptyLeaf(parentPath, target, prop, intentJson[prop]))) {
                        key = this.checkPathIsArray(pPath, target);
                        // checking if object is array or container

                        if (!Array.isArray(intentJson[prop]) && (key == null || key == undefined || key == "")) {
                            logger.info("Adding to Topology " + abPath);
                            this.addToCurrentObjects(abPath, "Container");
                            //need to change the logic of checksum
                            currentIntentChecksum = JSON.stringify(intentJson[prop]).hashCode().toString();
                            currentNodeChecksum = (targetJson[prop]) ? JSON.stringify(targetJson[prop]).hashCode().toString() : undefined;

                            if (this.validateBothCheckSums(currentIntentChecksum, currentNodeChecksum, abPath)) {
                                //metaData = mapFwk.set(metaData,abPath,currentChecksum);
                                this.compare(pPath, abPath, prop, intentJson[prop], targetJson[prop], target, report);
                            } else {
                                logger.info(abPath + " has not changed");

                                // adding all the child objects to currentTopo
                                this.addChildObjects(abPath);
                            }
                        } else {
                            //checksum is validate while evaluating the array
                            this.compare(pPath, abPath, prop, intentJson[prop], targetJson[prop], target, report);
                        }

                    } else {
                        //checking if the intent[prop] is a array object but coming as conatiner
                        var key;
                        if (typeof intentJson[prop] == 'object') {
                            key = this.checkPathIsArray(pPath, target);
                        }
                        if (key !== null && key !== "" && key !== undefined && typeof intentJson[prop] == 'object') {
                            // converting the container to array
                            var propArray = (Array.isArray(intentJson[prop])) ? propArray = intentJson[prop] : [intentJson[prop]];
                            // checksum will be validated while evaluating the array
                            this.compare(pPath, abPath, prop, propArray, null, target, report);
                        } else {
                            if (report !== null && report !== undefined && typeof intentJson[prop] == 'object' && (!this.isEmptyLeaf(parentPath, target, prop, intentJson[prop]))) {
                                //need to change the logic of checksum
                                currentIntentChecksum = JSON.stringify(intentJson[prop]).hashCode().toString();
                                currentNodeChecksum = undefined;
                                mapFwk.set(intentCheckSums, abPath, currentIntentChecksum);
                                mapFwk.set(nodeCheckSums, abPath, currentNodeChecksum);
                                // adding miss alligned conatiner object
                                logger.info("Adding to Topology");
                                this.addToCurrentObjects(abPath, "Container");
                                logger.info("Adding to sync request");
                                //checking if a conatiner is array element
                                var arrayKey = this.checkIfArrayElement(parentPath, absolutePath, prop);
                                var value = {};
                                if (arrayKey !== null && arrayKey !== "" && arrayKey !== undefined) {
                                    value = arrayKey;
                                    value[prop] = intentJson[prop];
                                    this.createSyncOperations(absolutePath, value);
                                } else {
                                    if (typeof intentJson[prop] == 'object' && !Array.isArray(intentJson[prop])) {
                                        value = {};
                                        value = intentJson[prop];
                                        /* This is a temp solution for considering a special secnario -                                  */
                                        /* One container contains a single child container with presence statement                       */
                                        /* When adding this kind of structure by netConf, an error message will show up -                */
                                        /* Unknown property start for object nokia-conf:/configure/filter/ip-filter/entry/match/dst-port */
                                        var attrList = Object.keys(value);
                                        var lenAttr = attrList.length;
                                        var processPresenContainer = false;
                                        if (lenAttr == 1) {
                                            var presenceContainerLists = this.getPresenceContainLists(target, abPath);
                                            if (presenceContainerLists && presenceContainerLists != undefined) {
                                                var pendingPath = abPath + "/" + attrList[0];
                                                pendingPath = this.convertPath(pendingPath);
                                                pendingPath = "nokia-conf:" + pendingPath;
                                                if (presenceContainerLists.indexOf(pendingPath) >= 0) {
                                                    logger.info("current container has \'presence\' statement: " + abPath + "/" + attrList[0]);
                                                    this.createSyncOperations(absolutePath + "/" + prop + "/" + attrList[0], value[attrList[0]]);
                                                    processPresenContainer = true;
                                                }
                                            }
                                        }

                                        if (processPresenContainer == false) {
                                            this.createSyncOperations(absolutePath + "/" + prop, value);
                                        }
                                    } // container inside the consider
                                }

                                atrName = this.decipherSpecialCharacterInKey(absolutePath);
                                report.addMisAlignedObject(auditFactory.createMisAlignedObject(atrName + "/" + prop, false));

                                this.addNewObjectsToTopo(pPath, abPath, prop, intentJson[prop], target);
                            } else {
                                // leaf attribute
                                this.handleLeafAttribute(parentPath, absolutePath, prop, intentJson[prop], targetJson[prop], target, report);

                            }

                        }
                    }
                }
            }
        } else {
            // leaf attribute
            this.handleLeafAttribute(parentPath, absolutePath, propertyName, intentJson, targetJson, target, report);
        }

    }

    this.handleLeafAttribute = function (parentPath, absolutePath, propertyName, intentJson, targetJson, target, report) {

        logger.info("Leaf Type Json Object = " + absolutePath);
        if ((intentJson || intentJson === 0) && intentJson !== "undefined" && intentJson !== "") {
            this.compareLeaf(parentPath, absolutePath, propertyName, intentJson, targetJson, target, report);
            var leafPath = absolutePath + "/" + propertyName;
            logger.info("adding the leaf to topo " + leafPath);
            var isKeyAttribute = this.checkIfArrayElement(parentPath, absolutePath, propertyName);
            // if leaf is a key element/attribute dont add it to the topology, we should not send delete request for that
            if (isKeyAttribute === null || isKeyAttribute === undefined) {
                this.addToCurrentObjects(leafPath, "Leaf");
            } else {
                if (isKeyAttribute[propertyName] === null || isKeyAttribute[propertyName] === undefined || isKeyAttribute[propertyName] === "undefined") {
                    this.addToCurrentObjects(leafPath, "Leaf");
                }
            }
        }
    }

    this.addNewObjectsToTopo = function (parentPath, absolutePath, propertyName, intentJson, target) {
        var currentIntentChecksum;
        var currentNodeChecksum;
        if (Array.isArray(intentJson)) {

            for (var intentPro in intentJson) {
                var key = this.checkPathIsArray(parentPath, target);
                if (key !== null && key !== "undefined" && key !== "") {
                    var path = absolutePath + "=" + this.cipherSpecialCharacterInKey(this.checkIfMultipleKey(key, intentJson[intentPro]).toString());
                    logger.info("adding array object to topo " + path);
                    this.addToCurrentObjects(path, "Array");
                    //adding the checksum
                    currentIntentChecksum = JSON.stringify(intentJson[intentPro]).hashCode().toString();
                    currentNodeChecksum = currentIntentChecksum;
                    mapFwk.set(intentCheckSums, path, currentIntentChecksum);
                    mapFwk.set(nodeCheckSums, path, currentNodeChecksum);
                    this.addNewObjectsToTopo(parentPath, path, "", intentJson[intentPro], target);
                } else {
                    // leaf list handling
                    var path = absolutePath + "=" + intentJson[intentPro];
                    this.addNewObjectsToTopo(parentPath, path, "", intentJson[intentPro], target);
                }
            }
        } else if (typeof intentJson == 'object') {

            for (var prop in intentJson) {
                var abPath = absolutePath + "/" + prop;
                var pPath = parentPath + "/" + prop;
                if (typeof intentJson[prop] == 'object') {
                    var key = this.checkPathIsArray(pPath, target);
                    // checking if object is array or container
                    if (!Array.isArray(intentJson[prop]) && (key == null || key == undefined || key == "")) {
                        logger.info("adding container object to topo " + path);
                        this.addToCurrentObjects(abPath, "Container");
                        //adding the checksum
                        currentIntentChecksum = JSON.stringify(intentJson[prop]).hashCode().toString();
                        currentNodeChecksum = currentIntentChecksum;
                        mapFwk.set(intentCheckSums, abPath, currentIntentChecksum);
                        mapFwk.set(nodeCheckSums, abPath, currentNodeChecksum);
                        this.addNewObjectsToTopo(pPath, abPath, prop, intentJson[prop], target);
                    } else {
                        //its a array
                        var propArray = (Array.isArray(intentJson[prop])) ? propArray = intentJson[prop] : [intentJson[prop]];
                        logger.info(propArray);
                        this.addNewObjectsToTopo(pPath, abPath, prop, propArray, target);
                    }
                } else {
                    //leaf level
                    var isKeyAttribute = this.checkIfArrayElement(pPath, abPath, prop);
                    // if leaf is a key element/attribute dont add it to the topology, we should not send delete request for that
                    if (isKeyAttribute === null || isKeyAttribute === undefined) {
                        this.addNewObjectsToTopo(pPath, abPath, prop, intentJson[prop], target);

                    } else {
                        if (isKeyAttribute[prop] === null || isKeyAttribute[prop] === undefined || isKeyAttribute[prop] === "undefined") {
                            this.addNewObjectsToTopo(pPath, abPath, prop, intentJson[prop], target);
                        }
                    }
                }
            }
        } else {

            //adding the checksum
            currentIntentChecksum = JSON.stringify(intentJson).hashCode().toString();
            currentNodeChecksum = currentIntentChecksum;
            mapFwk.set(intentCheckSums, absolutePath, currentIntentChecksum);
            mapFwk.set(nodeCheckSums, absolutePath, currentNodeChecksum);
            this.addToCurrentObjects(absolutePath, "Leaf");

        }
    }

    this.addChildObjects = function (parentPath) {

        for (var key in savedObjects) {
            if (key.indexOf(parentPath) >= 0) {
                this.addToCurrentObjects(key, mapFwk.get(savedObjects, key));
            }

        }

    }

    this.loadMetaDataFromSavedTopology = function (savedTopology) {
        if (savedTopology) {
            var xtraInfos = savedTopology.getXtraInfo();
            if (xtraInfos.length > 0) {
                xtraInfos.forEach(function (xtraInfo) {
                    mapFwk.set(metaData, xtraInfo.getKey(), xtraInfo.getValue());
                });
            }
        }
    }

    this.loadAllCheckSums = function (savedTopology) {
        if (savedTopology) {
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects != null && topoObjects != undefined && topoObjects.length > 0) {
                topoObjects.forEach(function (topoObject) {
                    var checksums = String(topoObject.getObjectPreviousVertexObjectIDs()).replace("[", "").replace("]", "");
                    var nodeChecksum;
                    var intentChecksum;
                    var splits = String(checksums).split(",");
                    intentChecksum = splits[0].split("=")[1];
                    nodeChecksum = splits[1].split("=")[1];
                    mapFwk.set(intentCheckSums, topoObject.getObjectType(), intentChecksum);
                    mapFwk.set(nodeCheckSums, topoObject.getObjectType(), nodeChecksum);
                    mapFwk.set(savedObjects, topoObject.getObjectType(), topoObject.getObjectRelativeObjectID());
                });
            }
        }
    }
    this.loadCurrentObjectsToTopology = function (target) {
        var currentTopo = topologyFactory.createServiceTopology();
        if (Object.keys(currentObjects).length) {
            for (var key in currentObjects) {
                var checksums = [];
                var objectId = mapFwk.get(currentObjects, key);
                checksums.push("intentChecksum=" + mapFwk.get(intentCheckSums, key));
                checksums.push("nodeChecksum=" + mapFwk.get(nodeCheckSums, key));
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key, objectId, "INFRASTRUCTURE", target, checksums));

            }
        }
        // adding meta data to current topology (need to change )
        for (var key in metaData) {
            this.addTopologyExtraInfo(currentTopo, target, "generic", key, mapFwk.get(metaData, key));
        }
        return currentTopo;
    }

    this.validateCheckSums = function (savedCheckSum, currentCheckSum) {
        // for now checksum is always fails
        return true;
        if (savedCheckSum == "undefined" || savedCheckSum == "" || savedCheckSum == undefined) {
            return true;
        } else if (savedCheckSum !== currentCheckSum) {
            return true;
        } else {
            return false;
        }

    }

    this.validateBothCheckSums = function (currentIntentCheckSum, currentNodeCheckSum, path) {

        var savedIntentChecksum = mapFwk.get(intentCheckSums, path);
        var savedNodeChecksum = mapFwk.get(nodeCheckSums, path);

        // checking if saved Node checking is undefined then, created recently so add the nodeChecksum as savedNodechecksum.
        // if(savedNodeChecksum = "undefined" || savedNodeChecksum == undefined || savedNodeChecksum ==""){
        //    savedNodeChecksum = currentNodeCheckSum;
        //    mapFwk.set(nodeCheckSums,path,savedNodeChecksum);
        //  }

        // validating intentChecksum
        var intentValidate = this.validateCheckSums(savedIntentChecksum, currentIntentCheckSum);
        var nodeValidate = this.validateCheckSums(savedNodeChecksum, currentNodeCheckSum);
        //  if(( savedNodeChecksum == undefined || savedNodeChecksum == "undefined")&& !intentValidate){
        //         mapFwk.set(nodeCheckSums,path,currentNodeCheckSum);
        //         return false;
        //  }

        if (intentValidate || nodeValidate) {
            mapFwk.set(intentCheckSums, path, currentIntentCheckSum);
            mapFwk.set(nodeCheckSums, path, currentNodeCheckSum);
            return true;
        } else {
            return false;
        }

    }

    this.addToCurrentObjects = function (path, objectType) {
        mapFwk.set(currentObjects, path, objectType);
    }

    this.getPresenceContainLists = function (target, path) {
        var mdcFwk = new MdcFwk();
        var getResult = null;
        var path = this.convertPath(path);
        var presenceContainerLists = [];
        var url = "/restconf/meta/api/v1/model/schema/" + target + "/nokia-conf:" + path;

        getResult = mdcFwk.fetch(target, url);
        if (getResult && getResult != undefined && getResult.msg) {
            var jsonObj = getResult.msg["attributes"];
            if (jsonObj != null && jsonObj != undefined) {
                for (var attribute in jsonObj) {
                    var item = jsonObj[attribute];
                    if (item["presence"] == true) {
                        presenceContainerLists.push(item["pathname"]);
                    }
                }
            }
        }
        return presenceContainerLists;
    }

    //Check if container is presence
    this.isPresenceContainer = function (target, path) {
        var mdcFwk = new MdcFwk();
        var getResult = null;
        var path = this.convertPath(path);
        var url = "/restconf/meta/api/v1/model/schema/" + target + "/nokia-conf:" + path;
        if (this.presenceContainers && this.presenceContainers != undefined) {
            if (this.presenceContainers.indexOf("nokia-conf:" + path) >= 0) {
                logger.info("current container has \'presence\' statement: " + "nokia-conf:" + path);
                return true;
            }
        }

        getResult = mdcFwk.fetch(target, url);
        if (getResult && getResult != undefined && getResult.msg) {
            var jsonObj = getResult.msg["attributes"];
            if (jsonObj != null && jsonObj != undefined) {
                for (var attribute in jsonObj) {
                    var item = jsonObj[attribute];
                    if (item["presence"] == true) {
                        if (this.presenceContainers == null || this.presenceContainers == undefined) {
                            this.presenceContainers = ['dummyPresenceConatiner'];
                        }
                        this.presenceContainers.push(item["pathname"]);
                    }
                }
            }
        }

        return false;
    }

    /*
        Convert path with keys and values to keys only
        Input: /configure\/filter\/ip-filter=elisa-ip-filter-sample\/entry=100
        Output: /configure\/filter\/ip-filter\/entry
    */

    this.convertPath = function (path) {
        var pathLists = path.split("/");
        var returnPath = "";
        if (pathLists.length > 1) {
            for (var i = 0; i < pathLists.length; i++) {
                var keyValPair = pathLists[i].match("(\\S+)=(\\S+)");
                if (keyValPair) {
                    pathLists[i] = keyValPair[1];
                }
                if (pathLists[i] == "") {
                    continue
                }
                returnPath += "/"
                returnPath += pathLists[i]
            }
        }
        return returnPath;
    }

    //check if leaf is empty
    this.isEmptyLeaf = function (path, target, prop, value) {
        var mdcFwk = new MdcFwk();
        var url = "/restconf/meta/api/v1/model/schema/" + target + "/nokia-conf:/" + path;
        var getResult = null;

        if ((JSON.stringify(value) == "[null]")) {
            return true
        }

        try{
            var metadata = JSON.parse(resourceProvider.getResource("meta-data.json"))["nokia-conf:"+path];
            if(metadata === undefined){
                metadata = JSON.parse(resourceProvider.getResource("meta-data.json"))["nokia-conf:/"+path];
            }
            logger.info("meta-data.json = \n{}", JSON.stringify(metadata));
            if(metadata){
                if (metadata["name"] === prop && metadata["nodetype"] === "property" && metadata["type"] === "empty") {
                    return true;
                }
            } else {
                getResult = mdcFwk.fetch(target, url);
                if (getResult && getResult != undefined && getResult.msg) {
                    var jsonObj = getResult.msg["attributes"];
                    if (jsonObj != null && jsonObj != undefined) {
                        for (var attribute in jsonObj) {
                            var item = jsonObj[attribute];
                            if(item["name"]){
                                if (item["name"] == prop) {
                                    if (item["nodetype"] == "property") {
                                        if (item["type"] == "empty") {
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }catch(e){
            logger.info("error pasring meta-data.json = \n{}", e);
            logger.info("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
            getResult = mdcFwk.fetch(target, url);
            logger.info(JSON.stringify(getResult));
            logger.info("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
            if (getResult && getResult != undefined && getResult.msg) {
                var jsonObj = getResult.msg["attributes"];
                if (jsonObj != null && jsonObj != undefined) {
                    for (var attribute in jsonObj) {
                        var item = jsonObj[attribute];
                        if(item["name"]){
                            if (item["name"] == prop) {
                                if (item["nodetype"] == "property") {
                                    if (item["type"] == "empty") {
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }

        }

        return false
    }

    this.compareLeaf = function (parentPath, absolutePath, propertyName, intentValue, targetValue, target, report) {

        var intentvalue = intentValue + "";
        var targetvalue = targetValue + "";

        var intentValueToNumber = Number(intentValue);
        var targetValueToNumber = Number(targetValue);

        if ((intentvalue !== targetvalue) && (report !== null && report !== 'undefined')) {
            if(!isNaN(intentValueToNumber) && !isNaN(targetValueToNumber)){
                if(intentValueToNumber == targetValueToNumber)
                {
                    logger.info("intentValue and targetValue are numbers and are equal.")
                    return;
                }
            }
            var atrName = this.decipherSpecialCharacterInKey(absolutePath);
            report.addMisAlignedAttribute(auditFactory.createMisAlignedAttribute(atrName + "/" + propertyName, intentValue, targetValue, target));
            var arrayKey = this.checkIfArrayElement(parentPath, absolutePath, propertyName);
            logger.info("Adding to sync request");
            var value = {};
            var path = absolutePath.replace(propertyName, "");
            if (arrayKey !== null && arrayKey !== "" && arrayKey !== "undefined") {
                value = arrayKey;
            }
            value[propertyName] = intentValue;
            logger.info("Value to be added to sync request =" + JSON.stringify(value));
            this.createSyncOperations(path, value);
        }

    }

    this.cipherSpecialCharacterInKey = function (key) {
        return key.toString().replaceAll("/", "%2F").replaceAll(":", "%3A");
    }

    this.decipherSpecialCharacterInKey = function (key) {
        return key.toString().replaceAll("%2F", "/").replaceAll("%3A", ":");
    }

    this.checkPathIsArray = function (path, target) {
        var key;
        try{

            key = JSON.parse(resourceProvider.getResource("meta-data.json"))["nokia-conf:"+path]["keys"];
            if(key===undefined){
                key = JSON.parse(resourceProvider.getResource("meta-data.json"))["nokia-conf:/"+path]["keys"];
            }
            logger.info("key = \n{}", JSON.stringify(key));
        }catch(e){

            // to make it compatable with
            key = mapFwk.get(metaData, path);
            // first time key might not be there in metaData, get the key
            if (key == null || key == undefined || !isNaN(path)) {
                key = this.getKey(path, target);
                //  this.addTopologyExtraInfo(currentTopo, target,null,path, key);
            }

        }

        metaData[path] = key;
        return key;
    }

    this.checkIfArrayElement = function (parentPath, absolutePath, propertyName) {
        var path = parentPath;
        path = path.replace("/" + propertyName, "");
        var key = this.checkMetaInTopology(path);
        if (key !== null && key !== "" && key !== undefined) {
            logger.info("Creating key and value for array level element");
            var abPath = absolutePath;
            abPath = abPath.replace(propertyName, "");
            var splits = abPath.split("=");
            var obj = {};
            var keys = key.toString().split(",");
            var keyValues = splits[splits.length - 1].split(",");
            for (var i = 0; i < keys.length; i++) {
                obj[keys[i]] = this.decipherSpecialCharacterInKey(keyValues[i].replace("/", ""));
            }
            //obj[key] = this.decipherSpecialCharacterInKey(splits[splits.length - 1].replace("/", ""));
            return obj;
        }
        return null;
    }

    this.removeDeletedObjectsFromTopo = function (target) {

        if (Object.keys(savedObjects).length > 0) {
            for (var key in savedObjects) {
                var value = mapFwk.get(currentObjects, key);
                if (value == undefined || value == "undefined" || value == null) {
                    logger.info("To be Deleted " + key);
                    if (!this.isPresenceContainer(target, key)) {
                        this.createDeleteOperation("nokia-conf:" + key);
                    }
                }

            }

        }

    }

    this.deleteAllFromTopology = function (savedTopology, target, result) {
        if (JSON.stringify(savedTopology) == "undefined" || savedTopology == undefined || savedTopology == null) {

            throw "Cannot delete before sync or use delete from controller";

        }
        if (editIdValue == null || editIdValue == "undefined" || typeof editIdValue == undefined) {
            editIdValue = 0;
        }
        this.deleteRequests = [];
        var topoObjects = savedTopology.getTopologyObjects();
        var traverse = this;
        if (topoObjects.length > 0) {
            topoObjects.forEach(function (topoObject) {
                if (!traverse.isPresenceContainer(target, topoObject.objectType)) {
                    traverse.createDeleteOperation("nokia-conf:" + topoObject.objectType);
                }
            });

            //sorting delete array
            this.deleteRequests.sort(function (a, b) {
                return b["target"].length - a["target"].length;
            });

            if (this.deleteRequests.length > 0) {
                result = this.syncRequest(target, this.deleteRequests, result, savedTopology);
            }
            if (result.success) {
                savedTopology.setTopologyObjects([]);
            }
        } else {
            throw "use delete from controller to delete the intent";
        }


        this.resetTheVariables();
        logger.info(savedTopology);
        result.setTopology(null);
        return result;
    }


    this.getElementFromArray = function (keyName, keyValue, targetJson) {

        var keys = keyName.toString().split(",");
        var keyValues = keyValue.toString().split(",");
        for (var property in targetJson) {
            var isMatch = true;
            for (var i = 0; i < keys.length; i++) {
                if (targetJson[property][keys[i]].toString() !== keyValues[i].toString()) {
                    isMatch = false;
                }
            }
            if (isMatch === true) {
                return targetJson[property];
            }
        }

        return null;
    }

    this.checkMetaInTopology = function (key) {

        var keyValue = mapFwk.get(metaData, key);
        return keyValue;

    }


    this.getKey = function (path, target) {
        var mdcFwk = new MdcFwk();
        var url = "/restconf/meta/api/v1/model/schema/" + target + "/nokia-conf:/" + path;
        var getResult = null;
        getResult = mdcFwk.fetch(target, url);
        if (getResult && getResult != undefined && getResult.msg) {
            var jsonObj = getResult.msg["attributes"];
            var keyName = "";
            for (var attribute in jsonObj) {
                var item = jsonObj[attribute];
                if (item["isKey"]) {
                    if (keyName === "")
                        keyName = item["name"];
                    else
                        keyName = keyName + "," + item["name"];

                }
            }
            metaData[path] = keyName;
            return keyName;
        }
    }

    this.checkIfMultipleKey = function (key, intentJson) {
        var keys = key.split(",");
        var multipleKey = "";
        if (keys.length > 1) {

            for (var i = 0; i < (keys.length) - 1; i++) {
                multipleKey = multipleKey + intentJson[keys[i]] + ",";
            }

            multipleKey = multipleKey + intentJson[keys[keys.length - 1]];

        } else {
            multipleKey = intentJson[key];
        }
        return multipleKey;
    }

    this.addTopologyExtraInfo = function (topology, target, intentType, key, value) {
        var xtraInfo = topologyFactory.createTopologyXtraInfoFrom(key, value);
        xtraInfo.setTarget(target);
        topology.addXtraInfo(xtraInfo);
    }


    this.createSyncOperations = function (targetUrl, targetJson) {

        logger.info("Adding the create object to Create Map");
        var savedAuditJson = mapFwk.get(createRequestsMap, targetUrl);

        if (savedAuditJson !== null && savedAuditJson !== undefined && savedAuditJson !== "" && savedAuditJson !== "undefined") {

            for (var prop in targetJson) {
                savedAuditJson[prop] = targetJson[prop];
            }
            mapFwk.set(createRequestsMap, targetUrl, savedAuditJson);

        } else {

            mapFwk.set(createRequestsMap, targetUrl, targetJson);

        }
    }

    this.addCreateRequestsToArray = function () {
        for (var prop in createRequestsMap) {
            logger.info("Creating Sync operation for create request");
            var edit;
            if (prop !== null && prop != 'undefined' && prop !== "") {
                this.sleep(1);
                editIdValue = Date.now();
                var edit = {
                    "operation": "merge",
                    "edit-id": "edit-" + editIdValue,
                    "target": "nokia-conf:" + prop,
                    "value": createRequestsMap[prop]
                };
            }
            if (edit !== null && edit !== 'undefined') {
                this.createRequests.push(edit);
            } else {
                logger.info("Couldnot create the operation part for the targetUrl:" + prop);
            }

        }

    }

    this.createDeleteOperation = function (targetUrl) {
        logger.info("Creating the Delete operation " + targetUrl);
        var deleteOperation;
        if (targetUrl !== null && targetUrl != 'undefined') {
            this.sleep(1);
            var editIdValue = Date.now();
            deleteOperation = {"operation": "delete", "edit-id": "edit-" + editIdValue, "target": targetUrl}

        }
        if (deleteOperation !== null && deleteOperation !== 'undefined') {
            this.deleteRequests.push(deleteOperation);
        } else {
            logger.info("Couldnot create the delete operation part for the targetUrl:" + targetUrl);
        }

    }

    this.syncRequest = function (target, requests, result, savedTopology) {
        var mdcFwk = new MdcFwk();
        var body;
        if (requests.length > 0) {
            var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + target + "/root/";

            body = utilityService.processTemplate(resourceProvider.getResource("create.ftl"), {
                timestamp: JSON.stringify("generic-patch-" + Date.now()),
                requests: JSON.stringify(requests)
            });

            logger.info("Sending the request with the body: " + body);
            var bodyObject = JSON.parse(body);
            var editObjs = [];
            var bodyEditObjs = bodyObject["ietf-yang-patch:yang-patch"]["edit"];
            for (var i in bodyEditObjs) {
                var obj = bodyEditObjs[i];
                var operation = obj["operation"];
                if (operation === "merge") {
                    var targetObj = obj["target"].split("/");
                    var pathInfo = targetObj[targetObj.length - 1].split("=")[0];
                    var valueObj = {};
                    valueObj[pathInfo] = obj["value"];
                    obj["value"] = valueObj;

                }
                editObjs.push(obj);
            }
            bodyObject["ietf-yang-patch:yang-patch"]["edit"] = editObjs;
            var deployResult = mdcFwk.deploy(target, url, JSON.stringify(bodyObject));
            logger.info(null, "deployResult : " + JSON.stringify(deployResult));

            if (!deployResult.success) {
                log.error(null, "deployResult2 : " + JSON.stringify(deployResult));
                result.setSuccess(false);
                result.setTopology(savedTopology);
                result.setErrorCode(deployResult.httpStatus);
                result.setErrorDetail(deployResult.msg);
                this.resetTheVariables();
                return result;

            }
            this.resetTheVariables();
            result.setTopology(savedTopology);
            result.setSuccess(true);
            return result;
        } else {
            logger.info("sync unsucessful or no changes to sync");
            result.setSuccess(true);
        }

    }

    this.getDeleteRequests = function () {
        return this.deleteRequests;
    }

    this.getCreateRequests = function () {
        return this.createRequests;
    }

    this.validateData = function (intentJson, path, target) {
        // logic to get the chassis type of give ned-id.
        return this.removeEmptyContainers("", intentJson, path, target);
    }

    this.removeEmptyContainers = function (prop, intentJson, path, target) {

        if (Array.isArray(intentJson)) {
            var object = [];
            for (var prop in intentJson) {
                var value = this.removeEmptyContainers(prop, intentJson[prop], path, target);
                if (this.isEmptyLeaf(this.pParentPath + path, target, prop, value)) {
                    object.push([value]);
                }
                if (value) {
                    object.push(value);
                }

            }
            if (Object.keys(object).length !== 0) {
                return object;
            }
        } else if (typeof intentJson == 'object') {
            var object = {};
            for (var prop in intentJson) {
                var pPath = path + "/" + prop;
                // for null values
                if (intentJson[prop] === null) {
                    intentJson[prop] = "null";
                }
                var value = this.removeEmptyContainers(prop, intentJson[prop], pPath, target);
                if (this.isEmptyLeaf(this.pParentPath + path, target, prop, value)) {
                    object[prop] = [value];
                }
                if ((value && value !== null) || value == 0) {
                    object[prop] = value;
                }

            }
            if (Object.keys(object).length !== 0) {
                return object;
            }
        } else {
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if (intentJson !== undefined && intentJson !== "") {
                return intentJson;
            }

            return null;
        }
    }

    this.validateElements = function (jsonPath, target) {
        this.getDeviceType(target);
        var resourceType = resourceProvider.getResource(this.deviceType).split("\n");
        if (resourceType) {
            var path = jsonPath.replaceAll("/", " ");
            var index = resourceType.indexOf(path);
            if (index == -1) {
                throw jsonPath + " not valid Leaf Element";
            } else {
                return true;
            }
        }
        throw this.deviceType + "does not exists";
    }

    this.getDeviceType = function (deviceName) {
        if (!this.deviceType) {
            var deviceAttributes = mds.getAllInfoFromDevices([deviceName]);
            var deviceType = deviceAttributes[0].familyTypeRelease.split(":")[0];
            if (deviceType) {
                this.deviceType = deviceType;
            } else {
                throw "device type error";
            }
        }
    }

    this.sleep = function (sleepDuration) {
        var now = new Date().getTime();
        while (new Date().getTime() < now + sleepDuration) {
            logger.info("sleeping for duration" + sleepDuration)
        }

    }

    this.resetTheVariables = function () {

        createRequestsMap = undefined;
        this.createRequests = undefined;
        this.deleteRequests = undefined;
        deviceType = undefined;
        metaData = undefined;
        currentObjects = undefined;
        nodeCheckSums = undefined;
        intentCheckSums = undefined;
        savedObjects = undefined;
        editIdValue = undefined;
        createRequests = undefined;
        deleteRequests = undefined;
        pParentPath = undefined;
        presenceContainers = undefined;
    }
}

