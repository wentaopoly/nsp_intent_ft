function NfmpSuggest() {

    this.getData = function (searchObjectJson, className, type) {
        var nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    if(!value[type].startsWith("_tmnx_"))
                    {
                        ret.push(value[type]);
                    }
                })
            }
        }

        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

    this.getPrefixListName = function (neId) {
        var className = "filterprefixlist.PrefixList";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "displayedName");
    }

    this.getRoutingInstances = function (neId, routerPointer) {
        var searchObjectJson = {
            "fullClassName": "vprn.Site",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };

        // Check if routerPointer exists and add it to the filter
        if (routerPointer !== undefined && routerPointer !== null) {
            searchObjectJson.filter.and.equal.push({
                "name": "objectFullName",
                "value": routerPointer
            });
        }

        var routingInstances = this.getData(searchObjectJson, "vprn.Site", "displayedName");

        return routingInstances;
    }

    this.getRoutingInstancePointer = function (neId, displayedName) {
            var searchObjectJson = {
                "fullClassName": "vprn.Site",
                "filter": {
                    "and": {
                        "equal": [
                            {
                                "name": "siteId",
                                "value": neId
                            },
                            {
                                "name": "displayedName",
                                "value": displayedName
                            }
                        ]
                    }
                },
                "resultFilter": {
                    "children": "",
                    "attribute": [
                        "objectFullName"
                    ]
                }
            };
            var routingInstances = this.getSuggestData(searchObjectJson, "vprn.Site", "objectFullName");

            return routingInstances;
        }

    this.getSuggestData = function (searchObjectJson, searchClass, propertyName)
    {
        var nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        finalResponse = finalResponse[searchClass];
        logger.info(JSON.stringify(finalResponse));

        if (Object.keys(finalResponse).length !== 0)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            finalResponse.forEach(function (value, index, array) {
                ret.push(value[propertyName].substring(0, value[propertyName].lastIndexOf(":")));
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }
}