var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpPortIngressPolicyFwk() {
    var util = new utilities();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var savedObjects;
    var currentObjects;
    var isAudit = false;
    var isLocalExists = false;
    var isGlobalExists = false;
    var distribute_url = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true";

    this.synchronize = function (input, result, intentTypeName, xpath, initialPropertyName, uniqueIdentifier) {
        if (input.getNetworkState().name() == "delete") {
            return this.syncDelete(input, result);
        }
        var savedTopology = input.getCurrentTopology();
        logger.info(savedTopology);
        savedObjects = {};
        currentObjects = {};
        this.loadSavedObjectsFromTopology(savedTopology);
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyId = input.getTarget().split("#")[2];
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
        if (!intentConfig) {
            intentConfig = Object.create({});
        }
        intentConfig["policy-id"] = parseInt(policyId);
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target Access-Ingress = " + policyId);

        this.createOrModify(target, intentConfig, policyId);
        var currentTopo = this.loadCurrentObjectsToTopology(target);

        result = util.setSuccessResult(result, currentTopo);
        return result;
    }

    this.syncDelete = function (input, result) {
        var className = "sasqos.PortAccessIngress";
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyId = input.getTarget().split("#")[2];
        var objectFullName = "network:" + neId + ":sasPortAccessIngressPolicy:" + policyId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        var searchPayLoad = this.constructSearchString(className, objectFullName);
        var searchResponse = nfmpFwk.find(neId, searchPayLoad);
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0)) {
            if (!(searchResponse.success))
                logger.info("[NFMP-ACCESS-INGRESS-FWK] syncDelete(): Unable to get Policy info from nfm-p for policy Id:" + policyId + " on " + neId);
            if (JSON.parse(searchResponse["response"]).length === 0)
                logger.info("[NFMP-ACCESS-INGRESS-FWK] syncDelete(): There is no access-ingress policy Id:" + policyId + " on " + neId);
            result.setSuccess(false);
            return;
        }
        logger.info("[NFMP-ACCESS-INGRESS-FWK] syncDelete(): Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success) {
            logger.info("[NFMP-ACCESS-INGRESS-FWK] syncDelete(): Unable to Delete: " + deleteResult.msg);
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }

    this.createOrModify= function(neId, intentConfig,uniqueIdentifier) {
        var fullClassName = "sasqos.PortAccessIngress";
        var objectFullName = "sasPortAccessIngressPolicy:" + intentConfig["policy-id"];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        var localPolicy = util.getIfObjectExists(fullClassName, localPolicyFullName);
        var result;
        var portIngressPayload;
        var distributePayload;
        var distributeResult;
        if (localPolicy != null) {
            isLocalExists = true;
            isGlobalExists = true;
            if (localPolicy[0]["id"] !== uniqueIdentifier) {
                throw new RuntimeException("Already there exists a policy on " + neId + " with policy ID " + intentConfig["policy-id"]);
            }
            portIngressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, isLocalExists, localPolicy);
            result = this.modifyRequest(neId, portIngressPayload);
            if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                throw new RuntimeException('Unable to Create/Distribute Policy: ' + intentConfig["policy-id"] +" , Kindly check the intent configuration");
            }
        }
        else {
            logger.info(LOG_PREFIX + "####### Unable to find the local policy, Trying to fetch global policy if available ######");
            var searchPayload = this.constructSearchString(fullClassName, objectFullName);
            var searchResponse = nfmpFwk.find(neId, searchPayload);
            if (!(searchResponse.success && JSON.stringify(searchResponse.response) === "")) {
                if (!searchResponse.success) {
                    logger.info(LOG_PREFIX + "createOrModify(): Unable to get Policy info from nfm-p for Ne " +
                        neId + " and Policy ID: " + uniqueIdentifier);
                }
                if (searchResponse.response === "") {
                    logger.info(LOG_PREFIX + "createOrModify(): There is no port-ingress policy with ID:" +
                        uniqueIdentifier + " on " + neId);
                }
            }
            else {
                throw new RuntimeException("createOrModify(): There exists a port-ingress policy with Policy ID " +intentConfig["policy-id"]);
            }

            var globalPolicy = util.getIfObjectExists(fullClassName, objectFullName);
            if (globalPolicy != null) {
                isGlobalExists = true;
                if (globalPolicy[0]["id"] !== uniqueIdentifier) {
                    logger.info(LOG_PREFIX + "createOrModify(): There exists a port-ingress global policy in NFMP with same policy ID " + intentConfig["policy-id"] + " on " + neId);
                    logger.info(LOG_PREFIX + "createOrModify(): Updating port-ingress global policy Id to policy " + intentConfig["policy-id"]);
                    this.updateAccessIngressPolicyId(neId, objectFullName, intentConfig["policy-id"]);
                }

                distributePayload = util.distribute(neId, objectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(neId, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                logger.info(LOG_PREFIX + "checking distribution of existing global policy was successful#######");
                if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                    throw new RuntimeException("Unable to Distribute existing Global Policy: " + uniqueIdentifier +
                        " , Kindly check the Global Policy configuration");
                }
                logger.info(LOG_PREFIX + "distribution of existing global policy was successful, updating with intent configuration ######");
                portIngressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, true, globalPolicy);
                result = this.modifyRequest(neId, portIngressPayload);
                if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                    throw new RuntimeException('Unable to Create/Distribute Policy: ' + uniqueIdentifier +
                        " , Kindly check the intent configuration");
                }
            }
            else {
                //distributing empty policy
                logger.info(LOG_PREFIX + "##### Unable to find the Global Policy, distributing empty policy and updating ######");
                portIngressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, false, null);
                result = this.modifyRequest(neId, portIngressPayload);
                distributePayload = util.distribute(neId, objectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(neId, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                //updating the local policy with intent configuration
                portIngressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, true, null);
                result = this.modifyRequest(neId, portIngressPayload);
            }
        }
        return result;
    }

    this.createPolicyLevelPayLoad = function (neId, intentConfig, isLocalExists, policyObject) {
        var fullClassName = "sasqos.PortAccessIngress";
        var policyFdn = "sasPortAccessIngressPolicy";
        var objectFullName = "sasPortAccessIngressPolicy:" + intentConfig["policy-id"];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        if (isLocalExists) {
            objectFullName = localPolicyFullName;
        }
        var properties = {};
        var childProperties = {};
        properties["id"] = intentConfig["policy-id"];
        properties["description"] = intentConfig["description"];
        properties["defaultFc"] = intentConfig["default-fc"];
        properties["defaultFcProfile"] = intentConfig["profile"];
        properties["ingressCounterType"] = util.gftransformCounterMode(intentConfig["counter-mode"]);
        properties["numQosClassifiers"] = intentConfig["num-qos-classifiers"];
        properties["dscpClassificationPointer"] = util.gfNfmpDscpClassification(intentConfig["dscp-classification"]);
        properties["dot1pClassificationPointer"] = util.gfNfmpDot1pClassification(intentConfig["dot1p-classification"]);
        properties["tableClassificationCriteria"] = util.gfconvertToTableClassificationCriteria(intentConfig["table-classification-criteria"]);
        if (intentConfig["meter"]) {
            if (!Array.isArray(intentConfig["meter"])) {
                intentConfig["meter"] = [intentConfig["meter"]];
            }
            var meterLevelDataPayload = [];
            for (var index in intentConfig["meter"]) {
                var intentMeterDataConfig = intentConfig["meter"][index];
                var meterLevelPayload = this.createMeterPayload(intentMeterDataConfig);
                meterLevelDataPayload.push(meterLevelPayload);
            }
            childProperties["sasqos.PortAccessIngressMeter"] = meterLevelDataPayload;
        }
        if (intentConfig["fc"]) {
            if (!Array.isArray(intentConfig["fc"])) {
                intentConfig["fc"] = [intentConfig["fc"]];
            }
            var forwardingClassPayload = [];
            for (var index in intentConfig["fc"]) {
                var intentForwardingClassConfig = intentConfig["fc"][index];
                var forwardClassPayload = this.createForwardingClassPayLoad(intentForwardingClassConfig);
                forwardingClassPayload.push(forwardClassPayload);
            }
            childProperties["sasqos.PortAccessIngressForwardingClass"] = forwardingClassPayload;
        }
        else {
            childProperties["sasqos.PortAccessIngressForwardingClass"] =[];
        }
        var policyLevelPayload = util.editPayload(policyFdn, properties, childProperties, fullClassName, objectFullName);
        return policyLevelPayload;
    }

    this.createMeterPayload = function (intentMeterDataConfig) {
        var properties = {};
        properties["id"] = intentMeterDataConfig["meter-id"];
        if (intentMeterDataConfig["rate-mode"]) {
            properties["rateMode"] = util.gftransformRateMode(intentMeterDataConfig["rate-mode"]);
        }
        if (intentMeterDataConfig["color-mode"]) {
            properties["colorMode"] = util.gftransformColorMode(intentMeterDataConfig["color-mode"]);
        }
        if(intentMeterDataConfig["multi-point"]){
            properties["mCast"]=intentMeterDataConfig["multi-point"];
        }
        if (intentMeterDataConfig["rate"] !== undefined) {
            if (intentMeterDataConfig["rate"]["pir"] === "max") {
                properties["pir"] = -1;
            } else if (intentMeterDataConfig["rate"]["pir"] !== undefined) {
                properties["pir"] = intentMeterDataConfig["rate"]["pir"];
            }
            if (intentMeterDataConfig["rate"]["cir"] === "max") {
                properties["cir"] = -1;
            } else if (intentMeterDataConfig["rate"]["cir"] !== undefined) {
                properties["cir"] = intentMeterDataConfig["rate"]["cir"];
            }
        }
        if (intentMeterDataConfig["adaptation-rule"]) {
            if (intentMeterDataConfig["adaptation-rule"]["pir"]) {
                properties["pirAdaptation"] = intentMeterDataConfig["adaptation-rule"]["pir"];
            }
            if (intentMeterDataConfig["adaptation-rule"]["cir"]) {
                properties["cirAdaptation"] = intentMeterDataConfig["adaptation-rule"]["cir"];
            }
        }
        if (intentMeterDataConfig['cbs-type'] === "bytes") {
            properties["cbsType"] = "bytes";
            if (intentMeterDataConfig["cbs"] === "Default") {
                properties["cbsBytes"] = -1;
            } else {
                properties["cbsBytes"] = intentMeterDataConfig["cbs"];
            }
        }
        if (intentMeterDataConfig['cbs-type'] === "kbytes") {
            properties["cbsType"] = "kbytes";
            if (intentMeterDataConfig["cbs"] === "Default") {
                properties["cbsKiloBytes"] = -1;
            } else {
                properties["cbsKiloBytes"] = intentMeterDataConfig["cbs"];
            }
        }
        if (intentMeterDataConfig['cbs-type'] === "kbits") {
            properties["cbsType"] = "kbits";
            if (intentMeterDataConfig["cbs"] === "Default") {
                properties["cbs"] = -1;
            } else {
                properties["cbs"] = intentMeterDataConfig["cbs"];
            }
        }
        if (intentMeterDataConfig['mbs-type'] === "bytes") {
            properties["mbsType"] = "bytes";
            if (intentMeterDataConfig["mbs"] === "Default") {
                properties["mbsBytes"] = -1;
            } else {
                properties["mbsBytes"] = intentMeterDataConfig["mbs"];
            }
        }
        if (intentMeterDataConfig['mbs-type'] === "kbytes") {
            properties["mbsType"] = "kbytes";
            if (intentMeterDataConfig["mbs"] === "Default") {
                properties["mbsKiloBytes"] = -1;
            } else {
                properties["mbsKiloBytes"] = intentMeterDataConfig["mbs"];
            }
        }
        if (intentMeterDataConfig['mbs-type'] === "kbits") {
            properties["mbsType"] = "kbits";
            if (intentMeterDataConfig["mbs"] === "Default") {
                properties["mbs"] = -1;
            } else {
                properties["mbs"] = intentMeterDataConfig["mbs"];
            }
        }
        return properties
    }

    this.createForwardingClassPayLoad = function (intentConfig) {
        var properties = {};
        properties["forwardingClass"] = intentConfig["fc-name"];
        if (intentConfig["meter-id"]) {
            properties["meterId"] = intentConfig["meter-id"];
        }
        if (intentConfig["multicast-meter-id"]) {
            properties["multicastMeterId"] = intentConfig["multicast-meter-id"];
        }
        return properties;
    }

    this.updateAccessIngressPolicyId = function (target, objectFullName, PolicyId) {
        var fullClassName = "sasqos.PortAccessIngress";
        var filterFdn = "sasPortAccessIngressPolicy";
        var properties = {};

        properties["id"] = PolicyId;

        var payload = {};
        var configInfo = {};
        configInfo["containedClassProperties"] = properties;
        configInfo["objectClassName"] = fullClassName;
        payload["distinguishedName"] = filterFdn;
        payload["objectFullName"] = objectFullName;
        payload["configInfo"] = configInfo;
        var result = this.modifyRequest(target, payload);
        return result;
    }

    this.modifyRequest = function (target, payload) {

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
           logger.error("Error result = {}",JSON.stringify(result));
           let errorMsg = result.msg;
           if(errorMsg.indexOf("object already exists") !== -1)
           {
               logger.info("Global policy Object already exists, Re-checking the Policy existence ");
               //util.delay(2000);
               let configInfo = payload.configInfo;
               let fullClassName;
               for (let key in configInfo) {
                 if (configInfo.hasOwnProperty(key)) {
                   fullClassName = key;
                   break;
                 }
               }
               let objectFullName = payload.objectFullName;
               objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
               logger.info("fullClassName = {}",fullClassName);
               logger.info("objectFullName = {}",objectFullName);
               if (!util.isObjectExists(fullClassName, objectFullName))
               {
                   throw new RuntimeException("Global Policy Object Not Found!!!");
               }
           }
           else
           {
               throw new RuntimeException(result.msg);
           }
        }
        return result;

    }

    this.audit = function (input, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        isAudit = true;
        var lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        var intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        intentConfig["policy-id"] = input.getTarget().split("#")[2];
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        if (intentConfig) {
            this.auditAndCompare(neId, intentConfig, auditReport);
        } else {
            throw "configuration not available in the intent";
        }
        return auditReport
    }

    this.auditAndCompare = function (neId, intentConfig, auditReport) {
        var PortIngressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, true, null);
        var result = this.auditRequest(neId, PortIngressPayload);
        auditReport = util.reportMisaligned(neId, result, auditReport);
        return auditReport;
    }

    this.auditRequest = function (neId, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.constructSearchString = function(className, objectFullName) {
        var expectedJson = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        return expectedJson;
    }

    this.loadSavedObjectsFromTopology = function (savedTopology) {
        if (savedTopology) {
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0) {
                topoObjects.forEach(function (topoObject) {
                    mapFwk.set(savedObjects, topoObject.getObjectType(), topoObject.getObjectRelativeObjectID());
                });
            }
        }

    }
    this.loadCurrentObjectsToTopology = function (target) {

        var currentTopo = topologyFactory.createServiceTopology();
        if (Object.keys(currentObjects).length) {
            for (var key in currentObjects) {
                objectId = mapFwk.get(currentObjects, key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key, objectId, "INFRASTRUCTURE", target, ""));
            }
        }
        return currentTopo;

    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }

    this.removeEmptyContainers = function (prop, intentJson, path, target) {

        if (Array.isArray(intentJson)) {
            var object = [];
            for (var prop in intentJson) {
                var value = this.removeEmptyContainers(prop, intentJson[prop], path, target);
                if (value) {
                    object.push(value);
                }

            }
            if (Object.keys(object).length !== 0) {
                return object;
            }
        } else if (typeof intentJson == 'object') {
            var object = {};
            for (var prop in intentJson) {
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop, intentJson[prop], pPath, target);
                if ((value && value !== null) || value == 0) {
                    object[prop] = value;
                }

            }
            if (Object.keys(object).length !== 0) {
                return object;
            }
        } else {
            if (intentJson !== undefined && intentJson !== "") {
                return intentJson;
            }

            return null;
        }
    }
}
