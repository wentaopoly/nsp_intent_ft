var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpCard() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    let nfmpFwk = new NfmpFwk();
    var parseTarget = new ParseTarget();
    var savedTopology;
    var isAudit = false;
    var auditResult = {};

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        logger.info("input = \n" + input + "-------" + result + "-------" + intentTypeName + "-------" + parentXpath + "-------" + initialPropertyName + "-------" + uniqueIdentifier);
        var cardSlotId = parseTarget.getUniqueIdentifier(input.getTarget());
        // code to handle delete
        if (input.getNetworkState().name() == "delete")
        {
            logger.info("Calling syncDelete");
            return this.syncDelete(input, result, cardSlotId);
        }
        // code to handle sync
        savedTopology = input.getCurrentTopology();
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        intentConfig["uniqueIdentifier"] = cardSlotId;
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        logger.info("Target Card Slot = " + intentConfig["uniqueIdentifier"]);
        this.createOrModify(neId, intentConfig["uniqueIdentifier"], intentConfig);
        result.setTopology(savedTopology);
        result.getTopology().setXtraInfo(savedTopology.getXtraInfo());
        return util.setSuccessResult(result, savedTopology);
    }
    this.audit = function (target, config, svcTopo, adminState, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        logger.info("Audit =\n" + target + "----------" + config + "----------" + svcTopo + "----------" + adminState + "----------" + auditReport + "----------" + intentTypeName + "----------" + parentXpath + "----------" + initialPropertyName + "----------" + uniqueIdentifier);

        isAudit = true;
        var neId = parseTarget.getNeIdFromTarget(target);
        var cardSlotId = parseTarget.getUniqueIdentifier(target);
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        intentConfig["uniqueIdentifier"] = cardSlotId;
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        logger.info("Target Card Slot ID = " + cardSlotId);
        if (intentConfig)
        {
            this.auditAndCompare(neId, cardSlotId, intentConfig, auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }

        return auditReport
    }
    this.auditAndCompare = function (neId, cardSlotId, intentConfig, auditReport) {
        this.createCardPayLoad(neId, cardSlotId, intentConfig);
        if (intentConfig["mda"])
        {
            this.mdaConfig(neId, intentConfig, intentConfig["uniqueIdentifier"])
        }
        if (intentConfig["xiom"])
        {
            this.xiomConfig(neId, intentConfig)
        }
        logger.info("Final audit result =\n" + JSON.stringify(auditResult))
        auditReport = util.reportMisaligned(neId, auditResult, auditReport);
        return auditReport;
    }
    this.auditRequest = function (neId, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }
    this.updateAuditResult = function (aInAuditResult) {
        var resultResp = JSON.parse(aInAuditResult.response);
        var misalignedAttributes = resultResp.misalignedAttributes;
        if (Object.keys(auditResult).length === 0)
        {
            auditResult = resultResp;
        }
        else
        {
            if (misalignedAttributes.length > 0)
            {
                auditResult.misalignedAttributes = auditResult.misalignedAttributes.concat(misalignedAttributes);
                auditResult.aligned = false;
            }
        }
    }
    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }
    this.createOrModify = function (neId, cardSlotId, intentConfig) {
        this.createCardPayLoad(neId, cardSlotId, intentConfig);
        this.deleteMdaXiom(neId, intentConfig);
        if (intentConfig["mda"])
        {
            this.mdaConfig(neId, intentConfig, intentConfig["uniqueIdentifier"])
        }
        if (intentConfig["xiom"])
        {
            this.xiomConfig(neId, intentConfig)
        }
    }
    this.createCardPayLoad = function (neId, cardSlotId, intentConfig) {
        if (savedTopology == null)
        {
            logger.info("Creating topology");
            savedTopology = topologyFactory.createServiceTopology();
        }
        var fullClassName = "equipment.BaseCard";
        var fdn = "network:" + neId + ":shelf-1:cardSlot-" + cardSlotId;
        if (neId && String(neId).indexOf(':') !== -1) {
            fdn = util.modifyNeIdForIpV6(fdn, neId);
        }
        var objectFullName = "network:" + neId + ":shelf-1:cardSlot-" + cardSlotId + ":card";
        if (neId && String(neId).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        }
        var properties = {};
        properties["slotId"] = cardSlotId;
        properties["specificType"] = [intentConfig["card-type"]];
        properties["administrativeState"] = util.convertAdminStateGreenField(intentConfig["admin-state"]);
        var childProperties = [];
        var cardPayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
        if (!isAudit)
        {
            logger.info("Sending the modify request for Card");
            this.modifyRequest(neId, cardPayload);
        }
        else
        {
            logger.info("Sending the audit request for Card");
            this.updateAuditResult(this.auditRequest(neId, cardPayload));

        }
    }
    this.mdaConfig = function (neId, intentConfig, cardSlotId, xiomCardSlotId) {
        if (!Array.isArray(intentConfig["mda"]))
        {
            intentConfig["mda"] = [intentConfig["mda"]];
        }
        for (var index in intentConfig["mda"])
        {
            var mdaConfig = intentConfig["mda"][index];
            this.createMdaPayLoad(neId, mdaConfig, cardSlotId, xiomCardSlotId, false);
            //SyncE cannot be created during create, hence resending the request seperatly
            this.createMdaPayLoad(neId, mdaConfig, cardSlotId, xiomCardSlotId, true);
        }
    }
    this.xiomConfig = function (neId, intentConfig) {
        if (!Array.isArray(intentConfig["xiom"]))
        {
            intentConfig["xiom"] = [intentConfig["xiom"]];
        }
        for (var index in intentConfig["xiom"])
        {
            var xiomConfig = intentConfig["xiom"][index];

            var cardSlotId = intentConfig["uniqueIdentifier"];
            var xiomCardSlotId = xiomConfig["xiom-slot"];

            var xiomPayload = this.createXiomPayLoad(neId, xiomConfig, cardSlotId);
            if (xiomConfig["mda"])
            {
                this.mdaConfig(neId, xiomConfig, cardSlotId, xiomCardSlotId);
            }
        }
    }
    this.createMdaPayLoad = function (neId, intentMdaConfig, cardSlotId, xiomCardSlotId, resend) {
        var mdaSlotId = intentMdaConfig["mda-slot"];
        var fullClassName = "equipment.DaughterCard";
        var fdn = "network:" + neId + ":shelf-1:cardSlot-" + cardSlotId + ":card:daughterCardSlot-" + mdaSlotId;
        if (neId && String(neId).indexOf(':') !== -1) {
             fdn = util.modifyNeIdForIpV6(fdn, neId);
        }
        var objectFullName = "network:" + neId + ":shelf-1:cardSlot-" + cardSlotId + ":card:daughterCardSlot-" + mdaSlotId + ":daughterCard";
        if (neId && String(neId).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        }
        if (xiomCardSlotId)
        {
            fdn = "network:" + neId + ":shelf-1:cardSlot-" + cardSlotId + ":card:xioSlot-" + xiomCardSlotId + ":xiomCard:daughterCardSlot-" + mdaSlotId;
            if (neId && String(neId).indexOf(':') !== -1) {
                fdn = util.modifyNeIdForIpV6(fdn, neId);
            }
            objectFullName = "network:" + neId + ":shelf-1:cardSlot-" + cardSlotId + ":card:xioSlot-" + xiomCardSlotId + ":xiomCard:daughterCardSlot-" + mdaSlotId + ":daughterCard";
            if (neId && String(neId).indexOf(':') !== -1) {
                 objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
            }
        }
        var entry = topologyFactory.createTopologyXtraInfoFrom(objectFullName, fullClassName);
        savedTopology.addXtraInfo(entry);

        var properties = {};
        if (intentMdaConfig)
        {
            properties["slotId"] = cardSlotId;
            if (xiomCardSlotId)
            {
                properties["xiomCardSlotId"] = xiomCardSlotId.toString();
            }
            properties["daughterCardSlotId"] = mdaSlotId;
            if (resend)
            {
                properties["syncE"] = intentMdaConfig["sync-e"];
            }
            else
            {
                properties["administrativeState"] = util.convertAdminStateGreenField(intentMdaConfig["admin-state"]);
                properties["specificType"] = [intentMdaConfig["mda-type"]];
            }
        }
        var childProperties = [];
        var mdaPayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
        if (!isAudit)
        {
            logger.info("Sending the modify request for MDA");
            this.modifyRequest(neId, mdaPayload);
        }
        else
        {
            logger.info("Sending the audit request for MDA");
            this.updateAuditResult(this.auditRequest(neId, mdaPayload));
        }
    }
    this.createXiomPayLoad = function (neId, intentXiomConfig, cardSlotId) {
        var xiomSlotId = intentXiomConfig["xiom-slot"];
        var fullClassName = "equipment.XiomCard";
        var fdn = "network:" + neId + ":shelf-1:cardSlot-" + cardSlotId + ":card:xioSlot-" + xiomSlotId;
        if (neId && String(neId).indexOf(':') !== -1) {
            fdn = util.modifyNeIdForIpV6(fdn, neId);
        }
        var objectFullName = "network:" + neId + ":shelf-1:cardSlot-" + cardSlotId + ":card:xioSlot-" + xiomSlotId + ":xiomCard";
        if (neId && String(neId).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        }
        var entry = topologyFactory.createTopologyXtraInfoFrom(objectFullName, fullClassName);
        savedTopology.addXtraInfo(entry);

        var properties = {};
        if (intentXiomConfig)
        {
            properties["slotId"] = cardSlotId;
            properties["xiomCardSlotId"] = xiomSlotId;
            properties["administrativeState"] = util.convertAdminStateGreenField(intentXiomConfig["admin-state"]);
            if (intentXiomConfig["xiom-type"] === "iom-s-3.0t")
            {
                properties["specificType"] = ["card_iom_s_3t"];
            }
            else
            {
                properties["specificType"] = ["card_iom_s_1_5t"];
            }
        }
        var childProperties = [];
        var xiomPayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
        if (!isAudit)
        {
            logger.info("Sending the modify request for Xiom");
            this.modifyRequest(neId, xiomPayload);
        }
        else
        {
            logger.info("Sending the audit request for Xiom");
            this.updateAuditResult(this.auditRequest(neId, xiomPayload));
        }
    }
    this.modifyRequest = function (neId, payload) {
        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }
    this.syncDelete = function (input, result, cardSlotId) {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var objectFullName = "network:" + neId + ":shelf-1:cardSlot-" + cardSlotId + ":card";
        if (neId && String(neId).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        }
        logger.info("Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }
    this.syncDeleteChild = function (objectFullName, neId) {
        if (neId && String(neId).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        }
        logger.info("Deleting : " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
    }
    this.deleteMdaXiom = function (neId, intentConfig) {
        logger.info("deleteMdaXiom MDA and XIOM");
        var objectFullNameList = [];
        if (intentConfig["mda"] && !Array.isArray(intentConfig["mda"]))
        {
            intentConfig["mda"] = [intentConfig["mda"]];
        }
        objectFullNameList = objectFullNameList.concat(this.getMdaObjectFullName(neId, intentConfig["mda"], intentConfig["uniqueIdentifier"]));
        if (intentConfig["xiom"] && !Array.isArray(intentConfig["xiom"]))
        {
            intentConfig["xiom"] = [intentConfig["xiom"]];
        }
        objectFullNameList = objectFullNameList.concat(this.getXiomObjectFullName(neId, intentConfig["xiom"], intentConfig["uniqueIdentifier"]));
        logger.info("List of Xiom and MDA objects in intent = \n" + objectFullNameList);
        logger.info("List of Xiom and MDA objects already exists = \n" + savedTopology.getXtraInfo());

        var intentlength = objectFullNameList.length;
        var XtraInfolength = savedTopology.getXtraInfo().length;

        var childObjectsBeDeleted = [];
        if (XtraInfolength > intentlength)
        {
            for (var index in savedTopology.getXtraInfo())
            {
                var xtraInfo = savedTopology.getXtraInfo()[index].getKey();
                var deleteFlag = true;


                for (var index in objectFullNameList)
                {
                    if (xtraInfo == objectFullNameList[index])
                    {
                        deleteFlag = false;
                        break;
                    }
                }
                if (deleteFlag)
                {
                    childObjectsBeDeleted.push(xtraInfo);
                }
            }
        }
        for (var index in childObjectsBeDeleted)
        {
            logger.info(childObjectsBeDeleted[index]);
            this.syncDeleteChild(childObjectsBeDeleted[index], neId);
        }
        savedTopology.setXtraInfo([]);
    }
    this.getMdaObjectFullName = function (neId, intentMdaConfig, cardSlotId, xiomCardSlotId) {
        var objectFullNameList = [];
        for (var index in intentMdaConfig)
        {
            var mdaConfig = intentMdaConfig[index];
            if (mdaConfig)
            {
                var mdaSlotId = mdaConfig["mda-slot"];
                var objectFullName = "network:" + neId + ":shelf-1:cardSlot-" + cardSlotId + ":card:daughterCardSlot-" + mdaSlotId + ":daughterCard";
                if (neId && String(neId).indexOf(':') !== -1) {
                    objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
                }
                if (xiomCardSlotId)
                {
                    objectFullName = "network:" + neId + ":shelf-1:cardSlot-" + cardSlotId + ":card:xioSlot-" + xiomCardSlotId + ":xiomCard:daughterCardSlot-" + mdaSlotId + ":daughterCard";
                    if (neId && String(neId).indexOf(':') !== -1) {
                        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
                    }
                }
                objectFullNameList = objectFullNameList.concat(objectFullName);
            }
        }
        return objectFullNameList;
    }
    this.getXiomObjectFullName = function (neId, intentXiomConfig, cardSlotId) {
        var objectFullNameList = [];
        for (var index in intentXiomConfig)
        {
            var xiomConfig = intentXiomConfig[index];
            if (xiomConfig)
            {
                var xiomSlotId = xiomConfig["xiom-slot"];
                var objectFullName = "network:" + neId + ":shelf-1:cardSlot-" + cardSlotId + ":card:xioSlot-" + xiomSlotId + ":xiomCard";
                if (neId && String(neId).indexOf(':') !== -1) {
                    objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
                }
                objectFullNameList = objectFullNameList.concat(objectFullName);
                if (xiomConfig["mda"] && !Array.isArray(xiomConfig["mda"]))
                {
                    xiomConfig["mda"] = [xiomConfig["mda"]];
                }
                objectFullNameList = objectFullNameList.concat(this.getMdaObjectFullName(neId, xiomConfig["mda"], cardSlotId, xiomSlotId));
            }
        }
        return objectFullNameList;
    }
}
