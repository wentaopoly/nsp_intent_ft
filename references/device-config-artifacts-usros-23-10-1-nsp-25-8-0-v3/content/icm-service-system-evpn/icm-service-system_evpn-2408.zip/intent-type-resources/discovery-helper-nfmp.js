var RuntimeException = Java.type('java.lang.RuntimeException');

load({
    script: resourceProvider.getResource("nfmp-fwk.js"),
    name: "NfmpFwk"
});
load({
    script: resourceProvider.getResource('parse-target.js'),
    name: 'ParseTarget'
});


function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();

    this.getDeviceConfiguration = function(target, initialPropertyName) {

        let neId = parseTarget.getNeIdFromTarget(target);
        let ethernetSegmentName = parseTarget.getUniqueIdentifier(target);
        let searchPayLoad = this.constructSearchString(neId, ethernetSegmentName);
        let searchResponse = nfmpFwk.find(neId, searchPayLoad);
        logger.info(JSON.stringify(searchResponse));
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                throw new RuntimeException("Failed to get ethernet segment info from nfm-p for Ne " + neId + " and Ethernet Segment Name: " + ethernetSegmentName);
            if(JSON.parse(searchResponse["response"]).length === 0)
                throw new RuntimeException("There is no Ethernet Segment with Name:" + ethernetSegmentName );
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse[0];

    }

    this.extractDeviceConfig = function(defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);

        let ethernetSegmentconfig = deviceConfig['properties'];
        if (null !== ethernetSegmentconfig) {
            this.extractEthernetSegmentProperties(parsedDefaultTargetData, ethernetSegmentconfig);
        }
        return parsedDefaultTargetData;
    }

    this.extractEthernetSegmentProperties = function(defaultTargetData, ethernetSegmentConfig)
    {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++) {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object') {
                let mappings = modelDeviceMapping.getMapping("ethernetsegment");
                this.traverseAndUpdateEthernetSegmentConfig(targetKey, targetObj, ethernetSegmentConfig, mappings);
            }
        }

        let portPointer = ethernetSegmentConfig["ethSegPortIdPointer"];
        let lagPointer = ethernetSegmentConfig["ethSegLagIdPointer"];

        defaultTargetData["ethernet-segment"]["association"]["type"] = "port";
        if(portPointer !== "")
        {
            let portArray = [{"port-id":""}];
            portArray[0]["port-id"] = ethernetSegmentConfig["ethSegAssociatedObjectName"].replace("Port ", "");
            defaultTargetData["ethernet-segment"]["association"]["port"] = portArray;
            defaultTargetData["ethernet-segment"]["association"]["lag"] = [];
        }
        else if (lagPointer !== "")
        {
            let lagArray = [{"lag-name":""}];
            lagArray[0]["lag-name"] = ethernetSegmentConfig["ethSegAssociatedObjectName"].split(" ")[1];
            defaultTargetData["ethernet-segment"]["association"]["lag"] = lagArray;
            defaultTargetData["ethernet-segment"]["association"]["port"] = [];
            defaultTargetData["ethernet-segment"]["association"]["type"] = "lag";
        }
        else
        {
            defaultTargetData["ethernet-segment"]["association"]["lag"] = [];
            defaultTargetData["ethernet-segment"]["association"]["port"] = [];
            defaultTargetData["ethernet-segment"]["association"]["type"] = "port";
        }
    }

    this.traverseAndUpdateEthernetSegmentConfig = function(objKey, obj, parsedDeviceConfig, mappings)
    {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (value != null && typeof value === 'object')
            {
                this.traverseAndUpdateEthernetSegmentConfig(mappedKey, value, parsedDeviceConfig, mappings);
            }
            else
            {
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
            }
        }
        return obj;
    }

    this.getAndUpdateFromDeviceConfig = function(mappings, mappedKey, targetKey, targetObj, parsedDeviceConfig) {
        // Get the key from mapping against targetKey
        // If the mapping key is not undefined, Get the value from deviceKey
        // if the value from deviceConfig against that mapping key is not n
        let nfmpKey = mappings[mappedKey];
        let deviceValue = parsedDeviceConfig[nfmpKey];

        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue, parsedDeviceConfig);

    }

    this.transformDeviceValue = function(mappedKey, deviceValue, parsedDeviceConfig) {
        if (deviceValue !== null) {
            switch (mappedKey)
            {
                case "ethernet-segment.multi-homing-mode":
                    deviceValue = this.transformMultiHomingMode(deviceValue);
                    break;
                case "ethernet-segment.admin-state":
                    deviceValue = this.transformAdminState(deviceValue);
                    break;
                case "ethernet-segment.df-election.es-activation-timer":
                    deviceValue = this.transformActivationTimer(deviceValue);
                    break;
                default:
            }
            return deviceValue;
        }
    }
    this.transformMultiHomingMode = function (deviceValue)
    {
        if(deviceValue === "disabled")
        {
            return "none"
        }
        else if(deviceValue === "singleActive")
        {
            return "single-active";
        }
        else if(deviceValue === "singleActiveNoEsiLabel")
        {
            return "single-active-no-esi-label";
        }
        else if(deviceValue === "allActive")
        {
            return "all-active";
        }
    }

    this.transformAdminState = function (deviceValue)
    {
        if(deviceValue === "enabled")
        {
            return "enable"
        }
        return "disable";
    }

    this.transformActivationTimer = function (deviceValue)
    {
        if(deviceValue == -1)
        {
            return undefined;
        }
        else
        {
            return deviceValue;
        }
    }

    this.constructSearchString = function(neId, name) {
        let filterExpression = "siteId='" + neId + "' AND ethSegEsName='" + name + "'";
        let jsonPayLoad = {
            "fullClassName": "svr.BgpEvpnEthernetSegment",
            "filter": {
                "filterExpression": filterExpression
            }
        };
        return jsonPayLoad;
    }
}
