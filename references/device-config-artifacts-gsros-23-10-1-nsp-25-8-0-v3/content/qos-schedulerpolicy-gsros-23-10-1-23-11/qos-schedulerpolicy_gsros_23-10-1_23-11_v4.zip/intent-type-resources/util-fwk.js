load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {

	this.setSuccessResult = function(result,savedTopology){
		result.setSuccess(true);
	    if (savedTopology !== undefined){
	      result.setTopology(savedTopology);
	    }
	    return result;
	}

	this.reportMisaligned = function(target, result, auditReport) {
		var report = JSON.parse(result.response);
		if (!report.aligned) {
			for (var i = 0; i < report.misalignedAttributes.length; i++) {
				var attributeData = report.misalignedAttributes[i];
                if (attributeData.expected == "present")
                {
                    //misaligned object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else if (attributeData.expected == "not present")
                {
                    //undesired object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
				var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
				auditReport.addMisAlignedAttribute(misalignedAttribute);
			}

            }
		}
		return auditReport
	}

	this.editPayload = function(fdn, properties, childProperties, fullClassName, objectFullName) {

		var payload = {};
		var configInfo = {};
		configInfo["containedClassProperties"] = properties;
		configInfo["containmentInfo"] = childProperties;
		configInfo["objectClassName"] = fullClassName;
		//payload["fdn"] = fdn;
		payload["distinguishedName"] = fdn;
		payload["objectFullName"] = objectFullName,
			payload["configInfo"] = configInfo;
		return payload;

	}

    /*
        function: isObjectExists
        description: To Check the Object exists or not.
   */
    this.isObjectExists = function(className, objectFullName)  {
        let nfmpFwk = new NfmpFwk();
        var ret = false;
        var searchObjectJson = {
            "fullClassName": className,
            "filter": {
                "filterExpression": "fullName='"+objectFullName+"'"
            }
        };
        var resultFetch = nfmpFwk.post("search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        if(Array.isArray(finalResponse))
        {
            ret = true;
        }
        return ret;
        }

    /*
       function: delay
       description: Sometimes the object creation takes time, we can use delay for child-level operation.
    */
      this.delay = function (milliseconds){
        var date = new Date();
        date.setMilliseconds(date.getMilliseconds() + milliseconds);
          while(new Date() < date){
        }
      }

    /*
      function: isInteger
      description: check if the passed number is integer or float
    */
      this.isInteger = function(num) {
        var regexPattern = /^-?[0-9]+$/;
        // check if the passed number is integer or float
        var result = regexPattern.test(num);
        return result;

    }

    this.modifyNeIdForIpV6 = function (objectFullName, neId) {
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }
}
