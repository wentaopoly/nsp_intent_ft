var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});

function NfmpAccessLag() {
    var util = new utilities();
    var mapFwk = new MapFwk();
    let nfmpFwk = new NfmpFwk();
    var parseTarget = new ParseTarget();
    var mdtfwk = new MdtFwk();

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        logger.info("input = \n" + input + "-------" + result + "-------" + intentTypeName + "-------" + initialPropertyName + "-------" + uniqueIdentifier);
        // code to handle delete
        if (input.getNetworkState().name() == "delete")
        {
            logger.info("Calling syncDelete");
            return this.syncDelete(input, result);
        }
        // code to handle sync
        var savedTopology = input.getCurrentTopology();
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        intentConfig["lag-id"] = input.getTarget().split("#")[3];
        intentConfig["lag-name"] = input.getTarget().split("#")[2];
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        this.createOrModify(neId, intentConfig);
        return util.setSuccessResult(result, savedTopology);
    }
    this.audit = function (target, config, svcTopo, adminState, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        logger.info("audit");
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        intentConfig["lag-id"] = target.split("#")[3];
        intentConfig["lag-name"] = target.split("#")[2];
        var neId = parseTarget.getNeIdFromTarget(target);
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        if (intentConfig)
        {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }

        return auditReport
    }
    this.auditAndCompare = function (neId, intentConfig, auditReport) {
        var lagInterfacePayLoad = this.createLagInterfacePayLoad(neId, intentConfig, true);
        var result = this.auditRequest(neId, lagInterfacePayLoad);
        auditReport = util.reportMisaligned(neId, result, auditReport);
        return auditReport;
    }

    this.auditRequest = function (neId, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.syncDelete = function (input, result) {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var lagId = input.getTarget().split("#")[3];
        var objectFullName = "network:" + neId + ":lag:interface-" + lagId;
        if (neId && String(neId).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        }
        logger.info("Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }
    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('input json: ' + json)
        return JSON.parse(json);
    }

    this.createOrModify = function (neId, intentConfig) {

        var lagInterfacePayLoad = this.createLagInterfacePayLoad(neId, intentConfig);
        var result = this.modifyRequest(neId, lagInterfacePayLoad);

        //send saperate request with admin state enable,
        //in NFMP modification of local and remote IPs ccannot be modified with adminState as enable
        if (intentConfig['bfd-liveness']['ipv4']['admin-state'] === 'enable')
        {
            var lagId = intentConfig["lag-id"];
            var fullClassName = "lag.BFDConfiguration";
            var fdn = "network:" + neId + ":lag:interface-" + lagId;
            if (neId && String(neId).indexOf(':') !== -1) {
                fdn = util.modifyNeIdForIpV6(fdn, neId);
            }
            var objectFullName = "network:" + neId + ":lag:interface-" + lagId + ":bfd-IPv4";
            if (neId && String(neId).indexOf(':') !== -1) {
                objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
            }
            var properties = {};
            var childProperties = [];
            properties['familyType'] = 'ipv4';
            properties["adiminState"] = util.convertAdminStateGreenField(intentConfig["bfd-liveness"]["ipv4"]["admin-state"]);
            var BFDPayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
            this.modifyRequest(neId, BFDPayload);
        }
        if (intentConfig['bfd-liveness']['ipv6']['admin-state'] === 'enable')
        {
            var lagId = intentConfig["lag-id"];
            var fullClassName = "lag.BFDConfiguration";
            var fdn = "network:" + neId + ":lag:interface-" + lagId;
            if (neId && String(neId).indexOf(':') !== -1) {
                fdn = util.modifyNeIdForIpV6(fdn, neId);
            }
            var objectFullName = "network:" + neId + ":lag:interface-" + lagId + ":bfd-IPv6";
            if (neId && String(neId).indexOf(':') !== -1) {
                objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
            }
            var properties = {};
            var childProperties = [];
            properties['familyType'] = 'ipv6';
            properties["adiminState"] = util.convertAdminStateGreenField(intentConfig["bfd-liveness"]["ipv6"]["admin-state"]);
            var BFDPayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
            this.modifyRequest(neId, BFDPayload);
        }

        return result;
    }
    this.createLagInterfacePayLoad = function (neId, intentConfig, isAudit) {
        var fullClassName = "lag.Interface";
        var fdn = "network:" + neId + ":lag";
        if (neId && String(neId).indexOf(':') !== -1) {
            fdn = util.modifyNeIdForIpV6(fdn, neId);
        }
        var lagId = intentConfig["lag-id"];
        var objectFullName = "network:" + neId + ":lag:interface-" + lagId;
        if (neId && String(neId).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        }
        var properties = {};
        properties["lagId"] = intentConfig["lag-id"];
        properties["lagNameId"] = intentConfig["lag-name"];
        properties["description"] = intentConfig["description"];
        properties["administrativeState"] = util.convertToNfmpAdminstarteState(intentConfig["admin-state"]);
        properties["mode"] = intentConfig["mode"];
        properties["lagPortType"] = intentConfig["port-type"];
        if (intentConfig["mode"] != "network")
        {
            if (properties["lagPortType"] === "hs")
            {
                //adaptQoS on NFMP must be link when port type is HS
                properties["adaptQoS"] = "link";
            }
        }
        properties["encapType"] = util.convertToNfmpEncapType(intentConfig["encap-type"]);

        properties["perLinkHashing"] = Boolean(intentConfig["per-link-hash"]["enablePerLinkHash"]);
        if (properties["perLinkHashing"])
        {
            //adaptQoS on NFMP must be link when perLinkHash is enabled
            if (intentConfig["mode"] != "network")
            {
                properties["adaptQoS"] = "link";
            }
            properties["perLinkHashWeighted"] = Boolean(intentConfig["per-link-hash"]["weighted"]["enableWeighted"]);
            if (properties["perLinkHashWeighted"])
            {
                properties["autoRebalance"] = Boolean(intentConfig["per-link-hash"]["weighted"]["auto-rebalance"]);
            }
            else
            {
                properties["autoRebalance"] = false;
            }
        }
        else
        {
            properties["perLinkHashWeighted"] = false;
            properties["autoRebalance"] = false;
        }
        if (intentConfig["port-threshold"])
        {
            properties["portThreshold"] = intentConfig["port-threshold"]["value"];
            properties["portThresholdAction"] = util.convertToNfmpportThresholdAction(intentConfig["port-threshold"]["action"]);
            if (properties["portThresholdAction"] == "staticCost")
            {
                properties["portThresholdStaticCost"] = intentConfig["port-threshold"]["cost"];
            }
            else
            {
                properties["portThresholdStaticCost"] = 0;
            }
        }
        var childProperties = [];
        //create lacp payload
        var lacpPayload = this.createLacpPayLoad(neId, intentConfig)
        childProperties.push(lacpPayload);

        //create member payload
        if (intentConfig["port"])
        {
            if (!Array.isArray(intentConfig["port"]))
            {
                intentConfig["port"] = [intentConfig["port"]];
            }
            for (var index in intentConfig["port"])
            {
                var intentMemberConfig = intentConfig["port"][index];
                var memberPayload = this.createMemberPayLoad(neId, intentMemberConfig)
                childProperties.push(memberPayload);
            }
        }
        //create BFDIpv4 payload
        var bfdIpv4Payload = this.createBFDIpv4Payload(neId, intentConfig, isAudit)
        childProperties.push(bfdIpv4Payload);
        //create BFDIpv6 payload
        var nodeType = mdtfwk.getTypeAndVersion(neId);
        var deviceType = util.getIxrType(neId);
        if (nodeType["type"] === "7750 SR" || nodeType["type"] === "7450 ESS" || nodeType["type"] === "7950 XRS" || deviceType["type"].startsWith("7250 IXR-x") || intentConfig["bfd-liveness"]["ipv6"])
        {
            var bfdIpv6Payload = this.createBFDIpv6Payload(neId, intentConfig, isAudit)
            childProperties.push(bfdIpv6Payload);
        }
        var lagPayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
        return lagPayload;
    }
    this.createLacpPayLoad = function (neId, intentConfig) {
        var fullClassName = "lag.LacpConfiguration";
        var lacpIntentConfig = intentConfig["lacp"];
        var properties = {};
        properties["lacpTransmitInterval"] = intentConfig["lacp-xmit-interval"];
        properties["lacpXmitStdby"] = intentConfig["lacp-xmit-stdby"];
        properties["administrativeState"] = lacpIntentConfig["enableLacp"];
        if (lacpIntentConfig && lacpIntentConfig["enableLacp"])
        {
            properties["lacpMode"] = lacpIntentConfig["mode"];
            properties["actorAdminKey"] = lacpIntentConfig["administrative-key"];
            if(lacpIntentConfig["system-id"])
            {
                properties["lagSystemId"] = lacpIntentConfig["system-id"] ? util.convertToNfmpsystemId(lacpIntentConfig["system-id"]) : lacpIntentConfig["system-id"];
            }
            properties["lagSystemPriority"] = lacpIntentConfig["system-priority"];
        }
        return this.createChildObjectPayload(fullClassName, properties);
    }

    this.createBFDIpv4Payload = function (neId, intentConfig, isAudit) {
        var fullClassName = "lag.BFDConfiguration";
        var properties = {};
        var ipv4Info = intentConfig["bfd-liveness"]["ipv4"];
        properties['familyType'] = 'ipv4';
        if (ipv4Info)
        {
            if (isAudit)
            {
                properties["adiminState"] = util.convertAdminStateGreenField(ipv4Info["admin-state"]);
            }
            else
            {
                properties["adiminState"] = 'disabled';
            }
            properties["localIP"] = ipv4Info["local-ip-address"];
            properties["remoteIP"] = ipv4Info["remote-ip-address"];
            properties["receiveInterval"] = ipv4Info["receive-interval"];
            properties["transmitInterval"] = ipv4Info["transmit-interval"];
            if (ipv4Info["max-admin-down-time"] === "infinite") {
                properties["maxAdminDownTime"] = -1;
            } else {
                properties["maxAdminDownTime"] = ipv4Info["max-admin-down-time"];
            }
            if (ipv4Info["max-setup-time"] === "infinite") {
                properties["maxSetupTime"] = -1;
            } else {
                properties["maxSetupTime"] = ipv4Info["max-setup-time"];
            }
            if (ipv4Info["multiplier"]) {
                properties["multiplier"] = ipv4Info["multiplier"];
            }
        }
        return this.createChildObjectPayload(fullClassName, properties);
    }
    this.createBFDIpv6Payload = function (neId, intentConfig, isAudit) {
        var fullClassName = "lag.BFDConfiguration";
        var properties = {};
        var ipv6Info = intentConfig["bfd-liveness"]["ipv6"];
        properties['familyType'] = 'ipv6';
        if (ipv6Info)
        {
            if (isAudit)
            {
                properties["adiminState"] = util.convertAdminStateGreenField(ipv6Info["admin-state"]);
            }
            else
            {
                properties["adiminState"] = 'disabled';
            }
            if (ipv6Info["local-ip-address"] != undefined)
            {
                properties["localIP"] = util.expandIPv6Address(ipv6Info["local-ip-address"]);
            }
            if (ipv6Info["remote-ip-address"] != undefined)
            {
                properties["remoteIP"] = util.expandIPv6Address(ipv6Info["remote-ip-address"]);
            }
            properties["receiveInterval"] = ipv6Info["receive-interval"];
            properties["transmitInterval"] = ipv6Info["transmit-interval"];
            if (ipv6Info["max-admin-down-time"] === "infinite") {
                properties["maxAdminDownTime"] = -1;
            } else {
                properties["maxAdminDownTime"] = ipv6Info["max-admin-down-time"];
            }
            if (ipv6Info["max-setup-time"] === "infinite") {
                properties["maxSetupTime"] = -1;
            } else {
                properties["maxSetupTime"] = ipv6Info["max-setup-time"];
            }
            if (ipv6Info["multiplier"]) {
                properties["multiplier"] = ipv6Info["multiplier"];
            }
        }
        return this.createChildObjectPayload(fullClassName, properties);
    }
    this.createMemberPayLoad = function (neId, intentMemberConfig) {
        var fullClassName = "lag.PortTermination";
        var properties = {};
        if (intentMemberConfig)
        {
            properties["memberName"] = intentMemberConfig["port-id"];
            properties["portPointer"] = util.getBaseFdnForPort(neId, intentMemberConfig["port-id"]);
            properties["priority"] = intentMemberConfig["priority"];
            properties["subGroupId"] = util.convertSubGroupGreenField(intentMemberConfig["sub-group"]);
            properties["hashWeight"] = intentMemberConfig["hash-weight"];
        }
        return this.createChildObjectPayload(fullClassName, properties);
    }
    this.createChildObjectPayload = function (fullClassName, properties) {

        var childObjectPayLoad = {};
        childObjectPayLoad['objectClassName'] = fullClassName;
        childObjectPayLoad['containedClassProperties'] = properties;
        return childObjectPayLoad;

    }

    this.modifyRequest = function (neId, payload) {
        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }
}
