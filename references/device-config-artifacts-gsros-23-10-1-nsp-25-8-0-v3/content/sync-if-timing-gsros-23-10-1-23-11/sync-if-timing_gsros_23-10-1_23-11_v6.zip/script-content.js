var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};


load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource('nsp-restconf-fwk.js'), name: 'nsp-restconf-fwk'});
var nspRestconfFwk = new NspRestconfFwk();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

var intentTypeName = 'sync-if-timing_gsros_23-10-1_23-11';

// example port, sap-ingress etc..
var initialPropertyName = 'central-frequency-clock';


// unique identifier
var uniqueIdentifier = 'timing';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/system';

function synchronize(input) {
    logger.info('Intent Synchronisation started')

    return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started')

    return NspIntentHelper.audit(target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function suggestPortIds(context) {
    //var ret;
    logger.info("suggestPortIds =>\n" + context)
    try
    {
        var neId;
        var target = context.getInputValues()["target"]["objectidentifier"];
        logger.info(target)
        if (target)
        {

            if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
            {
                neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
            }
            else
            {
                neId = target;
            }
        }
        else
        {
            neId = context.getInputValues()["arguments"]["__parent"]["target_objectidentifier"];
        }
        logger.info("listing ports for NeId : " + neId);

        ret = nspRestconfFwk.getPorts(neId);
    } catch (e)
    {
        logger.error(" " + e.message);
    }
    return ret;
}

function suggestTiming(context) {
    logger.info("suggestTiming =>\n" + context)
    return ["timing"];
}

function getTargetData(input) {
    logger.info("getTargetData input for brownfield = \n" + input);
    var target = input.target;
    var config = null;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info(JSON.stringify(deviceConfig));
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}

