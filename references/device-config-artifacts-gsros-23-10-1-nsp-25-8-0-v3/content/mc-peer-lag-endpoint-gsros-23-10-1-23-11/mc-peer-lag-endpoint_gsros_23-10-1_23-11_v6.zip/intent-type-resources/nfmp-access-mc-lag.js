var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpAccessMcLag() {

    var util = new utilities();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var savedTopology;
    var mcGrpSaveTopology = [];
    var mcRingGrpSaveTopology = [];
    var mcSyncGrpSaveTopology = [];
    var vlanEntrySaveTopology = [];
    var isAudit = false;
    var auditResult = {};

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, topologyInfo) {
        logger.info("input = \n" + input + "-------" + result + "-------" + intentTypeName + "-------" + initialPropertyName + "-------" + uniqueIdentifier);
        // code to handle delete
        if (input.getNetworkState().name() == "delete")
        {
            logger.info("Calling syncDelete");
            return this.syncDelete(input, result);
        }
        // code to handle sync
        savedTopology = input.getCurrentTopology();
        if(savedTopology!=null && savedTopology.getXtraInfo().length) {
            for (var index in savedTopology.getXtraInfo())
            {
                var xtraInfo = savedTopology.getXtraInfo()[index].getKey();
                if (xtraInfo && typeof xtraInfo === 'string' && xtraInfo.startsWith("mcring-group-manager:mc-ring-group-")) {
                    mcRingGrpSaveTopology.push(xtraInfo);
                }
                if (xtraInfo && typeof xtraInfo === 'string' && xtraInfo.startsWith("mc-sync-manager:mc-sync-")) {
                    mcSyncGrpSaveTopology.push(xtraInfo);
                }
                if (xtraInfo && typeof xtraInfo === 'string' && xtraInfo.indexOf(":synch:port-") > -1) {
                    vlanEntrySaveTopology.push(xtraInfo);
                }
            }
        }
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        intentConfig["firstSiteId"] = input.getTarget().split("#")[2];
        intentConfig["firstSiteSourceIpAddress"] = input.getTarget().split("#")[3];
        intentConfig["secondSiteId"] = input.getTarget().split("#")[4];
        intentConfig["endpointB-interfaceAddress"] = input.getTarget().split("#")[5];
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        this.createOrModify(neId, intentConfig);
        result.setTopology(savedTopology);
        result.getTopology().setXtraInfo(savedTopology.getXtraInfo());
        return util.setSuccessResult(result, savedTopology);
    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('input json: ' + json)
        return JSON.parse(json);
    }

    this.createOrModify = function (neId, intentConfig) {
        var deviceType = util.getIxrType(neId);
        var deviceTypeB = util.getIxrType(intentConfig["secondSiteId"]);
        this.createMcPeerPayLoad(neId, intentConfig, false);
        this.createMcLagPeerSpecificsPayLoad(neId, intentConfig);
        if(!deviceType["type"].startsWith("7250 IXR") && !deviceType["type"].startsWith("7705 SAR"))
        {
            this.createMcLagPayLoad(neId, intentConfig);
            this.createMcEndPointPayLoad(neId, intentConfig);
        }
        if( !deviceType["type"].startsWith("7250 IXR") && !deviceType["type"].startsWith("7750-SRa4") && !deviceType["type"].startsWith("7750-SRa8") && !deviceType["type"].startsWith("7950 XRS") && !deviceType["type"].startsWith("7950-XRS") && !deviceType["type"].startsWith("7750 SAR") &&
            !deviceTypeB["type"].startsWith("7250 IXR") && !deviceTypeB["type"].startsWith("7750-SRa4") && !deviceTypeB["type"].startsWith("7750-SRa8") && !deviceTypeB["type"].startsWith("7950 XRS") && !deviceTypeB["type"].startsWith("7950-XRS") && !deviceTypeB["type"].startsWith("7750 SAR")){
            this.createMcPeerIpsecPayLoad(neId, intentConfig);
            this.createMcIpsecGrpPayLoad(neId, intentConfig);
        }
        this.createMcSyncGrpPayload(neId, intentConfig);
        this.createMcRingGrpPayload(neId, intentConfig);
        this.createMcPeerPayLoad(neId, intentConfig, true);
    }

    this.createMcPeerPayLoad = function (neId, intentConfig, includeSyncAdminState) {
        var fullClassName = "multichassis.MultiChassisPeer";
        var endpointAsiteId = intentConfig["firstSiteId"];
        var endpointAInterfaceAddress = intentConfig["firstSiteSourceIpAddress"];
        var endpointBsiteId = intentConfig["secondSiteId"];
        var endpointBInterfaceAddress = intentConfig["endpointB-interfaceAddress"];
        var fdn = "sam-mc-peer-manager";
        var objectFullName = "sam-mc-peer-manager:mc-peer-" + endpointAInterfaceAddress + "-" + endpointBInterfaceAddress;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, endpointAInterfaceAddress, endpointBInterfaceAddress);
        var properties = {};
        properties["firstSiteId"] = endpointAsiteId;
        //properties["firstSitePointer"] = "network:" + endpointAsiteId;
        if (endpointAsiteId.indexOf(":") !== -1) {
            properties["firstSiteIpAddressType"] = "ipv6";
         } else {
            properties["firstSiteIpAddressType"] = "ipv4";
         }
         properties["firstSiteSourceIpAddress"] = endpointAInterfaceAddress;
         if (endpointAInterfaceAddress.indexOf(":") !== -1) {
            properties["firstSiteSourceIpAddressType"] = "ipv6";
         } else {
            properties["firstSiteSourceIpAddressType"] = "ipv4";
         }
        if (intentConfig["endPointADetails"]["peer-name"])
        {
            properties["firstSitePeerName"] = (intentConfig["endPointADetails"]["peer-name"]).toString();
        }
        if (intentConfig["endPointADetails"]["description"])
        {
            properties["firstSiteDescription"] = (intentConfig["endPointADetails"]["description"]).toString();
        }
        if (!isAudit)
        {
            properties["firstSiteAuthenticationKey"] = intentConfig["endPointADetails"]["authentication-key"];
        }
        properties["firstSiteAdministrativeState"] = util.convertToNfmpAdminstarteState(intentConfig["endPointADetails"]["admin-state"]);
        properties["firstSiteWarmStandby"] = intentConfig["endPointADetails"]["warm-standby"];
        properties["igmp"] = intentConfig["sync"]["igmp"];
        properties["igmpSnooping"] = intentConfig["sync"]["igmpSnooping"];
        properties["subscriberManagement"] = intentConfig["sync"]["subscriberManagement"];
        properties["subscriberManagementPPPoE"] = intentConfig["sync"]["subscriberManagementPPPoE"];
        properties["srrp"] = intentConfig["sync"]["srrp"];
        properties["mcRing"] = intentConfig["sync"]["mcRing"];
        properties["mcMld"] = intentConfig["sync"]["mcMld"];
        properties["mldSnooping"] = intentConfig["sync"]["mldSnooping"];
        //bits-type
        if(intentConfig["sync"]["mcPimSnooping"])
        {
            var bits = intentConfig["sync"]["mcPimSnooping"].split(" ");
            properties["mcPimSnooping"] = (bits.length > 1 && !isAudit) ? {"bit": bits} : bits;
        } else {
            properties["mcPimSnooping"] = "";
        }
        properties["subscriberHostTracking"] = intentConfig["sync"]["subscriberHostTracking"];
        properties["mcIPSec"] = intentConfig["sync"]["mcIPSec"];
        properties["mcDhcpServer"] = intentConfig["sync"]["mcDhcpServer"];
        properties["mcPythonCache"] = intentConfig["sync"]["mcPythonCache"];
        properties["mcDiameterProxy"] = intentConfig["sync"]["mcDiameterProxy"];
        properties["mcL2tp"] = intentConfig["sync"]["mcL2tp"];
        properties["mcKeyChainName"] = (intentConfig["sync"]["mcKeyChainName"])?"KeyChain:"+intentConfig["sync"]["mcKeyChainName"]:"";
        properties["secondSiteId"] = endpointBsiteId;
        //properties["secondSitePointer"] = "network:" + endpointBsiteId;
        if (endpointBsiteId.indexOf(":") !== -1) {
            properties["secondSiteIpAddressType"] = "ipv6";
        } else {
            properties["secondSiteIpAddressType"] = "ipv4";
        }
        properties["secondSiteSourceIpAddress"] = endpointBInterfaceAddress;
        if (endpointBInterfaceAddress.indexOf(":") !== -1) {
            properties["secondSiteSourceIpAddressType"] = "ipv6";
        } else {
            properties["secondSiteSourceIpAddressType"] = "ipv4";
        }
        if (intentConfig["endPointBDetails"]["peer-name"])
        {
            properties["secondSitePeerName"] = (intentConfig["endPointBDetails"]["peer-name"]).toString();
        }
        if (intentConfig["endPointBDetails"]["description"])
        {
            properties["secondSiteDescription"] = (intentConfig["endPointBDetails"]["description"]).toString();
        }
        if (!isAudit)
        {
            properties["secondSiteAuthenticationKey"] = intentConfig["endPointBDetails"]["authentication-key"];
        }
        properties["secondSiteAdministrativeState"] = util.convertToNfmpAdminstarteState(intentConfig["endPointBDetails"]["admin-state"]);
        properties["secondSiteWarmStandby"] = intentConfig["endPointBDetails"]["warm-standby"];

        if(includeSyncAdminState)
        {
            if(intentConfig["sync"]["admin-state"] == "enable")
            {
                properties["commonSyncAdminState"] = "tmnxInService";
            }
            else
            {
                properties["commonSyncAdminState"] = "tmnxOutOfService";
            }
        }
        if(intentConfig["enable-mc-ipsec"])
        {
            properties["enableMcIPSec"] = "true";
        }
        else
        {
            properties["enableMcIPSec"] = "false";
        }
        var childProperties = {};
        var mcPeerPayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
        if (!isAudit)
        {
            logger.info("Sending the modify request for MC Peer");
            this.modifyRequest(neId, mcPeerPayload);
        }
        else
        {
            logger.info("Sending the audit request for MC Peer");
            this.updateAuditResult(this.auditRequest(neId, mcPeerPayload));

        }
    }

    this.createMcLagPeerSpecificsPayLoad = function (neId, intentConfig) {
        var fullClassName = "multichassis.MultiChassisLagPeerSpecifics";
        var endpointAsiteId = intentConfig["firstSiteId"];
        var endpointAInterfaceAddress = intentConfig["firstSiteSourceIpAddress"];
        var endpointBsiteId = intentConfig["secondSiteId"];
        var endpointBInterfaceAddress = intentConfig["endpointB-interfaceAddress"];

        var endpointAfdn = "network" + endpointAsiteId + ":mc-peer-manager:peer-" + endpointBInterfaceAddress;
        endpointAfdn = util.modifyNeIdForIpV6(endpointAfdn, endpointAsiteId, endpointBInterfaceAddress);
        var endpointBfdn = "network" + endpointBsiteId + ":mc-peer-manager:peer-" + endpointAInterfaceAddress;
        endpointBfdn = util.modifyNeIdForIpV6(endpointBfdn, endpointBsiteId, endpointAInterfaceAddress);
        var endPointAObjectFullName = "network:" + endpointAsiteId + ":mc-peer-manager:peer-" + endpointBInterfaceAddress + ":mc-lag-spec";
        endPointAObjectFullName = util.modifyNeIdForIpV6(endPointAObjectFullName, endpointAsiteId, endpointBInterfaceAddress);
        var endPointBObjectFullName = "network:" + endpointBsiteId + ":mc-peer-manager:peer-" + endpointAInterfaceAddress + ":mc-lag-spec";
        endPointBObjectFullName = util.modifyNeIdForIpV6(endPointBObjectFullName, endpointBsiteId, endpointAInterfaceAddress);

        var endPointAProperties = {};
        endPointAProperties["keepAliveInterval"] = intentConfig["mc-lag"]["endPointADetails"]["keep-alive-interval"];
        endPointAProperties["holdOnNeighborFailure"] = intentConfig["mc-lag"]["endPointADetails"]["hold-on-neighbor-failure"];
        endPointAProperties["administrativeState"] = util.convertToNfmpAdminstarteState(intentConfig["mc-lag"]["endPointADetails"]["admin-state"]);

        var endPointAchildProperties = {};
        var endpointAMcLagPeerSpecificsPayload = util.editPayload(endpointAfdn, endPointAProperties, endPointAchildProperties, fullClassName, endPointAObjectFullName);
        if (!isAudit)
        {
            logger.info("Sending the modify request for Endpoint A MC Lag Peer Specifics");
            this.modifyRequest(neId, endpointAMcLagPeerSpecificsPayload);
        }
        else
        {
            logger.info("Sending the audit request for Endpoint A MC Lag Peer Specifics");
            this.updateAuditResult(this.auditRequest(neId, endpointAMcLagPeerSpecificsPayload));
        }

        var endPointBProperties = {};
        endPointBProperties["keepAliveInterval"] = intentConfig["mc-lag"]["endPointBDetails"]["keep-alive-interval"];
        endPointBProperties["holdOnNeighborFailure"] = intentConfig["mc-lag"]["endPointBDetails"]["hold-on-neighbor-failure"];
        endPointBProperties["administrativeState"] = util.convertToNfmpAdminstarteState(intentConfig["mc-lag"]["endPointBDetails"]["admin-state"]);

        var endPointBchildProperties = {};
        var endpointBMcLagPeerSpecificsPayload = util.editPayload(endpointBfdn, endPointBProperties, endPointBchildProperties, fullClassName, endPointBObjectFullName);
        if (!isAudit)
        {
            logger.info("Sending the modify request for Endpoint B MC Lag Peer Specifics");
            this.modifyRequest(neId, endpointBMcLagPeerSpecificsPayload);
        }
        else
        {
            logger.info("Sending the audit request for Endpoint B MC Lag Peer Specifics");
            this.updateAuditResult(this.auditRequest(neId, endpointBMcLagPeerSpecificsPayload));
        }
    }

    this.createMcLagPayLoad = function (neId, intentConfig) {
        if (savedTopology == null)
        {
            logger.info("Creating mc-lag topology");
            savedTopology = topologyFactory.createServiceTopology();
        }
        if (intentConfig["mc-lag"]["lag"])
        {
            if (!Array.isArray(intentConfig["mc-lag"]["lag"]))
            {
                intentConfig["mc-lag"]["lag"] = [intentConfig["mc-lag"]["lag"]];
            }
            var endpointAsiteId = intentConfig["firstSiteId"];
            var endpointAInterfaceAddress = intentConfig["firstSiteSourceIpAddress"];
            var endpointBsiteId = intentConfig["secondSiteId"];
            var endpointBInterfaceAddress = intentConfig["endpointB-interfaceAddress"];


            var intentlength = intentConfig["mc-lag"]["lag"].length;
            var XtraInfolength = savedTopology.getXtraInfo().length;

            var mcLagToBeDeleted = [];
            mcGrpSaveTopology = [];
            if (XtraInfolength > intentlength)
            {
                for (var index in savedTopology.getXtraInfo())
                {
                    var xtraInfo = savedTopology.getXtraInfo()[index].getKey();
                    var deleteFlag = true;

                    for (var index in intentConfig["mc-lag"]["lag"])
                    {
                        var intentMcLag = intentConfig["mc-lag"]["lag"][index];
                        var endpointALagId = intentMcLag["lag-name"];
                        var endpointBLagId = intentMcLag["remote-lag"];
                        var objectFullName = "mc-lag-mgr:mclag-" + endpointAInterfaceAddress + "-" + endpointALagId + "-" + endpointBInterfaceAddress + "-" + endpointBLagId;
                        objectFullName = util.modifyNeIdForIpV6(objectFullName, endpointAInterfaceAddress, endpointBInterfaceAddress);

                        if (xtraInfo == objectFullName)
                        {
                            deleteFlag = false;
                            break;
                        }
                    }
                    if (xtraInfo && typeof xtraInfo === 'string' && xtraInfo.startsWith("ipsecMgr:mcIPsec-")) {
                        mcGrpSaveTopology.push(xtraInfo);
                    }
                    if (deleteFlag && xtraInfo.startsWith("mc-lag-mgr:mclag-")) {
                        mcLagToBeDeleted.push(xtraInfo);
                    }
                }
            }
            for (var index in mcLagToBeDeleted)
            {
                this.syncDeleteMcLag(mcLagToBeDeleted[index]);
            }

            savedTopology.setXtraInfo([]);
            for (var index in intentConfig["mc-lag"]["lag"])
            {
                var intentMcLagConfig = intentConfig["mc-lag"]["lag"][index];

                var fullClassName = "multichassis.MultiChassisLag";
                var fdn = "mc-lag-mgr";
                var endpointALagId = intentMcLagConfig["lag-name"];
                var endpointBLagId = intentMcLagConfig["remote-lag"];
                var objectFullName = "mc-lag-mgr:mclag-" + endpointAInterfaceAddress + "-" + endpointALagId + "-" + endpointBInterfaceAddress + "-" + endpointBLagId;
                objectFullName = util.modifyNeIdForIpV6(objectFullName, endpointAInterfaceAddress, endpointBInterfaceAddress);

                var entry = topologyFactory.createTopologyXtraInfoFrom(objectFullName, JSON.stringify(intentMcLagConfig));
                savedTopology.addXtraInfo(entry);

                var properties = {};
                if (intentMcLagConfig)
                {
                    properties["lacpKey"] = intentMcLagConfig["lacp-key"];
                    properties["systemId"] = util.convertToNfmpsystemId(intentMcLagConfig["system-id"]);
                    properties["systemPriority"] = intentMcLagConfig["system-priority"];
                    if(intentMcLagConfig["source-bmac-lsb"] == 'use-lacp-key')
                    {
                        properties["srcBMacLsbUseLacpKey"] = true;
                        properties["srcBMacLSB"] = "FF-FF-FF-FF";
                    }
                    else
                    {
                        properties["srcBMacLsbUseLacpKey"] = false;
                        properties["srcBMacLSB"] = intentMcLagConfig["source-bmac-lsb"];
                    }

                    properties["firstIpAddress"] = endpointAInterfaceAddress;
                    //properties["firstSitePointer"] = "network:" + endpointAsiteId;
                    if (endpointAInterfaceAddress.indexOf(":") !== -1) {
                        properties["firstIpAddressType"] = "ipv6";
                    } else {
                        properties["firstIpAddressType"] = "ipv4";
                    }
                    //properties["firstLagId"] = intentMcLagConfig["lag-name"];
                    var firstLagPointer = "network:" + endpointAsiteId + ":lag:interface-" + intentMcLagConfig["lag-name"];
                    properties["firstLagInterfacePointer"] = util.modifyNeIdForIpV6(firstLagPointer, endpointAsiteId);

                    properties["secondIpAddress"] = endpointBInterfaceAddress;
                   if (endpointBInterfaceAddress.indexOf(":") !== -1) {
                        properties["secondIpAddressType"] = "ipv6";
                    } else {
                        properties["secondIpAddressType"] = "ipv4";
                    }
                    //properties["secondLagId"] = intentMcLagConfig["remote-lag"];
                    var secondLagPointer = "network:" + endpointBsiteId + ":lag:interface-" + intentMcLagConfig["remote-lag"];
                    properties["secondLagInterfacePointer"] = util.modifyNeIdForIpV6(secondLagPointer, endpointBsiteId);

                    var childProperties = {};
                    var mcLagPayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
                    if (!isAudit)
                    {
                        logger.info("Sending the modify request for MC Lag");
                        this.modifyRequest(neId, mcLagPayload);
                    }
                    else
                    {
                        logger.info("Sending the audit request for MC Lag");
                        this.updateAuditResult(this.auditRequest(neId, mcLagPayload));
                    }
                }
            }
        }
    }

    this.createMcEndPointPayLoad = function (neId, intentConfig) {
        let fullClassName = "multichassis.McEndpointGroup";
        let endpointAsiteId = intentConfig["firstSiteId"];
        let endpointAInterfaceAddress = intentConfig["firstSiteSourceIpAddress"];
        let endpointBsiteId = intentConfig["secondSiteId"];
        let endpointBInterfaceAddress = intentConfig["endpointB-interfaceAddress"];

        let mcEndPointFdn = "mcEpMgr";
        let mcEndPointObjectFullName = "mcEpMgr:mcEpGrp-first-"+endpointAInterfaceAddress+"-second-"+endpointBInterfaceAddress;
        mcEndPointObjectFullName = util.modifyNeIdForIpV6(mcEndPointObjectFullName, endpointAInterfaceAddress, endpointBInterfaceAddress);

        if(intentConfig["enable-mc-endpoint"])
        {
            let mcEndPointProperties = {};
            mcEndPointProperties["description"] = intentConfig["mc-endpoint"]["description"];

            //mcEndPointProperties["firstPeerPointer"] = "network:"+endpointAsiteId+":mc-peer-manager:peer-"+endpointBInterfaceAddress;
            mcEndPointProperties["firstSiteSourceIpAddress"] = endpointAInterfaceAddress;
            mcEndPointProperties["firstSiteAdministrativeState"] = util.convertToNfmpAdminstarteState(intentConfig["mc-endpoint"]["endPointADetails"]["admin-state"]);
            mcEndPointProperties["firstSiteKeepAliveInterval"] = intentConfig["mc-endpoint"]["endPointADetails"]["keep-alive-interval"];
            mcEndPointProperties["firstSitePassiveMode"] = intentConfig["mc-endpoint"]["endPointADetails"]["passive-mode"];
            mcEndPointProperties["firstSiteSystemPriority"] = intentConfig["mc-endpoint"]["endPointADetails"]["system-priority"];
            mcEndPointProperties["firstSiteBfdEnabled"] = intentConfig["mc-endpoint"]["endPointADetails"]["bfd"];
            mcEndPointProperties["firstSiteHoldOnNeighborFailure"] = intentConfig["mc-endpoint"]["endPointADetails"]["hold-on-neighbor-failure"];
            mcEndPointProperties["firstSiteBootTimer"] = intentConfig["mc-endpoint"]["endPointADetails"]["boot-timer"];

            //mcEndPointProperties["secondPeerPointer"] = "network:"+endpointBsiteId+":mc-peer-manager:peer-"+endpointAInterfaceAddress;
            mcEndPointProperties["secondSiteSourceIpAddress"] = endpointBInterfaceAddress;
            mcEndPointProperties["secondSiteAdministrativeState"] = util.convertToNfmpAdminstarteState(intentConfig["mc-endpoint"]["endPointBDetails"]["admin-state"]);
            mcEndPointProperties["secondSiteKeepAliveInterval"] = intentConfig["mc-endpoint"]["endPointBDetails"]["keep-alive-interval"];
            mcEndPointProperties["secondSitePassiveMode"] = intentConfig["mc-endpoint"]["endPointBDetails"]["passive-mode"];
            mcEndPointProperties["secondSiteSystemPriority"] = intentConfig["mc-endpoint"]["endPointBDetails"]["system-priority"];
            mcEndPointProperties["secondSiteBfdEnabled"] = intentConfig["mc-endpoint"]["endPointBDetails"]["bfd"];
            mcEndPointProperties["secondSiteHoldOnNeighborFailure"] = intentConfig["mc-endpoint"]["endPointBDetails"]["hold-on-neighbor-failure"];
            mcEndPointProperties["secondSiteBootTimer"] = intentConfig["mc-endpoint"]["endPointBDetails"]["boot-timer"];

            let mcEndPointchildProperties = {};
            let mcEndpointPayload = util.editPayload(mcEndPointFdn, mcEndPointProperties, mcEndPointchildProperties, fullClassName, mcEndPointObjectFullName);
            if (!isAudit)
            {
                logger.info("Sending the modify request for MC Endpoint");
                this.modifyRequest(neId, mcEndpointPayload);
            }
            else
            {
                logger.info("Sending the audit request for MC Endpoint");
                this.updateAuditResult(this.auditRequest(neId, mcEndpointPayload));
            }
        }
        else
        {
            this.syncDeleteMcEndpoint(mcEndPointObjectFullName);
        }
    }

    this.createMcPeerIpsecPayLoad = function(neId, intentConfig) {
        var fullClassName = "multichassis.McPeerIPSec";
        var endpointAsiteId = intentConfig["firstSiteId"];
        var endpointAInterfaceAddress = intentConfig["firstSiteSourceIpAddress"];
        var endpointBsiteId = intentConfig["secondSiteId"];
        var endpointBInterfaceAddress = intentConfig["endpointB-interfaceAddress"];

        var endpointAfdn = "network:" + endpointAsiteId + ":mc-peer-manager:peer-" + endpointBInterfaceAddress;
        endpointAfdn = util.modifyNeIdForIpV6(endpointAfdn, endpointAsiteId, endpointBInterfaceAddress);
        var endpointBfdn = "network:" + endpointBsiteId + ":mc-peer-manager:peer-" + endpointAInterfaceAddress;
        endpointBfdn = util.modifyNeIdForIpV6(endpointBfdn, endpointBsiteId, endpointAInterfaceAddress);
        var endPointAObjectFullName = "network:" + endpointAsiteId + ":mc-peer-manager:peer-" + endpointBInterfaceAddress + ":mcIPsec";
        endPointAObjectFullName = util.modifyNeIdForIpV6(endPointAObjectFullName, endpointAsiteId, endpointBInterfaceAddress);
        var endPointBObjectFullName = "network:" + endpointBsiteId + ":mc-peer-manager:peer-" + endpointAInterfaceAddress + ":mcIPsec";
        endPointBObjectFullName = util.modifyNeIdForIpV6(endPointBObjectFullName, endpointBsiteId, endpointAInterfaceAddress);

        var endPointAProperties = {};
        endPointAProperties["bfdEnable"] = intentConfig["mc-ipsec"]["endPointADetails"]["bfd-liveness"];
        endPointAProperties["keepAliveInterval"] = intentConfig["mc-ipsec"]["endPointADetails"]["keep-alive-interval"];
        endPointAProperties["holdOnNeighborFailure"] = intentConfig["mc-ipsec"]["endPointADetails"]["hold-on-neighbor-failure"];
        endPointAProperties["discoveryInterval"] = intentConfig["mc-ipsec"]["endPointADetails"]["discovery-interval"]["interval-secs"];
        endPointAProperties["discoveryIntervalBoot"] = intentConfig["mc-ipsec"]["endPointADetails"]["discovery-interval"]["boot"];

        var childPropertiesA = {};
        var endpointADomainPayload = [];
        let domainAData = intentConfig["mc-ipsec"] && intentConfig["mc-ipsec"]["endPointADetails"] && intentConfig["mc-ipsec"]["endPointADetails"]["domain"];
        if (domainAData) {
            if (!Array.isArray(domainAData)) {
                domainAData = [domainAData];
            }
            for (var index in domainAData) {
                var intentDomainAConfig = domainAData[index];
                var domainAPayload = this.createMcPeerIPSecDomainPayLoad(intentDomainAConfig);
                endpointADomainPayload.push(domainAPayload);
            }
            childPropertiesA["multichassis.McPeerIPSecDomain"] = endpointADomainPayload;
        } else {
            childPropertiesA["multichassis.McPeerIPSecDomain"] = [];
        }

        var endpointAMcPeerIpsecPayload = util.editPayload(endpointAfdn, endPointAProperties, childPropertiesA, fullClassName, endPointAObjectFullName);
        if (!isAudit) {
            logger.info("Sending the modify request for Endpoint A MC Peer IPSec");
            this.modifyRequest(neId, endpointAMcPeerIpsecPayload);
        } else {
            logger.info("Sending the audit request for Endpoint A MC Peer IPSec ");
            this.updateAuditResult(this.auditRequest(neId, endpointAMcPeerIpsecPayload));
        }

        var endPointBProperties = {};
        endPointBProperties["bfdEnable"] = intentConfig["mc-ipsec"]["endPointBDetails"]["bfd-liveness"];
        endPointBProperties["keepAliveInterval"] = intentConfig["mc-ipsec"]["endPointBDetails"]["keep-alive-interval"];
        endPointBProperties["holdOnNeighborFailure"] = intentConfig["mc-ipsec"]["endPointBDetails"]["hold-on-neighbor-failure"];
        endPointBProperties["discoveryInterval"] = intentConfig["mc-ipsec"]["endPointBDetails"]["discovery-interval"]["interval-secs"];
        endPointBProperties["discoveryIntervalBoot"] = intentConfig["mc-ipsec"]["endPointBDetails"]["discovery-interval"]["boot"];

        var childPropertiesB = {};
        var endpointBDomainPayload = [];
        let domainBData = intentConfig["mc-ipsec"] && intentConfig["mc-ipsec"]["endPointADetails"] && intentConfig["mc-ipsec"]["endPointBDetails"]["domain"];
        if (domainBData) {
            if (!Array.isArray(domainBData)) {
                domainBData = [domainBData];
            }
            for (var index in domainBData) {
                var intentDomainBConfig = domainBData[index];
                var domainObjectFullName = endPointBObjectFullName + ":ipscdom-" + intentDomainBConfig["group-id"];
                var domainBPayload = this.createMcPeerIPSecDomainPayLoad(intentDomainBConfig);
                endpointBDomainPayload.push(domainBPayload);
            }
            childPropertiesB["multichassis.McPeerIPSecDomain"] = endpointBDomainPayload;
        } else {
            childPropertiesB["multichassis.McPeerIPSecDomain"] = [];
        }
        var endpointBMcPeerIpsecPayload = util.editPayload(endpointBfdn, endPointBProperties, childPropertiesB, fullClassName, endPointBObjectFullName);
        if (!isAudit) {
            logger.info("Sending the modify request for Endpoint B MC Peer IPSec");
            this.modifyRequest(neId, endpointBMcPeerIpsecPayload);
        } else {
            logger.info("Sending the audit request for Endpoint B MC Peer IPSec");
            this.updateAuditResult(this.auditRequest(neId, endpointBMcPeerIpsecPayload));
        }
    }

    this.createMcPeerIPSecDomainPayLoad = function(intentDomainConfig) {
        var properties = {};
        if (intentDomainConfig) {
            properties["domainId"] = intentDomainConfig["id"];
            properties["administrativeState"] = util.convertToNfmpAdminstarteState(intentDomainConfig["admin-state"]);
        }
        return properties;
    };


    this.createMcIpsecGrpPayLoad = function(neId, intentConfig) {
        if (savedTopology == null) {
            logger.info("Creating mc-ipsec topology");
            savedTopology = topologyFactory.createServiceTopology();
        }
        var fullClassName = "multichassis.MultiChassisIPSecGroup";
        var endpointAsiteId = intentConfig["firstSiteId"];
        var endpointBsiteId = intentConfig["secondSiteId"];
        var endpointAInterfaceAddress = intentConfig["firstSiteSourceIpAddress"];
        var endpointBInterfaceAddress = intentConfig["endpointB-interfaceAddress"];
        var mcIpsecGrpFdn = "ipsecMgr";
        var intentlength;
        var mcIpsecFlag = false;
        var XtraConfigLength = savedTopology.getXtraInfo().length;;
        var tunnelGroupConfig = intentConfig["mc-ipsec"] && intentConfig["mc-ipsec"]["tunnelGroup"]
        if (tunnelGroupConfig && !Array.isArray(tunnelGroupConfig)) {
            tunnelGroupConfig = [tunnelGroupConfig];
        }
        if (!tunnelGroupConfig) {
            if (mcGrpSaveTopology.length === 1) {
                var data = mcGrpSaveTopology[0];
                this.syncDeleteMcIpsec(data);
            }
        } else {
            intentlength = tunnelGroupConfig.length;
        }
        var mcIpsecGrpToBeDeleted = [];
        if (tunnelGroupConfig) {
            if (mcGrpSaveTopology.length === 0) {
                if (XtraConfigLength > intentlength) {
                    var savedXtraInfo = savedTopology.getXtraInfo();
                    for (var i = 0; i < savedXtraInfo.length; i++) {
                        var xtraConfig = savedXtraInfo[i].getKey();
                        var deleteFlag = true;
                        for (var j = 0; j < tunnelGroupConfig.length; j++) {
                            var intentMcIpsecGrp = tunnelGroupConfig[j];
                            var endpointATunnelGrpId = intentMcIpsecGrp["firstTunnelGroupId"];
                            var endpointBTunnelGrpId = intentMcIpsecGrp["secondTunnelGroupId"];
                            var mcIpsecGrpObjectFullName = "ipsecMgr:mcIPsec-" + endpointAInterfaceAddress + "-grp1-" + endpointATunnelGrpId + "-" + endpointBInterfaceAddress + "-grp2-" + endpointBTunnelGrpId;
                            mcIpsecGrpObjectFullName = util.modifyNeIdForIpV6(mcIpsecGrpObjectFullName, endpointAInterfaceAddress, endpointBInterfaceAddress);
                            if (xtraConfig === mcIpsecGrpObjectFullName) {
                                deleteFlag = false;
                                break;
                            }
                        }
                        if (deleteFlag && mcGrpSaveTopologyItem && typeof mcGrpSaveTopologyItem === 'string' && mcGrpSaveTopologyItem.startsWith("ipsecMgr:")) {
                            mcIpsecFlag = true;
                            mcIpsecGrpToBeDeleted.push(xtraConfig);
                        }
                    }
                }
            } else {
                for (var i = 0; i < mcGrpSaveTopology.length; i++) {
                    var mcGrpSaveTopologyItem = mcGrpSaveTopology[i];
                    var deleteFlag = true;

                    for (var j = 0; j < tunnelGroupConfig.length; j++) {
                        var intentMcIpsecGrp = tunnelGroupConfig[j];
                        var endpointATunnelGrpId = intentMcIpsecGrp["firstTunnelGroupId"];
                        var endpointBTunnelGrpId = intentMcIpsecGrp["secondTunnelGroupId"];

                        var mcIpsecGrpObjectFullName = "ipsecMgr:mcIPsec-" + endpointAInterfaceAddress + "-grp1-" + endpointATunnelGrpId + "-" + endpointBInterfaceAddress + "-grp2-" + endpointBTunnelGrpId;
                        mcIpsecGrpObjectFullName = util.modifyNeIdForIpV6(mcIpsecGrpObjectFullName, endpointAInterfaceAddress, endpointBInterfaceAddress);

                        if (mcGrpSaveTopologyItem === mcIpsecGrpObjectFullName) {
                            deleteFlag = false;
                            break;
                        }
                    }

                    if (deleteFlag && mcGrpSaveTopologyItem.startsWith("ipsecMgr:")) {
                        mcIpsecGrpToBeDeleted.push(mcGrpSaveTopologyItem);
                    }
                }
            }
            for (var index in mcIpsecGrpToBeDeleted) {
                this.syncDeleteMcIpsec(mcIpsecGrpToBeDeleted[index]);
            }
            if (mcIpsecFlag && mcGrpSaveTopology.length === 0) {
                 savedTopology.setXtraInfo([]);
            }
            for (var i = 0; i < tunnelGroupConfig.length; i++) {
                var mcIpsecTunnelGrpData = tunnelGroupConfig[i];
                var mcIpsecGrpProperties = {};
                var mcIpsecGrpObjectFullName = "ipsecMgr:mcIPsec-" + endpointAInterfaceAddress + "-grp1-" + mcIpsecTunnelGrpData["firstTunnelGroupId"] + "-" + endpointBInterfaceAddress + "-grp2-" + mcIpsecTunnelGrpData["secondTunnelGroupId"];
                mcIpsecGrpObjectFullName = util.modifyNeIdForIpV6(mcIpsecGrpObjectFullName, endpointAInterfaceAddress, endpointBInterfaceAddress);
                var entry = topologyFactory.createTopologyXtraInfoFrom(mcIpsecGrpObjectFullName, JSON.stringify(mcIpsecTunnelGrpData));
                savedTopology.addXtraInfo(entry);
                mcIpsecGrpProperties["tunnelGroupSyncTag"] = mcIpsecTunnelGrpData["tunnelGroupSyncTag"];
                mcIpsecGrpProperties["firstSiteId"] = endpointAsiteId;
                mcIpsecGrpProperties["firstTunnelGroupId"] = mcIpsecTunnelGrpData["firstTunnelGroupId"];
                if (endpointAsiteId.indexOf(":") !== -1) {
                    mcIpsecGrpProperties["firstSiteIpAddressType"] = "ipv6";
                } else {
                    mcIpsecGrpProperties["firstSiteIpAddressType"] = "ipv4";
                }

                if (endpointAInterfaceAddress.indexOf(":") !== -1) {
                    mcIpsecGrpProperties["secondSitePeerIpAddressType"] = "ipv6";
                } else {
                    mcIpsecGrpProperties["secondSitePeerIpAddressType"] = "ipv4";
                }

                mcIpsecGrpProperties["secondSitePeerIpAddress"] = endpointAInterfaceAddress;

                mcIpsecGrpProperties["firstSiteAdministrativeState"] = mcIpsecTunnelGrpData["firstSiteAdministrativeState"];
                mcIpsecGrpProperties["firstSitePriority"] = mcIpsecTunnelGrpData["firstSitePriority"];
                mcIpsecGrpProperties["secondSiteId"] = endpointBsiteId;
                mcIpsecGrpProperties["secondTunnelGroupId"] = mcIpsecTunnelGrpData["secondTunnelGroupId"];
                if (endpointBsiteId.indexOf(":") !== -1) {
                    mcIpsecGrpProperties["secondSiteIpAddressType"] = "ipv6";
                } else {
                    mcIpsecGrpProperties["secondSiteIpAddressType"] = "ipv4";
                }
                if (endpointBInterfaceAddress.indexOf(":") !== -1) {
                    mcIpsecGrpProperties["firstSitePeerIpAddressType"] = "ipv6";
                } else {
                    mcIpsecGrpProperties["firstSitePeerIpAddressType"] = "ipv4";
                }
                mcIpsecGrpProperties["firstSitePeerIpAddress"] = endpointBInterfaceAddress;

                mcIpsecGrpProperties["secondSiteAdministrativeState"] = mcIpsecTunnelGrpData["secondSiteAdministrativeState"];
                mcIpsecGrpProperties["secondSitePriority"] = mcIpsecTunnelGrpData["secondSitePriority"];
                var mcIpsecGrpChildProperties = {};
                var mcIpsecGrpPayload = this.McIpsecGrpEditPayload(mcIpsecGrpFdn, mcIpsecGrpProperties, mcIpsecGrpChildProperties, fullClassName, mcIpsecGrpObjectFullName);
                if (!isAudit) {
                    logger.info("Sending modify request for MC IPSec Group");
                    this.modifyRequest(neId, mcIpsecGrpPayload);
                } else {
                    logger.info("Sending audit request for MC IPSec Group");
                    this.updateAuditResult(this.auditRequest(neId, mcIpsecGrpPayload));
                }
            }
        }
    }

    this.McIpsecGrpEditPayload = function(fdn, properties, childProperties, fullClassName, objectFullName) {

        var payload = {};
        var configInfo = {};
        configInfo[fullClassName] = properties;
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName;
        payload["clearOnDeployFailure"] = true;
        payload["configInfo"] = configInfo;
        return payload;
    }

    this.createMcPeerRingPayLoad = function (neId, mcRingConfig, endpointAsiteId, endpointAInterfaceAddress, endpointBsiteId, endpointBInterfaceAddress) {
        var fullClassName = "multichassis.MultiChassisRing";

        var endpointAfdn = "network:" + endpointAsiteId + ":mc-peer-manager:peer-" + endpointBInterfaceAddress;
        endpointAfdn = util.modifyNeIdForIpV6(endpointAfdn, endpointAsiteId, endpointBInterfaceAddress);
        var endpointBfdn = "network:" + endpointBsiteId + ":mc-peer-manager:peer-" + endpointAInterfaceAddress;
        endpointBfdn = util.modifyNeIdForIpV6(endpointBfdn, endpointBsiteId, endpointAInterfaceAddress);

        //endPointADetails
        if (mcRingConfig["endPointADetails"]["ring"] )
        {
            var endPointAObjectFullName = "network:" + endpointAsiteId + ":mc-peer-manager:peer-" + endpointBInterfaceAddress + ":ring-"+mcRingConfig["ringName"];
            endPointAObjectFullName = util.modifyNeIdForIpV6(endPointAObjectFullName, endpointAsiteId, endpointBInterfaceAddress);
            var intentMcRingAConfig = mcRingConfig["endPointADetails"]["ring"];

            var endPointAProperties = {};
            endPointAProperties["ringName"] = mcRingConfig["ringName"];
            endPointAProperties["administrativeState"] = util.convertToNfmpAdminstarteState(intentMcRingAConfig["admin-state"]);

            endPointAProperties["ibrccDebounceMaxTime"] = intentMcRingAConfig["in-band-control-path"]["max-debounce-time"];
            endPointAProperties["ibrccAdministrativeState"] = util.convertToNfmpAdminstarteState(intentMcRingAConfig["in-band-control-path"]["admin-state"]);
            endPointAProperties["ibrccDestinationIpAddr"] = intentMcRingAConfig["in-band-control-path"]["dst-ip"];
            //endPointAProperties["ibrccServiceName"] = intentMcRingAConfig["in-band-control-path"]["service-name"];
            endPointAProperties["ibrccInterfaceName"] = intentMcRingAConfig["in-band-control-path"]["interface"];

            var endPointAchildProperties = {};

            //PathBVlanRange
            var endpointAPathBPayload = [];
            let pathBsIntentConfig = intentMcRingAConfig["path-b"]["range"];
            if (pathBsIntentConfig) {
                if (!Array.isArray(pathBsIntentConfig)) {
                    pathBsIntentConfig = [pathBsIntentConfig];
                }
                for (var index in pathBsIntentConfig) {
                    var pathBIntentConfig = pathBsIntentConfig[index];
                    var pathBPayload = this.createVlanRangePayLoad(pathBIntentConfig);
                    endpointAPathBPayload.push(pathBPayload);
                }
                endPointAchildProperties["multichassis.PathBVlanRange"] = endpointAPathBPayload;
            } else {
                endPointAchildProperties["multichassis.PathBVlanRange"] = [];
            }

            //ExcludeVlanRange
            var endpointAExclPayload = [];
            let exclsIntentConfig = intentMcRingAConfig["path-excl"]["range"];
            if (exclsIntentConfig) {
                if (!Array.isArray(exclsIntentConfig)) {
                    exclsIntentConfig = [exclsIntentConfig];
                }
                for (var index in exclsIntentConfig) {
                    var exclIntentConfig = exclsIntentConfig[index];
                    var exclPayload = this.createVlanRangePayLoad(exclIntentConfig);
                    endpointAExclPayload.push(exclPayload);
                }
                endPointAchildProperties["multichassis.ExcludeVlanRange"] = endpointAExclPayload;
            } else {
                endPointAchildProperties["multichassis.ExcludeVlanRange"] = [];
            }

            //RingNode
            var endpointARingNodePayload = [];
            let ringNodesIntentConfig = intentMcRingAConfig["ring-node"];
            if (ringNodesIntentConfig) {
                if (!Array.isArray(ringNodesIntentConfig)) {
                    ringNodesIntentConfig = [ringNodesIntentConfig];
                }
                for (var index in ringNodesIntentConfig) {
                    var ringNodeIntentConfig = ringNodesIntentConfig[index];
                    var ringNodePayload = this.createMcRingNodePayLoad(ringNodeIntentConfig);
                    endpointARingNodePayload.push(ringNodePayload);
                }
                endPointAchildProperties["multichassis.MultiChassisRingNode"] = endpointARingNodePayload;
            } else {
                endPointAchildProperties["multichassis.MultiChassisRingNode"] = [];
            }

            var endpointAMcRingPayload = util.editPayload(endpointAfdn, endPointAProperties, endPointAchildProperties, fullClassName, endPointAObjectFullName);
            if (!isAudit)
            {
                logger.info("Sending the modify request for Endpoint A MC Ring");
                this.modifyRequest(neId, endpointAMcRingPayload);
            }
            else
            {
                logger.info("Sending the audit request for Endpoint A MC Ring");
                this.updateAuditResult(this.auditRequest(neId, endpointAMcRingPayload));
            }
        }
        //endPointBDetails
        if (mcRingConfig["endPointBDetails"]["ring"] )
        {
            var endPointBObjectFullName = "network:" + endpointBsiteId + ":mc-peer-manager:peer-" + endpointAInterfaceAddress + ":ring-"+mcRingConfig["ringName"];
            endPointBObjectFullName = util.modifyNeIdForIpV6(endPointBObjectFullName, endpointBsiteId, endpointAInterfaceAddress);
            var intentMcRingBConfig = mcRingConfig["endPointBDetails"]["ring"];


            var endPointBProperties = {};
            endPointBProperties["ringName"] = mcRingConfig["ringName"];
            endPointBProperties["administrativeState"] = util.convertToNfmpAdminstarteState(intentMcRingBConfig["admin-state"]);

            endPointBProperties["ibrccDebounceMaxTime"] = intentMcRingBConfig["in-band-control-path"]["max-debounce-time"];
            endPointBProperties["ibrccAdministrativeState"] = util.convertToNfmpAdminstarteState(intentMcRingBConfig["in-band-control-path"]["admin-state"]);
            endPointBProperties["ibrccDestinationIpAddr"] = intentMcRingBConfig["in-band-control-path"]["dst-ip"];
            //endPointBProperties["ibrccServiceName"] = intentMcRingBConfig["in-band-control-path"]["service-name"];
            endPointBProperties["ibrccInterfaceName"] = intentMcRingBConfig["in-band-control-path"]["interface"];

            var endPointBchildProperties = {};

            //PathBVlanRange
            var endpointBPathBPayload = [];
            let pathBsIntentConfig = intentMcRingBConfig["path-b"]["range"];
            if (pathBsIntentConfig) {
                if (!Array.isArray(pathBsIntentConfig)) {
                    pathBsIntentConfig = [pathBsIntentConfig];
                }
                for (var index in pathBsIntentConfig) {
                    var pathBIntentConfig = pathBsIntentConfig[index];
                    var pathBPayload = this.createVlanRangePayLoad(pathBIntentConfig);
                    endpointBPathBPayload.push(pathBPayload);
                }
                endPointBchildProperties["multichassis.PathBVlanRange"] = endpointBPathBPayload;
            } else {
                endPointBchildProperties["multichassis.PathBVlanRange"] = [];
            }

            //ExcludeVlanRange
            var endpointBExclPayload = [];
            let exclsIntentConfig = intentMcRingBConfig["path-excl"]["range"];
            if (exclsIntentConfig) {
                if (!Array.isArray(exclsIntentConfig)) {
                    exclsIntentConfig = [exclsIntentConfig];
                }
                for (var index in exclsIntentConfig) {
                    var exclIntentConfig = exclsIntentConfig[index];
                    var exclPayload = this.createVlanRangePayLoad(exclIntentConfig);
                    endpointBExclPayload.push(exclPayload);
                }
                endPointBchildProperties["multichassis.ExcludeVlanRange"] = endpointBExclPayload;
            } else {
                endPointBchildProperties["multichassis.ExcludeVlanRange"] = [];
            }

            //RingNode
            var endpointBRingNodePayload = [];
            let ringNodesIntentConfig = intentMcRingBConfig["ring-node"];
            if (ringNodesIntentConfig) {
                if (!Array.isArray(ringNodesIntentConfig)) {
                    ringNodesIntentConfig = [ringNodesIntentConfig];
                }
                for (var index in ringNodesIntentConfig) {
                    var ringNodeIntentConfig = ringNodesIntentConfig[index];
                    var ringNodePayload = this.createMcRingNodePayLoad(ringNodeIntentConfig);
                    endpointBRingNodePayload.push(ringNodePayload);
                }
                endPointBchildProperties["multichassis.MultiChassisRingNode"] = endpointBRingNodePayload;
            } else {
                endPointBchildProperties["multichassis.MultiChassisRingNode"] = [];
            }

            var endpointBMcRingPayload = util.editPayload(endpointBfdn, endPointBProperties, endPointBchildProperties, fullClassName, endPointBObjectFullName);
            if (!isAudit)
            {
                logger.info("Sending the modify request for Endpoint B MC Ring");
                this.modifyRequest(neId, endpointBMcRingPayload);
            }
            else
            {
                logger.info("Sending the audit request for Endpoint B MC Ring");
                this.updateAuditResult(this.auditRequest(neId, endpointBMcRingPayload));
            }
        }
    }

    this.createVlanRangePayLoad = function(vlanRangeIntentConfig) {
        var properties = {};
        if (vlanRangeIntentConfig) {
            properties["startVlan"] = vlanRangeIntentConfig["start"];
            properties["endVlan"] = vlanRangeIntentConfig["end"];
        }
        return properties;
    };

    this.createMcRingNodePayLoad = function(ringNodeIntentConfig) {
        var properties = {};
        if (ringNodeIntentConfig) {
            properties["ringNodeName"] = ringNodeIntentConfig["name"];
            properties["administrativeState"] = util.convertToNfmpAdminstarteState(ringNodeIntentConfig["admin-state"]);
            properties["rncvInterval"] = ringNodeIntentConfig["interval"];
            properties["rncvServiceId"] = ringNodeIntentConfig["rncvServiceId"];
            properties["rncvInnerEncapValue"] = ringNodeIntentConfig["rncvInnerEncapValue"];
            properties["rncvOuterEncapValue"] = ringNodeIntentConfig["rncvOuterEncapValue"];
            properties["rncvDestinationIpAddr"] = ringNodeIntentConfig["dst-ip"];
            properties["rncvSourceIpAddr"] = ringNodeIntentConfig["src-ip"];
            properties["rncvSourceMacAddr"] = ringNodeIntentConfig["src-mac"];
        }
        return properties;
    };

    this.createMcRingGrpPayload = function(neId, intentConfig) {
        if (savedTopology == null) {
            logger.info("Creating mc-ring topology");
            savedTopology = topologyFactory.createServiceTopology();
        }
        if(intentConfig["mc-ring"]["ringGroup"]) {
            if (!Array.isArray(intentConfig["mc-ring"]["ringGroup"]))
            {
                intentConfig["mc-ring"]["ringGroup"] = [intentConfig["mc-ring"]["ringGroup"]];
            }
        }
        var endpointAsiteId = intentConfig["firstSiteId"];
        var endpointBsiteId = intentConfig["secondSiteId"];
        var endpointAInterfaceAddress = intentConfig["firstSiteSourceIpAddress"];
        var endpointBInterfaceAddress = intentConfig["endpointB-interfaceAddress"];

        var mcRingGrpToBeDeleted = [];

        for (var i = 0; i < mcRingGrpSaveTopology.length; i++) {
            var mcRingGrpSaveTopologyItem = mcRingGrpSaveTopology[i];
            var deleteFlag = true;

            for (var index in intentConfig["mc-ring"]["ringGroup"]) {

                var mcRingGrpObjectFullName = "mcring-group-manager:mc-ring-group-" + intentConfig["mc-ring"]["ringGroup"][index]["ringName"] + "-first-" + endpointAInterfaceAddress + "-second-" + endpointBInterfaceAddress;
                mcRingGrpObjectFullName = util.modifyNeIdForIpV6(mcRingGrpObjectFullName, endpointAInterfaceAddress, endpointBInterfaceAddress);

                if (mcRingGrpSaveTopologyItem === mcRingGrpObjectFullName) {
                    deleteFlag = false;
                    break;
                }
            }

            if (deleteFlag && mcRingGrpSaveTopologyItem.startsWith("mcring-group-manager:mc-ring-group-")) {
                mcRingGrpToBeDeleted.push(mcRingGrpSaveTopologyItem);
            }
        }

        for (var index in mcRingGrpToBeDeleted)
        {
            this.syncDeleteMcRingGroup(mcRingGrpToBeDeleted[index]);
        }
        mcRingGrpSaveTopology=[];

        for (var index in intentConfig["mc-ring"]["ringGroup"]) {
            var mcRingGrpData = intentConfig["mc-ring"]["ringGroup"][index];
            var fullClassName = "multichassis.MultiChassisRingGroup";
            var mcRingGrpFdn = "mcring-group-manager";

            var mcRingGrpProperties = {};
            var mcRingGrpObjectFullName = "mcring-group-manager:mc-ring-group-" + mcRingGrpData["ringName"] + "-first-" + endpointAInterfaceAddress + "-second-" + endpointBInterfaceAddress;
            mcRingGrpObjectFullName = util.modifyNeIdForIpV6(mcRingGrpObjectFullName, endpointAInterfaceAddress, endpointBInterfaceAddress);

            var entry = topologyFactory.createTopologyXtraInfoFrom(mcRingGrpObjectFullName, JSON.stringify(mcRingGrpData));
            savedTopology.addXtraInfo(entry);

            if(!util.isObjectExists(fullClassName, mcRingGrpObjectFullName))
            {
                mcRingGrpProperties["ringName"] = mcRingGrpData["ringName"];
                mcRingGrpProperties["firstSiteId"] = endpointAsiteId;
                if (endpointAsiteId.indexOf(":") !== -1) {
                    mcRingGrpProperties["firstSiteIpAddressType"] = "ipv6";
                } else {
                    mcRingGrpProperties["firstSiteIpAddressType"] = "ipv4";
                }

                if (endpointAInterfaceAddress.indexOf(":") !== -1) {
                    mcRingGrpProperties["secondSitePeerIpAddressType"] = "ipv6";
                } else {
                    mcRingGrpProperties["secondSitePeerIpAddressType"] = "ipv4";
                }
                mcRingGrpProperties["secondSitePeerIpAddress"] = endpointAInterfaceAddress;
                mcRingGrpProperties["secondSiteId"] = endpointBsiteId;
                if (endpointBsiteId.indexOf(":") !== -1) {
                    mcRingGrpProperties["secondSiteIpAddressType"] = "ipv6";
                } else {
                    mcRingGrpProperties["secondSiteIpAddressType"] = "ipv4";
                }
                if (endpointBInterfaceAddress.indexOf(":") !== -1) {
                    mcRingGrpProperties["firstSitePeerIpAddressType"] = "ipv6";
                } else {
                    mcRingGrpProperties["firstSitePeerIpAddressType"] = "ipv4";
                }
                mcRingGrpProperties["firstSitePeerIpAddress"] = endpointBInterfaceAddress;

                var mcRingGrpChildProperties = {};
                var mcRingGrpPayload = this.McGrpEditPayload(mcRingGrpFdn, mcRingGrpProperties, mcRingGrpChildProperties, fullClassName, mcRingGrpObjectFullName);
                if (!isAudit) {
                    logger.info("Sending modify request for MC Ring Group");
                    this.modifyRequest(neId, mcRingGrpPayload);
                } else {
                    logger.info("Sending audit request for MC Ring Group");
                    this.updateAuditResult(this.auditRequest(neId, mcRingGrpPayload));
                }
            }

            this.createMcPeerRingPayLoad(neId, mcRingGrpData, endpointAsiteId, endpointAInterfaceAddress, endpointBsiteId, endpointBInterfaceAddress);
        }
    }

    this.syncDeleteMcRingGroup = function (objectFullName) {
        logger.info("Deleting MC-Ring Group: " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
    }

    this.McGrpEditPayload = function(fdn, properties, childProperties, fullClassName, objectFullName) {

        var payload = {};
        var configInfo = {};
        configInfo[fullClassName] = properties;
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName;
        payload["clearOnDeployFailure"] = true;
        payload["configInfo"] = configInfo;
        return payload;
    }

    this.createMcSyncGrpPayload = function(neId, intentConfig) {
        if (savedTopology == null) {
            logger.info("Creating mc-ring topology");
            savedTopology = topologyFactory.createServiceTopology();
        }
        if(intentConfig["sync"]["syncGroup"]) {
            if (!Array.isArray(intentConfig["sync"]["syncGroup"]))
            {
                intentConfig["sync"]["syncGroup"] = [intentConfig["sync"]["syncGroup"]];
            }
        }
        var endpointAsiteId = intentConfig["firstSiteId"];
        var endpointBsiteId = intentConfig["secondSiteId"];
        var endpointAInterfaceAddress = intentConfig["firstSiteSourceIpAddress"];
        var endpointBInterfaceAddress = intentConfig["endpointB-interfaceAddress"];

        var mcSyncGrpToBeDeleted = [];

        for (var i = 0; i < mcSyncGrpSaveTopology.length; i++) {
            var mcSyncGrpSaveTopologyItem = mcSyncGrpSaveTopology[i];
            var deleteFlag = true;

            for (var index in intentConfig["sync"]["syncGroup"]) {
                var mcSyncGrpObjectFullName = "mc-sync-manager:mc-sync-" + intentConfig["sync"]["syncGroup"][index]["tag"] + "-" + endpointAInterfaceAddress + "-" + endpointBInterfaceAddress;
                if(intentConfig["sync"]["syncGroup"][index]["firstSiteSyncTagConfigLevel"] == "sdpLevel") {
                    mcSyncGrpObjectFullName += "-3"
                }
                if(intentConfig["sync"]["syncGroup"][index]["firstSiteSyncTagConfigLevel"] == "sdpRangeLevel") {
                    mcSyncGrpObjectFullName += "-4"
                }
                mcSyncGrpObjectFullName = util.modifyNeIdForIpV6(mcSyncGrpObjectFullName, endpointAInterfaceAddress, endpointBInterfaceAddress);

                if (mcSyncGrpSaveTopologyItem === mcSyncGrpObjectFullName) {
                    deleteFlag = false;
                    break;
                }
            }

            if (deleteFlag && mcSyncGrpSaveTopologyItem.startsWith("mc-sync-manager:mc-sync-")) {
                mcSyncGrpToBeDeleted.push(mcSyncGrpSaveTopologyItem);
            }
        }

        for (var index in mcSyncGrpToBeDeleted)
        {
            this.syncDeleteMcSyncGroup(mcSyncGrpToBeDeleted[index]);
        }
        mcSyncGrpSaveTopology=[];

        for (var index in intentConfig["sync"]["syncGroup"]) {
            var mcSyncGrpData = intentConfig["sync"]["syncGroup"][index];
            var fullClassName = "multichassis.MultiChassisSync";
            var mcSyncGrpFdn = "mc-sync-manager";

            var mcSyncGrpProperties = {};
            var mcSyncGrpObjectFullName = "mc-sync-manager:mc-sync-" + mcSyncGrpData["tag"] + "-" + endpointAInterfaceAddress + "-" + endpointBInterfaceAddress;
            if(mcSyncGrpData["firstSiteSyncTagConfigLevel"] == "sdpLevel") {
                mcSyncGrpObjectFullName += "-3"
            }
            if(mcSyncGrpData["firstSiteSyncTagConfigLevel"] == "sdpRangeLevel") {
                mcSyncGrpObjectFullName += "-4"
            }
            mcSyncGrpObjectFullName = util.modifyNeIdForIpV6(mcSyncGrpObjectFullName, endpointAInterfaceAddress, endpointBInterfaceAddress);
            var isSyncGroupExists = util.isObjectExists(fullClassName, mcSyncGrpObjectFullName)
            var entry = topologyFactory.createTopologyXtraInfoFrom(mcSyncGrpObjectFullName, JSON.stringify(mcSyncGrpData));
            savedTopology.addXtraInfo(entry);


            mcSyncGrpProperties["description"] = mcSyncGrpData["description"];
            if(!isSyncGroupExists) {
                mcSyncGrpProperties["tag"] = mcSyncGrpData["tag"];
                if(!isAudit) {
                    mcSyncGrpProperties["firstSiteSyncTagConfigLevel"] = mcSyncGrpData["firstSiteSyncTagConfigLevel"];
                    mcSyncGrpProperties["firstSiteId"] = endpointAsiteId;
                    //mcSyncGrpProperties["firstSitePointer"] = "network:"+endpointAsiteId;
                    mcSyncGrpProperties["firstSiteIpAddressType"] = (endpointAsiteId.indexOf(":") !== -1)?"ipv6":"ipv4";
                    mcSyncGrpProperties["firstIpAddress"] = endpointAInterfaceAddress;
                    mcSyncGrpProperties["firstIpAddressType"] = (endpointAInterfaceAddress.indexOf(":") !== -1)?"ipv6":"ipv4";
                    mcSyncGrpProperties["firstPeerPointer"] = util.modifyNeIdForIpV6("network:"+endpointAsiteId+":mc-peer-manager:peer-"+endpointBInterfaceAddress,endpointAsiteId,endpointBInterfaceAddress);

                }
                //port
                if(mcSyncGrpData["firstSitePortName"]){
                    mcSyncGrpProperties["firstSitePortName"] = mcSyncGrpData["firstSitePortName"];
                    if(!isAudit) {
                        if(mcSyncGrpData["firstSitePortName"].indexOf("/") > -1) {
                            mcSyncGrpProperties["firstSitePortPointer"] = util.getBaseFdnForPort(endpointAsiteId,mcSyncGrpData["firstSitePortName"]);
                        }
                        else{
                            mcSyncGrpProperties["firstSitePortPointer"] = "network:"+endpointAsiteId+":lag:interface-"+util.getLagId(mcSyncGrpData["firstSitePortName"],endpointAsiteId);
                        }
                        mcSyncGrpProperties["firstSitePortPointer"] = util.modifyNeIdForIpV6(mcSyncGrpProperties["firstSitePortPointer"],endpointAsiteId);
                        mcSyncGrpProperties["firstSitePortEncapType"] = util.getPortLagEncapType(mcSyncGrpProperties["firstSitePortPointer"])["encapType"];
                        mcSyncGrpProperties["firstSitePeerSyncPortPointer"] = "";
                    }
                }
                else {
                    if(!isAudit){
                        mcSyncGrpProperties["firstSitePortName"] = "";
                        mcSyncGrpProperties["firstSitePortPointer"] = "";
                        mcSyncGrpProperties["firstSitePortEncapType"] = "unknown";
                        mcSyncGrpProperties["firstSitePeerSyncPortPointer"] = "";
                    }
                }
                //sdp
                if((mcSyncGrpData["firstSiteSdpId"])) {
                    mcSyncGrpProperties["firstSiteSdpId"] = mcSyncGrpData["firstSiteSdpId"];
                    if(!isAudit){
                        mcSyncGrpProperties["firstSitePeerSyncSdpPointer"] = "";
                        mcSyncGrpProperties["firstSiteSdpPointer"] = "serviceTunnel:from-"+endpointAsiteId+"-id-"+mcSyncGrpData["firstSiteSdpId"];
                    }
                }
                else {
                    if(!isAudit){
                        mcSyncGrpProperties["firstSiteSdpId"] = 0;
                        mcSyncGrpProperties["firstSitePeerSyncSdpPointer"] = "";
                        mcSyncGrpProperties["firstSiteSdpPointer"] = "";
                    }
                }

                if(!isAudit) {
                    mcSyncGrpProperties["secondSiteSyncTagConfigLevel"] = mcSyncGrpData["firstSiteSyncTagConfigLevel"];
                    mcSyncGrpProperties["secondSiteId"] = endpointBsiteId;
                    //mcSyncGrpProperties["secondSitePointer"] = "network:"+endpointBsiteId;
                    mcSyncGrpProperties["secondSiteIpAddressType"] = (endpointBsiteId.indexOf(":") !== -1)?"ipv6":"ipv4";
                    mcSyncGrpProperties["secondIpAddress"] = endpointBInterfaceAddress;
                    mcSyncGrpProperties["secondIpAddressType"] = (endpointBInterfaceAddress.indexOf(":") !== -1)?"ipv6":"ipv4";
                    mcSyncGrpProperties["secondPeerPointer"] = util.modifyNeIdForIpV6("network:"+endpointBsiteId+":mc-peer-manager:peer-"+endpointAInterfaceAddress,endpointBsiteId,endpointAInterfaceAddress);
                }
                //port
                if(mcSyncGrpData["secondSitePortName"])
                {
                    mcSyncGrpProperties["secondSitePortName"] = mcSyncGrpData["secondSitePortName"];
                    if(!isAudit) {
                        if(mcSyncGrpData["secondSitePortName"].indexOf("/") > -1) {
                            mcSyncGrpProperties["secondSitePortPointer"] = util.getBaseFdnForPort(endpointBsiteId,mcSyncGrpData["secondSitePortName"]);
                        }
                        else{
                            mcSyncGrpProperties["secondSitePortPointer"] = "network:"+endpointBsiteId+":lag:interface-"+util.getLagId(mcSyncGrpData["secondSitePortName"],endpointBsiteId);
                        }
                        mcSyncGrpProperties["secondSitePortPointer"] = util.modifyNeIdForIpV6(mcSyncGrpProperties["secondSitePortPointer"],endpointBsiteId);
                        mcSyncGrpProperties["secondSitePortEncapType"] = util.getPortLagEncapType(mcSyncGrpProperties["secondSitePortPointer"])["encapType"];
                        mcSyncGrpProperties["secondSitePeerSyncPortPointer"] = "";
                    }
                }
                else {
                    if(!isAudit){
                        mcSyncGrpProperties["secondSitePortName"] = "";
                        mcSyncGrpProperties["secondSitePortPointer"] = "";
                        mcSyncGrpProperties["secondSitePortEncapType"] = "unknown";
                        mcSyncGrpProperties["secondSitePeerSyncPortPointer"] = "";
                    }
                }
                //sdp
                if((mcSyncGrpData["secondSiteSdpId"])) {
                    mcSyncGrpProperties["secondSiteSdpId"] = mcSyncGrpData["secondSiteSdpId"];
                    if(!isAudit){
                        mcSyncGrpProperties["secondSitePeerSyncSdpPointer"] = "";
                        mcSyncGrpProperties["secondSiteSdpPointer"] = "serviceTunnel:from-"+endpointBsiteId+"-id-"+mcSyncGrpData["secondSiteSdpId"];
                    }
                }
                else {
                    if(!isAudit) {
                        mcSyncGrpProperties["secondSiteSdpId"] = 0;
                        mcSyncGrpProperties["secondSitePeerSyncSdpPointer"] = "";
                        mcSyncGrpProperties["secondSiteSdpPointer"] = "";
                    }
                }
            }

            var mcSyncGrpChildProperties = {};
            var mcSyncGrpPayload = this.McGrpEditPayload(mcSyncGrpFdn, mcSyncGrpProperties, mcSyncGrpChildProperties, fullClassName, mcSyncGrpObjectFullName);
            if (!isAudit) {
                logger.info("Sending modify request for MC Sync Group");
                this.modifyRequest(neId, mcSyncGrpPayload);
            } else {
                logger.info("Sending audit request for MC Sync Group");
               this.updateAuditResult(this.auditRequest(neId, mcSyncGrpPayload));
           }
           if(mcSyncGrpData["firstSiteSyncTagConfigLevel"] == "vlanLevel" && mcSyncGrpData["vlanEntries"]) {
               if (!Array.isArray(mcSyncGrpData["vlanEntries"]))
               {
                   mcSyncGrpData["vlanEntries"] = [mcSyncGrpData["vlanEntries"]];
               }
               var vlanEntriesToBeDeleted = [];
               for (var i = 0; i < vlanEntrySaveTopology.length; i++) {
                   var vlanEntrySaveTopologyItem = vlanEntrySaveTopology[i];
                   var deleteFlag = true;

                   for (var index in mcSyncGrpData["vlanEntries"]) {
                       var vlanEntryAObjectFullName = "network:" + endpointAsiteId + ":mc-peer-manager:peer-" + endpointBInterfaceAddress + ":synch:port-" + mcSyncGrpData["firstSitePortName"] +":"+mcSyncGrpData["vlanEntries"][index]["minOuterEncapValue"]+".0-"+mcSyncGrpData["vlanEntries"][index]["maxOuterEncapValue"]+".0";
                       vlanEntryAObjectFullName = util.modifyNeIdForIpV6(vlanEntryAObjectFullName, endpointAsiteId, endpointBInterfaceAddress);

                       if (vlanEntrySaveTopologyItem === vlanEntryAObjectFullName) {
                           deleteFlag = false;
                           break;
                       }
                   }
                   if (deleteFlag && vlanEntrySaveTopologyItem.indexOf(":synch:port-") > -1) {
                       vlanEntriesToBeDeleted.push(vlanEntrySaveTopologyItem);
                   }
               }

               for (var index in vlanEntriesToBeDeleted)
               {
                   this.syncDeleteVlanEntry(vlanEntriesToBeDeleted[index]);
               }
               vlanEntrySaveTopology=[];

               for (var index in mcSyncGrpData["vlanEntries"]) {
                   var vlanEntryData = mcSyncGrpData["vlanEntries"][index];
                   var vlanFullClassName = "multichassis.PeerSynchronizationPortEncapRange";
                   var vlanEntryProperties = {}

                   var vlanEntrySiteAFdn = "network:" + endpointAsiteId + ":mc-peer-manager:peer-" + endpointBInterfaceAddress + ":synch:port-" + mcSyncGrpData["firstSitePortName"];
                   vlanEntrySiteAFdn = util.modifyNeIdForIpV6(vlanEntrySiteAFdn, endpointAsiteId, endpointBInterfaceAddress);
                   var vlanEntrySiteBFdn = "network:" + endpointBsiteId + ":mc-peer-manager:peer-" + endpointAInterfaceAddress + ":synch:port-" + mcSyncGrpData["secondSitePortName"];
                   vlanEntrySiteBFdn = util.modifyNeIdForIpV6(vlanEntrySiteBFdn, endpointBsiteId, endpointAInterfaceAddress);
                   var vlanEntrySiteAObjectFullName = vlanEntrySiteAFdn +":"+vlanEntryData["minOuterEncapValue"]+".0-"+vlanEntryData["maxOuterEncapValue"]+".0";
                   var vlanEntrySiteBObjectFullName = vlanEntrySiteBFdn +":"+vlanEntryData["minOuterEncapValue"]+".0-"+vlanEntryData["maxOuterEncapValue"]+".0";

                   entry = topologyFactory.createTopologyXtraInfoFrom(vlanEntrySiteAObjectFullName, JSON.stringify(mcSyncGrpData["vlanEntries"]));
                   savedTopology.addXtraInfo(entry);
                   entry = topologyFactory.createTopologyXtraInfoFrom(vlanEntrySiteBObjectFullName, JSON.stringify(mcSyncGrpData["vlanEntries"]));
                   savedTopology.addXtraInfo(entry);

                   vlanEntryProperties["minOuterEncapValue"] = vlanEntryData["minOuterEncapValue"];
                   vlanEntryProperties["maxOuterEncapValue"] = vlanEntryData["maxOuterEncapValue"];
                   if(!isAudit)
                   {
                       vlanEntryProperties["maxInnerEncapValue"] = 0;
                       vlanEntryProperties["minInnerEncapValue"] = 0;
                       vlanEntryProperties["tag"] = mcSyncGrpData["tag"];
                       vlanEntryProperties["type"] = "dot1q";
                   }

                   var vlanEntryChildProperties = {}

                   var vlanEntryAPayload = this.McGrpEditPayload(vlanEntrySiteAFdn, vlanEntryProperties, vlanEntryChildProperties, vlanFullClassName, vlanEntrySiteAObjectFullName);
                   if (!isAudit) {
                       logger.info("Sending modify request for First Site Vlan Entry");
                       this.modifyRequest(neId, vlanEntryAPayload);
                   } else {
                       logger.info("Sending audit request for First Site Vlan Entry");
                      this.updateAuditResult(this.auditRequest(neId, vlanEntryAPayload));
                   }

                   var vlanEntryBPayload = this.McGrpEditPayload(vlanEntrySiteBFdn, vlanEntryProperties, vlanEntryChildProperties, vlanFullClassName, vlanEntrySiteBObjectFullName);
                   if (!isAudit) {
                       logger.info("Sending modify request for Second Site Vlan Entry");
                       this.modifyRequest(neId, vlanEntryBPayload);
                   } else {
                       logger.info("Sending audit request for Second Site Vlan Entry");
                      this.updateAuditResult(this.auditRequest(neId, vlanEntryBPayload));
                   }
               }
           }
        }
    }

    this.syncDeleteMcSyncGroup = function (objectFullName) {
        logger.info("Deleting MC-Sync Group: " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
    }

    this.syncDeleteVlanEntry = function (objectFullName) {
        logger.info("Deleting Vlan Entry : " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
    }

    this.syncDeleteMcIpsecDomain = function (objectFullName) {
        logger.info("Deleting MC-Endpoint : " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
    }

    this.syncDeleteMcIpsec = function (objectFullName) {
        logger.info("Deleting MC-IPSec : " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
    }

    this.modifyRequest = function (neId, payload) {
        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.syncDeleteMcEndpoint = function (objectFullName) {
        logger.info("Deleting MC-Endpoint : " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
    }

    this.syncDeleteMcLag = function (objectFullName) {
        logger.info("Deleting MC-Lag : " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
    }

    this.syncDelete = function (input, result) {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var endpointAInterfaceAddress = input.getTarget().split("#")[3];
        var endpointBInterfaceAddress = input.getTarget().split("#")[5];
        var objectFullName = "sam-mc-peer-manager:mc-peer-" + endpointAInterfaceAddress + "-" + endpointBInterfaceAddress;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, endpointAInterfaceAddress, endpointBInterfaceAddress);
        logger.info("Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }

    this.audit = function (target, config, svcTopo, adminState, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        logger.info("Audit =\n" + target + "----------" + config + "----------" + svcTopo + "----------" + adminState + "----------" + auditReport + "----------" + intentTypeName + "----------" + parentXpath + "----------" + initialPropertyName + "----------" + uniqueIdentifier);
        isAudit = true;
        var neId = parseTarget.getNeIdFromTarget(target);
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        intentConfig["firstSiteId"] = target.split("#")[2];
        intentConfig["firstSiteSourceIpAddress"] = target.split("#")[3];
        intentConfig["secondSiteId"] = target.split("#")[4];
        intentConfig["endpointB-interfaceAddress"] = target.split("#")[5];
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        if (intentConfig)
        {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }

        return auditReport
    }

    this.auditAndCompare = function (neId, intentConfig, auditReport) {
        var deviceType = util.getIxrType(neId);
        var deviceTypeB = util.getIxrType(intentConfig["secondSiteId"]);
        this.createMcPeerPayLoad(neId, intentConfig, true);
        this.createMcLagPeerSpecificsPayLoad(neId, intentConfig);
        if(!deviceType["type"].startsWith("7250 IXR") && !deviceType["type"].startsWith("7705 SAR"))
        {
            this.createMcLagPayLoad(neId, intentConfig);
            this.createMcEndPointPayLoad(neId, intentConfig);
        }
        if( !deviceType["type"].startsWith("7250 IXR") && !deviceType["type"].startsWith("7750-SRa4") && !deviceType["type"].startsWith("7750-SRa8") && !deviceType["type"].startsWith("7950 XRS") && !deviceType["type"].startsWith("7950-XRS") && !deviceType["type"].startsWith("7750 SAR") &&
            !deviceTypeB["type"].startsWith("7250 IXR") && !deviceTypeB["type"].startsWith("7750-SRa4") && !deviceTypeB["type"].startsWith("7750-SRa8") && !deviceTypeB["type"].startsWith("7950 XRS") && !deviceTypeB["type"].startsWith("7950-XRS") && !deviceTypeB["type"].startsWith("7750 SAR")){            this.createMcPeerIpsecPayLoad(neId, intentConfig);
            this.createMcIpsecGrpPayLoad(neId, intentConfig);
        }
        this.createMcSyncGrpPayload(neId, intentConfig);
        this.createMcRingGrpPayload(neId, intentConfig);
        logger.info("Final audit result =\n" + JSON.stringify(auditResult))
        auditReport = util.reportMisaligned(neId, auditResult, auditReport);
        return auditReport;
    }

    this.auditRequest = function (neId, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.updateAuditResult = function (aInAuditResult) {
        var resultResp = JSON.parse(aInAuditResult.response);
        var misalignedAttributes = resultResp.misalignedAttributes;
        if (Object.keys(auditResult).length === 0)
        {
            auditResult = resultResp;
        }
        else
        {
            if (misalignedAttributes.length > 0)
            {
                auditResult.misalignedAttributes = auditResult.misalignedAttributes.concat(misalignedAttributes);
                auditResult.aligned = false;
            }
        }
    }
}
