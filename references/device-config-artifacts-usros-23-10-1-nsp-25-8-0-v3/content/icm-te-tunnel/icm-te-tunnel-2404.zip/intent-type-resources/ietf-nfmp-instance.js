load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'mediator-fwk.js'});
NFMPInstance.prototype.imLogger = null;
NFMPInstance.prototype.nfmpMediator = null;
NFMPInstance.prototype.ietfUtil = new IetfUtilities();
NFMPInstance.prototype.pathValues = {};
NFMPInstance.prototype.nspMediator = new MediatorFramework("NSP");


load({script: resourceProvider.getResource("color-mapping.js"),name: "color-mapping"});
colorAdminTagMapping = new ColorMapping().colorMapping();

function NFMPInstance(deviceId)  {
    this.imLogger = new IntentLogger();
    this.nfmpMediator = ietfUtils.getNfmpMediator(deviceId);
}

NFMPInstance.prototype.setImLogger = function (logger) {
    this.imLogger = logger;
    this.ietfUtil.setImLogger(logger);
    this.nfmpMediator.setImLogger(logger);
};

NFMPInstance.prototype.deploySync = function (requestContext, results, device, nfmpTunnelId, neType) {
    this.imLogger.info("[ietf-nfmp-instance][deploySync]  {} ", device);
    this.pathValues = {
        "bandwidth": {},
        "hopcount": {},
        "setupPriority": {},
        "holdPriority": {},
        "isStandby": {},
        "isSrlg": {},
        "includeAdminGroup": {},
        "excludeAdminGroup": {}
    };

    var config = requestContext.get("intentConfigJson");
    config["nfmpTunnelId"] = requestContext.get("nfmpTunnelId");
    var destination = config["destination"];
    if (destination === device && config["bidirectional"]) {
        destination = config["source"];
    }

    //PATH
    //This needs to be sent to NFMP mediator using pass-through API
    this.deployPath(requestContext, device, destination);

    //LSP
    var lspTopoFdn = this.ietfUtil.getExtraInfo("lsp_" + device, requestContext.get("currentTopology"));
    if (nfmpTunnelId)
        config["nfmpTunnelId"] = parseInt(nfmpTunnelId);
    else {
        nfmpTunnelId = this.getIdFromFdn(this.ietfUtil.getExtraInfo("lsp_" + device, requestContext.get("currentTopology")));
        if (nfmpTunnelId)
            config["nfmpTunnelId"] = parseInt(nfmpTunnelId);
        else
            throw new RuntimeException('NSP NFMP tunnelId for source cannot be resolved ' + device);
    }

    if (config["association-objects"] && config["association-objects"]["association-object-extended"] && config["association-objects"]["association-object-extended"][0]) {
        config["path-profile"] = config["association-objects"]["association-object-extended"][0]["id"];
        if (config["association-objects"]["association-object-extended"][0]["extended-id"])
            config["path-group"] = parseInt(config["association-objects"]["association-object-extended"][0]["extended-id"].replace(":", ''), 16);
    }
    if(config["color"])
    {
        config["color"] = colorAdminTagMapping[config["color"]];
    }

    var lspPayload = this.objectPayload("NFMP/lsp.ftl", requestContext.get("target"), config, device, destination, this.populatePathObjForLsp(false, requestContext, device), requestContext.get("sourceNodeId")[device], requestContext.get("sourceNodeId")[destination]);
    if (lspTopoFdn) {
        lspPayload["objectFullName"] = lspTopoFdn;
    }
    //Augment to enable egress monitoring to on always
    if(neType.indexOf("IXR") == -1) {
        this.imLogger.debug("[ietf-nfmp-instance][deploySync] enable egress monitoring");
        if (lspPayload["childConfigInfo"]["mpls.DynamicLsp"]) {
            lspPayload["childConfigInfo"]["mpls.DynamicLsp"]["egrAccountingAdminState"] = "lspUp";
        } else if (lspPayload["childConfigInfo"]["mpls.SegmentRoutingTeLsp"]) {
            lspPayload["childConfigInfo"]["mpls.SegmentRoutingTeLsp"]["egrAccountingAdminState"] = "lspUp";
        }
    }

    //Adding actionMask delete to association-object
    if (Object.keys(config['association-objects']).length === 0) {
        if (lspPayload["childConfigInfo"]["mpls.DynamicLsp"]) {
            lspPayload["childConfigInfo"]["mpls.DynamicLsp"]["children-Set"]["mpls.PathProfile"] = {"actionMask": {"bit": ["delete"]}};
        } else if (lspPayload["childConfigInfo"]["mpls.SegmentRoutingTeLsp"]) {
            lspPayload["childConfigInfo"]["mpls.SegmentRoutingTeLsp"]["children-Set"]["mpls.PathProfile"] = {"actionMask": {"bit": ["delete"]}};
        }
    }

    var lspResponse = this.send("/v3/synchronize", lspPayload);
    if (!lspTopoFdn && lspResponse && lspResponse["mpls.DynamicLsp"] && lspResponse["mpls.DynamicLsp"]["objectFullName"]) {
        requestContext.get("currentTopology").addXtraInfo(topologyFactory.createTopologyXtraInfoFrom("lsp_" + device, lspResponse["mpls.DynamicLsp"]["objectFullName"]));
    } else if (!lspTopoFdn && lspResponse && lspResponse["mpls.SegmentRoutingTeLsp"] && lspResponse["mpls.SegmentRoutingTeLsp"]["objectFullName"]) {
        requestContext.get("currentTopology").addXtraInfo(topologyFactory.createTopologyXtraInfoFrom("lsp_" + device, lspResponse["mpls.SegmentRoutingTeLsp"]["objectFullName"]));
    }

    return results;
};

NFMPInstance.prototype.getPathName = function (pathType, lspName, pathName, requestContext) {
    if (pathType === "primary") {
        if (pathName.indexOf(lspName + "_") !== -1) {
            return pathName;
        } else if (requestContext && requestContext.get("isBF")) {
            return pathName;
        } else {
            return lspName + "_" + pathName
        }
    } else {
        this.imLogger.info("[ietf-nfmp-instance][getPathName] secondary name contains {}", pathName.indexOf("_secondary_"));
        if (pathName.indexOf("_secondary_") !== -1) {
            return pathName;
        } else if (requestContext && requestContext.get("isBF")) {
            return pathName;
        } else {
            return lspName + "_secondary_" + pathName;
        }
    }
};

NFMPInstance.prototype.deployPath = function (requestContext, device, destination) {
    var config = requestContext.get("intentConfigJson");
    this.imLogger.info("[ietf-nfmp-instance][deployPath]  {} ", JSON.stringify(config, null, 2));

    var deviceTopoObj = this.ietfUtil.getExtraInfo("nfmpFdn_" + device, requestContext.get("currentTopology"));
    if (deviceTopoObj) deviceTopoObj = JSON.parse(deviceTopoObj);

    if (!config["primary-paths"] || !config["primary-paths"]["primary-path"]) {
        //common hopless - No primary path specified - uni
        this.imLogger.debug("[ietf-nfmp-instance][deployPath] common hopless - No primary path specified {}", device);
        this.checkAndDeployHopless(config, requestContext, device, destination);
    } else {
        var primaryConf = config["primary-paths"]["primary-path"][0];
        //Bi-directional checks
        if (config["destination"] === device && config["bidirectional"]) {

            //common hopless - No primary path specified - reverse
            if (!primaryConf["primary-reverse-path"] || primaryConf["primary-reverse-path"] === "" || (primaryConf["primary-reverse-path"] && !primaryConf["primary-reverse-path"]["name"])) {
                this.checkAndDeployHopless(config, requestContext, device, destination);
            } else {
                //if route-object-include-exclude doesnt exists, then init empty array to avoid freemarker failures
                if (primaryConf["primary-reverse-path"]["explicit-route-objects-always"] === "") primaryConf["primary-reverse-path"]["explicit-route-objects-always"] = {};
                if (!primaryConf["primary-reverse-path"]["explicit-route-objects-always"]["route-object-include-exclude"]
                    || primaryConf["primary-reverse-path"]["explicit-route-objects-always"]["route-object-include-exclude"] === "")
                    primaryConf["primary-reverse-path"]["explicit-route-objects-always"]["route-object-include-exclude"] = [];

                //Explicit reverse path
                this.deployModifyPath(primaryConf["primary-reverse-path"], "primary", requestContext, device, destination, deviceTopoObj);

            }
        } else {

            //if route-object-include-exclude doesnt exists, then init empty array to avoid freemarker failures
            if (primaryConf["explicit-route-objects-always"] === "") primaryConf["explicit-route-objects-always"] = {};
            if (!primaryConf["explicit-route-objects-always"]["route-object-include-exclude"]
                || primaryConf["explicit-route-objects-always"]["route-object-include-exclude"] === "")
                primaryConf["explicit-route-objects-always"]["route-object-include-exclude"] = [];

            //Explicit path
            this.deployModifyPath(primaryConf, "primary", requestContext, device, destination, deviceTopoObj);
        }
    }

    //Secondary path
    if (config["source"] === device && config["secondary-paths"] && config["secondary-paths"]["secondary-path"]) {
        for (var i = 0; i < config["secondary-paths"]["secondary-path"].length; i++) {
            //if route-object-include-exclude doesnt exists, then init empty array to avoid freemarker failures
            if (config["secondary-paths"]["secondary-path"][i]["explicit-route-objects-always"] === "") config["secondary-paths"]["secondary-path"][i]["explicit-route-objects-always"] = {};
            if (!config["secondary-paths"]["secondary-path"][i]["explicit-route-objects-always"]["route-object-include-exclude"]
                || config["secondary-paths"]["secondary-path"][i]["explicit-route-objects-always"]["route-object-include-exclude"] === "")
                config["secondary-paths"]["secondary-path"][i]["explicit-route-objects-always"]["route-object-include-exclude"] = [];

            this.deployModifyPath(config["secondary-paths"]["secondary-path"][i], "secondary", requestContext, device, destination, deviceTopoObj);
        }
    }

    //Secondary reverse path
    if (config["destination"] === device && config["bidirectional"] && config["secondary-reverse-paths"] && config["secondary-reverse-paths"] ["secondary-reverse-path"]) {
        for (var h = 0; h < config["secondary-reverse-paths"]["secondary-reverse-path"].length; h++) {
            //if route-object-include-exclude doesnt exists, then init empty array to avoid freemarker failures
            if (config["secondary-reverse-paths"] ["secondary-reverse-path"][h]["explicit-route-objects-always"] === "") config["secondary-reverse-paths"] ["secondary-reverse-path"][h]["explicit-route-objects-always"] = {};
            if (!config["secondary-reverse-paths"] ["secondary-reverse-path"][h]["explicit-route-objects-always"]["route-object-include-exclude"]
                || config["secondary-reverse-paths"] ["secondary-reverse-path"][h]["explicit-route-objects-always"]["route-object-include-exclude"] === "")
                config["secondary-reverse-paths"] ["secondary-reverse-path"][h]["explicit-route-objects-always"]["route-object-include-exclude"] = [];

            this.deployModifyPath(config["secondary-reverse-paths"]["secondary-reverse-path"][h], "secondary", requestContext, device, destination, deviceTopoObj);
        }
    }

};

NFMPInstance.prototype.checkAndDeployHopless = function (config, requestContext, device, destination) {
    this.imLogger.debug("[ietf-nfmp-instance][deployPath] deploy new hopless path", device);
    var payload = {
        "fullClassName": "mpls.Tunnel",
        "filter": {
            "and": {
                "equal": [{"name": "displayedName", "value": "hopless"}, {
                    "name": "sourceNodeId",
                    "value": requestContext.get("sourceNodeId")[device]
                }]
            }
        },
        "resultFilter": {"attribute": ["objectFullName", "provisionedPathId"], "children": {}}
    };
    var tunnelResults = this.nfmpMediator.post("/v3/search", payload);
    if (config["te-bandwidth"] && config["te-bandwidth"]["generic"]) {
        this.pathValues.bandwidth[device + "_hopless"] = Math.round(parseInt(config["te-bandwidth"]["generic"]) / 1000000);
    }
    this.pathValues.setupPriority[device + "_hopless"] = config["setup-priority"];
    this.pathValues.holdPriority[device + "_hopless"] = config["hold-priority"];
    if (config["restoration"] && config["restoration"]["enable"] && config["restoration"]["restoration-scheme"] === "restoration-scheme-presignaled") {
        this.pathValues.isStandby[device + "_" + pathConfig["name"]] = true;
    }
    if (config["disjointness"] && config["disjointness"] === "srlg") {
        this.pathValues.isSrlg[device + "_" + pathConfig["name"]] = true;
    }
    this.computeAdminGroup(config, device, device + "_hopless", requestContext.get("sourceNodeId")[device]);
    if (tunnelResults.success && tunnelResults["response"] && tunnelResults["response"]["mpls.Tunnel"]) {
        var lObj = {"hopless": {"hopless": {"pathDn": "N/A"}}};
        lObj["hopless"]["hopless"]["tunnelDn"] = tunnelResults["response"]["mpls.Tunnel"]["objectFullName"];
        this.ietfUtil.setTopologyExtraInfo(requestContext.get("currentTopology"), "nfmpFdn_" + device, JSON.stringify(lObj));
    } else {
        var pathPayload = this.objectPayload("NFMP/path.ftl", requestContext.get("target"), requestContext.get("intentConfigJson"), device, destination, {"name": "hopless"}, requestContext.get("sourceNodeId")[device]);
        this.deployNewPath(pathPayload, requestContext, device, "hopless", "hopless");
    }
};

NFMPInstance.prototype.computeAdminGroup = function (config, siteId, key, sourceNodeId) {
    var self = this;
    if (config["path-affinity-names"] && config["path-affinity-names"]["path-affinity-name"]) {
        config["path-affinity-names"]["path-affinity-name"].forEach(function (type) {
            if (type["usage"] === "resource-aff-include-any" && type["affinity-name"]) {
                type["affinity-name"].forEach(function (name) {
                    if (!self.pathValues.includeAdminGroup[key]) self.pathValues.includeAdminGroup[key] = 0;
                    self.pathValues.includeAdminGroup[key] += Math.pow(2, self.fetchAdminGroupVal(name["name"], siteId, sourceNodeId));
                })
            }
            if (type["usage"] === "resource-aff-exclude-any" && type["affinity-name"]) {
                type["affinity-name"].forEach(function (name) {
                    if (!self.pathValues.excludeAdminGroup[key]) self.pathValues.excludeAdminGroup[key] = 0;
                    self.pathValues.excludeAdminGroup[key] += Math.pow(2, self.fetchAdminGroupVal(name["name"], siteId, sourceNodeId));
                })
            }
        });
        this.imLogger.info("[ietf-nfmp-instance][computeAdminGroup] includeAdminGroup {} excludeAdminGroup {}", JSON.stringify(this.pathValues.includeAdminGroup), JSON.stringify(this.pathValues.excludeAdminGroup));
    }
};

NFMPInstance.prototype.fetchAdminGroupVal = function (displayedName, siteId, sourceNodeId) {
    var payload = {
        "fullClassName": "rtr.AdminGroupPolicy",
        "filter": {
            "and": {
                "equal": [
                    {
                        "name": "displayedName",
                        "value": displayedName
                    },
                    {
                        "name": "siteId",
                        "value": sourceNodeId
                    }
                ]
            }
        },
        "resultFilter": {
            "attribute": [
                "value",
                "isLocal"
            ],
            "children": {}
        }
    };

    var results = this.nfmpMediator.post("/v3/search", payload);
    if (!results.success) {
        throw new RuntimeException(results.msg);
    } else {
        if (results.response["rtr.AdminGroupPolicy"] && results.response["rtr.AdminGroupPolicy"]["value"])
            return parseInt(results.response["rtr.AdminGroupPolicy"]["value"]);
        else
            throw new RuntimeException("Didnt find AdminGroupPolicy name " + displayedName + " Node " + siteId);
    }
};

NFMPInstance.prototype.deployModifyPath = function (pathConfig, pathType, requestContext, device, destination, deviceTopoObj) {
    pathConfig["name"] = this.getPathName(pathType, requestContext.get("target"), pathConfig["name"], requestContext);
    if (pathConfig["te-bandwidth"] && pathConfig["te-bandwidth"]["generic"]) {
        this.pathValues.bandwidth[device + "_" + pathConfig["name"]] = Math.round(parseInt(pathConfig["te-bandwidth"]["generic"]) / 1000000);
    }

    if (pathConfig["path-metric-bounds"] && pathConfig["path-metric-bounds"]["path-metric-bound"] && pathConfig["path-metric-bounds"]["path-metric-bound"][0]["metric-type"] &&
        pathConfig["path-metric-bounds"]["path-metric-bound"][0]["metric-type"] && pathConfig["path-metric-bounds"]["path-metric-bound"][0]["metric-type"] === "path-metric-hop") {
        this.pathValues.hopcount[device + "_" + pathConfig["name"]] = parseInt(pathConfig["path-metric-bounds"]["path-metric-bound"][0]["upper-bound"]);
    }
    this.pathValues.setupPriority[device + "_" + pathConfig["name"]] = pathConfig["setup-priority"];
    this.pathValues.holdPriority[device + "_" + pathConfig["name"]] = pathConfig["hold-priority"];

    if (pathConfig["restoration"] && pathConfig["restoration"]["enable"] && pathConfig["restoration"]["restoration-scheme"] === "restoration-scheme-presignaled") {
        this.pathValues.isStandby[device + "_" + pathConfig["name"]] = true;
    }

    if (pathConfig["disjointness"] && pathConfig["disjointness"] === "srlg") {
        this.pathValues.isSrlg[device + "_" + pathConfig["name"]] = true;
    }
    this.computeAdminGroup(pathConfig, device, device + "_" + pathConfig["name"], requestContext.get("sourceNodeId")[device]);
    this.imLogger.info("[ietf-nfmp-instance][deployModifyPath] pathValues {}", JSON.stringify(this.pathValues));
    this.imLogger.info("[ietf-nfmp-instance][deployModifyPath] pathConfig {}", JSON.stringify(pathConfig));
    var pathPayload = this.objectPayload("NFMP/path.ftl", requestContext.get("target"), requestContext.get("intentConfigJson"), device, destination, pathConfig, requestContext.get("sourceNodeId")[device]);

    //Modify payload
    this.imLogger.info("[ietf-nfmp-instance][deployModifyPath] deviceTopoObj {}", JSON.stringify(deviceTopoObj));
    if (deviceTopoObj && deviceTopoObj[pathType] && deviceTopoObj[pathType][pathConfig["name"]]) {
        if (deviceTopoObj[pathType][pathConfig["name"]]["pathDn"] && deviceTopoObj[pathType][pathConfig["name"]]["pathDn"] !== "N/A") {
            pathPayload["mpls.Tunnel.configureTunnelAndPath"]["pathConfigInfo"]["mpls.ProvisionedPath"]["objectFullName"] = deviceTopoObj[pathType][pathConfig["name"]]["pathDn"];
            delete pathPayload["mpls.Tunnel.configureTunnelAndPath"]["pathConfigInfo"]["mpls.ProvisionedPath"]["pathId"];
            delete pathPayload["mpls.Tunnel.configureTunnelAndPath"]["pathConfigInfo"]["mpls.ProvisionedPath"]["destinationNodeId"];
            delete pathPayload["mpls.Tunnel.configureTunnelAndPath"]["pathConfigInfo"]["mpls.ProvisionedPath"]["sourceNodeId"];
            pathPayload["mpls.Tunnel.configureTunnelAndPath"]["pathConfigInfo"]["mpls.ProvisionedPath"]["actionMask"] = {"bit": "modify"};
            if (pathPayload["mpls.Tunnel.configureTunnelAndPath"]["pathConfigInfo"]["mpls.ProvisionedPath"]["children-Set"] &&
                pathPayload["mpls.Tunnel.configureTunnelAndPath"]["pathConfigInfo"]["mpls.ProvisionedPath"]["children-Set"]["mpls.ProvisionedHop"]) {
                pathPayload["mpls.Tunnel.configureTunnelAndPath"]["pathConfigInfo"]["mpls.ProvisionedPath"]["children-Set"]["mpls.ProvisionedHop"].forEach(function (path) {
                    path["actionMask"] = {"bit": ["create", "modify"]};
                })
            }
        }

        if (deviceTopoObj[pathType][pathConfig["name"]]["tunnelDn"] && deviceTopoObj[pathType][pathConfig["name"]]["tunnelDn"] !== "N/A") {
            pathPayload["mpls.Tunnel.configureTunnelAndPath"]["tunnelConfigInfo"]["mpls.Tunnel"]["objectFullName"] = deviceTopoObj[pathType][pathConfig["name"]]["tunnelDn"];
            pathPayload["mpls.Tunnel.configureTunnelAndPath"]["tunnelConfigInfo"]["mpls.Tunnel"]["provisionedPathId"] = this.getIdFromFdn(deviceTopoObj[pathType][pathConfig["name"]]["tunnelDn"]);
            delete pathPayload["mpls.Tunnel.configureTunnelAndPath"]["tunnelConfigInfo"]["mpls.Tunnel"]["pathId"];
            delete pathPayload["mpls.Tunnel.configureTunnelAndPath"]["tunnelConfigInfo"]["mpls.Tunnel"]["destinationNodeId"];
            delete pathPayload["mpls.Tunnel.configureTunnelAndPath"]["tunnelConfigInfo"]["mpls.Tunnel"]["sourceNodeId"];
            pathPayload["mpls.Tunnel.configureTunnelAndPath"]["tunnelConfigInfo"]["mpls.Tunnel"]["actionMask"] = {"bit": "modify"};
        }
    }

    this.deployNewPath(pathPayload, requestContext, device, pathType, pathConfig["name"]);
};

NFMPInstance.prototype.deployNewPath = function (pathPayload, requestContext, device, pathType, name) {
    var pathRes = this.send("/rest/api/v3/request", pathPayload);
    try {
        var deviceTopoObj = this.ietfUtil.getExtraInfo("nfmpFdn_" + device, requestContext.get("currentTopology"));
        (!deviceTopoObj) ? deviceTopoObj = {} : deviceTopoObj = JSON.parse(deviceTopoObj);

        var pathDn = pathRes["mpls.Tunnel.configureTunnelAndPathResponse"]["result"]["mpls.TunnelAndPathResult"]["pathDn"];
        var tunnelDn = pathRes["mpls.Tunnel.configureTunnelAndPathResponse"]["result"]["mpls.TunnelAndPathResult"]["tunnelDn"];
        if (!deviceTopoObj[pathType]) deviceTopoObj[pathType] = {};
        deviceTopoObj[pathType][name] = {"tunnelDn": tunnelDn, "pathDn": pathDn};

        this.ietfUtil.setTopologyExtraInfo(requestContext.get("currentTopology"), "nfmpFdn_" + device, JSON.stringify(deviceTopoObj));

        this.imLogger.info("[ietf-nfmp-instance][deploySync] updated currentTopology {}", requestContext.get("currentTopology"));
        requestContext.put("currentTopology", requestContext.get("currentTopology"));
    } catch (e) {
        throw new RuntimeException("resolving path object failed  " + e);
    }
};

NFMPInstance.prototype.deleteSync = function (requestContext, results, device) {
    this.imLogger.info("MDM Instance deleteSync - " + device);

    var currentTopo = requestContext.get("currentTopology");
    this.imLogger.info("[ietf-nfmp-instance][deleteSync] currentTopology {}", currentTopo);
    var type = "rsvp";
    if (requestContext.get("intentConfigJson")["signaling-type"] === "path-setup-sr") {
        type = "srte";
    }
    var nfmpTunnelId = parseInt(this.getIdFromFdn(this.ietfUtil.getExtraInfo("lsp_" + device, requestContext.get("currentTopology"))));
    if (!nfmpTunnelId)
        throw new RuntimeException('NSP NFMP tunnelId for source cannot be resolved ' + device);
    try {
        //LSP
        this.execDeleteSyn(this.ietfUtil.getExtraInfo("lsp_" + device, currentTopo));

        //PATH
        var deviceTopoObj = this.ietfUtil.getExtraInfo("nfmpFdn_" + device, currentTopo);
        this.imLogger.info("[ietf-nfmp-instance][deleteSync] deviceTopoObj {}", deviceTopoObj);
        if (deviceTopoObj) {
            deviceTopoObj = JSON.parse(deviceTopoObj);
            var self = this;
            Object.keys(deviceTopoObj).forEach(function (key) {
                if (key !== "hopless") {
                    self.imLogger.info("[ietf-nfmp-instance][deleteSync] {}", JSON.stringify(deviceTopoObj[key]));
                    Object.keys(deviceTopoObj[key]).forEach(function (pathName) {
                        self.imLogger.info("[ietf-nfmp-instance][deleteSync] {}", JSON.stringify(deviceTopoObj[key][pathName]["tunnelDn"]));
                        self.execDeleteSyn(deviceTopoObj[key][pathName]["tunnelDn"]);
                    })
                }
            })
        }

        //Resource Pool
        self.deleteResourse(device, type, nfmpTunnelId)
    } catch (e) {
        this.imLogger.error(e);
    }



    return results;
};

NFMPInstance.prototype.execDeleteSyn = function (fdn) {
    if (fdn) {
        this.imLogger.info("[ietf-nfmp-instance][execDeleteSyn] fdn : {}", fdn);
        var jsonResponse = this.nfmpMediator.delete("/v3/delete/" + fdn);
        if (!jsonResponse.success) {
            this.imLogger.error("Deletion failed for {} response {}", fdn, jsonResponse.response);
            throw new RuntimeException(jsonResponse.response);
        }
    }
};

NFMPInstance.prototype.deleteResourse = function (deviceId, type, nfmpTunnelId) {
    this.imLogger.debug("[ietf-nfmp-instance][deleteResourse] Releasing resource {}", nfmpTunnelId);

    var response = this.nspMediator.post("https://restconf-gateway:443/restconf/data/nsp-resource-pool:resource-pools/numeric-resource-pools=ietf-tunnel-global-id-pool,ietf_" + deviceId + "_" + type + "/release-values", {
        "nsp-resource-pool:input": {
            "values": [nfmpTunnelId]
        }
    });

    if (!response.success) {
        this.imLogger.error("[ietf-nfmp-instance][deleteResourse] Failed to release resource : {}", JSON.stringify(response));
        throw new RuntimeException("Failed to release resource");
    } else {
        this.imLogger.debug("[RestconfFwk][createService] Successfully released resource");
    }
};

NFMPInstance.prototype.audit = function (requestContext, device, auditReport, neType) {
    this.pathValues = {
        "bandwidth": {},
        "hopcount": {},
        "setupPriority": {},
        "holdPriority": {},
        "isStandby": {},
        "isSrlg": {},
        "includeAdminGroup": {},
        "excludeAdminGroup": {}
    };
    var config = requestContext.get("intentConfigJson");
    var isBrownfield = false;

    var lspInfo = null;
    try {
        lspInfo = this.ietfUtil.getExtraInfo("lsp_" + device, requestContext.get("currentTopology"));
        lspInfo = lspInfo.split("-");
        config["nfmpTunnelId"] = parseInt(lspInfo[lspInfo.length - 1]);
    } catch (e) {
        this.imLogger.info("audit: Failed to retrieve pathId, reason: {}\nSetting via requestContext", e);
        config["nfmpTunnelId"] = parseInt(requestContext.get("nfmpTunnelId"));
        isBrownfield = true;
    }

    var destination = config["destination"];
    if (destination === device && config["bidirectional"]) {
        destination = config["source"];
    }
    if (config["association-objects"] && config["association-objects"]["association-object-extended"] && config["association-objects"]["association-object-extended"][0]) {
        config["path-profile"] = config["association-objects"]["association-object-extended"][0]["id"];
        if (config["association-objects"]["association-object-extended"][0]["extended-id"])
            config["path-group"] = parseInt(config["association-objects"]["association-object-extended"][0]["extended-id"].replace(":", ''), 16);
    }
    if(config["color"])
    {
        config["color"] = colorAdminTagMapping[config["color"]];
    }
    if (isBrownfield) {
        this.updatePathNames(config, requestContext);
    }

    var deviceTopoObj = this.ietfUtil.getExtraInfo("nfmpFdn_" + device, requestContext.get("currentTopology"));
    if (deviceTopoObj) deviceTopoObj = JSON.parse(deviceTopoObj);
    if (!config["primary-paths"] && !config["secondary-paths"] && !config["secondary-reverse-paths"]) {
        var lObj = {};
        lObj["name"] = "hopless";
        if (config["te-bandwidth"] && config["te-bandwidth"]["generic"]) {
            this.pathValues.bandwidth[device + "_hopless"] = Math.round(parseInt(config["te-bandwidth"]["generic"]) / 1000000);
        }
        this.pathValues.setupPriority[device + "_hopless"] = config["setup-priority"];
        this.pathValues.holdPriority[device + "_hopless"] = config["hold-priority"];
        var pathPayload = this.objectPayload("NFMP/path.ftl", requestContext.get("target"), requestContext.get("intentConfigJson"), device, destination, {"name": "hopless"}, requestContext.get("sourceNodeId")[device]);
        var pathPay = this.pathGenericPayload(pathPayload, deviceTopoObj["hopless"]["hopless"]);
        this.nfmpCompare(pathPay["tunnelConfigInfoPayload"], auditReport, requestContext.get("target"));
    } else {

        //Primary path
        if (config["primary-paths"] && config["primary-paths"]["primary-path"]) {
            var primaryConf = config["primary-paths"]["primary-path"][0];
            //Primary reverse path
            if (config["destination"] === device && config["bidirectional"] && primaryConf["primary-reverse-path"]) {
                this.auditPath(primaryConf["primary-reverse-path"], "primary", auditReport, requestContext, device, destination, deviceTopoObj);
            } else { //Primary path
                this.auditPath(primaryConf, "primary", auditReport, requestContext, device, destination, deviceTopoObj);
            }
        }

        if (config["source"] === device && config["secondary-paths"] && config["secondary-paths"]["secondary-path"]) {
            for (var i = 0; i < config["secondary-paths"]["secondary-path"].length; i++) {
                this.auditPath(config["secondary-paths"]["secondary-path"][i], "secondary", auditReport, requestContext, device, destination, deviceTopoObj);
            }
        }

        if (config["destination"] === device && config["bidirectional"] && config["secondary-reverse-paths"] && config["secondary-reverse-paths"] ["secondary-reverse-path"]) {
            for (var h = 0; h < config["secondary-reverse-paths"]["secondary-reverse-path"].length; h++) {
                this.auditPath(config["secondary-reverse-paths"] ["secondary-reverse-path"][h], "secondary", auditReport, requestContext, device, destination, deviceTopoObj);
            }
        }
    }

    var lspTopoFdn = this.ietfUtil.getExtraInfo("lsp_" + device, requestContext.get("currentTopology"));
    var lspPayload = this.objectPayload("NFMP/lsp.ftl", requestContext.get("target"), requestContext.get("intentConfigJson"), device, destination, this.populatePathObjForLsp(true, requestContext, device, deviceTopoObj), requestContext.get("sourceNodeId")[device], requestContext.get("sourceNodeId")[destination]);
    if (lspTopoFdn) {
        lspPayload["objectFullName"] = lspTopoFdn;
    } else {
        throw new RuntimeException("DIdnt resolve NFMP LSP Fdn");
    }

    //delete tunnelDestinationMatching property form lsp
    if(lspPayload["childConfigInfo"]["mpls.DynamicLsp"]) {
        delete lspPayload["childConfigInfo"]["mpls.DynamicLsp"]["tunnelDestinationMatching"];
    } else if(lspPayload["childConfigInfo"]["mpls.SegmentRoutingTeLsp"]) {
        delete lspPayload["childConfigInfo"]["mpls.SegmentRoutingTeLsp"]["tunnelDestinationMatching"];
    }

    this.nfmpCompare(lspPayload, auditReport, requestContext.get("target"));

    return auditReport;
};

/**
 * Converts the NFMP generated paths to Actual Paths
 * @param config
 * @param requestContext
 */
NFMPInstance.prototype.updatePathNames = function (config, requestContext) {
    var lspPathMap = requestContext.get("lspPathMap");
    if(config["primary-paths"]["primary-path"]) {
        var pathName = lspPathMap[config["primary-paths"]["primary-path"][0]["name"]];
        this.imLogger.info("[ietf-nfmp-instance][updatePathNames] primary path name = {}, to be mapped to = {}",
            config["primary-paths"]["primary-path"][0]["name"], pathName)
        config["primary-paths"]["primary-path"][0]["name"] = pathName;
    }
    if (config["secondary-paths"]["secondary-path"]) {
        var pathKey = lspPathMap[config["secondary-paths"]["secondary-path"][0]["name"]];
        this.imLogger.info("[ietf-nfmp-instance][updatePathNames] secondary path name = {}, to be mapped to = {}",
            config["primary-paths"]["primary-path"][0]["name"], pathName)
        config["secondary-paths"]["secondary-path"][0]["name"] = pathName;
    }
}

NFMPInstance.prototype.auditPath = function (pathConfig, pathType, auditReport, requestContext, device, destination, deviceTopoObj) {
    let deviceTopo = deviceTopoObj[pathType][pathConfig["name"]];
    if (!deviceTopo)
    {
        pathConfig["name"] = this.getPathName(pathType, requestContext.get("target"), pathConfig["name"], requestContext);
        deviceTopo = deviceTopoObj[pathType][pathConfig["name"]];
    }

    if (pathConfig["te-bandwidth"] && pathConfig["te-bandwidth"]["generic"]) {
        this.pathValues.bandwidth[device + "_" + pathConfig["name"]] = Math.round(parseInt(pathConfig["te-bandwidth"]["generic"]) / 1000000);
    }
    if (pathConfig["path-metric-bounds"] && pathConfig["path-metric-bounds"]["path-metric-bound"] && pathConfig["path-metric-bounds"]["path-metric-bound"][0]["metric-type"] && pathConfig["path-metric-bounds"]["path-metric-bound"][0]["metric-type"] && pathConfig["path-metric-bounds"]["path-metric-bound"][0]["metric-type"] === "path-metric-hop")     {
        this.imLogger.info("AUDIT: ietf-nfmp-helper: auditPath: setting hop count in pathValues");
        this.pathValues.hopcount[device + "_" + pathConfig["name"]] = parseInt(pathConfig["path-metric-bounds"]["path-metric-bound"][0]["upper-bound"]);
    }
    this.pathValues.setupPriority[device + "_" + pathConfig["name"]] = pathConfig["setup-priority"];
    this.pathValues.holdPriority[device + "_" + pathConfig["name"]] = pathConfig["hold-priority"];
    if (pathConfig["restoration"] && pathConfig["restoration"]["enable"] && pathConfig["restoration"]["restoration-scheme"] === "restoration-scheme-presignaled") {
        this.pathValues.isStandby[device + "_" + pathConfig["name"]] = true;
    }
    if (pathConfig["disjointness"] && pathConfig["disjointness"] === "srlg") {
        this.pathValues.isSrlg[device + "_" + pathConfig["name"]] = true;
    }
    this.computeAdminGroup(pathConfig, device, device + "_" + pathConfig["name"], requestContext.get("sourceNodeId")[device]);

    const pathPayload = this.objectPayload("NFMP/path.ftl", requestContext.get("target"), requestContext.get("intentConfigJson"), device, destination, pathConfig, requestContext.get("sourceNodeId")[device]);
    const pathPay = this.pathGenericPayload(pathPayload, deviceTopo);

    this.nfmpCompare(pathPay["tunnelConfigInfoPayload"], auditReport, requestContext.get("target"));
    if (Object.keys(pathPay["pathConfigInfoPayload"]).length !== 0) {
        this.nfmpCompare(pathPay["pathConfigInfoPayload"], auditReport, requestContext.get("target"));
    }
};

NFMPInstance.prototype.nfmpCompare = function (payload, auditReport, target) {
    var jsonResponse = this.nfmpMediator.post("/v3/compare", payload);
    if (jsonResponse.success) {
        this.imLogger.info("[ietf-nfmp-instance][nfmpCompare] NFMP audit results : {}", JSON.stringify(jsonResponse.response));
        if (!jsonResponse.response.aligned) {
            for (var i = 0; i < jsonResponse.response.misalignedAttributes.length; i++) {
                var attributeData = jsonResponse.response.misalignedAttributes[i];
                var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                auditReport.addMisAlignedAttribute(misalignedAttribute);
            }
        }
    } else {
        throw new RuntimeException(jsonResponse.response);
    }
};

NFMPInstance.prototype.objectPayload = function (resourceName, target, config, device, destination, extraParams, sourceNeId, destinationNeId) {
    this.imLogger.debug("[ietf-nfmp-instance][objectPayload] config {}", JSON.stringify(config));
    this.imLogger.debug("[ietf-nfmp-instance][objectPayload] extraParams {}", JSON.stringify(extraParams));
    try {
        var ret = utilityService.processTemplate(resourceProvider.getResource(resourceName), {
            "config": config,
            "target": target,
            "device": device,
            "destination": destination,
            "extraParams": extraParams,
            "sourceNeId": sourceNeId,
            "destinationNeId": destinationNeId
        });
        this.imLogger.info("[ietf-nfmp-instance][objectPayload] ret {}", ret);
        return JSON.parse(ret);
    } catch (e) {
        throw new RuntimeException("NFMP Parsing " + resourceName + " template failed for " + device + " " + e);
    }
};

NFMPInstance.prototype.send = function (url, payload) {
    var response = this.nfmpMediator.post(url, payload);
    if (!response.success || JSON.stringify(response.response).indexOf("Exception") !== -1) {
        throw new RuntimeException("Failed to deploy URL " + url + " Response - " + JSON.stringify(response.response));
    }
    return response.response;
};


NFMPInstance.prototype.pathGenericPayload = function (pathPayload, topObjFdn) {
    var pathConfigInfoPayload = {};
    var tunnelConfigInfoPayload = {};

    if (topObjFdn["tunnelDn"] && topObjFdn["tunnelDn"] !== "N/A") {
        tunnelConfigInfoPayload["configInfo"] = JSON.parse(JSON.stringify(pathPayload["mpls.Tunnel.configureTunnelAndPath"]["tunnelConfigInfo"]));
        delete tunnelConfigInfoPayload["configInfo"] ["mpls.Tunnel"]["actionMask"];
        tunnelConfigInfoPayload["objectFullName"] = topObjFdn["tunnelDn"];
        tunnelConfigInfoPayload["distinguishedName"] = "path";
        var lId = this.getIdFromFdn(tunnelConfigInfoPayload["objectFullName"]);
        tunnelConfigInfoPayload["configInfo"] ["mpls.Tunnel"]["pathId"] = lId;
        this.imLogger.info("[ietf-nfmp-instance][pathGenericPayload] tunnelConfigInfoPayload = {}", JSON.stringify(tunnelConfigInfoPayload));
    }

    if (topObjFdn["pathDn"] && topObjFdn["pathDn"] !== "N/A") {
        pathConfigInfoPayload["configInfo"] = JSON.parse(JSON.stringify(pathPayload["mpls.Tunnel.configureTunnelAndPath"]["pathConfigInfo"]));
        delete pathConfigInfoPayload["configInfo"] ["mpls.ProvisionedPath"]["actionMask"];
        delete pathConfigInfoPayload["configInfo"] ["mpls.ProvisionedPath"]["destinationNodeId"];
        if (pathConfigInfoPayload["configInfo"] ["mpls.ProvisionedPath"]["children-Set"]["mpls.ProvisionedHop"]) {
            pathConfigInfoPayload["configInfo"] ["mpls.ProvisionedPath"]["children-Set"]["mpls.ProvisionedHop"].forEach(function (path) {
                delete path["actionMask"];
            })
        }
        pathConfigInfoPayload["objectFullName"] = topObjFdn["pathDn"];
        pathConfigInfoPayload["distinguishedName"] = "path";
        pathConfigInfoPayload["configInfo"] ["mpls.ProvisionedPath"]["pathId"] = lId;
        this.imLogger.info("[ietf-nfmp-instance][deploySync] pathConfigInfoPayload {}", JSON.stringify(pathConfigInfoPayload));
    }

    return {"pathConfigInfoPayload": pathConfigInfoPayload, "tunnelConfigInfoPayload": tunnelConfigInfoPayload}
};

NFMPInstance.prototype.getIdFromFdn = function (fdn) {
    if (fdn) {
        var id = fdn.split("-");
        return id[id.length - 1];
    }
};

NFMPInstance.prototype.populatePathObjForLsp = function (isAudit,requestContext, device, deviceTopoObj) {
    if (!deviceTopoObj) {
        deviceTopoObj = this.ietfUtil.getExtraInfo("nfmpFdn_" + device, requestContext.get("currentTopology"));
        if (deviceTopoObj) deviceTopoObj = JSON.parse(deviceTopoObj);
    }
    this.imLogger.info("[ietf-nfmp-instance][populatePathObjForLsp] this.pathValues {}", JSON.stringify(this.pathValues));
    var config = requestContext.get("intentConfigJson");
    var tunnelLevelBW = null;
    if (config["te-bandwidth"] && config["te-bandwidth"]["generic"]) {
        tunnelLevelBW = Math.round(parseInt(config["te-bandwidth"]["generic"]) / 1000000);
        this.imLogger.info("[ietf-nfmp-instance][populatePathObjForLsp] Found tunnel level BW {}", tunnelLevelBW);
    }

    var lspPathArr = [];
    if (deviceTopoObj["hopless"] && deviceTopoObj["hopless"]["hopless"]) {
        var bw = 0;
        var hop = 0;
        var includeAdminGroup = 0;
        var excludeAdminGroup = 0;
        var setupPriority = config["setup-priority"];
        var holdPriority = config["hold-priority"];
        if (this.pathValues.bandwidth[device + "_hopless"]) bw = this.pathValues.bandwidth[device + "_hopless"];
        if (this.pathValues.hopcount[device + "_hopless"]) hop = this.pathValues.hopcount[device + "_hopless"];
        if (this.pathValues.includeAdminGroup[device + "_hopless"]) includeAdminGroup = this.pathValues.includeAdminGroup[device + "_hopless"];
        if (this.pathValues.excludeAdminGroup[device + "_hopless"]) excludeAdminGroup = this.pathValues.excludeAdminGroup[device + "_hopless"];
        if (this.pathValues.setupPriority[device + "_hopless"] && this.pathValues.setupPriority[device + "_hopless"] !== 7) setupPriority = this.pathValues.setupPriority[device + "_hopless"];
        if (this.pathValues.holdPriority[device + "_hopless"] && this.pathValues.holdPriority[device + "_hopless"] !==0) holdPriority = this.pathValues.holdPriority[device + "_hopless"];
        lspPathArr.push({
            "id": this.getIdFromFdn(deviceTopoObj["hopless"]["hopless"]["tunnelDn"]),
            "type": "primary",
            "bandwidth": bw,
            "hop": hop,
            "setupPriority": setupPriority,
            "holdPriority": holdPriority,
            "isSrlg": false,
            "includeAdminGroup": includeAdminGroup,
            "excludeAdminGroup": excludeAdminGroup,
            "isAudit": isAudit
        })
    }

    if (deviceTopoObj["primary"]) {
        var self = this;
        Object.keys(deviceTopoObj["primary"]).forEach(function (key) {
            var bw = 0;
            var hop = 0;
            var includeAdminGroup = 0;
            var excludeAdminGroup = 0;
            var setupPriority = config["setup-priority"];
            var holdPriority = config["hold-priority"];
            if (self.pathValues.bandwidth[device + "_" + key]) bw = self.pathValues.bandwidth[device + "_" + key];
            else if (tunnelLevelBW) bw = tunnelLevelBW;
            if (self.pathValues.setupPriority[device + "_" + key] && self.pathValues.setupPriority[device + "_" + key] !== 7) setupPriority = self.pathValues.setupPriority[device + "_" + key];
            if (self.pathValues.holdPriority[device + "_" + key] && self.pathValues.holdPriority[device + "_" + key] !== 0) holdPriority = self.pathValues.holdPriority[device + "_" + key];
            if (self.pathValues.hopcount[device + "_" + key]) hop = self.pathValues.hopcount[device + "_" + key];
            if (self.pathValues.includeAdminGroup[device + "_" + key]) includeAdminGroup = self.pathValues.includeAdminGroup[device + "_" + key];
            if (self.pathValues.excludeAdminGroup[device + "_" + key]) excludeAdminGroup = self.pathValues.excludeAdminGroup[device + "_" + key];
            lspPathArr.push({
                "id": self.getIdFromFdn(deviceTopoObj["primary"][key]["tunnelDn"]),
                "type": "primary",
                "bandwidth": bw,
                "hop": hop,
                "setupPriority": setupPriority,
                "holdPriority": holdPriority,
                "isSrlg": false,
                "includeAdminGroup": includeAdminGroup,
                "excludeAdminGroup": excludeAdminGroup,
                "isAudit": isAudit
            })
        });
    }

    if (deviceTopoObj["secondary"]) {
        Object.keys(deviceTopoObj["secondary"]).forEach(function (key) {
            var bw = 0;
            var hop = 0;
            var includeAdminGroup = 0;
            var excludeAdminGroup = 0;
            var type = "secondary";
            var isSrlg = false;
            var setupPriority = config["setup-priority"];
            var holdPriority = config["hold-priority"];
            if (self.pathValues.bandwidth[device + "_" + key]) bw = self.pathValues.bandwidth[device + "_" + key];
            else if (tunnelLevelBW) bw = tunnelLevelBW;
            if (self.pathValues.hopcount[device + "_" + key]) hop = self.pathValues.hopcount[device + "_" + key];
            if (self.pathValues.setupPriority[device + "_" + key] && self.pathValues.setupPriority[device + "_" + key] !== 7) setupPriority = self.pathValues.setupPriority[device + "_" + key];
            if (self.pathValues.holdPriority[device + "_" + key] && self.pathValues.holdPriority[device + "_" + key] !== 0) holdPriority = self.pathValues.holdPriority[device + "_" + key];
            if (self.pathValues.isStandby[device + "_" + key]) type = "standby";
            if (self.pathValues.isSrlg[device + "_" + key]) isSrlg = true;
            if (self.pathValues.includeAdminGroup[device + "_" + key]) includeAdminGroup = self.pathValues.includeAdminGroup[device + "_" + key];
            if (self.pathValues.excludeAdminGroup[device + "_" + key]) excludeAdminGroup = self.pathValues.excludeAdminGroup[device + "_" + key];
            lspPathArr.push({
                "id": self.getIdFromFdn(deviceTopoObj["secondary"][key]["tunnelDn"]),
                "type": type,
                "bandwidth": bw,
                "hop": hop,
                "setupPriority": setupPriority,
                "holdPriority": holdPriority,
                "isSrlg": isSrlg,
                "includeAdminGroup": includeAdminGroup,
                "excludeAdminGroup": excludeAdminGroup,
                "isAudit": isAudit
            })
        });
    }


    if (lspPathArr.length === 0)
        throw new RuntimeException("LSP requires at least one path");

    return lspPathArr;
};
