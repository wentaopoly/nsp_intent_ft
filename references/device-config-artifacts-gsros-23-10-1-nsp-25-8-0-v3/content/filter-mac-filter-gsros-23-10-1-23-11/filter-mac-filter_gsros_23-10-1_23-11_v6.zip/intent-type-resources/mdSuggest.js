function MdSuggest() {
    this.getMacFilterName = function (neId, filterId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-state:/state/filter/mac-filter?fields=oper-filter-id";
        return this.getData(neId, url, "filter-name", filterId);
    }

    this.getMacFilterId = function (neId, filterName) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-state:/state/filter/mac-filter?fields=oper-filter-id";
        if (filterName) {
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-state:/state/filter/mac-filter=" + filterName + "?fields=oper-filter-id";
        }
        return this.getData(neId, url, "oper-filter-id");
    }

    this.getData = function (neId, url, type, filterId) {
        var mdcFwk = new MdcFwk();
        logger.info(LOG_PREFIX + "MdSuggest MAC Filter --getData---neId={}, url={}, type={}", neId, url, type);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info(LOG_PREFIX + "MDC resultFetch MAC Filter =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"]["nokia-state:mac-filter"];
        logger.info(LOG_PREFIX + "finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                if (filterId) {
                    logger.info(LOG_PREFIX + "FilterId Selected = {}", filterId);
                    logger.info(LOG_PREFIX + "Device Filter ID = {}", finalResponse[index]["oper-filter-id"]);
                    if (finalResponse[index]["oper-filter-id"] == filterId) {
                        ret.push(finalResponse[index][type]);
                        break
                    }
                }
                else {
                    ret.push(finalResponse[index][type]);
                }
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "ret = \n" + JSON.stringify(ret));
        return ret;
    }
    this.getFilterLog = function (neId) {
        var url =  "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/filter/log";
        return this.getFilterLogData(neId, url, "log-id");
    }
    this.getFilterLogData = function (neId, url, type) {
        var mdcFwk = new MdcFwk();
        logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info("MDC resultFetch =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"]["nokia-conf:log"];
        logger.info("finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse))
        {
            for (var index in finalResponse)
            {

                logger.info("Device Filter Log Data = {}", finalResponse[index]["log-id"]);
                ret.push(finalResponse[index][type]);
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info("ret = \n" + JSON.stringify(ret));
        return ret;
    }

}
