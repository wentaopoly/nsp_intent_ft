/**************************************************************************
 * $RCSfile$
 * <p>
 * Author: Imran khan
 * <p>
 * Description:
 * <edit this part>
 * <p>
 * **************************************************************************
 * <p>
 * Source Control System Information
 * <p>
 * $Revision$
 * $Id$
 * Last Changed by:$Author$
 * <p>
 * **************************************************************************
 * <p>
 * Copyright (c) 2023 Nokia,All Rights Reserved.
 * Please read the associated COPYRIGHTS file for more details.
 **************************************************************************/
package com.nokia.nsp.sf.app.srlNode;

import com.nokia.nsp.sf.app.api.ISFPlugin;
import com.nokia.nsp.sf.app.util.ServiceUtil;
import com.nokia.nsp.md.common.IYangObject;
import com.nokia.nspos.persistence.yang.api.IYangDB;
import com.nokia.nsp.md.common.YangObject;
import com.nokia.nsp.md.db.yang.api.QueryParameters;
import com.nokia.nsp.md.ifg.yang.api.Fields;
import com.nokia.nsp.md.ifg.yang.api.Field;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class SFSRLPlugin implements ISFPlugin
{
    private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(SFSRLPlugin.class.getName());
    public static final String MODEL_MDM_FDN="fdn:model:mdm:";
    private static final String ELAN_EP_IF="elan_ep_if";
    private static final String ELAN_EP_IF_SUB="elan_ep_if_sub";
    private static final String ELAN_EP_NT_IF="elan_ep_nt_if";
    private static final String ELAN_TUNNEL_VXLANIF="elan_tunnel_if";

    public static Map<String, String> predefinedDeviceConfigureServicePathMap = initDeviceConfigureServicePathMap();
    private static Map<String, String> predefinedDeviceEndpointServicePathMap = initDeviceDeviceEndpointPathMap();
    public static Map<String, String> predefinedDeviceProtocolsServicePathMap = initDeviceProtocolsServicePathMap();

    private static Map<String, String> predefinedDeviceTunnelInterfacePathMap = initDeviceDeviceTunnelInterfacePathMap();

    public static Map<String,Map<String,List<String>>> predefinedDeviceServicePathMapToNspClass=initDeviceServicePathMapToNspClasses();

    private static Map<String,Map<String,List<String>>> initDeviceServicePathMapToNspClasses()
    {
        Map<String,Map<String,List<String>>> lListMap=new HashMap<>();
        Map<String,List<String>> lElanService=new HashMap<>();
        Map<String,List<String>> l3VpnService=new HashMap<>();
        List<String> lElanNspClass=new ArrayList<>(1);
        List<String> l3VpnNspClass=new ArrayList<>(1);
        lElanNspClass.add("nsp-service:/services/nsp-service:service-layer/nsp-service:elan/nsp-service:site");
        lElanService.put("srl_nokia-network-instance:/network-instance", lElanNspClass);

        //L3Vpn service class
        l3VpnNspClass.add("nsp-service:/services/nsp-service:service-layer/nsp-service:l3vpn/nsp-service:site");
        l3VpnService.put("srl_nokia-network-instance:/network-instance", l3VpnNspClass);

        List<String> lElanNspEpClass=new ArrayList<>(1);
        lElanNspEpClass.add("nsp-service:/services/nsp-service:service-layer/nsp-service:elan/nsp-service:endpoint");
        lElanService.put("srl_nokia-network-instance:/network-instance/interface", lElanNspEpClass);
        lElanService.put("srl_nokia-interfaces:/interface", lElanNspEpClass);
        lElanService.put("srl_nokia-interfaces:/interface/subinterface", lElanNspEpClass);

        List<String> lElanNspVxlanCalss=new ArrayList<>(1);
        lElanNspVxlanCalss.add("nsp-service:/services/nsp-service:service-layer/nsp-service:elan/nsp-service:site/service-extension:elan-site/vxlan/instance");
        lElanService.put("srl_nokia-tunnel-interfaces:/tunnel-interface/vxlan-interface/ingress", lElanNspVxlanCalss);
        lListMap.put(ServiceUtil.serviceType.elan.name(),lElanService);

        //L3-Protocols
        List<String> l3pnNspBgpClass=new ArrayList<>(1);
        l3pnNspBgpClass.add("nsp-service:/services/nsp-service:service-layer/nsp-service:l3vpn/nsp-service:site/service-extension:l3vpn-site/bgp-evpn/bgp");
        l3VpnService.put("srl_nokia-network-instance:/network-instance/protocols", l3pnNspBgpClass);

        List<String> l3pnNspVxlanCalss=new ArrayList<>(1);
        l3pnNspVxlanCalss.add("nsp-service:/services/nsp-service:service-layer/nsp-service:l3vpn/nsp-service:site/service-extension:l3vpn-site/bgp-evpn/bgp/vxlan");
        l3VpnService.put("srl_nokia-tunnel-interfaces:/tunnel-interface/vxlan-interface/ingress", l3pnNspVxlanCalss);

        lListMap.put(ServiceUtil.serviceType.l3vpn.name(),l3VpnService);

        logger.info("SFSRLPlugin -- initDeviceServicePathMapToNspClasses ---  return lListMap "+lListMap);
        return lListMap;
    }

    private static  Map<String, String>  initDeviceConfigureServicePathMap()
    {
        Map<String,String> lMap=new HashMap<>();
        lMap.put(ServiceUtil.serviceType.elan.name(), "srl_nokia-network-instance:/network-instance");
        lMap.put(ServiceUtil.serviceType.l3vpn.name(), "srl_nokia-network-instance:/network-instance");
        return lMap;
    }
    private static  Map<String, String> initDeviceProtocolsServicePathMap()
    {
        Map<String,String> lMap=new HashMap<>();
        lMap.put(ServiceUtil.serviceType.l3vpn.name(), "srl_nokia-network-instance:/network-instance/protocols");
        return lMap;
    }

    private static  Map<String, String>  initDeviceDeviceEndpointPathMap()
    {
        Map<String,String> lMap=new HashMap<>();

        lMap.put(ELAN_EP_IF_SUB, "srl_nokia-interfaces:/interface/subinterface");
        lMap.put(ELAN_EP_NT_IF, "srl_nokia-network-instance:/network-instance/interface");

        return lMap;
    }

    private static  Map<String, String>  initDeviceDeviceTunnelInterfacePathMap()
    {
        Map<String,String> lMap=new HashMap<>();
        lMap.put(ELAN_TUNNEL_VXLANIF, "srl_nokia-tunnel-interfaces:/tunnel-interface/vxlan-interface/ingress");
        return lMap;
    }

    public  Map<String,List<String>> getNspClassToResync(Map<String,List<String>> aInMap,String aInServiceType,String aInNeId, boolean aInAfterStitchIng,String aInNodeType,String aInNodeVersion)
    {
        return predefinedDeviceServicePathMapToNspClass.get(aInServiceType);
    }

    @Override
    public List<String> buildExtraSources(IYangObject aInSyncSiteYangObj, String aInObjectType, List<String> aInSources, String aInSvcType, String aInNeId, String aInNodeType, String aInNodeVersion)
    {
        List<String> lExtraSources = new ArrayList();
        return lExtraSources;
    }

    @Override
    public Map<String, List<String>> buildResyncRequest(List<String> aInSources, String aInSvcType, String aInNeId, boolean aInAfterStitchIng, String aInNodeType, String aInNodeVersion)
    {
        logger.info("SFSRLPlugin -- buildResyncRequest ---  return aInSources "+aInSources);
        //key:device classId
        //value: list of sourceFdn
        Map<String, List<String>> lListMap=new LinkedHashMap<>();
        for (String lSource : aInSources)
        {
            if (lSource.contains(MODEL_MDM_FDN))
            {
                String lDeviceClassId = getDeviceClassId(lSource, aInSvcType);
                if(lDeviceClassId!=null)
                {
                    List<String> lList=  lListMap.get(lDeviceClassId);
                    if(null==lList)
                    {
                        lList=new LinkedList<>();
                        lListMap.put(lDeviceClassId, lList);
                    }
                    lList.add(lSource);
                }
            }
        }
        return lListMap;
    }

    private String getDeviceClassId(String aInSource, String aInSvcType){

        if(ServiceUtil.serviceType.elan.name().equals(aInSvcType)){
            if(aInSource.contains("/network-instance")){
                if(aInSource.contains("/interface")) {
                    return predefinedDeviceEndpointServicePathMap.get(ELAN_EP_NT_IF);
                }
                return predefinedDeviceConfigureServicePathMap.get(aInSvcType);
            } else if(aInSource.contains("/subinterface")) {
                return predefinedDeviceEndpointServicePathMap.get(ELAN_EP_IF_SUB);
            } else if(aInSource.contains("/tunnel-interface")){
                return predefinedDeviceTunnelInterfacePathMap.get(ELAN_TUNNEL_VXLANIF);
            }

        } else if(ServiceUtil.serviceType.l3vpn.name().equals(aInSvcType)){
            if(aInSource.contains("/protocols")) {
                return predefinedDeviceProtocolsServicePathMap.get(aInSvcType);
            } else if(aInSource.contains("/network-instance")) {
                return predefinedDeviceConfigureServicePathMap.get(aInSvcType);
            } else if(aInSource.contains("/tunnel-interface")){
                return predefinedDeviceTunnelInterfacePathMap.get(ELAN_TUNNEL_VXLANIF);
            }
        }
        return null;
    }


    public List<String>  getSourceFdns(IYangObject aInSyncSiteYangObj, String serviceType, String aInNeId, String aInNodeType,String aInNodeVersion)
    {
        List<String> lSources = (List) aInSyncSiteYangObj.getExtraData("sources");
        List<String> sources = new LinkedList<>();
        logger.info("SFSRLPlugin -- getSourceFdns ---  return aInSyncSiteYangObj " + aInSyncSiteYangObj);
        for (String lSource : lSources) {
            if (lSource.contains(MODEL_MDM_FDN)) {
                if (ServiceUtil.serviceType.elan.name().equals(serviceType) ||
                        ServiceUtil.serviceType.l3vpn.name().equals(serviceType)) {
                    if (lSource.contains("/network-instance")) {
                        String[] token = lSource.split("/network-instance");
                        if (token[1].endsWith("']")) {
                            sources.add(lSource);
                        }
                        if (token[1].endsWith("']/protocols")) {
                            sources.add(lSource);
                        }
                    } else if (lSource.contains("/tunnel-interface")) {
                        sources.add(lSource);
                    }

                } else {
                    sources.add(lSource);
                }
            }
        }

        List lExtraSources=buildExtraSources(aInSyncSiteYangObj, SVC_SITE, sources, serviceType, aInNeId, aInNodeType,aInNodeVersion );
        if(lExtraSources!=null && !lExtraSources.isEmpty()){
            for(Object lExtraSource : lExtraSources){
                if (((String)lExtraSource).contains(MODEL_MDM_FDN)){
                    sources.add((String)lExtraSource);
                }
            }
        }

        if (aInSyncSiteYangObj.getProperty("endpoint") != null) {
            List lSyncEndpoints = (List) aInSyncSiteYangObj.getProperty("endpoint");
            for (Object lSyncEndpoint : lSyncEndpoints) {
                List lEpSources=(List)(((YangObject) lSyncEndpoint).getExtraData("sources"));
                sources.addAll(lEpSources);
                List lEpExtraSources=buildExtraSources(aInSyncSiteYangObj, ISFPlugin.SVC_ENDPOINT, lEpSources, serviceType, aInNeId, aInNodeType,aInNodeVersion );
                if(lEpExtraSources!=null && !lEpExtraSources.isEmpty()){
                    sources.addAll(lEpExtraSources);
                }
            }
        }
        logger.info("SFSRLPlugin -- getSourceFdns end ---  return sources " + sources);
        return sources;
    }


    public  List<String> getSourceFdns(IYangDB aInDb, IYangObject aInSiteYangObj, String serviceType, String aInNeId, String aInNodeType,String aInNodeVersion)
    {
        logger.info("SFSRLPlugin -- getSourceFdns second  ---  return aInDb "+ aInDb.toString());
        List<String> sources = new LinkedList<>();
        List<String> lSources = (List) aInSiteYangObj.getExtraData("sources");
        for (String lSource : lSources) {
            if (lSource.contains(MODEL_MDM_FDN)) {
                if (ServiceUtil.serviceType.elan.name().equals(serviceType)
                        || ServiceUtil.serviceType.l3vpn.name().equals(serviceType)) {
                    if (lSource.contains("/network-instance")) {
                        String[] token = lSource.split("/network-instance");
                        if (token[1].endsWith("']")) {
                            sources.add(lSource);
                        }
                        if (token[1].endsWith("']/protocols")) {
                            sources.add(lSource);
                        }
                    } else if (lSource.contains("/tunnel-interface")) {
                        sources.add(lSource);
                    }
                } else {
                    sources.add(lSource);
                }
            }
        }

        if(aInSiteYangObj.getProperty("endpoint") != null) {
            List lEndpoints = (List)aInSiteYangObj.getProperty("endpoint");
            for (Object lEndpoint : lEndpoints) {
                IYangObject lEp= findEndpoint(aInDb, (String)lEndpoint);
                if (lEp != null) {
                    List<String> lEpSources = (List) (lEp.getExtraData("sources"));
                    for (String lEpSource : lEpSources) {
                        if (lEpSource.contains(MODEL_MDM_FDN)) {
                            sources.add(lEpSource);
                        }
                    }
                }
            }
        }
        logger.info("SFSRLPlugin -- getSourceFdns second  ---  return sources "+ sources);
        return sources;
    }

    public boolean shouldCreateEndpoint(String aInServiceType,String aInNeId, String aInNodeType,String aInNodeVersion, boolean isServiceStitching) {
        return true;
    }
    private IYangObject findEndpoint(IYangDB aInDb, String aInEpPath)
    {
        List<Field> lFields = new ArrayList<>(1);
        lFields.add(new Field("endpoint-id"));

        QueryParameters qps = new QueryParameters();
        qps.setFields(new Fields(lFields));
        qps.setDepth(2);
        IYangObject lYangObj = aInDb.getSingle(aInEpPath, qps);
        return lYangObj;
    }
}
