var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn" : "http://www.nokia.com/management-solutions/ibn",
    "nc" : "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager" : "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders" : "anv-device-holders"
};

load({script:resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})

load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
mdtFwk = new MdtFwk();

var intentTypeName = 'qos-sap-ingress_csas_23-10-1_23-11';

// example port, sap-ingress etc..
var initialPropertyName = 'sap-ingress';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/qos';

// unique identifier
var uniqueIdentifier = 'sap-ingress-policy-id';


function synchronize(input) {
    logger.info("Intent Synchronisation started");

    var result = synchronizeResultFactory.createSynchronizeResult();
    // Code to synchronize goes here
    return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
    result.setSuccess(true);
    return result;
}

function audit(input) {
    //var report = auditFactory.createAuditReport(null, null);
    // Code to audit goes here
    logger.info('Intent Audit started')
    logger.info("*******config ===== {}",input);
    return NspIntentHelper.audit(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier)

    return report
}

function getTargetData(input) {
    logger.info(input);
    var target = input.target;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}

function validate(syncInput) {
    var contextualErrorJsonObj = {};
    var intentConfig = syncInput.getJsonIntentConfiguration();

    // Code to validation here. Add errors to contextualErrorJsonObj.
    // contextualErrorJsonObj["attribute"] = "Attribute must be set";

    if (Object.keys(contextualErrorJsonObj).length !== 0) {
        utilityService.throwContextErrorException(contextualErrorJsonObj);
    }
}

function suggestPolicyName(context) {
    logger.info("suggestPolicyName context = \n" + context);
    var policyId = context.getInputValues()["arguments"]["target_id"];
    logger.info("User  selected Policy ID : {}, searching Policy Name associaed to Policy-id - {}", policyId, policyId);
    var neId = getNeId(context);
    return navigateInstance(neId).getPolicyName(neId, policyId);
}

function suggestPolicyId(context) {
    logger.info("suggestPolicyId context = \n" + context);
    var policyId = context.getInputValues()["arguments"]["target_sap-ingress-policy-id"];
    logger.info("User  selected Policy Id : {}, searching Policy ID associaed to Policy Id - {}", policyId, policyId);
    var neId = getNeId(context);
    return navigateInstance(neId).getPolicyId(neId, policyId);
}

function suggestIngressClassificationPolicy(context) {
    logger.info("suggest Ingress Classification Policy context = \n" + context);
    var neId = getNeId(context);
    return navigateInstance(neId).getIngressClassificationPolicy(neId);
}


function getNeId(context) {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    logger.info(target)
    if (target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    logger.info("NeId : " + neId);
    return neId;
}


function navigateInstance(neId) {
    var managerName = mdtFwk.getManagerName(neId);
    logger.info('Device: ' + neId + ' is managed by: ' + managerName);
    switch (managerName)
    {
        case 'NFM-P':
            logger.info('Device is managed by NFMP')
            return new NfmpSuggest();
            break;
        default:
            logger.info('Device is not managed')
            throw new RuntimeException('Device is not Managed')
    }
    return ''
}
