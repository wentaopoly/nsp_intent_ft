load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {

    this.setSuccessResult = function (result, savedTopology) {
        result.setSuccess(true);
        if (savedTopology !== undefined)
        {
            result.setTopology(savedTopology);
        }
        return result;
    }

    this.reportMisaligned = function (target, result, auditReport) {
        var report = JSON.parse(result.response);
        if (!report.aligned)
        {
            for (var i = 0; i < report.misalignedAttributes.length; i++)
            {
                var attributeData = report.misalignedAttributes[i];
                if (attributeData.expected == "present")
                {
                    //misaligned object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else if (attributeData.expected == "not present")
                {
                    //undesired object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                    auditReport.addMisAlignedAttribute(misalignedAttribute);
                }

            }
        }
        return auditReport
    }

    this.editPayload = function (fdn, properties, childProperties, fullClassName, objectFullName) {
        var payload = {};
        var configInfo = {};
        configInfo[fullClassName] = properties;
        configInfo[fullClassName]["children-Set"] = childProperties;
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName;
        payload["clearOnDeployFailure"] = true;
        payload["configInfo"] = configInfo;
        return payload;
    }

    /*
        function: isObjectExists
        description: To Check the Object exists or not.
   */
    this.isObjectExists = function (className, objectFullName) {
        let nfmpFwk = new NfmpFwk();
        var ret = false;
        var searchObjectJson = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);

        logger.info("isObjectExists data = {}", JSON.stringify(resultFetch));

        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("Final response of search = {}", JSON.stringify(finalResponse));
        if (Object.keys(finalResponse).length !== 0 && finalResponse.constructor === Object)
        {
            ret = true;
        }
        logger.info("isObjectExists = {} ", ret);
        return ret;
    }

    /*
       function: delay
       description: Sometimes the object creation takes time, we can use delay for child-level operation.
    */
    this.delay = function (milliseconds) {
        var date = new Date();
        date.setMilliseconds(date.getMilliseconds() + milliseconds);
        while (new Date() < date)
        {
        }
    }

    this.convertAdminStateGreenField = function (adminState) {
        if (adminState == "enable")
        {
            return "tmnxInService";
        }
        else if (adminState == "disable")
        {
            return "tmnxOutOfService";
        }
    }
    this.convertAdminStateBrownField = function (adminState) {
        if (adminState == "tmnxInService")
        {
            return "enable";
        }
        else if (adminState == "tmnxOutOfService")
        {
            return "disable";
        }
    }
    this.convertHelloIntervalGreenField = function (helloInterval) {
        if (helloInterval == "500ms")
        {
            return "500";
        }
        else {
            return helloInterval.charAt(0);
        }
        return helloInterval;
    }
    this.convertHelloIntervalBrownField = function (helloInterval) {
        if (helloInterval == "500")
        {
            return "500ms";
        }
        else
        {
            return helloInterval + "s";
        }
        return helloInterval;
    }
}

