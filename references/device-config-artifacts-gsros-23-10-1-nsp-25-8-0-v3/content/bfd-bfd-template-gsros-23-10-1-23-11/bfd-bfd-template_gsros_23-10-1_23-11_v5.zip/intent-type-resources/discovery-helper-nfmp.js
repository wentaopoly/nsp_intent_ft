var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk' });
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("model-device-mapping.js"), name: "model-device-mapping"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});

var bfd_template_class_name = "mplstp.BFDTemplate";
var bfd_template_policy_fdn = "BFDTemplate";

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let mdcFwk = new MdcFwk();
    let parseTarget = new ParseTarget();
    let modelDeviceMapping = new ModelDeviceMapping();
    let util = new utilities();

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let bfdTemplateName = parseTarget.getUniqueIdentifier(target);
        let objectFullName = bfd_template_policy_fdn + ":" + bfdTemplateName;
        let localObjectFullName = "network:" + neId + ":" + objectFullName;
        localObjectFullName = util.modifyNeIdForIpV6(localObjectFullName, neId);
        logger.info(LOG_PREFIX + "localObjectFullName: " + localObjectFullName);
        let resultFetch = nfmpFwk.post("/v3/search", this.constructSearchString(bfd_template_class_name, localObjectFullName));
        if (!resultFetch.success) {
            throw new RuntimeException("Failed to find BFD Template : " + bfdTemplateName + " on NE " + neId);
        }
        let finalResponse = JSON.parse(resultFetch.response);
        if (JSON.stringify(finalResponse) === JSON.stringify({})) {
            throw new RuntimeException("search results is empty for BFD Template : " + bfdTemplateName + " finalResponse: " + JSON.stringify(finalResponse));
        }
        else if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse[bfd_template_class_name]];
            logger.info(LOG_PREFIX + "Search results: " + JSON.stringify(finalResponse));
        }
        return finalResponse[0];
    }

    this.constructSearchString = function (className, objectFullName) {
        let searchJson = {
            "fullClassName": className,
            "filter":{
                "equal":{
                    "name":"objectFullName",
                    "value": objectFullName
                }
            }
        };
        return searchJson;
    }

    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedTargetData = JSON.parse(defaultTargetData)[initialPropertyName];
        let bfdTemplateMapping = modelDeviceMapping.getBfdTemplateMapping();
        this.traverseAndUpdateConfig("bfd-template", parsedTargetData, deviceConfig, bfdTemplateMapping);

        let finalTargetData = {};
        finalTargetData[initialPropertyName] = parsedTargetData;
        logger.info(LOG_PREFIX + "Intent data after updating from NFMP: \n" + JSON.stringify(finalTargetData));
        return finalTargetData;
    }

    this.traverseAndUpdateConfig = function (objKey, defDataObj, deviceConfig, mappings) {
        let keys = Object.keys(defDataObj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = defDataObj[key];
            let mappedKey = objKey + "." + key;
            if (value != null && typeof value === "object") {
                this.traverseAndUpdateConfig(mappedKey, value, deviceConfig, mappings);
            }
            else {
                let nfmpKey = mappings[mappedKey];
                if (nfmpKey === "templateType" && deviceConfig[nfmpKey] === "cmpNp") {
                    defDataObj[key] = "cpm-np";
                }
                else if (nfmpKey === "templateType" && deviceConfig[nfmpKey] === "auto") {
                    delete defDataObj["type"];
                }
                else {
                    defDataObj[key] = deviceConfig[nfmpKey];
                }
            }
        }
    }
}