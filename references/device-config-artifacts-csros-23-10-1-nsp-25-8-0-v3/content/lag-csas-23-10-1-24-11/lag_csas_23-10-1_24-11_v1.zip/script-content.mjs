/********************************************************************************
 * DEVICE-SPECIFIC INTENT-TYPE USED FOR NSP DEVICE CONFIGURATION (ICM)
 *   Vendor: Nokia
 *   Device families: 7210 SAS
 *   Device version: 23.10.R1
 *
 * (c) 2025 by Nokia
 ********************************************************************************/

import { IntentHandlerBase }  from 'common/IntentHandlerBase.mjs';
import { NSP }  from 'common/NSP.mjs';
const HashMap = Java.type("java.util.HashMap");

class IntentHandler extends (IntentHandlerBase) {
  constructor() {
    super();
    this.greenFieldObjectFullName = "network:$systemAddress:lag:interface-$*lagId";
    this.greenFieldFDN = "network:$systemAddress:lag";
    this.brownFieldObjectFullName = "network:$systemAddress:lag:interface-$*lagId";
    this.isPolicyIntent = false;
    this.initialPropertyName = "lag-Interface";
    this.uniqueIdentifier = "lagId";
    NSP.checkRelease(24, 11);
  }

  transformPayloadGreenField(payload, neId, isAudit) {
       if (!payload.configInfo["lag.Interface"].hasOwnProperty("monitorOperGroupPointer")) {
              // Add the property with a null value to clear
              payload.configInfo["lag.Interface"].monitorOperGroupPointer = '';
       }
       else
       {
           payload.configInfo["lag.Interface"].monitorOperGroupPointer =
             "network:"+neId+":sOprGrp-"+payload.configInfo["lag.Interface"].monitorOperGroupPointer;
       }
	   if (payload.configInfo["lag.Interface"].hasOwnProperty("children-Set")) {
		let childrenSet = payload.configInfo["lag.Interface"]["children-Set"];
		if (childrenSet.hasOwnProperty("lag.PortTermination")) {
		   childrenSet["lag.PortTermination"].forEach(portTermination => {
			  if (portTermination.memberName) {
				 let portPointer = this.getPortData(neId, portTermination.memberName, "objectFullName");
				 portTermination.portPointer = portPointer;
			  }
		   });
		}
	   }
  }

  transformTargetValueBrownField(xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
      if(xpath === "monitorOperGroupPointer")
      {
          targetValue = targetValue.split("sOprGrp-").pop();
      }
      return targetValue;
  }

  // WebUI suggest/picker callouts:
  suggestLagId(context) {
        let className = "lag.Interface",
            neId = this.getNeId(context),
            attribute = "lagId";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                        "name": "siteId",
                        "value": neId
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    attribute
                ]
            }
        };

        return this.getData(neId, searchObject, className, attribute);
    }
    suggestMonitorOperGroup(context) {
        logger.info("suggest Monitor Oper Group Context = \n" + context);
        let neId = this.getNeId(context);
        let searchObjectJson = {
            "fullClassName": "netw.SystemOperGroup",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(neId, searchObjectJson, "netw.SystemOperGroup", "displayedName");
    }
	suggestPortIds(context) {
		logger.info("suggest Port Context = \n" + context);
		let neId = this.getNeId(context);
		let mode = context.getInputValues()["arguments"]["__parent"]["lag-Interface"]["mode"];
		let encapType = context.getInputValues()["arguments"]["__parent"]["lag-Interface"]["encapType"];
		return this.getPortIds(neId,mode,encapType);
	}
    getPortIds(neId, mode, encapType) {
        let searchObjectJson1 = {
            "fullClassName": "equipment.PhysicalPort",
            "filter": {
                "and": {
                    "equal": [{
                        "name": "siteId",
                        "value": neId
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "portName",
                    "objectFullName",
                    "description",
                    "encapType",
                    "mode"
                ]
            }
        };
        let searchObjectJson2 = {
            "fullClassName": "pxc.PortCrossConnectSubPort",
            "filter": {
                "and": {
                    "equal": [{
                        "name": "siteId",
                        "value": neId
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName",
                     "objectFullName",
                    "description",
                    "encapType",
                    "mode"
                ]
            }
        };
        let data = new HashMap();
    	let resultFetch1 = NSP.nfmpPOST(neId, "/v3/search", searchObjectJson1);
    	let resultFetch2 = NSP.nfmpPOST(neId, "/v3/search", searchObjectJson2);
    	let finalResponse1 = JSON.parse(resultFetch1.response)["equipment.PhysicalPort"];
    	let finalResponse2 = JSON.parse(resultFetch2.response)["pxc.PortCrossConnectSubPort"];
    	if(finalResponse1 && finalResponse2 && mode === "hybrid"){
    	  let finalResponse= finalResponse1.concat(finalResponse2);
    	    data = this.processResponse(finalResponse, mode, encapType);
    	   return data;
        }else if(finalResponse1){
           data = this.processResponse(finalResponse1, mode, encapType);
    	 return data
    	}else if(finalResponse2) {
    	  data = this.processResponse(finalResponse2, mode, encapType);
    	  return data;
    	}
    }

    processResponse(response, mode, encapType) {
        let result=new HashMap();
        let data=[];
        if (response) {
            data = response.map(function(portDetails) {
                let obj = {};
                if (mode === portDetails["mode"] && encapType === portDetails["encapType"]) {
                    obj["memberName"] = portDetails["portName"] || portDetails["displayedName"];
                    obj["description"] = portDetails["description"];
                    obj["encapType"] = portDetails["encapType"];
                    obj["mode"] = portDetails["mode"];
                    obj["portPointer"] = portDetails["objectFullName"];
                    return obj;
                }
                return null;
            }).filter(obj => obj !== null);
             result["data"] = JSON.stringify(data);
        }
        logger.info("Processed data: " +JSON.stringify(result));
        return result;
     }

    getPortData (neId, port, attribute) {
        let fullClassName = port.startsWith("pxc-") ? "pxc.PortCrossConnectSubPort" : "equipment.PhysicalPort";
        let attributeName = port.startsWith("pxc-") ? "displayedName" : "portName";
        let searchObjectJson = {
            "fullClassName": fullClassName,
            "filter": {
                "and": {
                    "equal": [
                        { "name": "siteId", "value": neId },
                        { "name": attributeName, "value": port }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [attribute]
            }
        };
        let resultFetch = NSP.nfmpPOST(neId, "/v3/search", searchObjectJson);
        let responseKey = fullClassName;
        let finalResponse = JSON.parse(resultFetch.response);
        let data = (finalResponse[responseKey] && finalResponse[responseKey][attribute]);
        return data;
   };

}

new IntentHandler();