load({ script: resourceProvider.getResource("mdt-fwk.js"), name: "MdtFwk" });
var mdtFwk = new MdtFwk();

load({
  script: resourceProvider.getResource("mdc-utils.js"),
  name: "MdcUtils",
});

load({
  script: resourceProvider.getResource("nfmp-utils.js"),
  name: "NfmpUtils",
});

load({
  script: resourceProvider.getResource("parse-target.js"),
  name: "ParseTarget",
});

var parseTarget = new ParseTarget();

function UtilFwk() {
  /**
   * Delegates the call to different instance(MDC or NFMP) to synchronize the configuration
   * @param {} input
   * @param {*} intentTypeName
   * @param {*} rootXPath
   * @param {*} intentContainer
   * @param {*} uniqueIdentifier
   * @param {*} deviceYangModuleName
   * @returns
   */
  this.synchronize = function (
    target,
    config,
    intentTypeName,
    rootXPath,
    intentContainer,
    uniqueIdentifier,
    deviceYangModuleName,
    topology,
    state,
    syncResult
  ) {
    // call preSync function
    config = customHooks.preSync({
      target:target,
      config:config,
      intentTypeName:intentTypeName,
      rootXPath:rootXPath,
      intentContainer:intentContainer,
      uniqueIdentifier:uniqueIdentifier,
      deviceYangModuleName:deviceYangModuleName,
      topology:topology,
      state:state,
      syncResult:syncResult
    });
    logger.info("--------- UtilFwk -> Synchronise started ------");
    logger.info("config " + config);
    logger.info("intentTypeName " + intentTypeName);
    logger.info("rootXPath " + rootXPath);
    logger.info("intentContainer " + intentContainer);
    logger.info("uniqueIdentifier " + uniqueIdentifier);
    logger.info("deviceYangModuleName " + deviceYangModuleName);
    logger.info("topology " + topology);
    logger.info("state " + state);
    var neId = parseTarget.getNeIdFromTarget(target);
    try {
      var instanceFwk = this.navigateInstance(neId);
      instanceFwk.synchronize(
        target,
        config,
        intentTypeName,
        rootXPath,
        intentContainer,
        uniqueIdentifier,
        deviceYangModuleName,
        topology,
        state,
        syncResult
      );
      logger.info("---------UtilFwk -> Synchronise done ------");
      customHooks.postSync({
        target:target,
        config:config,
        intentTypeName:intentTypeName,
        rootXPath:rootXPath,
        intentContainer:intentContainer,
        uniqueIdentifier:uniqueIdentifier,
        deviceYangModuleName:deviceYangModuleName,
        topology:topology,
        state:state,
        syncResult:syncResult
      });
      return syncResult;
    } catch (e) {
      logger.error("Error Occured while Synchronising with error: " + e);
      throw new RuntimeException("Error Executing Intent: " + e);
    }
  };

  /**
   * Delegates the call to different instance(MDC or NFMP) to audit the configuration
   *
   * @param {*} target
   * @param {*} intentConfig
   * @param {*} svcTopo
   * @param {*} adminState
   * @param {*} intentTypeName
   * @param {*} rootXPath
   * @param {*} intentContainer
   * @param {*} uniqueIdentifier
   * @param {*} deviceYangModuleName
   * @returns
   */
  this.audit = function (
    target,
    intentConfig,
    svcTopo,
    adminState,
    intentTypeName,
    rootXPath,
    intentContainer,
    uniqueIdentifier,
    deviceYangModuleName
  ) {
    // call the preAudit hook
    customHooks.preAudit({
      target: target,
      intentConfig: intentConfig,
      svcTopo: svcTopo,
      adminState: adminState,
      intentTypeName: intentTypeName,
      rootXPath: rootXPath,
      intentContainer: intentContainer,
      uniqueIdentifier: uniqueIdentifier,
      deviceYangModuleName: deviceYangModuleName
    });
    try {
      logger.info("--------- UtilFwk -> audit started ------");
      var neId = parseTarget.getNeIdFromTarget(target);
      var instanceFwk = this.navigateInstance(neId);
      var auditReport = auditFactory.createAuditReport(intentTypeName, target);
      instanceFwk.audit(
        target,
        intentConfig,
        svcTopo,
        adminState,
        intentTypeName,
        rootXPath,
        intentContainer,
        uniqueIdentifier,
        deviceYangModuleName,
        auditReport
      );
      logger.info("--------- report ------" + JSON.stringify(auditReport));
      logger.info("--------- UtilFwk -> audit done ------");
      // call the postAudit
      customHooks.postAudit({
        target: target,
        intentConfig: intentConfig,
        svcTopo: svcTopo,
        adminState: adminState,
        intentTypeName: intentTypeName,
        rootXPath: rootXPath,
        intentContainer: intentContainer,
        uniqueIdentifier: uniqueIdentifier,
        deviceYangModuleName: deviceYangModuleName,
        auditReport: auditReport
    });
      return auditReport;
    } catch (e) {
      logger.info("Error Occured while Auditing with error: " + e);
      throw new RuntimeException("Error Auditing Intent: " + e);
    }
  };

  /**
   * Get the instance for MDC or NFMP
   * @param {} neId
   * @returns
   */
  this.navigateInstance = function (neId) {
    var managerName = mdtFwk.getManagerName(neId);
    logger.info("Device: " + neId + " is managed by: " + managerName);
    switch (managerName) {
      case "NFM-P":
        logger.info("Device is managed by NFMP");
        return this.createNfmpInstance();
      case "MDC":
        logger.info("Device is managed by MDC");
        return this.createMdcInstance();
      default:
        logger.info("Device is not managed");
        throw new RuntimeException("Device is not Managed");
    }
  };

  /**
   * Create NFMP Manager
   * @returns instance of NfmpUtils
   */
  this.createNfmpInstance = function () {
    return new NfmpUtils();
  };

  /**
   * Create MDC Manager
   * @returns intance of MdcUtils
   */
  this.createMdcInstance = function () {
    return new MdcUtils();
  };

  /**
   *
   * @param {*} result
   * @returns
   */
  this.setErrorResult = function (result) {
    result.setSuccess(false);
    result.setErrorCode(100);
    result.setErrorDetail("failed To set Topology.");
    return result;
  };

  /**
   *
   * @param {*} result
   * @param {*} savedTopology
   * @returns
   */
  this.setSuccessResult = function (result, savedTopology) {
    result.setSuccess(true);
    if (savedTopology !== undefined) {
      result.setTopology(savedTopology);
    }
    return result;
  };

  /**
   *
   * @param {*} target
   * @param {*} card
   * @param {*} type
   * @returns
   */
  this.payloadBuilder = function (target, card, type) {
    if (type === "create_card") {
      var payload = {
        fdn: "network:" + target + ":shelf-1:cardSlot-" + card["slot-number"],
        slotId: card["slot-number"],
        specificType: "card_" + card["card-type"].split("-").join("_"),
      };
      return payload;
    }
    if (type === "edit_card") {
      var payload = {
        fdn: "network:" + target + ":shelf-1:cardSlot-" + card["slot-number"],
        objectFullName:
          "network:" + target + ":shelf-1:cardSlot-" + card["slot-number"],
        cardPowerSave: card["power-save"],
        cardAssignedLevel: card["level"],
        resetOnRecoverableError: card["reset-on-recoverable-error"],
      };
      if (card["fail-on-error"]) {
        payload["failOnError"] = card["fail-on-error"];
      }
      if (card["admin-state"] === "enable") {
        payload["administrativeState"] = "inService";
      } else {
        payload["administrativeState"] = "outOfService";
      }
      return payload;
    }

    if (type === "create_mda") {
      var mda = card.mda;
      var payload = {
        fdn:
          "network:" +
          target +
          ":shelf-1:cardSlot-" +
          card["slot-number"] +
          ":card:daughterCardSlot-" +
          mda["mda-slot"],
        slotId: card["slot-number"],
        daughterCardSlotId: mda["mda-slot"],
        specificType: "mda_" + mda["mda-type"].split("-").join("_"),
      };
      if (mda["admin-state"] === "enable") {
        payload["administrativeState"] = "inService";
      } else {
        payload["administrativeState"] = "outOfService";
      }
      return payload;
    }

    if (type === "edit_mda") {
      var mda = card.mda;
      var payload = {
        objectFullName:
          "network:" +
          target +
          ":shelf-1:cardSlot-" +
          card["slot-number"] +
          ":card:daughterCardSlot-" +
          mda["mda-slot"] +
          ":daughterCard",
      };
      if (mda["admin-state"] === "enable") {
        payload["administrativeState"] = "inService";
      } else {
        payload["administrativeState"] = "outOfService";
      }
      return payload;
    }

    if (type === "scheduler_body") {
      var schedulerAdjustment = card["virtual-scheduler-adjustment"];
      var payload = {
        objectFullName:
          "network:" +
          target +
          ":shelf-1:cardSlot-" +
          card["slot-number"] +
          ":VrSchAdj",
        rateCalcfastMinInt:
          schedulerAdjustment["interval"]["rate-calculation-minimum"][
            "fast-queue"
          ].toFixed(1),
        taskSchedInt:
          schedulerAdjustment["interval"]["task-scheduling"].toFixed(1),
        schedRunMinInt:
          schedulerAdjustment["interval"]["rate-calculation-minimum"][
            "slow-queue"
          ].toFixed(1),
        rateCalcslowMinInt:
          schedulerAdjustment["interval"]["scheduler-run-minimum"].toFixed(1),
        slowQueueThresh: schedulerAdjustment["slow-queue-threshold-rate"],
      };
      var mode = schedulerAdjustment["internal-scheduler-weight-mode"];
      if (mode === "auto") {
        payload["internalSchedWeightMode"] = "default";
      }
      if (mode === "force-equal") {
        payload["internalSchedWeightMode"] = "forceEqual";
      }
      if (mode === "offered-load") {
        payload["internalSchedWeightMode"] = "offeredLoad";
      }
      if (mode === "capped-offered-load") {
        payload["internalSchedWeightMode"] = "cappedOfferedLoad";
      }
      return payload;
    }

    if (type === "audit_card") {
      var payload = [
        {
          fdn:
            "network:" +
            target +
            ":shelf-1:cardSlot-" +
            card["slot-number"] +
            ":card",
          objectFullName:
            "network:" +
            target +
            ":shelf-1:cardSlot-" +
            card["slot-number"] +
            ":card",
          slotId: card["slot-number"],
          specificType: "card_" + card["card-type"].split("-").join("_"),
        },
        {
          fdn: "network:" + target + ":shelf-1:cardSlot-" + card["slot-number"],
          objectFullName:
            "network:" + target + ":shelf-1:cardSlot-" + card["slot-number"],
          //cardPowerSave:card["power-save"].toString(),
          cardAssignedLevel: card["level"],
          //resetOnRecoverableError:card["reset-on-recoverable-error"].toString(),
        },
      ];
      if (card["fail-on-error"]) {
        payload[1]["failOnError"] = card["fail-on-error"];
      }
      if (card["admin-state"] === "enable") {
        payload[1]["administrativeState"] = "inService";
      } else {
        payload[1]["administrativeState"] = "outOfService";
      }
      return payload;
    }

    if (type === "audit_mda") {
      var mda = card.mda;
      var payload = {
        fdn:
          "network:" +
          target +
          ":shelf-1:cardSlot-" +
          card["slot-number"] +
          ":card:daughterCardSlot-" +
          mda["mda-slot"] +
          ":daughterCard",
        objectFullName:
          "network:" +
          target +
          ":shelf-1:cardSlot-" +
          card["slot-number"] +
          ":card:daughterCardSlot-" +
          mda["mda-slot"] +
          ":daughterCard",
        slotId: card["slot-number"],
        daughterCardSlotId: mda["mda-slot"],
        specificType: "mda_" + mda["mda-type"].split("-").join("_"),
      };
      if (mda["admin-state"] === "enable") {
        payload["administrativeState"] = "inService";
      } else {
        payload["administrativeState"] = "outOfService";
      }
      return payload;
    }
  };

  /**
   *
   * @param {*} intentConfigXml
   * @returns
   */
  this.convertIntentConfigXmlToJson = function (intentConfigXml) {
    logger.info("intentConfigXml : " + intentConfigXml);
    var lXml = Java.type("org.json.XML");
    lsImpl = intentConfigXml
      .getOwnerDocument()
      .getImplementation()
      .getFeature("LS", "3.0");
    serializer = lsImpl.createLSSerializer();
    serializer.getDomConfig().setParameter("xml-declaration", false);
    str = serializer.writeToString(intentConfigXml);
    json = lXml.toJSONObject(str).toString();
    logger.info("intentConfigJson : " + json);
    return JSON.parse(json);
  };

  /**
   *
   * @param {*} target
   * @param {*} response
   * @param {*} card
   * @param {*} savedTopology
   * @returns
   */
  this.metaData = function (target, response, card, savedTopology) {
    var configurationResponse = JSON.parse(response);
    if (
      configurationResponse != null &&
      configurationResponse.objectFullName != null
    ) {
      var objectFullName =
        "network:" + target + ":shelf-1:cardSlot-" + card["slot-number"];
      var mdaFullName =
        "network:" +
        target +
        ":shelf-1:cardSlot-" +
        card["slot-number"] +
        ":card:daughterCardSlot-" +
        card["mda"]["mda-slot"];
      var topoValue = [card["card-type"], mdaFullName, card["mda"]["mda-type"]];
      var xtraInfo = topologyFactory.createTopologyXtraInfoFrom(
        objectFullName,
        topoValue
      );
      xtraInfo.setTarget(target);
      xtraInfo.setIntentType("Classic_Card_Conf");
      savedTopology.addXtraInfo(xtraInfo);
    }
    return savedTopology;
  };

  /**
   *
   * @param {*} card
   * @param {*} savedTopology
   * @param {*} target
   * @returns
   */
  this.getRequestType = function (card, savedTopology, target) {
    var fdn = "network:" + target + ":shelf-1:cardSlot-" + card["slot-number"];
    var specificType = this.extractInfo(savedTopology, fdn, 0);
    if (specificType === undefined) {
      return "create";
    } else if (specificType !== card["card-type"]) {
      return "replace";
    } else return "edit";
  };

  /**
   *
   * @param {*} card
   * @param {*} savedTopology
   * @param {*} target
   * @returns
   */
  this.getMdaRequestType = function (card, savedTopology, target) {
    var fdn = "network:" + target + ":shelf-1:cardSlot-" + card["slot-number"];
    var mdaType = this.extractInfo(savedTopology, fdn, 2);
    if (mdaType === undefined) {
      return "create";
    } else if (mdaType !== card["mda"]["mda-type"]) {
      return "replace";
    } else return "edit";
  };

  this.extractInfo = function (topology, key, i) {
    var values;
    if (topology != null && topology.getXtraInfo() != null) {
      topology.getXtraInfo().forEach(function (extraInfo) {
        if (extraInfo.getKey() == key) {
          var value = extraInfo.getValue();
          values = value.split(",");
        }
      });
    }

    if (values === undefined) return values;
    else return values[i];
  };

  /**
   *
   * @param {*} target
   * @param {*} result
   * @param {*} auditReport
   * @returns
   */
  this.reportMisaligned = function (target, result, auditReport) {
    var report = JSON.parse(result.response);
    if (!report.aligned) {
      for (var i = 0; i < report.misalignedAttributes.length; i++) {
        var attributeData = report.misalignedAttributes[i];
        var misalignedAttribute = auditFactory.createMisAlignedAttribute(
          attributeData.name,
          attributeData.expected,
          attributeData.actual,
          target
        );
        auditReport.addMisAlignedAttribute(misalignedAttribute);
      }
    }
    return auditReport;
  };

  /**
   *
   * @param {*} target
   * @param {*} savedTopology
   * @param {*} cardList
   * @returns
   */
  this.updatecCardDelete = function (target, savedTopology, cardList) {
    var topologyXtraInfo = savedTopology.getXtraInfo();

    var newTopology = topologyFactory.createServiceTopology();
    newTopology.setTarget(target);
    newTopology.setIntentType("classic_card_conf_lv_2_with_nfmp_fwk");
    var deletedCardList = [];
    var j = 0;
    var cardsDeleted = false;
    for (var i = 0; i < cardList.length; i++) {
      var objectFullName =
        "network:" + target + ":shelf-1:cardSlot-" + cardList[i]["slot-number"];
      var card = cardList[i];
      if (topologyXtraInfo[j].getKey() !== objectFullName) {
        while (j < topologyXtraInfo.length) {
          deletedCardList.push(topologyXtraInfo[j].getKey() + ":card");
          cardsDeleted = true;
          j++;
          if (topologyXtraInfo[j].getKey() === objectFullName) {
            i--;
            break;
          }
        }
      } else {
        var objectFullName =
          "network:" + target + ":shelf-1:cardSlot-" + card["slot-number"];
        var mdaFullName =
          "network:" +
          target +
          ":shelf-1:cardSlot-" +
          card["slot-number"] +
          ":card:daughterCardSlot-" +
          card["mda"]["mda-slot"];
        var topoValue = [
          card["card-type"],
          mdaFullName,
          card["mda"]["mda-type"],
        ];
        var xtraInfo = topologyFactory.createTopologyXtraInfoFrom(
          objectFullName,
          topoValue
        );
        xtraInfo.setTarget(target);
        xtraInfo.setIntentType("Classic_Card_Conf");
        newTopology.addXtraInfo(xtraInfo);
        j++;
      }
    }
    var result = {
      newTopology: newTopology,
      deletedCardList: deletedCardList,
      cardsDeleted: cardsDeleted,
    };
    log.info(
      null,
      "/n/n/n[Util-fwk] : Got result for updatecCardDelete :  " +
        result.newTopology +
        JSON.stringify(result)
    );
    return result;
  };

  /**
   *
   * @param {*} target
   * @param {*} portId
   * @returns
   */
  this.getBaseFdnForPort = function (target, portId) {
    var portIds = portId.split("/");
    var cardSlot = portIds[0];
    var mdaSlot = portIds[1];
    var portNumber = portIds[2];
    return (
      "network:" +
      target +
      ":shelf-1:cardSlot-" +
      cardSlot +
      ":card:daughterCardSlot-" +
      mdaSlot +
      ":daughterCard:port-" +
      portNumber
    );
  };

  /**
   *
   * @param {*} fdn
   * @param {*} properties
   * @param {*} fullClassName
   * @param {*} objectFullName
   * @returns
   */
  this.editPayload = function (fdn, properties, fullClassName, objectFullName) {
    var payload = {};
    var configInfo = {};
    configInfo["containedClassProperties"] = properties;
    configInfo["objectClassName"] = fullClassName;
    payload["fdn"] = fdn;
    (payload["objectFullName"] = objectFullName),
      (payload["configInfo"] = configInfo);
    return payload;
  };
}
