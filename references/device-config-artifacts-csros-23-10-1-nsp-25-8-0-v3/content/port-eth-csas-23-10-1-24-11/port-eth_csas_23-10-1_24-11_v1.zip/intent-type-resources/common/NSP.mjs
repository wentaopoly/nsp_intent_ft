/******************************************************************************
 * Helper functions to call other NSP/NFMP services.
 * Packaged as static methods of class NSP.
 *
 * (c) 2025 by Nokia
 ******************************************************************************/

export class NSP
{
  /**
   * Determine NSP version to perform release compatibility check.
   * Throws Error(), if NSP release is match the criteria (too old).
   *
   * @param {number} major Minimum expected major NSP Release
   * @param {number} minor Minimum expected minor NSP Release
   *
   * @throws Error
   */

  static checkRelease(major, minor) {
    const startTS = Date.now();
    logger.debug(`NSP::checkRelease(${major}, ${minor})`);

    const url = "https://rest-gateway/internal/shared-app-banner-utils/rest/api/v1/appBannerUtils/release-version";

    const managerInfo = mds.getManagerByName("NSP");
    if (managerInfo.getConnectivityState().toString() === "CONNECTED") {
      restClient.setIp(managerInfo.getIp());
      restClient.setPort(managerInfo.getPort());
      restClient.setProtocol(managerInfo.getProtocol().toString());

      restClient.get(url, "application/json", (exception, httpStatus, response) => {
        const duration = Date.now()-startTS;
        logger.info("GET {} finished within {} ms", url, duration|0);

        if (exception) {
          logger.error("Exception {} occured.", exception);
          throw new Error(`Couldn't determine NSP version. Exception ${exception} occured.`);
        }

        if (httpStatus != 200) {
            logger.warn("NSP response: {} {}", httpStatus, response);
            throw new Error(`Couldn't determine NSP version. HTTP STATUS: ${httpStatus}`);
        }

        logger.info("NSP response: {} {}", httpStatus, response);

        const json = JSON.parse(response);
        const version = json.response.data.nspOSVersion.match(/\d+\.\d+(?=\.\d+)/)[0];

        const parts = version.split('.').map(v => parseInt(v));

        if (parts[0] > major)
          logger.info("Release check successful");
        else if ((parts[0] === major) && (parts[1] >= minor))
          logger.info("Release check successful");
        else if ((parts[0] === major) && (parts[1] === 0))
          logger.warn("ENGINEERING LOAD");
        else {
          const errmsg = `Incompatible NSP Release ${version} (expected: ${major}.${minor})`;
          logger.error(errmsg);
          throw new Error(errmsg);
        }
      });
    } else {
      logger.error("NSP mediator is diconnected.");
      throw new Error(`Couldn't determine NSP version. NSP mediator is diconnected.`);
    }

    const duration = Date.now()-startTS;
    logger.debug("NSP::checkRelease() finished within {} ms", duration|0);
	}

  /**
   * Performs a REST GET request to an NFM-P device through the mediator and returns the result.
   *
   * @param {string} target - Network element identifier of the target device.
   * @param {string} targetUrl - The endpoint URL to send the request to.
   * @param {string} requestType - The content type for the request (e.g., "application/json").
   * @returns {Object} result - Contains success status, HTTP status, and message.
   */
  static nfmpFetch(target, targetUrl, requestType) {
    const startTS = Date.now();
    let result = {};

    const managerInfo = mds.getAllManagersWithDevice(target).get(0);
    if (managerInfo.getConnectivityState().toString() === "CONNECTED") {
      restClient.setIp(managerInfo.getIp());
      restClient.setPort(managerInfo.getPort());
      restClient.setProtocol(managerInfo.getProtocol().toString());

      restClient.get(targetUrl, requestType, (exception, httpStatus, response) => {
          const duration = Date.now()-startTS;
          logger.info("Fetch {} finished within {} ms", url, duration|0);
          result = exception ? {
              success: false, httpStatus: httpStatus,
              msg: `Couldn't connect to Manager of Device: ${target}, got response ${response}`
          } : (httpStatus !== 200 && httpStatus !== 201) ? {
              success: false, httpStatus: httpStatus,
              msg: `Failed to fetch service from NFM-P device ${target}, got response ${response}`
          } : {
              success: true, httpStatus: httpStatus,
              msg: response
          }
        }
      );
    }   else {
      logger.error("Mediator for {} is disconnected.", neId);
      result = { success: false, errmsg: "Mediator for "+neId+" is disconnected." };
    }

    const duration = Date.now()-startTS;
    logger.debug("NFMP::nfmpFetch() finished within {} ms", duration|0);

    return result;
  }

  /**
   * Deploys a configuration payload to an NFM-P device through the mediator.
   *
   * @param {string} neId - Network element identifier of the target device.
   * @param {string} payload - The configuration data to be deployed.
   * @param {string} requestType - The content type for the request (e.g., "application/json").
   * @returns {Object} result - Contains success status, HTTP status, and message.
   */
  static nfmpDeploy(neId, payload, requestType) {
    const startTS = Date.now();
    let result = {};

    const managerInfo = mds.getAllManagersWithDevice(neId).get(0);
    if (managerInfo.getConnectivityState().toString() === "CONNECTED") {
      const PATH_SYNCHRONIZE = "/v3/synchronize?synchronousDeploy=true&clearOnDeployFailure=true";

      restClient.setIp(managerInfo.getIp());
      restClient.setPort(managerInfo.getPort());
      restClient.setProtocol(managerInfo.getProtocol().toString());

      logger.info("Deploying to target: " + neId + ", targetUrl: " + PATH_SYNCHRONIZE + ", payload: " + payload);

      restClient.post(PATH_SYNCHRONIZE, requestType, payload, "application/json", (exception, httpStatus, response) => {
          const duration = Date.now()-startTS;
          logger.info("Deploy {} finished within {} ms", PATH_SYNCHRONIZE, duration|0);
          result = exception ? {
              success: false, httpStatus: httpStatus,
              msg: `Couldn't connect to Manager of Device: ${neId}, got response ${response}`
          } : (httpStatus !== 200 && httpStatus !== 201 && httpStatus !== 204) ? {
              success: false, httpStatus: httpStatus,
              msg: `Failed deployment to NFM-P for device ${neId}, got response ${response}`
          } : {
              success: true, httpStatus: httpStatus, response: response,
              msg: `Deployment to NFM-P for device ${neId} was successful, got response ${response}`
          }
        }
      );
    }   else {
      logger.error("Mediator for {} is disconnected.", neId);
      result = { success: false, errmsg: "Mediator for "+neId+" is disconnected." };
    }
    logger.info("NFMP::nfmpDeploy(): Got result " + JSON.stringify(result));
    const duration = Date.now()-startTS;
    logger.debug("NFMP::nfmpDeploy() finished within {} ms", duration|0);

    return result;
  }

  /**
   * Sends a POST request to an NFM-P through the mediator and returns the result.
   *
   * @param {string} neId - Network element identifier of the target device.
   * @param {string} targetUrl - The URL endpoint where the POST request is sent.
   * @param {Object} expectedJson - The JSON payload to send in the request.
   * @returns {Object} result - Contains success status, HTTP status, and message.
   */
  static nfmpPOST(neId, targetUrl, expectedJson) {
    const startTS = Date.now();
    let result = {};

    const managerInfo = mds.getAllManagersWithDevice(neId).get(0);
    if (managerInfo.getConnectivityState().toString() === "CONNECTED") {
      restClient.setIp(managerInfo.getIp());
      restClient.setPort(managerInfo.getPort());
      restClient.setProtocol(managerInfo.getProtocol().toString());

      logger.info("[NFMP::nfmpPOST] POST URL: {}, Payload: {}", targetUrl, JSON.stringify(expectedJson, null, 2));

      restClient.post(targetUrl, "application/json", JSON.stringify(expectedJson), "application/json", (exception, httpStatus, response) => {
          const duration = Date.now()-startTS;
          logger.info("POST {} finished within {} ms", targetUrl, duration|0);
          result = exception ? {
              success: false, httpStatus: httpStatus,
              msg: `Couldn't connect to Manager of Device: ${neId}, got response ${response}`
          } : (httpStatus !== 200 && httpStatus !== 201) ? {
              success: false, httpStatus: httpStatus,
              msg: `Failed deployment to NFM-P for device ${neId}, got response ${response}`
          } : {
              success: true, httpStatus: httpStatus, response: response,
              msg: `Deployment to NFM-P for device ${neId} was successful, got response ${response}`
          }
        }
      );
    }   else {
      logger.error("Mediator for {} is disconnected.", neId);
      result = { success: false, errmsg: "Mediator for "+neId+" is disconnected." };
    }

    const duration = Date.now()-startTS;
    logger.debug("NFMP::nfmpPOST() finished within {} ms", duration|0);

    return result;
  }

  /**
   * Compares a payload against an NFM-P device using a POST request via the mediator.
   *
   * @param {string} neId - Network element identifier of the target device.
   * @param {string} payload - The payload data to be sent for comparison.
   * @param {string} requestType - The content type for the request (e.g., "application/json").
   * @returns {Object} result - Contains success status, HTTP status, and message.
   */
  static nfmpCompare(neId, payload, requestType) {
    const startTS = Date.now();
    let result = {};

    const managerInfo = mds.getAllManagersWithDevice(neId).get(0);
    if (managerInfo.getConnectivityState().toString() === "CONNECTED") {
      const PATH_COMPARE = "/v3/compare";

      restClient.setIp(managerInfo.getIp());
      restClient.setPort(managerInfo.getPort());
      restClient.setProtocol(managerInfo.getProtocol().toString());

      logger.info("Deploying to target: " + neId + ", targetUrl: " + PATH_COMPARE + ", payload: " + payload);

      restClient.post(PATH_COMPARE, requestType, payload, "application/json", (exception, httpStatus, response) => {
          const duration = Date.now()-startTS;
          logger.info("Compare {} finished within {} ms", PATH_COMPARE, duration|0);
          result = exception ? {
              success: false, httpStatus: httpStatus,
              msg: `Couldn't connect to Manager of Device: ${neId}, got response ${response}`
          } : (httpStatus !== 200 && httpStatus !== 201) ? {
              success: false, httpStatus: httpStatus,
              msg: `Failed deployment to NFM-P for device ${neId}, got response ${response}`
          } : {
              success: true, httpStatus: httpStatus, response: response,
              msg: `Deployment to NFM-P for device ${neId} was successful, got response ${response}`
          }
        }
      );
    }   else {
      logger.error("Mediator for {} is disconnected.", neId);
      result = { success: false, errmsg: "Mediator for "+neId+" is disconnected." };
    }
    logger.info("NFMP::nfmpCompare(): Got result " + JSON.stringify(result));
    const duration = Date.now()-startTS;
    logger.debug("NFMP::nfmpCompare() finished within {} ms", duration|0);

    return result;
  }

  /**
   * Sends a DELETE request to an NFM-P to delete a specified object on a device.
   *
   * @param {string} neId - Network element identifier of the target device.
   * @param {string} objectFullName - Full path of the object to delete on the device.
   * @param {string} requestType - The content type for the request (e.g., "application/json").
   * @returns {Object} result - Contains success status, HTTP status, and message.
   */
  static nfmpDeployDelete(neId, objectFullName, requestType) {
    const startTS = Date.now();
    let result = {};

    const managerInfo = mds.getAllManagersWithDevice(neId).get(0);
    if (managerInfo.getConnectivityState().toString() === "CONNECTED") {
      const PATH_DELETE = "/v3/delete/";

      restClient.setIp(managerInfo.getIp());
      restClient.setPort(managerInfo.getPort());
      restClient.setProtocol(managerInfo.getProtocol().toString());

      logger.info("Deleting: objectFullName: " + objectFullName + ", deleteUrl: " + PATH_DELETE + objectFullName + "?synchronousDeploy=true&clearOnDeployFailure=true");

      restClient.delete(PATH_DELETE + objectFullName + "?synchronousDeploy=true&clearOnDeployFailure=true", requestType, (exception, httpStatus, response) => {
          const duration = Date.now()-startTS;
          logger.info("DeployDelete {} finished within {} ms", PATH_DELETE, duration|0);
          result = exception ? {
              success: false, httpStatus: httpStatus,
              msg: `Couldn't connect to Manager of Device: ${objectFullName}, got response ${response}`
          } : (httpStatus !== 200 && httpStatus !== 201 && httpStatus !== 204) ? {
              success: false, httpStatus: httpStatus,
              msg: `Failed deployment to NFM-P for device ${objectFullName}, got response ${response}`
          } : {
              success: true, httpStatus: httpStatus,
              msg: `Deployment to NFM-P for device ${objectFullName} was successful, got response ${response}`
          }
        }
      );
    }   else {
      logger.error("Mediator for {} is disconnected.", neId);
      result = { success: false, errmsg: "Mediator for "+neId+" is disconnected." };
    }
    logger.info("NFMP::nfmpDeployDelete(): Got result " + JSON.stringify(result));
    const duration = Date.now()-startTS;
    logger.debug("NFMP::nfmpDeployDelete() finished within {} ms", duration|0);

    return result;
  }

  /**
   * Sends an XML-based REST POST request to an NFM-P through the mediator and returns the result.
   *
   * @param {string} neId - Identifier of the network element (device) to target.
   * @param {string} url - The REST endpoint URL to send the request to.
   * @param {string} req - The XML-formatted request payload.
   * @returns {Object} result - Contains success status, HTTP status, and message.
   */
  static nfmpPassThroughRequest(neId, url, req) {
    const startTS = Date.now();
    let result = {};

    const managerInfo = mds.getAllManagersWithDevice(neId).get(0);
    if (managerInfo.getConnectivityState().toString() === "CONNECTED") {
      restClient.setIp(managerInfo.getIp());
      restClient.setPort(managerInfo.getPort());
      restClient.setProtocol(managerInfo.getProtocol().toString());

      log.info(null, "Passing Through : " + url + ", with req: " + req);

      restClient.post(url, "application/xml", req, "application/xml", (exception, httpStatus, response) => {
          const duration = Date.now()-startTS;
          logger.info("DeployDelete {} finished within {} ms", url, duration|0);
          result = exception ? {
              success: false, httpStatus: httpStatus,
              msg: `Couldn't connect to Manager of Device: , got response ${response}`
          } : (httpStatus !== 200 && httpStatus !== 201 && httpStatus !== 204) ? {
              success: false, httpStatus: httpStatus,
              msg: `Failed deployment to NFM-P for device , got response ${response}`
          } : {
              success: true, httpStatus: httpStatus,
              msg: `Deployment to NFM-P for device  was successful, got response ${response}`
          }
        }
      );
    }   else {
      logger.error("Mediator for {} is disconnected.", neId);
      result = { success: false, errmsg: "Mediator for "+neId+" is disconnected." };
    }
    log.info(null, "NFMP::nfmpPassThroughRequest(): deploy pass through: Got result " + JSON.stringify(result));
    const duration = Date.now()-startTS;
    logger.debug("NFMP::nfmpPassThroughRequest() finished within {} ms", duration|0);

    return result;
  }

  /**
   * Executes NSP RESTCONF GET
   *
   * @param {string} resource model-path string of the parent resource
   * @returns success {boolean} and errmsg {string}
   */

  static restconfGET(resource) {
    const startTS = Date.now();
    logger.info("NSP::restconfPOST({})", resource);

    let result = {};
    const managerInfo = mds.getManagerByName("NSP");
    if (managerInfo.getConnectivityState().toString() === "CONNECTED") {
      const url = "https://restconf-gateway/restconf/data/"+resource;

      restClient.setIp(managerInfo.getIp());
      restClient.setPort(managerInfo.getPort());
      restClient.setProtocol(managerInfo.getProtocol().toString());

      restClient.get(url, "application/json", (exception, httpStatus, response) => {
        const duration = Date.now()-startTS;
        logger.info("GET {} finished within {} ms", url, duration|0);

        if (exception) {
          logger.error("Exception {} occured.", exception);
          result = { success: false, httpStatus: httpStatus, response: {}, errmsg: "Exception "+exception+" occured."};
        }
        else if (httpStatus >= 400) {
          // Either client error (4xx) or server error (5xx)
          let errmsg = "HTTP ERROR "+httpStatus;
          logger.warn("NSP response: {} {}", httpStatus, response);

          if ((/<html/i).test(response)) {
            // Extract error details from HTML response:
            const errMatch = response.match(/<body[^>]*>(.*)<\/body>/i);
            if (errMatch)
              errmsg = errMatch[1].trim(); // extracted errmsg from html body
          } else {
            // Extract error details from JSON response:
            //
            // Error details returned in accordance to rfcC8040
            //   {"ietf-restconf:errors":{"error":[{ error details }]}}
            //
            // Error fields (check rfc6241 for details):
            //   error-type       enumeration
            //   error-tag        string
            //   error-app-tag?   string
            //   error-path?      instance-identifier
            //   error-message?   string
            //   error-info?      anydata

            const errorObject = JSON.parse(response);
            if ("ietf-restconf:errors" in errorObject)
              errmsg = errorObject["ietf-restconf:errors"].error.map(error => error["error-message"]).join(", ");
          }

          result = { success: false, httpStatus: httpStatus, response: {}, errmsg: errmsg};
        }
        else if (httpStatus == 201) {
          logger.debug("NSP response: {}", httpStatus);
          result = { success: true, httpStatus: httpStatus, };
        } else {
          logger.info("NSP response: {} {}", httpStatus, response);
          result = { success: true, httpStatus: httpStatus, response: JSON.parse(response) };
        }
      });
    } else
      result = { success: false, errmsg: "NSP mediator is disconnected." };

    const duration = Date.now()-startTS;
    logger.debug("NSP::restconfGET() finished within {} ms", duration|0);

    return result;
  }

  /**
   * Sends the updated intentConfig(after BrownField Discovery) to the ICM action-result endpoint via POST request using restClient.
   * Logs performance, response, and errors. Returns result with success status and response data.
   *
   * @param {Object} data - The payload to be sent via POST.
   * @returns {Object} result - Contains success status, HTTP status, and message.
   */
  static gtdSend(data) {
    const startTS = Date.now();
    logger.debug("NSP::gtdSend({})", data);
    let result = {};

    restClient.setIp("nsp-infra-config-server-app-service");
    restClient.setPort(parseInt("8888"));
    restClient.setProtocol("http");

    logger.info(JSON.stringify(data));
    restClient.post("action-result", "application/json", JSON.stringify(data), "application/json", (exception, httpStatus, response) => {
      const duration = Date.now() - startTS;
      logger.debug("POST {} finished within {} ms", JSON.stringify(data), duration | 0);

      if (exception) {
        result = { success: false, httpStatus, msg: `Couldn't connect got response ${response}` };
      } else if (httpStatus !== 200 && httpStatus !== 201) {
        result = { success: false, httpStatus, msg: `Failed to fetch service got response ${response}` };
      } else {
        logger.info(JSON.stringify(response));
        result = { success: true, httpStatus, msg: JSON.parse(response) };
      }
    });

    logger.debug("NSP::gtdSend() finished within {} ms", Date.now() - startTS | 0);
    return result;
  }

}
