function ModelDeviceMapping() {
    this.getDcpuPolicyMapping = function () {
        var mapping = {};
        mapping['policy.description'] = 'description';
        mapping['policy.type'] = 'dCpuProtectionPolicyType';
        return mapping;
    }
    this.getDcpuChildMapping = function () {
        var mapping = {};
        //Static Policier
        mapping['policy.static-policer.policer-name'] = "displayedName";
        mapping['policy.static-policer.description'] = "description";
        mapping['policy.static-policer.detection-time'] = "detectionTime";
        mapping['policy.static-policer.log-events'] = "logEventsState";
        //exceed-action
        mapping['policy.static-policer.exceed-action.action'] = "exceedAction";
        mapping['policy.static-policer.exceed-action.hold-down'] = "holdDownDuration";
        //rate
        mapping['policy.static-policer.rate.type'] = "rateType";
        mapping['policy.static-policer.rate.kbps.limit'] = "kbpsRateLimit";
        mapping['policy.static-policer.rate.kbps.mbs'] = "bufferSpace";
        mapping['policy.static-policer.rate.packets.limit'] = "packetRateLimit";
        mapping['policy.static-policer.rate.packets.within'] = "timeLimit";
        mapping['policy.static-policer.rate.packets.initial-delay'] = "initPacketLimit";

        //Local Monitor Policier
        mapping['policy.local-monitoring-policer.policer-name'] = "displayedName";
        mapping['policy.local-monitoring-policer.description'] = "description";
        mapping['policy.local-monitoring-policer.log-events'] = "logEventsState";
        //exceed-action
        mapping['policy.local-monitoring-policer.exceed-action'] = "exceedAction";
        //rate
        mapping['policy.local-monitoring-policer.rate.type'] = "rateType";
        mapping['policy.local-monitoring-policer.rate.kbps.limit'] = "kbpsRateLimit";
        mapping['policy.local-monitoring-policer.rate.kbps.mbs'] = "bufferSpace";
        mapping['policy.local-monitoring-policer.rate.packets.limit'] = "packetRateLimit";
        mapping['policy.local-monitoring-policer.rate.packets.within'] = "timeLimit";
        mapping['policy.local-monitoring-policer.rate.packets.initial-delay'] = "initPacketLimit";

        //Protocol
        mapping['policy.protocol.protocol-name'] = "protocolId";
        mapping['policy.protocol.enforcement.type'] = "enforceType";
        mapping['policy.protocol.enforcement.static.policer-name'] = "enforcementPolicerName";
        mapping['policy.protocol.enforcement.dynamic.mon-policer-name'] = "enforcementPolicerName";
        mapping['policy.protocol.enforcement.dynamic-local-mon-bypass'] = "enforcementPolicerName";
        mapping['policy.protocol.enforcement.shared.shared-policer-name'] = "enforcementSharedPolicerName";
        mapping['policy.protocol.dynamic-parameters.detection-time'] = "detectionTime";
        mapping['policy.protocol.dynamic-parameters.log-events'] = "logEventsState";
        //exceed-action
        mapping['policy.protocol.dynamic-parameters.exceed-action.action'] = "exceedAction";
        mapping['policy.protocol.dynamic-parameters.exceed-action.hold-down'] = "holdDownDuration";
        //rate
        mapping['policy.protocol.dynamic-parameters.rate.type'] = "rateType";
        mapping['policy.protocol.dynamic-parameters.rate.kbps.limit'] = "kbpsRateLimit";
        mapping['policy.protocol.dynamic-parameters.rate.kbps.mbs'] = "bufferSpace";
        mapping['policy.protocol.dynamic-parameters.rate.packets.limit'] = "packetRateLimit";
        mapping['policy.protocol.dynamic-parameters.rate.packets.within'] = "timeLimit";
        mapping['policy.protocol.dynamic-parameters.rate.packets.initial-delay'] = "initPacketLimit";
        return mapping;
    }
}
