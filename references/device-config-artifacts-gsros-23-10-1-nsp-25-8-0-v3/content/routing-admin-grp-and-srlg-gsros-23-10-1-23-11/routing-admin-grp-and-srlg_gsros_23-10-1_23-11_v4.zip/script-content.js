var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
  "ibn" : "http://www.nokia.com/management-solutions/ibn",
  "nc" : "urn:ietf:params:xml:ns:netconf:base:1.0",
  "device-manager" : "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
  "http://www.nokia.com/management-solutions/anv-device-holders" : "anv-device-holders"
};


load({script:resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

var intentTypeName = 'routing-admin-grp-and-srlg_gsros_23-10-1_23-11';

// example port, sap-ingress etc..
var initialPropertyName = 'if-attribute';


// unique identifier
var uniqueIdentifier = 'admin-grp-srlg';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/routing-options';

function synchronize(input) {
  logger.info('Intent Synchronisation started')

  return NspIntentHelper.synchronize(input,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier);
}

function onAudit(target, config, svcTopo, adminState) {
  logger.info('Intent Audit started')

  return NspIntentHelper.audit(target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function suggestAdminGrpAndSrlg(context) {
  logger.info("suggestAdminGrpAndSrlg =>\n" + context)
  return ["admin-grp-srlg"];
}

function getTargetData(input) {
  logger.info(input);
  var target = input.target;
  logger.info("target=" + target);
  var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
  var data = gtdFwk.gtdSend(deviceConfig);
  return data.msg.result;
}
