var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn" : "http://www.nokia.com/management-solutions/ibn",
    "nc" : "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager" : "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders" : "anv-device-holders"
};


load({script:resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();
load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
var mdtFwk =  new MdtFwk();
load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})
load({script: resourceProvider.getResource('mdSuggest.js'), name: 'MdSuggest'})

var intentTypeName = 'file-accounting_gsros_23-10-1_23-11';

// example port, sap-ingress etc..
var initialPropertyName = 'log';


// unique identifier
var uniqueIdentifier = 'id';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure';

function synchronize(input) {
    logger.info('Intent Synchronisation started')

    return NspIntentHelper.synchronize(input,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier);
}

function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started')

    return NspIntentHelper.audit(target, config, svcTopo, adminState,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier);
}

function getTargetData(input) {
    logger.info("getTargetData input for brownfield = \n" + input);
    var target = input.target;
    var config = null;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info(JSON.stringify(deviceConfig));
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}

function suggestAccountingPolicyID(context) {
    logger.info("suggestAccountingPolicyID context = \n" + context);
    var neId = getNeId(context);
    return navigateInstance(neId).getAccountingPolicyId(neId);
}

function suggestQueueId(context) {
   logger.info("suggestQueueId context = \n" + context);
   var result=[];
   var inp = JSON.parse(context['inputValues'])
   var queueList = inp['arguments']['log']['accounting-policy']['custom-record']['queue'];

   if (queueList!==null || queueList!==undefined){
       if (!Array.isArray(queueList)) {
           queueList = [queueList];
       }
       for (var i = 0; i < queueList.length; i++)
       {
           result.push(queueList[i]['id']);
       }
   }
   return result;
}

function suggestPolicerId(context) {
   logger.info("suggestPolicerId context = \n" + context);
   var result=[];
   var inp = JSON.parse(context['inputValues'])
   var policerList = inp['arguments']['log']['accounting-policy']['custom-record']['policer'];

   if (policerList!==null || policerList!==undefined){
       if (!Array.isArray(policerList)) {
           policerList = [policerList];
       }
       for (var i = 0; i < policerList.length; i++)
       {
           result.push(policerList[i]['id']);
       }
   }
   return result;
}

function getNeId(context) {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    logger.info(target)
    if (target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    logger.info("NeId : " + neId);
    return neId;
}

function navigateInstance(neId) {
    var managerName = mdtFwk.getManagerName(neId);
    logger.info('Device: ' + neId + ' is managed by: ' + managerName);
    switch (managerName)
    {
        case 'NFM-P':
            logger.info('Device is managed by NFMP')
            return new NfmpSuggest();
            break;
        case 'MDC':
            logger.info('Device is managed by MDM')
            return new MdSuggest();
            break;
        default:
            logger.info('Device is not managed')
            throw new RuntimeException('Device is not Managed')
    }
    return ''
}