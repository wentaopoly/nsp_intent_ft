function ModelDeviceMapping() {

  this.getBfdTemplateMapping = function () {
    var mapping = {};
    mapping["bfd-template.multiplier"] = "multiplier";
    mapping["bfd-template.transmit-interval"] = "transmitTimer";
    mapping["bfd-template.echo-receive"] = "echoReceiveInterval";
    mapping["bfd-template.receive-interval"] = "receiveTimer";
    mapping["bfd-template.type"] = "templateType";
    return mapping;
  }

}
