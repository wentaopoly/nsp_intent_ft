var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
var mdtFwk = new MdtFwk();

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})
load({script: resourceProvider.getResource('mdSuggest.js'), name: 'MdSuggest'})

var intentTypeName = 'icm-equipment-card_mda';

// example port, sap-ingress etc..
var initialPropertyName = 'card';

// unique identifier
var uniqueIdentifier = 'slot-number';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure';

function synchronize(input) {
    logger.info('Intent Synchronisation started :\n' + input)
    return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started')
    return NspIntentHelper.audit(target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function suggestCardTypes(context) {
    logger.info("suggestCardTypes context = \n" + context);
    var neId = getNeId(context);
    var slotId = getCardSlot(context);
    return navigateInstance(neId).getCardTypes(neId, slotId);
}

function suggestMdaTypes(context) {
    logger.info("suggestMdaTypes context = \n" + context);
    var neId = getNeId(context);
    var slotId = getCardSlot(context);
    var mdaSlotId = context.getInputValues()["arguments"]["mda-slot"];
    var xiomSlotId = context.getInputValues()["arguments"]["__parent"]["xiom-slot"];
    return navigateInstance(neId).getMdaTypes(neId, slotId, xiomSlotId, mdaSlotId);
}

function suggestXiomTypes(context) {
    logger.info("suggestXiomTypes context = \n" + context);
    var neId = getNeId(context);
    var slotId = getCardSlot(context);
    var xiomSlotId = context.getInputValues()["arguments"]["xiom-slot"];
    return navigateInstance(neId).getXiomTypes(neId, slotId, xiomSlotId);
}

function getNeId(context) {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    logger.info(target)
    if (target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    else
    {
        var arguments = JSON.parse(context.getInputValues());
        neId = neIdIterator(arguments["arguments"]);
    }
    logger.info("NeId : " + neId);
    return neId;
}

function neIdIterator(context) {
    var parent = context["__parent"];
    if (parent)
    {
        var neId = parent["target_objectidentifier"];
        if (!neId)
        {
            neId = neIdIterator(parent)
        }
        return neId;
    }
}

function getCardSlot(context) {
    var cardSlotId;
    var target = context.getInputValues()["target"]["slot-number"];
    logger.info("target =" + target)
    if (target)
    {
        cardSlotId = target;
    }
    else
    {
        logger.info("target is empty...Checking other possibility")
        target = context.getInputValues()["target"]["objectidentifier"];
        logger.info("target =" + target)
        if (target)
        {
            if (target.match("slot=\\d"))
            {
                cardSlotId = target.match("slot=\\d")[0].split("=")[1];
            }
            else if (target.match("cardSlot=\\d"))
            {
                cardSlotId = target.match("cardSlot=\\d")[0].split("=")[1];
            }
        }
        else
        {
            var arguments = JSON.parse(context.getInputValues());
            cardSlotId = cardSlotIterator(arguments["arguments"]);
            logger.info("cardSlotId =" + cardSlotId)
        }

    }
    cardSlotId = cardSlotId.replaceAll("Card Slot - ", "").replaceAll("Card Slot-", "");
    logger.info("CardSlotId : " + cardSlotId);
    return cardSlotId;
}

function cardSlotIterator(context) {
    var parent = context["__parent"];
    if (parent)
    {
        var cardSlotID = parent["target_slot-number"];
        if (!cardSlotID)
        {
            cardSlotID = cardSlotIterator(parent)
        }
        return cardSlotID;
    }
}

function navigateInstance(neId) {
    var managerName = mdtFwk.getManagerName(neId);
    logger.info('Device: ' + neId + ' is managed by: ' + managerName);
    switch (managerName)
    {
        case 'NFM-P':
            logger.info('Device is managed by NFMP')
            return new NfmpSuggest();
            break;
        case 'MDC':
            logger.info('Device is managed by MDM')
            return new MdSuggest();
            break;
        default:
            logger.info('Device is not managed')
            throw new RuntimeException('Device is not Managed')
    }
    return ''
}

function getTargetData(input) {
    logger.info("getTargetData input for brownfield = \n" + input);
    var target = input.target;
    var config = null;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info(JSON.stringify(deviceConfig));
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}