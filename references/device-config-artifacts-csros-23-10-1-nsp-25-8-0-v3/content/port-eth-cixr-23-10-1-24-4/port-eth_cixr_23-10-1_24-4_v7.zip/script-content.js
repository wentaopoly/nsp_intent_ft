	var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
const icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
const gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})
var nfmpSuggest = new NfmpSuggest();

let intentTypeName = "port-eth_cixr_23-10-1_24-4";

// example port, sap-ingress etc..
let initialPropertyName = "equipment-PhysicalPort";

var LOG_PREFIX = "[Port]: "

// unique identifier
let uniqueIdentifier = "port-id";


/**
 * This function is starting point by IM for sync operation
 * @param input
 * @returns {*}
 */
function synchronize(input) {
    logger.info("-------------------- script-content.js -> synchronize() --------------------");
    logger.info("Intent Synchronisation started - input = {}", input)
    return NspIntentHelper.synchronize(input, intentTypeName, initialPropertyName, uniqueIdentifier);
}

/**
 * The function is starting point for audit operation in IM
 * @param input
 * @returns {*}
 */
function audit(input) {
    logger.info("-------------------- script-content.js -> audit() --------------------");
    logger.info("Intent Audit started - input = {}", input)
    return NspIntentHelper.audit(input, intentTypeName, initialPropertyName, uniqueIdentifier)
}

/**
 * This function returns NE-ID
 *
 * @param context
 * @returns {string}
 */
function getNeId(context) {
    logger.info("-------------------- script-content.js -> getNeId() --------------------");
    let neId;
    let target = context.getInputValues()["target"]["objectidentifier"];
    logger.info("target = {}", target)
    if (target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    logger.info("NeId : " + neId);
    return neId;
}

/**
 * The function is used in Brownfield discovery by ICM Framework
 * It discover's the configuration from the target device
 * and manipulate as per Template's default-target-data
 *
 * @see ICMFwk for more details
 * @param {*} input - the config data of a deployment
 * @returns result - the result of the operation
 */
function getTargetData(input) {
    logger.info("-------------------- script-content.js -> getTargetData() --------------------");
    logger.info("getTargetData input for brownfield = \n" + input);
    let target = input.target;
    let config = null;
    logger.info("target=" + target);
    let deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info("deviceConfig = {} ", JSON.stringify(deviceConfig));
    let data = gtdFwk.gtdSend(deviceConfig);
    logger.info("data = {}", JSON.stringify(data));
    logger.info("returning result = {}", JSON.stringify(data.msg.result));
    return data.msg.result;
}

function suggestPolicyDefinitionName(context) {
    logger.info(LOG_PREFIX + "suggestPolicyDefinitionName context = \n" + context);
    return nfmpSuggest.getPolicyDefinitionName();
}

function suggestPortSchedulerOverridePortSchedulerName(context) {
    logger.info(LOG_PREFIX + "suggestPortSchedulerOverridePortSchedulerName context = \n" + context);
    return [context.getInputValues()["arguments"]["__parent"]["equipment-PhysicalPort"]["portSchedulerPolicyObjectPointer"]];
}

function suggestNetworkQueueObjectName(context) {
    logger.info(LOG_PREFIX + "suggestNetworkQueueObjectName context = \n" + context);
    return nfmpSuggest.getNetworkQueueObjectName();
}

function suggestUNIProfileName(context) {
    logger.info(LOG_PREFIX + "suggestUNIProfileName context = \n" + context);
    return nfmpSuggest.getUNIProfileName();
}

function suggestPortEgrHsmdaSchedulerPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestPortEgrHsmdaSchedulerPolicyName context = \n" + context);
    return nfmpSuggest.getPortEgrHsmdaSchedulerPolicyName();
}

function suggestL2ProfileName(context) {
    logger.info(LOG_PREFIX + "suggestL2ProfileName context = \n" + context);
    return nfmpSuggest.getL2ProfileName();
}

function suggestHsSchedulerName(context) {
    logger.info(LOG_PREFIX + "suggestHsSchedulerName context = \n" + context);
    return nfmpSuggest.getHsSchedulerName();
}

function suggestHsPortPoolName(context) {
    logger.info(LOG_PREFIX + "suggestHsPortPoolName context = \n" + context);
    return nfmpSuggest.getHsPortPoolName();
}

function suggestPortRmdName(context) {
    logger.info(LOG_PREFIX + "suggestPortRmdName context = \n" + context);
    return nfmpSuggest.getPortRmdName(getNeId(context));
}

function suggestSapName(context) {
    logger.info(LOG_PREFIX + "suggestSapName context = \n" + context);
    let snmpPortId = getSnmpPortId((context.getInputValues()["target"]["port-id"]).replace("Port",""));
    return nfmpSuggest.getSapName(getNeId(context), snmpPortId);
}

function suggestVlanFilterName(context) {
    logger.info(LOG_PREFIX + "suggestVlanFilterName context = \n" + context);
    return nfmpSuggest.getVlanFilterName();
}

function suggestShaperPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestShaperPolicyName context = \n" + context);
    return nfmpSuggest.getShaperPolicyName();
}

function suggestSystemOperGroupName(context) {
    logger.info(LOG_PREFIX + "suggestSystemOperGroupName context = \n" + context);
    return nfmpSuggest.getSystemOperGroupName(getNeId(context));
}

function suggestEgressQGroupPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestEgressQGroupPolicyName context = \n" + context);
    return nfmpSuggest.getEgressQGroupPolicyName();
}

function suggestAccessEgrQueueGroupName(context) {
    logger.info(LOG_PREFIX + "suggestAccessEgrQueueGroupName context = \n" + context);
    return [context.getInputValues()["arguments"]["__parent"]["queueGroupPolicyPointer"]];
}

function suggestNetworkEgrQueueGroupName(context) {
    logger.info(LOG_PREFIX + "suggestNetworkEgrQueueGroupName context = \n" + context);
    return [context.getInputValues()["arguments"]["__parent"]["queueGroupPolicyPointer"]];
}

function suggestAccountingPolicyId(context) {
    logger.info(LOG_PREFIX + "suggestAccountingPolicyId context = \n" + context);
    let mode = context.getInputValues()["arguments"]["equipment-PhysicalPort"]["mode"];
    return nfmpSuggest.getAccountingPolicyId(getNeId(context),mode);
}

function suggestEthAccessAccountingPolicyId(context) {
    logger.info(LOG_PREFIX + "suggestEthAccessAccountingPolicyId context = \n" + context);
    return nfmpSuggest.getEthAccessAccountingPolicyId(getNeId(context));
}

function suggestEtherAccountingPolicyId(context) {
    logger.info(LOG_PREFIX + "suggestEtherAccountingPolicyId context = \n" + context);
    return nfmpSuggest.getEtherAccountingPolicyId(getNeId(context));
}

function suggestQGroupAccountingPolicyId(context) {
    logger.info(LOG_PREFIX + "suggestEtherAccountingPolicyId context = \n" + context);
    return nfmpSuggest.getQGroupAccountingPolicyId(getNeId(context));
}

function suggestSchedulerPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestSchedulerPolicyName context = \n" + context);
    return nfmpSuggest.getSchedulerPolicyName();
}

function suggestHsmdaEgressSecondaryShaperName(context) {
    logger.info(LOG_PREFIX + "suggestHsmdaEgressSecondaryShaperName context = \n" + context);
    let target = context.getInputValues()["target"]["objectidentifier"];
    let portId = context.getInputValues()["target"]["port-id"];

    let shelfId;
    var splittedTarget = target.split("/");
    for (let i = 4; i < splittedTarget.length; i++) {
        if (splittedTarget[i].indexOf("shelf=") != -1 ){
            shelfId = splittedTarget[i].split("shelf=")[1];
        }
    }
    logger.info("shelfId = {}",shelfId);
    let snmpPortId = getSnmpPortId(portId.replace("Port",""));
    logger.info("snmpPortId = {}",snmpPortId);

    return nfmpSuggest.getHsmdaEgressSecondaryShaperName(getNeId(context),shelfId,snmpPortId);
}

/**
 * This function returns NE-ID
 *
 * @param context
 * @returns {string}
 */
function getSnmpPortId(portId) {
    let portIds = portId.split("/");
    let cardSlot;
    let xiomSlot;
    let mdaSlot;
    let connector;
    let portNumber

    portIds.forEach(function (item, index) {
        switch (index)
        {
            case 0:
                cardSlot = item;
                break;
            case 1:
                //xiom
                if (isNaN(item))
                {
                    xiomSlot = item;
                }
                else
                {
                    mdaSlot = item;
                }
                break;
            case 2:
                //connector
                if (isNaN(item))
                {
                    connector = item;
                }
                else if (mdaSlot)
                {
                    portNumber = item;
                }
                else
                {
                    mdaSlot = item;
                }
                break;
            case 3:
                //connector
                if (isNaN(item))
                {
                    connector = item;
                }
                else
                {
                    portNumber = item;
                }
                break;
            case 4:
                portNumber = item;
                break;


        }
    });
    var snmpPortId = cardSlot << 25;
    snmpPortId |= (mdaSlot << 21);
    snmpPortId |= (portNumber << 15);
    return snmpPortId;

}

function suggestHsmdaWrrPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestHsmdaWrrPolicyName context = \n" + context);
    return nfmpSuggest.getHsmdaWrrPolicyName();
}

function suggestEgressQueueId(context) {
    logger.info(LOG_PREFIX + "suggestEgressQueueId context = \n" + context);
    var queueGroupPolicyName = context.getInputValues()["arguments"]["__parent"]["queueGroupPolicyPointer"];
    var ret = nfmpSuggest.getEgressQueueId(getNeId(context),queueGroupPolicyName);
    var accessEgrQOverrides = context.getInputValues()["arguments"]["__parent"]["ethernetequipment-AccessEgrQOverride"];
    for (var index in accessEgrQOverrides) {
        ret = ret.filter(el => el !== accessEgrQOverrides[index]["queueId"]);
    }
    return ret
}

function suggestNetworkEgrQueueId(context) {
    logger.info(LOG_PREFIX + "suggestNetworkEgrQueueId context = \n" + context);
    var queueGroupPolicyName = context.getInputValues()["arguments"]["__parent"]["queueGroupPolicyPointer"];
    var ret = nfmpSuggest.getEgressQueueId(getNeId(context),queueGroupPolicyName);
    var networkEgrOverrides = context.getInputValues()["arguments"]["__parent"]["ethernetequipment-NetworkEgrQOverride"];
    for (var index in networkEgrOverrides) {
        ret = ret.filter(el => el !== networkEgrOverrides[index]["queueId"]);
    }
    return ret
}

function suggestschedulerName(context) {
    logger.info(LOG_PREFIX + "suggestschedulerName context = \n" + context);
    var schedulerPolicyName = context.getInputValues()["arguments"]["__parent"]["schedulerPolicyPointer"];
    return nfmpSuggest.getSchedulerName(getNeId(context),schedulerPolicyName);;
}

function suggestIngressQGroupPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestIngressQGroupPolicyName context = \n" + context);
    return nfmpSuggest.getIngressQGroupPolicyName();
}

function suggestAccessIngrQGroupPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestAccessIngrQGroupPolicyName context = \n" + context);
    return [context.getInputValues()["arguments"]["__parent"]["queueGroupPolicyPointer"]];
}

function suggestIngressQueueId(context) {
    logger.info(LOG_PREFIX + "suggestIngressQueueId context = \n" + context);
    var queueGroupPolicyName = context.getInputValues()["arguments"]["__parent"]["queueGroupPolicyPointer"];
    var ret =  nfmpSuggest.getIngressQueueId(getNeId(context),queueGroupPolicyName);
    var accessIngrQOverrides = context.getInputValues()["arguments"]["__parent"]["ethernetequipment-AccessIngrQOverride"];
    for (var index in accessIngrQOverrides) {
        ret = ret.filter(el => el !== accessIngrQOverrides[index]["queueId"]);
    }
    return ret
}

function suggestPolicerControlPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestPolicerControlPolicyName context = \n" + context);
    return nfmpSuggest.getPolicerControlPolicyName();
}

function suggestRadiusServerPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestRadiusServerPolicyName context = \n" + context);
    return nfmpSuggest.getRadiusServerPolicyName();
}

function suggestPortName(context) {
    logger.info(LOG_PREFIX + "suggestPortName context = \n" + context);
    return nfmpSuggest.getPortName(getNeId(context));
}

function suggestMacPolicyId(context) {
    logger.info(LOG_PREFIX + "suggestMacPolicyId context = \n" + context);
    return nfmpSuggest.getMacPolicyId();
}

function suggestCaName(context) {
    logger.info(LOG_PREFIX + "suggestCaName context = \n" + context);
    return nfmpSuggest.getCaName(getNeId(context));
}

function suggestPortSchedulerPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestPortSchedulerPolicyName context = \n" + context);
    return nfmpSuggest.getPortSchedulerPolicyName();
}

function suggestHwAggShaperSchedulerPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestHwAggShaperSchedulerPolicyName context = \n" + context);
    return nfmpSuggest.getHwAggShaperSchedulerPolicyName();
}

function suggestSlopePolicyName(context) {
    logger.info(LOG_PREFIX + "suggestSlopePolicyName context = \n" + context);
    return nfmpSuggest.getSlopePolicyName(getNeId(context));
}

function suggestMonitorOperGroupName(context) {
    logger.info(LOG_PREFIX + "suggestMonitorOperGroupName context = \n" + context);
    return nfmpSuggest.getMonitorOperGroupName(getNeId(context));
}

function suggestVlanQosPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestVlanQosPolicyName context = \n" + context);
    return nfmpSuggest.getVlanQosPolicyName(getNeId(context));
}

function suggestPortQosPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestPortQosPolicyName context = \n" + context);
    return nfmpSuggest.getPortQosPolicyName(getNeId(context));
}