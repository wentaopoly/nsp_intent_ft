var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk'});
load({script: resourceProvider.getResource('traverse-fwk.js'), name: 'TraverseFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
load({script: resourceProvider.getResource('intentConfigValueReplacer.js'), name: 'IntentConfigValueReplacer'});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities" });
function MdcIntentFwk() {
    var intentDeviationObj = new IntentDeviceDeviation();
    var intentConfigValueReplacerObj = new IntentConfigValueReplacer();
    var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,5}(:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){6}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(\/(0|[1-9][0-9]?|1[0-1][0-9]?|12[0-8]))?$/;
    var util = new utilities();
    this.restResponseHandler = function (exception, httpStatus, response) {
        logger.info("[IntentMgr] REST response : " + response);
        logger.info("[IntentMgr] REST httpStatus : " + httpStatus);
        if (exception) {
            throw new RuntimeException("Couldn't connect to device proxy for ; Response: " + response);
        }

        if (httpStatus !== 200 && httpStatus !== 201) {
            throw new RuntimeException("Failed to access device  using MDC; Response: " + response);
        }

        restResponse = JSON.parse(response);
    };

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {

        var traverseFwk = new TraverseFwk();
        var parseTarget = new ParseTarget();
        var target = parseTarget.getNeIdFromTarget(input.getTarget());

        var neFamily = intentDeviationObj.getNeFamilyRelease(target);
        var neVersion = intentDeviationObj.getNeVersion(neFamily);

        // saved topology
        var savedTopology = input.getCurrentTopology();

        if (savedTopology == null) {
            savedTopology = topologyFactory.createServiceTopology();
        }

        if (input.getNetworkState().name() == "delete") {
            logger.info(JSON.stringify(savedTopology));
            traverseFwk.resetTheVariables();
            var requests = [];
            var deleteObj = {};
            deleteObj["operation"] = "delete";
            deleteObj["edit-id"] = "edit-" + new Date().getTime();
            if (neVersion.startsWith("19.") || neVersion.startsWith("20.")) {
                deleteObj["target"] = "nokia-conf:/configure/lag=" + parseInt(input.getTarget().split("#")[3]);
            } else {
                deleteObj["target"] = "nokia-conf:/configure/lag=" + parseTarget.getUniqueIdentifier(input.getTarget());
            }
            requests.push(deleteObj)
            result = traverseFwk.syncRequest(target, requests, result, savedTopology);
            result.setTopology(null);
            return result;
        }

        var intentConfig;

        if (target !== "0.0.0.0") {
            var intentConfig;
            intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];

            if (neVersion.startsWith("19.") || neVersion.startsWith("20.")) {
                delete intentConfig["max-ports"];
                intentConfig["lag-index"] = parseInt(input.getTarget().split("#")[3]);
            } else {
                intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());
            }

            //Removing deviations info
            intentConfig = intentDeviationObj.removeIntentConfig(intentConfig, target);
            //Replace Values
            intentConfig = intentConfigValueReplacerObj.replaceConfigValue(intentConfig);

            //NSPD-302227:per-link-hash is not supported on ESS and XRS node if lag mode is access
            var neType = intentDeviationObj.getNeType(neFamily);
            if(intentConfig['mode'] === "access" && (neType === "7950 XRS" || neType === "7450 ESS")){
                delete intentConfig['per-link-hash'];
            }

            if (intentConfig) {
                savedTopology = traverseFwk.traverse(target, intentConfig, savedTopology, null, parentXpath, initialPropertyName);

                //sorting delete array
                var deleteRequests = traverseFwk.getDeleteRequests();
                deleteRequests.sort(function (a, b) {
                    return b["target"].length - a["target"].length;
                });

                // concating createrequests and deleterequests
                var createRequests = traverseFwk.getCreateRequests();
                var requests;
                if (deleteRequests && createRequests) {
                    requests = deleteRequests.concat(createRequests);
                }
                if (requests) {
                    result = traverseFwk.syncRequest(target, requests, result, savedTopology);
                }

            } else {

                result = traverseFwk.deleteAllFromTopology(savedTopology, target, result);
            }

        }
        traverseFwk.resetTheVariables();
        return result;
    }

    this.audit = function (target, config, svcTopo, adminState, report, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        var currentConfig;
        var traverseFwk = new TraverseFwk();
        var parseTarget = new ParseTarget();
        currentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        currentConfig = this.expandIPv6(currentConfig);
        var targetNeId = parseTarget.getNeIdFromTarget(target);
        var neFamily = intentDeviationObj.getNeFamilyRelease(targetNeId);
        var neVersion = intentDeviationObj.getNeVersion(neFamily);
        if (neVersion.startsWith("19.") || neVersion.startsWith("20.")) {
            currentConfig["lag-index"] = parseInt(target.split("#")[3]);
        } else {
            currentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        }
        //Ignoring deviations compare
        currentConfig = intentDeviationObj.removeIntentConfig(currentConfig, targetNeId);
        //Replace Values
        currentConfig = intentConfigValueReplacerObj.replaceConfigValue(currentConfig);

        if (currentConfig["lacp"]) {
            if (currentConfig["lacp"]["system-id"]) {
                currentConfig["lacp"]["system-id"] = currentConfig["lacp"]["system-id"].replaceAll("-", ":");
            }
        }
        if (targetNeId !== "0.0.0.0") {

            svcTopo = traverseFwk.traverse(targetNeId, currentConfig, svcTopo, report, parentXpath, initialPropertyName);
            // reseting the variables
            traverseFwk.resetTheVariables();
        }

        return report;

    }

    this.getNodes = function (context) {
        var returnVal = []
        var url = "/restconf/meta/api/v1/nes"
        try {
            var managerList = []
            var managers = mds.getAllManagersOfType("REST");
            managers.forEach(function (manager) {
                if (mds.getManagerByName(manager).getConnectivityState().toString() === 'CONNECTED') {
                    managerList.push(manager)
                }
            })

            var devices = mds.getAllManagedDevicesFrom(managerList);

            devices.forEach(function (device) {
                returnVal.push(device.getName());
            });

            return returnVal;
        } catch (e) {
            logger.info("Exception *******************  : " + e);
            return {
                "Device Not Found": "Device Not Found"
            }
        }
    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }

    this.expandIPv6 = function (obj) {
        for (var key in obj) {
            if (typeof obj[key] === 'object' && obj[key] !== null) {
                this.expandIPv6(obj[key]);
            } else if (typeof obj[key] === 'string' && this.matchExact(ipv6Regex, obj[key])) {
                obj[key] = this.expandIPv6AddressForMd(obj[key]);
            }
        }
      return obj
    }

    this.matchExact = function(r, str) {
        var match = str.match(r);
        return match && str === match[0];
    }

    this.expandIPv6AddressForMd = function (input) {
        var expanded = util.expandIPv6ForMd(input);
        expanded = util.MdIpv6ValidAddresssMaskSupport(expanded);
        return expanded;
    };
}
