function NspSuggest(){
    this.getCustomerName = function (customerId){
        return this.getData(customerId,null,"customer-name")
    }

    this.getCustomerId = function (customerName){
        return this.getData(null,customerName,"customer-id")
    }

    this.getData = function (customerId,customerName,type) {
        var ret = [];
        var resultFetch = nspRestconfFwk.getCustomerData();
        logger.info("_____________________________________________________________________");
        logger.info("NSP resultFetch =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        if (Array.isArray(resultFetch))
        {
            for (var index in resultFetch)
            {
                if(customerId != null && customerId !== "" ){
                    if (resultFetch[index]["customer-id"] == customerId)
                    {
                        ret.push(resultFetch[index][type]);
                        break;
                    }
                }
                else if (customerName != null && customerName != ""){
                    if (resultFetch[index]["customer-name"] == customerName)
                    {
                        ret.push(resultFetch[index][type]);
                        break;
                    }
                }
                else
                {
                    ret.push(resultFetch[index][type]);
                }
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info("ret = \n" + JSON.stringify(ret));
        return ret;
    }

    this.getSites = function () {
        return nspRestconfFwk.getSites();
    }
}