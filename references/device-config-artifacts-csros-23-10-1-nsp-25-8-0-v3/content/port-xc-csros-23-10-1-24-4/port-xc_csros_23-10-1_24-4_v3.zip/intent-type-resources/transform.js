function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
      if(payload["configInfo"]["pxc.PortCrossConnect"]["pxcPortId"]) {
          payload["configInfo"]["pxc.PortCrossConnect"]["pxcPortPointer"] = this.convertInterfaceToFDN(payload["configInfo"]["pxc.PortCrossConnect"]["pxcPortId"], neId);
      }
      return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        if(xpath == "pxcPortId"){
          targetValue = this.convertPXCPortToInterface(targetValue, neId);
        }
        return targetValue;
    }
    this.transformTargetValueBrownField = function (neId, xpath, targetValue, targetKey) {
        if(xpath == "pxcPortId") {
          targetValue = this.convertInterfaceToPXCPort(targetValue, neId);
        }
        return targetValue;
    }

    this.convertPXCPortToInterface = function (portId, neId) {
      if(portId == 0){
        return "503316480";
      }
      var interfaceId = "";
      var ret = nspRestconfFwk.getPorts(neId);
      var retData = JSON.parse(ret["data"]);
      if (!Array.isArray(retData)) {
          retData = [retData];
      }
      for(let i in retData) {
          if(retData[i]["port-id"] == portId) {
            interfaceId = retData[i]["port-index"];
            break;
          }
      }
      return JSON.stringify(interfaceId);
    }

    this.convertInterfaceToPXCPort = function (interfaceId, neId) {
      if(/.*\/.*/.test(interfaceId)) {
        return interfaceId;
      }
      var portId = "";
      var ret = nspRestconfFwk.getPorts(neId);
      var retData = JSON.parse(ret["data"]);
      if (!Array.isArray(retData)) {
          retData = [retData];
      }
      for(let i in retData) {
          if(retData[i]["port-index"] == interfaceId) {
            portId = retData[i]["port-id"];
            break;
          }
      }
      return portId;
    }

    this.convertInterfaceToFDN = function (interfaceId, neId) {
      if(/.*\/.*/.test(interfaceId)) {
        return interfaceId;
      }
      var portId = "";
      var ret = nspRestconfFwk.getPorts(neId);
      var retData = JSON.parse(ret["data"]);
      if (!Array.isArray(retData)) {
          retData = [retData];
      }
      for(let i in retData) {
          if(retData[i]["port-index"] == interfaceId) {
            portId = retData[i]["FDN"];
            break;
          }
      }
      return portId;
    }
}
