/*
 *
 * The intent of this framework is to provide a set of JS methods that DIRECTLY mimic
 * the behaviour of all published operations of the resource manager.  For helper
 * methods that intents can make use of (i.e. getServiceId()) please see the
 * resourceMgrHelper-fwk.js file.
 *
 */

function ResourceMgr() {
  var nspFwk = load({
    script: resourceProvider.getResource("nsp-fwk.js"),
    name: "nsp-fwk",
  });
  nspFwk = new nspFwk();

  var RESTCONF_GATEWAY = "restconf-gateway";

  // Base Resource managers pools
  var RES_MGR_BASE_POOLS_RESTCONF =
    "/restconf/data/nsp-resource-pool:resource-pools";

  // Pools Identities
  var RA_IP_POOLS_IDENTITY = "ip-resource-pools";
  var RA_RD_RT_POOLS_IDENTITY = "rd-rt-resource-pools";
  var RA_NUMERICAL_POOLS_IDENTITY = "numeric-resource-pools";
  var RA_STRING_POOLS_IDENTITY = "string-resource-pools";

  // Pool keys
  var RA_RD_RT = "rd_rt";
  var RA_STRING = "string";
  var RA_NUMERIC = "numeric";
  var RA_IP = "ip";

  // Pool Types
  var RA_IP_POOLS_TYPE = "ip-address-prefix";
  var RA_RD_RT_POOLS_TYPE = "rd_rt";
  var RA_NUMERICAL_POOLS_TYPE = "numerical";
  var RA_STRING_POOLS_TYPE = "literal";

  var RA_MGR_GET_ALL_IP_POOLS_RESTCONF =
    "/restconf/data/nsp-resource-pool:resource-pools/ip-resource-pools";
  var RA_MGR_GET_ALL_RD_RT_POOLS_RESTCONF =
    "/restconf/data/nsp-resource-pool:resource-pools/rd-rt-resource-pools";
  var RA_MGR_GET_ALL_NUM_POOLS_RESTCONF =
    "/restconf/data/nsp-resource-pool:resource-pools/numeric-resource-pools";
  var RA_MGR_GET_ALL_STRING_POOLS_RESTCONF =
    "/restconf/data/nsp-resource-pool:resource-pools/string-resource-pools";

  // IP POOL
  var RA_MGR_OBTAIN_VALUE_FROM_POOL_IP_RESTCONF =
    "/restconf/data/nsp-resource-pool:resource-pools/ip-resource-pools={poolName},{scope}/obtain-value-from-pool";
  var RA_MGR_OBTAIN_VALUE_NUM_POOL_RESTCONF =
    "/restconf/data/nsp-resource-pool:resource-pools/numeric-resource-pools={poolName},{scope}/obtain-value-from-pool";

  // utilities

  this.determinePoolType = function (type) {
    if (type === RA_IP) {
      return RA_IP_POOLS_IDENTITY;
    } else if (type === RA_RD_RT) {
      return RA_RD_RT_POOLS_IDENTITY;
    } else if (type === RA_NUMERIC) {
      return RA_NUMERICAL_POOLS_IDENTITY;
    } else if (type === RA_STRING) {
      return RA_STRING_POOLS_IDENTITY;
    } else {
      return RA_STRING_POOLS_IDENTITY;
    }
  };

  this.constructRestconfUrl = function (path) {
    var url = "https://" + RESTCONF_GATEWAY + path;
    return url;
  };

  /**
   *
   * @param poolName
   * @param scope
   * @param poolDescription
   * @param min
   * @param max
   * @returns {{"nsp-resource-pool:numeric-resource-pools": [{scope: string, name: string, "numeric-spec": {"min-value": string, "max-value": string}, description: string, type: string}]}}
   */
  this.createNumPoolBody = function (
    poolName,
    scope,
    poolDescription,
    min,
    max
  ) {
    var payload = {
      "nsp-resource-pool:numeric-resource-pools": [
        {
          name: poolName,
          scope: scope,
          type: "nsp-resource-pool-utils:numerical",
          description: poolDescription,
          "numeric-spec": {
            "min-value": min,
            "max-value": max,
          },
        },
      ],
    };
    return payload;
  };

  /**
   *
   * @param poolName
   * @param scope
   * @param poolDescription
   * @param networkIp
   * @param mask
   * @returns {{"nsp-resource-pool:ip-resource-pools": [{"ip-pool-spec": {"ip-mask": string}, scope: string, name: string, description: string, type: string}]}}
   */
  this.createIPHostPoolBody = function (
    poolName,
    scope,
    poolDescription,
    networkIp,
    mask
  ) {
    var payload = {
      "nsp-resource-pool:ip-resource-pools": [
        {
          name: poolName,
          scope: scope,
          type: "nsp-resource-pool-utils:ip-address-prefix",
          description: poolDescription,
          "ip-pool-spec": {
            "ip-masks": [{ "ip-mask": networkIp + "/" + mask, purposes: [""] }],
          },
        },
      ],
    };
    return payload;
  };

  /**
   *
   * @param poolName
   * @param scope
   * @param poolDescription
   * @param networkIp
   * @param mask
   * @param allocMask
   * @returns {{"nsp-resource-pool:ip-resource-pools": [{"ip-pool-spec": {"allocation-mask": string, "ip-mask": string}, scope: string, name: string, description: string, type: string}]}}
   */
  this.createIPSubnetPoolBody = function (
    poolName,
    scope,
    poolDescription,
    networkIp,
    mask,
    allocMask
  ) {
    var payload = {
      "nsp-resource-pool:ip-resource-pools": [
        {
          name: poolName,
          scope: scope,
          type: "nsp-resource-pool-utils:ip-address-prefix",
          description: poolDescription,
          "ip-pool-spec": {
            "ip-masks": [{ "ip-mask": networkIp + "/" + mask, purposes: [""] }],
            "allocation-mask": allocMask,
          },
        },
      ],
    };
    return payload;
  };

  /**
   *
   * @param poolName
   * @param scope
   * @param poolDescription
   * @param min
   * @param max
   * @returns {{"nsp-resource-pool:rd-rt-resource-pools": [{scope: string, name: string, "numeric-spec": {"min-value": string, "max-value": string}, description: string, type: string}]}}
   */
  this.createRdRtPoolBody = function (
    poolName,
    scope,
    poolDescription,
    min,
    max
  ) {
    var payload = {
      "nsp-resource-pool:rd-rt-resource-pools": [
        {
          name: poolName,
          scope: scope,
          type: "nsp-resource-pool-utils:rd_rt",
          description: poolDescription,
          "rd-rt-pool-spec": {
            "min-value": min,
            "max-value": max,
          },
        },
      ],
    };
    return payload;
  };

  /**
   *
   * @param poolName
   * @param scope
   * @param poolDescription
   * @param stringMaxLength
   * @param stringPatter {regex}
   * @param maxPoolCapacity
   * @returns {{"nsp-resource-pool:string-resource-pools": [{scope: string, name: string, "string-pool-spec": {"max-capacity": string, pattern: string, "string-length": string}, description: string, type: string}]}}
   */
  this.createStringPoolBody = function (
    poolName,
    scope,
    poolDescription,
    stringMaxLength,
    stringPattern,
    maxPoolCapacity
  ) {
    var payload = {
      "nsp-resource-pool:string-resource-pools": [
        {
          name: poolName,
          scope: scope,
          type: "nsp-resource-pool-utils:literal",
          description: poolDescription,
          "string-pool-spec": {
            "string-length": stringMaxLength,
            pattern: stringPattern,
            "max-capacity": maxPoolCapacity,
          },
        },
      ],
    };
    return payload;
  };

  /**
   *
   * @param totalResources
   * @param allOrNothing
   * @param owner
   * @param reference
   * @param confirmed {Boolean}
   * @returns {{"nsp-resource-pool:input": {owner: *, reference: *, "all-or-nothing": *, confirmed: *, "total-number-of-resources": *}}}
   */
  this.obtainResourcePayload = function (
    type,
    description,
    totalResources,
    allOrNothing,
    owner,
    reference,
    confirmed,
    baseString
  ) {
    var payload = {
      "nsp-resource-pool:input": {
        "total-number-of-resources": totalResources,
        "all-or-nothing": allOrNothing,
        owner: owner,
        description: description,
        reference: reference,
        confirmed: confirmed,
      },
    };
    if (type === RA_RD_RT) {
      payload["nsp-resource-pool:input"]["base-string"] = baseString;
    }
    return payload;
  };

  /**
   *
   * @param valuesToReserve {Array}
   * @param allOrNothing {Boolean}
   * @param owner
   * @param reference
   * @param confirmed
   * @returns {{"nsp-resource-pool:input": {owner: *, reference: *, "reserve-values": *, "all-or-nothing": *, confirmed: *}}}
   */
  this.reserveResourcePayload = function (
    type,
    description,
    valuesToReserve,
    allOrNothing,
    owner,
    reference,
    confirmed,
    baseString
  ) {
    var payload = {
      "nsp-resource-pool:input": {
        owner: owner,
        "reserve-values": valuesToReserve,
        "all-or-nothing": allOrNothing,
        description: description,
        reference: reference,
        confirmed: confirmed,
      },
    };
    if (type === RA_RD_RT) {
      payload["nsp-resource-pool:input"]["base-string"] = baseString;
    }
    return payload;
  };
  // Common

  /**
   * In order to use this function, use the methods defined in this class to build a body
   * @param requestBody
   * @returns {*}
   */
  this.createPool = function (requestBody) {
    var url = this.constructRestconfUrl(RES_MGR_BASE_POOLS_RESTCONF);

    logger.info(" Create Pool: requestBody = {}", JSON.stringify(requestBody));
    var result = nspFwk.send(
      url,
      "POST",
      requestBody,
      "application/yang-data+json",
      "application/yang-data+json"
    );
    return result;
  };

  /**
   *
   * @param requestBody
   * @returns {*}
   */
  this.deletePool = function (poolType, poolName, scope) {
    var poolKey = this.determinePoolType(poolType);

    var url = this.constructRestconfUrl(
      RES_MGR_BASE_POOLS_RESTCONF + "/" + poolKey + "=" + poolName + "," + scope
    );

    logger.info(
      " Deleting Pool: Id = {}, name={}, scope={} ",
      poolKey,
      poolName,
      scope
    );
    var result = nspFwk.send(
      url,
      "DELETE",
      "application/yang-data+json",
      "application/yang-data+json"
    );
    return result;
  };

  /**
   *  In order to use this function, use the methods defined in this class to build a body
   * @param poolType constant id defined above and is required
   * @param poolName
   * @param scope
   * @param requestBody
   * @returns {{}}
   */
  this.obtainValueFromPool = function (poolType, poolName, scope, requestBody) {
    var poolKey = this.determinePoolType(poolType);

    var requestUrl =
      "/restconf/data/nsp-resource-pool:resource-pools/{poolType}={poolName},{scope}/obtain-value-from-pool"
        .replace("{poolType}", poolKey)
        .replace("{poolName}", poolName)
        .replace("{scope}", scope);
    var url = this.constructRestconfUrl(requestUrl);

    logger.info(
      "Obtain Resources from {} name={}, scope={}: requestBody = {}",
      poolType,
      poolName,
      scope,
      JSON.stringify(requestBody)
    );
    var result = nspFwk.send(
      url,
      "POST",
      requestBody,
      "application/yang-data+json",
      "application/yang-data+json"
    );

    return result;
  };

  /**
   *  In order to use this function, use the methods defined in this class to build a body
   * @param poolType constant id defined above and is required
   * @param poolName
   * @param scope
   * @param requestBody
   * @returns {{}}
   */
  this.reserveResources = function (poolType, poolName, scope, requestBody) {
    var poolKey = this.determinePoolType(poolType);

    var requestUrl =
      "/restconf/data/nsp-resource-pool:resource-pools/{poolType}={poolName},{scope}/reserve"
        .replace("{poolType}", poolKey)
        .replace("{poolName}", poolName)
        .replace("{scope}", scope);
    var url = this.constructRestconfUrl(requestUrl);

    logger.info(
      "Book Resources from {} name={}, scope={}: requestBody = {}",
      poolType,
      poolName,
      scope,
      JSON.stringify(requestBody)
    );
    var result = nspFwk.send(
      url,
      "POST",
      requestBody,
      "application/yang-data+json",
      "application/yang-data+json"
    );

    return result;
  };

  /**
   *
   * @param poolType constant id defined above and is required
   * @param poolName
   * @param scope
   * @param valueToDelete
   * @returns {{}}
   */
  this.deleteResourceFromPool = function (
    poolType,
    poolName,
    scope,
    valueToDelete
  ) {
    var poolKey = this.determinePoolType(poolType);

    var consumed = "consumed-resources";
    if (poolType == "numeric-resource-pools") {
      consumed = "num-consumed-resources";
    }
    var requestUrl =
      "/restconf/data/nsp-resource-pool:resource-pools/{poolType}={poolName},{scope}/{consumed}={valueToDelete}"
        .replace("{poolType}", poolKey)
        .replace("{poolName}", poolName)
        .replace("{scope}", scope)
        .replace("{consumed}", consumed)
        .replace("{valueToDelete}", valueToDelete);
    var url = this.constructRestconfUrl(requestUrl);

    logger.info(
      "Delete Resources from {} name={}, scope={}, value={}",
      poolType,
      poolName,
      scope,
      valueToDelete
    );
    var result = nspFwk.send(
      url,
      "DELETE",
      "application/yang-data+json",
      "application/yang-data+json"
    );

    return result;
  };

  /**
   *
   * @param poolType
   * @param poolName
   * @param scope
   * @param owner
   * @returns {*}
   */
  this.deleteResourceByOwnerFromPool = function (
    poolType,
    poolName,
    scope,
    owner
  ) {
    var poolKey = this.determinePoolType(poolType);
    var requestUrl =
      "/restconf/data/nsp-resource-pool:resource-pools/{poolType}={poolName},{scope}/release-by-owner"
        .replace("{poolType}", poolKey)
        .replace("{poolName}", poolName)
        .replace("{scope}", scope);
    var url = this.constructRestconfUrl(requestUrl);

    var requestBody = {
      "nsp-resource-pool:input": {
        owner: owner,
      },
    };
    logger.info(
      " del all resources from {} name={}, scope={} by owner = {}",
      poolType,
      poolName,
      scope,
      owner
    );
    var result = nspFwk.send(
      url,
      "POST",
      requestBody,
      "application/yang-data+json",
      "application/yang-data+json"
    );

    return result;
  };

  /**
   *
   * @param poolType
   * @param poolName
   * @param scope
   * @param reference
   * @returns {*}
   */
  this.deleteResourceByReferenceFromPool = function (
    poolType,
    poolName,
    scope,
    reference
  ) {
    var poolKey = this.determinePoolType(poolType);
    var requestUrl =
      "/restconf/data/nsp-resource-pool:resource-pools/{poolType}={poolName},{scope}/release-by-ref"
        .replace("{poolType}", poolKey)
        .replace("{poolName}", poolName)
        .replace("{scope}", scope);
    var url = this.constructRestconfUrl(requestUrl);

    var requestBody = {
      "nsp-resource-pool:input": {
        reference: reference,
      },
    };
    logger.info(
      " del all resources from {} name={}, scope={} by reference = {}",
      poolType,
      poolName,
      scope,
      reference
    );
    var result = nspFwk.send(
      url,
      "POST",
      requestBody,
      "application/yang-data+json",
      "application/yang-data+json"
    );

    return result;
  };

  /**
   *
   * @param poolType
   * @param poolName
   * @param scopes {Array}
   * @param reference
   * @returns {*}
   */
  this.deleteResourceByOwnerFromPoolAllScopes = function (
    poolType,
    poolName,
    scopes,
    owner
  ) {
    var poolKey = this.determinePoolType(poolType);

    var requestUrl =
      "/restconf/operations/nsp-resource-pool-operations:execution-delete-resources-by-owner-scopes";
    var url = this.constructRestconfUrl(requestUrl);

    var requestBody = {
      "nsp-resource-pool-operations:input": {
        name: poolName,
        type: poolKey,
        owner: owner,
        scopes: scopes,
      },
    };
    logger.info(
      " del all resources from {} name={}, scopes={} by reference = {}",
      poolType,
      poolName,
      scopes,
      owner
    );
    var result = nspFwk.send(
      url,
      "POST",
      requestBody,
      "application/yang-data+json",
      "application/yang-data+json"
    );

    return result;
  };

  /**
   *
   * @param poolType
   * @param poolName
   * @param scope
   * @returns {*}
   */
  this.getPool = function (poolType, poolName, scope) {
    var poolKey = this.determinePoolType(poolType);
    var requestUrl =
      "/restconf/data/nsp-resource-pool:resource-pools/{poolType}={poolName},{scope}"
        .replace("{poolType}", poolKey)
        .replace("{poolName}", poolName)
        .replace("{scope}", scope);
    var url = this.constructRestconfUrl(requestUrl);

    var result = nspFwk.send(
      url,
      "GET",
      "application/yang-data+json",
      "application/yang-data+json"
    );

    return result;
  };

  /**
   *
   * @returns {*}
   */
  this.getAllPools = function () {
    var requestUrl = "/restconf/data/nsp-resource-pool:resource-pools";
    var url = this.constructRestconfUrl(requestUrl);

    var result = nspFwk.send(
      url,
      "GET",
      "application/yang-data+json",
      "application/yang-data+json"
    );

    return result;
  };
}
