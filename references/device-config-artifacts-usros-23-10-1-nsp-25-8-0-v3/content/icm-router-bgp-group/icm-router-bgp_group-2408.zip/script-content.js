var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
  "ibn": "http://www.nokia.com/management-solutions/ibn",
  "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
  "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
  "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};


load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
var mdtFwk = new MdtFwk();

load({script: resourceProvider.getResource('mdSuggest.js'), name: 'MdSuggest'})

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})

var LOG_PREFIX = "[BGP Group]: "

var intentTypeName = 'icm-router-bgp_group';

// example port, sap-ingress etc..
var initialPropertyName = 'group';

var deviceYangModuleName = 'nokia-conf';

// unique identifier
var uniqueIdentifier = 'group-name';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/router=Base/bgp';

var topologyInfo = {};

function synchronize(input) {
  logger.info('Intent Synchronisation started')

  return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, topologyInfo);
}

function onAudit(target, config, svcTopo, adminState) {
  logger.info('Intent Audit started')

  return NspIntentHelper.audit(target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, topologyInfo);
}

function suggestGroupName(context) {
  logger.info(LOG_PREFIX + "suggestGroupName context = \n" + context);
  var neId = getNeId(context);
  return navigateInstance(neId).getGroupName(neId);
}

function suggestPolicyStatement(context) {
  logger.info("suggest Policy Statement Context = \n" + context);
  var neId = this.getNeId(context);
  return navigateInstance(neId).getPolicyStatement(neId);
}

function navigateInstance(neId) {
  var managerName = mdtFwk.getManagerName(neId);
  logger.info(LOG_PREFIX + 'Device: ' + neId + ' is managed by: ' + managerName);
  switch (managerName) {
    case "NFM-P":
      logger.info(LOG_PREFIX + 'Device is managed by NFMP');
      return new NfmpSuggest();
      break;
    case "MDC":
      logger.info(LOG_PREFIX + 'Device is managed by MDC');
      return new MdSuggest();
      break;
    default:
      logger.info(LOG_PREFIX + 'Device is not managed')
      throw new RuntimeException(LOG_PREFIX + 'Device is not Managed')
  }
  return '';
}

function getTargetData(input) {
  logger.info("getTargetData input for brownfield = \n" + input);
  var target = input.target;
  var config = null;
  logger.info("target=" + target);
  var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
  logger.info(JSON.stringify(deviceConfig));
  var data = gtdFwk.gtdSend(deviceConfig);
  return data.msg.result;
}

function getNeId(context) {
  var neId;
  var target = context.getInputValues()["target"]["objectidentifier"];
  logger.info(LOG_PREFIX + "target : {}", target)
  if (!target)
  {
    target = context.getInputValues()["arguments"]["__root"]["target_objectidentifier"];
  }
  if(target)
  {
    if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
      neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
    }
    else {
      neId = target;
    }
  }
  logger.info(LOG_PREFIX + "NeId identified " + " : {}", neId);
  return neId;
}


