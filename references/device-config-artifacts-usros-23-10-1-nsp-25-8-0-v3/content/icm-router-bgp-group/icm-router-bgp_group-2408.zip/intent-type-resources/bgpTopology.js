function BgpTopology() {

    var savedTopologyBGPGroup = {};
    var savedTopologyBGPNeighbour = {};

    this.setSavedTopologyBGPGroup = function (bgpGroup) {
        this.savedTopologyBGPGroup = bgpGroup;
    }

    this.getSavedTopologyBGPGroup = function () {

        if(this.savedTopologyBGPGroup == undefined){
            this.savedTopologyBGPGroup = topologyFactory.createServiceTopology();
        }

        return this.savedTopologyBGPGroup;
    }

    this.setSavedTopologyBGPNeighbour = function (bgpNeighbour) {
        this.savedTopologyBGPNeighbour = bgpNeighbour;
    }

    this.getSavedTopologyBGPNeighbour = function () {

        if(this.savedTopologyBGPNeighbour == undefined){
            this.savedTopologyBGPNeighbour = topologyFactory.createServiceTopology();
        }

        return this.savedTopologyBGPNeighbour;
    }
}