load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {

    this.getDomain = function (neId) {
         let className = "netw.MultiChassisIPSecDomain";
         let searchObject = {
               "fullClassName": className,
               "filter": {
                   "and": {
                       "equal": [
                            {
                               "name": "siteId",
                               "value": neId
                           }
                       ]
                   }
               },
               "resultFilter": {
                   "children": "",
                   "attribute": [
                "domainId"
                   ]
               }
         };
         return this.getData(searchObject, className, "domainId");
    }

    this.getInterface = function (neId) {
         let className = "ies.L3AccessInterface";
         let searchObject = {
               "fullClassName": className,
               "filter": {
                   "and": {
                       "equal": [
                            {
                               "name": "nodeId",
                               "value": neId
                           }
                       ]
                   }
               },
               "resultFilter": {
                   "children": "",
                   "attribute": [
                       "displayedName"
                   ]
               }
         };
         return this.getData(searchObject, className, "displayedName");
    }

    this.getMcKeyChainName = function () {
         let className = "security.KeyChain";
         let searchObject = {
               "fullClassName": className,
               "filter": {
                   "and": {
                       "equal": [
                            {
                                "name": "isLocal",
                                "value": "false"
                            },
                            {
                                "name": "isBackup",
                                "value": "false"
                            }
                       ]
                   }
               },
               "resultFilter": {
                   "children": "",
                   "attribute": [
                       "displayedName"
                   ]
               }
         };
         return this.getData(searchObject, className, "displayedName");
    }

    this.getRncvServiceId = function (neId) {
         let className = "ies.L3AccessInterface";
         let searchObject = {
               "fullClassName": className,
               "filter": {
                   "and": {
                       "equal": [
                            {
                               "name": "nodeId",
                               "value": neId
                           }
                       ]
                   }
               },
               "resultFilter": {
                   "children": "",
                   "attribute": [
                       "serviceId"
                   ]
               }
         };
         return this.getData(searchObject, className, "serviceId");
    }

    this.getTunnelGrp = function (neId) {
        let className = "isa.IPSecIsaGroup";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        { "name": "siteId", "value": neId },
                        { "name": "multiActive", "value": "true" }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": ["groupNumber", "mcIPSecTnlGrpPointer"]
            }
        };

        let result = [];
        let nfmpFwk = new NfmpFwk();
        let response = nfmpFwk.post("/v3/search", searchObject);
        let data = JSON.parse(response.response)[className];

        if (data) {
            if (!Array.isArray(data)) data = [data];
            for (let i = 0; i < data.length; i++) {
                if (!data[i]["mcIPSecTnlGrpPointer"]) {
                    result.push(data[i]["groupNumber"]);
                }
            }
        }

        return result;
    };

    this.getSdpData = function (neId) {
        let searchObjectJson = {
            "fullClassName": "svt.Tunnel",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "sourceNodeId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "pathId","displayedName","underlyingTransport"
                ]
            }
        };
        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var response = JSON.parse(resultFetch.response)["svt.Tunnel"];
        if (response && !Array.isArray(response)) {
            response = [response];
        }
        let result = {};
        let data= [];
        if (response) {
            data = response.map(function (sdpDetails) {
                let obj = {};
                if (sdpDetails["pathId"] && sdpDetails["displayedName"] && sdpDetails["underlyingTransport"]) {
                    obj["id"]= sdpDetails["pathId"];
                    obj["ethSegSdpIdPointer"] = sdpDetails["displayedName"];
                    obj["underlyingTransport"] = sdpDetails["underlyingTransport"];
                    return obj
                }
                return null;
            }).filter(obj => obj !== null);

            result["data"] = JSON.stringify(data);
        }
        return result;
    }

    this.getPorts = function(neId) {
        var searchObjectJson1 = {
            "fullClassName": "equipment.PhysicalPort",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "isPrimaryLagMember",
                            "value": false
                        }
                    ],
                    "or": {
                        "equal": [
                            {
                                "name": "mode",
                                "value": "access"
                            },
                            {
                                "name": "mode",
                                "value": "hybrid"
                            }
                       ]
                   }
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "portName",
                    "objectFullName",
                    "description",
                    "encapType",
                    "mode",
                    "portCategory"
                ]
            }
        };
        var searchObjectJson2 = {
            "fullClassName": "lag.Interface",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ],
                    "notEqual": [
                        {
                            "name": "mode",
                            "value": "network"
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "lagNameId",
                    "objectFullName",
                    "description",
                    "encapType",
                    "mode"]
            }
        };
        let nfmpFwk = new NfmpFwk();
        var data;
        let resultFetch1 = nfmpFwk.post("/v3/search", searchObjectJson1);
        var finalResponse1 = JSON.parse(resultFetch1.response)["equipment.PhysicalPort"];
        logger.info("Final Response1: " +JSON.stringify(finalResponse1));
        let resultFetch2 = nfmpFwk.post("/v3/search", searchObjectJson2);
        var finalResponse2 = JSON.parse(resultFetch2.response)["lag.Interface"];
        logger.info("Final Response2: " +JSON.stringify(finalResponse2));
        if(finalResponse1 && finalResponse2) {
          var finalResponse= finalResponse1.concat(finalResponse2);
            data = processResponse(finalResponse);
           return data;
        }else
        if(finalResponse1){
           data = processResponse(finalResponse1);
           return data
        }
        else if(finalResponse2) {
          data = processResponse(finalResponse2);
          return data;
        }
    }

     function processResponse(response) {
         var result={};
         var data=[];
         logger.info("Input Response: " +JSON.stringify(response));
         if (response) {
             data = response.map(function(portDetails) {
                 var obj = {};
                     obj["portName"] = portDetails["portName"] || portDetails["lagNameId"];
                     obj["description"] = portDetails["description"];
                     obj["encapType"] = portDetails["encapType"];
                     obj["mode"] = portDetails["mode"];
                     return obj;
             }).filter(obj => obj !== null);
             result["data"] = JSON.stringify(data);
         }
         logger.info("Processed data: " +JSON.stringify(result));
         return result;
     }

    this.getData = function (searchObjectJson, className, type) {
        let nfmpFwk = new NfmpFwk();
        let ret = [];
        let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        let finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    ret.push(value[type]);
                })
            }
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }
}
