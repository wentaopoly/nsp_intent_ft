var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk'});
load({script: resourceProvider.getResource('traverse-fwk.js'), name: 'TraverseFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
load({script: resourceProvider.getResource('intentConfigValueReplacer.js'), name: 'IntentConfigValueReplacer'});
function MdcIntentFwk() {

    var intentDeviationObj = new IntentDeviceDeviation();
    var intentConfigValueReplacerObj = new IntentConfigValueReplacer();
    var util = new utilities();
    var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,5}(:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){6}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(\/(0|[1-9][0-9]?|1[0-1][0-9]?|12[0-8]))?$/;
    this.restResponseHandler = function(exception, httpStatus, response) {
        logger.info("[IntentMgr] REST response : " + response);
        logger.info("[IntentMgr] REST httpStatus : " + httpStatus);
        if (exception) {
            throw new RuntimeException("Couldn't connect to device proxy for ; Response: "+response);
        }
        if (httpStatus !== 200 && httpStatus !== 201) {
            throw new RuntimeException("Failed to access device  using MDC; Response: "+response);
        }
        restResponse = JSON.parse(response);
    };

    this.synchronize = function(input, result,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {
      var traverseFwk = new TraverseFwk();
      var parseTarget = new ParseTarget();
      var target = parseTarget.getNeIdFromTarget(input.getTarget());

      // saved topology
      var savedTopology = input.getCurrentTopology();

      if(savedTopology == null) {
          savedTopology = topologyFactory.createServiceTopology();
      }
      
      if (input.getNetworkState().name() == "delete") {
          logger.info(JSON.stringify(savedTopology));
          traverseFwk.resetTheVariables();
          result = traverseFwk.deleteAllFromTopology(savedTopology,target,result);
          return result;
      }
  
      var intentConfig;

      if(target !== "0.0.0.0") {
            var intentConfig;
            intentConfig  = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
            var policyName = input.getTarget().split("#")[2];
            var policyId = input.getTarget().split("#")[3];
            intentConfig['network-policy-name'] = policyName;
            intentConfig['policy-id'] = parseInt(policyId);
            //Removing deviations info
            intentConfig = intentDeviationObj.removeIntentConfig(intentConfig, target);
            //Replace Values
            // intentConfig = intentConfigValueReplacerObj.replaceConfigValue(intentConfig);
            if (intentConfig) {
                savedTopology = traverseFwk.traverse(target,intentConfig,savedTopology,null,parentXpath,initialPropertyName);

              //sorting delete array
                var deleteRequests = traverseFwk.getDeleteRequests();
                deleteRequests.sort(function(a, b){
                                return b["target"].length - a["target"].length;
                });

              //concating createrequests and deleterequests
                var createRequests = traverseFwk.getCreateRequests();
                var requests;
                if(deleteRequests && createRequests){
                    requests = deleteRequests.concat(createRequests);
                }
                if ( requests ){
                    result = traverseFwk.syncRequest(target,requests,result,savedTopology);
                }

            }else{

                    result = traverseFwk.deleteAllFromTopology(savedTopology,target,result);
            }

       }
      traverseFwk.resetTheVariables();
      return result;
    }

    this.audit = function(target, config, svcTopo, adminState, report, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        var currentConfig;
        var traverseFwk = new TraverseFwk();
        var parseTarget = new ParseTarget();
        var targetNeId = parseTarget.getNeIdFromTarget(target);

        if(target !== "0.0.0.0") {
            currentConfig  = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
            currentConfig = this.expandIPv6(currentConfig);
            var policyName = target.split("#")[2];
            var policyId = target.split("#")[3];
            currentConfig['network-policy-name'] = policyName;
            currentConfig['policy-id'] = parseInt(policyId);
            //Ignoring deviations compare
            currentConfig = intentDeviationObj.removeIntentConfig(currentConfig, targetNeId);
            //Replace Values
            currentConfig = intentConfigValueReplacerObj.replaceConfigValue(currentConfig);
            svcTopo = traverseFwk.traverse(targetNeId,currentConfig,svcTopo,report,parentXpath,initialPropertyName);
            // reseting the variables
            traverseFwk.resetTheVariables();
        }
        return report;
    }

    this.getNodes = function(context){
        var returnVal = []
        var url = "/restconf/meta/api/v1/nes"
        try {
        var managerList = []
        var managers = mds.getAllManagersOfType("REST");
        managers.forEach(function (manager) {
          if (mds.getManagerByName(manager).getConnectivityState().toString() === 'CONNECTED') {
            managerList.push(manager)
          }
        })

        var devices = mds.getAllManagedDevicesFrom(managerList);

        devices.forEach(function (device) {
            returnVal.push(device.getName());
        });
        return returnVal;
        } catch (e) {
            logger.info("Exception *******************  : " + e);
        return {
          "Device Not Found": "Device Not Found"
        }
        }
    }

    this.xml2object = function(xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info(LOG_PREFIX + 'inp json: '+ json)
        return JSON.parse(json);
    }

    this.expandIPv6 = function (obj) {
        for (var key in obj) {
            if (typeof obj[key] === 'object' && obj[key] !== null) {
                this.expandIPv6(obj[key]);
            } else if (typeof obj[key] === 'string' && this.matchExact(ipv6Regex, obj[key])) {
                obj[key] = this.expandIPv6AddressForMd(obj[key]);
            }
        }
      return obj
    }

    this.matchExact = function(r, str) {
        var match = str.match(r);
        return match && str === match[0];
    }

    this.expandIPv6AddressForMd = function (input) {
        var expanded = util.expandIPv6ForMd(input);
        expanded = util.MdIpv6ValidAddresssMaskSupport(expanded);
        return expanded;
    };
}
