var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});


function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let cardSlotId = parseTarget.getUniqueIdentifier(target);

        let deviceConfig = this.getCardAndChildConfiguration(neId, cardSlotId);

        logger.info("*********************************deviceConfigSTART*************************************");
        logger.info(JSON.stringify(deviceConfig));
        logger.info("*********************************deviceConfigEND*************************************");
        return deviceConfig;
    }

    this.getCardAndChildConfiguration = function (neId, cardSlotId) {
        let fullName = "fullName = 'network:" + neId + ":shelf-1:cardSlot-" + cardSlotId + ":card'"
        if (neId && String(neId).indexOf(':') !== -1) {
                    fullName = util.modifyNeIdForIpV6(fullName, neId);
        }
        let cardConfig;
        let xiomConfig = [];
        let mdaConfig = [];
        let jsonPayLoad = {
            "filter": {
                "filterExpression": fullName
            },
            "fullClassName": "equipment.BaseCard"
        };
        let searchResponse = nfmpFwk.post("search", jsonPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find Card : ");
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        cardConfig = searchResponse[0]["properties"];
        let cardChildren = searchResponse[0]["children"];
        for (let index in cardChildren)
        {
            let child = cardChildren[index];
            switch (child["fullClassName"])
            {
                case  "equipment.XiomCardSlot" :
                    {
                        logger.info("CHILD = equipment.XiomCardSlot");
                        let xiomCardIter = child["children"]
                        if (xiomCardIter)
                        {
                            for (let xiomIndex in xiomCardIter)
                            {
                                let xiomCard = xiomCardIter[xiomIndex];
                                if (xiomCard["fullClassName"] === "equipment.XiomCard")
                                {
                                    logger.info("CHILD = equipment.XiomCard");
                                    xiomConfig.push(xiomCard["properties"]);
                                    let xiomMdaChildren = xiomCard["children"];
                                    for (let xiomMdaIndex in xiomMdaChildren)
                                    {
                                        let xiomMdaSlot = xiomMdaChildren[xiomMdaIndex];
                                        if (xiomMdaSlot["fullClassName"] === "equipment.DaughterCardSlot")
                                        {
                                            logger.info("CHILD = XIOM-equipment.DaughterCardSlot");
                                            let xiomMdaIter = xiomMdaSlot["children"];
                                            if (xiomMdaIter)
                                            {
                                                for (let mdaSlotIndex in xiomMdaIter)
                                                {
                                                    let xiomMda = xiomMdaIter[mdaSlotIndex];
                                                    if (xiomMda["fullClassName"] === "equipment.DaughterCard")
                                                    {
                                                        logger.info("CHILD = XIOM-equipment.DaughterCard");
                                                        mdaConfig.push(xiomMda["properties"]);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                case "equipment.DaughterCardSlot":
                    {
                        logger.info("CHILD = equipment.DaughterCardSlot");
                        let mdaSlotChildren = child["children"];
                        if (mdaSlotChildren)
                        {
                            for (let mdaSlotIndex in mdaSlotChildren)
                            {
                                let mda = mdaSlotChildren[mdaSlotIndex];
                                if (mda["fullClassName"] === "equipment.DaughterCard")
                                {
                                    mdaConfig.push(mda["properties"]);
                                }
                            }
                        }
                    }
            }
        }
        let deviceConfig = {
            "cardConfig": cardConfig,
            "xiomConfig": xiomConfig,
            "mdaConfig": mdaConfig
        };
        return deviceConfig;
    }
    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        logger.info("Intent data before updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData))
        if (null !== deviceConfig)
        {
            this.extractCardProperties(parsedDefaultTargetData, deviceConfig);
            logger.info("Intent data after updating Card from NFMP :\n" + JSON.stringify(parsedDefaultTargetData))
            let mdaArray = this.extractMdaProperties(parsedDefaultTargetData['card']['mda'], deviceConfig['mdaConfig'], "card.mda");
            parsedDefaultTargetData['card']['mda'] = mdaArray;
            logger.info("Intent data after updating MDA from NFMP :\n" + JSON.stringify(parsedDefaultTargetData))
            let xiomArray = this.extractXiomProperties(parsedDefaultTargetData['card']['xiom'], deviceConfig);
            parsedDefaultTargetData['card']['xiom'] = xiomArray;
        }
        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData))
        return parsedDefaultTargetData;
    }
    this.extractCardProperties = function (defaultTargetData, deviceConfig) {
        logger.info("Extracting Card Properties");
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object' && !Array.isArray(targetObj))
            {
                this.traverseAndUpdateConfig(targetKey, targetObj, deviceConfig["cardConfig"]);
            }
        }
        return defaultTargetData;
    }
    this.extractMdaProperties = function (defaultTargetData, deviceConfig, objKey) {
        logger.info("Extracting MDA Properties")
        logger.info("defaultTargetData \n" + JSON.stringify(defaultTargetData));
        logger.info("deviceConfig \n" + JSON.stringify(deviceConfig));
        let mdaArray = [];
        let mdaData = defaultTargetData[0];
        let mappings = modelDeviceMapping.getMdaMapping();
        for (let i = 0; i < deviceConfig.length; i++)
        {
            let deviceMdaConfig = deviceConfig[i];
            if ((objKey === "card.xiom.mda" && deviceMdaConfig["xiomCardSlotId"] !== "0") ||
                (objKey === "card.mda" && deviceMdaConfig["xiomCardSlotId"] === "0"))
            {
                let keys = Object.keys(mdaData);
                logger.info("keys = " + keys);
                for (let j = 0; j < keys.length; j++)
                {
                    let targetKey = keys[j];
                    let targetObj = mdaData[targetKey];
                    let mappedKey = objKey + "." + targetKey;
                    //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj) + "\nmappedKey = " + mappedKey);
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, mdaData, deviceMdaConfig);
                }
                mdaArray.push(JSON.parse(JSON.stringify(mdaData)));
            }
        }
        return mdaArray;
    }
    this.extractXiomProperties = function (defaultTargetData, deviceConfig) {
        logger.info("Extracting Xiom Properties")
        logger.info("defaultTargetData \n" + JSON.stringify(defaultTargetData));
        let xiomConfig = deviceConfig["xiomConfig"];
        let mdaConfig = deviceConfig["mdaConfig"];
        logger.info("xiomdeviceConfig \n" + JSON.stringify(xiomConfig));
        logger.info("----------------------------------------------------------------");
        logger.info("MdadeviceConfig \n" + JSON.stringify(mdaConfig));
        let xiomArray = [];
        let xiomData = defaultTargetData[0];
        let mappings = modelDeviceMapping.getXiomMapping();
        for (let i = 0; i < xiomConfig.length; i++)
        {
            let deviceXiomConfig = xiomConfig[i];
            let keys = Object.keys(xiomData);
            logger.info("keys = " + keys);
            for (let j = 0; j < keys.length; j++)
            {
                let targetKey = keys[j];
                let targetObj = xiomData[targetKey];
                let mappedKey = "card.xiom." + targetKey;
                //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj) + "\nmappedKey = " + mappedKey);
                if (mappedKey === "card.xiom.mda")
                {
                    logger.info("XIOM DATA = \n" + JSON.stringify(xiomData));
                    let xiomMdaArray = this.extractMdaProperties(xiomData['mda'], mdaConfig, "card.xiom.mda");
                    xiomData['mda'] = xiomMdaArray;
                    logger.info("Intent data after updating XIOM MDA from NFMP :\n" + JSON.stringify(xiomData))

                }
                else
                {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, xiomData, deviceXiomConfig);
                }
            }
            xiomArray.push(JSON.parse(JSON.stringify(xiomData)));
        }
        return xiomArray;
    }
    this.traverseAndUpdateConfig = function (objKey, obj, deviceConfig) {
        logger.info("objKey-targetKey = " + objKey + "\ntargetObj ===== " + JSON.stringify(obj));
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            let deviceConfigData = deviceConfig;
            let mappings = modelDeviceMapping.getCardMapping();
            logger.info("key = " + key + ", value = " + value + ", mappedKey = " + mappedKey);
            if (mappings && deviceConfigData && !mappedKey.startsWith("card.mda") && !mappedKey.startsWith("card.xiom"))
            {
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, deviceConfigData);
            }
        }
        return obj;
    }
    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, deviceConfig) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = deviceConfig[nfmpKey];
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);
    }
    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue !== null)
        {
            switch (mappedKey)
            {
                case "card.admin-state":
                case "card.xiom.admin-state":
                case "card.xiom.mda.admin-state":
                case "card.mda.admin-state":
                    deviceValue = util.convertAdminStateBrownField(deviceValue);
                    break;
                case "card.xiom.xiom-type":
                    if (deviceValue === "card_iom_s_3t")
                    {
                        deviceValue = "iom-s-3.0t";
                    }
                    else
                    {
                        deviceValue = "iom-s-1.5t";
                    }
                case "card.card-type":
                case "card.mda.mda-type":
                case "card.xiom.mda.mda-type":
                    deviceValue = this.getType(deviceValue);

            }
            return deviceValue;
        }
    }
    this.getType = function (deviceValue) {
        return deviceValue.toString();
    }
}
