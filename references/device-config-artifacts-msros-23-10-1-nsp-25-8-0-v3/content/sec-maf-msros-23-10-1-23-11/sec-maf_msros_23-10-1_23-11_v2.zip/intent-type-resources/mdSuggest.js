function MdSuggest() {
        this.getRouterInstance = function (neId) {
                   const requests = [
                    {
                      url:`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/service/vprn?fields=service-name`,
                      responseKey: "nokia-conf:vprn",
                      property: "service-name"
                    },
                    {
                      url:`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router?fields=router-name`,
                      responseKey: "nokia-conf:router",
                      property: "router-name"
                    }
                  ];
                  return this.getMergedData(neId, requests);
        }
    this.getMergedData = function (neId,requests) {
        const mdcFwk = new MdcFwk();
        let result = [];
        requests.forEach(function (request) {
          const url = request.url;
          const responseKey = request.responseKey;
          const property = request.property;
          const resultFetch = mdcFwk.fetch(neId, url);
          const finalResponse = resultFetch.msg[responseKey];
          if (Array.isArray(finalResponse) && finalResponse.length > 0) {
             const names = finalResponse.map(function (Data) {
               return Data[property];
             }).filter(function (value) {
               return value != null;
             });
           result = result.concat(names);
          }
        });
        var flag = 0;
        for (let i=0; i<result.length;i++) {
            if(result[i] == "Base") {
                flag = 1;
            }
        }
        if (flag == 0) {
           result.push("Base");
        }
    return result.length > 0 ? result : [];
   };

this.getSuggestData = function(neId, url, initialProperty, propertyName) {
  const mdcFwk = new MdcFwk();   const resultFetch = mdcFwk.fetch(neId, url);
  const finalResponse = resultFetch.msg[initialProperty];
  const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data[propertyName]).filter(value => value != null):[];
  logger.info("ret =", JSON.stringify(ret));
  return ret;
  }
}
