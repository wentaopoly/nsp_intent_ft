load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {
    this.getPolicyName = function (neId, policyId) {
        var className =  "aingr.Policy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "policyName",
                    "id"
                ]
            }
        };
        if (policyId) {
            var QoS_Policy = {};
            QoS_Policy["name"] = "id";
            QoS_Policy["value"] = policyId;
            searchObject["filter"]["and"]["equal"].push(QoS_Policy);
        }
        return this.getData(neId, searchObject, "policyName", policyId);
    }

    this.getPolicyId= function (neId, policyName) {
        var className = "aingr.Policy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "policyName",
                    "id"
                ]
            }
        };
        if (policyName) {
            var QoS_Policy = {};
            QoS_Policy["name"] = "policyName";
            QoS_Policy["value"] = policyName;
            searchObject["filter"]["and"]["equal"].push(QoS_Policy);
        }
        return this.getData(neId, searchObject, "id", policyName);
    }

    this.getIngressClassificationPolicy = function (neId) {
        var searchObjectJson = {
            "fullClassName": "ixrqos.IngressClassification",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        finalResponse = finalResponse["ixrqos.IngressClassification"];
        logger.info(JSON.stringify(finalResponse));

        if (Object.keys(finalResponse).length !== 0)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            finalResponse.forEach(function (value, index, array) {
                ret.push(value["displayedName"]);
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

    this.getData = function (target, searchObjectJson, type, PolicyAttribute) {
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.find(target, searchObjectJson);
        logger.info(LOG_PREFIX + resultFetch.response);
        var finalResponse = JSON.parse(resultFetch.response)["aingr.Policy"];
        logger.info(LOG_PREFIX + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                if (PolicyAttribute) {
                    logger.info(LOG_PREFIX + "Policy Selected = {}", PolicyAttribute);
                    logger.info(LOG_PREFIX + "Device policy = {}", finalResponse[index][type]);
                    ret.push(finalResponse[index][type]);
                    break;
                }
                else {
                    ret.push(finalResponse[index][type]);
                }
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "result = \n" + JSON.stringify(ret));
        return ret;
    }
}
