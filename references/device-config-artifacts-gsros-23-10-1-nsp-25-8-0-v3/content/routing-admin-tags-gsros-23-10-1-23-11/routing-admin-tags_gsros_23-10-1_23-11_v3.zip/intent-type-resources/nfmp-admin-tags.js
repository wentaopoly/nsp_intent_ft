var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpAdminTags() {

    var util = new utilities();
    var savedTopology;
    var parseTarget = new ParseTarget();
    var isAudit = false;
    var isEdit = false;
    let nfmpFwk = new NfmpFwk();
    var auditResult = {};
    var nfmpFwkPostRequest = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true"
    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        if (input.getNetworkState().name() == "delete")
        {
            logger.info("Intent delete called.Ignoring Delete. Please delete Admin-tag-policy and Admin-tag manually");
            return;
        }
        savedTopology = input.getCurrentTopology();
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        //set the policy name from target
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        this.createOrModify(neId, intentConfig);
        result.setTopology(savedTopology);
        result.getTopology().setXtraInfo(savedTopology.getXtraInfo());
        return util.setSuccessResult(result, savedTopology);
    }
    this.createOrModify = function (neId, intentConfig) {
        this.createPolicyLevelPayLoad(neId, intentConfig);
    }
    this.createPolicyLevelPayLoad = function (neId, intentConfig) {
        if (savedTopology == null)
        {
            logger.info("Creating topology to store admin-tag and admin-tag-policy");
            savedTopology = topologyFactory.createServiceTopology();
        }
        logger.info("Begin List of admin-tags objects already exists = \n" + savedTopology.getXtraInfo());
        this.deleteAdminTags(neId, intentConfig);
        this.createAdminTag(neId, intentConfig);
        this.cretaeAdminTagPolicy(neId, intentConfig);
    }
    this.createAdminTag = function (neId, intentConfig) {
        if (intentConfig["admin-tag"])
        {
            if (!Array.isArray(intentConfig["admin-tag"]))
            {
                intentConfig["admin-tag"] = [intentConfig["admin-tag"]];
            }
            for (var index in intentConfig["admin-tag"])
            {
                isEdit = false;
                var adminTagConfig = intentConfig["admin-tag"][index];
                var fullClassName = "rtr.AdminTag";
                var policyFdn = "rtrAdminTag";
                var objectFullName = "rtrAdminTag:rtr-1-tag-" + adminTagConfig["tag"];
                var localPolicyFullName = "network:" + neId + ":" + objectFullName;
                localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
                if (util.isObjectExists(fullClassName, localPolicyFullName) || isAudit)
                {
                    objectFullName = localPolicyFullName;
                    if (!isAudit)
                    {
                        isEdit = true;
                    }
                }
                var entry = topologyFactory.createTopologyXtraInfoFrom(localPolicyFullName, fullClassName);
                savedTopology.addXtraInfo(entry);
                var properties = {};
                properties["tagName"] = adminTagConfig["tag"];
                properties["policyMode"] = "static";
                properties["routerId"] = 1;
                var childProperties = {};
                var policyLevelPayload = util.editPayload(policyFdn, properties, childProperties, fullClassName, objectFullName);
                if (!isAudit)
                {
                    this.sendRequestAndDistribute(neId, policyLevelPayload, objectFullName, localPolicyFullName, fullClassName);
                }
                else
                {
                    this.updateAuditResult(this.auditRequest(neId, policyLevelPayload));
                }
            }
        }
    }
    this.cretaeAdminTagPolicy = function (neId, intentConfig) {
        if (intentConfig["route-admin-tag-policy"])
        {
            if (!Array.isArray(intentConfig["route-admin-tag-policy"]))
            {
                intentConfig["route-admin-tag-policy"] = [intentConfig["route-admin-tag-policy"]];
            }
            for (var index in intentConfig["route-admin-tag-policy"])
            {
                isEdit = false;
                var adminTagPolicyConfig = intentConfig["route-admin-tag-policy"][index];
                var fullClassName = "rtr.AdminTagPolicy";
                var policyFdn = "rtrAdminTagPolicy";
                var objectFullName = "rtrAdminTagPolicy:rtr-1-ratpol-" + adminTagPolicyConfig["policy-name"];
                var localPolicyFullName = "network:" + neId + ":" + objectFullName;
                localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
                if (util.isObjectExists(fullClassName, localPolicyFullName) || isAudit)
                {
                    objectFullName = localPolicyFullName;
                    if (!isAudit)
                    {
                        isEdit = true;
                    }
                }
                var entry = topologyFactory.createTopologyXtraInfoFrom(localPolicyFullName, fullClassName);
                savedTopology.addXtraInfo(entry);
                var properties = {};
                properties["policyName"] = adminTagPolicyConfig["policy-name"];
                properties["policyMode"] = "static";
                properties["routerId"] = 1;
                var childProperties = {};
                if (adminTagPolicyConfig["include"])
                {
                    if (!Array.isArray(adminTagPolicyConfig["include"]))
                    {
                        adminTagPolicyConfig["include"] = [adminTagPolicyConfig["include"]];
                    }
                    var includePayloadArray = [];
                    for (var index in adminTagPolicyConfig["include"])
                    {
                        var includeConfig = adminTagPolicyConfig["include"][index];
                        var includePayload = this.createIncludePayload(adminTagPolicyConfig["policy-name"], includeConfig, childProperties);
                        includePayloadArray.push(includePayload);
                    }
                    childProperties["rtr.IncludeAdminTag"] = includePayloadArray;
                }
                else
                {
                    childProperties["rtr.IncludeAdminTag"] = [];
                }

                if (adminTagPolicyConfig["exclude"])
                {
                    if (!Array.isArray(adminTagPolicyConfig["exclude"]))
                    {
                        adminTagPolicyConfig["exclude"] = [adminTagPolicyConfig["exclude"]];
                    }
                    var excludePayloadArray = [];
                    for (var index in adminTagPolicyConfig["exclude"])
                    {
                        var excludeConfig = adminTagPolicyConfig["exclude"][index];
                        var excludePayload = this.createExcludePayload(adminTagPolicyConfig["policy-name"], excludeConfig, childProperties);
                        excludePayloadArray.push(excludePayload);
                    }
                    childProperties["rtr.ExcludeAdminTag"] = excludePayloadArray;
                }
                else
                {
                    childProperties["rtr.ExcludeAdminTag"] = [];
                }
                var policyLevelPayload = util.editPayload(policyFdn, properties, childProperties, fullClassName, objectFullName);
                if (!isAudit)
                {
                    this.sendRequestAndDistribute(neId, policyLevelPayload, objectFullName, localPolicyFullName, fullClassName);
                }
                else
                {
                    this.updateAuditResult(this.auditRequest(neId, policyLevelPayload));
                }
            }
        }
    }
    this.sendRequestAndDistribute = function (neId, payload, objectFullName, localPolicyFullName, fullClassName) {
        this.modifyRequest(neId, payload);
        if (!isEdit)
        {
            logger.info("Distributing the policy to local");
            var distributePayload = util.distribute(neId, objectFullName, false);
            var distributeResult = nfmpFwk.post(nfmpFwkPostRequest, distributePayload);
            if (!distributeResult.success)
            {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }
            util.delay(2000);
            // Changing SyncWithGlobal To Local Edit Only
            distributePayload = util.distribute(neId, objectFullName, true);
            distributeResult = nfmpFwk.post(nfmpFwkPostRequest, distributePayload);
            if (!distributeResult.success)
            {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }
            util.delay(2000);
            if (!util.isObjectExists(fullClassName, localPolicyFullName))
            {
                throw new RuntimeException("Unable to Distribute existing Global Policy: " + objectFullName + " to local policy: " + localPolicyFullName + " , Kindly check the Global Policy configuration");
            }
        }
    }
    this.modifyRequest = function (neId, payload) {

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
           logger.error("Error result = {}",JSON.stringify(result));
           let errorMsg = result.msg;
           if(errorMsg.indexOf("object already exists") !== -1)
           {
               logger.info("Global policy Object already exists, Re-checking the Policy existence ");
               //util.delay(2000);
               let configInfo = payload.configInfo;
               let fullClassName;
               for (let key in configInfo) {
                 if (configInfo.hasOwnProperty(key)) {
                   fullClassName = key;
                   break;
                 }
               }
               let objectFullName = payload.objectFullName;
               objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
               logger.info("fullClassName = {}",fullClassName);
               logger.info("objectFullName = {}",objectFullName);
               if (!util.isObjectExists(fullClassName, objectFullName))
               {
                   throw new RuntimeException("Global Policy Object Not Found!!!");
               }
           }
           else
           {
               throw new RuntimeException(result.msg);
           }
        }
        return result;
    }
    this.createIncludePayload = function (policyName, includeConfig, childProperties) {
        //var fullClassName = "rtr.AdminTagPolicy";
        var properties = {};
        properties["tagName"] = includeConfig["tag"];
        properties["tagPointer"] = "rtrAdminTag:rtr-1-tag-" + includeConfig["tag"];
        properties["policyName"] = policyName;
        properties["routerId"] = 1;
        return properties;
    }
    this.createExcludePayload = function (policyName, excludeConfig, childProperties) {
        //var fullClassName = "rtr.AdminTagPolicy";
        var properties = {};
        properties["tagName"] = excludeConfig["tag"];
        properties["tagPointer"] = "rtrAdminTag:rtr-1-tag-" + excludeConfig["tag"];
        properties["policyName"] = policyName;
        properties["routerId"] = 1;
        return properties;
    }
    this.syncDeleteChild = function (objectFullName, neId) {
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        logger.info("Deleting : " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
    }
    this.deleteAdminTags = function (neId, intentConfig) {
        logger.info("deleteAdminTags Admin-tag and Admin-tag-policy");
        var objectFullNameList = [];
        if (intentConfig["route-admin-tag-policy"] && !Array.isArray(intentConfig["route-admin-tag-policy"]))
        {
            intentConfig["route-admin-tag-policy"] = [intentConfig["route-admin-tag-policy"]];
        }
        objectFullNameList = objectFullNameList.concat(this.getAdminTagsObjectFullName(neId, intentConfig["route-admin-tag-policy"], "admin-tag-policy"));

        if (intentConfig["admin-tag"] && !Array.isArray(intentConfig["admin-tag"]))
        {
            intentConfig["admin-tag"] = [intentConfig["admin-tag"]];
        }
        objectFullNameList = objectFullNameList.concat(this.getAdminTagsObjectFullName(neId, intentConfig["admin-tag"], "admin-tag"));

        logger.info("List of admin-tags objects in intent = \n" + objectFullNameList);
        logger.info("List of admin-tags objects already exists = \n" + savedTopology.getXtraInfo());

        var intentlength = objectFullNameList.length;
        var XtraInfolength = savedTopology.getXtraInfo().length;

        var childObjectsBeDeleted = [];
        for (var index in savedTopology.getXtraInfo())
        {
            logger.info("Iterating savedTopology ");

            var xtraInfo = savedTopology.getXtraInfo()[index].getKey();
            logger.info("xtraInfo ====== {}", xtraInfo);
            var deleteFlag = true;
            for (var index in objectFullNameList)
            {
                logger.info("Iterating objectFullNameList ");
                logger.info("objectFullNameList[index] ====== {}", objectFullNameList[index]);
                if (xtraInfo == objectFullNameList[index])
                {
                    deleteFlag = false;
                    break;
                }
            }
            if (deleteFlag)
            {
                childObjectsBeDeleted.push(xtraInfo);
            }
        }
        for (var index in childObjectsBeDeleted)
        {
            logger.info(childObjectsBeDeleted[index]);
            this.syncDeleteChild(childObjectsBeDeleted[index],neId);
        }
        savedTopology.setXtraInfo([]);
    }
    this.getAdminTagsObjectFullName = function (neId, intentAdminTagsConfig, type) {
        var objectFullNameList = [];
        for (var index in intentAdminTagsConfig)
        {
            var adminTagsConfig = intentAdminTagsConfig[index];
            if (adminTagsConfig)
            {
                var objectFullName;
                if (type === "admin-tag")
                {
                    objectFullName = "network:" + neId + ":rtrAdminTag:rtr-1-tag-" + adminTagsConfig["tag"];
                    objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
                }
                else if (type === "admin-tag-policy")
                {
                    objectFullName = "network:" + neId + ":rtrAdminTagPolicy:rtr-1-ratpol-" + adminTagsConfig["policy-name"];
                    objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
                }
                objectFullNameList = objectFullNameList.concat(objectFullName);
            }
        }
        return objectFullNameList;
    }
    this.audit = function (target, config, svcTopo, adminState, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        isAudit = true;
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        var neId = parseTarget.getNeIdFromTarget(target);
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        if (intentConfig)
        {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }
        return auditReport
    }
    this.auditAndCompare = function (neId, intentConfig, auditReport) {
        this.createPolicyLevelPayLoad(neId, intentConfig);
        logger.info("Final audit result =\n" + JSON.stringify(auditResult))
        auditReport = util.reportMisaligned(neId, auditResult, auditReport);
        return auditReport;
    }
    this.auditRequest = function (neId, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }
    this.updateAuditResult = function (aInAuditResult) {
        var resultResp = JSON.parse(aInAuditResult.response);
        var misalignedAttributes = resultResp.misalignedAttributes;
        if (Object.keys(auditResult).length === 0)
        {
            auditResult = resultResp;
        }
        else
        {
            if (misalignedAttributes.length > 0)
            {
                auditResult.misalignedAttributes = auditResult.misalignedAttributes.concat(misalignedAttributes);
                auditResult.aligned = false;
            }
        }
    }
    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('input json: ' + json)
        return JSON.parse(json);
    }
}
