import { IntentHandlerBase }  from 'common/IntentHandlerBase.mjs';
import { NSP }  from 'common/NSP.mjs';
const HashMap = Java.type("java.util.HashMap");

class IntentHandler extends (IntentHandlerBase) {
  constructor() {
    super();
    NSP.checkRelease(24, 11);
    this.ignoreChildren = [];
  }

  getDeviceModelPath(target) {
    const items = target.split('#');
    return `nokia-conf:/configure/router=Base/bgp/group=${encodeURIComponent(items[2])}`;
  }

  getDesiredConfig(target, intentConfigJSON) {
    const items = target.split('#');
    const config = Object.values(Object.values(JSON.parse(intentConfigJSON)[0])[0])[0];
    config["group-name"] = items[2];
    return {"nokia-conf:group": [this.cleanupConfig(config)]};
  }
  
  getTargetDataHook(target, config) {
    return {"group": config};
  }

  // WebUI suggest/picker callouts:
  suggestGroupName(context) {
    const target = this.getTarget(context);
    return this.getDeviceModelObjects(context, `nokia-conf:/configure/router=Base/bgp/group`, "group-name");
  }

  suggestKeychainsKeychainName(context) {
    const target = this.getTarget(context);
    return this.getDeviceModelObjects(context, `nokia-conf:/configure/system/security/keychains/keychain`);
  }

  suggestPolicyOptionsPolicyStatementName(context) {
    const target = this.getTarget(context);
    return this.getDeviceModelObjects(context, `nokia-conf:/configure/policy-options/policy-statement`);
  }

  suggestBmpStationName(context) {
    const target = this.getTarget(context);
    return this.getDeviceModelObjects(context, `nokia-conf:/configure/bmp/station`);
  }

suggestInterfaceName(context) {
    let data1 = this.getDeviceModelObjects(context, `nokia-conf:/configure/router/interface`);
    let data2 = this.getDeviceModelObjects(context, `nokia-conf:/configure/service/ies/interface`);
    if (!data1 && !data2) {
        return new HashMap();
    }
    if (!data1) {
        return data2;
    }
    if (!data2) {
        return data1;
    }
    let list1 = Array.from(data1.keySet());
    let list2 = Array.from(data2.keySet());
    let interfaceData = [...new Set([...list1, ...list2])];
    let result = new HashMap();
    interfaceData.forEach(i => result.put(i, i));
    return result;
}


getModuleRefs() {
  return JSON.parse('{}');
}


}

new IntentHandler();