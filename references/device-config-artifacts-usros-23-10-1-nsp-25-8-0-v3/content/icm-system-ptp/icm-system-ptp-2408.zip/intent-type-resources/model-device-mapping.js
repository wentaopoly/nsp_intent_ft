function ModelDeviceMapping() {
    this.getPtpMapping = function () {
        var mapping = {};
        mapping['ptp.admin-state'] = 'clockAdminState';
        mapping['ptp.announce-receipt-timeout'] = 'ptpClockAnnoRxTimeout';
        mapping['ptp.log-announce-interval'] = 'ptpClockAnnounceInterval';
        mapping['ptp.clock-type'] = 'clockType';
        mapping['ptp.network-type'] = 'clockNetworkType';
        mapping['ptp.domain'] = 'clockDomain';
        mapping['ptp.profile'] = 'clockProfile';
        mapping['ptp.local-priority'] = 'clockLocalPriority';
        mapping['ptp.priority1'] = 'clockPriority1';
        mapping['ptp.priority2'] = 'clockPriority2';
        mapping['ptp.tx-while-sync-uncertain'] = 'txWhileSyncUncertain';
        return mapping;
    }

    this.getPtpPortMapping = function () {
        var mapping = {};
        mapping['ptp.port.port-id'] = 'displayedName';
        mapping['ptp.port.admin-state'] = 'ptpPortClockAdminState';
        mapping['ptp.port.address'] = 'ptpPortMulticastAddress';
        mapping['ptp.port.local-priority'] = 'ptpPortLocalPriority';
        mapping['ptp.port.log-delay-interval'] = 'ptpPortDelayInterval';
        mapping['ptp.port.log-sync-interval'] = 'ptpPortSyncInterval';
        mapping['ptp.port.master-only'] = 'ptpPortMasterOnly';
        return mapping;
    }
}
