
var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn" : "http://www.nokia.com/management-solutions/ibn",
    "nc" : "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager" : "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders" : "anv-device-holders"
};

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})

load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
mdtFwk = new MdtFwk();


var LOG_PREFIX = "[Port QOS Access Egress 7210]: "

var intentTypeName = 'qos-port-egress_csas_23-10-1_23-11';

// example port, sap-ingress etc..
var initialPropertyName = 'port-qos-egress';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/qos';

// unique identifier
var uniqueIdentifier = 'port-qos-policy-id';

function synchronize(input) {
    return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function audit(input) {
    logger.info('Intent Audit started')
    logger.info("*******config ===== {}", input);
    return NspIntentHelper.audit(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier)
}


function getTargetData(input) {
    logger.info(input);
    var target = input.target;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}


function suggestPortEgressPolicyId(context) {
    logger.info(LOG_PREFIX + "suggestPolicyId context = \n" + context);
    logger.info(LOG_PREFIX + "***** Suggesting Port Access Egress Policy ID's ********");
    var neId = getNeId(context);
    return new NfmpSuggest().getPolicyId(neId);
}

function suggestQueueManagementPolicy(context) {
    var neId = getNeId(context);
    var className = "sasqos.QueueMgmtPolicy";
    logger.info(LOG_PREFIX + "********** suggestQueueManagementPolicy ********* ");
    return new NfmpSuggest().getSupportAttributePolicyDetails(neId, className, false);
}

function suggestRemarkingPolicy(context) {
    var neId = getNeId(context);
    var className = "sasqos.Remark";
    logger.info(LOG_PREFIX + "********** suggestRemarkingPolicy ********* ");
    return new NfmpSuggest().getSupportAttributePolicyDetails(neId, className, false);
}

function getNeId(context) {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    logger.info(target)
    if (target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    logger.info(LOG_PREFIX + "NeId : " + neId);
    return neId;
}



function validate(syncInput) {
    var contextualErrorJsonObj = {};
    var intentConfig = syncInput.getJsonIntentConfiguration();


    if (Object.keys(contextualErrorJsonObj).length !== 0) {
        utilityService.throwContextErrorException(contextualErrorJsonObj);
    }
}

