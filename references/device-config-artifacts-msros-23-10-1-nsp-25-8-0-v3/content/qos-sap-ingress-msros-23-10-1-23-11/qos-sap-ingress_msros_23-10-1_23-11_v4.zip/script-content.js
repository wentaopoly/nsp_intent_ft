var RuntimeException = Java.type("java.lang.RuntimeException");

var prefixToNsMap = {
    ibn: "http://www.nokia.com/management-solutions/ibn",
    nc: "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders":
        "anv-device-holders",
};

load({script: resourceProvider.getResource("mdc-fwk.js"), name: "MdcFwk"});
const mdcFwk = new MdcFwk();

load({script: resourceProvider.getResource("mdt-fwk.js"), name: "MdtFwk"});
var mdtFwk = new MdtFwk();

load({
    script: resourceProvider.getResource("parse-target.js"),
    name: "ParseTarget",
});
var parsedTarget = new ParseTarget();

/**
 * Load lodash and create object as underscore(_)
 */
load({
    script: resourceProvider.getResource("lodash.js"),
    name: "Lodash",
});
const _ = new Lodash();

/**
 * Load Deep-diff and create object as DeepDiff
 */
load({
    script: resourceProvider.getResource("deep-diff.js"),
    name: "DeepDiff",
});
const deepDiff = new DeepDiff();

/**
 *
 * Load and instantiate UtilFwk
 * @see UtilFwk
 */
load({
    script: resourceProvider.getResource("util-fwk.js"),
    name: "UtilFwk",
});
const utilFwk = new UtilFwk();


/**
 *
 * Load and instantiate ICMFwk
 * It contain ICM framework specific functions
 *
 * @see ICMFwk
 */
load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"});
const icmFwk = new ICMFwk();

/**
 * Load and instance IcmServiceFwk
 *
 * @see GtdFWk
 */
load({
    script: resourceProvider.getResource("icm-service-fwk.js"),
    name: "icm-service-fwk",
});
const icmServiceFwk = new IcmServiceFwk();

/**
 *
 */
load({
    script: resourceProvider.getResource("parse-target.js"),
    name: "ParseTarget",
});
var parsedTarget = new ParseTarget();

load({
    script: resourceProvider.getResource("common-utils.js"),
    name: "CommonUtil",
});


load({
  script: resourceProvider.getResource("custom-hooks.js"),
  name: "CustomHooks",
});

const customHooks = new CustomHooks();
load({script: resourceProvider.getResource('mdSuggest.js'), name: 'mdSuggest'});

var commonUtil = new CommonUtil();

const metadata = JSON.parse(resourceProvider.getResource("meta-data.json"));

var intentTypeName = 'qos-sap-ingress_msros_23-10-1_23-11';

/**
 * The node which you would like to configure.
 * example port, sap-ingress etc.
 * In the intent-yang, you will see this as a container
 * which encapsulates all the different type of nodes
 */
var intentContainer = 'sap-ingress';

var deviceYangModuleName = 'nokia-conf';

// unique identifier
var uniqueIdentifier = 'sap-ingress-policy-name';

// example "configure" , "configure/qos" etc..
var rootXPath = 'configure/qos';

/**
 *
 * @param {*} input
 */
function validate(input) {
    logger.info("--------------Intent validate --------------");
    var config = formatConfig(input.getJsonIntentConfiguration());
    logger.info("config " + config);
}

/**
 *
 * This function is starting point by IM for sync operation
 *
 * @param {*} input
 * @returns
 */
function synchronize(input) {
    /**
     * Deployment of intents to the network, called for synchronize operations.
     * Used to apply create, update, delete and reconcile to managed devices.
     *
     * All created objects are remembered/restored as part of topology/extra-data
     * to apply house-keeping operations.
     *
     **/
    logger.info("--------------Intent Synchronisation started--------------");
    logger.info("input " + input);
    logger.info("intentTypeName " + intentTypeName);
    logger.info("rootXPath " + rootXPath);
    logger.info("intentContainer " + intentContainer);
    logger.info("uniqueIdentifier " + uniqueIdentifier);
    logger.info("deviceYangModuleName " + deviceYangModuleName);

    // TODO, so far the code is handling single intentContainer
    // but there can be multuple top level containers like the case of cpm-filter having ip-filter, ipv6-filter and mac-filter
    // format the config as per your use-case
    var config = formatConfig(input.getJsonIntentConfiguration());
    logger.info("config " + config);

    var target = input.getTarget();
    var state = input.getNetworkState().name();
    logger.info("state " + state);
    var startTime = new Date().getTime();
    var syncResult = synchronizeResultFactory.createSynchronizeResult();
    logger.info(
        intentTypeName + ":synchronize(" + target + ") in state " + state
    );
    // current topology
    var topology = input.getCurrentTopology();
    if (topology == null) {
        topology = topologyFactory.createServiceTopology();
    }
    logger.info("topology " + JSON.stringify(topology));
    var resp = utilFwk.synchronize(
        target,
        config,
        intentTypeName,
        rootXPath,
        intentContainer,
        uniqueIdentifier,
        deviceYangModuleName,
        topology,
        state,
        syncResult
    );
    var endTime = Date.now();
    var timeTaken = (endTime - startTime) / 1000; // seconds
    logger.info(
        "Time taken to synchronize " + timeTaken + " seconds for intent " + target
    );
    var endTime = Date.now();
    var timeTaken = (endTime - startTime) / 1000; // seconds
    logger.info("Time taken to synchronize " + timeTaken);
    logger.info("--------------Intent Synchronisation done--------------");
    return resp;
}

/**
 *
 * The function is starting point for audit operation in IM
 *
 * @param {*} input
 * @returns auditReport
 */
function audit(input) {
    logger.info("-------------- Intent Audit --------------");
    var startTime = new Date().getTime();
    var target = input.getTarget();
    var key = intentTypeName + ":" + intentTypeName;
    var intentConfig = JSON.parse(input.getJsonIntentConfiguration())[0][key][
        intentContainer
        ];
    var state = input.getNetworkState().name();
    var topology = input.getCurrentTopology();

    logger.info("target " + target);
    logger.info("topology " + topology);
    logger.info("state " + state);
    logger.info("intentConfig " + JSON.stringify(intentConfig));
    let auditReport = utilFwk.audit(
        target,
        intentConfig,
        topology,
        state,
        intentTypeName,
        rootXPath,
        intentContainer,
        uniqueIdentifier,
        deviceYangModuleName
    );
    var endTime = Date.now();
    var timeTaken = (endTime - startTime) / 1000; // seconds
    logger.info(
        "Time taken to audit " + timeTaken + " seconds for intent " + target
    );
    return auditReport;
}

/**
 *
 * The function is used in Brownfield disscovery by ICM FW
 * It discover the configuration from the target device
 * and manipulate as per Template's default-target-data
 *
 *
 * @see ICMFwk for more details
 * @param {*} input - the config data of a deployment
 * @returns result - the result of the operation
 */
function getTargetData(input) {
    logger.info("-------- Intent getTargetData started ------");
    logger.info(JSON.stringify(input));
    var target = input.target;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(
        target,
        deviceYangModuleName,
        rootXPath,
        intentContainer
    );
    logger.info(JSON.stringify(deviceConfig));
    var data = icmServiceFwk.gtdSend(deviceConfig);
    logger.info(JSON.stringify(data));
    logger.info(JSON.stringify(data.msg.result));
    return data.msg.result;
}

/**
 *
 * If there are multiple containers at in intent-yang for intentContainer name,
 * the config returned by the scriptEnginer is array
 *
 * @param {*} config
 * @returns
 */
const formatConfig = (config) => {
    if (Array.isArray(config)) {
        return config[0];
    } else {
        return config;
    }
};

function suggestPolicyName(context) {
    logger.info("suggestPolicyName context = \n" + context);
    var policyId = context.getInputValues()["arguments"]["target_policy-id"];
    logger.info("User  selected Policy ID : {}, searching Policy Name associaed to Policy-id - {}", policyId, policyId);
    var neId = getNeId(context);
    return navigateInstance(neId).getPolicyName(neId, policyId);
}

function suggestPolicyId(context) {
    logger.info("suggestPolicyId context = \n" + context);
    var policyName = context.getInputValues()["arguments"]["target_sap-ingress-policy-name"];
    logger.info("User  selected Policy Name : {}, searching Policy ID associaed to Policy Name - {}", policyName, policyName);
    var neId = getNeId(context);
    return navigateInstance(neId).getPolicyId(neId, policyName);
}

function suggestPolicer(context) {
    var policerIds = [];
    logger.info("Suggest Policer Context = \n" + context);
    var policer = context['inputValues']['arguments']['__root']['sap-ingress']['policer'];
    policer.forEach(function (policerObject) {
        logger.info("Policer Id in Input : " + policerObject['policer-id']);
        policerIds.push(policerObject['policer-id']);
    });
    return policerIds;
}

function suggestIpCriteriaPrefixList(context) {
    logger.info("suggest IP Prefix List Context = \n" + context);
    var neId = getNeId(context);
    return navigateInstance(neId).getIpCriteriaPrefixList(neId);
}

function suggestIpv6CriteriaPrefixList(context) {
    logger.info("suggest IPv6 Prefix List Context = \n" + context);
    var neId = getNeId(context);
    return navigateInstance(neId).getIpv6CriteriaPrefixList(neId);
}

function suggestAdvConfigPolicy(context) {
    logger.info("suggest Advanced QoS policy Context = \n" + context);
    var neId = getNeId(context);
    return navigateInstance(neId).getAdvConfigPolicy(neId);
}

function suggestFcPolicer(context) {
    var fcPolicerId = [];
    logger.info("suggestFcPolicer context = \n" + context);
    var policer = context['inputValues']['arguments']['__root']['sap-ingress']['policer'];
    policer.forEach(function (fcPolicerObject) {
        logger.info("Forwarding Class Policer Id in Input : " + fcPolicerObject['policer-id']);
        fcPolicerId.push(fcPolicerObject['policer-id']);
    });
    return fcPolicerId;
}

function suggestFcQueue(context) {
    var fcQueueResult = [];
    logger.info("suggest Fc Queue context = \n" + context);
    var queue = context['inputValues']['arguments']["__root"]["sap-ingress"]["queue"];
    queue.forEach(function (fcQueueObject) {
        logger.info("FC Queue ID In Input : " + fcQueueObject['queue-id']);
        fcQueueResult.push(fcQueueObject['queue-id']);
    });
    return fcQueueResult;
}

function suggestQueueGroupName(context) {
    logger.info("suggest Queue_Group_Name context = \n" + context);
    var neId = getNeId(context);
    return navigateInstance(neId).getQueueGroupNames(neId);
}

function suggestQueueGroupQueue(context) {
    logger.info("suggest Queue_Group_Queues context = \n" + context);
    var neId = getNeId(context);
    var queueGroupName = context['inputValues']['arguments']["queue-group-queue"]["queue-group-name"];
    if (queueGroupName) {
        return navigateInstance(neId).getQueueGroupQueues(neId, queueGroupName);
    }
}

function suggestUnknownPolicer(context) {
    var unknownPolicerIds = [];
    logger.info("suggest Unknown Policer context = \n" + context);
    var policer = context['inputValues']['arguments']['__root']['sap-ingress']['policer'];
    var neId = getNeId(context);
    policer.forEach(function (unknownPolicerObject) {
        logger.info("Unknown Policer Id in Input : " + unknownPolicerObject['policer-id']);
        unknownPolicerIds.push(unknownPolicerObject['policer-id']);
    });
    return unknownPolicerIds;
}

function suggestUnknownQueue(context) {
    var unknownQueue = [];
    logger.info("suggest Unknown Queue context = \n" + context);
    var neId = getNeId(context);
    var queue = context['inputValues']['arguments']["__root"]["sap-ingress"]["queue"];
    queue.forEach(function (unknownQueueObject) {
        logger.info("Unknown Queue ID In Input : " + unknownQueueObject['queue-id']);
        unknownQueue.push(unknownQueueObject['queue-id']);
    });
    return unknownQueue;
}

function suggestUnknownQueueGrpName(context) {
    logger.info("suggest Unknown_Queue_Grp_Name context = \n" + context);
    var neId = getNeId(context);
    return navigateInstance(neId).getQueueGroupNames(neId);
}

function suggestUnknownQueueGrpQueue(context) {
    logger.info("suggest Unknown_Queue_Grp_Name context = \n" + context);
    var queueGroupName = context['inputValues']['arguments']["unknown-queue-group-queue"]["queue-group-name"];
    var neId = getNeId(context);
    if (queueGroupName) {
        return navigateInstance(neId).getQueueGroupQueues(neId, queueGroupName);
    }
}

function suggestBroadcastPolicer(context) {
    var broadcastPolicerId = [];
    logger.info("suggest Broadcast Policer context = \n" + context);
    var policer = context['inputValues']['arguments']['__root']['sap-ingress']['policer'];
    policer.forEach(function (broadcastPolicerObject) {
        logger.info("Broadcast Policer Id in Input : " + broadcastPolicerObject['policer-id']);
        broadcastPolicerId.push(broadcastPolicerObject['policer-id']);
    });
    return broadcastPolicerId;
}

function suggestBroadcastQueueGrpName(context) {
    logger.info("suggest Broadcast_Queue_Grp_Name context = \n" + context);
    var neId = getNeId(context);
    return navigateInstance(neId).getQueueGroupNames(neId);
}

function suggestBroadcastQueue(context) {
    var broadcastQueue = [];
    logger.info("suggest Broadcast_Queue_Grp_Queue context = \n" + context);
    var neId = getNeId(context);
    var queue = context['inputValues']['arguments']["__root"]["sap-ingress"]["queue"];
    queue.forEach(function (broadcastQueueObject) {
        logger.info("Broadcast Queue ID In Input : " + broadcastQueueObject['queue-id']);
        broadcastQueue.push(broadcastQueueObject['queue-id']);
    });
    return broadcastQueue;
}

function suggestBroadcastQueueGroupQueue(context) {
    logger.info("suggest Broadcast_Queue_Grp_Queue context = \n" + context);
    var queueGroupName = context['inputValues']['arguments']["broadcast-queue-group-queue"]["queue-group-name"];
    var neId = getNeId(context);
    if (queueGroupName) {
        return navigateInstance(neId).getQueueGroupQueues(neId, queueGroupName);
    }
}

function suggestMulticastPolicer(context) {
    var multicastPolicer = [];
    logger.info("suggest Multicast Policer context = \n" + context);
    var neId = getNeId(context);
    var policer = context['inputValues']['arguments']['__root']['sap-ingress']['policer'];
    policer.forEach(function (multicastPolicerObject) {
        logger.info("Multicast Policer Id in Input : " + multicastPolicerObject['policer-id']);
        multicastPolicer.push(multicastPolicerObject['policer-id']);
    });
    return multicastPolicer;
}

function suggestMultiCastQueue(context) {
    var multicastQueue = [];
    logger.info("suggest Multicast Queue context = \n" + context);
    var neId = getNeId(context);
    var queue = context['inputValues']['arguments']["__root"]["sap-ingress"]["queue"];
    queue.forEach(function (multicastQueueObject) {
        logger.info("Multicast Queue ID In Input : " + multicastQueueObject['queue-id']);
        multicastQueue.push(multicastQueueObject['queue-id']);
    });
    return multicastQueue;
}

function suggestMulticastQueueGrpName(context) {
    logger.info("suggest Multicast_Queue_Grp_Name context = \n" + context);
    var neId = getNeId(context);
    return navigateInstance(neId).getQueueGroupNames(neId);
}

function suggestMulticastQGroupQueue(context) {
    logger.info("suggest Multicast_Queue_Grp_Queue context = \n" + context);
    var queueGroupName = context['inputValues']['arguments']["multicast-queue-group-queue"]["queue-group-name"];
    var neId = getNeId(context);
    if (queueGroupName) {
        return navigateInstance(neId).getQueueGroupQueues(neId, queueGroupName);
    }
}

function getNeId(context) {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    logger.info("target : {}", target)
    if (!target) {
        target = context.getInputValues()["arguments"]["__root"]["target_objectidentifier"];
    }
    if (target) {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        } else {
            neId = target;
        }
    }
    logger.info("NeId identified " + " : {}", neId);
    return neId;
}

function navigateInstance(neId) {
    var managerName = mdtFwk.getManagerName(neId);
    logger.info('Device: ' + neId + ' is managed by: ' + managerName);
    switch (managerName) {
        case 'MDC':
            logger.info('Device is managed by MDM')
            return new MdSuggest();
            break;
        default:
            logger.info('Device is not managed')
            throw new RuntimeException('Device is not Managed')
    }
    return ''
}

function suggestFc() {
    return ["be", "l2", "af", "l1", "h2", "ef", "h1", "nc"];
}

function suggestFcConfigured(context) {
    var defaultFc = [];
    logger.info("Suggest Configured FC Context = \n" + context);
    var forwardingClass = context['inputValues']['arguments']['__root']['sap-ingress']['fc'];
    forwardingClass.forEach(function (fcObject) {
        logger.info("FC Name in Input : " + fcObject['fc-name']);
        defaultFc.push(fcObject['fc-name']);
    });
    return defaultFc;
}

function suggestDefaultFC(context) {
    var defaultFc = [];
    logger.info("Suggest Default FC Context = \n" + context);
    var forwardingClass = context['inputValues']['arguments']['sap-ingress']['fc'];
    forwardingClass.forEach(function (fcObject) {
        logger.info("FC Name in Input : " + fcObject['fc-name']);
        defaultFc.push(fcObject['fc-name']);
    });
    return defaultFc;
}
