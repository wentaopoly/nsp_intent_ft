var RuntimeException = Java.type('java.lang.RuntimeException');

load({
    script: resourceProvider.getResource('mdc-fwk.js'),
    name: 'MdcFwk'
});
load({
    script: resourceProvider.getResource('parse-target.js'),
    name: 'ParseTarget'
});


function MdcDiscoveryHelper() {
    let mdcFwk = new MdcFwk();
    let parseTarget = new ParseTarget();

    let neId = undefined;

    this.getDeviceConfiguration = function (targetWithTemplate, initialPropertyName) {

        neId = parseTarget.getNeIdFromTarget(targetWithTemplate);
        let url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/system/security/" + initialPropertyName;
        let getResult = mdcFwk.fetch(neId, url);
        let configFromDevice = getResult.msg["nokia-conf:" + initialPropertyName];
        if (configFromDevice == undefined) {
            throw new RuntimeException("cannot get configuration from device");
        }

        return configFromDevice;
    }

    this.extractDeviceConfig = function (targetData, deviceConfig, initialPropertyName) {

        let url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/system/security";
        let getResult = mdcFwk.fetch(neId, url);

        let configFromDevice = getResult.msg["nokia-conf:security"];

        if (configFromDevice == undefined ||
            ( configFromDevice['cpm-filter'] == undefined && configFromDevice['cpm-queue'] == undefined)) {
            throw new RuntimeException("cannot get configuration from device");
        }

        let cpmConfig = {};
        
        cpmConfig['cpm-filter'] = configFromDevice['cpm-filter'];
        cpmConfig['cpm-queue'] = configFromDevice['cpm-queue'];

        let parsedTargetData = JSON.parse(targetData);

        let cpmObjects = ['cpm-filter', 'cpm-queue'];

        for (let i = 0; i < cpmObjects.length; i++) {
            let cpmObject = cpmObjects[i];
            if (cpmConfig[cpmObject]) {
                let config = parsedTargetData[cpmObject];
                let mergedTargetData = this.traverse(config, cpmConfig[cpmObject]);
                parsedTargetData[cpmObject] = mergedTargetData;
            }
        }

        if(configFromDevice['cpm-queue'] == undefined)
        {
            delete parsedTargetData['cpm-queue'];
        }

        if(configFromDevice['cpm-filter'] == undefined)
        {
            delete parsedTargetData['cpm-filter'];
        }

        if(configFromDevice['cpm-filter'] != undefined)
        {
            if (parsedTargetData["cpm-filter"]["ip-filter"]) {
                let ipFilterEntries = parsedTargetData["cpm-filter"]["ip-filter"]["entry"];
                if (ipFilterEntries) {
                    let ipFilterentyObjects = []
                    for (let i = 0; i < ipFilterEntries.length; i++) {
                        let entryObj = ipFilterEntries[i];
                        if (entryObj["match"]) {
                            if (entryObj["match"]["src-port"]) {
                                if (entryObj["match"]["src-port"]["range"]) {
                                    entryObj["match"]["src-port"]["port"] = "range";
                                } else if (entryObj["match"]["src-port"]["port-list"]) {
                                    entryObj["match"]["src-port"]["port"] = "port-list";
                                } else {
                                    entryObj["match"]["src-port"]["port"] = "eq";
                                }
                            } else if (entryObj["match"]["dst-port"]) {
                                if (entryObj["match"]["dst-port"]["range"]) {
                                    entryObj["match"]["dst-port"]["port"] = "range";
                                } else if (entryObj["match"]["dst-port"]["port-list"]) {
                                    entryObj["match"]["dst-port"]["port"] = "port-list";
                                } else {
                                    entryObj["match"]["dst-port"]["port"] = "eq";
                                }
                            }
                            ipFilterentyObjects.push(entryObj);
                        }
                    }
                    parsedTargetData["cpm-filter"]["ip-filter"]["entry"] = ipFilterentyObjects;
                }
            }
        }

        return parsedTargetData;
    }


    this.traverse = function (targetData, deviceConfig) {
        if (targetData !== null && targetData !== undefined) {
            let keys = Object.keys(targetData);
            for (let i = 0; i < keys.length; i++) {
                let propertyName = keys[i];
                let deviceValue = deviceConfig[propertyName];

                if (deviceValue != undefined && Array.isArray(deviceValue)) {
                    targetData[propertyName] = this.ArrayTraverse(targetData[propertyName], deviceValue, []);
                } else if (deviceValue != undefined && typeof deviceValue === 'object') {
                    targetData[propertyName] = this.containerTraverse(targetData[propertyName], deviceValue, {});
                } else {
                    targetData[propertyName] = deviceValue
                }
            }

        }
        return targetData;
    }

    this.ArrayTraverse = function (arrayTargetData, arrayDeviceConfigData, arrayData) {
        for (let i = 0; i < arrayDeviceConfigData.length; i++) {
            let arrayObject = {};
            let keys = Object.keys(arrayTargetData[0]);
            for (let j = 0; j < keys.length; j++) {
                let propertyName = keys[j];
                let deviceValue = arrayDeviceConfigData[i][propertyName];

                if (deviceValue != null && deviceValue != undefined && Array.isArray(deviceValue)) {
                    arrayObject[propertyName] = this.ArrayTraverse(arrayTargetData[0][propertyName], deviceValue, []);
                } else if (deviceValue != null && deviceValue != undefined && typeof deviceValue === 'object') {
                    arrayObject[propertyName] = this.containerTraverse(arrayTargetData[0][propertyName], deviceValue, {});

                } else {
                    arrayObject[propertyName] = deviceValue
                }
            }
            arrayData.push(arrayObject);
        }

        return arrayData;
    }

    this.containerTraverse = function (containerTargetData, containerDeviceConfigData, targetContainer) {
        let keys = Object.keys(containerTargetData);
        for (let i = 0; i < keys.length; i++) {
            let propertyName = keys[i];
            let deviceValue = containerDeviceConfigData[propertyName];

            if (deviceValue != null && deviceValue != undefined && Array.isArray(deviceValue)) {
                if (this.isAtrributeLeafList(deviceValue)) {
                    targetContainer[propertyName] = deviceValue;
                } else {
                    targetContainer[propertyName] = this.ArrayTraverse(containerTargetData[propertyName], deviceValue, []);
                }

            } else if (deviceValue != null && deviceValue != undefined && typeof deviceValue === 'object') {
                targetContainer[propertyName] = this.containerTraverse(containerTargetData[propertyName], deviceValue, {});
            } else {
                targetContainer[propertyName] = deviceValue
            }
        }
        return targetContainer;
    }

    this.isAtrributeLeafList = function (leaflistData) {
        let isLeaflist = true;
        for (let i = 0; i < leaflistData.length; i++) {

            if (leaflistData[i] != null && typeof leaflistData[i] == 'object') {
                isLeaflist = false;
                break;
            }
        }
        return isLeaflist;
    }

    this.cipherSpecialCharacterInKey = function (key) {
        return key.replaceAll("/", "%2F").replaceAll(":", "%3A");
    }
}
