load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
load({script: resourceProvider.getResource('nfmp-config.js'), name: 'NfmpConfig'})
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'})

function NspIntentHelper() {

    let mdtFwk = new MdtFwk();

    this.synchronize = function (input, intentTypeName, initialPropertyName, uniqueIdentifier) {
        logger.info("-------------------- nsp-intent-helper.js -> synchronize() --------------------");
        logger.info("intentTypeName = {},\ninitialPropertyName = {},\nuniqueIdentifier ={}", intentTypeName, initialPropertyName, uniqueIdentifier);
        try
        {
            let result = synchronizeResultFactory.createSynchronizeResult();
            let instanceFwk = this.navigateInstance(input.getTarget());
            instanceFwk.synchronize(input, result, intentTypeName, initialPropertyName, uniqueIdentifier);
            return result
        } catch (e)
        {
            logger.info('Error Occured while Synchronising with error: ' + e)
            throw new RuntimeException('Error Executing Intent: ' + e)
        }
    }
    this.audit = function (input, intentTypeName, initialPropertyName, uniqueIdentifier) {
        logger.info("-------------------- nsp-intent-helper.js -> audit() --------------------");
        logger.info("intentTypeName = {},\ninitialPropertyName = {},\nuniqueIdentifier ={}", intentTypeName, initialPropertyName, uniqueIdentifier);
        try
        {
            let instanceFwk = this.navigateInstance(input.getTarget());
            logger.info('instanceFwk ' + instanceFwk)
            let report = auditFactory.createAuditReport(null, null);
            //Calling the audit of respective fwk
            instanceFwk.audit(input, report, intentTypeName, initialPropertyName, uniqueIdentifier)
            return report
        } catch (e)
        {
            logger.info('Error Occured while Auditing with error: ' + e)
            throw new RuntimeException('Error Executing Intent: ' + e)
        }
    }
    this.navigateInstance = function (target) {
        let neId = new ParseTarget().getNeIdFromTarget(target);
        if (neId === "NSP")
        {
            logger.info('Device is managed by NFMP')
            return this.createNfmpInstance()
        }
        else
        {
            let managerName = mdtFwk.getManagerName(new ParseTarget().getNeIdFromTarget(target));
            logger.info('Device: ' + target + ' is managed by: ' + managerName);
            switch (managerName)
            {
                case 'NFM-P':
                    logger.info('Device is managed by NFMP')
                    return this.createNfmpInstance()
                    break;
                default:
                    logger.info('Device is not managed')
                    throw new RuntimeException('Device is not Managed')
            }
        }
        return ''
    }
    this.createNfmpInstance = function () {
        return new NfmpConfig()
    }
}
