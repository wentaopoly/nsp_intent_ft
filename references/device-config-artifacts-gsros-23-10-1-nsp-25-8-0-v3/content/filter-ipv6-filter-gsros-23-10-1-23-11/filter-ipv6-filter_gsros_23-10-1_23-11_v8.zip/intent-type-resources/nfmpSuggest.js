load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {
    this.getFilterName = function (neId, filterId) {
        var className = "aclfilter.Ipv6Filter";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "filterName",
                    "id"
                ]
            }
        };
        if (filterId) {
            var policyFilter = {};
            policyFilter["name"] = "id";
            policyFilter["value"] = filterId;
            searchObject["filter"]["and"]["equal"].push(policyFilter);
        }
        logger.info(LOG_PREFIX + "final search object = {}", searchObject);
        return this.getData(neId, searchObject, "filterName", filterId);
    }

    this.getFilterId = function (neId, filterName) {
        var className = "aclfilter.Ipv6Filter";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "filterName",
                    "id"
                ]
            }
        };
        if (filterName) {
            var policyFilter = {};
            policyFilter["name"] = "filterName";
            policyFilter["value"] = filterName;
            searchObject["filter"]["and"]["equal"].push(policyFilter);
        }
        return this.getData(neId, searchObject, "id", filterName);
    }

    this.getData = function (target, searchObjectJson, type, filterPolicyAttribute) {
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.find(target, searchObjectJson);
        logger.info(LOG_PREFIX + resultFetch.response);
        var finalResponse = JSON.parse(resultFetch.response)["aclfilter.Ipv6Filter"];
        logger.info(LOG_PREFIX + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                if (filterPolicyAttribute) {
                    logger.info(LOG_PREFIX + "Filter Selected = {}", filterPolicyAttribute);
                    logger.info(LOG_PREFIX + "Device policy = {}", finalResponse[index][type]);
                    ret.push(finalResponse[index][type]);
                    break;
                }
                else {
                    ret.push(finalResponse[index][type]);
                }
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "result = \n" + JSON.stringify(ret));
        return ret;
    }
    this.getFilterLog = function (neId) {
        var searchObjectJson = {
            "fullClassName": "nodelog.FilterLog",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        return this.getSuggestData(searchObjectJson, "nodelog.FilterLog", "id");
    }

    this.getSampleProfile = function (neId) {
        var searchObjectJson = {
            "fullClassName": "cflowd.CflowdSampleProfile",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "profileId"
                ]
            }
        };
        return this.getSuggestData(searchObjectJson, "cflowd.CflowdSampleProfile", "profileId");
    }

    this.getEmbedFilter = function(neId) {
      var searchObject = {
            "fullClassName": "aclfilter.Ipv6Filter",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "filterName",
                    "scope"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        return this.getSuggestEmbedFilterData(searchObject, "aclfilter.Ipv6Filter", "filterName");
    }

    this.getSuggestEmbedFilterData = function (searchObjectJson, searchClass, propertyName)
    {

        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        logger.info("RESULT FETCH : " + JSON.stringify(resultFetch));
        var finalResponse = JSON.parse(resultFetch.response);
        finalResponse = finalResponse[searchClass];

        if (Object.keys(finalResponse).length !== 0)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            logger.info("1234 : " + JSON.stringify(finalResponse));
            finalResponse.forEach(function (value, index, array) {
                if(value["scope"] == "embedded") {
                  logger.info("VALUE : " + value);
                  logger.info("PROPERTY NAME : " + propertyName);
                  logger.info("value[propertyName]" + value[propertyName]);
                  ret.push(value[propertyName]);
                }
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

    this.getPrefixList = function (neId) {
        var searchObjectJson = {
            "fullClassName": "filterprefixlist.PrefixList",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "prefixListType",
                            "value": "ipv6"
                        },
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getSuggestData(searchObjectJson, "filterprefixlist.PrefixList", "displayedName");
    }

    this.getPortList = function (neId) {
        var searchObjectJson = {
            "fullClassName": "filterprefixlist.PortList",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getSuggestData(searchObjectJson, "filterprefixlist.PortList", "displayedName");
    }

    this.getGreTunnel = function (neId) {
        var searchObjectJson = {
            "fullClassName": "aclfilter.GreTunnelTemplate",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getSuggestData(searchObjectJson, "aclfilter.GreTunnelTemplate", "displayedName");
    }


    this.getRoutingInstances = function (neId) {
        var searchObjectJson = {
            "fullClassName": "vprn.Site",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        var routingInstances = this.getSuggestData(searchObjectJson, "vprn.Site", "displayedName");
        var index = routingInstances.indexOf("_tmnx_InternalEsaVprn");

        if (index !== -1) {
            // Remove the string at the found index
            routingInstances.splice(index, 1);
        }
        routingInstances.push("Base");
        return routingInstances;
    }

    this.getVPRNServices = function (neId) {
        var searchObjectJson = {
            "fullClassName": "vprn.Site",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };

        var vprns = this.getSuggestData(searchObjectJson, "vprn.Site", "displayedName");
        var index = vprns.indexOf("_tmnx_InternalEsaVprn");

        if (index !== -1) {
            // Remove the string at the found index
            vprns.splice(index, 1);
        }
        return vprns;
    }

    this.getVPRNServiceFullName = function (neId, vprnName) {
        var searchObjectJson = {
            "fullClassName": "vprn.Site",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "displayedName",
                            "value": vprnName
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "objectFullName"
                ]
            }
        };

        var vprnFullName = this.getSuggestData(searchObjectJson, "vprn.Site", "objectFullName");
        var vprnService = "";
        if(vprnFullName.length > 0)
        {
            vprnService = vprnFullName[0];
            if(vprnService)
            {
                vprnService = vprnService.replace(":"+ neId, "");
            }
        }
        else
        {
            throw new RuntimeException("Unable to find VPRN service " + vprnName + "on NE " + neId);
        }

        return vprnService;
    }

    this.getVPRNServiceName = function (neId, vprnFullName) {
        var searchObjectJson = {
            "fullClassName": "vprn.Site",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "objectFullName",
                            "value": vprnFullName+":"+neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };

        var vprnNames = this.getSuggestData(searchObjectJson, "vprn.Site", "displayedName");
        var vprnService = "";
        if(vprnNames.length > 0)
        {
            vprnService = vprnNames[0];

        }
        else
        {
            logger.info("Unable to find VPRN service " + vprnFullName + "on NE " + neId);
        }

        return vprnService;
    }

    this.getVPLSServices = function (neId) {
        var searchObjectJson = {
            "fullClassName": "vpls.Site",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        var vplsServices = this.getSuggestData(searchObjectJson, "vpls.Site", "displayedName");
        var index = vplsServices.indexOf("_tmnx_InternalEsaVpls");

        if (index !== -1) {
            // Remove the string at the found index
            vplsServices.splice(index, 1);
        }
        return vplsServices;
    }

    this.getVPLSServicesFullName = function (neId, vplsName) {
        var searchObjectJson = {
            "fullClassName": "vpls.Site",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "displayedName",
                            "value": vplsName
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "objectFullName"
                ]
            }
        };
        var vplsServices = this.getSuggestData(searchObjectJson, "vpls.Site", "objectFullName");
        var vplsService = "";
        if(vplsServices.length > 0)
        {
            vplsService = vplsServices[0];
            if(vplsService)
            {
                vplsService = vplsService.replace(":"+ neId, "");
            }
        }
        else
        {
            throw new RuntimeException("Unable to find VPLS service " + vplsName + "on NE " + neId);
        }

        return vplsService;
    }

    this.getVPLSName = function (neId, vplsFullName) {
        var searchObjectJson = {
            "fullClassName": "vpls.Site",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "objectFullName",
                            "value": vplsFullName+":"+neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        var vplsServices = this.getSuggestData(searchObjectJson, "vpls.Site", "displayedName");
        var vplsService = "";
        if(vplsServices.length > 0)
        {
            vplsService = vplsServices[0];
        }
        else
        {
            logger.info("Unable to find VPLS service " + vplsFullName + "on NE " + neId);
        }

        return vplsService;
    }

    this.getLSPs = function (neId) {
        var searchObjectJson = {
            "fullClassName": "mpls.Lsp",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "sourceIpAddress",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getLspData(searchObjectJson,"displayedName");
    }

    this.getLSPFullName = function (neId, lspName) {
        var searchObjectJson = {
            "fullClassName": "mpls.Lsp",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "sourceIpAddress",
                            "value": neId
                        },
                        {
                            "name": "displayedName",
                            "value": lspName
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "objectFullName"
                ]
            }
        };
        var lspFullNames = this.getLspData(searchObjectJson,"objectFullName");
        var lspFullName = "";
        if(lspFullNames.length > 0)
        {
            lspFullName = lspFullNames[0]
        }
        else
        {
            throw new RuntimeException("Unable to find LSP " + lspName + "on NE " + neId);
        }
        return lspFullName;
    }

    this.getLSPName = function (neId, lspObjFullName) {
        var searchObjectJson = {
            "fullClassName": "mpls.Lsp",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "sourceIpAddress",
                            "value": neId
                        },
                        {
                            "name": "objectFullName",
                            "value": lspObjFullName
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        var lspFullNames = this.getLspData(searchObjectJson,"displayedName");
        var lspFullName = "";
        if(lspFullNames.length > 0)
        {
            lspFullName = lspFullNames[0]
        }
        else
        {
            logger.info("Unable to find LSP " + lspObjFullName + "on NE " + neId);
        }
        return lspFullName;
    }

    this.getSuggestData = function (searchObjectJson, searchClass, propertyName)
    {

        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        finalResponse = finalResponse[searchClass];

        if (Object.keys(finalResponse).length !== 0)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            finalResponse.forEach(function (value, index, array) {
                ret.push(value[propertyName]);
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

    this.getLspData = function (searchObjectJson, propertyName)
    {

        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse))
        {
            finalResponse = [finalResponse];
        }
        finalResponse = finalResponse[0];

        for(var lspTypes in finalResponse)
        {
            if(finalResponse[lspTypes])
            {
                var lspObj = finalResponse[lspTypes];
                if (Object.keys(lspObj).length !== 0)
                {
                    if (!Array.isArray(lspObj))
                    {
                        lspObj = [lspObj];
                    }
                    lspObj.forEach(function (value, index, array) {
                        ret.push(value[propertyName]);
                    })
                }
            }
        }

        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }
}
