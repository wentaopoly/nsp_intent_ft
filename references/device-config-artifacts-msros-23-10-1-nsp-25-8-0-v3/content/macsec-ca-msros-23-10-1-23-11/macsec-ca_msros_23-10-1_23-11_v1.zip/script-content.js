var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('mdSuggest.js'), name: 'MdSuggest'})

var intentTypeName = 'macsec-ca_msros_23-10-1_23-11';

// example port, sap-ingress etc..
var initialPropertyName = 'connectivity-association';


// unique identifier
var uniqueIdentifier = 'ca-name';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/macsec';

function synchronize(input) {
    logger.info('Intent Synchronisation started')
    return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started')
    return NspIntentHelper.audit(target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function suggestCaName(context) {
    logger.info("suggestCaName context = \n" + context);
    var neId = getNeId(context);
    return new MdSuggest().getCaName(neId);
}

function getNeId(context) {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    logger.info(target)
    if (target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    logger.info("NeId : " + neId);
    return neId;
}

function getTargetData(input) {
    logger.info("getTargetData input for brownfield = \n" + input);
    var target = input.target;
    var config = null;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info(JSON.stringify(deviceConfig));
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}

