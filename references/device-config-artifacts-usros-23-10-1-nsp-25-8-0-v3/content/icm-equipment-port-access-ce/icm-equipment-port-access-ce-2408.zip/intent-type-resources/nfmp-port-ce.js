var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpPort() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    let nfmpFwk = new NfmpFwk();
    var savedObjects;
    var currentObjects;
    var isAudit = false;

    this.synchronize = function(input, result,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {
        // setting up topology
        var savedTopology = input.getCurrentTopology();
        logger.info("Saved Topology = "+savedTopology);
        savedObjects = {};
        currentObjects = {};
        //loading the saved objects from topology
        this.loadSavedObjectsFromTopology(savedTopology);
        var parseTarget = new ParseTarget();
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        logger.info("Target device = " + target);
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());
        logger.info("Target port = " + intentConfig[uniqueIdentifier]);
        intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        logger.info("Configuration to be pushed = "+JSON.stringify(intentConfig));

        if (input.getNetworkState().name() == "delete"){
            return this.syncDelete(target,intentConfig[uniqueIdentifier],result);
        }

        this.createOrModify(target,intentConfig[uniqueIdentifier],intentConfig);
        var currentTopo = this.loadCurrentObjectsToTopology(target);

        return util.setSuccessResult(result,currentTopo);
    };

    this.audit = function(target, config, svcTopo, adminState, auditReport,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {
        var savedTopology = svcTopo;
        currentObjects = {};
        var parseTarget = new ParseTarget();
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        var target = parseTarget.getNeIdFromTarget(target);
        logger.info("Target device = " + target);
        logger.info("Target port = " + intentConfig[uniqueIdentifier]);
        intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        logger.info("auditing configuration = "+JSON.stringify(intentConfig));
        isAudit = true;

        if(intentConfig){
            this.auditAndCompare(target,intentConfig[uniqueIdentifier],intentConfig,auditReport);
        }else{
            throw "configuration not available in the intent";
        }

        return auditReport;
    };

    this.createOrModify = function(target,portId,intentConfig){

        // port level attributes
        var result = this.portLevel(target,portId,intentConfig);

        // removing the delete objects
        this.deleteRemovedObjects(target);

        return result;
    };

    this.auditAndCompare = function(target,portId,intentConfig,auditReport){
        // port level attributes
        var portLevelPayload = this.portLevel(target,portId,intentConfig,"audit",auditReport);
        var result = this.auditRequest(target, portLevelPayload);
        result = this.auditTimeSlotBits(target,portId,intentConfig,result);
        auditReport = util.reportMisaligned(target, result,auditReport);

        return auditReport;
    };

    this.portLevel = function(target,portId,intentConfig){
        var properties = {};
        var fullClassName = "equipment.PhysicalPort";                    // full class name for port
        var portLevelFdn = util.getBaseFdnForPort(target,portId);        // portlevel attributes fdn
        var objectFullName = portLevelFdn;                               // objectFullName is same as fdn for port level

        (intentConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";
        if (intentConfig["description"]){
            properties["description"] = intentConfig["description"];
        }

        if(!isAudit){
            var portLevelPayload = util.editPayload(portLevelFdn,properties,null,fullClassName,objectFullName);
            var result = this.modifyRequest(target, portLevelPayload);
            this.createDS1E1PortSpecifics(target,intentConfig,portLevelFdn);
            //creating DS1E1 Channel
            if(intentConfig["ds1e1Channel"]){
                this.createDS1E1Channel(target,intentConfig,portLevelFdn);
            }
        }else{
            var childProperties = [];
            //child-1 : DS1E1PortSpecifics
            var ds1e1PortSpecificsPayload = this.createDS1E1PortSpecifics(target,intentConfig,portLevelFdn);
            childProperties.push(ds1e1PortSpecificsPayload);

            //child-2 : DS1E1 Channel
            if(intentConfig["ds1e1Channel"]){
                var ds1e1ChannelPayload = this.createDS1E1Channel(target,intentConfig,portLevelFdn);
                childProperties.push(ds1e1ChannelPayload);
            }
            var portLevelPayload = util.editPayload(portLevelFdn,properties,childProperties,fullClassName,objectFullName);
            return portLevelPayload;
        }
    };

    this.createDS1E1PortSpecifics = function(target,intentConfig,portLevelFdn){
        var fullClassName = "tdmequipment.DS1E1PortSpecifics";
        var ds1e1PortSpecificsFdn = portLevelFdn +":ds1e1Port";
        var objectFullName = ds1e1PortSpecificsFdn;
        var properties = {};

        properties["ds1PortType"] = intentConfig["port-type"];

        if(!isAudit){
            var ds1e1PortSpecificsPayload = util.editPayload(portLevelFdn,properties,null,fullClassName,objectFullName);
            var result = this.modifyRequest(target, ds1e1PortSpecificsPayload);
        }else{
            return this.createChildObjectPayload(fullClassName,null,properties);
        }
    };

    this.createDS1E1Channel = function(target,intentConfig,portLevelFdn){
        var fullClassName = "tdmequipment.DS1E1Channel";
        var ds1e1ChannelConfig = intentConfig["ds1e1Channel"];
        var ds1e1ChannelFdn = portLevelFdn +":ds1e1-1";
        var objectFullName = ds1e1ChannelFdn;
        var properties = {};


        if(!isAudit){
            if (intentConfig["port-type"] == "ds1"){
                properties["portChannelType"] = "pdhDs1";
            }else{
                properties["portChannelType"] = "pdhE1";
            }
            properties["displayedLocalChannelId"] = "1";
        }
        (ds1e1ChannelConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";

        if(!isAudit){
            var ds1e1ChannelPayload = util.editPayload(portLevelFdn,properties,null,fullClassName,objectFullName);
            var result = this.modifyRequest(target, ds1e1ChannelPayload);
            this.createDS1E1ChannelSpecifics(target,intentConfig,ds1e1ChannelFdn);
            properties={};
            var childProperties = [];
            if(intentConfig["ds1e1Channel"]["ds0Channel-group"]){
                if(!Array.isArray(intentConfig["ds1e1Channel"]["ds0Channel-group"])){
                    intentConfig["ds1e1Channel"]["ds0Channel-group"] = [intentConfig["ds1e1Channel"]["ds0Channel-group"]];
                }
                for(var index in intentConfig["ds1e1Channel"]["ds0Channel-group"]){
                    var ds0ChannelGroupConfig = intentConfig["ds1e1Channel"]["ds0Channel-group"][index];
                    childProperties.push(this.createDS0ChannelGroup(target,ds0ChannelGroupConfig,ds1e1ChannelFdn));
                }
                ds1e1ChannelPayload = util.editPayload(portLevelFdn,properties,childProperties,fullClassName,objectFullName);
                result = this.modifyRequest(target, ds1e1ChannelPayload);

                childProperties = [];
                //when DS0Channel Group created, it comes up with Admin-state 'Down', setting Admin-state after creating DS0ChannelGroup
                for(var index in intentConfig["ds1e1Channel"]["ds0Channel-group"]){
                    var ds0ChannelGroupConfig = intentConfig["ds1e1Channel"]["ds0Channel-group"][index];
                    childProperties.push(this.setDS0ChannelGroupAdminState(target,ds0ChannelGroupConfig,ds1e1ChannelFdn));
                }
                ds1e1ChannelPayload = util.editPayload(portLevelFdn,properties,childProperties,fullClassName,objectFullName);
                result = this.modifyRequest(target, ds1e1ChannelPayload);
            }
        }else{
            var childProperties = [];
            //child-1 : DS1E1ChannelSpecifics
            var ds1e1ChannelSpecificsPayload = this.createDS1E1ChannelSpecifics(target,intentConfig,ds1e1ChannelFdn);
            childProperties.push(ds1e1ChannelSpecificsPayload);

            //child-2 : DS0ChannelGroups
            if(intentConfig["ds1e1Channel"]["ds0Channel-group"]){
                if(!Array.isArray(intentConfig["ds1e1Channel"]["ds0Channel-group"])){
                    intentConfig["ds1e1Channel"]["ds0Channel-group"] = [intentConfig["ds1e1Channel"]["ds0Channel-group"]];
                }
                for(var index in intentConfig["ds1e1Channel"]["ds0Channel-group"]){
                    var ds0ChannelGroupConfig = intentConfig["ds1e1Channel"]["ds0Channel-group"][index];


                    var ds0ChannelGroupPayload = this.createDS0ChannelGroup(target,ds0ChannelGroupConfig,ds1e1ChannelFdn);
                    childProperties.push(ds0ChannelGroupPayload);
                }
            }

            return this.createChildObjectPayload(fullClassName,childProperties,properties);
        }
    };

    this.createDS1E1ChannelSpecifics = function(target,intentConfig,ds1e1ChannelFdn){
        var fullClassName = "tdmequipment.DS1E1ChannelSpecifics";
        var ds1e1ChannelSpecificsConfig = intentConfig["ds1e1Channel"];
        var ds1e1ChannelSpecificsFdn = ds1e1ChannelFdn+":ds1e1Specs";
        var objectFullName = ds1e1ChannelSpecificsFdn;
        var properties = {};

        var nfmpDS1E1ChannelSpecifics = util.getIfObjectExists(fullClassName,objectFullName);
        //Checking DS1E1 Channel Specifics exits, it take some time for DS1E1 Channel To get created & come up.
        if(!isAudit && (nfmpDS1E1ChannelSpecifics === null || !(this.isDS1E1ChannelSpecificsReady(nfmpDS1E1ChannelSpecifics,intentConfig)))){
            logger.info("Adding 5 sec delay for DS1E1 Channel Specifics to get created.");
            util.delay(5000);
            nfmpDS1E1ChannelSpecifics = util.getIfObjectExists(fullClassName,objectFullName);
            if(nfmpDS1E1ChannelSpecifics === null|| !(this.isDS1E1ChannelSpecificsReady(nfmpDS1E1ChannelSpecifics,intentConfig))){
                throw new RuntimeException("DS1E1 Channel Specifics: "+objectFullName+" still does not exist.Try synchronize after some time.");
            }
        }

        if(ds1e1ChannelSpecificsConfig["channel-framing"])
        {
            properties["channelFraming"] = ds1e1ChannelSpecificsConfig["channel-framing"];
        }
        if(ds1e1ChannelSpecificsConfig["signal-mode-cas"])
        {
            properties["signalMode"] = "cas";
        }

        if(!isAudit){
            var ds1e1ChannelSpecificsPayload = util.editPayload(ds1e1ChannelFdn,properties,null,fullClassName,objectFullName);
            var result = this.modifyRequest(target, ds1e1ChannelSpecificsPayload);
        }else{
            return this.createChildObjectPayload(fullClassName,null,properties);
        }
    };

    this.isDS1E1ChannelSpecificsReady = function (DS1E1ChannelSpecificsObject, intentConfig) {
        var ds1e1ChannelSpecifics = DS1E1ChannelSpecificsObject[0];
        if (ds1e1ChannelSpecifics != null) {
            if (ds1e1ChannelSpecifics["properties"]["channelType"] == intentConfig["port-type"])
                return true
        }

        return false
    }

    this.createDS0ChannelGroup = function(target,ds0ChannelGroupConfig,ds1e1ChannelFdn){
        var fullClassName = "tdmequipment.DS0ChannelGroup";
        var ds0ChannelGroupFdn = ds1e1ChannelFdn+":ds0Grp-"+ds0ChannelGroupConfig["channel-group-id"];
        var objectFullName = ds0ChannelGroupFdn;
        var properties = {};

        if(!isAudit){
            properties["portChannelType"] = "pdhDs0Grp";
            properties["mode"] = "access";
        }

        properties["displayedLocalChannelId"] = ds0ChannelGroupConfig["channel-group-id"].toString();
        if( ds0ChannelGroupConfig["encap-type-cem"] ){
            properties["encapType"] = "cemEncap";
        }

        if(!isAudit){
            //keeping key and value same as object full name of the DS0ChannelGroup
            mapFwk.set(currentObjects,objectFullName,objectFullName);
        }else{
            (ds0ChannelGroupConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";
        }

        var childProperties = [];
        //child-1 : DS0ChannelGroupSpecifics
        var ds0ChannelGroupSpecificsPayload = this.createDS0ChannelGroupSpecifics(target,ds0ChannelGroupConfig,ds0ChannelGroupFdn);
        childProperties.push(ds0ChannelGroupSpecificsPayload);

        return this.createChildObjectPayload(fullClassName,childProperties,properties);
    };

    this.createDS0ChannelGroupSpecifics = function(target,ds0ChannelGroupConfig,ds0ChannelGroupFdn){
        var fullClassName = "tdmequipment.DS0ChannelGroupSpecifics";
        var ds0ChannelGroupSpecificsConfig = ds0ChannelGroupConfig;
        var ds0ChannelGroupSpecificsFdn = ds0ChannelGroupFdn+":ds0GrpSpecs";
        var objectFullName = ds0ChannelGroupSpecificsFdn;
        var properties = {};

        if(!isAudit){
            properties["scramble"] = false;
        }
        if (ds0ChannelGroupSpecificsConfig["timeslots"]){
            properties["timeSlotBits"] = util.getNfmpTimeSlotBits(ds0ChannelGroupSpecificsConfig["timeslots"]);
        }

        return this.createChildObjectPayload(fullClassName,null,properties);
    };

    this.setDS0ChannelGroupAdminState = function(target,ds0ChannelGroupConfig,ds1e1ChannelFdn){
        var fullClassName = "tdmequipment.DS0ChannelGroup";
        var ds0ChannelGroupFdn = ds1e1ChannelFdn+":ds0Grp-"+ds0ChannelGroupConfig["channel-group-id"];
        var objectFullName = ds0ChannelGroupFdn;
        var properties = {};

        properties["displayedLocalChannelId"] = ds0ChannelGroupConfig["channel-group-id"].toString();
        (ds0ChannelGroupConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";

        return this.createChildObjectPayload(fullClassName,null,properties);
    };

    this.createChildObjectPayload = function(fullClassName,childProperties,properties){

        var childObjectPayLoad = {};

        childObjectPayLoad['objectClassName'] = fullClassName;
        childObjectPayLoad['containedClassProperties'] = properties;
        if (!util.isEmpty(childProperties)){
            childObjectPayLoad['containmentInfo'] = childProperties;
        }

        return childObjectPayLoad;

    };

    this.auditRequest = function(target,payload){

        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }

        return result;

    };

    this.modifyRequest = function(target,payload){

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }

        return result;

    };

    this.syncDelete = function (target,portId,result) {

        var portLevelFdn = util.getBaseFdnForPort(target,portId);
        var objectFullName = portLevelFdn+":ds1e1-1";
        logger.info("Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success) {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }

        result.setSuccess(true);

    };

    this.xml2object = function(xmlElement) {

        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('Input JSON: '+ json)
        return JSON.parse(json);

    };

    this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }
            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }
            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }

    };

    this.loadCurrentObjectsToTopology = function(target) {

        var currentTopo = topologyFactory.createServiceTopology();
        if(Object.keys(currentObjects).length){
            for(var key in currentObjects){
                objectId = mapFwk.get(currentObjects,key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key,objectId,"INFRASTRUCTURE",target,""));
            }
        }

        return currentTopo;

    };

    this.loadSavedObjectsFromTopology = function(savedTopology) {

        if(savedTopology){
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0){
                topoObjects.forEach(function(topoObject){
                    mapFwk.set(savedObjects,topoObject.getObjectType(),topoObject.getObjectRelativeObjectID());
                });
            }
        }

    };

    this.deleteRemovedObjects = function(target) {

        if(Object.keys(savedObjects).length > 0){
            for(var key in savedObjects){
                var value = mapFwk.get(currentObjects,key);
                if(value == undefined || value =="undefined" || value == null) {
                    logger.info("To be Deleted " + key);
                    var objectFullName = key;
                    if (target && String(target).indexOf(':') !== -1) {
                        objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
                    }
                    var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

                    if (!deleteResult.success) {
                        throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
                    }
                }
            }
        }

    };

    this.auditTimeSlotBits = function(target,portId,intentConfig,result){
        var response = JSON.parse(result.response);

        if(intentConfig["ds1e1Channel"] && intentConfig["ds1e1Channel"]["ds0Channel-group"]){
            for (var index in intentConfig["ds1e1Channel"]["ds0Channel-group"]){
                var intentDS0ChannelGroup = intentConfig["ds1e1Channel"]["ds0Channel-group"][index];
                var objectFullName = util.getBaseFdnForPort(target,portId)+":ds1e1-1:ds0Grp-"+intentDS0ChannelGroup["channel-group-id"]+":ds0GrpSpecs";
                var ds0ChannelGroupSpecifics = util.getIfObjectExists("tdmequipment.DS0ChannelGroupSpecifics", objectFullName);
                var intentTimeSlot = util.getNfmpTimeSlotBits(intentDS0ChannelGroup["timeslots"]);
                if(ds0ChannelGroupSpecifics !=null){
                    var timeSlotBits = (ds0ChannelGroupSpecifics[0]["properties"]["timeSlotBits"]==="") ? [] : ds0ChannelGroupSpecifics[0]["properties"]["timeSlotBits"];
                    var compareResult = util.compareTimeSlots(intentTimeSlot,timeSlotBits);
                    if ( !compareResult ){
                        var misalignedTimeSlot={};
                        misalignedTimeSlot["actual"] = timeSlotBits;
                        misalignedTimeSlot["expected"] = intentTimeSlot;
                        misalignedTimeSlot["name"] = "tdmequipment.DS0ChannelGroupSpecifics|"+objectFullName+"|timeSlotBits";
                        if(!util.isContiansInResponse(response["misalignedAttributes"], misalignedTimeSlot)){
                            response["misalignedAttributes"].push(misalignedTimeSlot);
                            response["aligned"] = false;
                        }
                    }
                }
            }
        }

        result.response = JSON.stringify(response);
        var msg = "Deployment to NFM-P for device "+target+" was successful, got response "+JSON.stringify(response);
        result.msg = msg;
        return result;
    };

}


