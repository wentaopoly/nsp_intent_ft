var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpPort() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    let nfmpFwk = new NfmpFwk();
    var savedObjects;
    var currentObjects;
    var isAudit = false;
    var isDataChannelFramed = false;

    this.synchronize = function(input, result,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {
        // setting up topology
        var savedTopology = input.getCurrentTopology();
        logger.info("Saved Topology = "+savedTopology);
        savedObjects = {};
        currentObjects = {};
        //loading the saved objects from topology
        this.loadSavedObjectsFromTopology(savedTopology);
        var parseTarget = new ParseTarget();
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        logger.info("Target device = " + target);
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());
        logger.info("Target port = " + intentConfig[uniqueIdentifier]);
        intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        logger.info("Configuration to be pushed = "+JSON.stringify(intentConfig));

        if (input.getNetworkState().name() == "delete"){
            return this.syncDelete(target,intentConfig[uniqueIdentifier],result);
        }

        this.createOrModify(target,intentConfig[uniqueIdentifier],intentConfig);
        var currentTopo = this.loadCurrentObjectsToTopology(target);

        return util.setSuccessResult(result,currentTopo);
    }

    this.audit = function(target, config, svcTopo, adminState, auditReport,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {
        var savedTopology = svcTopo;
        currentObjects = {};
        var parseTarget = new ParseTarget();
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        var target = parseTarget.getNeIdFromTarget(target);
        logger.info("Target device = " + target);
        logger.info("Target port = " + intentConfig[uniqueIdentifier]);
        intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        logger.info("auditing configuration = "+JSON.stringify(intentConfig));
        isAudit = true;

        if(intentConfig){
            this.auditAndCompare(target,intentConfig[uniqueIdentifier],intentConfig,auditReport);
        }else{
            throw "configuration not available in the intent";
        }

        return auditReport;
    }

    this.createOrModify = function(target,portId,intentConfig){

        // port level attributes
        var result = this.portLevel(target,portId,intentConfig);

        // removing the delete objects
        this.deleteRemovedObjects(target);

        return result;
    }

    this.auditAndCompare = function(target,portId,intentConfig,auditReport){

        // port level attributes
        var portLevelPayload = this.portLevel(target,portId,intentConfig);
        var result = this.auditRequest(target, portLevelPayload);
        result = this.auditTimeSlotBits(target,portId,intentConfig,result);
        auditReport = util.reportMisaligned(target, result,auditReport);

        return auditReport;
    }

    this.portLevel = function(target,portId,intentConfig){

        var properties = {};
        var fullClassName = "equipment.PhysicalPort";                    // full class name for port
        var portLevelFdn = util.getBaseFdnForPort(target,portId);        // portlevel attributes fdn
        if (target && String(target).indexOf(':') !== -1) {
            portLevelFdn = util.modifyNeIdForIpV6(portLevelFdn, target);
        }
        var objectFullName = portLevelFdn;                               // objectFullName is same as fdn for port level

        (intentConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";
        if (intentConfig["description"]){
            properties["description"] = intentConfig["description"];
        }

        if(!isAudit){
            var portLevelPayload = util.editPayload(portLevelFdn,properties,null,fullClassName,objectFullName);
            var result = this.modifyRequest(target, portLevelPayload);
            //creating Data Channel
            if(intentConfig["dataChannel"]){
                this.createDataChannel(target,intentConfig,portLevelFdn);
            }
        }else{
            var childProperties = [];
            if(intentConfig["dataChannel"]){
                var dataChannelPayload = this.createDataChannel(target,intentConfig,portLevelFdn);
                childProperties.push(dataChannelPayload);
            }
            var portLevelPayload = util.editPayload(portLevelFdn,properties,childProperties,fullClassName,objectFullName);
            return portLevelPayload;
        }
    }

    this.createDataChannel = function(target,intentConfig,portLevelFdn){
        var fullClassName = "tdmequipment.DataChannel";
        var dataChannelConfig = intentConfig["dataChannel"];
        var dataChannelFdn = portLevelFdn+":data-1";
        var objectFullName = dataChannelFdn;
        var properties = {};

        (dataChannelConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";
        if (!isAudit){
            properties["portChannelType"] = "tdmTpif";
            properties["displayedLocalChannelId"] = "1";
        }

        if(!isAudit){
            var dataChannelPayload = util.editPayload(portLevelFdn,properties,null,fullClassName,objectFullName);
            var result = this.modifyRequest(target, dataChannelPayload);
            this.createDataChannelSpecifics(target,intentConfig,dataChannelFdn);
            if(intentConfig["dataChannel"]["ds0Channel-group"]){
                this.createDs0ChannelGroup(target,intentConfig,dataChannelFdn);
            }
        }else{
            var childProperties = [];
            //child-1 : DataChannelSpecifics
            var dataChannelSpecificsPayload = this.createDataChannelSpecifics(target,intentConfig,dataChannelFdn);
            childProperties.push(dataChannelSpecificsPayload);

            //child-2 : DS0ChannelGroup
            if(intentConfig["dataChannel"]["ds0Channel-group"]){
                var ds0ChannelGroupPayload = this.createDs0ChannelGroup(target,intentConfig,dataChannelFdn);
                childProperties.push(ds0ChannelGroupPayload);
            }

            return this.createChildObjectPayload(fullClassName,childProperties,properties);
        }
    }

    this.createDataChannelSpecifics = function(target,intentConfig,dataChannelFdn){
        var fullClassName = "tdmequipment.DataChannelSpecifics";
        var dataChannelSpecificsConfig = intentConfig["dataChannel"];
        var dataChannelSpecificsFdn = dataChannelFdn+":dataSpec";
        var objectFullName = dataChannelSpecificsFdn;
        var properties = {};

        //Checking Data Channel Specifics exits, it take some time for data Channel To get created.
        if(!isAudit && !util.isObjectExists(target,fullClassName,objectFullName)){
            logger.info("Adding 5 sec delay for Data Channel Specifics to get created.");
            util.delay(5000);
            if(!util.isObjectExists(target,fullClassName,objectFullName)){
                throw new RuntimeException("Data Channel Specifics: "+objectFullName+"does not exist.Try Synchronize after some time.");
            }
        }

        if(dataChannelSpecificsConfig["framing"])
        {
            properties["dataFraming"] = dataChannelSpecificsConfig["framing"];
            if(dataChannelSpecificsConfig["framing"] == "framed"){
                isDataChannelFramed = true;
            }
        }


        if(!isAudit){
            var dataChannelSpecificsPayload = util.editPayload(dataChannelFdn,properties,null,fullClassName,objectFullName);
            var result = this.modifyRequest(target, dataChannelSpecificsPayload);
        }else{
            return this.createChildObjectPayload(fullClassName,null,properties);
        }
    }

    this.createDs0ChannelGroup = function(target,intentConfig,dataChannelFdn){
        var fullClassName = "tdmequipment.DS0ChannelGroup";
        var ds0ChannelGroupConfig = intentConfig["dataChannel"]["ds0Channel-group"];
        var ds0ChannelGroupFdn = dataChannelFdn+":ds0Grp-1";
        var objectFullName = ds0ChannelGroupFdn;
        var properties = {};

        if(ds0ChannelGroupConfig["channel-group-id"]){
            properties["displayedLocalChannelId"] = "1";
        }
        if(!isAudit){
            properties["portChannelType"] = "pdhDs0Grp";
            properties["mode"] = "access";
            properties["encapType"] = "cemEncap";
        }


        if(!isAudit){
            //keeping key and value same as object full name of the DS0ChannelGroup
            mapFwk.set(currentObjects,objectFullName,objectFullName);
            var ds0ChannelGroupPayload = util.editPayload(dataChannelFdn,properties,null,fullClassName,objectFullName);
            var result = this.modifyRequest(target, ds0ChannelGroupPayload);
            this.createDS0ChannelGroupSpecifics(target,intentConfig,ds0ChannelGroupFdn);
            properties = {};
            (ds0ChannelGroupConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";
            if(!isAudit){
                var ds0ChannelGroupPayload = util.editPayload(dataChannelFdn,properties,null,fullClassName,objectFullName);
                var result = this.modifyRequest(target, ds0ChannelGroupPayload);
            }
        }else{
            (ds0ChannelGroupConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";

            var childProperties = [];
            //child-1 : DS0ChannelGroupSpecifics
            var ds0ChannelGroupSpecificsPayload = this.createDS0ChannelGroupSpecifics(target,intentConfig,ds0ChannelGroupFdn);
            childProperties.push(ds0ChannelGroupSpecificsPayload);

            return this.createChildObjectPayload(fullClassName,childProperties,properties);
        }
    }

    this.createDS0ChannelGroupSpecifics = function(target,intentConfig,ds0ChannelGroupFdn){
        var fullClassName = "tdmequipment.DS0ChannelGroupSpecifics";
        var ds0ChannelGroupSpecificsConfig = intentConfig["dataChannel"]["ds0Channel-group"];
        var ds0ChannelGroupSpecificsFdn = ds0ChannelGroupFdn+":ds0GrpSpecs";
        var objectFullName = ds0ChannelGroupSpecificsFdn;
        var properties = {};

        //Checking DS0 Channel Group Specifics exits, it take some time for DS0 Channel Group To get created.
        if(!isAudit && !util.isObjectExists(target,fullClassName,objectFullName)){
            logger.info("Adding 5 sec delay for DS0 Channel Group Specifics to get created.");
            util.delay(5000);
            if(!util.isObjectExists(target,fullClassName,objectFullName)){
                throw new RuntimeException("DS0 Channel Group Specifics: "+objectFullName+"does not exist.Try Synchronize after some time.");
            }
        }

        if (ds0ChannelGroupSpecificsConfig["timeslots"]){
            properties["timeSlotBits"] = util.getTimeSlotBits(ds0ChannelGroupSpecificsConfig["timeslots"],isDataChannelFramed,isAudit);
        }


        if(!isAudit){
            var ds0ChannelGroupSpecificsPayload = util.editPayload(ds0ChannelGroupFdn,properties,null,fullClassName,objectFullName);
            var result = this.modifyRequest(target, ds0ChannelGroupSpecificsPayload);
        }else{
            return this.createChildObjectPayload(fullClassName,null,properties);
        }
    }

    this.createChildObjectPayload = function(fullClassName,childProperties,properties){

        var childObjectPayLoad = {};

        childObjectPayLoad['objectClassName'] = fullClassName;
        childObjectPayLoad['containedClassProperties'] = properties;
        if (!util.isEmpty(childProperties)){
            childObjectPayLoad['containmentInfo'] = childProperties;
        }

        return childObjectPayLoad;
    }

    this.auditRequest = function(target,payload){
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }

        return result;
    }

    this.modifyRequest = function(target,payload){
        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }

        return result;
    }

    this.syncDelete = function (target,portId,result) {

        var portLevelFdn = util.getBaseFdnForPort(target,portId);
        if (target && String(target).indexOf(':') !== -1) {
            portLevelFdn = util.modifyNeIdForIpV6(portLevelFdn, target);
        }
        var objectFullName = portLevelFdn+":data-1";
        logger.info("Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success) {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }

        result.setSuccess(true);
    }

    this.xml2object = function(xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('Input JSON: '+ json)
        return JSON.parse(json);
    }

    this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }
            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }
            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }

    this.loadCurrentObjectsToTopology = function(target) {
        var currentTopo = topologyFactory.createServiceTopology();
        if(Object.keys(currentObjects).length){
            for(var key in currentObjects){
                objectId = mapFwk.get(currentObjects,key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key,objectId,"INFRASTRUCTURE",target,""));
            }
        }
        return currentTopo;
    }

    this.loadSavedObjectsFromTopology = function(savedTopology) {
        if(savedTopology){
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0){
                topoObjects.forEach(function(topoObject){
                    mapFwk.set(savedObjects,topoObject.getObjectType(),topoObject.getObjectRelativeObjectID());
                });
            }
        }
    }

    this.deleteRemovedObjects = function(target) {
        if(Object.keys(savedObjects).length > 0){
            for(var key in savedObjects){
                var value = mapFwk.get(currentObjects,key);
                if(value == undefined || value =="undefined" || value == null) {
                    logger.info("To be Deleted " + key);
                    var objectFullName = key;
                    var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

                    if (!deleteResult.success) {
                        throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
                    }
                }
            }
        }
    };

    this.auditTimeSlotBits = function(target,portId,intentConfig,result){
        var response = JSON.parse(result.response);
        var isMisalignedTimeslotPresent = false;
        var objectFullName = ""
        for (var index in response["misalignedAttributes"]){
            var misalignedAttribute = response["misalignedAttributes"][index];
            var attributeName = misalignedAttribute["name"].split("|")[2];
            if (attributeName === "timeSlotBits"){
                isMisalignedTimeslotPresent = true;
            }
        }
        if(!isMisalignedTimeslotPresent){
            if(intentConfig["dataChannel"] && intentConfig["dataChannel"]["ds0Channel-group"] && intentConfig["dataChannel"]["ds0Channel-group"]["timeslots"]){
                var objectFullName=util.getBaseFdnForPort(target,portId)+":data-1:ds0Grp-1:ds0GrpSpecs";
                var ds0ChannelGroupSpecifics = util.getIfObjectExists("tdmequipment.DS0ChannelGroupSpecifics", objectFullName);
                var intentTimeSlot = util.getTimeSlotBits(intentConfig["dataChannel"]["ds0Channel-group"]["timeslots"],isDataChannelFramed,true);
                if(ds0ChannelGroupSpecifics != null){
                    var timeSlotBits=ds0ChannelGroupSpecifics[0]["properties"]["timeSlotBits"];
                    var compareResult = util.compareTimeSlots(intentTimeSlot,timeSlotBits);
                    if ( !compareResult ){
                        var misalignedTimeSlot={};
                        misalignedTimeSlot["actual"] = timeSlotBits;
                        misalignedTimeSlot["expected"] = intentTimeSlot;
                        misalignedTimeSlot["name"] = "tdmequipment.DS0ChannelGroupSpecifics|"+objectFullName+"|timeSlotBits";
                        response["misalignedAttributes"].push(misalignedTimeSlot);
                        response["aligned"] = false;
                    }
                }
            }
        }
        result.response = JSON.stringify(response);
        var msg = "Deployment to NFM-P for device "+target+" was successful, got response "+JSON.stringify(response);
        result.msg = msg;
        return result;
    };
}
