var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpTiming() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        logger.info("input = \n" + input + "-------" + result + "-------" + intentTypeName + "-------" + initialPropertyName + "-------" + uniqueIdentifier);
        // code to handle delete
        if (input.getNetworkState().name() == "delete")
        {
            result.setSuccess(true);
            return result;
        }
        // code to handle sync
        var savedTopology = input.getCurrentTopology();
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        this.createOrModify(neId, intentConfig);
        return util.setSuccessResult(result, savedTopology);
    }
    this.audit = function (target, config, svcTopo, adminState, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        logger.info("audit");
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        var neId = parseTarget.getNeIdFromTarget(target);
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        if (intentConfig)
        {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }

        return auditReport
    }
    this.auditAndCompare = function (neId, intentConfig, auditReport) {
        var timingPayLoad = this.createTimingPayLoad(neId, intentConfig);
        var result = this.auditRequest(neId, timingPayLoad);
        auditReport = util.reportMisaligned(neId, result, auditReport);
        return auditReport;
    }
    this.auditRequest = function (neId, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }
    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('input json: ' + json)
        return JSON.parse(json);
    }

    this.createOrModify = function (neId, intentConfig) {
        var timingPayLoad = this.createTimingPayLoad(neId, intentConfig);
        var result = this.modifyRequest(neId, timingPayLoad);
        return result;
    }
    this.createTimingPayLoad = function (neId, intentConfig) {
        var fullClassName = "sonet.SiteSync";
        var fdn = "network:" + neId + ":shelf-1";
        fdn = util.modifyNeIdForIpV6(fdn, neId);
        var objectFullName = "network:" + neId + ":shelf-1:sync";
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        var properties = {};
        properties["minQualityLevel"] = util.qualityLevelEnumGreenField(intentConfig["ql-minimum"]);
        if (intentConfig["ql-selection"])
        {
            properties["qualityLevel"] = util.convertQualityLevelGreenField(intentConfig["ql-selection"]);
        }
        else
        {
            properties["qualityLevel"] = util.convertQualityLevelGreenField(false);
        }
        if (intentConfig["revert"])
        {
            properties["revertive"] = intentConfig["revert"].toString();
        }
        else
        {
            properties["revertive"] = "false";
        }
        if(intentConfig['wait-to-restore'])
        {
            properties["waitToRestore"] = intentConfig['wait-to-restore'];
        }
        else
        {
            properties["waitToRestore"] = 0;
        }
        if (intentConfig["ref-order"])
        {
            logger.info("ref-order=\n{}", JSON.stringify(intentConfig["ref-order"]));
            var refOrderIter = Object.keys(intentConfig["ref-order"]);
            for (var i = 0; i < refOrderIter.length; i++)
            {
                switch (refOrderIter[i])
                {
                    case "first":
                        properties["firstTimingReferenceInput"] = util.refOrderEnumGreenField(intentConfig["ref-order"]["first"]);
                        break;
                    case "second":
                        properties["secondTimingReferenceInput"] = util.refOrderEnumGreenField(intentConfig["ref-order"]["second"]);
                        break;
                    case "third":
                        properties["thirdTimingReferenceInput"] = util.refOrderEnumGreenField(intentConfig["ref-order"]["third"]);
                        break;
                    case "fourth":
                        properties["fourthTimingReferenceInput"] = util.refOrderEnumGreenField(intentConfig["ref-order"]["fourth"]);
                        break;
                    case "fifth":
                        properties["fifthTimingReferenceInput"] = util.refOrderEnumGreenField(intentConfig["ref-order"]["fifth"]);
                        break;
                    case "sixth":
                        properties["sixthTimingReferenceInput"] = util.refOrderEnumGreenField(intentConfig["ref-order"]["sixth"]);
                        break;
                }
            }
        }
        logger.info("NFMP properties after adding ref-order = " + JSON.stringify(properties));
        if (intentConfig["ref1"])
        {
            properties["firstTimingReferenceAdministrativeState"] = util.convertAdminStateGreenField(intentConfig["ref1"]["admin-state"]);
            properties["firstTimingReferenceQualityLevel"] = util.qualityLevelEnumGreenField(intentConfig["ref1"]["ql-override"]);
            if (intentConfig["ref1"]["source-port"])
            {
                properties["firstTimingReferencePortPointer"] = util.getBaseFdnForPort(neId, intentConfig["ref1"]["source-port"]);
            }
            else
            {
                properties["firstTimingReferencePortPointer"] = "";
            }
        }
        if (intentConfig["ref2"])
        {
            properties["secondTimingReferenceAdministrativeState"] = util.convertAdminStateGreenField(intentConfig["ref2"]["admin-state"]);
            properties["secondTimingReferenceQualityLevel"] = util.qualityLevelEnumGreenField(intentConfig["ref2"]["ql-override"]);
            if (intentConfig["ref2"]["source-port"])
            {
                properties["secondTimingReferencePortPointer"] = util.getBaseFdnForPort(neId, intentConfig["ref2"]["source-port"]);
            }
            else
            {
                properties["secondTimingReferencePortPointer"] = "";
            }
        }
        if (intentConfig["bits"])
        {
            properties["bitsInterfaceType"] = util.convertInterfaceTypeGreenField(intentConfig["bits"]["interface-type"]);
            properties["bitsQualityLevel"] = util.qualityLevelEnumGreenField(intentConfig["bits"]["ql-override"]);
            properties["saBit"] = intentConfig["bits"]["ssm-bit"];
            if (intentConfig["bits"]["input"])
            {
                properties["bitsAdministrativeState"] = util.convertAdminStateGreenField(intentConfig["bits"]["input"]["admin-state"]);
            }
            if (intentConfig["bits"]["output"])
            {
                properties["bitsOutputState"] = util.convertAdminStateGreenField(intentConfig["bits"]["output"]["admin-state"]);
                properties["bitslineLength"] = util.convertLineLengthGreenField(intentConfig["bits"]["output"]["line-length"]);
                properties["bitsOutQlMinimum"] = util.qualityLevelEnumGreenField(intentConfig["bits"]["output"]["ql-minimum"]);
                properties["bitsSource"] = util.convertOutputSourceGreenField(intentConfig["bits"]["output"]["source"]);
                properties["bitsOutSquelch"] = (intentConfig["bits"]["output"]["squelch"]).toString();
            }
        }
        if (intentConfig["ptp"])
        {
            properties["ptpAdministrativeState"] = util.convertAdminStateGreenField(intentConfig["ptp"]["admin-state"]);
            properties["ptpQualityLevel"] = util.qualityLevelEnumGreenField(intentConfig["ptp"]["ql-override"]);
        }
        if (intentConfig["synce"])
        {
            properties["syncEAdministrativeState"] = util.convertAdminStateGreenField(intentConfig["synce"]["admin-state"]);
            properties["syncEQualityLevel"] = util.qualityLevelEnumGreenField(intentConfig["synce"]["ql-override"]);
        }
        if (intentConfig["gnss"])
        {
            properties["gnssAdminStatus"] = util.convertAdminStateGreenField(intentConfig["gnss"]["admin-state"]);
            properties["gnssQltyLevel"] = util.qualityLevelEnumGreenField(intentConfig["gnss"]["ql-override"]);
        }
        var childProperties = [];
        var timingPayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
        return timingPayload;
    }
    this.modifyRequest = function (neId, payload) {
        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }
}
