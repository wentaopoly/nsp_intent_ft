function ModelDeviceMapping() {


    this.getMapping = function(type){
        switch(type){
            case "port":
                return this.getPortMapping();
            case "ds1e1PortSpecifics":
                return this.getDS1E1PortSpecificsMapping();
            case "ds1e1Channel":
                return this.getDS1E1ChannelMapping();
            case "ds1e1ChannelSpecifics":
                return this.getDS1E1ChannelSpecificsMapping();
            case "ds0Channel-group":
                return this.getDS0ChannelGroupMapping();
            case "ds0ChannelGroupSpecifics":
                return this.getDS0ChannelGroupSpecificsMapping();
            default:
                return this.getPortMapping();
        }
    }

    this.getPortMapping = function() {
        var mapping = {};
        mapping['port.admin-state'] = 'administrativeState';
        mapping['port.description'] = 'description';

        return mapping;
    }

    this.getDS1E1PortSpecificsMapping = function() {
        var mapping = {};
        mapping['port.port-type'] = 'ds1PortType';

        return mapping;
    }

    this.getDS1E1ChannelMapping = function() {
        var mapping = {};
        mapping['port.ds1e1Channel.admin-state'] = 'administrativeState';

        return mapping;
    }

    this.getDS1E1ChannelSpecificsMapping = function() {
        var mapping = {};
        mapping['port.ds1e1Channel.channel-framing'] = 'channelFraming';
        mapping['port.ds1e1Channel.signal-mode-cas'] = 'signalMode';

        return mapping;
    }

    this.getDS0ChannelGroupMapping = function() {
        var mapping = {};
        mapping['port.ds1e1Channel.ds0Channel-group.channel-group-id'] = 'displayedLocalChannelId';
        mapping['port.ds1e1Channel.ds0Channel-group.admin-state'] = 'administrativeState';
        mapping['port.ds1e1Channel.ds0Channel-group.encap-type-cem'] = 'encapType';

        return mapping;
    }

    this.getDS0ChannelGroupSpecificsMapping = function() {
        var mapping = {};
        mapping['port.ds1e1Channel.ds0Channel-group.timeslots'] = 'timeSlotBits';

        return mapping;
    }
}
