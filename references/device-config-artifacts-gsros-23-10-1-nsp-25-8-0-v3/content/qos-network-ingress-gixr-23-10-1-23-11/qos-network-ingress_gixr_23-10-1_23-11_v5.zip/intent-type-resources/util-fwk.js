load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {

  this.setSuccessResult = function (result, savedTopology) {
    result.setSuccess(true);
    if (savedTopology !== undefined) {
      result.setTopology(savedTopology);
    }
    return result;
  };

  this.reportMisaligned = function (target, result, auditReport) {
    var report = JSON.parse(result.response);
    if (!report.aligned) {
      for (var i = 0; i < report.misalignedAttributes.length; i++) {
        var attributeData = report.misalignedAttributes[i];
        if (attributeData.expected == "present") {
          //misaligned object
          var objectDn = attributeData.name;
          var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
          auditReport.addMisAlignedObject(misalignedObject);
        }
        else if (attributeData.expected == "not present") {
          //undesired object
          var objectDn = attributeData.name;
          var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
          auditReport.addMisAlignedObject(misalignedObject);
        }
        else {
          var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
          auditReport.addMisAlignedAttribute(misalignedAttribute);
        }
      }
    }
    return auditReport
  }

  this.editPayload = function(fdn, properties, childProperties, fullClassName, objectFullName){
    var payload  = {};
    var configInfo = {};
    configInfo[fullClassName] = properties;
    configInfo[fullClassName]["children-Set"] = childProperties;
    //payload["fdn"] = fdn;
    payload["distinguishedName"] = fdn;
    payload["objectFullName"] = objectFullName;
    payload["clearOnDeployFailure"] = true;
    payload["configInfo"] = configInfo;
    logger.info(LOG_PREFIX + "All final payload : " + JSON.stringify(payload));
    return payload;
  }

  this.delay = function (milliseconds){
    var date = new Date();
    date.setMilliseconds(date.getMilliseconds() + milliseconds);
    while(new Date() < date){
    }
  }

  this.getIfObjectExists = function(className, objectFullName) {
    let nfmpFwk = new NfmpFwk();
    var expectedJson = {
      "fullClassName": className,
      "filter":{
        "equal":{
          "name":"objectFullName",
          "value": objectFullName
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          "displayedName"
        ]
      }
    };
    var resultFetch = nfmpFwk.post("/v3/search", expectedJson);
    logger.info(LOG_PREFIX + "search results : " + JSON.stringify(resultFetch));
    var finalResponse = JSON.parse(resultFetch.response);
    if (JSON.stringify(finalResponse) === JSON.stringify({})) {
      logger.info(LOG_PREFIX + "Search results is empty: " + JSON.stringify(finalResponse));
      finalResponse = null;
    }
    else if (!Array.isArray(finalResponse)) {
      finalResponse = [finalResponse["ixrqos.NetworkIngressPolicy"]];
      logger.info(LOG_PREFIX + "Search results: " + JSON.stringify(finalResponse));
    }
    return finalResponse;
  }

  this.isObjectExists = function (className, objectFullName) {
    let nfmpFwk = new NfmpFwk();
    var ret = false;
    var searchObjectJson = {
      "fullClassName": className,
      "filter": {
        "equal": {
          "name": "objectFullName",
          "value": objectFullName
        }
      }
    };
    var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);

    logger.info(LOG_PREFIX + "isObjectExists data = {}", JSON.stringify(resultFetch));
    var finalResponse = JSON.parse(resultFetch.response);
    logger.info(LOG_PREFIX + "Final response of search = {}", JSON.stringify(finalResponse));
    if (Object.keys(finalResponse).length !== 0 && finalResponse.constructor === Object)
    {
      ret = true;
    }
    logger.info(LOG_PREFIX + "isObjectExists = {} ", ret);
    return ret;
  }

  this.transformPoilcerAllocationGf = function (policerAllocation) {
    switch (policerAllocation) {
      case "per-fc":
        return "perFc";
      case "per-fc-unicast-multicast":
        return "perFcUniMulti";
      default:
        return policerAllocation;
    }
  }

  this.transformPolicerStatModeGf = function (policerStat) {
    switch (policerStat) {
      case "offered-profile-with-discards":
        return "offeredProfileWithDiscards";
      default:
        return "noStats";
    }
  }

  this.transformPolicerStatModeBf = function (policerStat) {
    switch (policerStat) {
      case "offeredProfileWithDiscards":
        return "offered-profile-with-discards";
      default:
        return "no-stats"
    }
  }

    this.modifyNeIdForIpV6 = function (objectFullName, neId) {
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }
}
