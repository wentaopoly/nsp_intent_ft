var RuntimeException = Java.type("java.lang.RuntimeException");

var prefixToNsMap = {
  ibn: "http://www.nokia.com/management-solutions/ibn",
  nc: "urn:ietf:params:xml:ns:netconf:base:1.0",
  "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
  "http://www.nokia.com/management-solutions/anv-device-holders":
    "anv-device-holders",
};

load({ script: resourceProvider.getResource("mdc-fwk.js"), name: "MdcFwk" });
const mdcFwk = new MdcFwk();

load({ script: resourceProvider.getResource("mdt-fwk.js"), name: "MdtFwk" });
var mdtFwk = new MdtFwk();

load({
  script: resourceProvider.getResource("parse-target.js"),
  name: "ParseTarget",
});
var parsedTarget = new ParseTarget();

/**
 * Load lodash and create object as underscore(_)
 */
load({ script: resourceProvider.getResource("lodash.js"), name: "Lodash" });
const _ = new Lodash();

/**
 * Load Deep-diff and create object as DeepDiff
 */
load({ script: resourceProvider.getResource("deep-diff.js"), name: "DeepDiff" });
const deepDiff = new DeepDiff();

/**
 *
 * Load and instantiate UtilFwk
 * @see UtilFwk
 */
load({ script: resourceProvider.getResource("util-fwk.js"), name: "UtilFwk" });
const utilFwk = new UtilFwk();

/**
 *
 * Load and instantiate ICMFwk
 * It contain ICM framework specific functions
 *
 * @see ICMFwk
 */
load({ script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk" });
const icmFwk = new ICMFwk();

/**
 * Load and instance IcmServiceFwk
 *
 * @see GtdFWk
 */
load({ script: resourceProvider.getResource("icm-service-fwk.js"), name: "icm-service-fwk" });
const icmServiceFwk = new IcmServiceFwk();

load({ script: resourceProvider.getResource("common-utils.js"), name: "CommonUtil" });
var commonUtil = new CommonUtil();

load({script: resourceProvider.getResource("custom-hooks.js"),name: "CustomHooks",});
const customHooks = new CustomHooks();

load({script: resourceProvider.getResource('mdSuggest.js'), name: "MdSuggest" });
var mdSuggest = new MdSuggest();

const metadata = JSON.parse(resourceProvider.getResource("meta-data.json"));

var intentTypeName = 'qos-sap-egress_msros_24-10-1_24-4';

/**
 * The node which you would like to configure.
 * example port, sap-ingress etc.
 * In the intent-yang, you will see this as a container
 * which encapsulates all the different type of nodes
 */
var intentContainer = 'sap-egress';

var deviceYangModuleName = 'nokia-conf';

// unique identifier
var uniqueIdentifier = 'sap-egress-policy-name,policy-id';

// example "configure" , "configure/qos" etc..
var rootXPath = 'configure/qos';

/**
 *
 * @param {*} input
 */
function validate(input) {
  logger.info("--------------Intent validate --------------");
  var config = formatConfig(input.getJsonIntentConfiguration());
  logger.info("config " + config);
}

function suggestSapEgressPolicyName(context) {
  // logger.info("suggestSapEgressPolicyName context = \n" + context);
  var policyId = context.getInputValues()["target"]["policy-id"];
  logger.info("User selected Policy ID : {}, searching Policy Name associated to Policy-id - {}", policyId, policyId);
  var neId = getNeId(context);
  return mdSuggest.getSapEgressPolicyName(neId, policyId);
}

function suggestSapEgressPolicyId(context) {
  // logger.info("suggestSapEgressPolicyId context = \n" + context);
  var policyName = context.getInputValues()["target"]["target_sap-egress-policy-name"];
  logger.info("User selected Policy Name : {}, searching Policy ID associated to Policy Name - {}", policyName, policyName);
  var neId = getNeId(context);
  return mdSuggest.getSapEgressPolicyId(neId, policyName);
}

function suggestPostPolicerMapping(context) {
  // logger.info("suggestPostPolicerMapping context = \n" + context);
  var neId = getNeId(context);
  return mdSuggest.getPostPolicerMapping(neId);
}

function suggestHsAttachmentPolicy(context) {
  // logger.info("suggestHsAttachmentPolicy context = \n" + context);
  var neId = getNeId(context);
  return mdSuggest.getHsAttachmentPolicy(neId);
}

function suggestAdvConfigPolicy(context) {
  // logger.info("suggestAdvConfigPolicy context = \n" + context);
  var neId = getNeId(context);
  return mdSuggest.getAdvConfigPolicy(neId);
}

function suggestWredQueuePolicy(context) {
  // logger.info("suggestWredQueuePolicy context = \n" + context);
  var neId = getNeId(context);
  return mdSuggest.getWredQueuePolicy(neId);
}

function suggestFcPolicer(context) {
  var result = [];
  // logger.info("suggestFcPolicer context = \n" + context);
  var policerConfigs = JSON.parse(context.getInputValues())["arguments"]["__parent"]["sap-egress"]["policer"];
  if (!Array.isArray(policerConfigs)) {
    policerConfigs = [policerConfigs];
  }
  for (var index in policerConfigs) {
    result.push(policerConfigs[index]["policer-id"]);
  }
  return result;
}

function suggestFcQrmQueue(context) {
  var result = [];
  // logger.info("suggestFcQrmQueue context = \n" + context);
  var queueConfigs = JSON.parse(context.getInputValues())["arguments"]["__parent"]["sap-egress"]["queue"];
  if (!Array.isArray(queueConfigs)) {
    queueConfigs = [queueConfigs];
  }
  for (var index in queueConfigs) {
    result.push(queueConfigs[index]["queue-id"])
  }
  return result;
}

function suggestQueueGroupName(context) {
  // logger.info("suggestQueueGroupName context = \n" + context);
  var neId = getNeId(context);
  return mdSuggest.getQueueGroupNames(neId);
}

function suggestQueueGroupQueues(context) {
  // logger.info("suggestQueueGroupQueues context = \n" + context);
  var neId = getNeId(context);
  var queueGroupName = JSON.parse(context.getInputValues())["arguments"]["queue-group-queue"]["queue-group-name"];
  logger.info("queueGroup: " + queueGroupName);
  if (queueGroupName !== '' && queueGroupName !== undefined) {
    return mdSuggest.getQueueGroupQueues(neId, queueGroupName);
  }
  else {
    logger.info("suggestQueueGroupQueues(): Queue Group is undefined/empty");
  }
}

function suggestIpPrefixList(context) {
  // logger.info("suggestIpPrefixList context = \n" + context);
  var neId = getNeId(context);
  return mdSuggest.getIpPrefixList(neId);
}

function suggestIpV6PrefixList(context) {
  // logger.info("suggestIpV6PrefixList context = \n" + context);
  var neId = getNeId(context);
  return mdSuggest.getIpV6PrefixList(neId);
}

/**
 *
 * This function is starting point by IM for sync operation
 *
 * @param {*} input
 * @returns
 */
function synchronize(input) {
  /**
   * Deployment of intents to the network, called for synchronize operations.
   * Used to apply create, update, delete and reconcile to managed devices.
   *
   * All created objects are remembered/restored as part of topology/extra-data
   * to apply house-keeping operations.
   *
   **/
  logger.info("--------------Intent Synchronisation started--------------");
  logger.info("input " + input);
  logger.info("intentTypeName " + intentTypeName);
  logger.info("rootXPath " + rootXPath);
  logger.info("intentContainer " + intentContainer);
  logger.info("uniqueIdentifier " + uniqueIdentifier);
  logger.info("deviceYangModuleName " + deviceYangModuleName);

  // TODO, so far the code is handling single intentContainer
  // but there can be multuple top level containers like the case of cpm-filter having ip-filter, ipv6-filter and mac-filter
  // format the config as per your use-case
  var config = formatConfig(input.getJsonIntentConfiguration());
  logger.info("config " + config);

  var target = input.getTarget();
  var state = input.getNetworkState().name();
  logger.info("state " + state);
  var startTime = new Date().getTime();
  var syncResult = synchronizeResultFactory.createSynchronizeResult();
  logger.info(
    intentTypeName + ":synchronize(" + target + ") in state " + state
  );
  // current topology
  var topology = input.getCurrentTopology();
  if (topology == null) {
    topology = topologyFactory.createServiceTopology();
  }
  logger.info("topology " + JSON.stringify(topology));
  var resp = utilFwk.synchronize(
    target,
    config,
    intentTypeName,
    rootXPath,
    intentContainer,
    uniqueIdentifier,
    deviceYangModuleName,
    topology,
    state,
    syncResult
  );
  var endTime = Date.now();
  var timeTaken = (endTime - startTime) / 1000; // seconds
  logger.info(
    "Time taken to synchronize " + timeTaken + " seconds for intent " + target
  );
  var endTime = Date.now();
  var timeTaken = (endTime - startTime) / 1000; // seconds
  logger.info("Time taken to synchronize " + timeTaken);
  logger.info("--------------Intent Synchronisation done--------------");
  return resp;
}

/**
 *
 * The function is starting point for audit operation in IM
 *
 * @param {*} input
 * @returns auditReport
 */
function audit(input) {
  logger.info("-------------- Intent Audit --------------");
  var startTime = new Date().getTime();
  var target = input.getTarget();
  var key = intentTypeName + ":" + intentTypeName;
  var intentConfig = JSON.parse(input.getJsonIntentConfiguration())[0][key][
    intentContainer
  ];
  var state = input.getNetworkState().name();
  var topology = input.getCurrentTopology();

  logger.info("target " + target);
  logger.info("topology " + topology);
  logger.info("state " + state);
  logger.info("intentConfig " + JSON.stringify(intentConfig));
  let auditReport = utilFwk.audit(
    target,
    intentConfig,
    topology,
    state,
    intentTypeName,
    rootXPath,
    intentContainer,
    uniqueIdentifier,
    deviceYangModuleName
  );
  var endTime = Date.now();
  var timeTaken = (endTime - startTime) / 1000; // seconds
  logger.info(
    "Time taken to audit " + timeTaken + " seconds for intent " + target
  );
  return auditReport;
}

/**
 *
 * The function is used in Brownfield disscovery by ICM FW
 * It discover the configuration from the target device
 * and manipulate as per Template's default-target-data
 *
 *
 * @see ICMFwk for more details
 * @param {*} input - the config data of a deployment
 * @returns result - the result of the operation
 */
function getTargetData(input) {
  logger.info("-------- Intent getTargetData started ------");
  logger.info(JSON.stringify(input));
  var target = input.target;
  logger.info("target=" + target);
  var deviceConfig = icmFwk.getDeviceConfiguration(
    target,
    deviceYangModuleName,
    rootXPath,
    intentContainer
  );
  logger.info(JSON.stringify(deviceConfig));
  var data = icmServiceFwk.gtdSend(deviceConfig);
  logger.info(JSON.stringify(data));
  logger.info(JSON.stringify(data.msg.result));
  return data.msg.result;
}

function getNeId(context) {
  var neId;
  var target = context.getInputValues()["target"]["objectidentifier"];
  logger.info("getNeId() target : {}", target)
  if (target) {
    if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
      neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
    }
    else {
      neId = target;
    }
  }
  logger.info("getNeId() NeId identified " + " : {}", neId);
  return neId;
}

/**
 *
 * If there are multiple containers at in intent-yang for intentContainer name,
 * the config returned by the scriptEnginer is array
 *
 * @param {*} config
 * @returns
 */
const formatConfig = (config) => {
  if (Array.isArray(config)) {
    return config[0];
  } else {
    return config;
  }
};
