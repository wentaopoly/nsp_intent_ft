package com.nokia.nsp.md.resync.plugin.srl;

import com.alu.nms.common.util.model.ModelFdn;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nokia.nsp.md.common.IExecutionContext;
import com.nokia.nsp.md.common.IYangObject;
import com.nokia.nsp.md.common.YangObject;
import com.nokia.nsp.md.db.yang.api.ExecutionContext;
import com.nokia.nsp.md.db.yang.api.QueryParameters;
import com.nokia.nsp.md.db.yang.api.meta.IYangPath;
import com.nokia.nsp.md.ifg.yang.api.Fields;
import com.nokia.nsp.md.resync.api.IReadObjects;
import com.nokia.nsp.md.resync.plugin.common.DeviceInfo;
import com.nokia.nsp.md.resync.plugin.common.DeviceResyncClass;
import com.nokia.nsp.md.resync.plugin.common.IMDMPluginMdResyncProvider;
import com.nokia.nsp.md.resync.plugin.common.INspResyncDeviceClassHandler;
import com.nokia.nsp.md.resync.plugin.common.IPartialResyncContext;
import com.nokia.nsp.md.resync.plugin.common.ISaveTaskInfo;
import com.nokia.nsp.md.resync.plugin.common.ResyncClass;
import com.nokia.nsp.md.resync.plugin.common.Utils;
import com.nokia.nspos.model.domain.common.types.SourceType;
import com.nokia.nspos.persistence.impl.db.transaction.Transactor;
import com.nokia.nspos.persistence.impl.db.transaction.TxPhase;
import com.nokia.nspos.persistence.yang.api.IYangDB;
import com.nokia.nspos.persistence.yang.api.SourceData;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

public class SrlElanResyncHandler implements INspResyncDeviceClassHandler {

	public static final String SRL_SERVICE_CLASS_ID = "srl_nokia-network-instance:/network-instance";
	private static final Logger logger = LoggerFactory.getLogger(SrlElanResyncHandler.class.getName());

	SourceData sourceData = new SourceData(SourceType.other, ModelFdn.decode("fdn:app:resync"));
	private static ThreadLocal<Map<String,SrlResyncRequestWrapper>> resyncThreadLocal=new ThreadLocal<>();
	public static ThreadLocal<Map<String, String>> neNameCache = new ThreadLocal<>();
	static String fieldFilterRequestJson = "{\"type\":null,\"admin-state\":null,\"oper-state\":null,\"description\":null,\"interface\":{\"name\":null},\"vxlan-interface\":{\"name\":null},\"protocols\":{\"srl_nokia-bgp-vpn:bgp-vpn\":{\"bgp-instance\":{\"route-target\":\n" +
			"\n" +
			"{\"export-rt\":null,\"import-rt\":null}\n" +
			",\"route-distinguisher\":\n" +
			"\n" +
			"{\"rd\":null}\n" +
			"}},\"bgp-evpn\":{\"srl_nokia-bgp-evpn:bgp-instance\":{\"evi\":null,\"vxlan-interface\":null,\"ecmp\":null}}}}";
	static HashMap fieldFilterMap =  new HashMap();
	public  int getDeviceMaxDepth(DeviceResyncClass aInDeviceClass,String aInNodeType,String aInNodeVersion)
	{
		return 5;
	}

	@Override
	public boolean isHandleRootDevice(DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, ISaveTaskInfo aInISaveTaskInfo, DeviceInfo aInDeviceInfo) {
		return true;
	}

	public void handleRootDevice(IYangPath aInIYangPath, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass,
								 Object aInDeviceObject, ISaveTaskInfo aInISaveTaskInfo, DeviceInfo aInDeviceInfo, IReadObjects aInIReadObjects, List < IYangObject > aOutProcessedObjects) {


		String aNeId =  aInISaveTaskInfo.getNeId();
		IMDMPluginMdResyncProvider aMDMPluginMdResyncProvider = aInISaveTaskInfo.getIMDMPluginMdResyncProvider();
		IYangDB aInYangDB = aMDMPluginMdResyncProvider.getiMdResyncFw().getIYangDB();
		String netIns = getNetInstance((Map) aInDeviceObject);
		if (netIns.contains("'*'") || netIns.equals("default") || netIns.equals("mgmt"))
		{
			return;
		}
		logger.debug("handleRootDevice : Filter response for NetworkInstance : {} on siteId : {} response : {} ",netIns,aNeId, aInDeviceObject);
		if(((Map<?, ?>)aInDeviceObject).get("type").equals("srl_nokia-network-instance:mac-vrf")) {
			String lOperationalSitePath = "/nsp-service:services/service-layer/elan/site[site-id='" + aNeId + "'][name='" + netIns + "']";
			String lSyncSitePath = "/nsp-sync:sites/elan-site[site-id='" + aNeId + "'][name='" + netIns + "']";
			String lParentPath = lSyncSitePath;
			//IYangObject lOperationalSiteYo = aInYangDB.getSingle(lOperationalSitePath);
			Map<String,Object> map = new HashMap<>();
			map.put("site-id",aNeId);
			map.put("name",netIns);
			IYangObject operationalModel = aInIReadObjects.removeBaseOnParams(map);
			if(null == operationalModel) {
				IYangObject alternative = aInIReadObjects.getAlternativeReadObjects().remove(lSyncSitePath);
				if(null == alternative){
					//create alternative site
					createSyncSite(aInDeviceObject, aNeId, aInYangDB, netIns);
				} else {
					//update the sync site
					updateSyncSite(aInDeviceObject, aNeId, aInYangDB, netIns, alternative);
				}
			} else {
				aOutProcessedObjects.add(operationalModel);
				UpdateOperSite((Map) aInDeviceObject, aNeId, aInYangDB, netIns, operationalModel);
			}

//			if (lOperationalSiteYo != null) {
//				createOrUpdateOperSite((Map) aInDeviceObject, aNeId, aInYangDB, netIns, lOperationalSiteYo);
//			} else {
//				createSyncSite(aInDeviceObject, aNeId, aInYangDB, netIns, lParentPath);
//			}
		}
	}

	private void UpdateOperSite(Map aInDeviceObject, String aNeId, IYangDB aInYangDB, String netIns, IYangObject lOperationalSiteYo) {
		Map<String, Object> aOutNspObject = getOutNspObject(aInDeviceObject, lOperationalSiteYo);
		Map<String, Object> aOutNspExtSiteObject;
		if(lOperationalSiteYo.getProperty("service-extension:elan-site") == null){
			aOutNspExtSiteObject = new HashMap<String, Object>();
			ArrayList lSources = new ArrayList();
			Map<String, Object> lMetaData = new HashMap<>();
			setSources((Map) aInDeviceObject.get("_fdn_"), aNeId,lSources,lMetaData,aOutNspExtSiteObject);
		} else {
			IYangObject lSiteExtProp = (IYangObject)lOperationalSiteYo.getProperty("service-extension:elan-site");
			aOutNspExtSiteObject = lSiteExtProp.getProperties();
		}
		updateOperSite(aInDeviceObject, aNeId, aInYangDB, netIns, aOutNspObject, lOperationalSiteYo, aOutNspExtSiteObject);
	}

	private void createSyncSiteForPartialResync(Object aInDeviceObject, String aNeId, IYangDB aInYangDB, String netins, String lParentPath) {
		List<String> lSources = new ArrayList<>();
		IYangObject lSyncSiteYo = aInYangDB.getSingle(lParentPath);
		Map<String, Object> aOutNspObject;
		Map<String, Object> lMetaData = new HashMap<>();
		String lEPParentPath = "/nsp-sync:sites/elan-site[site-id='" + aNeId + "'][name='" + netins;
		aOutNspObject = createSyncSiteProp(aNeId, netins, aInDeviceObject,aInYangDB, lSources,lEPParentPath);
		setSources((Map)((Map) aInDeviceObject).get("_fdn_"),aNeId,lSources,lMetaData,aOutNspObject);
		QueryParameters lQueryParams = getlQueryParams();
		if(lSyncSiteYo == null) {
			logger.info("creating Sync service {} on neId  {} ", netins, aNeId);
			aInYangDB.createChild("/nsp-sync:sites", "elan-site", new YangObject(aOutNspObject), sourceData, lQueryParams);
		} else {
			logger.info("Updating Sync service {} on neId  {} ",netins,aNeId);
			aInYangDB.update(lSyncSiteYo.getIdentifier(), new YangObject(aOutNspObject), lQueryParams);
		}
	}

	private void createSyncSite(Object aInDeviceObject, String aNeId, IYangDB aInYangDB, String netins) {
		List<String> lSources = new ArrayList<>();
		//IYangObject lSyncSiteYo = aInYangDB.getSingle(lParentPath);
		Map<String, Object> aOutNspObject;
		Map<String, Object> lMetaData = new HashMap<>();
		String lEPParentPath = "/nsp-sync:sites/elan-site[site-id='" + aNeId + "'][name='" + netins;
		aOutNspObject = createSyncSiteProp(aNeId, netins, aInDeviceObject,aInYangDB, lSources,lEPParentPath);
		setSources((Map)((Map) aInDeviceObject).get("_fdn_"),aNeId,lSources,lMetaData,aOutNspObject);
		QueryParameters lQueryParams = getlQueryParams();
		//if(lSyncSiteYo == null) {
		logger.info("creating Sync service {} on neId  {} ", netins, aNeId);
		aInYangDB.createChild("/nsp-sync:sites", "elan-site", new YangObject(aOutNspObject), sourceData, lQueryParams);
//		} else {
//			logger.info("Updating Sync service {} on neId  {} ",netins,aNeId);
//			aInYangDB.update(lSyncSiteYo.getIdentifier(), new YangObject(aOutNspObject), lQueryParams);
//		}
	}

	private void updateSyncSite(Object aInDeviceObject, String aNeId, IYangDB aInYangDB, String netins, IYangObject lSyncSiteYo) {
		List<String> lSources = new ArrayList<>();
		//IYangObject lSyncSiteYo = aInYangDB.getSingle(lParentPath);
		Map<String, Object> aOutNspObject;
		Map<String, Object> lMetaData = new HashMap<>();
		String lEPParentPath = "/nsp-sync:sites/elan-site[site-id='" + aNeId + "'][name='" + netins;
		aOutNspObject = createSyncSiteProp(aNeId, netins, aInDeviceObject,aInYangDB, lSources,lEPParentPath);
		setSources((Map)((Map) aInDeviceObject).get("_fdn_"),aNeId,lSources,lMetaData,aOutNspObject);
		QueryParameters lQueryParams = getlQueryParams();
		//if(lSyncSiteYo == null) {
		//logger.info("creating Sync service {} on neId  {} ", netins, aNeId);
		//aInYangDB.createChild("/nsp-sync:sites", "elan-site", new YangObject(aOutNspObject), sourceData, lQueryParams);
//		} else {
		logger.info("Updating Sync service {} on neId  {} ",netins,aNeId);
		aInYangDB.update(lSyncSiteYo.getIdentifier(), new YangObject(aOutNspObject), lQueryParams);
//		}
	}

	private List<?> populateBgpVpnInstance(Map<String, Object> aInDeviceObject,String aInNeId, String netins) {

		int bgpVpnId = -1;
		String bgpVpnRd = null;
		String bgpVpnImRt = null;
		String bgpVpnExRt = null;
		Map<String, Object> bgpSources = null;
		Map<String, Object> rdSources = null;
		Map<String, Object> rtSources = null;

		List<Object> returnBgpList = null;

		Map<String, Object> aOutNspObject = null;
		if(aInDeviceObject!= null &&  aInDeviceObject.get("srl_nokia-bgp-vpn:bgp-vpn") != null) {

			LinkedHashMap<?,?> bgpVpn = (LinkedHashMap) aInDeviceObject.get("srl_nokia-bgp-vpn:bgp-vpn");

			//bgp-vpn
			Map<String, Object> rdExpObject = new HashMap<>();
			Map<String, Object> rdImpObject = new HashMap<>();
			List<String> impCommList = new ArrayList<>();
			List<String> expCommList = new ArrayList<>();

			if(bgpVpn != null){
				returnBgpList = new ArrayList<>();
				aOutNspObject = new HashMap<String, Object>();
				ArrayList bgpVpnInst = (ArrayList)bgpVpn.get("bgp-instance");
				if (bgpVpnInst != null){
					bgpVpnId = (Integer) ((LinkedHashMap)bgpVpnInst.get(0)).get("id");
					bgpSources = getNspModelSources((Map)bgpVpnInst.get(0),aInNeId);
					LinkedHashMap rd = (LinkedHashMap)((LinkedHashMap)bgpVpnInst.get(0)).get("route-distinguisher");
					LinkedHashMap rt = (LinkedHashMap)((LinkedHashMap)bgpVpnInst.get(0)).get("route-target");
					if(rd != null) {
						bgpVpnRd = (String) rd.get("rd");
						List sources = (List)bgpSources.get("nsp-model:sources");
						sources.add(Utils.buildSourceFdn((Map) rd.get("_fdn_"), aInNeId, true));
						//rdSources = getNspModelSources(rd,aInNeId);
						logger.debug("Ne ID : {}  NetworkInstance : {}   rd  : {}",aInNeId,netins,bgpVpnRd);
					}
					if(rt != null){
						bgpVpnImRt = (String) rt.get("import-rt");
						bgpVpnExRt = (String) rt.get("export-rt");
						rtSources = getNspModelSources(rt,aInNeId);
						logger.debug("Ne ID : {}  NetworkInstance : {} import-rt  : {}",aInNeId,netins, bgpVpnImRt);
						logger.debug("Ne ID : {}  NetworkInstance : {} export-rt  : {}",aInNeId,netins, bgpVpnExRt);
					}
				}
			}
			if (bgpVpnId != -1){
				returnBgpList.add(aOutNspObject);
				aOutNspObject.put("bgp-instance", bgpVpnId);
				aOutNspObject.put("@",bgpSources);
				if(bgpVpnRd != null){
					aOutNspObject.put("route-distinguisher", bgpVpnRd);
				}

				if (bgpVpnImRt != null) {
					impCommList.add(bgpVpnImRt);
					rdImpObject.put("community", impCommList);
					rdImpObject.put("@",rtSources);
					aOutNspObject.put("route-target-import", rdImpObject);
				}

				if (bgpVpnExRt != null) {
					expCommList.add(bgpVpnExRt);
					rdExpObject.put("community", expCommList);
					rdExpObject.put("@",rtSources);
					aOutNspObject.put("route-target-export", rdExpObject);
				}
			}
		}
		return returnBgpList;
	}

	private String getVxlanIF(Map<String, Object> aInDeviceObject){
		String vxlanIF = null;
		ArrayList<?> vxlanInterfaceList = (ArrayList) aInDeviceObject.get("vxlan-interface");
		if(vxlanInterfaceList != null && !vxlanInterfaceList.isEmpty()){
			vxlanIF = (String)((LinkedHashMap) vxlanInterfaceList.get(0)).get("name");
		}
		return vxlanIF;
	}

	private ArrayList<?> getProtocolBgpEvpnEVI(Map<String, Object> aInDeviceObject){
		Integer evi = null;
		ArrayList<?> bgpinst = null;
		LinkedHashMap<?,?> lprotocols = (LinkedHashMap) aInDeviceObject.get("protocols");
		if(lprotocols != null){
			LinkedHashMap<?,?> bgpEvpn = (LinkedHashMap) lprotocols.get("bgp-evpn");
			if(bgpEvpn != null){
				bgpinst = (ArrayList)bgpEvpn.get("srl_nokia-bgp-evpn:bgp-instance");
			}
		}
		return bgpinst;
	}

	private String getVxlanFdn(String aInSource, String aInVxLanIFName){

		String[] lSourceArr = aInSource.split("/network-instance");
		String[] vxLanName = aInVxLanIFName.split("\\.");
		String vxLanFdn = lSourceArr[0] + "/tunnel-interface[name='" + vxLanName[0] + "']/vxlan-interface[index='" +
				vxLanName[1] + "']/ingress";
		return vxLanFdn;
	}

	private Map<String, Object> getNspModelSources(Map<String, Object> aInUnitObjMap,String aInNeId) {
		Object lUnitFdn = aInUnitObjMap.get("_fdn_");
		List<String> lSources = new ArrayList<>();
		String lUnitSource = Utils.buildSourceFdn((Map) lUnitFdn, aInNeId, true);
		lSources.add(lUnitSource);
		Map<String, Object> lMetaData = new HashMap<>();
		lMetaData.put("nsp-model:sources", lSources);
		return lMetaData;
	}

	@Override
	public void handleDelete(ISaveTaskInfo aInISaveTaskInfo, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, Map < String, Object > aInDeviceObject, String aInNeId, IMDMPluginMdResyncProvider aInMdResyncFw, DeviceInfo aInDeviceInfo) {

		logger.debug(" handleDelete  .: aInDeviceClass {}  aInNspClass:{}   ",aInDeviceClass,aInNspClass);

		String netins = getNetInstance(aInDeviceObject);
		String lDevicePath = aInDeviceClass.getDeviceClassPath();
		IYangDB lYangDB = aInISaveTaskInfo.getIMDMPluginMdResyncProvider().getiMdResyncFw().getIYangDB();

		String lOperationalSitePath = "/nsp-service:services/service-layer/elan/site[site-id='" + aInNeId + "'][name='" + netins +"']";
		String lSyncSitePath = "/nsp-sync:sites/elan-site[site-id='" + aInNeId + "'][name='" + netins + "']";

		QueryParameters lQueryParams =getlQueryParams();
		if (lDevicePath.equals(SRL_SERVICE_CLASS_ID)) {
			IYangObject lOperationalSiteYo = lYangDB.getSingle(lOperationalSitePath);
			IYangObject lSyncSiteYo = lYangDB.getSingle(lSyncSitePath);
			if (null != lOperationalSiteYo) {
				lYangDB.delete(lOperationalSiteYo.getIdentifier(), lQueryParams);
				logger.info("Deleting Operational Service site !!!! : {} " , netins);
			}
			if (null != lSyncSiteYo) {
				lYangDB.delete(lSyncSiteYo.getIdentifier(), lQueryParams);
				logger.info("Deleting Sync Service site !!!! : {}",netins);
			}
		}
	}

	private String getNetInstance(Map aInDeviceObject) {
		Object lObjectFdn = aInDeviceObject.get("_fdn_");
		String nm = (String)((Map)lObjectFdn).get("fdn");
		int startIndex = nm.indexOf("name");
		String netIns = nm.substring(startIndex + 6, nm.indexOf("'", startIndex + 6));
		return netIns;
	}

	@Override
	public void handleDelete(ISaveTaskInfo aInISaveTaskInfo, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, ModelFdn aInDeviceObject, String aInNeId, IMDMPluginMdResyncProvider aInMdResyncFw, DeviceInfo aInDeviceInfo) {
		logger.info(" handleDelete 2: aInDeviceClass {}  aInNspClass:{}  aInDeviceObject: {}  ",aInDeviceClass,aInNspClass,aInDeviceObject);
	}

	@Override
	public Object handleDeviceResyncClass(DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, Object aInDeviceObject,
										  String aInNeId, IMDMPluginMdResyncProvider aInMdResyncFw, DeviceInfo aInDeviceInfo) {

		logger.info(" handleDeviceResyncClass .: aInDeviceClass {}  aInNspClass:{}  ",aInDeviceClass,aInNspClass);
		if (null == aInDeviceObject) {
			return null;
		}

		Map < String, Object > aOutNspObject = new HashMap < > ();
		return aOutNspObject;
	}

	@Override
	public void handleUpdate(ISaveTaskInfo aInISaveTaskInfo, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, Map < String, Object > aInDeviceObject, String aInNeId, IMDMPluginMdResyncProvider aInMDMPluginMdResyncProvider, DeviceInfo aInDeviceInfo) {

		//logger.info(" handleUpdate for neId : {}  corresponding  Resync class :  {}",aInNeId,aInDeviceClass,aInNspClass);
		String lDevicePath = aInDeviceClass.getDeviceClassPath();
		IYangDB lYangDB = aInISaveTaskInfo.getIMDMPluginMdResyncProvider().getiMdResyncFw().getIYangDB();
		String netins = getNetInstance((Map) aInDeviceObject);
		String lOperationalSitePath = "/nsp-service:services/service-layer/elan/site[site-id='" + aInNeId + "'][name='" + netins +"']";
		String lSyncSitePath = "/nsp-sync:sites/elan-site[site-id='" + aInNeId + "'][name='" + netins + "']";

		Map<String, Object> aOutNspObject;
		QueryParameters lQueryParams =getlQueryParams();
		if(!lDevicePath.equals(SRL_SERVICE_CLASS_ID))
			return;
		//NSPD-318012 - If node is flapping with different values let says admin-state, then node may send update for individual attributes
		//we may not get 'type' attribute along with other attribute and will result in null pointer hence adding a safe check.
		if(aInDeviceObject.get("type") != null && !(aInDeviceObject.get("type").equals("srl_nokia-network-instance:mac-vrf")))
			return;
		IYangObject lOperationalSiteYo = lYangDB.getSingle(lOperationalSitePath);
		IYangObject lSyncSiteYo = lYangDB.getSingle(lSyncSitePath);
		if (null != lOperationalSiteYo) {
			aOutNspObject = getOutNspObject( aInDeviceObject, lOperationalSiteYo);
			lYangDB.update(lOperationalSiteYo.getIdentifier(),new YangObject(aOutNspObject),lQueryParams);
		} else if (lSyncSiteYo != null) {
			aOutNspObject = getOutNspObject( aInDeviceObject, lSyncSiteYo);
			lYangDB.update(lSyncSiteYo.getIdentifier(), new YangObject(aOutNspObject),lQueryParams);
		} else {  // If Not Operational and Sync Site are not there, User is creating site from Node CLI
			scheduldePartialResync(aInDeviceClass, aInNspClass, aInDeviceObject, aInNeId, aInMDMPluginMdResyncProvider, aInDeviceInfo);
		}
	}

	@NotNull
	private Map<String, Object> getOutNspObject(Map aInDeviceObject, IYangObject lSiteYo) {
		Map<String, Object> aOutNspObject = new HashMap<String, Object>();
		if(aInDeviceObject.get("admin-state") != null) {
			String adminState = convertAdminState((String)aInDeviceObject.get("admin-state"));
			aOutNspObject.put("admin-state", adminState);
		}
		if(aInDeviceObject.get("oper-state") != null) {
			String operState = convertOperState((String)aInDeviceObject.get("oper-state"));
			aOutNspObject.put("oper-state", operState);
		}
		if(aInDeviceObject.get("description") != null) {
			aOutNspObject.put("description", (String)aInDeviceObject.get("description"));
		}
		return aOutNspObject;
	}

	private void scheduldePartialResync(DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, Map<String, Object> aInDeviceObject, String aInNeId, IMDMPluginMdResyncProvider aInMDMPluginMdResyncProvider, DeviceInfo aInDeviceInfo) {
		logger.info(" :scheduldePartialResync: Neid {}  deviceClassPath {} ",aInNeId,aInDeviceClass.getDeviceClassPath() );
		Map<String,SrlResyncRequestWrapper> lWrapperMap=resyncThreadLocal.get();
		if(null == lWrapperMap)
		{
			lWrapperMap=new HashMap<>();
			resyncThreadLocal.set(lWrapperMap);
			Transactor.getContext().addEventHandler(TxPhase.POST_ROLLBACK,(phase, context) -> {
				resyncThreadLocal.remove();
			});
			Transactor.getContext().addEventHandler(TxPhase.POST_COMMIT, (phase, context) -> {
				Map<String,SrlResyncRequestWrapper> lTmpWrapperMap=resyncThreadLocal.get();
				resyncThreadLocal.remove();
				if(null!=lTmpWrapperMap)
				{
					for(Map.Entry<String,SrlResyncRequestWrapper> lEntry:lTmpWrapperMap.entrySet())
					{
						aInMDMPluginMdResyncProvider.submitPartialResyncTask(lEntry.getKey(),
								lEntry.getValue().getResyncClasses(),lEntry.getValue().getXPaths(), aInNeId, aInDeviceInfo.getNodeType(), aInDeviceInfo.getNodeVersion(), aInDeviceInfo.getAmiName(), aInDeviceInfo.getAmiVersion(),null);
					}
				}

			});
		}
		SrlResyncRequestWrapper lResyncWrapper=lWrapperMap.get(aInDeviceClass.getDeviceClassPath());
		if(null == lResyncWrapper)
		{
			Set<ResyncClass> lResyncClasses=new HashSet<>(1);
			lResyncClasses.add(aInNspClass);
			lResyncWrapper=new SrlResyncRequestWrapper(aInDeviceClass.getDeviceClassPath(),lResyncClasses);
			lWrapperMap.put(aInDeviceClass.getDeviceClassPath(), lResyncWrapper);
		}
		Object lFdn = aInDeviceObject.get("_fdn_");
		lResyncWrapper.addXPath((String) ((Map<String, Object>) lFdn).get("fdn"), Utils.buildSourceFdn((Map) lFdn));
	}

	@Override
	public void handlePartialDeviceResyncClass(ISaveTaskInfo aInISaveTaskInfo, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass,
											   Map < String, Object > aInDeviceObject, String aInNeId, IMDMPluginMdResyncProvider aInMdResyncFw, DeviceInfo aInDeviceInfo, IPartialResyncContext aInIPartialResyncContext) {

		//logger.info("handlePartialDeviceResyncClass : for neId {} for  DeviceClass: {} Resync class {}: ", aInNeId, aInDeviceClass, aInNspClass);
		String lDevicePath = aInDeviceClass.getDeviceClassPath();
		IYangDB lYangDB = aInISaveTaskInfo.getIMDMPluginMdResyncProvider().getiMdResyncFw().getIYangDB();
		String netIns = getNetInstance((Map)aInDeviceObject);

		logger.debug("handlePartialDeviceResyncClass : Filter response for NetworkInstance : {} on siteId : {} response : {} ",netIns,aInNeId, aInDeviceObject);

		String lOperationalSitePath = "/nsp-service:services/service-layer/elan/site[site-id='" + aInNeId + "'][name='" + netIns +"']";
		String lOperationalExtSitePath = "/nsp-service:services/service-layer/elan/site/service-extension:elan-site[site-id='" + aInNeId + "'][name='" + netIns + "']";
		String lSyncSitePath = "/nsp-sync:sites/elan-site[site-id='" + aInNeId + "'][name='" + netIns + "']";

		if (lDevicePath.equals(SRL_SERVICE_CLASS_ID) && aInDeviceObject.get("type").equals("srl_nokia-network-instance:mac-vrf")) {
			IYangObject lOperationalSiteYo = lYangDB.getSingle(lOperationalSitePath);
			if (null != lOperationalSiteYo) {
				UpdateOperSite((Map) aInDeviceObject, aInNeId, lYangDB, netIns, lOperationalSiteYo);
			}  else {  // If Not Operational and Sync Site are not there, User is creating site from Node CLI
				createSyncSiteForPartialResync(aInDeviceObject,aInNeId,lYangDB,netIns,lSyncSitePath);
			}
		}
	}

	private void updateOperSite(Map<String, Object> aInDeviceObject, String aInNeId, IYangDB lYangDB, String netIns, Map<String, Object> aOutNspObject, IYangObject lOperationalSiteYo, Map<String, Object> aOutNspExtSiteObject) {
		QueryParameters lQueryParams = getlQueryParams();
		lQueryParams.getIExecutionContext().addExtraParameter("return-light-data", true);
		//Ext-Site
		populateExtSiteProperties(aOutNspObject, aOutNspExtSiteObject,aInNeId,lYangDB);
		//BGP-EVPN
		populateBgpEvpnProperties(aInNeId, aInDeviceObject, netIns, aOutNspExtSiteObject,true);
		//VXLAN
		populateVxlanProperties(aInDeviceObject, aOutNspExtSiteObject,aInNeId,netIns);
		//BGP
		populateBgpProperties(aInDeviceObject, aInNeId, netIns, aOutNspExtSiteObject);
		lYangDB.update(lOperationalSiteYo.getIdentifier(), new YangObject(aOutNspObject), lQueryParams);
		logger.info("Updating Oper service {} on neId  {} ",netIns,aInNeId);
	}

	private void populateBgpProperties(Map<String, Object> lDeviceObjectMap, String aInNeId, String netins, Map<String, Object> aOutNspExtSiteObject) {
		List aOutExtBgpVpnList = populateBgpVpnInstance((Map) lDeviceObjectMap.get("protocols"), aInNeId, netins);
		if(null != aOutExtBgpVpnList){
			aOutNspExtSiteObject.put("bgp",aOutExtBgpVpnList);
		}
	}

	private void populateExtSiteProperties(Map<String, Object> aOutNspSiteObject,Map<String, Object> aOutNspExtSiteObject,String aInNeId,IYangDB iYangDB) {
		if(null != aOutNspExtSiteObject){
			aOutNspSiteObject.put("service-extension:elan-site",aOutNspExtSiteObject);
//			if(aOutNspExtSiteObject.get("tenant-id") == null) {
//				aOutNspExtSiteObject.put("tenant-id", "1");
//			}
			if(aOutNspExtSiteObject.get("ne-name") == null) {
				QueryParameters lQpNeName = new QueryParameters();
				IExecutionContext lExecutionContext = new ExecutionContext(null, null, false, false, false);
				lQpNeName.setIExecutionContext(lExecutionContext);
				lQpNeName.setFields(Fields.parse("ne-name"));
				lQpNeName.setDepth(2);
				String ne_name = getNeNameByIdFromCache(aInNeId, lQpNeName, iYangDB);
				if (ne_name != null) {
					aOutNspExtSiteObject.put("ne-name", ne_name);
				}
			}
		}
	}

	private void populateVxlanProperties( Map<String, Object> lDeviceObjectMap,Map<String, Object> aOutNspExtSiteObject,String aInNeId,String netIns) {
		String aInVxlanIfName = getVxlanIF(lDeviceObjectMap);
		Map<String, Object> aOutExtSiteVxlanObject = new HashMap<String, Object>();
		Map<String, Object> vxlanInstanceObject = new HashMap<String, Object>();

		List<Map<String, Object>> vxInstList = new ArrayList<>();
		if(null != aInVxlanIfName){
			vxlanInstanceObject.put("vxlan-instance-id", 1);
			String[] vxIndexArr = aInVxlanIfName.split("\\.");
			if(vxIndexArr.length == 2) {
				String vxlanInterfaceXpath = "/tunnel-interface[name='" + vxIndexArr[0] + "']/vxlan-interface[index='" + vxIndexArr[1] + "']/ingress";
				String vxlanInterfaceFdn = "fdn:model:mdm:" + aInNeId + ":" + vxlanInterfaceXpath;
				List<String> lSources = new ArrayList<>();
				lSources.add(vxlanInterfaceFdn);
				Map<String, Object> lMetaData = new HashMap<>();
				lMetaData.put("nsp-model:sources", lSources);
				IYangObject vxlanObj = (IYangObject)aOutNspExtSiteObject.get("vxlan");
				Map<String, Object> vxlanInstanceProps = null;
				if(vxlanObj != null) {
					vxlanInstanceProps = vxlanObj.getProperties();
				}
				if(vxlanObj == null || vxlanInstanceProps == null || vxlanInstanceProps.size() == 0){
					vxlanInstanceObject.put("vni", vxIndexArr[1]);
				}
				vxlanInstanceObject.put("@", lMetaData);
				logger.debug("NeId : {}  networkInstance : {}  vxlan-interface : {} ",aInNeId,netIns,vxlanInterfaceXpath);
			}
			vxInstList.add(vxlanInstanceObject);
			aOutExtSiteVxlanObject.put("instance", vxInstList);
			aOutNspExtSiteObject.put("vxlan", aOutExtSiteVxlanObject);
		}
	}

	private void populateBgpEvpnProperties(String aNeId, Map<String, Object> lDeviceObjectMap,  String netIns, Map<String, Object> aOutNspExtSiteObject,boolean isOperationalSite) {
		Map<String, Object> aOutExtSiteBgpEvpnObject = new HashMap<>();
		Map<String, Object> aOutExtSiteBgpEvpnEcmpObject = new HashMap<>();
		List<Map<String, Object>> arryListBgpEvpnEcmp = new ArrayList<>();
		Map<String, Object> bgpEvpnSources = null;
		ArrayList<?> bgpinst = getProtocolBgpEvpnEVI(lDeviceObjectMap);
		if(bgpinst != null) {
			Integer evi = (Integer) ((LinkedHashMap)bgpinst.get(0)).get("evi");
			aOutExtSiteBgpEvpnObject.put("evi", evi);

			//Service Model ECMP present in MPLS container inside bgp-evpn
			if(isOperationalSite) {
				Integer ecmp = (Integer) ((LinkedHashMap)bgpinst.get(0)).get("ecmp");
				Integer bgpInstanceId;
				String id = ((LinkedHashMap)bgpinst.get(0)).get("id").toString();
				bgpInstanceId = new Integer(Integer.parseInt(id));
				aOutExtSiteBgpEvpnEcmpObject.put("bgp-instance", bgpInstanceId);
				aOutExtSiteBgpEvpnEcmpObject.put("ecmp", ecmp);
				aOutExtSiteBgpEvpnEcmpObject.put("@", getNspModelSources((Map) bgpinst.get(0), aNeId));
				arryListBgpEvpnEcmp.add(aOutExtSiteBgpEvpnEcmpObject);
				aOutExtSiteBgpEvpnObject.put("mpls", arryListBgpEvpnEcmp);
				logger.debug("NeId : {}  networkInstance : {}  ecmp : {} ", aNeId, netIns, ecmp);
			}

			aOutExtSiteBgpEvpnObject.put("@", getNspModelSources((Map)bgpinst.get(0), aNeId));
			aOutNspExtSiteObject.put("bgp-evpn", aOutExtSiteBgpEvpnObject);
			logger.debug("NeId : {}  networkInstance : {}  evi : {} ",aNeId,netIns,evi);

		}
	}


	@NotNull
	private QueryParameters getlQueryParams() {
		QueryParameters lQueryParams = new QueryParameters();
		IExecutionContext lExecutionContext = new ExecutionContext(null, null, true, false);
		lQueryParams.setIExecutionContext(lExecutionContext);
		return lQueryParams;
	}

	private void setSources(Map aInDevIfFdn, String aInNeId,List<String> lSources,Map<String, Object> lMetaData,Map<String, Object> aOutNspObject) {
		String lSource = Utils.buildSourceFdn(aInDevIfFdn, aInNeId, true);
		lSources.add(lSource);

		lMetaData.put("nsp-model:sources", lSources);
		aOutNspObject.put("@", lMetaData);
	}

	private Map<String, Object> createSyncSiteProp(String aNeId, String netIns, Object aInDeviceObject,IYangDB aInYangDB, List lSources,String lEPParentPath){

		Map<String, Object> lObjectMap = (Map)aInDeviceObject;
		Map<String, Object> aOutNspObject = getOutNspObject(lObjectMap,null);
		aOutNspObject.put("site-id", aNeId);
		aOutNspObject.put("ne-service-id", netIns);
		aOutNspObject.put("name", netIns);
		//aOutNspObject.put("customer-name", "1");
		Object lObjectFdn = lObjectMap.get("_fdn_");
		String lSource = Utils.buildSourceFdn((Map) lObjectFdn, aNeId, true);
		//lSources.add(lSource);
		String vxlanIF = getVxlanIF(lObjectMap);
		if(vxlanIF != null){
			String vxlanFdn = getVxlanFdn(lSource, vxlanIF);
			if(vxlanFdn != null){
				lSources.add(vxlanFdn);
			}
		}
		//BGP-EVPN
		populateBgpEvpnProperties(aNeId,lObjectMap, netIns, aOutNspObject,false);
		//BGP
		populateBgpProperties(lObjectMap, aNeId, netIns, aOutNspObject);
		List endPoints;
		endPoints = createEndpoints(aInYangDB,aNeId,(List)lObjectMap.get("interface"),lEPParentPath);
		if(endPoints != null) {
			aOutNspObject.put("endpoint",endPoints);
		}
		return aOutNspObject;
	}

	private String convertOperState(String aInState){
		if(aInState.equals("up")){
			return "enabled";
		} else if(aInState.equals("down")){
			return "disabled";
		}
		return "unknown";
	}
	private String convertAdminState(String aInState){
		if(aInState.equals("enable")){
			return "unlocked";
		} else if(aInState.equals("disable")){
			return "locked";
		}
		return "unknown";
	}


	private List createEndpoints(IYangDB aInYangDB, String aInNeId, List<Map<String,Object>> endPointDetails, String lEPPathParent) {

		List endPointList = null;
		if(endPointDetails != null && endPointDetails.size() > 0) {
			endPointList = new ArrayList();
			for(Map<String,Object> endPoint : endPointDetails){

				Map<String, Object> lMetaData = new HashMap<>();
				Object lDevFdn = endPoint.get("_fdn_");
				String lEndpointSource = Utils.buildSourceFdn((Map)lDevFdn, aInNeId, true);
				String lEpName = (String) endPoint.get(("name"));//getIfNameFromIfFdn(aInDevIfFdn);
				String lEpEndpointId = aInNeId + "-" + lEpName;
				String lEPPath = lEPPathParent + "']/endpoint[endpoint-id='" + lEpEndpointId + "']";

				if (logger.isDebugEnabled()) {
					logger.debug("lEPPath: " + lEPPath);
				}
				IYangObject lExistSyncEpYo = aInYangDB.getSingle(lEPPath);
				if (null == lExistSyncEpYo) {
					Map<String, Object> lSyncEpProps = new HashMap<String, Object>();
					lSyncEpProps.put("name", lEpName);
					lSyncEpProps.put("endpoint-id", lEpEndpointId);
					lSyncEpProps.put("site-id", aInNeId);

					//YangObject lSyncEpYo = new YangObject(lSyncEpProps);
					List lSources = new ArrayList();
					lSources.add(lEndpointSource);

					lMetaData.put("nsp-model:sources", lSources);
					lSyncEpProps.put("@", lMetaData);

					logger.info("lCreatedSyncEpYo: " + lSyncEpProps.get("name"));
					endPointList.add(lSyncEpProps);
				}
			}
		}
		return endPointList;
	}

	public static String getNeNameByIdFromCache(String aInNeId, QueryParameters aInQueryParameters, IYangDB aInYangDb) {
		Map<String, String> lNeNameCache = neNameCache.get();
		if (null == lNeNameCache) {
			lNeNameCache = new HashMap<>();
			neNameCache.set(lNeNameCache);
			Transactor.getContext().addEventHandler(TxPhase.FINAL, (p, c) -> {
				neNameCache.remove();
			});
		}

		String lFoundNeName = lNeNameCache.get(aInNeId);
		if (null == lFoundNeName) {
			if (logger.isDebugEnabled()) {
				logger.debug("Querying db for ne-name for ne {}", aInNeId);
			}
			String lportFdn = "/nsp-equipment:network/network-element[ne-id='" + aInNeId + "']";
			IYangObject lNeYangObj = aInYangDb.getSingle(lportFdn, aInQueryParameters);
			if (lNeYangObj != null && lNeYangObj.hasProperty("ne-name")) {
				lFoundNeName = (String) lNeYangObj.getProperty("ne-name");
			} else {
				lFoundNeName = "";
			}
			lNeNameCache.put(aInNeId, lFoundNeName);
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("Found ne-name for ne {} in cache", aInNeId);
			}
		}
		return lFoundNeName;
	}

	@Override
	public Map<String, Object> buildFieldFilter(DeviceResyncClass aInDeviceClass, String aInNodeType, String aInNodeVersion) {
		if (fieldFilterMap == null || fieldFilterMap.isEmpty()) {
			try {
				fieldFilterMap =  new ObjectMapper().readValue(fieldFilterRequestJson, HashMap.class);
			} catch (IOException ie) {
				logger.error("Failed to parse type=" + fieldFilterRequestJson + ", [ " + this + " ] ", ie);
				fieldFilterMap = new HashMap();
			}
		}
		logger.debug ("filter request : " + fieldFilterRequestJson);
		return fieldFilterMap;
	}
}

