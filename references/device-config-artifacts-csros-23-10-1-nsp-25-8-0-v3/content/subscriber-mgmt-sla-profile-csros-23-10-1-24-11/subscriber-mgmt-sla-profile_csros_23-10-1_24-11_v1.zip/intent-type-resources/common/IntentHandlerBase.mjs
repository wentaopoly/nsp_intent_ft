/******************************************************************************
 * DEVICE-SPECIFIC INTENT-HANDLER-BASE IMPLEMENTATION
 *
 * (c) 2025 by Nokia
 ******************************************************************************/

import { NSP } from "common/NSP.mjs";
import { WebUI } from "common/WebUI.mjs";

const ValidateResult = Java.type("com.nokia.fnms.controller.ibn.intenttype.spi.ValidateResult");
const SynchronizeResult = Java.type("com.nokia.fnms.controller.ibn.intenttype.spi.SynchronizeResult");
const AuditReport = Java.type("com.nokia.fnms.controller.ibn.intenttype.spi.AuditReport");
const MisAlignedObject = Java.type("com.nokia.fnms.controller.ibn.intenttype.spi.MisAlignedObject");
const MisAlignedAttribute = Java.type("com.nokia.fnms.controller.ibn.intenttype.spi.MisAlignedAttribute");
const RuntimeException = Java.type("java.lang.RuntimeException");
const ArrayList = Java.type("java.util.ArrayList");

/**
 * IntentHandlers implements the formal contract with the intent-engine (JAVA IBN).
 * Implementation is common for device-specific intent-types and must not be changed!
 *
 * Be aware, that the IntentHandlerBase is an abstract base class. To use it, it must be
 * extended/adjusted to the intent-type specific needs. Hooks are provided to enable
 * flexibility. Designers may choose to overwrite members/methods to customize the
 * behavior as needed.
 */

export class IntentHandlerBase extends WebUI
{
  /**
   * Constructor is called during IntentHandler object creation
   *
   * Only one IntentHandler object is created. This object is shared between
   * all intent instances of this intent-type/version. Constructor is called
   * when the intent-type is created/updated in the intent-engine.
   */

  constructor() {
    super();

    this.previousChildrenSet = {};
    this.currentChildrenSet = {};
    this.savedTopology ;
    this.uniqueIdentifierValue;
    this.isAudit = false;
    this.isEdit = false;
    this.fullDeviceConfig = {};
    this.jsonFile = JSON.parse(resourceProvider.getResource("meta-data/property-meta-data.json"));
  }

  /**************************************************************************
   * Intent Hooks
   *
   * Design your own intent-handler class to customize the default behavior.
   * Extend IntentHandler and augment/adjust as needed.
   **************************************************************************/

  /**
   * Hook to add custom intent-type specific validation logic.
   * It will be executed in addition to YANG validation and common validation rules.
   * Default implementation does not have any extra validation rules.
   *
   * @param {string} intentType Inten-type name
   * @param {string} intentTypeVersion Inten-type version
   * @param {string} target Intent target
   * @param {object} config Intent configuration
   * @param {object} contextualErrorJsonObj used to return list of validation errors (key/value pairs)
   */
  validateHook(intentType, intentTypeVersion, target, config, contextualErrorJsonObj) {
  }

  /**
   * Hook to Transform fdn for GreenField Deployment.
   *
   * @param {string} fdn GreenField FDN.
   * @param {Object} intentConfig Intent configuration
   * @param {string} neId Network element identifier
   * @param {boolean} isAudit Flag indicating if the operation is an audit.
   * @returns {string} fdn  Transformed GreenField FDN.
   */
  transformFdnGreenField(fdn, intentConfig, neId, isAudit) {
  	return fdn;
  }

  /**
   * Hook to Transform Object Full Name for GreenField Deployment.
   *
   * @param {string} objectFullName GreenField objectFullName.
   * @param {Object} intentConfig Intent configuration
   * @param {string} neId Network element identifier
   * @param {boolean} isAudit Flag indicating if the operation is an audit.
   * @param {boolean} isDelete Flag indicating if the operation is an delete.
   * @returns {string} objectFullName  Transformed GreenField objectFullName.
   */
  transformObjectFullNameGreenField(objectFullName, intentConfig, neId, isAudit, isDelete) {
  	return objectFullName;
  }

  /**
   * Hook to Transform Local Policy Object FullName for GreenField Deployment.
   *
   * @param {string} localPolicyFullName GreenField localPolicyFullName.
   * @param {Object} objectFullName Object FullName
   * @param {string} neId Network element identifier
   * @param {boolean} isAudit Flag indicating if the operation is an audit.
   * @returns {string} localPolicyFullName  Transformed GreenField localPolicyFullName.
   */
  transformLocalPolicyObjectFullNameGreenField(localPolicyFullName, objectFullName, neId, isAudit) {
  	return localPolicyFullName;
  }

  /**
   * Hook to Transform target value for GreenField Deployment.
   *
   * @param {string} xpath Xpath of the target attribute to be transformed.
   * @param {any} targetValue Original value of the target attribute.
   * @param {string} targetKey Key of the target attribute.
   * @param {string} neId Network element identifier.
   * @param {boolean} isAudit Flag indicating whether the operation is an audit.
   * @returns {any} Transformed value of the target attribute.
   */
  transformTargetValueGreenField(xpath, targetValue, targetKey, neId, isAudit) {
  	return targetValue;
  }

  /**
   * Hook to Transform the Set/List key type based on the provided xpath.
   *
   * @param {string} xpath Xpath of the target attribute.
   * @param {string} keyType Original key type of the Set/List.
   * @returns {string} Transformed key type.
   */
  transformSetListKeyTypeGreenfield(xpath, keyType) {
  	return keyType;
  }

  /**
   * Hook to Transform map key type based on the given XPath for Greenfield context.
   *
   * @param {string} xpath XPath of the map attribute.
   * @param {string} keyType Original key type of the map.
   * @returns {string} Transformed key type for Greenfield.
   */
  transformMapKeyTypeGreenfield(xpath, keyType) {
  	return keyType;
  }

  /**
   * Hook to Transform the payload for GreenField operations.
   *
   * @param {Object} payload Original payload to be transformed.
   * @param {string} neId Network element identifier.
   * @param {boolean} isAudit Flag indicating if the operation is an audit.
   * @returns {Object} Transformed GreenField payload.
   */
  transformPayloadGreenField(payload, neId, isAudit) {
  	return payload;
  }

  /**
   * Hook to Transform the  object Full Name used for distribution.
   *
   * @param {string} objectFullName object Full name to be transformed.
   * @param {Object} intentConfig Intent configuration.
   * @param {Object} payload Payload associated with the distribution.
   * @param {string} neId Network element identifier.
   * @returns {string} Transformed objectFullName used for distribution.
   */
  transformObjectFullNameDistribute(objectFullName, intentConfig, payload, neId) {
    return objectFullName;
  }

  /**
   * Hook to Transform the Local Object Full Name for Distribute operation.
   *
   * @param {string} localObjectFullName Full name of the local policy object to be transformed.
   * @param {object} intentConfig Intent configuration.
   * @param {object} payload Payload associated with the distribution.
   * @param {string} neId Network element identifier.
   * @returns {string} localObjectFullName Transformed localObjectFullName used for distribution.
   */
  transformLocalObjectFullNameDistribute(localObjectFullName, intentConfig, payload, neId) {
    return localObjectFullName;
  }

  /**
   * Hook to Transform Object FullName used for BrownField Discovery.
   *
   * @param {string} objectFullName Full name of the object to be transformed.
   * @param {Object} uniqueIdentifierValues Key-value pairs representing unique identifiers.
   * @param {string} neId Network Element Identifier.
   * @returns {string} objectFullName Transformed objectFullName used for BrownField Discovery.
   */
  transformObjectFullNameBrownField(objectFullName, uniqueIdentifierValues, neId) {
    return objectFullName;
  }

  /**
   * Hook to Transform Set/List key type for Brownfield Discovery.
   *
   * @param {string} xpath Xpath of the attribute being processed.
   * @param {string} keyType Original key type to transform.
   * @returns {string} Transformed key type.
   */
  transformSetListKeyTypeBrownfield(xpath, keyType) {
    return keyType;
  }

  /**
   * Hook to Transform target value during BrownField Discovery.
   *
   * @param {string} xpath - XPath of the target attribute.
   * @param {any} targetValue - Value of the target attribute to be transformed.
   * @param {string} targetKey - Key associated with the target attribute.
   * @param {Object} fullDeviceConfig - Full configuration object of the device.
   * @param {boolean} targetWithTemplate - Flag indicating if target is derived from a template.
   * @returns {any} Transformed target value during BrownField Discovery.
   */
  transformTargetValueBrownField(xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
    return targetValue;
  }

  /**************************************************************************
   * Internal helper methods of IntentHandler
   **************************************************************************/

  /**
   * Extracts the neId from target (ICM-style intents)
   *
   * @param {*} target Target Parameters as passed by IBN
   */
  getNeIdFromTarget(target) {
    const match = target.match(/ne-id='([^']+)'/);
    return match ? match[1] : target.split('#')[1];
  }

  /**
   * Retrieves the device configuration from NFMP for the given target and initial property name.
   * @param {string} target - Target identifier used to derive neId and unique identifiers.
   * @param {string} initialPropertyName - Property name used to determine full class name.
   * @returns {Object} Final parsed response from NFMP search.
   * @throws {RuntimeException} If the search fails or response is invalid.
   */
  getDeviceConfiguration(target, initialPropertyName) {
    const neId = this.getNeIdFromTarget(target);
    this.uniqueIdentifierValue = target.split("#").slice(2);
    let fullClassName = initialPropertyName.replace("-", ".");
    let objectFullName = this.getObjectFullName(this.brownFieldObjectFullName, this.uniqueIdentifierValue, neId);
    objectFullName = this.transformObjectFullNameBrownField(objectFullName, this.uniqueIdentifierValue, neId);
    logger.info("objectFullName = {}", objectFullName);

    const searchPayLoad = {
      fullClassName,
      filter: { equal: { name: "objectFullName", value: objectFullName } }
    };

    const searchResponse = NSP.nfmpPOST(neId, "/v3/search", searchPayLoad);
    logger.info("searchResponse == {}", JSON.stringify(searchResponse));

    const finalResponse = JSON.parse(searchResponse.response);
    logger.info("Final response of search = {}", JSON.stringify(finalResponse));

    if (!searchResponse.success || !(Object.keys(finalResponse).length && finalResponse.constructor === Object)) {
      throw new RuntimeException(`Failed to find the object : objectFullName = ${objectFullName}, fullClassName = ${fullClassName}`);
    }

    return finalResponse;
  }

  /**
   * Extracts and transforms device configuration data into the intentConfig for BrownField Discovery.
   *
   * @param {string} defaultTargetData - JSON string containing default intent Template with null values.
   * @param {Object} deviceConfig - Device-specific configuration values.
   * @param {string} initialPropertyName - Property name used to determine full class name..
   * @param {string} targetWithTemplate - Target with Template info in it.
   * @returns {Object} Parsed and cleaned configuration object updated with device-specific data.
   */
  extractDeviceConfig(defaultTargetData, deviceConfig, initialPropertyName, targetWithTemplate) {
    let parsedDefaultTargetData = JSON.parse(defaultTargetData);
    logger.info("***********************************deviceConfig***********************************************");
    logger.info(JSON.stringify(deviceConfig));
    logger.info("************************************parsedDefaultTargetData***********************************");
    logger.info(JSON.stringify(parsedDefaultTargetData));
    logger.info("**************************************************END******************************************");
    if (deviceConfig)
    {
        this.fullDeviceConfig = deviceConfig[initialPropertyName.replace("-", ".")];
        this.traverseProperties(targetWithTemplate, parsedDefaultTargetData[initialPropertyName], deviceConfig[initialPropertyName.replace("-", ".")]);
    }
    this.removeNullAndEmptyKeys(parsedDefaultTargetData);
    this.clearEmpties(parsedDefaultTargetData);
    logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData));
    return parsedDefaultTargetData;
  }

  /**
   * Traverse and map deviceConfig values onto a parsed default template object.
   * Handles nested objects, arrays, and special types (map, set, list).
   *
   * @param {Object} targetWithTemplate - Base object that tracks transformations
   * @param {Object} parsedDefaultTargetData - Parsed template with default values to populate
   * @param {Object} deviceConfig - Configuration values to overlay
   * @param {String} xpath - Dot-separated path to current location in object tree
   */
  traverseProperties(targetWithTemplate, parsedDefaultTargetData, deviceConfig, xpath) {
    if (!deviceConfig) return;
    Object.keys(parsedDefaultTargetData).forEach((targetKey) => {
      let targetValue = parsedDefaultTargetData[targetKey],
        attributeDataType = this.jsonFile[targetKey],
        isMapSetList = ["map", "set", "list"].includes(attributeDataType?.dataTypeInfo?.type),
        parentXpath = xpath ? `${xpath}.${targetKey}` : targetKey;

      if (targetValue && typeof targetValue === "object" && !isMapSetList) {
        if (deviceConfig["children-Set"]) {
          let deviceChildConfig = deviceConfig["children-Set"][targetKey.replace(/-/g, ".")];
          if (Array.isArray(targetValue)) {
            let obj = JSON.parse(JSON.stringify(targetValue[0])), keyId = 1;
            deviceChildConfig = Array.isArray(deviceChildConfig) ? deviceChildConfig : [deviceChildConfig];
            deviceChildConfig.forEach((child, index) => {
              let objClone = JSON.parse(JSON.stringify(obj));
              if (child) {
                  if(objClone.hasOwnProperty("key-id")) objClone["key-id"] = keyId++;
                  this.traverseProperties(targetWithTemplate, objClone, child, parentXpath);
              }
              targetValue[index] = objClone;
            });
          } else {
            this.traverseProperties(targetWithTemplate, targetValue, deviceChildConfig, parentXpath);
          }
        }
      } else {
        if (typeof deviceConfig[targetKey] === "object" && !targetKey.includes("-")) {
          let data = deviceConfig[targetKey];
          if (Array.isArray(data)) {
            if (isMapSetList) {
              let dataType = attributeDataType.dataTypeInfo.type;
              if (["set", "list"].includes(dataType)) {
                let keyType = attributeDataType.dataTypeInfo.typeListProperties.type.toLowerCase();
                keyType = this.transformSetListKeyTypeBrownfield(parentXpath, keyType);
                let transformed = data.map(obj => ({ [keyType]: obj }));
                let val = this.transformTargetValueBrownField(parentXpath, transformed, targetKey, this.fullDeviceConfig, targetWithTemplate);
                parsedDefaultTargetData[targetKey] = val;
              } else if (dataType === "map") {
                let deviceValue = this.transformTargetValueBrownField(parentXpath, data, targetKey, this.fullDeviceConfig, targetWithTemplate);
                parsedDefaultTargetData[targetKey] = deviceValue;
              }
            } else {
              let bitData = data.reduceRight((acc, cur) => `${cur} ${acc}`, '').trim();
              let deviceValue = this.transformTargetValueBrownField(parentXpath, bitData, targetKey, this.fullDeviceConfig, targetWithTemplate);
              parsedDefaultTargetData[targetKey] = deviceValue;
            }
          } else {
            let deviceValue = this.transformTargetValueBrownField(parentXpath, data, targetKey, this.fullDeviceConfig, targetWithTemplate);
            parsedDefaultTargetData[targetKey] = deviceValue;
          }
        } else if (targetKey !== "key-id" && deviceConfig[targetKey]?.length > 0) {
          let deviceValue = this.transformTargetValueBrownField(parentXpath, deviceConfig[targetKey], targetKey, this.fullDeviceConfig, targetWithTemplate);
          parsedDefaultTargetData[targetKey] = deviceValue;
        }
      }
      logger.info("targetKey = {}, targetValue = {}, deviceConfig = {}", targetKey, JSON.stringify(targetValue), JSON.stringify(deviceConfig[targetKey]));
    });
  }

  /**
   * Removes null values and empty objects recursively from a configuration object.
   *
   * @param {Object} cfg Configuration object to be cleaned.
   * @returns {void} Modifies the input object in place, removing nulls and empty objects.
   */
  removeNullAndEmptyKeys(cfg) {
    Object.keys(cfg).forEach(key => {
        if(cfg[key] === null || (typeof cfg[key] === 'object' && Object.keys(cfg[key]).length === 0))
            delete cfg[key];
        else if (typeof cfg[key] === 'object')
            this.removeNullAndEmptyKeys(cfg[key]);  // Recursively process nested objects
    });
  }

  /**
   * Recursively removes empty nested objects from a given object.
   *
   * @param {Object} o The object to clean by removing all empty nested objects.
   * @returns {void}
   */
  clearEmpties(o) {
    for (let k in o) {
      if (o[k] && typeof o[k] === "object") {
        this.clearEmpties(o[k]);
        if (!Object.keys(o[k]).length) delete o[k];
      }
    }
  }

  /**
   * Updates auditReport with misaligned Attribute/Object.
   * @param {Object} target - The target object being audited.
   * @param {Object} result - The result object containing the audit response.
   * @param {Object} auditReport - The audit report to be updated.
   * @returns {Object} - The updated auditReport.
   */
  reportMisaligned(target, result, auditReport) {
    let report = JSON.parse(result.response);
    if (!report.aligned) report.misalignedAttributes.forEach(attributeData => {
      let objectDn = attributeData.name, isUndesired = attributeData.expected === "not present";
      if (attributeData.expected === "present" || isUndesired)
        auditReport.addMisAlignedObject(auditFactory.createMisAlignedObject(objectDn, isUndesired));
      else
        auditReport.addMisAlignedAttribute(auditFactory.createMisAlignedAttribute(objectDn, String(attributeData.expected), String(attributeData.actual), target));
    });
    return auditReport;
  }


  /**
   * Distributes global policy to local
   * @param neId
   * @param objectFullName
   * @param isLocalEdit
   * @returns {{}}
   */
  distribute(neId, objectFullName, isLocalEdit) {
    const policyDefination = isLocalEdit
      ? "policy.PolicyDefinition.setDistributionModeToLocalEditOnly"
      : "policy.PolicyDefinition.distributeV2";
    return {
      [policyDefination]: {
        clearOnDeployFailure: true,
        deployer: "immediate",
        instanceFullName: objectFullName,
        siteIds: { string: neId }
      }
    };
  }

  /**
   * Resends the given payload to a local object with updated full name.
   * @param {string} neId - Network element ID.
   * @param {Object} payload - Configuration payload.
   * @param {string} localObjectFullName - Fully qualified name of local object.
   */
  resendPayloadToLocal(neId, payload, localObjectFullName) {
      payload["objectFullName"] = localObjectFullName;
      logger.info("Modified payload for resending to local = " + JSON.stringify(payload));
      this.modifyRequest(neId, payload);
  };

  /**
   * Sends a modify request for NFMP deployment.
   * Logs payload and handles errors, including specific checks for policy intent collisions.
   *
   * @param {string} neId - The network element ID.
   * @param {Object} payload - The payload containing configuration data.
   * @returns {Object} result - The result of the deployment.
   * @throws {RuntimeException} If deployment fails and policy object is not found.
   */
  modifyRequest(neId, payload) {
      logger.info("-------------------- IntentHandlerBase.mjs -> modifyRequest() --------------------");
      logger.info("Sending the modify request for mdt");
      logger.info(JSON.stringify(payload));

      const result = NSP.nfmpDeploy(neId, JSON.stringify(payload), "application/json");

      if (!result.success) {
          logger.error("Error result = {}", JSON.stringify(result));
          const errorMsg = result.msg;

          if (this.isPolicyIntent && errorMsg.includes("object already exists")) {
              logger.info("Global policy Object already exists, Re-checking the Policy existence ");
              const configInfo = payload.configInfo;
              const fullClassName = Object.keys(configInfo)[0];
              const objectFullName = payload.objectFullName;

              logger.info("fullClassName = {}", fullClassName);
              logger.info("objectFullName = {}", objectFullName);

              if (!this.isObjectExists(neId, fullClassName, objectFullName)) {
                  throw new RuntimeException("Global Policy Object Not Found!!!");
              }
          } else {
              throw new RuntimeException(errorMsg);
          }
      }

      return result;
  };

  /**
   * Recursively removes all properties named "key-id" from an object,
   * including nested objects.
   *
   * @param {Object} obj - The object to process.
   */
  removeKeysId(obj) {
      Object.keys(obj).forEach(key => {
          if (key === "key-id") {
              delete obj[key];
          } else if (typeof obj[key] === 'object') {
              this.removeKeysId(obj[key]);
          }
      });
  }

  /**
   * Recursively compares previousData and currentData objects.
   * If the currentData is missing properties present in previousData,
   * it attempts to either compare them or remove/add appropriate children structures.
   *
   * @param {Object} previousData - The source object to compare from.
   * @param {Object} currentData - The target object to compare to.
   */
  compare(previousData, currentData) {
    for (const previousDataKey in previousData) {
      if (typeof previousData[previousDataKey] === 'object') {
        const previousChildKey = previousDataKey;
        const previousChild = previousData[previousDataKey];
        const currentChild = currentData[previousDataKey];
        if (Array.isArray(previousChild) && Array.isArray(currentChild)) {
          this.iterateArrayObject(previousChild, currentChild);
          continue;
        }
        currentChild ? this.compare(previousChild, currentChild) : this.removeChildrenFromCurrent(previousChild, currentData, previousChildKey);
      }
    }
  }

  /**
   * Handles the case where a key in previousData does not exist in currentData.
   * If the key is "children-Set", it adds an empty object or array entries.
   * Otherwise, it checks jsonFile for the attribute type and sets default values.
   *
   * @param {Object} previousChild - The child object from previousData.
   * @param {Object} currentData - The target object to update.
   * @param {string} key - The missing key being handled.
   */
  removeChildrenFromCurrent(previousChild, currentData, key) {
    if (key === "children-Set") {
      currentData['children-Set'] ??= {};
      for (const previousChildKey in previousChild) {
        const previousChildObj = previousChild[previousChildKey];
        if (typeof previousChildObj === 'object' && Array.isArray(previousChildObj)) {
          currentData['children-Set'][previousChildKey] = [];
        }
      }
    } else {
      currentData[key] = [];
      const attributeDataType = this.jsonFile[key];
      const type = attributeDataType?.dataTypeInfo?.type;
      if (["map", "set", "list"].includes(type)) currentData[key] = "";
    }
  }

  /**
   * Iterates through two arrays of objects and recursively compares matched elements by "key-id".
   *
   * @param {Array<Object>} previousChild - The array from previousData.
   * @param {Array<Object>} currentChild - The array from currentData.
   */
  iterateArrayObject(previousChild, currentChild) {
    for (const previousChildElement of previousChild) {
      const previousChildObj = previousChildElement;
      const currentChildObj = currentChild.find(currentChildElement => currentChildElement["key-id"] === previousChildObj["key-id"]);
      if (currentChildObj) this.compare(previousChildObj, currentChildObj);
    }
  }

  /**
   * Checks if an object exists by querying a backend search API.
   *
   * @param {string} className - The full class name to search for.
   * @param {string} objectFullName - The specific object name to match.
   * @returns {boolean} - True if object exists, false otherwise.
   */
  isObjectExists(neId, className, objectFullName) {
    let searchObjectJson = { fullClassName: className, filter: { equal: { name: "objectFullName", value: objectFullName }}},
        resultFetch = NSP.nfmpPOST(neId, "/v3/search", searchObjectJson),
        finalResponse = JSON.parse(resultFetch.response),
        ret = finalResponse.constructor === Object && Object.keys(finalResponse).length !== 0;

    logger.info("isObjectExists data = {}", JSON.stringify(resultFetch));
    logger.info("Final response of search = {}", JSON.stringify(finalResponse));
    logger.info("isObjectExists = {} ", ret);
    return ret;
  };

  /**
   * Delays the execution
   * Sometimes the object creation takes time, we can use delay for child-level operation.
   * @param milliseconds
   */
  delay(milliseconds) {
    let date = new Date();
    date.setMilliseconds(date.getMilliseconds() + milliseconds);
    while (new Date() < date) {}
  }

  /**
   * Generates and transforms intent configuration to payload structure for GreenField/Audit operations.
   *
   * @param {string} neId - Network Element Identifier.
   * @param {Object|Array} modifiedIntentConfig - Object or Array to store modified intent configuration in payload structure.
   * @param {Object} intentConfig - Original intent configuration to process.
   * @param {string} parentXpath - Xpath representing the parent path of current attribute.
   * @returns {void}
   */
  generateJson(neId, modifiedIntentConfig, intentConfig, parentXpath) {
    logger.info("-------------------- IntentHandlerBase.mjs -> generateJson() --------------------");

    let keys = Object.keys(intentConfig);
    let modifiedArrarIntentConfig = {};

    keys.forEach(targetKey => {
      let targetValue = intentConfig[targetKey];
      let attributeDataType = this.jsonFile[targetKey];
      let isMapSetList = ['map', 'set', 'list'].includes(attributeDataType?.dataTypeInfo?.type);

      let isObject = targetValue !== null && typeof targetValue === 'object' && !isMapSetList;
      let xpath = parentXpath ? `${parentXpath}.${targetKey}` : targetKey;

      if (isObject) {
        if (Array.isArray(modifiedIntentConfig)) {
          this.updateChildrenSet(neId, modifiedArrarIntentConfig, targetKey, targetValue, parentXpath);
        } else {
          this.updateChildrenSet(neId, modifiedIntentConfig, targetKey, targetValue, parentXpath);
        }
      } else {
        targetValue = this.transformTargetValueGreenField(xpath, targetValue, targetKey, neId, this.isAudit);

        let applyValue = (store, key, value) => {
          store[key] = value;
        };

        let targetStore = Array.isArray(modifiedIntentConfig) ? modifiedArrarIntentConfig : modifiedIntentConfig;

        if (targetKey !== "key-id" && this.jsonFile[targetKey]?.dataTypeInfo) {
          let dataType = this.jsonFile[targetKey].dataTypeInfo.type;

          if (dataType === "bitmask") {
            let bit = targetValue.split(" ");
            applyValue(targetStore, targetKey, this.isAudit ? bit : (bit.length > 1 ? { bit } : bit));
          } else if (dataType === "set" || dataType === "list") {
            let keyType = this.jsonFile[targetKey].dataTypeInfo.typeListProperties.type.toLowerCase();
            keyType = this.transformSetListKeyTypeGreenfield(xpath, keyType);
            let keyTypeValue = targetValue.map(item => item[Object.keys(item)[0]]);
            applyValue(targetStore, targetKey, this.isAudit ? keyTypeValue : (keyTypeValue.length ? { [keyType]: keyTypeValue } : ""));
          } else if (dataType === "map") {
            let keyType = this.transformMapKeyTypeGreenfield(xpath, "item");
            let keyTypeValue = targetValue.map(obj => ({ key: obj.key, value: obj.value }));
            applyValue(targetStore, targetKey, this.isAudit ? keyTypeValue : (keyTypeValue.length ? { [keyType]: keyTypeValue } : ""));
          } else {
            applyValue(targetStore, targetKey, targetValue);
          }
        } else {
          applyValue(targetStore, targetKey, targetValue);
        }
      }
    });

    if (Array.isArray(modifiedIntentConfig)) {
      modifiedIntentConfig.push(modifiedArrarIntentConfig);
    }
  }

  /**
   * Updates the `children-Set` section of the modified intent config with payload structured data.
   *
   * @param {string} neId - Network element identifier.
   * @param {Object} modifiedIntentConfig - The object being updated with children data.
   * @param {string} targetKey - Key identifying the current child node.
   * @param {Object|Array} targetValue - Value(s) to insert under the child node.
   * @param {string} xpath - Xpath of the current element, used to track hierarchy.
   */
  updateChildrenSet(neId, modifiedIntentConfig, targetKey, targetValue, xpath) {
    logger.info("-------------------- IntentHandlerBase.mjs -> updateChildrenSet() --------------------");

    if (!modifiedIntentConfig["children-Set"]) {
      modifiedIntentConfig["children-Set"] = {};
    }

    let parentXpath = xpath ? `${xpath}.${targetKey}` : targetKey;
    let className = targetKey.replace("-", ".");

    if (Array.isArray(targetValue)) {
      modifiedIntentConfig["children-Set"][className] = [];
      targetValue.forEach(val => {
        this.generateJson(neId, modifiedIntentConfig["children-Set"][className], val, parentXpath);
      });
    } else {
      modifiedIntentConfig["children-Set"][className] = {};
      this.generateJson(neId, modifiedIntentConfig["children-Set"][className], targetValue, parentXpath);
    }
  }

  /**
   * Removes attributes from intent configuration that are unsupported for the specified NE/chassis Type.
   *
   * @param {Object} intentConfig Intent configuration.
   * @param {string} neId Network element identifier used to determine NE chassis, version & type.
   */
  removeUnsupportedAttributes(intentConfig, neId) {
  	logger.info("-------------------- IntentHandlerBase.mjs -> removeUnsupportedAttributes() --------------------");
    let neFamily = mds.getAllInfoFromDevices(neId).get(0).getFamilyTypeRelease(),
          neType = neFamily.split(":")[0],
          neVersion = neFamily.split(":")[1],
          neChassisType = neFamily.split(":")[2],
          unsupportedJson = JSON.parse(resourceProvider.getResource("custom/intent-deviations.json")),
          unsupportedAttribute = [];

    if (unsupportedJson[neType]) {
      unsupportedJson[neType].forEach(({["chassis-types"]: chassisType, ["versions"]: neVersions, ["unsupported-attributes"]: attrs}) => {
        if ((chassisType.length === 0 || chassisType.includes(neChassisType)) &&
            (neVersions.length === 0 || neVersions.includes(neVersion))) {
            unsupportedAttribute.push(...attrs);
        }
      });
    }

    logger.info("unsupportedAttribute = {}", JSON.stringify(unsupportedAttribute));
    if (unsupportedAttribute.length) this.removeAttributes(intentConfig, unsupportedAttribute);
  }

  /**
   * Recursively removes unsupported attributes from an intent configuration object.
   *
   * @param {Object} intentConfig Intent configuration
   * @param {Array<string>} unsupportedAttribute List of unsupported attribute paths to be removed.
   * @param {string} [parent=""] Internal use for tracking nested attribute paths used during recursion.
   */
  removeAttributes(intentConfig, unsupportedAttribute, parent = "") {
    for (let key in intentConfig) {
      const attr = parent ? `${parent}.${key}` : key;
      if (unsupportedAttribute.includes(attr)) {
        logger.info("removing  = {}", key);
        delete intentConfig[key];
      } else if (typeof intentConfig[key] === 'object') {
          Array.isArray(intentConfig[key])
            ? intentConfig[key].forEach(i => this.removeAttributes(i, unsupportedAttribute, key))
            : this.removeAttributes(intentConfig[key], unsupportedAttribute, key);
      }
    }
  }

  /**
   * Resolves placeholders (e.g. $systemAddress) in objectFullName with values from intentConfig or neId.
   *
   * @param {string} objectFullName - The objectFullName with placeholders to be resolved.
   * @param {object|array} valuesSource - Either an intentConfig during GreenField Deployment or uniqueIdentifierValues array during BrownField Discovery.
   * @param {string} neId - Network Element ID, used for $systemAddress and formatting.
   * @returns {string} - Fully resolved object name.
   */
   getObjectFullName(objectFullName, valuesSource, neId) {
    let result = objectFullName.replace(/\*/g, ""), inputString = result, dollarIndex = inputString.indexOf('$'), indexCounter = 0;
    while (dollarIndex !== -1) {
      let nextHyphenIndex = inputString.indexOf('-', dollarIndex), nextColonIndex = inputString.indexOf(':', dollarIndex), nextHashIndex = inputString.indexOf('#', dollarIndex),
          endIndex = [nextHyphenIndex, nextColonIndex, nextHashIndex].filter(i => i !== -1).reduce((a, b) => Math.min(a, b), inputString.length),
          substring = inputString.substring(dollarIndex + 1, endIndex), replaceSubstring = inputString.substring(dollarIndex, endIndex),
          //for non satellite shelf the default shelfId = 1 & for Router instance id the default routingInstanceId = 1
          value = substring === "systemAddress" ? neId :
                  (inputString.includes(":shelf-$id") && substring === "id") || (inputString.includes(":router-$routingInstanceId") && substring === "routingInstanceId") ? 1 :
                  Array.isArray(valuesSource) ? valuesSource[indexCounter++] : valuesSource[substring];
      result = result.replace(replaceSubstring, value);
      dollarIndex = inputString.indexOf('$', dollarIndex + 1);
    }
    return (neId && String(neId).includes(':')) ? result.replace(neId, neId.replaceAll(":", "_")) : result;
  }

  /**
   * Creates a configuration payload for deployment or audit from intent configuration.
   *
   * @param {string} neId Network Element Identifier.
   * @param {Object} intentConfig Configuration object containing intent data.
   * @param {string} initialPropertyName Initial property name used to derive the class name.
   * @returns {Object} currentChildrenSet The configuration payload to be used for deployment or audit.
   */
  createConfigPayLoad(neId, intentConfig, initialPropertyName){
    logger.info("-------------------- IntentHandlerBase.mjs -> createConfigPayLoad() --------------------");
  	if (this.savedTopology == null)
      this.savedTopology = topologyFactory.createServiceTopology();
    let fullClassName = initialPropertyName.replace("-", ".");

    let fdn = this.getObjectFullName(this.greenFieldFDN,intentConfig,neId);
    fdn = this.transformFdnGreenField(fdn, intentConfig, neId, this.isAudit);

    let objectFullName = this.getObjectFullName(this.greenFieldObjectFullName,intentConfig,neId);
    objectFullName = this.transformObjectFullNameGreenField(objectFullName, intentConfig, neId, this.isAudit);
    logger.info("objectFullName = {}", objectFullName);
    logger.info("fdn = {}", fdn);
    let localPolicyFullName = "network:" + neId + ":" + objectFullName;
    if (neId && String(neId).indexOf(':') !== -1)
      localPolicyFullName = localPolicyFullName.replace(neId, neId.replaceAll(":","_"));
    localPolicyFullName = this.transformLocalPolicyObjectFullNameGreenField(localPolicyFullName, objectFullName, neId, this.isAudit);

    let objectFullNameToBeDeployed = objectFullName;
    if (this.isPolicyIntent) {
      if (this.isObjectExists(neId, fullClassName, localPolicyFullName) || this.isAudit) {
        objectFullNameToBeDeployed = localPolicyFullName;
        if(!this.isAudit) this.isEdit = true;
      }
      logger.info("localPolicyFullName = {}", localPolicyFullName);
	  }

    let addLocalObjectFullName = true, addObjectFullName = true;
    for (let index in this.savedTopology.getXtraInfo()) {
      let xtraInfo = this.savedTopology.getXtraInfo()[index].getKey();
      if (xtraInfo === "objectFullName") addObjectFullName = false;
      if (this.isPolicyIntent && xtraInfo === "localObjectFullName") addObjectFullName = false;
    }
    if (addObjectFullName) {
      logger.info("Adding objectFullName to save topology");
      this.savedTopology.addXtraInfo(topologyFactory.createTopologyXtraInfoFrom("objectFullName", objectFullName));
    }
    if (this.isPolicyIntent && addLocalObjectFullName) {
      logger.info("Adding addLocalObjectFullName to save topology");
      this.savedTopology.addXtraInfo(topologyFactory.createTopologyXtraInfoFrom("localObjectFullName", localPolicyFullName));
    }
    logger.info("Removing unsupported attributes")
    this.removeUnsupportedAttributes(intentConfig, neId);
    logger.info("intentConfig after removing unsupported attributes = {} ", JSON.stringify(intentConfig));
    let modifiedIntentConfig = {};
    this.generateJson(neId, modifiedIntentConfig, intentConfig)
    logger.info("modifiedIntentConfig = {}",JSON.stringify(modifiedIntentConfig))
    let payload = {
	    "distinguishedName": fdn,
	    "objectFullName": objectFullNameToBeDeployed,
	    "clearOnDeployFailure": true,
	    "configInfo": { [fullClassName]: modifiedIntentConfig }
	};
	let currentChildrenSet = JSON.parse(JSON.stringify(payload));
	this.savedTopology.addXtraInfo(topologyFactory.createTopologyXtraInfoFrom("childrenSet", JSON.stringify(currentChildrenSet)));
	logger.info("Previous Children set = {}", JSON.stringify(this.previousChildrenSet));
	logger.info("Current Children set = {}", JSON.stringify(currentChildrenSet));
	this.compare(this.previousChildrenSet, currentChildrenSet);
	this.removeKeysId(currentChildrenSet);
	this.transformPayloadGreenField(currentChildrenSet, neId, this.isAudit);
	logger.info("payload = {}", JSON.stringify(currentChildrenSet));
    return currentChildrenSet;
  }


  /**************************************************************************
   * Public methods of IntentHandler
   *
   * Entrypoints defined/called by IBN Engine (JAVA)
   **************************************************************************/

  /**
   * Validation of intent config/target that is automatically called for intent
   * create/edit and state-change operations.
   *
   * If the intent config is identified invalid, the create/edit operation will
   * fail. Execution happens before synchronize() to ensure intent data is valid.
   *
   * In this particular case we are validating if the device is known to the
   * mediator and if the corresponding freemarker template (ftl) could be loaded.
   *
   * @param {SynchronizeInput} input input provided by intent-engine
   * @returns {ValidateResult}
   *
   * @throws ContextErrorException
   */

  validate(input) {
    const startTS = Date.now();
    logger.info("IntentHandler::validate()");

    const target = input.getTarget();
    const intentType = input.getIntentType();
    const intentTypeVersion = input.getIntentTypeVersion();

    const config = JSON.parse(input.getJsonIntentConfiguration())[0];

    const contextualErrorJsonObj = {};
    const validateResult = new ValidateResult();

    const neId = this.getNeIdFromTarget(target);
    const neInfo = mds.getAllInfoFromDevices(neId);

    if (neInfo === null || neInfo.size() === 0) {
      contextualErrorJsonObj["Node not found"] = neId;
    } else {
      const neFamilyTypeRelease = neInfo.get(0).getFamilyTypeRelease();
      if (neFamilyTypeRelease === null) {
        contextualErrorJsonObj["Family/Type/Release unkown"] = neId;
      }
    }

    this.validateHook(intentType, intentTypeVersion, target, config, contextualErrorJsonObj);

    const duration = Date.now()-startTS;
    logger.info("IntentHandler::validate() finished within {} ms", duration|0);

    if (Object.keys(contextualErrorJsonObj).length !== 0)
      utilityService.throwContextErrorException(contextualErrorJsonObj);

    return validateResult;
  }

  /**
   * Deployment of intents to the network, called for synchronize operations.
   * Used to apply create, update, delete and reconcile to managed devices.
   *
   * @param {SynchronizeInput} input information about the intent to be synchronized
   * @returns {SynchronizeResult} provide information about the execution/success back to the engine
   */

  async synchronize(input) {
    logger.info("Intent Synchronisation started - input = {}", input)
    const startTS = Date.now(),
          state = input.getNetworkState().name(),
          target = input.getTarget(),
          intentType = input.getIntentType(),
          intentTypeVersion = input.getIntentTypeVersion(),
          syncResult = new SynchronizeResult(),
          neId = this.getNeIdFromTarget(target);
    this.isAudit = false;
    this.isEdit = false;
    logger.info("IntentHandler::synchronize() in state {} ", state);
    this.savedTopology = input.getCurrentTopology();
    let lConfig = JSON.parse(input.getJsonIntentConfiguration())[0],
        intentConfig = lConfig[Object.keys(lConfig)[0]][this.initialPropertyName];
    logger.info("Initial intentConfig = {} ", JSON.stringify(intentConfig));
    this.uniqueIdentifierValue = input.getTarget().split("#").slice(2);
    this.uniqueIdentifier.split(",").forEach((value, index) => intentConfig[value] = this.uniqueIdentifierValue[index]);

    if (state === "delete") {
      let objectFullName;
      for (let xtraInfo of this.savedTopology.getXtraInfo()) {
        let key = xtraInfo.getKey(), value = xtraInfo.getValue();
        if (key === "objectFullName" || key === "localObjectFullName") {
            objectFullName = value;
            if (key === "localObjectFullName") break;
        }
      }
      objectFullName = objectFullName.replaceAll("#", "%23");
      if (neId?.includes(':')) objectFullName = objectFullName.replace(neId, neId.replaceAll(":", "_"));
      objectFullName = this.transformObjectFullNameGreenField(objectFullName, intentConfig, neId, this.isAudit, true);
      logger.info("Deleting " + objectFullName);
      let deleteResult = NSP.nfmpDeployDelete(neId, objectFullName, "application/json");
      if (!deleteResult.success) throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
      syncResult.setSuccess(true);
      logger.info("IntentHandler::synchronize() finished within {} ms", (Date.now() - startTS) | 0);
      return syncResult;
    }

    this.removeNullAndEmptyKeys(intentConfig);

    if (this.savedTopology) {
      this.savedTopology.getXtraInfo().forEach(entry => { if (entry.getKey() === "childrenSet") this.previousChildrenSet = JSON.parse(entry.getValue()); });
      logger.info("previousChildrenSet = {}", JSON.stringify(this.previousChildrenSet));
    }

    let payload = this.createConfigPayLoad(neId, intentConfig, this.initialPropertyName);
    this.modifyRequest(neId, payload);

    if (this.isPolicyIntent && !this.isEdit) {
      // Distribute Global Policy to Ne in Target
      const url = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true";
      logger.info("Distributing the policy to local");
      let fullClassName = this.initialPropertyName.replace("-", "."),
          objectFullName,
          localObjectFullName;
      this.savedTopology.getXtraInfo().forEach(entry => {
        let key = entry.getKey(), value = entry.getValue();
        if (key === "objectFullName") objectFullName = value;
        if (key === "localObjectFullName") localObjectFullName = value;
      });

      objectFullName = this.transformObjectFullNameDistribute(objectFullName, intentConfig, payload, neId);
      localObjectFullName = this.transformLocalObjectFullNameDistribute(localObjectFullName, intentConfig, payload, neId);
      if (neId.includes(':')) {
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":", "_"));
        localObjectFullName = localObjectFullName.replace(neId, neId.replaceAll(":", "_"));
      }

      logger.info("Distribute objectFullName = {}", objectFullName);
      let distributePayload = this.distribute(neId, objectFullName, false), distributeResult = NSP.nfmpPOST(neId, url, distributePayload);
      if (!distributeResult.success) throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg);
      this.delay(2000);
      // Changing SyncWithGlobal To Local Edit Only
      distributePayload = this.distribute(neId, objectFullName, true); distributeResult = NSP.nfmpPOST(neId, url, distributePayload);
      if (!distributeResult.success) throw new RuntimeException('Unable to Distribute Policy: ' + r.msg);
      this.delay(2000);
      //check if local policy got created, if not throw error, because clearOnDeploy will not give any error if distribute fails.
      logger.info("Checking if local policy object");
      if (!this.isObjectExists(neId, fullClassName, localObjectFullName))
          throw new RuntimeException("Unable to find local Policy : '" + localObjectFullName + "', for the Class Name: '" + fullClassName + "'. Please check NFMP for any deployment errors.");
      //resend the payload to local to make sure the correct data is updated
      //becuase during multiple/simultaneous distribute, where one node supports a property and nother node doesnt
      //support a property, then by the time the distrubute to node with supported property hits
      //the global might have been got modified
      this.resendPayloadToLocal(neId, payload, localObjectFullName);
    }

    syncResult.setSuccess(true);
    if (this.savedTopology !== undefined) {
      syncResult.setTopology(this.savedTopology);
      syncResult.getTopology().setXtraInfo(this.savedTopology.getXtraInfo());
    }

    logger.info("IntentHandler::synchronize() finished within {} ms", (Date.now() - startTS) | 0);
    return syncResult;
  }

  /**
   * Method to audit intents. Renders the desired configuration (same
   * as synchronize) and retrieves the actual configuration from MDC.
   * Compares actual against desired configuration to produce the AuditReport.
   *
   * @param {AuditInput} input input provided by intent-engine
   * @returns {AuditReport} audit report
   */

  async onAudit(input) {
    logger.info("Intent Audit started - input = {}", input)
    const startTS = Date.now(),
          state = input.getNetworkState().name(),
          target = input.getTarget(),
          intentType = input.getIntentType(),
          intentTypeVersion = input.getIntentTypeVersion();

    logger.info("IntentHandler::onAudit() in state {} ", state);

    let auditReport = new AuditReport();
    auditReport.setIntentType(intentType);
    auditReport.setTarget(target);
    this.isAudit = true;

    const neId = this.getNeIdFromTarget(target),
          lConfig = JSON.parse(input.getJsonIntentConfiguration())[0],
          intentConfig = lConfig[Object.keys(lConfig)[0]][this.initialPropertyName];

    logger.info("intentConfig = {} ", JSON.stringify(intentConfig));

    this.uniqueIdentifierValue = target.split("#").slice(2);
    this.uniqueIdentifier.split(",").forEach((value, index) => intentConfig[value] = this.uniqueIdentifierValue[index]);

    this.removeNullAndEmptyKeys(intentConfig);

    logger.info("auditing configuration = " + JSON.stringify(intentConfig));
    logger.info("Target device = " + neId);

    if (!intentConfig) throw "configuration not available in the intent";

    const payload = this.createConfigPayLoad(neId, intentConfig, this.initialPropertyName);
    logger.info("Sending the audit request for mdt\n{}", JSON.stringify(payload));

    const result = NSP.nfmpCompare(neId, JSON.stringify(payload), "application/json");
    if (!result.success) throw new RuntimeException(result.msg);

    auditReport = this.reportMisaligned(neId, result, auditReport);

    logger.info("IntentHandler::onAudit() finished within {} ms", (Date.now() - startTS) | 0);
    return auditReport;
  }

  /**
   * Backend implementation for rpc get-target-data. Used to create/update ICM intent
   * configuration from existing network device configuration (brownfield discovery).
   *
   * Implementation is for device-specific intent-types (100% attribute coverage/exposure).
   * To support future nodal releases, removing all "unknown" attributes (not captured as
   * part of the intent-model at auto-generation time) should be considered.
   *
   * @param {object} input Object including RPC input and intent information
   * @returns {string} RPC output as XML string
   */

  getTargetData(input) {
    const startTS = Date.now();
    logger.info("-------------------- IntentHandlerBase.mjs -> getTargetData() --------------------");
    logger.info("getTargetData input for brownfield = \n" + input);
    const target = input.getTarget();
    logger.info("target=" + target);

    const templateName = target.split("#")[0];
    const response = NSP.restconfGET(`/nsp-icm:icm/templates/template=${templateName}`);
    logger.info("[NSP][restconfGET] response = {}", JSON.stringify(response));

    const templateObj = response.httpStatus === 200 ? response.response : null;
    const defaultTargetData = templateObj?.['nsp-icm:template']?.[0]?.['target-data-struct'];

    let deviceConfig = this.getDeviceConfiguration(target, this.initialPropertyName);
    if (typeof deviceConfig === 'string' && deviceConfig.includes('Failed to fetch service')) {
        logger.error(deviceConfig);
        return deviceConfig;
    }

    deviceConfig = this.extractDeviceConfig(defaultTargetData, deviceConfig, this.initialPropertyName, target);
    logger.info("deviceConfig = {}", JSON.stringify(deviceConfig));

    const data = NSP.gtdSend(deviceConfig);
    logger.info("data = {}", JSON.stringify(data));
    logger.info("returning result = {}", JSON.stringify(data.msg.result));

    const duration = Date.now() - startTS;
    logger.info("IntentHandler::getTargetData() finished within {} ms", duration | 0);
    return data.msg.result;
  }
}
