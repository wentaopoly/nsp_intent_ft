function ModelDeviceMapping() {

    this.getMapping = function(type){
        switch(type){
            case "sap-egress":
                return this.getSapEgressPolicyMapping();
            case "fc":
                return this.getSapEgressFcMapping();
            case "queue":
                return this.getSapEgressQueueMapping();
            default:
                logger.info(LOG_PREFIX + "Unable to get mapping, unknown type: " + type);
        }
    }

    this.getSapEgressPolicyMapping = function() {
        var mapping = {};
        mapping["sap-egress.description"] = "description";
        mapping["sap-egress.scope"] = "scope";
        mapping["sap-egress.dot1p-classification"] = "dot1pClassificationPointer";
        mapping["sap-egress.dscp-classification"] = "dscpClassificationPointer";
        mapping["sap-egress.ip-prec-classification"] = "ipPrecClassificationPointer";
        mapping["sap-egress.remarking"] = "remarking";
        mapping["sap-egress.remark"] = "remarkPolicyPointer";
        return mapping;
    }

    this.getSapEgressFcMapping = function() {
        var mapping = {};
        mapping["fc.fc-name"] = "forwardingClass";
        mapping["fc.queue"] = "queueId";
        return mapping;
    }

    this.getSapEgressQueueMapping = function() {
        var mapping = {};
        mapping["queue.queue-id"] = "id";
        mapping["queue.cbs"] = "committedBurstSize";
        mapping["queue.mbs"] = "maximumBurstSize";
        mapping["queue.queue-mgmt"] = "queuemgmtPolicyPointer";
        mapping["queue.queue-mode"] = "mode";
        mapping["queue.weight"] = "weight";
        mapping["queue.priority"] = "priority";
        mapping["queue.slope-policy"] = "slopePolicyPointer";
        mapping["queue.rate.pir"] = "pir";
        mapping["queue.rate.cir"] = "cir";
        mapping["queue.adaptation-rule.pir"] = "pirAdaptation";
        mapping["queue.adaptation-rule.cir"] = "cirAdaptation";
        return mapping;
    }
}
