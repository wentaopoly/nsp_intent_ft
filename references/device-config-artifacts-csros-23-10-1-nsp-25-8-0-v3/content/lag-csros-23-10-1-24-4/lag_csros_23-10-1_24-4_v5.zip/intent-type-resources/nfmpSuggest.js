function NfmpSuggest() {
    this.getLagId = function (neId, lagName) {
        var className = "lag.Interface";
        let equalFilter = [
                            {
                              "name": "siteId",
                              "value": neId
                            }
                          ];
        if(lagName)
        {
            let lagNameFilter = {
                                     "name": "lagNameId",
                                     "value": lagName
                                   };
            equalFilter.push(lagNameFilter);
        }
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": equalFilter
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "lagId"
                ]
            }
        };
        return this.getData(neId, searchObject, "lagId");
    }
    this.getLagName = function (neId, lagId) {
        var className = "lag.Interface";
        let equalFilter = [
                            {
                              "name": "siteId",
                              "value": neId
                            }
                          ];
        if(lagId)
        {
            let lagIdFilter = {
                                     "name": "lagId",
                                     "value": lagId
                                   };
            equalFilter.push(lagIdFilter);
        }
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": equalFilter
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "lagNameId"
                ]
            }
        };
        return this.getData(neId, searchObject, "lagNameId");
    }

    this.getData = function (target, searchObjectJson, type) {
        var nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = this.find(target, searchObjectJson);
        logger.info(LOG_PREFIX + resultFetch.response);
        var finalResponse = JSON.parse(resultFetch.response)["lag.Interface"];
        logger.info(LOG_PREFIX + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                    ret.push(finalResponse[index][type]);
                }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "result = \n" + JSON.stringify(ret));
        return ret;
    }

    this.getMonitorOperGroup = function (neId) {
        //monitorOperGroupPointer
        var searchObjectJson = {
            "fullClassName": "service.OperGroup",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "groupName"
                ]
            }
        };
        return this.getSuggestData(searchObjectJson, "service.OperGroup", "groupName");
    }

    this.getUNIProfile = function (neId) {
        //agUniProfilePointer
        var searchObjectJson = {
            "fullClassName": "ethernetservice.UniProfile",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getSuggestData(searchObjectJson, "ethernetservice.UniProfile", "displayedName");
    }

 this.getPortIds = function(neId, mode, encapType) {
    var searchObjectJson1 = {
        "fullClassName": "equipment.PhysicalPort",
        "filter": {
            "and": {
                "equal": [{
                    "name": "siteId",
                    "value": neId
                }]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": [
                "portName",
                "objectFullName",
                "description",
                "encapType",
                "mode"
            ]
        }
    };
    var searchObjectJson2 = {
        "fullClassName": "pxc.PortCrossConnectSubPort",
        "filter": {
            "and": {
                "equal": [{
                    "name": "siteId",
                    "value": neId
                }]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": [
                "displayedName",
                 "objectFullName",
                "description",
                "encapType",
                "mode"
            ]
        }
    };
    var nfmpFwk = new NfmpFwk();
    var data;
	var resultFetch1 = this.find(neId, searchObjectJson1);
	var resultFetch2 = this.find(neId, searchObjectJson2);
	var finalResponse1 = JSON.parse(resultFetch1.response)["equipment.PhysicalPort"];
	var finalResponse2 = JSON.parse(resultFetch2.response)["pxc.PortCrossConnectSubPort"];
	if(finalResponse1 && finalResponse2 && mode === "hybrid"){
	  var finalResponse= finalResponse1.concat(finalResponse2);
	    data = processResponse(finalResponse, mode, encapType);
	   return data;
    }else if(finalResponse1){
       data = processResponse(finalResponse1, mode, encapType);
	 return data
	}else if(finalResponse2) {
	  data = processResponse(finalResponse2, mode, encapType);
	  return data;
	}
}

 function processResponse(response, mode, encapType) {
    var result={};
    var data=[];
    if (response) {
        data = response.map(function(portDetails) {
            var obj = {};
            if (mode === portDetails["mode"] && encapType === portDetails["encapType"]) {
                obj["memberName"] = portDetails["portName"] || portDetails["displayedName"];
                obj["description"] = portDetails["description"];
                obj["encapType"] = portDetails["encapType"];
                obj["mode"] = portDetails["mode"];
                obj["portPointer"] = portDetails["objectFullName"];
                return obj;
            }
            return null;
        }).filter(obj => obj !== null);
         result["data"] = JSON.stringify(data);
    }
    logger.info("Processed data: " +JSON.stringify(result));
    return result;
 }

    this.getSuggestData = function (searchObjectJson, searchClass, propertyName)
    {

        var nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        finalResponse = finalResponse[searchClass];
        logger.info(JSON.stringify(finalResponse));

        if (Object.keys(finalResponse).length !== 0)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            finalResponse.forEach(function (value, index, array) {
                ret.push(value[propertyName]);
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

   this.getPortData = function (neId, port, attribute) {
    var fullClassName = port.startsWith("pxc-") ? "pxc.PortCrossConnectSubPort" : "equipment.PhysicalPort";
    var attributeName = port.startsWith("pxc-") ? "displayedName" : "portName";
    var searchObjectJson = {
        "fullClassName": fullClassName,
        "filter": {
            "and": {
                "equal": [
                    { "name": "siteId", "value": neId },
                    { "name": attributeName, "value": port }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": [attribute]
        }
    };
    var resultFetch = this.find(neId, searchObjectJson);
    var responseKey = fullClassName;
    var finalResponse = JSON.parse(resultFetch.response);
    var data = (finalResponse[responseKey] && finalResponse[responseKey][attribute]);
    return data;
   };

   this.find = function(target, jsonRequest) {
        var PATH_SEARCH = "/v3/search";
        var result = {};
        nfmpFwk.configRestClient();
        restClient.post(PATH_SEARCH, "application/json", JSON.stringify(jsonRequest), "application/json", function(exception, httpStatus, response) {
            if (exception != null || httpStatus >= 400) {
                result = {
                    success: false,
                    httpStatus: httpStatus,
                    msg: "Couldn't connect to Manager of Device: " + target + ", got response " + response
                };

            } else {
                result = {
                    success: true,
                    httpStatus: httpStatus,
                    response: response,
                    msg: "Deployment to NFM-P for device " + target + " was successful, got response " + response
                };
            }

        });
        log.info(null, "[NFMP-FWK] find() Search Response:" + JSON.stringify(result));
        return result;
   }

   this.getPortDataForBF = function(neId, snmpPortId) {
    var searchObjectJson1 = {
        "fullClassName": "equipment.PhysicalPort",
        "filter": {
            "and": {
                "equal": [
                    { "name": "siteId", "value": neId },
                    { "name": "snmpPortId", "value": snmpPortId }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": ["portName"]
        }
    };
    var searchObjectJson2 = {
        "fullClassName": "pxc.PortCrossConnectSubPort",
        "filter": {
            "and": {
                "equal": [
                    { "name": "siteId", "value": neId },
                    { "name": "snmpPortId", "value": snmpPortId }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": ["portName"]
        }
    };
    var resultFetch1 = this.find(neId, searchObjectJson1);
    var resultFetch2 = this.find(neId, searchObjectJson2);
    var finalResponse1 = JSON.parse(resultFetch1.response)["equipment.PhysicalPort"];
    var finalResponse2 = JSON.parse(resultFetch2.response)["pxc.PortCrossConnectSubPort"];
    var data;
    if (finalResponse1 && finalResponse1.portName) {
        data = finalResponse1.portName;
    } else if (finalResponse2 && finalResponse2.portName) {
        data = finalResponse2.portName;
    }
    return data;
   };
}