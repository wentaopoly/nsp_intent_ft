/**************************************************************************
 * $RCSfile$
 * <p>
 * Author: afshandev
 * <p>
 * Description:
 * <edit this part>
 * <p>
 * **************************************************************************
 * <p>
 * Source Control System Information
 * <p>
 * $Revision$
 * $Id$
 * Last Changed by:$Author$
 * <p>
 * **************************************************************************
 * <p>
 * Copyright (c) 2022 Nokia,All Rights Reserved.
 * Please read the associated COPYRIGHTS file for more details.
 **************************************************************************/
package com.nokia.nsp.sf.app.srNode;

import com.nokia.nsp.sf.app.api.ISFPlugin;
import com.nokia.nsp.sf.app.util.ServiceUtil;
import com.nokia.nsp.md.common.IYangObject;
import com.nokia.nspos.persistence.yang.api.IYangDB;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SFSRPlugin implements ISFPlugin
{
    public static final String MODEL_MDM_FDN="fdn:model:mdm:";
    public static final Pattern SVC_NAME_PATTERN = Pattern.compile("\\[service-name\\=\"(.*?)\"\\]($|\\/|\\[)");
    public static final Map<String, String> predefinedDeviceConfigureServicePathMap = initDeviceConfigureServicePathMap();
    public static final Map<String, String> predefinedDeviceStateServicePathMap = initDeviceDeviceStateServicePathMap();
    public static final Map<String,Map<String,List<String>>> predefinedDeviceServicePathMapToNspClass=initDeviceServicePathMapToNspClasses();

    private static Map<String,Map<String,List<String>>> initDeviceServicePathMapToNspClasses()
    {
        Map<String,Map<String,List<String>>> lListMap=new HashMap<>();
        Map<String,List<String>> lElineService=new HashMap<>();
        List<String> lElineNspCalss=new ArrayList<>(1);
        lElineNspCalss.add("nsp-service:/services/nsp-service:service-layer/nsp-service:eline/nsp-service:site");
        lElineService.put("nokia-conf:/configure/service/epipe", lElineNspCalss);
        lElineService.put("nokia-state:/state/service/epipe",lElineNspCalss);
        lListMap.put(ServiceUtil.serviceType.eline.name(),lElineService);

        Map<String,List<String>> lElanService=new HashMap<>();
        List<String> lElanNspCalss=new ArrayList<>(1);
        lElanNspCalss.add("nsp-service:/services/nsp-service:service-layer/nsp-service:elan/nsp-service:site");
        lElanService.put("nokia-conf:/configure/service/vpls", lElanNspCalss);
        lElanService.put("nokia-state:/state/service/vpls",lElanNspCalss);
        lListMap.put(ServiceUtil.serviceType.elan.name(),lElanService);

        Map<String,List<String>> lL3VpnService=new HashMap<>();
        List<String> lL3VpnNspCalss=new ArrayList<>(1);
        lL3VpnNspCalss.add("nsp-service:/services/nsp-service:service-layer/nsp-service:l3vpn/nsp-service:site");
        lL3VpnService.put("nokia-conf:/configure/service/vprn", lL3VpnNspCalss);
        lL3VpnService.put("nokia-state:/state/service/vprn",lL3VpnNspCalss);
        lListMap.put(ServiceUtil.serviceType.l3vpn.name(),lL3VpnService);

        Map<String,List<String>> lIesService=new HashMap<>();
        List<String> lIesNspCalss=new ArrayList<>(1);
        lIesNspCalss.add("nsp-service:/services/nsp-service:service-layer/nsp-service:ies/nsp-service:site");
        lIesService.put("nokia-conf:/configure/service/ies", lIesNspCalss);
        lIesService.put("nokia-state:/state/service/ies",lIesNspCalss);
        lListMap.put(ServiceUtil.serviceType.ies.name(),lIesService);

        Map<String,List<String>> lClineService=new HashMap<>();
        List<String> lClineNspCalss=new ArrayList<>(1);
        lClineNspCalss.add("nsp-service:/services/nsp-service:service-layer/nsp-service:cline/nsp-service:site");
        lClineService.put("nokia-conf:/configure/service/cline", lClineNspCalss);
        lClineService.put("nokia-state:/state/service/cline",lClineNspCalss);
        lListMap.put(ServiceUtil.serviceType.cline.name(),lClineService);

        Map<String,List<String>> lMirrorService=new HashMap<>();
        List<String> lMirrorNspCalss=new ArrayList<>(1);
        lMirrorNspCalss.add("nsp-service:/services/nsp-service:service-layer/nsp-service:mirror/nsp-service:site");
        lMirrorService.put("nokia-conf:/configure/service/mirror", lMirrorNspCalss);
        lMirrorService.put("nokia-state:/state/service/mirror",lMirrorNspCalss);
        lListMap.put(ServiceUtil.serviceType.mirror.name(),lMirrorService);
        return lListMap;
    }

    private static  Map<String, String>  initDeviceConfigureServicePathMap()
    {
        Map<String,String> lMap=new HashMap<>();
        lMap.put(ServiceUtil.serviceType.eline.name(), "nokia-conf:/configure/service/epipe");
        lMap.put(ServiceUtil.serviceType.elan.name(),"nokia-conf:/configure/service/vpls");
        lMap.put(ServiceUtil.serviceType.l3vpn.name(),"nokia-conf:/configure/service/vprn");
        lMap.put(ServiceUtil.serviceType.ies.name(), "nokia-conf:/configure/service/ies");
        lMap.put(ServiceUtil.serviceType.cline.name(), "nokia-conf:/configure/service/cline");
        lMap.put(ServiceUtil.serviceType.mirror.name(), "nokia-conf:/configure/service/mirror");
        return lMap;
    }
    private static  Map<String, String>  initDeviceDeviceStateServicePathMap()
    {
        Map<String,String> lMap=new HashMap<>();
        lMap.put(ServiceUtil.serviceType.eline.name(), "nokia-state:/state/service/epipe");
        lMap.put(ServiceUtil.serviceType.elan.name(), "nokia-state:/state/service/vpls");
        lMap.put(ServiceUtil.serviceType.l3vpn.name(), "nokia-state:/state/service/vprn");
        lMap.put(ServiceUtil.serviceType.ies.name(), "nokia-state:/state/service/ies");
        lMap.put(ServiceUtil.serviceType.cline.name(), "nokia-state:/state/service/cline");
        lMap.put(ServiceUtil.serviceType.mirror.name(), "nokia-state:/state/service/mirror");
        return lMap;
    }

    public  Map<String,List<String>> getNspClassToResync(Map<String,List<String>> aInMap,String aInServiceType,String aInNeId, boolean aInAfterStitchIng,String aInNodeType,String aInNodeVersion)
    {
        return predefinedDeviceServicePathMapToNspClass.get(aInServiceType);
    }

    @Override
    public List<String> buildExtraSources(IYangObject aInSyncSiteYangObj, String aInObjectType, List<String> aInSources, String aInSvcType, String aInNeId, String aInNodeType, String aInNodeVersion)
    {
        List<String> lExtraSources = new ArrayList();
        for(String lConfigure : aInSources ) {
            if(lConfigure.indexOf(":/configure")>0) {

                lExtraSources.add(lConfigure.replace(":/configure", ":/state"));
            }
            if(aInObjectType.equals(ISFPlugin.SVC_TUNNEL_BINDING) && lConfigure.indexOf("/spoke-sdp")>0
               && aInSyncSiteYangObj!=null && aInSyncSiteYangObj.hasProperty("ne-service-id")){
                String lNeServiceId =(String)aInSyncSiteYangObj.get("ne-service-id");
                String lSvcName = "service-id='" + lNeServiceId + "'";
                String lSdpName = lConfigure.substring(lConfigure.lastIndexOf("[") + 1, lConfigure.lastIndexOf("]"));
                String lMdmAmiModelTunnelBindingObj = "fdn:app:mdm-ami-cmodel:" + aInNeId + ":service:ServiceResourceBinding:/service[" + lSvcName + "]/spoke-sdp[" + lSdpName + "]";
                lExtraSources.add(lMdmAmiModelTunnelBindingObj);
            }
            if(aInObjectType.equals(ISFPlugin.SVC_SITE) && lConfigure.indexOf("/configure")>0&& aInSyncSiteYangObj!=null && aInSyncSiteYangObj.hasProperty("ne-service-id")){
                String lNeServiceId =(String)aInSyncSiteYangObj.get("ne-service-id");
                String lSvcName = "service-id='" + lNeServiceId + "'";
                String lMdmAmiModelTunnelBindingObj = "fdn:app:mdm-ami-cmodel:" + aInNeId + ":service:Site:/service[" + lSvcName + "]";
                lExtraSources.add(lMdmAmiModelTunnelBindingObj);
            }
        }
        return lExtraSources;
    }

    @Override
    public Map<String, List<String>> buildResyncRequest(List<String> aInSources, String aInSvcType, String aInNeId, boolean aInAfterStitchIng, String aInNodeType, String aInNodeVersion)
    {
        //key:device classId
        //value: list of sourceFdn
        Map<String, List<String>> lListMap=new LinkedHashMap<>();
        for (String lSource : aInSources)
        {
            if (lSource.contains(MODEL_MDM_FDN))
            {
                String lDeviceClassId = getDeviceClassId(lSource, aInSvcType);
                if(lDeviceClassId!=null)
                {
                    List<String> lList=  lListMap.get(lDeviceClassId);
                    if(null==lList)
                    {
                        lList=new LinkedList<>();
                        lListMap.put(lDeviceClassId, lList);
                    }
                    //handle quote
                    Matcher lMatch = SVC_NAME_PATTERN.matcher(lSource);
                    if (lMatch.find() && lMatch.group(1).contains("'")) {
                        lSource = lMatch.replaceFirst("[service-name='$1']$2");
                    }
                    lList.add(lSource);
                }
            }
        }
        return lListMap;
    }

    private String getDeviceClassId(String aInSource, String aInSvcType){

        if(aInSource.contains("configure")){
            return predefinedDeviceConfigureServicePathMap.get(aInSvcType);
        }else if (aInSource.contains("state")){
            return predefinedDeviceStateServicePathMap.get(aInSvcType);
        }
        return null;
    }

    public List<String>  getSourceFdns(IYangObject aInSyncSiteYangObj, String serviceType, String aInNeId, String aInNodeType,String aInNodeVersion)
    {
        List<String> lSources = (List) aInSyncSiteYangObj.getExtraData("sources");
        List<String> sources = new LinkedList<>();
        for (String lSource : lSources) {
            if (lSource.contains(MODEL_MDM_FDN)) {
                if (ServiceUtil.serviceType.l3vpn.name().equals(serviceType)) {
                    if (lSource.contains("/service/vprn")) {
                        String[] token = lSource.split("/service/vprn");
                        if (token[1].endsWith("']")) {
                            sources.add(lSource);
                        }
                    }
                } else {
                    sources.add(lSource);
                }
            }
        }

        List lExtraSources=buildExtraSources(aInSyncSiteYangObj, SVC_SITE, sources, serviceType, aInNeId, aInNodeType,aInNodeVersion );
        if(lExtraSources!=null && !lExtraSources.isEmpty()){
            for(Object lExtraSource : lExtraSources){
                if (((String)lExtraSource).contains(MODEL_MDM_FDN)){
                    sources.add((String)lExtraSource);
                }
            }
        }
        return sources;
    }


    public  List<String> getSourceFdns(IYangDB aInDb, IYangObject aInSiteYangObj, String serviceType, String aInNeId, String aInNodeType,String aInNodeVersion)
    {
        List<String> sources = new LinkedList<>();
        List<String> lSources = (List) aInSiteYangObj.getExtraData("sources");
        for (String lSource : lSources) {
            if (lSource.contains(MODEL_MDM_FDN)) {
                if (ServiceUtil.serviceType.l3vpn.name().equals(serviceType)) {
                    if (lSource.contains("/service/vprn")) {
                        String[] token = lSource.split("/service/vprn");
                        if (token[1].endsWith("']")) {
                            sources.add(lSource);
                        }
                    }
                } else {
                    sources.add(lSource);
                }
            }
        }
        return sources;
    }

    public boolean shouldCreateEndpoint(String aInServiceType,String aInNeId, String aInNodeType,String aInNodeVersion, boolean isServiceStitching) {
        return false;
    }

    @Override
    public boolean shouldUseNspCustomer(String aInNeId) {
        return true;
    }

}
