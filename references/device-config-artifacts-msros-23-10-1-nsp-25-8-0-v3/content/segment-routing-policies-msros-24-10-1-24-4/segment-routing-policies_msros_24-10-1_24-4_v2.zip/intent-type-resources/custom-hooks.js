load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
load({script: resourceProvider.getResource("parse-target.js"), name: "ParseTarget"});
function CustomHooks() {
var ipv6AddressUtil = new IPv6AddressUtil();
var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,5}(:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){6}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(\/(0|[1-9][0-9]?|1[0-1][0-9]?|12[0-8]))?$/;

    /**
   * PreAudit Hook
   */
  const preAudit = (inputObj) => {
     /**
     * Write your custom preAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName
     *
     */

    logger.info("[CUSTOM-HOOKS] preAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
    var target = inputObj["target"];
    var intentConfig = inputObj["intentConfig"];
    var intentDeviationObj = new IntentDeviceDeviation();
    var neId = parseTarget.getNeIdFromTarget(target);
    intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
    intentConfig = intentDeviationObj.removeIntentConfig(JSON.stringify(intentConfig), neId);
    logger.info("preAudit intent config after removing deviation attributes: " + JSON.stringify(intentConfig));
    inputObj ["intentConfig"] = intentConfig;

    let staticPolicy = intentConfig["static-policy"];
    if (intentConfig && staticPolicy) {
                for(let i=0;i< staticPolicy.length; i++) {
                if(staticPolicy[i] && staticPolicy[i]["endpoint"]) {
                    let endpoint = staticPolicy[i]["endpoint"];
                    if (endpoint && String(endpoint).indexOf(':') !== -1) {
                        staticPolicy[i]["endpoint"] =  this.expandIPv6AddressForMd(endpoint);
                    }
                }
                }
    }
    if (intentConfig && staticPolicy) {
        for (let i = 0; i < staticPolicy.length; i++) {
            const srV6 = staticPolicy[i]["segment-routing-v6"];
            if (staticPolicy[i] && srV6 && srV6["binding-sid"]) {
                const bindingSids = srV6["binding-sid"];
                for (let j = 0; j < bindingSids.length; j++) {
                    let bindingSid = bindingSids[j];
                    let ipAddr = bindingSid && bindingSid["ip-address"];
                    if (ipAddr && String(ipAddr).indexOf(":") !== -1) {
                        bindingSid["ip-address"] = this.expandIPv6AddressForMd(ipAddr);
                    }
                }
            }
        }
    }
    if (intentConfig && staticPolicy) {
            for (let i = 0; i < staticPolicy.length; i++) {
                const srV6 = staticPolicy[i]["segment-routing-v6"];
                if (staticPolicy[i] && srV6 && srV6["return-path-bfd-sid"]) {
                    let retPath = srV6["return-path-bfd-sid"];
                    if (retPath && String(retPath).indexOf(':') !== -1) {
                        srV6["return-path-bfd-sid"] =  this.expandIPv6AddressForMd(retPath);
                    }
                }
            }
    }
    if (intentConfig && staticPolicy) {
      for (let i = 0; i < staticPolicy.length; i++) {
        if (staticPolicy[i] && staticPolicy[i]["segment-list"]) {
          let segmentList = staticPolicy[i]["segment-list"];

          for (let j = 0; j < segmentList.length; j++) {
            if (segmentList[j] && segmentList[j]["segment"]) {
              let segmentIndex = segmentList[j]["segment"];

              for (let k = 0; k < segmentIndex.length; k++) {
                if (segmentIndex[k] && segmentIndex[k]["srv6-sid"]) {
                  let srv6Sid = segmentIndex[k]["srv6-sid"];

                  if (srv6Sid && String(srv6Sid).indexOf(':') !== -1) {
                    segmentIndex[k]["srv6-sid"] = this.expandIPv6AddressForMd(srv6Sid);
                  }
                }
              }
            }
          }
        }
      }
    }
    return inputObj;
  };

  /**
   * PostAudit Hook
   */
  const postAudit = (inputObj) => {
    /**
     * Write your custom postAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName, auditReport
     *
     */

    logger.info("[CUSTOM-HOOKS] postAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));


  };

  /**
   * PreSync Hook
   */
    /**
     * PreSync Hook
     */
    const preSync = (inputObj) => {
        /**
         * Write your custom preSync logic here
         * inputObj by default contains the following keys:
         *          target, config, intentTypeName, rootXPath,
         *          intentContainer, uniqueIdentifier, deviceYangModuleName
         *          topology, state, syncResult
         */
        logger.info("[CUSTOM-HOOKS] preSync call");
        var config = JSON.parse(inputObj["config"]);
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(config));
        var target = inputObj["target"];
        config = this.removeEmptyContainers("", config, "", target);
        config = this.expandIPv6(config);
        var intentTypeName = inputObj["intentTypeName"];
        var intentContainer = inputObj["intentContainer"];
        var intentDeviationObj = new IntentDeviceDeviation();
        var neId = parseTarget.getNeIdFromTarget(target);
        if (!Array.isArray(config)) {
            config = [config];
        }
        let preSyncConf = [];
        for (var index in config) {
            var confObj= config[index][intentTypeName + ":" + intentTypeName][intentContainer];
            let configObj = JSON.stringify(confObj);
            let deviatedObj = intentDeviationObj.removeIntentConfig(configObj, neId);
            let finalConfigObj = {};
            let intentKey = intentTypeName + ":" + intentTypeName
            finalConfigObj[intentKey] = {};
            finalConfigObj[intentKey][intentContainer] = deviatedObj;
            preSyncConf.push(finalConfigObj);
        }
        inputObj["config"] = JSON.stringify(preSyncConf);
        logger.info("intent config after removing deviation attributes" + JSON.stringify(inputObj));
        return inputObj;
    };

  /**
   * PostSync Hook
   */
  const postSync = (inputObj) => {
    /**
     * Write your custom postSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] postSync call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

  };

  /**
   *
   * PostDiscovery Hook
   */
  const postDiscovery = (inputObj) => {
    /**
     * Write your custom postDiscovery logic here
     * inputObj by default contains the following keys:
     *        deviceConfig, intentContainer, neId,
     *        targetDataStruct, templateName, deviceYangModuleName
     */

    logger.info("[CUSTOM-HOOKS] postDiscovery call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

  }
    this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }

    this.expandIPv6 = function (obj) {
          for (var key in obj) {
              if (typeof obj[key] === 'object' && obj[key] !== null) {
                  this.expandIPv6(obj[key]);
              } else if (typeof obj[key] === 'string' && this.matchExact(ipv6Regex, obj[key])) {
                  obj[key] = this.expandIPv6AddressForMd(obj[key]);
          }
        }
        return obj
      }
      this.matchExact = function(r, str) {
         var match = str.match(r);
         return match && str === match[0];
      }

      this.expandIPv6AddressForMd = function (input) {
         var expanded = ipv6AddressUtil.expandIPv6Address(input);
         expanded = ipv6AddressUtil.MdIpv6ValidAddresssMaskSupport(expanded);
         return expanded;
      };

  this.preAudit = preAudit;
  this.postAudit = postAudit;
  this.preSync = preSync;
  this.postSync = postSync;
  this.postDiscovery = postDiscovery;

}