var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpPtp() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var isAudit = false;

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        logger.info("input = \n" + input + "-------" + result + "-------" + intentTypeName + "-------" + initialPropertyName + "-------" + uniqueIdentifier);
        // code to handle delete
        if (input.getNetworkState().name() == "delete")
        {
            result.setSuccess(true);
            return result;
        }
        // code to handle sync
        var savedTopology = input.getCurrentTopology();
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        this.createOrModify(neId, intentConfig);
        return util.setSuccessResult(result, savedTopology);
    }
    this.audit = function (target, config, svcTopo, adminState, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        logger.info("audit");
        isAudit = true;
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        var neId = parseTarget.getNeIdFromTarget(target);
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        if (intentConfig)
        {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }

        return auditReport
    }
    this.auditAndCompare = function (neId, intentConfig, auditReport) {
        var ptpPayLoad = this.createPtpPayLoad(neId, intentConfig);
        var result = this.auditRequest(neId, ptpPayLoad);
        auditReport = util.reportMisaligned(neId, result, auditReport);
        return auditReport;
    }
    this.auditRequest = function (neId, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }
    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('input json: ' + json)
        return JSON.parse(json);
    }

    this.createOrModify = function (neId, intentConfig) {
        var ptpPayLoad = this.createPtpPayLoad(neId, intentConfig);
        var result = this.modifyRequest(neId, ptpPayLoad);
        return result;
    }
    this.createPtpPayLoad = function (neId, intentConfig) {
        var fullClassName = "ptp.IEEEPTPClock";
        var fdn = "network:" + neId;
        if (neId && String(neId).indexOf(':') !== -1) {
            fdn = util.modifyNeIdForIpV6(fdn, neId);
        }
        var objectFullName = "network:" + neId + ":ptp";
        if (neId && String(neId).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        }
        var properties = {};
        properties["clockAdminState"] = util.convertAdminStateGreenField(intentConfig["admin-state"]);
        properties["ptpClockAnnoRxTimeout"] = intentConfig["announce-receipt-timeout"];
        properties["ptpClockAnnounceInterval"] = intentConfig["log-announce-interval"];
        properties["clockType"] = util.convertClockTypeGreeField(intentConfig["clock-type"]);
        properties["clockNetworkType"] = intentConfig["network-type"];
        properties["clockDomain"] = intentConfig["domain"];
        properties["clockProfile"] = util.convertProfileGreeField(intentConfig["profile"]);
        properties["clockLocalPriority"] = intentConfig["local-priority"];
        properties["clockPriority1"] = intentConfig["priority1"];
        properties["clockPriority2"] = intentConfig["priority2"];
        if (intentConfig["tx-while-sync-uncertain"])
        {
            properties["txWhileSyncUncertain"] = (intentConfig["tx-while-sync-uncertain"]).toString();
        }
        else
        {
            properties["txWhileSyncUncertain"] = "false";
        }

        var childProperties = [];
        //create member payload
        if (intentConfig["port"])
        {
            logger.info("Intent has PTP-PORT")
            if (!Array.isArray(intentConfig["port"]))
            {
                intentConfig["port"] = [intentConfig["port"]];
            }
            for (var index in intentConfig["port"])
            {
                var intentPtpPortConfig = intentConfig["port"][index];
                var ptpPortPayload = this.createPtpPortPayLoad(neId, intentPtpPortConfig)
                childProperties.push(ptpPortPayload);
            }
        }
            //if no ptp-port objects,then add ptp-port objectFullName so that ns-mdt-nfmp-mediator will find in nfmp
        // and delete the ports
        else
        {
            logger.info("Intent doesnt have PTP-PORT")
            var objClassName = "ptp.IEEEPTPPort";
            var childObjectPayLoad = {};
            childObjectPayLoad['objectClassName'] = objClassName;
            if (!isAudit)
            {
                childProperties.push(childObjectPayLoad);
            }
        }
        var ptpPayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
        return ptpPayload;
    }
    this.createPtpPortPayLoad = function (neId, intentptpPortConfig) {
        var fullClassName = "ptp.IEEEPTPPort";
        var properties = {};
        if (intentptpPortConfig)
        {
            properties["associatedPhysicalPort"] = util.getBaseFdnForPort(neId, intentptpPortConfig["port-id"]);
            properties["ptpPortClockAdminState"] = util.convertAdminStateGreenField(intentptpPortConfig["admin-state"]);
            if (intentptpPortConfig["address"])
            {
                properties["ptpPortMulticastAddress"] = util.convertAddressGreenField(intentptpPortConfig["address"]);
            }
            properties["ptpPortLocalPriority"] = intentptpPortConfig["local-priority"];
            if (intentptpPortConfig["log-delay-interval"])
            {
                properties["ptpPortDelayInterval"] = util.convertInvervalGreeField(intentptpPortConfig["log-delay-interval"]);
            }
            if (intentptpPortConfig["log-sync-interval"])
            {
                properties["ptpPortSyncInterval"] = util.convertInvervalGreeField(intentptpPortConfig["log-sync-interval"]);
            }
            if (intentptpPortConfig["master-only"])
            {
                properties["ptpPortMasterOnly"] = intentptpPortConfig["master-only"];
            }
            else
            {
                properties["ptpPortMasterOnly"] = false;
            }
        }
        return this.createChildObjectPayload(fullClassName, properties);
    }
    this.createChildObjectPayload = function (fullClassName, properties) {

        var childObjectPayLoad = {};
        childObjectPayLoad['objectClassName'] = fullClassName;
        childObjectPayLoad['containedClassProperties'] = properties;
        return childObjectPayLoad;

    }

    this.modifyRequest = function (neId, payload) {
        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

}
