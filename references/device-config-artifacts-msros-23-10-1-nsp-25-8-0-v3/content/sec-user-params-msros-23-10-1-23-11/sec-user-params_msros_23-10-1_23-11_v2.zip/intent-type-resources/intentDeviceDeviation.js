function IntentDeviceDeviation() {

    this.removeIntentConfig = function (intentConfig, neId) {
        var deviationData = undefined;
        try {
            deviationData = this.deviationData();
        } catch (err) {
            return intentConfig;
        }
        logger.info("Removing deviations from config: " + intentConfig);
        intentConfig = JSON.parse(intentConfig);
        var neFamily = this.getNeFamilyRelease(neId);
        logger.info("NE family : " + neFamily);
        var neType = this.getNeType(neFamily);
        var chassisType = this.getChassisType(neFamily);
        var neVersion = this.getNeVersion(neFamily);
        logger.info("Intent dev JS: neType: " + neType + ", chassisType: " + chassisType + ", neVersion: " + neVersion);
        var deviationInfoArr = deviationData['devitaionInfo'];
        for (var i = 0; i < deviationInfoArr.length; i++) {
            var deviationObj = deviationInfoArr[i];
            var deviationNetype = deviationObj['neType'];
            var deviationNeVersion = deviationObj['neVersion'];
            var deviationChassisTypes = deviationObj['chassisTypes'];
            var chassisFlag = deviationChassisTypes.length == 0;
            if (!chassisFlag) {
                chassisFlag = deviationChassisTypes.indexOf(chassisType) != -1;
            }
            var result = ((neType.localeCompare(deviationNetype) == 0) && chassisFlag);
            var neversionResult = deviationNeVersion.length == 0;
            if (!neversionResult) {
                neversionResult = deviationNeVersion.indexOf(neVersion) != -1;
            }
            logger.info("neType : " + neType + ", chassisType : " + chassisType + ",result : " + result + ", neVersionResult : " + neversionResult);
            if (result && neversionResult) {
                var notSupportedAttributes = deviationObj['NotSupportedAttributes'];
                for (var j = 0; j < notSupportedAttributes.length; j++) {
                    var segments = notSupportedAttributes[j].split(".");
                    var attributeToDelete = segments.pop();
                    var dataPath = segments.join(".");
                    logger.info("Deleting attribute : " + attributeToDelete + ", from Data Path : " + dataPath);
                    deleteAttribute(intentConfig, dataPath, attributeToDelete);
                }
            }
        }
        return intentConfig;
    }

    function deleteAttribute(intentConfig, path, attribute) {
        if (path !== '') {
            var segments = path.split(".");
            for (var segment of segments) {
                if (!intentConfig.hasOwnProperty(segment)) {
                    return;
                }
                intentConfig = intentConfig[segment];
                //check for Array or Object
                if (Array.isArray(intentConfig)) {
                    for (var i = 0; i < intentConfig.length; i++) {
                        if (intentConfig[i].hasOwnProperty(attribute)) {
                            delete intentConfig[i][attribute];
                        }
                        else {
                            segments.splice(0, segments.indexOf(segment) + 1);
                            var remSegments = segments.join(".");
                            deleteAttribute(intentConfig[i], remSegments, attribute);
                        }
                    }
                }
                else if (intentConfig.hasOwnProperty(attribute)) {
                    delete intentConfig[attribute];
                }
            }
        }
        else {
            if (intentConfig.hasOwnProperty(attribute)) {
                delete intentConfig[attribute];
            }
        }
    }

    this.getNeType = function (neFamily) {
        var neFamilyArr = neFamily.split(":");
        return neFamilyArr[0];
    }

    this.getChassisType = function (neFamily) {
        var neFamilyArr = neFamily.split(":");
        return neFamilyArr[2];
    }

    this.getNeVersion = function (neFamily) {
        var neFamilyArr = neFamily.split(":");
        return neFamilyArr[1];
    }

    this.deviationData = function () {
        var deviationObj = resourceProvider.getResource("intentDeviations.json");
        logger.info("Deviation Info Data : " + deviationObj);
        return JSON.parse(deviationObj);
    }

    this.getNeFamilyRelease = function (target) {
        var neId = target;
        var returnNeType = ''
        try {
            var managerList = []
            var managers = mds.getAllManagersOfType("REST");
            managers.forEach(function (manager) {
                if (mds.getManagerByName(manager).getConnectivityState().toString() === 'CONNECTED') {
                    managerList.push(manager)
                }
            });
            var devices = mds.getAllManagedDevicesFrom(managerList);
            devices.forEach(function (device) {
                var deviceName = device.getName();
                logger.info("device Name : " + deviceName);
                logger.info(device);
                var result = deviceName.localeCompare(neId);
                if (result == 0) {
                    logger.info("result: " + result);
                    returnNeType = device.getFamilyTypeRelease();
                    return returnNeType;
                }
            });
            return returnNeType;

        } catch (e) {
            logger.error(null, "[LOGGER-DEMO] Exception *******************  : " + e);
            return {
                "Device Not Found": "Device Not Found"
            }

        }
    }
}
