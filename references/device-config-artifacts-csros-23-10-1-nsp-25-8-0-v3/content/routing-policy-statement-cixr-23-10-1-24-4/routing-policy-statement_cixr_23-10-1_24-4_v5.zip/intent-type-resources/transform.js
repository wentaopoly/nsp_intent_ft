load({ script: resourceProvider.getResource("nfmpSuggest.js"), name: "NfmpSuggest" });
load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
function transformData() {
    const nfmpSuggest = new NfmpSuggest();
    const ipv6AddrUtil = new IPv6AddressUtil();
    var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(\/(0|[1-9][0-9]?|1[0-1][0-9]?|12[0-8]))?$/;
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        localObjectFullName = localObjectFullName.replace(neId, neId.replaceAll(":","_"));
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        localPolicyFullName = localPolicyFullName.replace(neId, neId.replaceAll(":","_"));
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        if(payload["configInfo"])
        {
            let statementConfig = payload["configInfo"]["rp.PolicyStatement"];
            if(statementConfig)
            {
                if(statementConfig["action"] == "none")
                {
                    statementConfig["children-Set"]["rp.DefaultAction"] = undefined;
                }
                else
                {
                    if(statementConfig["children-Set"]["rp.DefaultAction"])
                    {
                        if(statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"])
                        {
                            if(statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultAddCommunityAction"])
                            {
                                if(statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultAddCommunityAction"]["addCommunityName"] == null)
                                {
                                    statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultAddCommunityAction"]["addCommunityName"] = "";
                                }
                            }
                            else
                            {
                                statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultAddCommunityAction"] = new Object();
                                statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultAddCommunityAction"]["addCommunityName"] = "";
                            }
                            if(statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultRemoveCommunityAction"])
                            {
                                if(statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultRemoveCommunityAction"]["removeCommunityName"] == null)
                                {
                                    statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultRemoveCommunityAction"]["removeCommunityName"] = "";
                                }
                            }
                            else
                            {
                                statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultRemoveCommunityAction"] = new Object();
                                statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultRemoveCommunityAction"]["removeCommunityName"] = "";
                            }
                            if(statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultReplaceCommunityAction"])
                            {
                                if(statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultReplaceCommunityAction"]["replaceCommunityName"] == null)
                                {
                                    statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultReplaceCommunityAction"]["replaceCommunityName"] = ""
                                }
                            }
                            else
                            {
                               statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultReplaceCommunityAction"] = new Object();
                               statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultReplaceCommunityAction"]["replaceCommunityName"] = ""
                            }
                        }
                        else
                        {
                             statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"] = new Object();
                             statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultAddCommunityAction"] = new Object();
                             statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultAddCommunityAction"]["addCommunityName"] = "";
                             statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultRemoveCommunityAction"] = new Object();
                             statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultRemoveCommunityAction"]["removeCommunityName"] = "";
                             statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultReplaceCommunityAction"] = new Object();
                             statementConfig["children-Set"]["rp.DefaultAction"]["children-Set"]["rp.DefaultReplaceCommunityAction"]["replaceCommunityName"] = "";
                        }
                    }
                    if(isAudit && statementConfig["action"] == "drop")
					{
						statementConfig["action"] = "reject";
					}
                }
                if(statementConfig["children-Set"]["rp.PolicyStatementEntry"])
                {
                    let policyStmtEntries = statementConfig["children-Set"]["rp.PolicyStatementEntry"]
                    if (policyStmtEntries instanceof Object && !Array.isArray(policyStmtEntries)) {
                        policyStmtEntries = [policyStmtEntries];
                    }
                    policyStmtEntries.forEach(entry => {
                        if(entry["action"] == "none")
                        {
                            entry["children-Set"]["rp.Action"] = undefined;
                        }
                        else
                        {
                            if(entry["children-Set"]["rp.Action"])
                            {
                                if(entry["children-Set"]["rp.Action"]["children-Set"])
                                {
                                    if(entry["children-Set"]["rp.Action"]["children-Set"]["rp.AddCommunityAction"])
                                    {
                                        if(entry["children-Set"]["rp.Action"]["children-Set"]["rp.AddCommunityAction"]["addCommunityName"] == null)
                                        {
                                            entry["children-Set"]["rp.Action"]["children-Set"]["rp.AddCommunityAction"]["addCommunityName"] = "";
                                        }
                                    }
                                    else
                                    {
                                        entry["children-Set"]["rp.Action"]["children-Set"]["rp.AddCommunityAction"] = new Object();
                                        entry["children-Set"]["rp.Action"]["children-Set"]["rp.AddCommunityAction"]["addCommunityName"] = "";
                                    }
                                    if(entry["children-Set"]["rp.Action"]["children-Set"]["rp.RemoveCommunityAction"])
                                    {
                                        if(entry["children-Set"]["rp.Action"]["children-Set"]["rp.RemoveCommunityAction"]["removeCommunityName"] == null)
                                        {
                                            entry["children-Set"]["rp.Action"]["children-Set"]["rp.RemoveCommunityAction"]["removeCommunityName"] = "";
                                        }
                                    }
                                    else
                                    {
                                        entry["children-Set"]["rp.Action"]["children-Set"]["rp.RemoveCommunityAction"] = new Object();
                                        entry["children-Set"]["rp.Action"]["children-Set"]["rp.RemoveCommunityAction"]["removeCommunityName"] = "";
                                    }
                                    if(entry["children-Set"]["rp.Action"]["children-Set"]["rp.ReplaceCommunityAction"])
                                    {
                                        if(entry["children-Set"]["rp.Action"]["children-Set"]["rp.ReplaceCommunityAction"]["replaceCommunityName"] == null)
                                        {
                                            entry["children-Set"]["rp.Action"]["children-Set"]["rp.ReplaceCommunityAction"]["replaceCommunityName"] = ""
                                        }
                                    }
                                    else
                                    {
                                       entry["children-Set"]["rp.Action"]["children-Set"]["rp.ReplaceCommunityAction"] = new Object();
                                       entry["children-Set"]["rp.Action"]["children-Set"]["rp.ReplaceCommunityAction"]["replaceCommunityName"] = ""
                                    }
                                }
                                else
                                {
                                     entry["children-Set"]["rp.Action"]["children-Set"] = new Object();
                                     entry["children-Set"]["rp.Action"]["children-Set"]["rp.AddCommunityAction"] = new Object();
                                     entry["children-Set"]["rp.Action"]["children-Set"]["rp.AddCommunityAction"]["addCommunityName"] = "";
                                     entry["children-Set"]["rp.Action"]["children-Set"]["rp.RemoveCommunityAction"] = new Object();
                                     entry["children-Set"]["rp.Action"]["children-Set"]["rp.RemoveCommunityAction"]["removeCommunityName"] = "";
                                     entry["children-Set"]["rp.Action"]["children-Set"]["rp.ReplaceCommunityAction"] = new Object();
                                     entry["children-Set"]["rp.Action"]["children-Set"]["rp.ReplaceCommunityAction"]["replaceCommunityName"] = "";
                                }
                            }
                            if(isAudit && entry["action"] == "drop")
							{
								entry["action"] = "reject";
							}
                        }
                        if(!entry["enableFromCriteria"])
                        {
                            entry["children-Set"]["rp.FromCriteria"] = undefined;
                        }
                        else
                        {
                            if(entry["children-Set"] && entry["children-Set"]["rp.FromCriteria"] && entry["children-Set"]["rp.FromCriteria"]["communityName"] == "N/A")
                            {
                                entry["children-Set"]["rp.FromCriteria"]["communityName"] = "";
                            }
                            if(entry["children-Set"] && entry["children-Set"]["rp.FromCriteria"])
                            {
                                if(entry["children-Set"]["rp.FromCriteria"]["children-Set"] == null)
                                {
                                    entry["children-Set"]["rp.FromCriteria"]["children-Set"] = new Object();
                                }
                                if(entry["children-Set"]["rp.FromCriteria"]["children-Set"])
                                {
                                    if(entry["children-Set"]["rp.FromCriteria"]["children-Set"]["rp.CommunityExpression"] == null)
                                    {
                                       entry["children-Set"]["rp.FromCriteria"]["children-Set"]["rp.CommunityExpression"] = [];
                                    }
                                    if(entry["children-Set"]["rp.FromCriteria"]["children-Set"]["rp.PSPolicyVariables"] == null)
                                    {
                                       entry["children-Set"]["rp.FromCriteria"]["children-Set"]["rp.PSPolicyVariables"] = [];
                                    }
                                    else {
                                      let policyVariables=  entry["children-Set"]["rp.FromCriteria"]["children-Set"]["rp.PSPolicyVariables"];
                                      policyVariables.forEach(pventry => {
                                          if(pventry["policyVarValue"] && pventry["policyVarValue"] == "N/A")
                                          {
                                            delete pventry["policyVarValue"];
                                          }
                                      })
                                    }
                                    if(entry["children-Set"]["rp.FromCriteria"]["children-Set"]["rp.FromCriteriaPrefixListMembers"])
                                    {
                                        if(entry["children-Set"]["rp.FromCriteria"]["children-Set"]["rp.FromCriteriaPrefixListMembers"]["addPrefixListMemberName"] == null)
                                        {
                                            entry["children-Set"]["rp.FromCriteria"]["children-Set"]["rp.FromCriteriaPrefixListMembers"]["addPrefixListMemberName"] = "";
                                        }
                                    }
                                    else
                                    {
                                        entry["children-Set"]["rp.FromCriteria"]["children-Set"]["rp.FromCriteriaPrefixListMembers"] = new Object();
                                        entry["children-Set"]["rp.FromCriteria"]["children-Set"]["rp.FromCriteriaPrefixListMembers"]["addPrefixListMemberName"] = "";
                                    }
                                    if(!isAudit && entry["children-Set"]["rp.FromCriteria"]["nextHopPrefixList"] && entry["children-Set"]["rp.FromCriteria"]["nextHopPrefixList"] == "N/A")
                                    {
                                      entry["children-Set"]["rp.FromCriteria"]["nextHopPrefixList"] = "";
                                    }
                                    if(entry["children-Set"]["rp.FromCriteria"]["addInterfaceNames"] == null)
                                    {
                                       entry["children-Set"]["rp.FromCriteria"]["addInterfaceNames"] = "N/A";
                                    }
                                    if(entry["children-Set"]["rp.FromCriteria"]["protocolBits"] == null)
                                    {
                                        entry["children-Set"]["rp.FromCriteria"]["protocolBits"] = ["none"];
                                    }
                                    if(entry["children-Set"]["rp.FromCriteria"]["family"] == null)
                                    {
                                       entry["children-Set"]["rp.FromCriteria"]["family"] = "";
                                    }
                                }
                            }
                        }
                        if(!entry["enableToCriteria"])
                        {
                            entry["children-Set"]["rp.ToCriteria"] = undefined;
                        }
                        else
                        {
                            if(entry["children-Set"]["rp.ToCriteria"]["protocolBits"] == null)
                            {
                               entry["children-Set"]["rp.ToCriteria"]["protocolBits"] = ["none"];
                            }
                            if(entry["children-Set"]["rp.ToCriteria"]["children-Set"] == null)
                            {
                                entry["children-Set"]["rp.ToCriteria"]["children-Set"] = new Object();
                            }
                            if(entry["children-Set"]["rp.ToCriteria"]["children-Set"])
                            {
                                if(entry["children-Set"]["rp.ToCriteria"]["children-Set"]["rp.ToCriteriaPrefixListMembers"])
                                {
                                    if(entry["children-Set"]["rp.ToCriteria"]["children-Set"]["rp.ToCriteriaPrefixListMembers"]["addPrefixListMemberName"] == null)
                                    {
                                        entry["children-Set"]["rp.ToCriteria"]["children-Set"]["rp.ToCriteriaPrefixListMembers"]["addPrefixListMemberName"] = "";
                                    }
                                }
                                else
                                {
                                    entry["children-Set"]["rp.ToCriteria"]["children-Set"]["rp.ToCriteriaPrefixListMembers"] = new Object();
                                    entry["children-Set"]["rp.ToCriteria"]["children-Set"]["rp.ToCriteriaPrefixListMembers"]["addPrefixListMemberName"] = "";
                                }
                            }
                        }
                        entry["enableFromCriteria"] = undefined;
                        entry["enableToCriteria"] = undefined;
                    });
                    statementConfig["children-Set"]["rp.PolicyStatementEntry"] = policyStmtEntries;
                }
            }
            payload["configInfo"]["rp.PolicyStatement"]  = statementConfig;
        }
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        if(targetValue && targetValue != "N/A")
        {
            if(xpath == "rp-PolicyStatementEntry.rp-Action.srMaintPolicy" || xpath == "rp-DefaultAction.srMaintPolicy")
            {
                targetValue = "srMaintenance:srmaint-"+ targetValue;
            }
            if(xpath == "rp-PolicyStatementEntry.rp-Action.adminTagPolicy" || xpath == "rp-DefaultAction.adminTagPolicy")
            {
                targetValue = "rtrAdminTagPolicy:rtr-1-ratpol-" + targetValue;
            }
            if(xpath == "rp-PolicyStatementEntry.rp-FromCriteria.rp-PSFromCriteriaPrefixListOverride.prefixListOverrideName")
            {
                targetValue = "rpPrefixList:prefix-list-" + targetValue;
            }
            if(xpath == "rp-PolicyStatementEntry.rp-FromCriteria.routeDistinguisherPointer")
            {
                targetValue = "routeDistinguisher:rd-" + targetValue;
            }
            if(xpath == "rp-DefaultAction.srv6Locator" || xpath == "rp-PolicyStatementEntry.rp-Action.srv6Locator")
            {
                targetValue = "network:"+neId+":router-1:srv6:srv6Loc-"+targetValue;
            }
            if(xpath == "rp-DefaultAction.multicastRedirectionInterface" || xpath == "rp-PolicyStatementEntry.rp-Action.multicastRedirectionInterface")
            {
                if (targetValue && targetValue!= "N/A")
                {
                    targetValue = nfmpSuggest.getInterfaceData(neId, targetValue, "terminatedObjectName", "objectFullName");
                }
            }
            if(isAudit)
            {
               if(xpath == "rp-DefaultAction.nextHop" ||
                    xpath == "rp-DefaultAction.bfdSidValue" ||
                    xpath == "rp-PolicyStatementEntry.rp-Action.nextHop" ||
                    xpath == "rp-PolicyStatementEntry.rp-Action.bfdSidValue" ||
                    xpath == "rp-PolicyStatementEntry.rp-FromCriteria.nextHop" ||
                    xpath == "rp-PolicyStatementEntry.rp-FromCriteria.endPoint" ||
                    xpath == "rp-PolicyStatementEntry.rp-FromCriteria.neighborIpAddress" ||
                    xpath == "rp-PolicyStatementEntry.rp-ToCriteria.neighborIpAddress" ||
                    xpath == "rp-PolicyStatementEntry.rp-FromCriteria.srv6SidPrefixAddress" ||
                    xpath == "rp-PolicyStatementEntry.rp-FromCriteria.rp-PSPolicyVariables.policyVarAddress")
               {
                    if(ipv6AddrUtil.matchExact(ipv6Regex,targetValue))
                    {
                        targetValue = ipv6AddrUtil.expandIPv6AddressForClassic(targetValue);
                    }
               }
               if(xpath == "rp-PolicyStatementEntry.rp-FromCriteria.rp-PSPolicyVariables.policyVarDecimal")
               {
                  targetValue = Number(targetValue);
                  targetValue = targetValue.toFixed(3);
               }
            }
        }
        if(xpath == "rp-DefaultAction.rp-DefaultAddCommunityAction.addCommunityName" ||
            xpath == "rp-DefaultAction.rp-DefaultRemoveCommunityAction.removeCommunityName" ||
             xpath == "rp-DefaultAction.rp-DefaultReplaceCommunityAction.replaceCommunityName" ||
             xpath == "rp-PolicyStatementEntry.rp-Action.rp-AddCommunityAction.addCommunityName" ||
             xpath == "rp-PolicyStatementEntry.rp-Action.rp-RemoveCommunityAction.removeCommunityName" ||
             xpath == "rp-PolicyStatementEntry.rp-Action.rp-ReplaceCommunityAction.replaceCommunityName" ||
             xpath == "rp-PolicyStatementEntry.rp-FromCriteria.addInterfaceNames" ||
             xpath == "rp-PolicyStatementEntry.rp-FromCriteria.rp-FromCriteriaPrefixListMembers.addPrefixListMemberName" ||
             xpath == "rp-PolicyStatementEntry.rp-ToCriteria.rp-ToCriteriaPrefixListMembers.addPrefixListMemberName")
        {
            if(targetValue)
            {
                targetValue = targetValue.map(item => `"${item}"`).join(" ");
            }
            else
            {
                targetValue = "N/A"
            }
        }
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
        if(targetValue && targetValue != "N/A")
        {
            if(xpath == "rp-PolicyStatementEntry.rp-Action.srMaintPolicy" || xpath == "rp-DefaultAction.srMaintPolicy")
            {
                targetValue = targetValue.replace("srMaintenance:srmaint-", "");
            }
            if(xpath == "rp-PolicyStatementEntry.rp-Action.adminTagPolicy" || xpath == "rp-DefaultAction.adminTagPolicy")
            {
                targetValue = targetValue.replace("rtrAdminTagPolicy:rtr-1-ratpol-", "");
            }
            if(xpath == "rp-PolicyStatementEntry.rp-FromCriteria.rp-PSFromCriteriaPrefixListOverride.prefixListOverrideName")
            {
                targetValue = targetValue.replace("rpPrefixList:prefix-list-", "");
            }
            if(xpath == "rp-PolicyStatementEntry.rp-FromCriteria.routeDistinguisherPointer")
            {
                targetValue = targetValue.replace("routeDistinguisher:rd-", "");
            }
            if(xpath == "rp-DefaultAction.srv6Locator" || xpath == "rp-PolicyStatementEntry.rp-Action.srv6Locator")
            {
                let parts = targetValue.split("router-1:srv6:srv6Loc-");
                if (parts.length > 1) {
                    targetValue = parts[1].split(":")[0];
                }
            }
            if(xpath == "rp-DefaultAction.multicastRedirectionInterface" || xpath == "rp-PolicyStatementEntry.rp-Action.multicastRedirectionInterface")
            {
                if (targetValue && targetValue!= "N/A")
                {
                    targetValue = nfmpSuggest.getInterfaceData("", targetValue, "objectFullName", "terminatedObjectName");
                }
            }
            if(xpath == "rp-DefaultAction.rp-DefaultAddCommunityAction.addCommunityName" ||
                xpath == "rp-DefaultAction.rp-DefaultRemoveCommunityAction.removeCommunityName" ||
                 xpath == "rp-DefaultAction.rp-DefaultReplaceCommunityAction.replaceCommunityName" ||
                 xpath == "rp-PolicyStatementEntry.rp-Action.rp-AddCommunityAction.addCommunityName" ||
                 xpath == "rp-PolicyStatementEntry.rp-Action.rp-RemoveCommunityAction.removeCommunityName" ||
                 xpath == "rp-PolicyStatementEntry.rp-Action.rp-ReplaceCommunityAction.replaceCommunityName" ||
                 xpath == "rp-PolicyStatementEntry.rp-FromCriteria.addInterfaceNames" ||
                 xpath == "rp-PolicyStatementEntry.rp-FromCriteria.rp-FromCriteriaPrefixListMembers.addPrefixListMemberName" ||
                 xpath == "rp-PolicyStatementEntry.rp-ToCriteria.rp-ToCriteriaPrefixListMembers.addPrefixListMemberName")
            {
                if(targetValue != "" && targetValue != "N/A" )
                {
                    let matches = targetValue.match(/"([^"]*)"/g);
                    targetValue =  matches ? matches.map(str => str.replace(/"/g, '')) : [];
                }
                else
                {
                    targetValue = [];
                }
            }
        }
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
}