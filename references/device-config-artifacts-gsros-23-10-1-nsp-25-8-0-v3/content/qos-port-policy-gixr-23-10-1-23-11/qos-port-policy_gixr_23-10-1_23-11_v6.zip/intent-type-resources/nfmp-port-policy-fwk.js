var RuntimeException = Java.type("java.lang.RuntimeException");
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

var port_qos_full_class_name = "ixrqos.PortQosPolicy";
var port_qos_policy_name = "displayedName";
var port_qos_fdn = "PortQosPolicy7250SROS";

function NfmpPortPolicyFwk() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var isAudit = false;
    var isLocalExists = false;
    var isGlobalExists = false;
    var isEdit = false;

    this.synchronize = function(input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {

        if (input.getNetworkState().name() == "delete") {
            logger.info(LOG_PREFIX + "Calling syncDelete");
            return this.syncDelete(input, result);
        }
        var savedTopology = input.getCurrentTopology();
        logger.info(LOG_PREFIX + "Saved Topology = " + savedTopology);
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyName = parseTarget.getUniqueIdentifier(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];

        intentConfig = this.removeEmptyContainers("", intentConfig,"", neId);

        intentConfig[port_qos_policy_name] = policyName;
        logger.info(LOG_PREFIX + "Configuration of Port QoS Policy to be pushed = " + JSON.stringify(intentConfig));
        logger.info(LOG_PREFIX + "Target device = " + neId);
        logger.info(LOG_PREFIX + "Target Qos Network = " + policyName);
        this.createOrModify(neId, intentConfig);
   
        return util.setSuccessResult(result, savedTopology);
    }

    this.createOrModify = function (neId, intentConfig) {
        var objectFullName = port_qos_fdn + ":" + intentConfig[port_qos_policy_name];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        logger.info(LOG_PREFIX + "Searching if any local policy exists on NE: " + neId);
        var localPolicy = util.getIfObjectExists(port_qos_full_class_name, localPolicyFullName);
        logger.info(LOG_PREFIX + "localPolicy: " + JSON.stringify(localPolicy));
        var result;
        var portQosPolicyPayload;
        var distributeResult;

        if (localPolicy != null) {
            isLocalExists = true;
            isGlobalExists = true;
            if (localPolicy[0]["displayedName"] !== intentConfig[port_qos_policy_name]) {
                throw new RuntimeException("Already there exists a policy on " + neId +
                    " with policy name " + localPolicy[0]["displayedName"]);
            }
            portQosPolicyPayload = this.createPortQosPolicyPayload(neId, intentConfig, isLocalExists, localPolicy);
            result = this.modifyRequest(neId, portQosPolicyPayload);
            if (!util.isObjectExists(port_qos_full_class_name, localPolicyFullName)) {
                throw new RuntimeException('Unable to Create/Distribute Policy: ' + intentConfig[port_qos_policy_name] +
                    " , Kindly check the intent configuration");
            }
        }
        else {
            logger.info(LOG_PREFIX + "Unable to find the local policy, Trying to fetch global policy if available");
            var searchPayload = this.constructSearchString(neId, intentConfig[port_qos_policy_name]);
            var searchResponse = nfmpFwk.find(neId, searchPayload);
            if (!(searchResponse.success && JSON.stringify(searchResponse.response) === "")) {
                if (!searchResponse.success) {
                    logger.info(LOG_PREFIX + "createOrModify(): Unable to get Policy info from nfm-p for Ne " +
                        neId + " and Policy name: " + intentConfig[port_qos_policy_name]);
                }
                if (searchResponse.response === "") {
                    logger.info(LOG_PREFIX + "createOrModify(): There is no QoS Port policy with Name:" +
                        intentConfig[port_qos_policy_name] + " on " + neId);
                }
            }
            else {
                throw new RuntimeException("createOrModify(): There exists a QoS Port policy " + intentConfig[port_qos_policy_name] + " on " +
                    neId + " with ID " + JSON.parse(searchResponse["response"])[0]["displayedName"]);
            }

            var globalPolicy = util.getIfObjectExists(port_qos_full_class_name, objectFullName);
            if (globalPolicy != null) {
                isGlobalExists = true;
                if (globalPolicy[0]["displayedName"] !== intentConfig[port_qos_policy_name]) {
                    logger.info(LOG_PREFIX + "createOrModify(): There exists a QoS Port global policy in NFMP with policy name " +
                        globalPolicy[0]["displayedName"] + " on: " + neId);
                    logger.info(LOG_PREFIX + "createOrModify(): Updating QoS Port global policy name to " +
                        intentConfig[port_qos_policy_name] + "on " + neId );
                    this.updatePortPolicyName(neId, objectFullName, intentConfig[port_qos_policy_name]);
                }

                distributeResult = this.distributePolicy(neId, objectFullName, false);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributeResult = this.distributePolicy(neId, objectFullName, true);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                logger.info(LOG_PREFIX + "checking distribution of existing global policy");
                if (!util.isObjectExists(port_qos_full_class_name, localPolicyFullName)) {
                    throw new RuntimeException("Unable to Distribute existing Global Policy: " + intentConfig[port_qos_policy_name] +
                        " , Kindly check the Global Policy configuration");
                }
                logger.info(LOG_PREFIX + "distribution of existing global policy was successful, updating with intent configuration");
                portQosPolicyPayload = this.createPortQosPolicyPayload(neId, intentConfig, true, null);
                result = this.modifyRequest(neId, portQosPolicyPayload);
                if (!util.isObjectExists(port_qos_full_class_name, localPolicyFullName)) {
                    throw new RuntimeException('Unable to Create/Distribute Policy: ' + intentConfig[port_qos_policy_name] +
                        " , Kindly check the intent configuration");
                }
            }
            else {
                //distributing empty policy
                logger.info(LOG_PREFIX + "Unable to find the Global Policy, distributing empty policy and updating");
                portQosPolicyPayload = this.createPortQosPolicyPayload(neId, intentConfig, false, null);
                result = this.modifyRequest(neId, portQosPolicyPayload);
                distributeResult = this.distributePolicy(neId, objectFullName, false);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributeResult = this.distributePolicy(neId, objectFullName, true);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                //updating the local policy with intent configuration
                portQosPolicyPayload = this.createPortQosPolicyPayload(neId, intentConfig, true, null);
                result = this.modifyRequest(neId, portQosPolicyPayload);
            }
        }
        return result;
    }

    this.constructSearchString = function(neId, policyName, policyId) {
        logger.info(LOG_PREFIX + "Creating search payload for NE ID : " + neId + " with Policy Name : " + policyName);
        var jsonPayLoad = {
            "fullClassName": port_qos_full_class_name,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName",
                    "id"
                ]
            }
        };
        var nameSearchObj = {
            "name": "policyName",
            "value": policyName
        };
        var idSearchObj = {
            "name": "id",
            "value": policyId
        };
        if (policyName !== undefined) {
            jsonPayLoad["filter"]["and"]["equal"].push(nameSearchObj);
        }
        else {
            jsonPayLoad["filter"]["and"]["equal"].push(idSearchObj);
        }
        return jsonPayLoad;
    }

    this.updatePortPolicyName = function (neId, objectFullName, policyName) {
        var payload = {};
        var configInfo = {};
        var properties = {};
        properties["displayedName"] = policyName;

        configInfo[port_qos_full_class_name] = properties;
        payload["distinguishedName"] = port_qos_fdn;
        payload["objectFullName"] = objectFullName;
        payload["clearOnDeployFailure"] = true;
        payload["configInfo"] = configInfo;
        logger.info(LOG_PREFIX + "Payload for updating Global Policy name : " + JSON.stringify(payload));
        return this.modifyRequest(neId, payload);
    }

    this.createPortQosPolicyPayload = function (neId, intentConfig, isLocalExists, policyObject) {
        var objectFullName = port_qos_fdn + ":" + intentConfig[port_qos_policy_name];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        if (isAudit || isLocalExists) {
            objectFullName = localPolicyFullName;
        }

        var properties = {};
        var childProperties = {};
        properties["displayedName"] = intentConfig[port_qos_policy_name];

        if (isLocalExists) {
            for (var attribute in intentConfig) {
                switch (attribute) {
                    case "description":
                        properties["description"] = intentConfig[attribute];
                        break;
                    case "scope":
                        properties["scope"] = intentConfig[attribute];
                        break;
                    case "packet-byte-offset":
				
                        if (intentConfig[attribute]["add"] !== undefined && intentConfig[attribute]["add"] !== null) {

                            properties["packetByteOffset"] = parseInt(intentConfig[attribute]["add"]);
                        }
                        if (intentConfig[attribute]["subtract"] !== undefined && intentConfig[attribute]["subtract"] !== null) {

                            properties["packetByteOffset"] = -parseInt(intentConfig[attribute]["subtract"]);
                        }
                        break;
                    case "queue":
                        this.createQueuePayload(neId, intentConfig, childProperties);
                        break;
                    case "wrr-weights":
                        this.createWrrWeightsPayload(neId, intentConfig, childProperties);
                        break;
                }
            }
        }
        return util.editPayload(port_qos_fdn, properties, childProperties, port_qos_full_class_name, objectFullName);
    }

    this.createWrrWeightsPayload = function (neId, intentConfig, childProperties) {
        var wrrWeightsClassName = "ixrqos.PortQosWrrWeights";
        var properties = {};
        var wrrWeightsConfig = intentConfig["wrr-weights"];
        for (var attribute in wrrWeightsConfig) {
            switch (attribute) {
                case "wrr-weights-id":
                    properties["id"] = wrrWeightsConfig[attribute];
                    break;
                case "uc-weight":
                    properties["ucWeight"] = wrrWeightsConfig[attribute];
                    break;
                case "mc-weight":
                    properties["mcWeight"] = wrrWeightsConfig[attribute];
                    break;
            }
        }
        childProperties[wrrWeightsClassName] = properties;
    }
    
    this.createQueuePayload = function (neId, intentConfig, childProperties) {
        var queuePayloadArray = [];
        var queueClassName = "ixrqos.PortQosQueue";
        if (!Array.isArray(intentConfig["queue"])) {
            intentConfig["queue"] = [intentConfig["queue"]];
        }
        for (var idx in intentConfig["queue"]) {
            var queueConfig = intentConfig["queue"][idx];
            var queuePayload = this.configureQueuePayload(neId, queueConfig);
            queuePayloadArray.push(queuePayload);
        }
        childProperties[queueClassName] = queuePayloadArray;
    }
    
    this.configureQueuePayload = function (neId, queueConfig) {
        var deviceType = util.getIxrType(neId);
        var properties = {};
        if (queueConfig) {
            for (var queueData in queueConfig) {
                switch (queueData) {
                    case "queue-id":
                        properties["id"] = queueConfig[queueData];
                        break;
                    case "queue-mgmt":
                        properties["queueMgmtPolicy"] = queueConfig[queueData];
                        break;
                    case "wrr-weights":
                        properties["wrrWeight"] = queueConfig[queueData];
                        break;
                    case "low-latency":
                        if (deviceType["type"].startsWith("7250 IXR-x") || deviceType["type"].startsWith("7250 IXR-x3") || deviceType["type"].startsWith("7250 IXR-x1") || deviceType["type"].startsWith("7250 IXR-R6d") || deviceType["type"].startsWith("7250 IXR-R6dl") || deviceType["type"].startsWith("7250 IXR-e2")) {
                            properties["lowLatency"] = queueConfig[queueData];
                        }
                        break;
                    case "adaptation-rule":
                        var adaptObj = queueConfig[queueData];
                        if (adaptObj["pir"]) {
                            properties["pirAdaptation"] = adaptObj["pir"];
                        }
                        if (adaptObj["cir"]) {
                            properties["cirAdaptation"] = adaptObj["cir"];
                        }
                        break;
                    case "scheduler-mode":
                        if (queueConfig[queueData]["wfq"]) {
                            properties["schedulerMode"] = "wfq";
                            properties["pirWeight"] = queueConfig[queueData]["wfq"]["pir-weight"];
                            var percentRate = queueConfig[queueData]["wfq"]["percent-rate"];

                            if (!isNaN(parseFloat(percentRate["pir"]))) {
                                if (Number(parseFloat(percentRate["pir"])) % 1 == 0) {
                                    properties["pirPercent"] = Number(parseFloat(percentRate["pir"])).toFixed(1);
                                } else {
                                    properties["pirPercent"] = Number(parseFloat(percentRate["pir"]));
                                }
                            }
                            if (!isNaN(parseFloat(percentRate["cir"]))) {
                                if (Number(parseFloat(percentRate["pir"])) % 1 == 0) {
                                    properties["cirPercent"] = Number(parseFloat(percentRate["cir"])).toFixed(1);
                                } else {
                                    properties["cirPercent"] = Number(parseFloat(percentRate["cir"]));
                                }
                            }
                        }
                        break;
                }
            }
        }
        return properties;
    }

    this.distributePolicy = function(nodeIp, objectFullName, localEdit) {
        logger.info(LOG_PREFIX + "localEdit : " + localEdit);
        var payload = {};
        if (localEdit === false) {
            payload["policy.PolicyDefinition.distributeV2"] = {};
            payload["policy.PolicyDefinition.distributeV2"]["clearOnDeployFailure"] = true;
            payload["policy.PolicyDefinition.distributeV2"]["deployer"] = "immediate";
            payload["policy.PolicyDefinition.distributeV2"]["instanceFullName"] = objectFullName;
            payload["policy.PolicyDefinition.distributeV2"]["siteIds"] = {};
            payload["policy.PolicyDefinition.distributeV2"]["siteIds"]["string"] = nodeIp;
            logger.info(LOG_PREFIX + objectFullName + ": policy distribute Payload: " + JSON.stringify(payload));
        }
        else {
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"] = {};
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["clearOnDeployFailure"] = true;
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["deployer"] = "immediate";
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["instanceFullName"] = objectFullName;
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["siteIds"] = {};
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["siteIds"]["string"] = nodeIp;
            logger.info(LOG_PREFIX + objectFullName + ": policy switch to local edit only Payload for " + nodeIp+ " : " + JSON.stringify(payload));
        }

        return nfmpFwk.post("/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true", payload);
    }

    this.syncDelete = function (input, result) {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyName = parseTarget.getUniqueIdentifier(input.getTarget());
        var objectFullName = port_qos_fdn + ":" + policyName;
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        var localPolicy = util.getIfObjectExists(port_qos_full_class_name, localPolicyFullName);
        logger.info(LOG_PREFIX + "Deleting search response : " + JSON.stringify(localPolicy));
        if (localPolicy !== null) {
            logger.info(LOG_PREFIX + "syncDelete(): Deleting " + localPolicyFullName);
            var deleteResult = nfmpFwk.deployDelete(localPolicyFullName, "application/json");
            if (!deleteResult.success) {
                logger.info(LOG_PREFIX + "syncDelete(): Unable to Delete: " + deleteResult.msg);
                throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
            }
            result.setSuccess(true);
        }
        else {
            logger.info(LOG_PREFIX + "syncDelete(): There is no Port QoS policy with Name:" +
                policyName + " on " + neId);
            result.setSuccess(false);
        }
    }

    this.modifyRequest = function (neId, payload) {
        logger.info(LOG_PREFIX + "Sending the modify request for MDT");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
           logger.error("Error result = {}",JSON.stringify(result));
           let errorMsg = result.msg;
           if(errorMsg.indexOf("object already exists") !== -1)
           {
               logger.info("Global policy Object already exists, Re-checking the Policy existence ");
               //util.delay(2000);
               let configInfo = payload.configInfo;
               let fullClassName;
               for (let key in configInfo) {
                 if (configInfo.hasOwnProperty(key)) {
                   fullClassName = key;
                   break;
                 }
               }
               let objectFullName = payload.objectFullName;
               objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
               logger.info("fullClassName = {}",fullClassName);
               logger.info("objectFullName = {}",objectFullName);
               if (!util.isObjectExists(fullClassName, objectFullName))
               {
                   throw new RuntimeException("Global Policy Object Not Found!!!");
               }
           }
           else
           {
               throw new RuntimeException(result.msg);
           }
        }
        return result;
    }

    this.audit = function(target, config, svcTopo, adminState, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        isAudit = true;
        var neId = parseTarget.getNeIdFromTarget(target);
        var policyName = parseTarget.getUniqueIdentifier(target);
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        intentConfig = this.removeEmptyContainers("",intentConfig,"",neId);
        logger.info(LOG_PREFIX + "auditing configuration = "+JSON.stringify(intentConfig));
        logger.info(LOG_PREFIX + "Target device = " + neId);
        logger.info(LOG_PREFIX + "Target Network QoS = " + policyName);
        intentConfig[port_qos_policy_name] = policyName;
        if (intentConfig) {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else {
            throw "configuration not available in the intent";
        }
        return auditReport;
    }

    this.auditAndCompare = function (target, intentConfig, auditReport) {
        var portQosPolicyPayload = this.createPortQosPolicyPayload(target, intentConfig, true, null);
        var result = this.auditRequest(target, portQosPolicyPayload);
        auditReport = util.reportMisaligned(target, result, auditReport);
        return auditReport;
    }

    this.auditRequest = function (target, payLoad) {
        logger.info(LOG_PREFIX + "Sending the audit request for mdt");
        logger.info(JSON.stringify(payLoad));
        var result = nfmpFwk.compare(target, JSON.stringify(payLoad), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.removeEmptyContainers= function(prop, intentJson, path, target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop,intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop,intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }

    this.xml2object = function(xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: '+ json)
        return JSON.parse(json);
    }
}
