var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
const icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
const gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})
var nfmpSuggest = new NfmpSuggest();

let intentTypeName = "qos-sap-egress_csros_23-10-1_24-4";

// example port, sap-ingress etc..
let initialPropertyName = "aengr-Policy";

var LOG_PREFIX = "[QOS Sap Egress]: "

// unique identifier
let uniqueIdentifier = "id,policyName";


/**
 * This function is starting point by IM for sync operation
 * @param input
 * @returns {*}
 */
function synchronize(input) {
    logger.info(LOG_PREFIX + "-------------------- script-content.js -> synchronize() --------------------");
    logger.info(LOG_PREFIX + "Intent Synchronisation started - input = {}", input)
    return NspIntentHelper.synchronize(input, intentTypeName, initialPropertyName, uniqueIdentifier);
}

/**
 * The function is starting point for audit operation in IM
 * @param input
 * @returns {*}
 */
function audit(input) {
    logger.info(LOG_PREFIX + "-------------------- script-content.js -> audit() --------------------");
    logger.info(LOG_PREFIX + "Intent Audit started - input = {}", input)
    return NspIntentHelper.audit(input, intentTypeName, initialPropertyName, uniqueIdentifier)
}

/**
 * This function returns NE-ID
 *
 * @param context
 * @returns {string}
 */
function getNeId(context) {
    logger.info(LOG_PREFIX + "-------------------- script-content.js -> getNeId() --------------------");
    let neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    if ((target == undefined || target == "") && context.getInputValues()["arguments"]["__root"])
    {
        target = context.getInputValues()["arguments"]["__root"]["target_objectidentifier"];
    }
    if((target == undefined || target == "") && context.getInputValues()["arguments"]["__parent"])
    {
        target = context.getInputValues()["arguments"]["__parent"]["target_objectidentifier"];
    }
    logger.info(LOG_PREFIX + "target = {}", target)
    if (target)
    {
        if(target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    logger.info(LOG_PREFIX + "NeId : " + neId);
    return neId;
}

/**
 * The function is used in Brownfield discovery by ICM Framework
 * It discover's the configuration from the target device
 * and manipulate as per Template's default-target-data
 *
 * @see ICMFwk for more details
 * @param {*} input - the config data of a deployment
 * @returns result - the result of the operation
 */
function getTargetData(input) {
    logger.info(LOG_PREFIX + "-------------------- script-content.js -> getTargetData() --------------------");
    logger.info(LOG_PREFIX + "getTargetData input for brownfield = \n" + input);
    let target = input.target;
    let config = null;
    logger.info(LOG_PREFIX + "target=" + target);
    let deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info(LOG_PREFIX + "deviceConfig = {} ", JSON.stringify(deviceConfig));
    let data = gtdFwk.gtdSend(deviceConfig);
    logger.info(LOG_PREFIX + "data = {}", JSON.stringify(data));
    logger.info(LOG_PREFIX + "returning result = {}", JSON.stringify(data.msg.result));
    return data.msg.result;
}


function suggestPostPolicerMappingPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestPostPolicerMappingPolicyName context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getPostPolicerMappingPolicyName(neId);
}

function suggestHsAttachmentPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestHsAttachmentPolicyName context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getHsAttachmentPolicyName(neId);
}

function suggestHsmdaWrrPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestHsmdaWrrPolicyName context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getHsmdaWrrPolicyName(neId);
}

function suggestAdvancedConfigPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestAdvancedConfigPolicyName context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getAdvancedConfigPolicyName(neId);
}

function suggestIpPrefixListName(context) {
    logger.info(LOG_PREFIX + "suggestIpPrefixListName context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getIpPrefixListName(neId);
}

function suggestIpv6PrefixListName(context) {
    logger.info(LOG_PREFIX + "suggestIpv6PrefixListName context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getIpv6PrefixListName(neId);
}

function suggestHsmdaSlopePolicyName(context) {
    logger.info(LOG_PREFIX + "suggestHsmdaSlopePolicyName context = \n" + context);
    var neId = getNeId(context); 
    return nfmpSuggest.getHsmdaSlopePolicyName(neId);
}

function suggestSlopePolicyName(context) {
    logger.info(LOG_PREFIX + "suggestSlopePolicyName context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getSlopePolicyName(neId);
}
   
function suggestSlopePolicerId(context) {
    logger.info(LOG_PREFIX + "suggestSlopePolicerId context = \n" + context);
    return nfmpSuggest.getSlopePolicerId();
}

function suggestParentArbiterName(context) {
    logger.info(LOG_PREFIX + "suggestParentArbiterName context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getParentArbiterName(neId);
}

function suggestSchedulerName(context) {
    logger.info(LOG_PREFIX + "suggestSchedulerName context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getSchedulerName(neId);
}

function suggestQueueId(context) {
    var queue_id=[];
    logger.info(LOG_PREFIX + "suggestQueueId context = \n" + context);
    var queues = context['inputValues']['arguments']['__root']['aengr-Policy']['aengr-Queue'];
    queues.forEach(function(queueObject) {
        logger.info("Queue Id in Input : " + queueObject['id']);
        queue_id.push(queueObject['id']);
    });
    return queue_id;
}

function suggestPolicerId(context) {
    var policer_id=[];
    logger.info(LOG_PREFIX + "suggestPolicerId context = \n" + context);
    var policers = context['inputValues']['arguments']['__root']['aengr-Policy']['aengr-Policer']
    policers.forEach(function(policerObject) {
        logger.info("policer Id in Input : " + policerObject['id']);
        policer_id.push(policerObject['id']);
    });
    return policer_id;
}
function suggestPolicyId(context) {
    logger.info("suggestPolicyId context = \n" + context);
    var neId = getNeId(context);
    let policyName = undefined;
    var templateName = context.getInputValues()["target"]["templatename"];
    if(context.getInputValues()["target"]["target"])
    {
        policyName = context.getInputValues()["target"]["target"][templateName]["target_policyName"]
    }
    else
    {
        policyName = context.getInputValues()["target"]["policyName"]
    }
    return nfmpSuggest.getPolicyId(neId,policyName);
}
function suggestPolicyName(context) {
    logger.info("suggestPolicyName context = \n" + context);
    var neId = getNeId(context);
    let policyId = undefined;
    var templateName = context.getInputValues()["target"]["templatename"];
    if(context.getInputValues()["target"]["target"])
    {
        policyId = context.getInputValues()["target"]["target"][templateName]["target_id"]
    }
    else
    {
        policyId = context.getInputValues()["target"]["id"]
    }
    return nfmpSuggest.getPolicyName(neId,policyId);
}

function suggestQueueGroupTemplatePolicyName(context) {
    logger.info("suggestQueueGroupTemplatePolicyName context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getQueueGroupTemplatePolicyName(neId);
}

function suggestfcQueueId(context) {
    var queue_id = [];
    logger.info(LOG_PREFIX + "suggestFCQueueId context = \n" + context);
    let portRedirectGroupQueue = context['inputValues']['arguments']['portRedirectGroupQueue'];
    let mapping = context['inputValues']['arguments']['mapping'];
    if (mapping == 'queue' || (mapping == 'policer' && portRedirectGroupQueue == 'true')) {
        logger.info(LOG_PREFIX + "suggestQueueId context mapping= \n" + mapping);
        var queues = context['inputValues']['arguments']['__root']['aengr-Policy']['aengr-Queue'];
        queues.forEach(function (queueObject) { logger.info("Queue Id in Input : " + queueObject['id']); queue_id.push(queueObject['id']); }
        );
    } else {
        var neId = getNeId(context); var queueGroupPolicy = context['inputValues']['arguments']['queueGroup']; queue_id = nfmpSuggest.queueGroupQueueId(neId, queueGroupPolicy);
    }
    return queue_id;

}
