load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'MediatorFramework'});

function NspRestconfFwk() {
    this.mediatorFwk = new MediatorFramework("NSP");
}

NspRestconfFwk.prototype.RESTCONF_HOST = "restconf-gateway";
NspRestconfFwk.prototype.RESTCONF_PORT = "443";
NspRestconfFwk.prototype.mediatorFwk = null;
NspRestconfFwk.prototype.NSP_RESTCONF_INVENTORY_FIND_URL = "/restconf/operations/nsp-inventory:find";
NspRestconfFwk.prototype.NSP_CUSTOMER = "/nsp-customer:customers/customer";

NspRestconfFwk.prototype.constructURL = function (path, method) {
    var url = "https://" + this.RESTCONF_HOST + ":" + this.RESTCONF_PORT + path;
    logger.info("[RestconfFwk] {}Calling restconf via NSP Mediator: {}", method, url);
    return url;
};

NspRestconfFwk.prototype.getByXpath = function (xPath) {
    var url = this.constructURL("/restconf/data" + xPath, "GET");
    var response = this.mediatorFwk.fetch(url);
    logger.debug("[RestconfFwk][getByXpath] response = {}", JSON.stringify(response));
    if (response.httpStatus === 200) {
        return response["response"];
    } else {
        return null;
    }
};

NspRestconfFwk.prototype.findByXpath = function (xPath, depth, fields) {
    if (!depth)
    {
        depth = 3;
    }
    var url = this.constructURL(this.NSP_RESTCONF_INVENTORY_FIND_URL, "POST");
    var input = {};
    var ret = null;
    input["xpath-filter"] = xPath;
    input["depth"] = depth;
    if (fields !== undefined)
        input["fields"] = fields;
    var requestBody = {};
    requestBody["input"] = input;

    var response = this.mediatorFwk.post(url, requestBody);
    logger.info("[RestconfFwk][findByXpath] response = {}", JSON.stringify(response));

    if (response.httpStatus === 200 && response)
    {
        var lRes = JSON.parse(response["response"]);
        if (lRes && lRes["nsp-inventory:output"])
        {
            var data = JSON.parse(response["response"])["nsp-inventory:output"]["data"];
            if (data.length !== 0)
                ret = data;
        }
    }
    return ret;
};

NspRestconfFwk.prototype.findByXpathPaginated = function (xPath, depth, fields, offset) {
    if (!depth) depth = 3;
    if (!offset) offset = 0;
    var limit = 300;
    var url = this.constructURL(this.NSP_RESTCONF_INVENTORY_FIND_URL, "POST");
    var input = {};
    var ret = [];
    input["xpath-filter"] = xPath;
    input["depth"] = depth;
    if (fields !== undefined)
        input["fields"] = fields;
    input["offset"] = offset;
    input["limit"] = limit;
    var requestBody = {};
    requestBody["input"] = input;

    var response = this.mediatorFwk.post(url, requestBody);
    logger.info("[RestconfFwk][findByXpathPaginated] response = {}", JSON.stringify(response));

    if (response.httpStatus === 200 && response)
    {
        var lRes = JSON.parse(response["response"]);
        if (lRes && lRes["nsp-inventory:output"])
        {
            var data = lRes["nsp-inventory:output"]["data"];
            if (data.length !== 0)
            {
                ret = ret.concat(data);
            }
            if ((lRes["nsp-inventory:output"]["end-index"] + 1) !== lRes["nsp-inventory:output"]["total-count"])
            {
                ret = ret.concat(this.findByXpathPaginated(xPath, depth, fields, lRes["nsp-inventory:output"]["end-index"] + 1));
            }
        }
    }
    return ret;
};


NspRestconfFwk.prototype.getNspCustomer = function (customerId) {
    var xPath = null;
    if (customerId) {
        xPath = this.NSP_CUSTOMER + "[id="+customerId+"]";
    } else {
        xPath = this.NSP_CUSTOMER;
    }
    var result = {};
    var customerData = this.findByXpath(xPath, 3, "id;name;description;phone-number;contact;sites");
    if (customerData) {
        var ret = customerData.map(function (customer) {
            var obj = {};
            obj["customer-id"] = customer["id"];
            obj["customer-name"] = customer["name"];
            obj["phone"] = customer["phone-number"];
            obj["description"] = customer["description"];
            obj["contact"] = customer["contact"];
            if ( customer["sites"] !== undefined )
            {
                if (!Array.isArray(customer["sites"]))
                {
                    customer["sites"] = [customer["sites"]];
                }
                var sites = [];
                for (var i = 0; i < customer["sites"].length; i++)
                {
                    var site = {}
                    site["site-id"] = customer["sites"][i]["site-id"];
                    sites.push(site);
                }
                obj["sites"] = sites;
            }
            return obj;
        });
        result = ret[0];
    }
    return result;
};

NspRestconfFwk.prototype.getCustomerData = function () {
    var xPath = this.NSP_CUSTOMER;
    var result = {};
    var customerData = this.findByXpath(xPath, 1, "id;name");
    if (customerData) {
        var ret = customerData.map(function (customer) {
            var obj = {};
            obj["customer-id"] = customer["id"];
            obj["customer-name"] = customer["name"];
            return obj;
        });
        result = ret;
    }
    return result
}

NspRestconfFwk.prototype.getSites = function () {
    var xPath = "/nsp-equipment:network/network-element";
    var result = {};
    var resultFetch = this.findByXpathPaginated(xPath, 3, "ne-id");
    if (resultFetch) {
        var data = resultFetch.map(function (customer) {
            var obj = {};
            obj["site-id"] = customer["ne-id"];
            return obj;
        });
        result["data"] = JSON.stringify(data);
        logger.info("result = {}", JSON.stringify(result));
    }
    return result;
}

NspRestconfFwk.prototype.getNeId = function () {
    var xPath = "/nsp-equipment:network/network-element";
    var result = [];
    var data = this.findByXpathPaginated(xPath, 3, 'ne-id');
    if (data)
    {
        var ret = data.map(function (ne) {
            result.push(ne["ne-id"]);
        });
    }
    return result;
};


NspRestconfFwk.prototype.getByXpath = function (xPath) {
    var url = this.constructURL("/restconf/data" + xPath, "GET");
    var response = this.mediatorFwk.fetch(url);
    logger.debug("[RestconfFwk][getByXpath] response = {}", JSON.stringify(response));
    if (response.httpStatus === 200)
    {
        return response["response"];
    }
    else
    {
        return null;
    }
};
