function ModelDeviceMapping()
{
    this.getMapping = function(type)
    {
        switch(type)
        {
            case "IPfilter":
                return this.getIPFilterMapping();
            case "IPfilterEntry":
                return this.getIPFilterEntryMapping();
            default:
                return this.getIPFilterMapping();
        }
    }
    this.getIPFilterMapping = function ()
    {
        var mapping = {};
        mapping['ip-filter.description'] = 'description';
        mapping['ip-filter.default-action'] = 'defaultAction';
        return mapping;
    }

    this.getIPFilterEntryMapping = function ()
    {
        var mapping = {};
        mapping['ip-filter.entry.entry-id'] = 'id';
        mapping['ip-filter.entry.description'] = 'description';

        return mapping;
    }

}
