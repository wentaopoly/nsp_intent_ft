var RuntimeException = Java.type("java.lang.RuntimeException");
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk" });
load({ script: resourceProvider.getResource("map-fwk.js"), name: "MapFwk" });
load({
  script: resourceProvider.getResource("parse-target.js"),
  name: "ParseTarget",
});

function NfmpUtils() {
  var mapFwk = new MapFwk();
  var parseTarget = new ParseTarget();

  /**
   *
   * @param {*} input
   * @param {*} result
   * @param {*} intentTypeName
   * @param {*} initialPropertyName
   * @param {*} uniqueIdentifier
   * @returns
   */
  this.synchronize = function (
    input,
    result,
    intentTypeName,
    initialPropertyName,
    uniqueIdentifier
  ) {
    // code to handle delete
    if (input.getNetworkState().name() == "delete") {
      result.setSuccess(true);
      return result;
    }

    // code to handle sync
  };

  /**
   *
   * @param {*} target
   * @param {*} config
   * @param {*} svcTopo
   * @param {*} adminState
   * @param {*} auditReport
   * @param {*} intentTypeName
   * @param {*} initialPropertyName
   * @param {*} uniqueIdentifier
   */
  this.audit = function (
    target,
    config,
    svcTopo,
    adminState,
    auditReport,
    intentTypeName,
    initialPropertyName,
    uniqueIdentifier
  ) {
    // code to handle audit
  };
}
