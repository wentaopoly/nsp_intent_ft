function NfmpSuggest() {
    this.getPXC = function (neId) {
        let className = "pxc.PortCrossConnect";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "pxcId"
                ]
            }
        };
        return this.getData(searchObject, className, "pxcId")
    }
    this.getData = function (searchObjectJson, className, type) {
        let nfmpFwk = new NfmpFwk();
        let ret = [];
        let resultFetch = nfmpFwk.post("v3/search", searchObjectJson);
        logger.info(resultFetch.response);
        let finalResponse = JSON.parse(resultFetch.response);
        finalResponse = finalResponse[className];
        logger.info(JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse))
        {
            finalResponse = [finalResponse];
        }
        if (Object.keys(finalResponse).length !== 0)
        {
            finalResponse.forEach(function (value, index, array) {
                ret.push(value[type]);
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

    this.getPXCPortDetail = function (ret) {
        let className = "pxc.PortCrossConnect";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "pxcId"
                ]
            }
        };
        return this.getData(searchObject, className, "pxcId")
    }
}
