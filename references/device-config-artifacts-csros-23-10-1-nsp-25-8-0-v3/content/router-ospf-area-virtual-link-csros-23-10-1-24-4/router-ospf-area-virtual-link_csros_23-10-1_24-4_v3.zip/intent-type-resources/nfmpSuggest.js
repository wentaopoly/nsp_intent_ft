function NfmpSuggest() {
   this.getAuthenticationKeyChain = function (neId) {
        let className = "security.KeyChain";
        let searchObject = {
              "fullClassName": className,
              "filter": {
                  "and": {
                      "equal": [
                           {
                              "name": "siteId",
                              "value": neId
                          }
                      ]
                  }
              },
              "resultFilter": {
                  "children": "",
                  "attribute": [
               "displayedName"
                  ]
              }
        };
        return this.getData(searchObject, className, "displayedName");
   }

    this.getAreaSite = function (neId ,instanceId) {
        let className = "ospf.AreaSite";
        let searchObject = {
        "fullClassName": className,
        "filter": {
            "and": {
                "equal": [
                    {
                        "name": "siteId",
                        "value": neId
                    },
                    {
                       "name": "instanceIndex",
                       "value": instanceId

                   },
                   {
                      "name": "version",
                      "value": "2"
                   }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": [
                "areaId"
            ]
          }
        };
        var finalResponse = this.getData(searchObject, className, "areaId");
        if (Array.isArray(finalResponse) && finalResponse.length > 0) {
        var AreaId = finalResponse.filter(function(item) {
            return item === "0.0.0.0";
        });
        }else{
          return [];
        }
       return AreaId;
    }

    this.getInstanceIndex = function (neId) {
        let className = "ospf.Site";
        let searchObject = {
        "fullClassName": className,
        "filter": {
            "and": {
                "equal": [
                    {
                        "name": "siteId",
                        "value": neId
                    },
                    {
                       "name": "version",
                       "value": "v2"
                    }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": [
                "instanceIndex"
             ]
           }
        };
        return this.getData(searchObject, className, "instanceIndex");
    }

    this.getTransitArea = function (neId ,instanceId, virtualNeighborRouterId, actionType) {
        let className1 = "ospf.VirtualLink";
        let className2 = "ospf.AreaSite";
        if(actionType === "associate"){
        let searchObject1 = {
         "fullClassName": className1,
           "filter": {
             "and": {
               "equal": [
                  {
                     "name": "siteId",
                     "value": neId
                  },
                  {
                    "name":"version",
                    "value":"2"
                  },
                  {
                    "name":"instanceIndex",
                    "value":instanceId
                  },
                  {
                    "name":"virtualNeighborRouterId",
                    "value": virtualNeighborRouterId
                  },
                  {
                    "name":"areaId",
                    "value":"0.0.0.0"
                  }
               ]
             }
           },
           "resultFilter": {
             "children": "",
               "attribute": [
                  "transitAreaId"
               ]
             }
           }
           return this.getData(searchObject1, className1, "transitAreaId");
        }else {
        let searchObject2 = {
        "fullClassName": className2,
        "filter": {
            "and": {
                "equal": [
                    {
                        "name": "siteId",
                        "value": neId
                    },
                    {
                       "name": "instanceIndex",
                       "value": instanceId

                   },
                   {
                      "name": "version",
                      "value": "2"
                   }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": [
                "areaId"
            ]
          }
        };
        var finalResponse = this.getData(searchObject2, className2, "areaId");
        if (Array.isArray(finalResponse) && finalResponse.length > 0) {
        var AreaId = finalResponse.filter(function(item) {
            return item !== "0.0.0.0";
        });
        }else{
          return [];
        }
       }
       return AreaId;
    }

   this.getData = function (searchObjectJson, className, type) {
        let nfmpFwk = new NfmpFwk();
        let ret = [];
        let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        let finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    ret.push(value[type]);
                })
            }
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
   }

   this.getRouterId = function (neId, instanceId, actionType) {
      let className = "ospf.VirtualLink";
      let neIdXPath = `/nsp-equipment:network/network-element`;
      let nspRestConf = new NspRestconfFwk();
      let finalResponse = nspRestConf.findByXpath(neIdXPath, "3", "ne-id");
      if(actionType === "associate"){
      let searchObject = {
       "fullClassName": className,
         "filter": {
           "and": {
             "equal": [
                {
                   "name": "siteId",
                   "value": neId
                },
                {
                  "name":"version",
                  "value":"2"
                },
                {
                  "name":"instanceIndex",
                  "value":instanceId
                },
                {
                  "name":"areaId",
                  "value":"0.0.0.0"
                }
             ]
           }
         },
         "resultFilter": {
           "children": "",
             "attribute": [
                "virtualNeighborRouterId"
             ]
           }
         }
         return this.getData(searchObject, className, "virtualNeighborRouterId");
      }else if(finalResponse) {
        let data = finalResponse.map(element => element["ne-id"]).filter(id => id !== neId);
        return data;
    }
    return [];
  }
}
