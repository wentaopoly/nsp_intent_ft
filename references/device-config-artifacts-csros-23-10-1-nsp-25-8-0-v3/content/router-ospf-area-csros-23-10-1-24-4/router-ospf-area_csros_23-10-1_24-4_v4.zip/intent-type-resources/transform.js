function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        if(/instance-0/.test(objectFullName)) {
        objectFullName = objectFullName.replace("-instance-0", "");
        }
        objectFullName = objectFullName.replace("undefined", "v2");
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        if(/instance-0/.test(objectFullName)) {
        objectFullName = objectFullName.replace("-instance-0", "");
        }
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        fdn = fdn.replace("undefined", "v2");
        if(intentConfig["instanceIndex"] == 0) {
          fdn = fdn.split("-instance")[0];
        }
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        logger.info("PAYLOAD IS : " + JSON.stringify(payload));

        let intentConfig = payload["configInfo"]["ospf.AreaSite"];

        let ImportPolicies = [];
        let ExportPolicies = [];

        if(intentConfig["ospf.AreaImportPolicy"]) {
        if(intentConfig["ospf.AreaImportPolicy"]["policy1"]) {
          ImportPolicies.push(intentConfig["ospf.AreaImportPolicy"]["policy1"]);
        }
        else {
          ImportPolicies.push(null);
        }
        if(intentConfig["ospf.AreaImportPolicy"]["policy2"]) {
          ImportPolicies.push(intentConfig["ospf.AreaImportPolicy"]["policy2"]);
        }
        else {
          ImportPolicies.push(null);
        }
        if(intentConfig["ospf.AreaImportPolicy"]["policy3"]) {
          ImportPolicies.push(intentConfig["ospf.AreaImportPolicy"]["policy3"]);
        }
        else {
          ImportPolicies.push(null);
        }
        if(intentConfig["ospf.AreaImportPolicy"]["policy4"]) {
          ImportPolicies.push(intentConfig["ospf.AreaImportPolicy"]["policy4"]);
        }
        else {
          ImportPolicies.push(null);
        }
        if(intentConfig["ospf.AreaImportPolicy"]["policy5"]) {
          ImportPolicies.push(intentConfig["ospf.AreaImportPolicy"]["policy5"]);
        }
        else {
          ImportPolicies.push(null);
        }
        }
        logger.info("ImportPolicies " + JSON.stringify(ImportPolicies));

        if(intentConfig["ospf.AreaExportPolicy"]) {
        if(intentConfig["ospf.AreaExportPolicy"]["policy1"]) {
          ExportPolicies.push(intentConfig["ospf.AreaExportPolicy"]["policy1"]);
        }
        else {
          ExportPolicies.push(null);
        }
        if(intentConfig["ospf.AreaExportPolicy"]["policy2"]) {
          ExportPolicies.push(intentConfig["ospf.AreaExportPolicy"]["policy2"]);
        }
        else {
          ExportPolicies.push(null);
        }
        if(intentConfig["ospf.AreaExportPolicy"]["policy3"]) {
          ExportPolicies.push(intentConfig["ospf.AreaExportPolicy"]["policy3"]);
        }
        else {
          ExportPolicies.push(null);
        }
        if(intentConfig["ospf.AreaExportPolicy"]["policy4"]) {
          ExportPolicies.push(intentConfig["ospf.AreaExportPolicy"]["policy4"]);
        }
        else {
          ExportPolicies.push(null);
        }
        if(intentConfig["ospf.AreaExportPolicy"]["policy5"]) {
          ExportPolicies.push(intentConfig["ospf.AreaExportPolicy"]["policy5"]);
        }
        else {
          ExportPolicies.push(null);
        }
        }
        logger.info("ExportPolicies " + JSON.stringify(ExportPolicies));

         if(!(isValidList(ExportPolicies) && isValidList(ImportPolicies))) {
           logger.error("The import and export policies should be configured in the correct order [P1, P2, P3, P4, P5]");
           throw new RuntimeException("The import and export policies should be configured in the correct order [P1, P2, P3, P4, P5]");
         }


        return payload;
    }

    function isValidList(list) {
      // Check if the list has exactly 5 elements
      if (list.length !== 5) {
        //return false;
      }

      // Check if all non-null values come first and all nulls are at the end
      let foundNull = false;
      for (let i = 0; i < list.length; i++) {
        if (list[i] === null) {
          foundNull = true; // Once a null is found, all subsequent elements should be null
        } else if (foundNull) {
          return false; // If a non-null value is found after a null, return false
        }
      }

      return true; // The list satisfies the condition
    }

    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey) {
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
}
