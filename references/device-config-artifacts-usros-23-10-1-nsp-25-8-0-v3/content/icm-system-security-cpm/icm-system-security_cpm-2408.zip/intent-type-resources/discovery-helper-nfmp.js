var RuntimeException = Java.type('java.lang.RuntimeException');

load({
    script: resourceProvider.getResource("nfmp-fwk.js"),
    name: "NfmpFwk"
});
load({
    script: resourceProvider.getResource('parse-target.js'),
    name: 'ParseTarget'
});


function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();

    this.getDeviceConfiguration = function(target, initialPropertyName) {

        let neId = parseTarget.getNeIdFromTarget(target);
        let searchResponse = nfmpFwk.find(neId);
        logger.info(JSON.stringify(searchResponse));
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                throw new RuntimeException("Failed to get CPM filter info from nfm-p for Ne " + neId );
            if(JSON.parse(searchResponse["response"]).length === 0)
                throw new RuntimeException("There is no CPM filter on NE:" + neId );
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse[0];

    }

    this.extractDeviceConfig = function(defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);

        let cpmFilterconfig = deviceConfig['properties'];
        if (null !== cpmFilterconfig) {
            this.extractCPMFilterProperties(parsedDefaultTargetData, cpmFilterconfig);
            if(cpmFilterconfig["defaultAction"] == "forward")
            {
                parsedDefaultTargetData["cpm-filter"]["default-action"] = "accept";
            }
            else
            {
                parsedDefaultTargetData["cpm-filter"]["default-action"] = "drop";
            }
            parsedDefaultTargetData["default-action"]
        }
        let childrenConfig = deviceConfig["children"];
        if (undefined !== childrenConfig && null !== childrenConfig && childrenConfig.length !== 0) {

            let ipFilterData = parsedDefaultTargetData['cpm-filter']['ip-filter']['entry'];
            if (ipFilterData !== null && Array.isArray(ipFilterData) && ipFilterData.length !== 0)
            {
                let ipFilterArray = this.extractIPFilterData(ipFilterData, childrenConfig);
                parsedDefaultTargetData['cpm-filter']['ip-filter']['entry'] = ipFilterArray;
            }
            let ipv6FilterData = parsedDefaultTargetData['cpm-filter']['ipv6-filter']['entry'];
            if (ipv6FilterData !== null && Array.isArray(ipv6FilterData) && ipv6FilterData.length !== 0)
            {
                let ipv6Array = this.extractIPv6FilterData(ipv6FilterData, childrenConfig);
                parsedDefaultTargetData['cpm-filter']['ipv6-filter']['entry'] = ipv6Array;
            }
            let cpmQueueData = parsedDefaultTargetData['cpm-queue']['queue'];
            if (cpmQueueData !== null && Array.isArray(cpmQueueData) && cpmQueueData.length !== 0) {
                let cpmQueueArray = this.extractCPMQueueData(cpmQueueData, childrenConfig);
                parsedDefaultTargetData['cpm-queue']['queue'] = cpmQueueArray;
            }
        }
        else
        {
            parsedDefaultTargetData['cpm-filter']['ip-filter']['entry'] = undefined;
            parsedDefaultTargetData['cpm-filter']['ipv6-filter']['entry'] = undefined;
            parsedDefaultTargetData['cpm-queue']['queue'] = undefined;
        }

        //this.clearEmpties(parsedDefaultTargetData);
        return parsedDefaultTargetData;
    }

    this.extractIPFilterData = function(defaultIPFilterData, childrenConfig)
    {
        let ipFilterArray = [];
        let ipFilterDefaults = defaultIPFilterData[0];
        let mappings = modelDeviceMapping.getMapping("cpmIPfilter");
        for (let i = 0; i < childrenConfig.length; i++)
        {
            let childConfig = childrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass === 'sitesec.CpmIpFilterEntry')
            {
                let ipFilterData = JSON.parse(JSON.stringify(ipFilterDefaults));
                this.traverseAndUpdateConfig('cpm-filter.ip-filter.entry', ipFilterData, childConfig['properties'], mappings);
                ipFilterData['action'] = new Object();
                if(childConfig['properties']['action'] == "forward")
                {
                    ipFilterData['action']['accept'] = [null];
                }
                else if(childConfig['properties']['action'] == "default")
                {
                    ipFilterData['action']['default'] = [null]
                }
                else if(childConfig['properties']['action'] == "queue")
                {
                    ipFilterData['action']['queue'] = childConfig['properties']['queueId'];
                }
                else
                {
                    ipFilterData['action']['drop'] = [null];
                }
                ipFilterData["match"]['protocol'] = this.transformProtocol(childConfig['properties']['protocol']);
                if(childConfig['properties']['fragment'] == "off")
                {
                    ipFilterData["match"]['fragment'] = undefined;
                }
                else
                {
                    ipFilterData["match"]['fragment'] = childConfig['properties']['fragment'];
                }
                ipFilterData["match"]['icmp'] = new Object();
                if(childConfig['properties']['icmpCode'] && childConfig['properties']['icmpCode'] != -1)
                {
                    ipFilterData["match"]['icmp']["code"] = childConfig['properties']['icmpCode'];
                }
                else
                {
                    ipFilterData["match"]['icmp']["code"] = undefined;
                }

                if(childConfig['properties']['icmpType'] && childConfig['properties']['icmpType'] != -1)
                {
                    ipFilterData["match"]['icmp']["type"] = childConfig['properties']['icmpType'];
                }
                else
                {
                    ipFilterData["match"]['icmp']["type"] = undefined;
                }

                ipFilterData['match']['ip-option'] = new Object();
                ipFilterData['match']['ip-option']['mask'] = childConfig['properties']['ipOptionMask'];
                ipFilterData['match']['ip-option']['type'] = this.transformIPMaskValue(childConfig['properties']['ipOptionValue']);
                ipFilterData['match']['src-ip'] = new Object();
                let filterPrefixList = childConfig['properties']['srcIpPrefixListPointer'];
                if(filterPrefixList !== "")
                {
                    ipFilterData['match']['src-ip']['ip-prefix-list'] = filterPrefixList.replace("filterPrefixList:", "");
                }
                else
                {
                    ipFilterData['match']['src-ip']['address'] = childConfig['properties']['sourceIpAddress'];
                    if(childConfig['properties']['sourceIpAddressMask'])
                    {
                        ipFilterData['match']['src-ip']['address'] = childConfig['properties']['sourceIpAddress'] + "/" + childConfig['properties']['sourceIpAddressMask'].replace("ipAddrMask", "");
                    }
                }

                ipFilterData['match']['dst-ip'] = new Object();
                filterPrefixList = childConfig['properties']['dstIpPrefixListPointer'];
                if(filterPrefixList !== "")
                {
                    ipFilterData['match']['dst-ip']['ip-prefix-list'] = filterPrefixList.replace("filterPrefixList:", "");
                }
                else
                {
                    ipFilterData['match']['dst-ip']['address'] = childConfig['properties']['destinationIpAddress'];
                    if(childConfig['properties']['destinationIpAddressMask'])
                    {
                        ipFilterData['match']['dst-ip']['address'] = childConfig['properties']['destinationIpAddress'] + "/" + childConfig['properties']['destinationIpAddressMask'].replace("ipAddrMask", "");
                    }
                }

                if((ipFilterData['match']['protocol'] == "tcp" || ipFilterData['match']['protocol'] == "udp" || ipFilterData['match']['protocol'] == "tcp-udp")
                    && childConfig['properties']['portSelector'])
                {
                    if(childConfig['properties']['portSelector'] == "AND_PORT")
                    {
                        ipFilterData['match']['src-port'] = new Object();
                        if(childConfig['properties']['sourcePortListPointer'])
                        {
                            ipFilterData["match"]["src-port"]["port"] = "port-list"
                            ipFilterData['match']['src-port']['port-list'] = childConfig['properties']['sourcePortListPointer'].replace("filterPortList:", "")
                        }
                        else if(childConfig['properties']['sourcePortOperator'] == "mask")
                        {
                            ipFilterData["match"]["src-port"]["port"] = "eq"
                            ipFilterData['match']['src-port']["eq"] = childConfig['properties']['sourcePort'];
                            ipFilterData['match']['src-port']["mask"] = childConfig['properties']['sourcePortMask'];
                        }
                        else if(childConfig['properties']['sourcePortOperator'] == "range")
                        {
                            ipFilterData["match"]["src-port"]["port"] = "range"
                            ipFilterData['match']['src-port']["range"] = new Object();
                            ipFilterData['match']['src-port']["range"]["start"] = childConfig['properties']['sourcePort'];
                            ipFilterData['match']['src-port']["range"]["end"] = childConfig['properties']['sourcePortHigh'];
                        }

                        ipFilterData['match']['dst-port'] = new Object();

                        if(childConfig['properties']['destinationPortListPointer'])
                        {
                            ipFilterData["match"]["dst-port"]["port"] = "port-list"
                            ipFilterData['match']['dst-port']['port-list'] = childConfig['properties']['destinationPortListPointer'].replace("filterPortList:", "")
                        }
                        else if(childConfig['properties']['destinationPortOperator'] == "mask")
                        {
                            ipFilterData["match"]["dst-port"]["port"] = "eq"
                            ipFilterData['match']['dst-port']["eq"] = childConfig['properties']['destinationPort'];
                            ipFilterData['match']['dst-port']["mask"] = childConfig['properties']['destinationPortMask'];
                        }
                        else if(childConfig['properties']['destinationPortOperator'] == "range")
                        {
                            ipFilterData["match"]["dst-port"]["port"] = "range"
                            ipFilterData['match']['dst-port']["range"] = new Object();
                            ipFilterData['match']['dst-port']["range"]["start"] = childConfig['properties']['destinationPort'];
                            ipFilterData['match']['dst-port']["range"]["end"] = childConfig['properties']['destinationPortHigh'];
                        }
                        ipFilterData['match']['port'] = undefined;
                    }
                    else if(childConfig['properties']['portSelector'] == "OR_PORT")
                    {
                        ipFilterData['match']['port'] = new Object();
                        if(childConfig['properties']['portListPointer'])
                        {
                            ipFilterData["match"]["port"]["port"] = "port-list"
                            ipFilterData['match']['port']['port-list'] = childConfig['properties']['portListPointer'].replace("filterPortList:", "")
                        }
                        else if(childConfig['properties']['portOperator'] == "mask")
                        {
                            ipFilterData["match"]["port"]["port"] = "eq"
                            ipFilterData['match']['port']["eq"] = childConfig['properties']['port'];
                            ipFilterData['match']['port']["mask"] = childConfig['properties']['portMask'];
                        }
                        else if(childConfig['properties']['portOperator'] == "range")
                        {
                            ipFilterData["match"]["port"]["port"] = "range"
                            ipFilterData['match']['port']["range"] = new Object();
                            ipFilterData['match']['port']["range"]["start"] = childConfig['properties']['port'];
                            ipFilterData['match']['port']["range"]["end"] = childConfig['properties']['portHigh'];
                        }
                        ipFilterData["match"]["src-port"] = undefined;
                        ipFilterData["match"]["dst-port"] = undefined;
                    }
                    else
                    {
                        ipFilterData['match']['src-port'] = undefined;
                        ipFilterData['match']['dst-port'] = undefined;
                        ipFilterData['match']['port'] = undefined;
                    }
                }
                else
                {
                    ipFilterData['match']['src-port'] = undefined;
                    ipFilterData['match']['dst-port'] = undefined;
                    ipFilterData['match']['port'] = undefined;
                }

                ipFilterArray.push(ipFilterData);
            }
        }
        return ipFilterArray;

    }

    this.extractIPv6FilterData = function(defaultipv6FilterData, childrenConfig)
    {
        let ipv6FilterArray = [];
        let ipv6FilterDefaults = defaultipv6FilterData[0];
        for (let i = 0; i < childrenConfig.length; i++)
        {
            let childConfig = childrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass === 'sitesec.CpmIPv6FilterEntry')
            {
                let ipv6FilterData = JSON.parse(JSON.stringify(ipv6FilterDefaults));
                ipv6FilterData['entry-id'] = childConfig['properties']['id'];
                ipv6FilterData['description'] = childConfig['properties']['description'];
                ipv6FilterData['action'] = new Object();
                if(childConfig['properties']['action'] == "forward")
                {
                    ipv6FilterData['action']['accept'] = [null];
                }
                else if(childConfig['properties']['action'] == "default")
                {
                    ipv6FilterData['action']['default'] = [null];
                }
                else if(childConfig['properties']['action'] == "queue")
                {
                    ipv6FilterData['action']['queue'] = childConfig['properties']['queueId'];
                }
                else
                {
                    ipv6FilterData['action']['drop'] = [null];
                }
                ipv6FilterData['match'] = new Object();
                ipv6FilterData["match"]['next-header'] = this.transformProtocol(childConfig['properties']['protocol']);
                if(childConfig['properties']['fragment'] == "off")
                {
                    ipv6FilterData["match"]['fragment'] = undefined;
                }
                else
                {
                    ipv6FilterData["match"]['fragment'] = childConfig['properties']['fragment'];
                }
                ipv6FilterData["match"]['icmp'] = new Object();
                if(childConfig['properties']['icmpCode'] && childConfig['properties']['icmpCode'] != -1)
                {
                    ipv6FilterData["match"]['icmp']["code"] = childConfig['properties']['icmpCode'];
                }
                else
                {
                    ipv6FilterData["match"]['icmp']["code"] = undefined;
                }

                if(childConfig['properties']['icmpType'] && childConfig['properties']['icmpType'] != -1)
                {
                    ipv6FilterData["match"]['icmp']["type"] = childConfig['properties']['icmpType'];
                }
                else
                {
                    ipv6FilterData["match"]['icmp']["type"] = undefined;
                }

                ipv6FilterData['match']['src-ip'] = new Object();
                let filterPrefixList = childConfig['properties']['srcIpPrefixListPointer'];
                if(filterPrefixList !== "")
                {
                    ipv6FilterData['match']['src-ip']['ipv6-prefix-list'] = filterPrefixList.replace("filterPrefixList:", "").replace("#type-IPv6", "");
                }
                else
                {
                    ipv6FilterData['match']['src-ip']['address'] = childConfig['properties']['sourceIpAddress'];
                    if(childConfig['properties']['sourceIpAddressMask'])
                    {
                        ipv6FilterData['match']['src-ip']['address'] = childConfig['properties']['sourceIpAddress'] +"/"+ childConfig['properties']['sourceIpAddressMask'];
                    }
                }

                ipv6FilterData['match']['dst-ip'] = new Object();
                filterPrefixList = childConfig['properties']['dstIpPrefixListPointer'];
                if(filterPrefixList !== "")
                {
                    ipv6FilterData['match']['dst-ip']['ipv6-prefix-list'] = filterPrefixList.replace("filterPrefixList:", "").replace("#type-IPv6", "");
                }
                else
                {
                    ipv6FilterData['match']['dst-ip']['address'] = childConfig['properties']['destinationIpAddress'];
                    if(childConfig['properties']['destinationIpAddressMask'])
                    {
                        ipv6FilterData['match']['dst-ip']['address'] = childConfig['properties']['destinationIpAddress']+"/"+childConfig['properties']['destinationIpAddressMask'];
                    }
                }

                if((ipv6FilterData['match']['next-header'] == "tcp" || ipv6FilterData['match']['next-header'] == "udp" || ipv6FilterData['match']['next-header'] == "tcp-udp")
                    && childConfig['properties']['portSelector'])
                {
                    if(childConfig['properties']['portSelector'] == "AND_PORT")
                    {
                        ipv6FilterData['match']['src-port'] = new Object();
                        if(childConfig['properties']['sourcePortListPointer'])
                        {
                            ipv6FilterData["match"]["src-port"]["port"] = "port-list"
                            ipv6FilterData['match']['src-port']['port-list'] = childConfig['properties']['sourcePortListPointer'].replace("filterPortList:", "")
                        }
                        else if(childConfig['properties']['sourcePortOperator'] == "mask")
                        {
                            ipv6FilterData["match"]["src-port"]["port"] = "eq"
                            ipv6FilterData['match']['src-port']["eq"] = childConfig['properties']['sourcePort'];
                            ipv6FilterData['match']['src-port']["mask"] = childConfig['properties']['sourcePortMask'];
                        }
                        else if(childConfig['properties']['sourcePortOperator'] == "range")
                        {
                            ipv6FilterData["match"]["src-port"]["port"] = "range"
                            ipv6FilterData['match']['src-port']["range"] = new Object();
                            ipv6FilterData['match']['src-port']["range"]["start"] = childConfig['properties']['sourcePort'];
                            ipv6FilterData['match']['src-port']["range"]["end"] = childConfig['properties']['sourcePortHigh'];
                        }

                        ipv6FilterData['match']['dst-port'] = new Object();

                        if(childConfig['properties']['destinationPortListPointer'])
                        {
                            ipv6FilterData["match"]["dst-port"]["port"] = "port-list"
                            ipv6FilterData['match']['dst-port']['port-list'] = childConfig['properties']['destinationPortListPointer'].replace("filterPortList:", "")
                        }
                        else if(childConfig['properties']['destinationPortOperator'] == "mask")
                        {
                            ipv6FilterData["match"]["dst-port"]["port"] = "eq"
                            ipv6FilterData['match']['dst-port']["eq"] = childConfig['properties']['destinationPort'];
                            ipv6FilterData['match']['dst-port']["mask"] = childConfig['properties']['destinationPortMask'];
                        }
                        else if(childConfig['properties']['destinationPortOperator'] == "range")
                        {
                            ipv6FilterData["match"]["dst-port"]["port"] = "range"
                            ipv6FilterData['match']['dst-port']["range"] = new Object();
                            ipv6FilterData['match']['dst-port']["range"]["start"] = childConfig['properties']['destinationPort'];
                            ipv6FilterData['match']['dst-port']["range"]["end"] = childConfig['properties']['destinationPortHigh'];
                        }
                        ipv6FilterData['match']['port'] = undefined;
                    }
                    else if(childConfig['properties']['portSelector'] == "OR_PORT")
                    {
                        ipv6FilterData['match']['port'] = new Object();
                        if(childConfig['properties']['portListPointer'])
                        {
                            ipv6FilterData["match"]["port"]["port"] = "port-list"
                            ipv6FilterData['match']['port']['port-list'] = childConfig['properties']['portListPointer'].replace("filterPortList:", "")
                        }
                        else if(childConfig['properties']['portOperator'] == "mask")
                        {
                            ipv6FilterData["match"]["port"]["port"] = "eq"
                            ipv6FilterData['match']['port']["eq"] = childConfig['properties']['port'];
                            ipv6FilterData['match']['port']["mask"] = childConfig['properties']['portMask'];
                        }
                        else if(childConfig['properties']['portOperator'] == "range")
                        {
                            ipv6FilterData["match"]["port"]["port"] = "range"
                            ipv6FilterData['match']['port']["range"] = new Object();
                            ipv6FilterData['match']['port']["range"]["start"] = childConfig['properties']['port'];
                            ipv6FilterData['match']['port']["range"]["end"] = childConfig['properties']['portHigh'];
                        }

                        ipv6FilterData["match"]["src-port"] = undefined;
                        ipv6FilterData["match"]["dst-port"] = undefined;
                    }
                    else
                    {
                        ipv6FilterData['match']['src-port'] = undefined;
                        ipv6FilterData['match']['dst-port'] = undefined;
                        ipv6FilterData['match']['port'] = undefined;
                    }
                }
                else
                {
                    ipv6FilterData['match']['src-port'] = undefined;
                    ipv6FilterData['match']['dst-port'] = undefined;
                    ipv6FilterData['match']['port'] = undefined;
                }
                ipv6FilterArray.push(ipv6FilterData);
            }
        }
        return ipv6FilterArray;
    }

    this.extractCPMQueueData = function(defaultCPMQueueData, childrenConfig)
    {
        let cpmQueueArray = [];
        let cpmQueueDefaults = defaultCPMQueueData[0];
        let mappings = modelDeviceMapping.getMapping("cpmQueue");
        for (let i = 0; i < childrenConfig.length; i++)
        {
            let childConfig = childrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass === 'sitesec.CpmFilterQueue')
            {
                let cpmQueueData = JSON.parse(JSON.stringify(cpmQueueDefaults));
                this.traverseAndUpdateConfig('cpm-queue.queue', cpmQueueData, childConfig['properties'], mappings);
                cpmQueueArray.push(cpmQueueData);
            }
        }
        return cpmQueueArray;
    }

    this.extractCPMFilterProperties = function(defaultTargetData, cpmFilterconfig)
    {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++) {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object') {
                let mappings = modelDeviceMapping.getMapping("cpmfilter");
                this.traverseAndUpdateConfig(targetKey, targetObj, cpmFilterconfig, mappings);
            }
        }
    }

    this.traverseAndUpdateConfig = function(objKey, obj, parsedDeviceConfig, mappings)
    {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];

            let mappedKey = objKey + "." + key;
            if (mappedKey !== "cpm-queue.queue" && mappedKey !== "cpm-filter.ip-filter.entry")
            {
                if (value != null && typeof value === 'object')
                {
                    this.traverseAndUpdateConfig(mappedKey, value, parsedDeviceConfig, mappings);
                }
                else
                {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }


    this.getAndUpdateFromDeviceConfig = function(mappings, mappedKey, targetKey, targetObj, parsedDeviceConfig) {
        // Get the key from mapping against targetKey
        // If the mapping key is not undefined, Get the value from deviceKey
        // if the value from deviceConfig against that mapping key is not n
        let nfmpKey = mappings[mappedKey];
        let deviceValue = parsedDeviceConfig[nfmpKey];

        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue, parsedDeviceConfig);

    }

    this.transformDeviceValue = function(mappedKey, deviceValue, parsedDeviceConfig) {
        if (deviceValue !== null) {
            switch (mappedKey)
            {
                case "cpm-filter.ip-filter.admin-state":
                case "cpm-filter.ipv6-filter.admin-state":
                    deviceValue = this.transformAdminState(deviceValue);
                    break;
                case "cpm-filter.ip-filter.match.protocol":
                case "cpm-filter.ipv6-filter.match.next-header":
                    deviceValue = this.transformProtocol(deviceValue);
                    break;
                case "cpm-queue.queue.cbs":
                case "cpm-queue.queue.mbs":
                    deviceValue = this.transformCBSorMBS(deviceValue);
                    break;
                case "cpm-queue.queue.rate.cir":
                case "cpm-queue.queue.rate.pir":
                    deviceValue = this.transformCIRorPIR(deviceValue);
                    break;
                default:
            }
            return deviceValue;
        }
    }

    this.transformAdminState = function (deviceValue)
    {
        if(deviceValue === "tmnxInService")
        {
            return "enable"
        }
        return "disable";
    }

    this.transformCIRorPIR = function (deviceValue)
    {
        if(deviceValue === "-1")
        {
            return "max"
        }
        return deviceValue;
    }

    this.transformCBSorMBS = function (deviceValue)
    {
        if(deviceValue === "-1")
        {
            return undefined;
        }
        return deviceValue;
    }

    this.transformIPMaskValue = function (deviceValue)
    {
        if(deviceValue == "EOOL")
        {
            return "0";
        }
        else if(deviceValue == "NOP")
        {
            return "1";
        }
        else if(deviceValue == "RR")
        {
            return "7";
        }
        else if(deviceValue == "ZSU")
        {
            return "10";
        }
        else if(deviceValue == "MTUP")
        {
            return "11";
        }
        else if(deviceValue == "MTUR")
        {
            return "12";
        }
        else if(deviceValue == "ENCODE")
        {
            return "15";
        }
        else if(deviceValue == "TS")
        {
            return "68";
        }
        else if(deviceValue == "TR")
        {
            return "82";
        }
        else if(deviceValue == "SEC")
        {
            return "130";
        }
        else if(deviceValue == "LSR")
        {
            return "131";
        }
        else if(deviceValue == "E_SEC")
        {
            return "133";
        }
        else if(deviceValue == "CIPSO")
        {
            return "134";
        }
        else if(deviceValue == "SID")
        {
            return "136";
        }
        else if(deviceValue == "SSR")
        {
            return "137";
        }
        else if(deviceValue == "VISA")
        {
            return "142";
        }
        else if(deviceValue == "IMITD")
        {
            return "144";
        }
        else if(deviceValue == "EIP")
        {
            return "145";
        }
        else if(deviceValue == "ADDEXT")
        {
            return "147";
        }
        else if(deviceValue == "RTRALT")
        {
            return "148";
        }
        else if(deviceValue == "SDB")
        {
            return "149";
        }
        else if(deviceValue == "NSAPA")
        {
            return "150";
        }
        else if(deviceValue == "DPS")
        {
            return "151";
        }
        else if(deviceValue == "UMP")
        {
            return "152";
        }
        else if(deviceValue == "FINN")
        {
            return "205";
        }
        else
        {
            deviceValue = deviceValue.replace("undefined00", "").replace("undefined0", "").replace("undefined", "");
        }
        return deviceValue;
    }

    this.transformProtocol = function (protocol)
    {
        if(protocol == "UDPTCP")
        {
            return "tcp-udp";
        }
        else if(protocol == "ICMP")
        {
            return "icmp";
        }
        else if(protocol == "IGMP")
        {
            return "igmp";
        }
        else if(protocol == "IP")
        {
            return "ip";
        }
        else if(protocol == "TCP")
        {
            return "tcp";
        }
        else if(protocol == "EGP")
        {
            return "egp";
        }
        else if(protocol == "IGP")
        {
            return "igp";
        }
        else if(protocol == "UDP")
        {
            return "udp";
        }
        else if(protocol == "RDP")
        {
            return "rdp";
        }
        else if(protocol == "IPv6")
        {
            return "ipv6";
        }
        else if(protocol == "IPv6Route")
        {
            return "ipv6-route";
        }
        else if(protocol == "IPv6Frag")
        {
            return "ipv6-frag";
        }
        else if(protocol == "IDRP")
        {
            return "idrp";
        }
        else if(protocol == "RSVP")
        {
            return "rsvp";
        }
        else if(protocol == "GRE")
        {
            return "gre";
        }
        else if(protocol == "IPv6_ICMP")
        {
            return "ipv6-icmp";
        }
        else if(protocol == "IPv6_NoNxt")
        {
            return "ipv6-no-nxt";
        }
        else if(protocol == "IPv6_Opts")
        {
            return "ipv6-opts";
        }
        else if(protocol == "ISO_IP")
        {
            return "iso-ip";
        }
        else if(protocol == "EIGRP")
        {
            return "eigrp";
        }
        else if(protocol == "OSPFIGP")
        {
            return "ospf-igp";
        }
        else if(protocol == "ETHERIP")
        {
            return "ether-ip";
        }
        else if(protocol == "ENCAP")
        {
            return "encap";
        }
        else if(protocol == "PNNI")
        {
            return "pnni";
        }
        else if(protocol == "PIM")
        {
            return "pim";
        }
        else if(protocol == "VRRP")
        {
            return "vrrp";
        }
        else if(protocol == "L2TP")
        {
            return "l2tp";
        }
        else if(protocol == "STP")
        {
            return "stp";
        }
        else if(protocol == "PTP")
        {
            return "ptp";
        }
        else if(protocol == "ISIS")
        {
            return "isis";
        }
        else if(protocol == "CRTP")
        {
            return "crtp";
        }
        else if(protocol == "CRUDP")
        {
            return "crudp";
        }
        else if(protocol == "SCTP")
        {
            return "sctp";
        }
        else
        {
            return undefined;
        }
    }

    this.constructSearchString = function(neId) {
        let filterExpression = "siteId='" + neId + "'";
        let jsonPayLoad = {
            "fullClassName": "sitesec.CpmIpFilter",
            "filter": {
                "filterExpression": filterExpression
            }
        };
        return jsonPayLoad;
    }

    this.clearEmpties = function (o)
    {
        for (let k in o)
        {
            if (!o[k] || typeof o[k] !== "object")
            {
                continue
            }

            this.clearEmpties(o[k]);
            if (Object.keys(o[k]).length === 0)
            {
                delete o[k];
            }
        }
    }
}
