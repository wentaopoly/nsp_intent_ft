var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk'});
load({script: resourceProvider.getResource('traverse-fwk.js'), name: 'TraverseFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
load({script: resourceProvider.getResource('intentConfigValueReplacer.js'), name: 'IntentConfigValueReplacer'});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities" });

function MdcIntentFwk() {
    var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,5}(:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){6}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(\/(0|[1-9][0-9]?|1[0-1][0-9]?|12[0-8]))?$/;
    var util = new utilities();
  //var intentDeviationObj = new IntentDeviceDeviation();
  var intentConfigValueReplacerObj = new IntentConfigValueReplacer();

  this.restResponseHandler = function (exception, httpStatus, response) {
    logger.info("[IntentMgr] REST response : " + response);
    logger.info("[IntentMgr] REST httpStatus : " + httpStatus);
    if (exception) {
      throw new RuntimeException("Couldn't connect to device proxy for ; Response: " + response);
    }
    if (httpStatus !== 200 && httpStatus !== 201) {
      throw new RuntimeException("Failed to access device  using MDC; Response: " + response);
    }
    restResponse = JSON.parse(response);
  };

  this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, bgpTopologyObj) {

    var traverseFwk = new TraverseFwk();
    var parseTarget = new ParseTarget();
    var target = parseTarget.getNeIdFromTarget(input.getTarget());
    var groupName = parseTarget.getUniqueIdentifier(input.getTarget());


    // saved topology
    var savedTopology = input.getCurrentTopology();

    if (savedTopology == null) {
      savedTopology = topologyFactory.createServiceTopology();
    }

    if (input.getNetworkState().name() == "delete") {
      logger.info(JSON.stringify(savedTopology));
      traverseFwk.resetTheVariables();
      var requests = [];

      var delintentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName]['neighbor'];
      var noOfNeighbors = 0;
      if(delintentConfig != undefined)
      {
        if(!Array.isArray(delintentConfig))
        {
          delintentConfig = [delintentConfig];
        }
        noOfNeighbors = delintentConfig.length;
        for (var i = 0; i < delintentConfig.length; i++)
        {
          var obj = delintentConfig[i];
          var url = "nokia-conf:/configure/router=Base/bgp/neighbor=" + obj['ip-address'];
          var deleteBGPNeighborObj = {};
          deleteBGPNeighborObj["operation"] = "delete";
          deleteBGPNeighborObj["edit-id"] = "edit-" + (new Date().getTime() + i );
          deleteBGPNeighborObj["target"] = url;
          requests.push(deleteBGPNeighborObj);
        }
      }

      if (requests.length > 0) {
        result = traverseFwk.syncRequest(target, requests, result, bgpTopologyObj.getSavedTopologyBGPNeighbour());
      }

      requests = [];
      var deleteBGPGroupObj = {};
      deleteBGPGroupObj["operation"] = "delete";
      deleteBGPGroupObj["edit-id"] = "edit-" + (new Date().getTime() + noOfNeighbors);
      deleteBGPGroupObj["target"] = "nokia-conf:/" + parentXpath + "/" + 'group='+groupName;
      requests.push(deleteBGPGroupObj)
      if (requests.length > 0) {
        result = traverseFwk.syncRequest(target, requests, result, bgpTopologyObj.getSavedTopologyBGPGroup());
      }

      result.setTopology(null);
      return result;
    }

    var bgpObjs = ['group', 'neighbor'];
    for (var i = 0; i < bgpObjs.length; i++) {
      var bgpObj = bgpObjs[i];
      if (bgpObj === 'group') {
        if (target !== "0.0.0.0") {
          var intentConfig;
          intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][bgpObj];

          //Replace Values
          intentConfig = intentConfigValueReplacerObj.replaceConfigValue(intentConfig);

          if (intentConfig != undefined && intentConfig !== "") {
            intentConfig[uniqueIdentifier] = groupName;

            var savedTopology = bgpTopologyObj.getSavedTopologyBGPGroup();
            savedTopology = traverseFwk.traverse(target, intentConfig, savedTopology, null, parentXpath, bgpObj);
            bgpTopologyObj.setSavedTopologyBGPGroup(savedTopology);

            //sorting delete array
            var deleteRequests = traverseFwk.getDeleteRequests();
            deleteRequests.sort(function (a, b) {
              return b["target"].length - a["target"].length;
            });

            // concating createrequests and deleterequests
            var createRequests = traverseFwk.getCreateRequests();
            var requests;
            if (deleteRequests && createRequests) {
              requests = createRequests.concat(deleteRequests);
            }
            if (requests) {
              result = traverseFwk.syncRequest(target, requests, result, savedTopology);
            }

            if (!result['success']) {
              traverseFwk.resetTheVariables();
              return result;
            }

          }
        }
      }

      if (bgpObj === 'neighbor') {
        if (target !== "0.0.0.0") {
          var intentConfig = [];
          intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][bgpObj];
          //intentConfig = intentDeviationObj.removeIntentConfig(intentConfig, target);
          //Replace Values
          if(!Array.isArray(intentConfig))
          {
             intentConfig = [intentConfig];
          }
          for (var index in intentConfig)
          {
            if(intentConfig[index])
            {
              intentConfig[index]["group"] = groupName;
            }
          }
          intentConfig = intentConfigValueReplacerObj.replaceConfigValue(intentConfig);
          var savedTopology = bgpTopologyObj.getSavedTopologyBGPNeighbour();
          savedTopology = traverseFwk.traverse(target, intentConfig, savedTopology, null, parentXpath, bgpObj);
          bgpTopologyObj.setSavedTopologyBGPNeighbour(savedTopology);

          //sorting delete array
          var deleteRequests = traverseFwk.getDeleteRequests();
          deleteRequests.sort(function (a, b) {
            return b["target"].length - a["target"].length;
          });

          // concating createrequests and deleterequests
          var createRequests = traverseFwk.getCreateRequests();
          var requests;
          if (deleteRequests && createRequests) {
            requests = createRequests.concat(deleteRequests);
          }
          if (requests) {
            result = traverseFwk.syncRequest(target, requests, result, savedTopology);
          }
          traverseFwk.resetTheVariables();
        }
      }
    }

    return result;
  }

  this.audit = function (target, config, svcTopo, adminState, report, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, bgpTopologyObj) {
    var parseTarget = new ParseTarget();
    var bgpObjs = ['group', 'neighbor'];
    for (var i = 0; i < bgpObjs.length; i++) {
      var bgpObj = bgpObjs[i];
      var currentConfig;
      var traverseFwk = new TraverseFwk();

      currentConfig = this.xml2object(config)['configuration'][intentTypeName][bgpObj];
      currentConfig = this.expandIPv6(currentConfig);
      //Replace Values
      var targetNeId = parseTarget.getNeIdFromTarget(target);
      var groupName = parseTarget.getUniqueIdentifier(target);
      if (targetNeId !== "0.0.0.0") {

        if(currentConfig)
        {
          currentConfig = intentConfigValueReplacerObj.replaceConfigValue(currentConfig);
        }
        else
        {
          continue;
        }
        if (bgpObj === 'group') {
          currentConfig['group-name'] = groupName;
          delete currentConfig['authentication-key'];
          //currentConfig = intentDeviationObj.removeIntentConfig(currentConfig, targetNeId);
          svcTopo = bgpTopologyObj.getSavedTopologyBGPGroup();
        }

        if (bgpObj === 'neighbor') {
          if(currentConfig)
          {
            if(!Array.isArray(currentConfig))
            {
              currentConfig = [currentConfig];
            }
            for(var index in currentConfig)
            {
              currentConfig[index]["group"] = groupName;
              delete currentConfig[index]["authentication-key"];
            }
          }
          svcTopo = bgpTopologyObj.getSavedTopologyBGPNeighbour();
        }

        svcTopo = traverseFwk.traverse(targetNeId, currentConfig, svcTopo, report, parentXpath, bgpObj);
        // reseting the variables
        traverseFwk.resetTheVariables();
      }
    }

    return report;

  }

  this.xml2object = function (xmlElement) {
    var lXml = Java.type("org.json.XML");
    var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
    var serializer = lsImpl.createLSSerializer();
    serializer.getDomConfig().setParameter("xml-declaration", false);
    var str = serializer.writeToString(xmlElement);
    var json = lXml.toJSONObject(str).toString();
    logger.info('inp json: ' + json)
    return JSON.parse(json);
  }

    this.expandIPv6 = function (obj) {
        for (var key in obj) {
            if (typeof obj[key] === 'object' && obj[key] !== null) {
                this.expandIPv6(obj[key]);
            } else if (typeof obj[key] === 'string' && this.matchExact(ipv6Regex, obj[key])) {
                obj[key] = this.expandIPv6AddressForMd(obj[key]);
            }
        }
      return obj
    }

    this.matchExact = function(r, str) {
        var match = str.match(r);
        return match && str === match[0];
    }

    this.expandIPv6AddressForMd = function (input) {
        var expanded = util.expandIPv6ForMd(input);
        expanded = util.MdIpv6ValidAddresssMaskSupport(expanded);
        return expanded;
    };
}
