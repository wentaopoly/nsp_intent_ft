load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
load({script: resourceProvider.getResource("parse-target.js"), name: "ParseTarget"});
load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});

function CustomHooks() {
  var ipv6AddressUtil = new IPv6AddressUtil();
  var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,5}(:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){6}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(\/(0|[1-9][0-9]?|1[0-1][0-9]?|12[0-8]))?$/;

  /**
   * PreAudit Hook
   */
  const preAudit = (inputObj) => {
     /**
     * Write your custom preAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName
     *
     */

    logger.info("[CUSTOM-HOOKS] preAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj " + JSON.stringify(inputObj));
    var target = inputObj["target"];
    var intentConfig = inputObj["intentConfig"];
    var intentDeviationObj = new IntentDeviceDeviation();
    var neId = parseTarget.getNeIdFromTarget(target);
    intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
    intentConfig = this.expandIPv6(intentConfig);
     if (intentConfig["ethernet-segment"])
    {
        //convert esi. ipv6 to lowercase
      for (let i = 0; i < intentConfig["ethernet-segment"].length; i++) {
        let segment = intentConfig["ethernet-segment"][i];
        if (segment && segment["esi"]) {
          // Check if esi matches the format with colons
          const esiRegex = /^([0-9A-Fa-f]{2}:){9}[0-9A-Fa-f]{2}$/;
          if (esiRegex.test(segment["esi"])) {
            // Convert esi to the desired format
            segment["esi"] = "0x" + segment["esi"].replace(/:/g, "").toLowerCase();
          }
        }
        if(segment["pbb"] && segment["pbb"]["source-bmac-lsb"]){
           let sourceBmacLsb = segment["pbb"]["source-bmac-lsb"];
           let nameExtension = "0x";
           if (!sourceBmacLsb.startsWith(nameExtension)) {
               sourceBmacLsb = "0x" + sourceBmacLsb.replace(/:/g, "").toLowerCase();
           } else {
               sourceBmacLsb = sourceBmacLsb.toLowerCase();
           }
            segment["pbb"]["source-bmac-lsb"] = sourceBmacLsb;
         }
        ["port", "lag", "pw-port"].forEach((key) => {
          if (segment["association"] && segment["association"][key]) {
            segment["association"][key] = supportAllAssociateList(segment["association"][key]);
          }
        });
        intentConfig["ethernet-segment"][i] = segment;
      }
    }
    intentConfig = intentDeviationObj.removeIntentConfig(intentConfig, neId);
    return intentConfig;
  };

  /**
   * PostAudit Hook
   */
  const postAudit = (inputObj) => {
    /**
     * Write your custom postAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName, auditReport
     *
     */

    logger.info("[CUSTOM-HOOKS] postAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj " + JSON.stringify(inputObj));
  };

  /**
   * PreSync Hook
   */
  const preSync = (inputObj) => {
    /**
     * Write your custom preSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] preSync call");
    logger.info("[CUSTOM-HOOKS] inputObj " + JSON.stringify(inputObj));
    var target = inputObj["target"];
    let config = JSON.parse(inputObj.config);
    config = this.removeEmptyContainers("", config, "", target);
    var intentTypeName = inputObj["intentTypeName"];
    var intentContainer = inputObj["intentContainer"];
    logger.info("preSync call for bgp evpn intent deviation implementation");
    var intentDeviationObj = new IntentDeviceDeviation();
    var neId = parseTarget.getNeIdFromTarget(target);
    if (!Array.isArray(config)) {
      config = [config];
    }
    let preSyncConf = [];
    for (var index in config) {
      var confObj = config[index][intentTypeName + ":" + intentTypeName][intentContainer];
      confObj = this.expandIPv6(confObj);
        if (confObj["ethernet-segment"])
        {
        //convert esi. ipv6 to lowercase
        for (let i = 0; i < confObj["ethernet-segment"].length; i++) {
          let segment = confObj["ethernet-segment"][i];
          if (segment && segment["esi"]) {
            // Check if esi matches the format with colons
            const esiRegex = /^([0-9A-Fa-f]{2}:){9}[0-9A-Fa-f]{2}$/;
            if (esiRegex.test(segment["esi"])) {
                        // Convert esi to the desired format
              segment["esi"] = "0x" + segment["esi"].replace(/:/g, "").toLowerCase();
            }
          }
          if(segment["pbb"] && segment["pbb"]["source-bmac-lsb"]){
            let sourceBmacLsb = segment["pbb"]["source-bmac-lsb"];
            let nameExtension = "0x";
            if (!sourceBmacLsb.startsWith(nameExtension)) {
                 sourceBmacLsb = "0x" + sourceBmacLsb.replace(/:/g, "").toLowerCase();
            } else {
                 sourceBmacLsb = sourceBmacLsb.toLowerCase();
            }
            segment["pbb"]["source-bmac-lsb"] = sourceBmacLsb;
          }
          ["port", "lag", "pw-port"].forEach((key) => {
            if (segment["association"] && segment["association"][key]) {
             segment["association"][key] = supportAllAssociateList(segment["association"][key]);
            }
          });
          confObj["ethernet-segment"][i] = segment;
        }
      }
      let deviatedObj = intentDeviationObj.removeIntentConfig(confObj, neId);
      let finalConfigObj = {};
        let intentKey = intentTypeName + ":" + intentTypeName
      finalConfigObj[intentKey] = {};
      finalConfigObj[intentKey][intentContainer] = deviatedObj;
      preSyncConf.push(finalConfigObj);
    }
    logger.info("intent config after removing deviation attributes: " + JSON.stringify(preSyncConf));
    return JSON.stringify(preSyncConf);
  };

  /**
   * PostSync Hook
   */
  const postSync = (inputObj) => {
    /**
     * Write your custom postSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] postSync call");
    logger.info("[CUSTOM-HOOKS] inputObj " + JSON.stringify(inputObj));
  };

  /**
   *
   * PostDiscovery Hook
   */
  const postDiscovery = (inputObj) => {
    /**
     * Write your custom postDiscovery logic here
     * inputObj by default contains the following keys:
     *        deviceConfig, intentContainer, neId,
     *        targetDataStruct, templateName, deviceYangModuleName
     */

    logger.info("[CUSTOM-HOOKS] postDiscovery call");
    logger.info("[CUSTOM-HOOKS] inputObj " + JSON.stringify(inputObj));

  }

  this.removeEmptyContainers = function (prop, intentJson, path, target) {
    if (Array.isArray(intentJson)) {
      var object = [];
      for (var prop in intentJson) {
        var value = this.removeEmptyContainers(prop, intentJson[prop], path, target);
        if (value) {
          object.push(value);
        }

        }
        if(Object.keys(object).length !== 0){
            return object;
      }
    }else if( typeof intentJson == 'object' ){
        var object = {};
        for(var prop in intentJson){
            var pPath = path + "/" + prop;
            var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
            if((value && value!==null) || value == 0 ){
                object[prop] = value;
            }

        }
        if(Object.keys(object).length !== 0){
        return object;
      }
    }else{
        if(intentJson!==undefined && intentJson!==""){
    return intentJson;
        }

        return null;
    }
}

this.expandIPv6 = function (obj) {
        for (var key in obj) {
            if (typeof obj[key] === 'object' && obj[key] !== null) {
                this.expandIPv6(obj[key]);
            } else if (typeof obj[key] === 'string' && this.matchExact(ipv6Regex, obj[key])) {
                obj[key] = this.expandIPv6AddressForMd(obj[key]);
        }
      }
      return obj
    }
    this.matchExact = function(r, str) {
            var match = str.match(r);
            return match && str === match[0];
}

        this.expandIPv6AddressForMd = function (input) {
            var expanded = ipv6AddressUtil.expandIPv6Address(input);
            expanded = ipv6AddressUtil.MdIpv6ValidAddresssMaskSupport(expanded);
            return expanded;
        };
    function supportAllAssociateList(container) {
      if (container && Array.isArray(container)) {
          for (let i = 0; i < container.length; i++) {
              let config = container[i];
              if (config && config["virtual-ranges"]) {
                  if (config["virtual-ranges"]["dot1q"] && config["virtual-ranges"]["dot1q"]["q-tag"]) {
                      let qTags = config["virtual-ranges"]["dot1q"]["q-tag"];
                      if (qTags && Array.isArray(qTags)) {
                          for (let j = 0; j < qTags.length; j++) {
                              let qTagConfig = qTags[j];
                              if (qTagConfig) {
                                  if (qTagConfig["start"] && typeof qTagConfig["start"] === "number") {
                                      qTagConfig["start"] = String(qTagConfig["start"]);
                                  }
                                  if (qTagConfig["end"] && typeof qTagConfig["end"] === "number") {
                                      qTagConfig["end"] = String(qTagConfig["end"]);
                                  }
                              }
                          }
                      }
                  }
                  if (config["virtual-ranges"]["qinq"]) {
                      let sTagcTag = config["virtual-ranges"]["qinq"]["s-tag-c-tag"];
                      if (sTagcTag && Array.isArray(sTagcTag)) {
                          for (let j = 0; j < sTagcTag.length; j++) {
                              let sTagcTagConfig = sTagcTag[j];
                              if (sTagcTagConfig) {
                                  if (sTagcTagConfig["c-tag-start"] && typeof sTagcTagConfig["c-tag-start"] === "number") {
                                      sTagcTagConfig["c-tag-start"] = String(sTagcTagConfig["c-tag-start"]);
                                  }
                                  if (sTagcTagConfig["c-tag-end"] && typeof sTagcTagConfig["c-tag-end"] === "number") {
                                      sTagcTagConfig["c-tag-end"] = String(sTagcTagConfig["c-tag-end"]);
                                  }
                                  if (sTagcTagConfig["s-tag"] && typeof sTagcTagConfig["s-tag"] === "number") {
                                      sTagcTagConfig["s-tag"] = String(sTagcTagConfig["s-tag"]);
                                  }
                              }
                          }
                      }
                      let sTag = config["virtual-ranges"]["qinq"]["s-tag"];
                      if (sTag && Array.isArray(sTag)) {
                          for (let j = 0; j < sTag.length; j++) {
                              let sTagConfig = sTag[j];
                              if (sTagConfig) {
                                  if (sTagConfig["start"] && typeof sTagConfig["start"] === "number") {
                                      sTagConfig["start"] = String(sTagConfig["start"]);
                                  }
                                  if (sTagConfig["end"] && typeof sTagConfig["end"] === "number") {
                                      sTagConfig["end"] = String(sTagConfig["end"]);
                                  }
                              }
                          }
                      }
                  }
              }
          }
      }
     return container;
  }
  this.supportAllAssociateList = supportAllAssociateList;
  this.preAudit = preAudit;
  this.postAudit = postAudit;
  this.preSync = preSync;
  this.postSync = postSync;
  this.postDiscovery = postDiscovery;

}