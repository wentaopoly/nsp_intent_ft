function MdSuggest() {

   this.getLagPort = function (neId) {
      logger.info("getLagPort ==> neId = {}", neId);
      const url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/lag";
      return this.getData(neId, url, "lag-name", "nokia-conf:lag");
   }

   this.getOperGroup = function (neId) {
      logger.info("getOperGroup ==> neId = {}", neId);
      const url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/service/oper-group";
      return this.getData(neId, url, "name", "nokia-conf:oper-group");
   }

   this.getPortName = function (neId) {
      logger.info("getOperGroup ==> neId = {}", neId);
      const url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/port";
      return this.getData(neId, url, "port-id", "nokia-conf:port");
   }
   this.getPwPortId = function (neId) {
      logger.info("getOperGroup ==> neId = {}", neId);
      const url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/pw-port";
      return this.getData(neId, url, "pw-port-id", "nokia-conf:pw-port");
   }

   this.getSDPId = function (neId) {
      logger.info("getOperGroup ==> neId = {}", neId);
      const url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/service/sdp";
      return this.getData(neId, url, "sdp-id", "nokia-conf:sdp");
   }

   this.getData = function (neId, url, type, configName) {
      var mdcFwk = new MdcFwk();
      var resultFetch = mdcFwk.fetch(neId, url);
      var finalResponse = resultFetch["msg"][configName];
      const ret = Array.isArray(finalResponse) ? finalResponse.map(Data => Data[type]).filter(value => value != null) : [];
      logger.info("getData() of [" + configName + "] values = \n" + JSON.stringify(ret));
      return ret;
   }
}