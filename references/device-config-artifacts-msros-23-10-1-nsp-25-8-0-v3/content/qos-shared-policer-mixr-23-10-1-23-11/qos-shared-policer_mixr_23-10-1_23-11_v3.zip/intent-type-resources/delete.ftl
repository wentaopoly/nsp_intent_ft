{
  "ietf-yang-patch:yang-patch": {
    "patch-id": "generic-patch-${timestamp}",
    "edit": [
      {
        "operation": "delete",
        "edit-id": "edit-${timestamp}",
        "target": "${target}"
      }
    ]
  }
}