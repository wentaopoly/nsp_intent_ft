var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})

var intentTypeName = 'macsec-ca_csros_23-10-1_23-11';

// example port, sap-ingress etc..
var initialPropertyName = 'connectivity-association';


// unique identifier
var uniqueIdentifier = 'ca-name';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/macsec';

function synchronize(input) {
    logger.info('Intent Synchronisation started')
    return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function audit(input) {
    logger.info('Intent Audit started')
    logger.info("*******config ===== {}", input);
    return NspIntentHelper.audit(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier)
}

function suggestCaName(context) {
    logger.info("suggestCaName context = \n" + context);
    var neId = getNeId(context);
    return new NfmpSuggest().getCaName();
}

function suggestSites(context) {
    logger.info("suggestSites context = \n" + context);
    var neId = getNeId(context);
    return new NfmpSuggest().getSites();
}

function suggestHsmId(context) {
    logger.info("suggestHsmId context = \n" + context);
    var neId = getNeId(context);
    return new NfmpSuggest().getHsmId();
}

function suggestPskId(context) {
    logger.info("suggestPskId context = \n" + context);
    var arr = [];
    var inp = JSON.parse(context['inputValues'])
    var staticCak = inp["arguments"]["connectivity-association"]["static-cak"];
    var preSharedKeys = staticCak["pre-shared-key"]
    logger.info("staticCak=====" + JSON.stringify(staticCak));
    logger.info("preSharedKeys=====" + JSON.stringify(preSharedKeys));
    if (preSharedKeys)
    {
        for (var i = 0; i < preSharedKeys.length; i++)
        {
            arr.push(preSharedKeys[i]["psk-id"]);
        }
    }
    logger.info("arr = {}", JSON.stringify(arr))
    return arr;
}

function getNeId(context) {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    logger.info(target)
    if (target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    logger.info("NeId : " + neId);
    return neId;
}

function getTargetData(input) {
    logger.info("getTargetData input for brownfield = \n" + input);
    var target = input.target;
    var config = null;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info(JSON.stringify(deviceConfig));
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}

