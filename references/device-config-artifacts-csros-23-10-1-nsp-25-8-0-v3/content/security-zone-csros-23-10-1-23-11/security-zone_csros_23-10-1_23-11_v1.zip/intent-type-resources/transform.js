load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})
var nfmpSuggest = new NfmpSuggest();
function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        var nfmpSuggest = new NfmpSuggest();
        logger.info("GF PAYLOAD : " + JSON.stringify(payload["configInfo"]));
        if(payload["configInfo"]) {
        if(payload["configInfo"]["securitypolicy.Zone"]) {
        if(payload["configInfo"]["securitypolicy.Zone"]["children-Set"]) {
        if(payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"]) {

          for(let i=0; i<payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"].length; i++) {

            if(payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]) {
            if(payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]) {
            if(payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"]) {

              for(let j=0; j<payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"].length; j++) {

                if(payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"][j]["vprnInterfacePointer"] != undefined || payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"][j]["iesInterfacePointer"] != undefined || payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"][j]["interfacePointer"] != undefined) {

                  //payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"][j]["ipAddressStart"] = "";
                  //payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"][j]["ipAddressEnd"] = "";

                  if(payload["configInfo"]["securitypolicy.Zone"]["routerType"] == "base") {

                    payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"][j]["interfacePointer"] = nfmpSuggest.getObjectFullNameNetworkInterface(neId, payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"][j]["interfacePointer"]);
                  }
                  else if(payload["configInfo"]["securitypolicy.Zone"]["routerType"] == "vprn") {

                    payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"][j]["vprnInterfacePointer"] = nfmpSuggest.getVPRNInterface(neId, payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"][j]["vprnInterfacePointer"]);
                  }
                  else if(payload["configInfo"]["securitypolicy.Zone"]["routerType"] == "ies") {

                    payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"][j]["iesInterfacePointer"] = nfmpSuggest.getIESInterface(neId, payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"][j]["iesInterfacePointer"]);
                  }
                }

                else if(payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"][j]["ipAddressStart"] != "" || payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"][j]["ipAddressEnd"] != "") {

                  if(payload["configInfo"]["securitypolicy.Zone"]["routerType"] == "base") {

                    payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"][j]["interfacePointer"] = "";
                  }
                  else if(payload["configInfo"]["securitypolicy.Zone"]["routerType"] == "vprn") {

                    payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"][j]["vprnInterfacePointer"] = "";
                  }
                  else if(payload["configInfo"]["securitypolicy.Zone"]["routerType"] == "ies") {

                    payload["configInfo"]["securitypolicy.Zone"]["children-Set"]["securitypolicy.NatPool"][i]["children-Set"]["securitypolicy.NatPoolEntry"][j]["iesInterfacePointer"] = "";
                  }
                }
              }
            }
            }
            }
          }
        }
        }
        }
        }
        logger.info("UPDATED GF PAYLOAD : " + JSON.stringify(payload));

        if(payload)

        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {

        var nfmpSuggest = new NfmpSuggest();
        logger.info("TARGET KEY : " + targetKey);
        if(targetKey == "secPolicyPointer") {
          targetValue = "securityPolicy:sp-" + targetValue;
        }
        if(targetKey == "secLogPointer") {
          targetValue = "securityLog:seclog-" + targetValue;
        }
        if(targetKey == "vprnPointer") {
          targetValue = "svc-mgr:service-" + nfmpSuggest.getVPRNServiceID(neId, targetValue);
        }
        if(targetKey == "iesPointer") {
          targetValue = "svc-mgr:service-" + nfmpSuggest.getIESServiceID(neId, targetValue);
        }
        if(targetKey == "vplsPointer") {
          targetValue = "svc-mgr:service-" + nfmpSuggest.getVPLSServiceID(neId, targetValue);
        }
        if(targetKey == "mvplsPointer") {
          targetValue = "svc-mgr:service-" + nfmpSuggest.getMVPLSServiceID(neId, targetValue);
        }
        if(targetKey == "epipePointer") {
          targetValue = "svc-mgr:service-" + nfmpSuggest.getEPIPEServiceID(neId, targetValue);
        }
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
        let neId = fullDeviceConfig["siteId"];
        if(targetKey == "secPolicyPointer") {
          targetValue = targetValue.split("securityPolicy:sp-")[1];
        }
        if(targetKey == "secLogPointer") {
          targetValue = targetValue.split("securityLog:seclog-")[1];
        }
        if(targetKey == "vprnPointer") {
          targetValue = nfmpSuggest.getVPRNID(neId, targetValue.split("svc-mgr:service-")[1]);
        }
        if(targetKey == "iesPointer") {
          targetValue = nfmpSuggest.getIESID(neId, targetValue.split("svc-mgr:service-")[1]);
        }
        if(targetKey == "vplsPointer") {
          targetValue = nfmpSuggest.getVPLSID(neId, targetValue.split("svc-mgr:service-")[1]);
        }
        if(targetKey == "mvplsPointer") {
          targetValue = nfmpSuggest.getMVPLSID(neId, targetValue.split("svc-mgr:service-")[1]);
        }
        if(targetKey == "epipePointer") {
          targetValue = nfmpSuggest.getEPIPEID(neId, targetValue.split("svc-mgr:service-")[1]);
        }
        if(targetKey == "interfacePointer") {
          targetValue = nfmpSuggest.getInterfacePointerID(neId, targetValue);
        }
        if(targetKey == "iesInterfacePointer") {
          targetValue = nfmpSuggest.getIESInterfaceID(neId, targetValue);
        }
        if(targetKey == "vprnInterfacePointer") {
          targetValue = nfmpSuggest.getVPRNInterfaceID(neId, targetValue);
        }
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
}
