var RuntimeException = Java.type("java.lang.RuntimeException");
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({
    script: resourceProvider.getResource("util-fwk.js"),
    name: "utilities",
});
load({script: resourceProvider.getResource("map-fwk.js"), name: "MapFwk"});
load({
    script: resourceProvider.getResource("parse-target.js"),
    name: "ParseTarget",
});
load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})
load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
function NfmpMacFilter() {
    var util = new utilities();
    var mapFwk = new MapFwk();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var savedObjects;
    var currentObjects;
    var isAudit = false;
    var isLocalExists = false;
    var isGlobalExists = false;
    var macFilterPayload;
    var isEdit = false;
    var mdtfwk = new MdtFwk();
    var distribute_url = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true";

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        // code to handle delete
        if (input.getNetworkState().name() === "delete") {
            return this.syncDelete(input, result);
        }

        var savedTopology = input.getCurrentTopology();
        savedObjects = {};
        currentObjects = {};
        isAudit = false;
        //loading the saved objects from topology
        this.loadSavedObjectsFromTopology(savedTopology);

        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        var filterId = util.getMacFilterId(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        if (!intentConfig) {
            intentConfig = Object.create({});
        }
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());
        intentConfig["id"] = parseInt(filterId);
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target MAC-Filter = " + intentConfig[uniqueIdentifier]);

        this.createOrModify(target, intentConfig,intentConfig[uniqueIdentifier]);
        var currentTopo = this.loadCurrentObjectsToTopology(target);

        result = util.setSuccessResult(result, currentTopo);
        return result;
    }
    // code to handle sync

    this.audit = function (target, config, svcTopo, adminState, auditReport, intentTypeName, xpath, initialPropertyName, uniqueIdentifier) {

        var savedTopology = svcTopo;
        savedObjects = {};
        currentObjects = {};
        isAudit = true;
        var filterId = util.getMacFilterId(target);
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        if (!intentConfig) {
            intentConfig = Object.create({});
        }
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        intentConfig["id"] = parseInt(filterId);
        var neId = parseTarget.getNeIdFromTarget(target);
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target mac-filter = " + intentConfig[uniqueIdentifier]);

        if (intentConfig) {
            this.auditAndCompare(neId, intentConfig, auditReport);
        } else {
            throw "configuration not available in the intent";
        }

        return auditReport
    }
    this.auditAndCompare = function (target, intentConfig, auditReport) {
        var macFilterPayload = this.createPolicyLevelPayLoad(target, intentConfig, true);
        var result = this.auditRequest(target, macFilterPayload);
        auditReport = util.reportMisaligned(target, result, auditReport);
        return auditReport;
    }
    this.auditRequest = function (target, payload) {
        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.createOrModify= function(neId, intentConfig,uniqueIdentifier) {
        var fullClassName = "aclfilter.MacFilter";
        var objectFullName = "MAC Filter:" + intentConfig["id"];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        var localPolicy = util.getIfObjectExists(fullClassName, localPolicyFullName);
        var result;
        var macFilterPayload;
        var distributePayload;
        var distributeResult;
        if (localPolicy != null) {
            isLocalExists = true;
            isGlobalExists = true;
            if (localPolicy[0]["filterName"] !== uniqueIdentifier) {
                throw new RuntimeException("Already there exists a policy on " + neId +
                    " with Filter name " + localPolicy[0]["filterName"] + " with filter ID " + intentConfig["id"]);
            }
            macFilterPayload = this.createPolicyLevelPayLoad(neId, intentConfig, isLocalExists, localPolicy);
            result = this.modifyRequest(neId, macFilterPayload);
            if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                throw new RuntimeException('Unable to Create/Distribute Policy: ' + intentConfig["id"] +
                    " , Kindly check the intent configuration");
            }
        }
        else {
            logger.info(LOG_PREFIX + "####### Unable to find the local policy, Trying to fetch global policy if available ######");
            var searchPayload = this.constructSearchString(fullClassName, objectFullName);
            var searchResponse = nfmpFwk.find(neId, searchPayload);
            if (!(searchResponse.success && JSON.stringify(searchResponse.response) === "")) {
                if (!searchResponse.success) {
                    logger.info(LOG_PREFIX + "createOrModify(): Unable to get Policy info from nfm-p for Ne " +
                        neId + " and Filter name: " + uniqueIdentifier);
                }
                if (searchResponse.response === "") {
                    logger.info(LOG_PREFIX + "createOrModify(): There is no mac-filter policy with Name:" +
                        uniqueIdentifier + " on " + neId);
                }
            }
            else {
                throw new RuntimeException("createOrModify(): There exists a mac-filter policy " + uniqueIdentifier + " on " +
                    neId + " with ID " +intentConfig["id"]);
            }

            var globalPolicy = util.getIfObjectExists(fullClassName, objectFullName);
            if (globalPolicy != null) {
                isGlobalExists = true;
                if (globalPolicy[0]["filterName"]  !== uniqueIdentifier) {
                    logger.info(LOG_PREFIX + "createOrModify(): There exists a mac-filter global policy in NFMP with Filter name " +
                        globalPolicy[0]["filterName"] + " with same filter ID " + intentConfig["id"] + " on " + neId);
                    logger.info(LOG_PREFIX + "createOrModify(): Updating mac-filter global Filter name to " +
                        uniqueIdentifier + " on " + neId + " for policy " + intentConfig["id"]);
                    this.updateMacFilterName(neId, objectFullName, uniqueIdentifier);
                }

                distributePayload = util.distribute(neId, objectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(neId, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                logger.info(LOG_PREFIX + "checking distribution of existing global policy was successful#######");
                if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                    throw new RuntimeException("Unable to Distribute existing Global Policy: " + uniqueIdentifier +
                        " , Kindly check the Global Policy configuration");
                }
                logger.info(LOG_PREFIX + "distribution of existing global policy was successful, updating with intent configuration ######");
                macFilterPayload = this.createPolicyLevelPayLoad(neId, intentConfig, true, globalPolicy);
                result = this.modifyRequest(neId, macFilterPayload);
                if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                    throw new RuntimeException('Unable to Create/Distribute Policy: ' + uniqueIdentifier +
                        " , Kindly check the intent configuration");
                }
            }
            else {
                //distributing empty policy
                logger.info(LOG_PREFIX + "##### Unable to find the Global Policy, distributing empty policy and updating ######");
                macFilterPayload = this.createPolicyLevelPayLoad(neId, intentConfig, false, null);
                result = this.modifyRequest(neId, macFilterPayload);
                distributePayload = util.distribute(neId, objectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(neId, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                //updating the local policy with intent configuration
                macFilterPayload = this.createPolicyLevelPayLoad(neId, intentConfig, true, null);
                result = this.modifyRequest(neId, macFilterPayload);
            }
        }
        return result;
    }


    this.updateMacFilterName = function (target, objectFullName, filterName) {
        var fullClassName = "aclfilter.MacFilter";
        var filterFdn = "MAC Filter";
        var properties = {};

        properties["filterName"] = filterName;

        var payload = {};
        var configInfo = {};
        configInfo["containedClassProperties"] = properties;
        configInfo["objectClassName"] = fullClassName;
        payload["distinguishedName"] = filterFdn;
        payload["objectFullName"] = objectFullName;
        payload["configInfo"] = configInfo;
        var result = this.modifyRequest(target, payload);
        return result;
    }

    this.syncDelete = function (input, result) {

        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var filterId = util.getMacFilterId(input.getTarget());
        var className = "aclfilter.MacFilter";
        var objectFullName = "network:" + neId + ":MAC Filter:" + filterId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        var searchPayLoad = this.constructSearchString(className, objectFullName);
        var searchResponse = nfmpFwk.find(neId, searchPayLoad);
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0)) {
            if (!(searchResponse.success))
                logger.info("[NFMP-MAC-FILTER-FWK] syncDelete(): Unable to get Filter info from nfm-p for filter with Id:" + filterId + " on " + neId);
            if (JSON.parse(searchResponse["response"]).length === 0)
                logger.info("[NFMP-MAC-FILTER-FWK] syncDelete(): There is no MAC Filter with Id:" + filterId + " on " + neId);
            result.setSuccess(false);
            return;
        }
        logger.info("[NFMP-MAC-FILTER-FWK] syncDelete(): Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success) {
            logger.info("[NFMP-MAC-FILTER-FWK] syncDelete(): Unable to Delete: " + deleteResult.msg);
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }


    this.constructSearchString = function (className, objectFullName) {
        var expectedJson = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "filterName",
                    "id"
                ]
            }
        };
        return expectedJson;
    }


    this.loadSavedObjectsFromTopology = function (savedTopology) {
        if (savedTopology) {
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0) {
                topoObjects.forEach(function (topoObject) {
                    mapFwk.set(savedObjects, topoObject.getObjectType(), topoObject.getObjectRelativeObjectID());
                });
            }
        }

    }
    this.loadCurrentObjectsToTopology = function (target) {

        var currentTopo = topologyFactory.createServiceTopology();
        if (Object.keys(currentObjects).length) {
            for (var key in currentObjects) {
                objectId = mapFwk.get(currentObjects, key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key, objectId, "INFRASTRUCTURE", target, ""));
            }
        }
        return currentTopo;

    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }

    this.modifyRequest = function (target, payload) {

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
           logger.error("Error result = {}",JSON.stringify(result));
           let errorMsg = result.msg;
           if(errorMsg.indexOf("object already exists") !== -1)
           {
               logger.info("Global policy Object already exists, Re-checking the Policy existence ");
               //util.delay(2000);
               let configInfo = payload.configInfo;
               let fullClassName;
               for (let key in configInfo) {
                 if (configInfo.hasOwnProperty(key)) {
                   fullClassName = key;
                   break;
                 }
               }
               let objectFullName = payload.objectFullName;
               objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
               logger.info("fullClassName = {}",fullClassName);
               logger.info("objectFullName = {}",objectFullName);
               if (!util.isObjectExists(fullClassName, objectFullName))
               {
                   throw new RuntimeException("Global Policy Object Not Found!!!");
               }
           }
           else
           {
               throw new RuntimeException(result.msg);
           }
        }
        return result;

    }

    this.createPolicyLevelPayLoad = function (target, intentConfig, isLocalExists, policyObject) {
        var fullClassName = "aclfilter.MacFilter";
        var filterFdn = "MAC Filter";
        var objectFullName = "MAC Filter:" + intentConfig["id"];
        var localPolicyFullName = "network:" + target + ":MAC Filter:" + intentConfig["id"];
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, target);
        if (isLocalExists) {
            objectFullName = localPolicyFullName;
        }

        var properties = {};
        properties["id"] = intentConfig["id"];
        properties["filterName"] = intentConfig["filterName"];
        properties["description"] = intentConfig["description"];
        properties["defaultAction"] = util.transformNfmpDefaultAction(intentConfig["default-action"]);
        properties["macFilterType"] = intentConfig["type"];
        properties["scope"] = intentConfig["scope"];

        var macFilterEntryPayload = [];
        var childProperties = {};
        if (isLocalExists) {
            if (intentConfig["entry"]) {
                if (!Array.isArray(intentConfig["entry"])) {
                    intentConfig["entry"] = [intentConfig["entry"]];
                }
                for (var index in intentConfig["entry"]) {
                    var intentMacFilterEntryConfig = intentConfig["entry"][index];
                    var entryObjectFullName = objectFullName + ":" + "entry-" + intentMacFilterEntryConfig["entry-id"];
                    mapFwk.set(currentObjects, entryObjectFullName, entryObjectFullName);
                    var entryPayload = this.createMacFilterEntryPayLoad(target, intentMacFilterEntryConfig);
                    macFilterEntryPayload.push(entryPayload);
                }
                childProperties["aclfilter.MacFilterEntry"] = macFilterEntryPayload;
            }
            else{
                childProperties["aclfilter.MacFilterEntry"] = [];
            }
        }
        var EntryLevelPayload = util.editPayload(filterFdn, properties, childProperties, fullClassName, objectFullName);
        return EntryLevelPayload;
    }

    this.createMacFilterEntryPayLoad = function (target, intentMacFilterEntryConfig) {
        var properties = {};
        var nodeType = mdtfwk.getTypeAndVersion(target);
        var deviceType=this.getIxrType(target);
        if (intentMacFilterEntryConfig) {
            properties["id"] = intentMacFilterEntryConfig["entry-id"];
            properties["description"] = intentMacFilterEntryConfig["description"];
            properties["pbrDownActionOvr"] = util.transformNfmpPbrName(intentMacFilterEntryConfig["pbr-down-action-override"]);
            if (intentMacFilterEntryConfig["sticky-dest"] === "no-hold-time-up") {
                properties["stickyDestHoldTimeUp"] = -1;
            }else {
                properties["stickyDestHoldTimeUp"] = intentMacFilterEntryConfig["sticky-dest"];
            }
            properties["logId"] = intentMacFilterEntryConfig["log"];
            properties["collectStats"] = intentMacFilterEntryConfig["collect-stats"];
            if (intentMacFilterEntryConfig["match"]) {
                properties["frameType"] = util.transformNfmpProtocol(intentMacFilterEntryConfig["match"]["frame-type"]);
                properties["snapOui"] = util.transformNfmpSnapOuiName(intentMacFilterEntryConfig["match"]["snap-oui"],nodeType);
                if (intentMacFilterEntryConfig["match"]["snap-pid"] !== undefined || intentMacFilterEntryConfig["match"]["snap-pid"] === undefined) {
                    if (intentMacFilterEntryConfig["match"]["snap-pid"] !== undefined) {
                        properties["snapPid"] = intentMacFilterEntryConfig["match"]["snap-pid"];
                    } else if (nodeType["type"].startsWith("7750")||nodeType["type"].startsWith("7450")||nodeType["type"].startsWith("7950")) {
                        properties["snapPid"] = "-1";
                    }
                }
                if (intentMacFilterEntryConfig["match"]["src-mac"] !== undefined || intentMacFilterEntryConfig["match"]["src-mac"] === undefined) {
                    if (intentMacFilterEntryConfig["match"]["src-mac"] !== undefined) {
                        properties["sourceMacAddress"] = util.nfmpValidMacAddress(intentMacFilterEntryConfig["match"]["src-mac"]["address"]);
                        properties["sourceMacAddressMask"] = util.nfmpValidMacAddress(intentMacFilterEntryConfig["match"]["src-mac"]["mask"]);
                    } else {
                        var srcMacDefaultValue = "00-00-00-00-00-00";
                        properties["sourceMacAddress"] = srcMacDefaultValue;
                        if (!nodeType["type"].startsWith("7705")) {
                            properties["sourceMacAddressMask"] = srcMacDefaultValue;
                        }
                    }
                }
                if (intentMacFilterEntryConfig["match"]["dst-mac"] !== undefined || intentMacFilterEntryConfig["match"]["dst-mac"] === undefined) {
                    if (intentMacFilterEntryConfig["match"]["dst-mac"] !== undefined) {
                        properties["destinationMacAddress"] = util.nfmpValidMacAddress(intentMacFilterEntryConfig["match"]["dst-mac"]["address"]);
                        properties["destinationMacAddressMask"] = util.nfmpValidMacAddress(intentMacFilterEntryConfig["match"]["dst-mac"]["mask"]);
                    } else {
                        var dstMacDefaultValue = "00-00-00-00-00-00";
                        properties["destinationMacAddress"] = dstMacDefaultValue;
                        if (!nodeType["type"].startsWith("7705")) {
                            properties["destinationMacAddressMask"] = dstMacDefaultValue;
                        }
                    }

                }
                if (intentMacFilterEntryConfig["match"]["etype"]!==undefined) {
                    if(nodeType["type"].startsWith("7250")){
                        properties["frameType"]="ethernetII";
                    }
                    properties["ethernetType"] = parseInt(intentMacFilterEntryConfig["match"]["etype"]);
                }else{
                    properties["ethernetType"] =-1;
                }
                if (intentMacFilterEntryConfig["match"]["dot1p"] !== undefined || intentMacFilterEntryConfig["match"]["dot1p"] === undefined) {
                    if (intentMacFilterEntryConfig["match"]["dot1p"] !== undefined) {
                        properties["dot1pValue"] = util.nfmpDot1p(intentMacFilterEntryConfig["match"]["dot1p"]["priority"]);
                        properties["dot1pMask"] = util.nfmpDot1p(intentMacFilterEntryConfig["match"]["dot1p"]["mask"]);
                    } else if(nodeType["type"].startsWith("7750")||nodeType["type"].startsWith("7450")||nodeType["type"].startsWith("7950")||nodeType["type"].startsWith("7250")||nodeType["type"].startsWith("7210")){
                        properties["dot1pValue"] = "default";
                        properties["dot1pMask"] = "priority_0";
                    }
                }
                if (intentMacFilterEntryConfig["match"]["llc-ssap"] !== undefined || intentMacFilterEntryConfig["match"]["llc-ssap"] === undefined) {
                    if (intentMacFilterEntryConfig["match"]["llc-ssap"] !== undefined) {
                        properties["ssap"] = intentMacFilterEntryConfig["match"]["llc-ssap"]["ssap"];
                        properties["ssapMask"] = intentMacFilterEntryConfig["match"]["llc-ssap"]["mask"];
                    } else  if (nodeType["type"].startsWith("7750")||nodeType["type"].startsWith("7450")||nodeType["type"].startsWith("7950")) {
                        var llc_ssapDefaultValue = "-1";
                        properties["ssap"] = llc_ssapDefaultValue;
                        properties["ssapMask"] = llc_ssapDefaultValue;
                    }
                }
                if (intentMacFilterEntryConfig["match"]["llc-dsap"] !== undefined || intentMacFilterEntryConfig["match"]["llc-dsap"] === undefined) {
                    if (intentMacFilterEntryConfig["match"]["llc-dsap"] !== undefined) {
                        properties["dsap"] = intentMacFilterEntryConfig["match"]["llc-dsap"]["dsap"];
                        properties["dsapMask"] = intentMacFilterEntryConfig["match"]["llc-dsap"]["mask"];
                    } else  if (nodeType["type"].startsWith("7750")||nodeType["type"].startsWith("7450")||nodeType["type"].startsWith("7950")) {
                        var llc_dsapDefaultValue = "-1";
                        properties["dsap"] = llc_dsapDefaultValue;
                        properties["dsapMask"] = llc_dsapDefaultValue;
                    }

                }
                if (intentMacFilterEntryConfig["match"]["inner-tag"] !== undefined || intentMacFilterEntryConfig["match"]["inner-tag"] === undefined) {
                    if (intentMacFilterEntryConfig["match"]["inner-tag"] !== undefined) {
                        properties["innerTagValue"] = intentMacFilterEntryConfig["match"]["inner-tag"]["tag"];
                        properties["innerTagMask"] = intentMacFilterEntryConfig["match"]["inner-tag"]["mask"];
                    } else if (nodeType["type"].startsWith("7750")||nodeType["type"].startsWith("7450")||nodeType["type"].startsWith("7950")) {
                        properties["innerTagValue"] = "-1";
                        properties["innerTagMask"] = "4095";
                    }
                }
                if (intentMacFilterEntryConfig["match"]["outer-tag"] !== undefined || intentMacFilterEntryConfig["match"]["outer-tag"] === undefined) {
                    if (intentMacFilterEntryConfig["match"]["outer-tag"] !== undefined) {
                        properties["outerTagValue"] = intentMacFilterEntryConfig["match"]["outer-tag"]["tag"];
                        properties["outerTagMask"] = intentMacFilterEntryConfig["match"]["outer-tag"]["mask"];
                    } else if (nodeType["type"].startsWith("7750")||nodeType["type"].startsWith("7450")||nodeType["type"].startsWith("7950")) {
                        properties["outerTagValue"] = "-1";
                        properties["outerTagMask"] = "4095";
                    }
                }

                if (intentMacFilterEntryConfig["match"]["isid"]["value"] !== undefined) {
                    properties["isidLow"] = intentMacFilterEntryConfig["match"]["isid"]["value"];
                    properties["isidHigh"] = intentMacFilterEntryConfig["match"]["isid"]["value"];
                } else if (intentMacFilterEntryConfig["match"]["isid"]["range"] !== undefined) {
                    properties["isidLow"] = intentMacFilterEntryConfig["match"]["isid"]["range"]["start"];
                    properties["isidHigh"] = intentMacFilterEntryConfig["match"]["isid"]["range"]["end"];
                } else if (nodeType["type"].startsWith("7750")||nodeType["type"].startsWith("7450")||nodeType["type"].startsWith("7950")) {
                    var isidDefaultValue = "-1";
                    properties["isidLow"] = isidDefaultValue;
                    properties["isidHigh"] = isidDefaultValue;
                }

            }
            if (intentMacFilterEntryConfig["action"]) {
                if (intentMacFilterEntryConfig["action"]["drop"] !== undefined) {
                    properties["action"] = "drop";
                }

                if (intentMacFilterEntryConfig["action"]["ignore-match"] !== undefined) {
                    properties["action"] = "ignoreMatch";
                }
                if (intentMacFilterEntryConfig["action"]["http-redirect"] !== undefined) {
                    properties["action"] = "httpredirect";
                    properties["redirectURL"] = intentMacFilterEntryConfig["action"]["http-redirect"]["url"];
                }
                if (intentMacFilterEntryConfig["action"]["forward"] !== undefined) {
                    if (intentMacFilterEntryConfig["action"]["forward"]["sap"]) {
                        properties["action"] = "forwardSap";
                        properties["fwdSapPortName"] = util.extractPort(intentMacFilterEntryConfig["action"]["forward"]["sap"]["sap-id"]);
                        properties["fwdSapOuterEncapValue"] = util.extractOuterEncapValue(intentMacFilterEntryConfig["action"]["forward"]["sap"]["sap-id"]);
                        properties["fwdSapInnerEncapValue"] = util.extractInnerEncapValue(intentMacFilterEntryConfig["action"]["forward"]["sap"]["sap-id"]);
                    } else if (intentMacFilterEntryConfig["action"]["forward"]["sdp"]) {
                        properties["action"] = "forwardSdp";
                        properties["fwdSdpBindPathId"] = util.extractPathId(intentMacFilterEntryConfig["action"]["forward"]["sdp"]["sdp-bind-id"]);
                        properties["fwdSdpBindVcId"] = util.extractVCId(intentMacFilterEntryConfig["action"]["forward"]["sdp"]["sdp-bind-id"]);
                    } else if (intentMacFilterEntryConfig["action"]["forward"]["esi-l2"]) {
                        properties["action"] = "forwardEsi";
                        properties["fwdEsiValue"] = intentMacFilterEntryConfig["action"]["forward"]["esi-l2"]["esi-value"];
                        properties["fwdEsiVplsServicePointer"] = util.esiVplsNfmpPattern(intentMacFilterEntryConfig["action"]["forward"]["esi-l2"]["vpls"]);


                    }
                }
                if (intentMacFilterEntryConfig["action"]["accept"] !== undefined) {
                    if (intentMacFilterEntryConfig["action"]["rate-limit"]) {
                        properties["action"] = "ratelimit";
                        if (intentMacFilterEntryConfig["action"]["rate-limit"]["pir"] === "max") {
                            properties["rateLimit"] = -1;
                        } else {
                            properties["rateLimit"] = intentMacFilterEntryConfig["action"]["rate-limit"]["pir"];
                        }
                    } else {
                        properties["action"] = "forward";
                    }
                }
                if(deviceType["type"].startsWith("7250 IXR-x")){
                    if (intentMacFilterEntryConfig["action"]["accept"] !== undefined) {
                        if(intentMacFilterEntryConfig["action"]["fc"]){
                            properties["forwardFcType"]=intentMacFilterEntryConfig["action"]["fc"];
                        }
                    }
                }
                if (intentMacFilterEntryConfig["action"]["secondary"]) {
                    if (intentMacFilterEntryConfig["action"]["secondary"]["forward"] !== undefined) {
                        if (intentMacFilterEntryConfig["action"]["secondary"]["forward"]["sap"]) {
                            properties["secondaryAction"] = "forwardSap";
                            properties["secondaryFwdSapPortName"] = util.extractPort(intentMacFilterEntryConfig["action"]["secondary"]["forward"]["sap"]["sap-id"]);
                            properties["secondaryFwdSapOuterEncapValue"] = util.extractOuterEncapValue(intentMacFilterEntryConfig["action"]["secondary"]["forward"]["sap"]["sap-id"]);
                            properties["secondaryFwdSapInnerEncapValue"] = util.extractInnerEncapValue(intentMacFilterEntryConfig["action"]["secondary"]["forward"]["sap"]["sap-id"]);
                        } else if (intentMacFilterEntryConfig["action"]["secondary"]["forward"]["sdp"]) {
                            properties["secondaryAction"] = "forwardSdp";
                            properties["secondaryFwdSdpBindPathId"] = util.extractPathId(intentMacFilterEntryConfig["action"]["secondary"]["forward"]["sdp"]["sdp-bind-id"]);
                            properties["secondaryFwdSdpBindVcId"] = util.extractVCId(intentMacFilterEntryConfig["action"]["secondary"]["forward"]["sdp"]["sdp-bind-id"]);
                        }
                    }
                }else if(nodeType["type"].startsWith("7750")||nodeType["type"].startsWith("7450")||nodeType["type"].startsWith("7950")){
                    properties["secondaryAction"]="none"
                }
            }else{
                //Sending Default Action Value
                properties["action"] = "drop";
            }
        }
        return properties;
    }

    this.getIxrType= function (target) {
        var deviceInfos = mds.getAllInfoFromDevices(target);
        if (null == deviceInfos || deviceInfos.size() === 0) {
            throw new RuntimeException("Device not found :" + target);
        }
        var deviceInfo = deviceInfos.get(0);
        var deviceType = deviceInfo.getFamilyTypeRelease();
        if (deviceType == null) {
            throw new RuntimeException("Device Family type and release not found for device: " + target);
        }
        var type= deviceType.split(':');
        log.info(null, "Device type:" + type);
        var deviceType;
        deviceType = {
            type: type[2]
        };
        return deviceType;
    };
}

