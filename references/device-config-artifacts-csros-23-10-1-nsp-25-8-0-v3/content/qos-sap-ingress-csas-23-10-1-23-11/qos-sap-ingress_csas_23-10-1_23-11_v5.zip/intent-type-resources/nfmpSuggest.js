load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {
    this.getPolicyName = function (neId) {
        var searchObject = {
            "fullClassName": "sasqos.AccessIngress",
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "attribute": [
                    "displayedName"
                ]
            }
        };
        //return this.getData(neId, searchObject, "id", policyName);
        return this.getData(searchObject, "displayedName")
    }

    this.getPolicyId= function (neId, policyName) {
        var className = "sasqos.AccessIngress";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "equal":
                    {
                        "name": "siteId",
                        "value": neId
                    }

            },
            "resultFilter": {
                "attribute": [
                    "id"
                ]
            }
        };
        return this.getData(searchObject, "id");
    }




    this.getData = function (searchObjectJson, a) {
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        finalResponse = finalResponse["sasqos.AccessIngress"];
        logger.info(JSON.stringify(finalResponse));

        if (Object.keys(finalResponse).length !== 0)
        {
            finalResponse.forEach(function (value, index, array) {
                ret.push(value[a]);
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }
}
