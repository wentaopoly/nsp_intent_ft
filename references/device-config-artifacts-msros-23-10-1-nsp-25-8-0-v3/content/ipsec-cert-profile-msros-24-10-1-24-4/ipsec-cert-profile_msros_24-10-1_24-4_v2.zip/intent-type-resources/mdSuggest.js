function MdSuggest() {

    this.getCertProfileName = function (neId) {
           const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/ipsec/cert-profile?fields=name`;
           return this.getSuggestData(neId, url, "nokia-conf:cert-profile", "name");
        }
    this.getCaProfileName = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/system/security/pki/ca-profile?fields=ca-profile-name`;
    return this.getSuggestData(neId, url, "nokia-conf:ca-profile", "ca-profile-name");
   }

   this.getSuggestData = function(neId, url, initialProperty, propertyName) {
      const mdcFwk = new MdcFwk();
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg[initialProperty];
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data[propertyName]).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }
}
