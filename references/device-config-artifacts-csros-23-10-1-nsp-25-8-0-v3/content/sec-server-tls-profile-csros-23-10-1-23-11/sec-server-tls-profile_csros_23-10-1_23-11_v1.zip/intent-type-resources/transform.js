function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        if(!isAudit){
            if(!payload["configInfo"]["sitesec.TlsServerProfile"]["cipherListName"]) {
              payload["configInfo"]["sitesec.TlsServerProfile"]["cipherListName"] = "";
            }
            if(!payload["configInfo"]["sitesec.TlsServerProfile"]["certificateProfile"]) {
              payload["configInfo"]["sitesec.TlsServerProfile"]["certificateProfile"] = "";
            }
            if(!payload["configInfo"]["sitesec.TlsServerProfile"]["trustAnchorProfile"]) {
              payload["configInfo"]["sitesec.TlsServerProfile"]["trustAnchorProfile"] = "";
            }
            if(!payload["configInfo"]["sitesec.TlsServerProfile"]["cnListName"]) {
              payload["configInfo"]["sitesec.TlsServerProfile"]["cnListName"] = "";
            }
            if(!payload["configInfo"]["sitesec.TlsServerProfile"]["groupListName"]) {
              payload["configInfo"]["sitesec.TlsServerProfile"]["groupListName"] = "";
            }
            if(!payload["configInfo"]["sitesec.TlsServerProfile"]["signatureListName"]) {
              payload["configInfo"]["sitesec.TlsServerProfile"]["signatureListName"] = "";
            }
        }

        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
}