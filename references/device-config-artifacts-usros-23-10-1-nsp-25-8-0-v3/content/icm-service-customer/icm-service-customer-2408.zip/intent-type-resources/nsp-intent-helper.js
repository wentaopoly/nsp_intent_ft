load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
load({script: resourceProvider.getResource('mdc-intent-fwk.js'), name: 'MdcIntentFwk'})
load({script: resourceProvider.getResource('nfmp-customer.js'), name: 'NfmpCustomer'})
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('nsp-audit.js'), name: 'NSPAudit'})

load({script: resourceProvider.getResource('nsp-restconf-fwk.js'), name: 'nsp-restconf-fwk'});
var nspRestconfFwk = new NspRestconfFwk();

function NspIntentHelper() {

  var mdtFwk = new MdtFwk();
  var util = new utilities();
  var md_sites = [];
  var classic_sites = [];
  //var savedTopologyMap = {};

  this.synchronize = function(input,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier, topologyMap) {

    logger.info('Nsp Intent Helper -> Synchronise');

    try
    {
      md_sites = [];
      classic_sites = [];
      var startTime = Date.now()
      logger.info('[Nsp-Intent-Helper] Synchronize startTime = '+startTime);
      var intentConfig = util.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
      var result = synchronizeResultFactory.createSynchronizeResult();
      var sites = intentConfig['sites']

      if (sites !== undefined && sites !== null)
      {
        if(!Array.isArray(sites))
        {
          sites = [sites];
        }
        for (var i = 0; i < sites.length; i++)
        {
          var target = sites[i]['site-id'];
          this.populateSiteByManager(target);
        }
      }
      intentConfig['sites'] = md_sites;
      logger.info("Calling MDC-Intent-fwk ... on sites {}", JSON.stringify(md_sites))
      this.createMdcInstance().synchronize(input, result,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier,intentConfig, topologyMap);
      logger.info("Customer Management Topology MAP = {}",JSON.stringify(topologyMap));
      if ( result['success'])
      {
        intentConfig['sites'] = classic_sites;
        logger.info("Calling Nfmp-Customer ... on sites {}", JSON.stringify(classic_sites))
        this.createNfmpInstance().synchronize(input, result,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier,intentConfig);
      }

      var endTime = Date.now()
      logger.info('[Nsp-Intent-Helper] Synchronize EndTime = '+endTime);
      logger.info("[Nsp-Intent-Helper] Synchronize Took : {} ms ", endTime - startTime)

      return result
    }
    catch (e)
    {
      logger.info('Error Occured while Synchronising with error: ' + e)
      throw new RuntimeException('Error Executing Intent: ' + e)
    }
  }

  this.audit = function(target, config, svcTopo, adminState,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {

    try {
      var nspAudit = new NSPAudit()
      var startTime = Date.now()

      var report = auditFactory.createAuditReport(null, null);
      nspAudit.handleAudit(target, config, svcTopo, adminState, report, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier)

      logger.info("[Nsp-Intent-Helper] Audit Took : {} ms ", Date.now() - startTime)
      return report
    } catch (e) {
      logger.info('Error Occured while Auditing with error: ' + e)
      throw new RuntimeException('Error Executing Intent: ' + e)
    }
  }

  this.populateSiteByManager = function(target) {

    var managerName = mdtFwk.getManagerName(target);

    logger.info('Device: ' + target + ' is managed by: ' + managerName);
    var site = {}
    site['site-id'] = target;
    switch(managerName) {
      case 'NFM-P':
        logger.info('Device is managed by NFMP')
        classic_sites.push(site)
        break;
      case 'MDC':
        logger.info('Device is managed by MDM')
        md_sites.push(site)
        break;
      default:
        logger.info('Device is not managed')
        throw new RuntimeException('Device is not Managed')
    }

    return ''
  }

  this.createNfmpInstance = function() {
    return new NfmpCustomer()
  }

  this.createMdcInstance = function() {
    return new MdcIntentFwk()
  }

}
