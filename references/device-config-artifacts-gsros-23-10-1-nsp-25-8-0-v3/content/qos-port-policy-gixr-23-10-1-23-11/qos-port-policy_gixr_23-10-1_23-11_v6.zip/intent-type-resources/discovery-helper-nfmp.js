var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk' });
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("model-device-mapping.js"), name: "model-device-mapping"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});

var port_qos_full_class_name = "ixrqos.PortQosPolicy";
var port_qos_policy_name = "displayedName";
var port_qos_fdn = "PortQosPolicy7250SROS";

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let mdcFwk = new MdcFwk();
    let parseTarget = new ParseTarget();
    let modelDeviceMapping = new ModelDeviceMapping();
    let util = new utilities();

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let policyName = parseTarget.getUniqueIdentifier(target);
        let objectFullName = port_qos_fdn + ":" + policyName;
        let localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        logger.info(LOG_PREFIX + "localPolicyFullName: " + localPolicyFullName);
        let resultFetch = nfmpFwk.post("/v3/search", this.constructSearchString(port_qos_full_class_name, localPolicyFullName));
        if (!resultFetch.success) {
            throw new RuntimeException("Failed to find policy : " + policyName + " on NE " + neId);
        }
        let finalResponse = JSON.parse(resultFetch.response);
        if (JSON.stringify(finalResponse) === JSON.stringify({})) {
            throw new RuntimeException("search results is empty for policy : " + policyName + " finalResponse: " + JSON.stringify(finalResponse));
        }
        else if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse[port_qos_full_class_name]];
            logger.info(LOG_PREFIX + "Search results: " + JSON.stringify(finalResponse));
        }
        return finalResponse[0];
    }

    this.constructSearchString = function (className, objectFullName) {
        let searchJson = {
            "fullClassName": className,
            "filter":{
                "equal":{
                    "name":"objectFullName",
                    "value": objectFullName
                }
            }
        };
        return searchJson;
    }

    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedTargetData = JSON.parse(defaultTargetData)[initialPropertyName];
        let loadingTargetData = JSON.parse(JSON.stringify(parsedTargetData));
        this.extractNonChildProperties(parsedTargetData, deviceConfig);
        let portQosChildConfigs = deviceConfig["children-Set"];
        for (let childAttribute in portQosChildConfigs) {
            switch (childAttribute) {
                case "ixrqos.PortQosQueue":
                    {
                        let portQosQueueConfig = portQosChildConfigs[childAttribute];
                        let queueDefObj = loadingTargetData["queue"][0];
                        delete queueDefObj["scheduler-mode"]["wfq-or-strict-priority"];
                        parsedTargetData["queue"] = this.extractDeviceProperties(portQosQueueConfig, queueDefObj, "queue");
                        break;
                    }
                case "ixrqos.PortQosForwardingClass":
                    {
                        let portQosFcConfig = portQosChildConfigs[childAttribute];
                        parsedTargetData["fc"] = this.extractDeviceProperties(portQosFcConfig, loadingTargetData["fc"][0], "fc");
                        break;
                    }
                case "ixrqos.PortQosWrrWeights":
                    {
                        let portQosWrrWeightsConfig = portQosChildConfigs[childAttribute];
                        parsedTargetData["wrr-weights"] = this.extractDeviceProperties(portQosWrrWeightsConfig, loadingTargetData["wrr-weights"][0], "wrr-weights");
                        break;
                    }
            }
        }
        let finalTargetData = {};
        finalTargetData[initialPropertyName] = parsedTargetData;
        logger.info(LOG_PREFIX + "Intent data after updating from NFMP: \n" + JSON.stringify(finalTargetData));
        return finalTargetData;
    }

    this.extractNonChildProperties = function (parsedTargetData, deviceConfig) {
        let portQosMapping = modelDeviceMapping.getMapping("port-qos");
        parsedTargetData["packet-byte-offset"] = null;
        delete parsedTargetData["fc"];
        delete parsedTargetData["wrr-weights"];
        delete parsedTargetData["queue"];
        this.traverseAndUpdateConfig("port-qos", parsedTargetData, deviceConfig, portQosMapping);
        logger.info(LOG_PREFIX + "Updated non child properties - " + JSON.stringify(parsedTargetData));
    }

    this.extractDeviceProperties = function (configData, defaultDataObj, keyPrefix) {
        let configDataArray = [];
        let mappings = modelDeviceMapping.getMapping(keyPrefix);
        if (!Array.isArray(configData)) {
            configData = [configData];
        }
        for (let idx in configData) {
            let configDataObj = configData[idx];
            let defData = JSON.parse(JSON.stringify(defaultDataObj));
            this.traverseAndUpdateConfig(keyPrefix, defData, configDataObj, mappings);
            configDataArray.push(defData);
        }
        logger.info(LOG_PREFIX + "parsedTargetData for: " + keyPrefix + ": " + JSON.stringify(configDataArray));
        return configDataArray;
    }

    this.traverseAndUpdateConfig = function (objKey, defDataObj, deviceConfig, mappings) {
        let keys = Object.keys(defDataObj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = defDataObj[key];
            let mappedKey = objKey + "." + key;
            if (value != null && typeof value === "object") {
                this.traverseAndUpdateConfig(mappedKey, value, deviceConfig, mappings)
            }
            else {
                let nfmpKey = mappings[mappedKey];
                if (mappedKey !== "port-qos.packet-byte-offset") {
                    defDataObj[key] = deviceConfig[nfmpKey];
                }
                else {
                    if (parseInt(deviceConfig[nfmpKey]) < 0) {
                        defDataObj["packet-byte-offset"] = {};
                        defDataObj["packet-byte-offset"]["subtract"] = -(String(deviceConfig[nfmpKey]));
                    }
                    else {
                        defDataObj["packet-byte-offset"] = {};
                        defDataObj["packet-byte-offset"]["add"] = String(deviceConfig[nfmpKey]);
                    }
                }
            }
        }
        return defDataObj;
    }
}