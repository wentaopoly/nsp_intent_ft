function NfmpSuggest() {

    this.getPostPolicerMappingPolicyName = function (neId) {
        var className = "postpolicermapping.PostPolicerMappingPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]

                }

            },

            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            } 
          };

        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }
    this.queueGroupQueueId = function (neId, name) {
        var className = "qgroup.EgressQueue";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "isLocal",
                            "value": "true"
                        },
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "containingPolicyDisplayedName",
                            "value": name
                        }
                    ],

                }
            },

            "resultFilter":

                { "children": "", "attribute": ["id"] }
        };

        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "id");
        return ret

    }
    this.getHsAttachmentPolicyName = function (neId) {
        var className = "hsqos.HsAttachmentPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]

                }

            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }

        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }
    this.getHsmdaWrrPolicyName = function (neId) {
        var className = "portscheduler.HsmdaWrrPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "isLocal",
                            "value": "true"
                        },
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }

        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret

    }
    this.getIpPrefixListName = function (neId) {
        var className = "qosprefixlist.PrefixList";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "prefixListType",
                            "value": "ipv4"
                        },
                        {
                            "name": "isLocal",
                            "value": "true"
                        },
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]

                }

            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }

        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }
    this.getIpv6PrefixListName = function (neId) {
        var className = "qosprefixlist.PrefixList";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "prefixListType",
                            "value": "ipv6"
                        },
                        {
                            "name": "isLocal",
                            "value": "true"
                        },
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }

        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }
    this.getHsmdaSlopePolicyName = function (neId) {
        var className = "slope.HsmdaSlopePolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "isLocal",
                            "value": "true"
                        },
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }

        };

        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }
    this.getParentArbiterName = function (neId) {
        var className = "policing.PolicerControlArbiter";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "isLocal",
                            "value": "true"
                        },
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }

        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "displayedName");
    }
    this.getSchedulerName = function (neId) {
        var className = "vs.Entry";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "isLocal",
                            "value": "true"
                        },
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }

        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "displayedName");
    }
    this.getSlopePolicyName = function (neId) {
        var className = "slope.Policy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "isLocal",
                            "value": "true"
                        },
                        {
                            "name": "siteId",
                            "value": neId

                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }

        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }
    this.getSlopePolicerId = function (neId) {
        var className = "slope.Policy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "isLocal",
                            "value": "true"
                        },
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }

        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "displayedName");
    }
    this.getQueueGroupTemplatePolicyName = function (neId) {
        var className = "qgroup.EgressQGroupPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "isLocal",
                            "value": "true"
                        },
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ],
                    "notEqual": [

                        {
                            "name": "displayedName",
                            "value": "_tmnx_nat_egr_q_grp"
                        },
                        {
                            "name": "displayedName",
                            "value": "_tmnx_lns_esm_egr_q_grp"
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }

        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "displayedName");
    }
    this.getPolicyId = function (neId, policyName) {
        var className = "aengr.Policy";
        let equalFilter = [
                            {
                              "name": "siteId",
                              "value": neId
                            }
                          ];
        if(policyName)
        {
            let policyNameFilter = {
                                     "name": "policyName",
                                     "value": policyName
                                   };
            equalFilter.push(policyNameFilter);
        }
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": equalFilter
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }

        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "id");
    }
    this.getPolicyName = function (neId, policyId) {
            var className = "aengr.Policy";
            let equalFilter = [
                                {
                                  "name": "siteId",
                                  "value": neId
                                }
                              ];
            if(policyId)
            {
                let policyIdFilter = {
                                         "name": "id",
                                         "value": policyId
                                       };
                equalFilter.push(policyIdFilter);
            }
            var searchObject = {
                "fullClassName": className,
                "filter": {
                    "and": {
                        "equal": equalFilter
                    }
                },
                "resultFilter": {
                    "children": "",
                    "attribute": [
                        "policyName"
                    ]
                }

            };
            logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
            return this.getData(searchObject, className, "policyName");
        }
    this.getQueueId = function (neId, policyId) {

        var className = "aengr.Queue";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "containingPolicyId",
                            "value": policyId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                 "attribute": [
                    "id"
                ]
            }

        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "id");

    }
    this.getPolicerId = function (neId, policyId) {

        var className = "aengr.Policer";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },

                        {
                            "name": "containingPolicyId",
                            "value": policyId
                        }
                    ]

                }
            },

            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
                
            }

        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "id");
    }
    this.getAdvancedConfigPolicyName = function (neId) {

        var className = "vs.AdvancedConfigPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "isLocal",
                            "value": "true"
                        },
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }

        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }
    this.getData = function (searchObjectJson, className, type) {

        var nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);

        logger.info("finalResponse = {}", JSON.stringify(finalResponse));
        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}", className, JSON.stringify(finalResponse));

        if (finalResponse !== undefined) {

            if (!Array.isArray(finalResponse)) { finalResponse = [finalResponse]; }
            if (Object.keys(finalResponse).length !== 0) {

                finalResponse.forEach(function (value, index, array) {
                    ret.push(value[type]);
                })
            }
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }
}