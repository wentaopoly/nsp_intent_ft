function CpmTopology() {

    var savedTopologyCpmFilter = {};
    var savedTopologyCpmQueue = {};

    this.setSavedTopologyCpmFilter = function (cpmFilter) {
        this.savedTopologyCpmFilter = cpmFilter;
    }

    this.getSavedTopologyCpmFilter = function () {

        if(this.savedTopologyCpmFilter == undefined){
            this.savedTopologyCpmFilter = topologyFactory.createServiceTopology();
        }

        return this.savedTopologyCpmFilter;
    }

    this.setSavedTopologyCpmQueue = function (cpmQueue) {
        this.savedTopologyCpmQueue = cpmQueue;
    }

    this.getSavedTopologyCpmQueue = function () {

        if(this.savedTopologyCpmQueue == undefined){
            this.savedTopologyCpmQueue = topologyFactory.createServiceTopology();
        }

        return this.savedTopologyCpmQueue;
    }
}