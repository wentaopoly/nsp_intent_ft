load({ script: resourceProvider.getResource("util-fwk.js"), name: "UtilFwk" });

function CustomHooks() {
    /**
   * PreAudit Hook
   */
  const preAudit = (inputObj) => {
     /**
     * Write your custom preAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer, 
     *          uniqueIdentifier, deviceYangModuleName
     *           
     */
    
    logger.info("[CUSTOM-HOOKS] preAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
    let communityConfig = inputObj.intentConfig;

      for (let key in communityConfig) {
        if (communityConfig[key] && communityConfig[key].constructor === Object && Object.keys(communityConfig[key]).length === 0) {
          delete communityConfig[key];
        }
        else if(key == "expression")
        {
            if(communityConfig[key]["exact"] == false && (communityConfig[key]["expr"] == "" || communityConfig[key]["expr"] == undefined))
            {
                delete communityConfig[key];
            }
        }
        if(key == "member") {
              var member = communityConfig["member"];
            
              member.forEach(item => {
                item.member = utilFwk.convertIPv6ToLowercaseIfValid(item.member);
              });
        }
      }
    // Update the "config" field in the original JSON object
    inputObj.intentConfig = communityConfig;
  }

  /**
   * PostAudit Hook
   */
  const postAudit = (inputObj) => {
    /**
     * Write your custom postAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer, 
     *          uniqueIdentifier, deviceYangModuleName, auditReport
     *           
     */

    logger.info("[CUSTOM-HOOKS] postAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

    
  };

  /**
   * PreSync Hook
   */
  const preSync = (inputObj) => {
    /**
     * Write your custom preSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] preSync call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
    let configArray = JSON.parse(inputObj.config);

    configArray.forEach(configItem => {
          let communityConfig = configItem[inputObj["intentTypeName"]+":"+inputObj["intentTypeName"]].community;

          for (let key in communityConfig) {
            if (communityConfig[key] && communityConfig[key].constructor === Object && Object.keys(communityConfig[key]).length === 0) {
              delete communityConfig[key];
            }
            else if(key == "expression")
            {
                if(communityConfig[key]["exact"] == false && (communityConfig[key]["expr"] == "" || communityConfig[key]["expr"] == undefined))
                {
                    delete communityConfig[key];
                }
            }
          }
        });
    
        // Update the "config" field in the original JSON object
        inputObj.config = JSON.stringify(configArray);
    
        logger.info("[CUSTOM-HOOKS] updated inputObj "+ JSON.stringify(inputObj));
  };  

  /**
   * PostSync Hook
   */
  const postSync = (inputObj) => {
    /**
     * Write your custom postSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] postSync call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
    
  };

  /**
   * 
   * PostDiscovery Hook
   */
  const postDiscovery = (inputObj) => {
    /**
     * Write your custom postDiscovery logic here
     * inputObj by default contains the following keys:
     *        deviceConfig, intentContainer, neId,
     *        targetDataStruct, templateName, deviceYangModuleName
     */

    logger.info("[CUSTOM-HOOKS] postDiscovery call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
  }

  this.preAudit = preAudit;
  this.postAudit = postAudit;
  this.preSync = preSync;
  this.postSync = postSync;
  this.postDiscovery = postDiscovery;

}