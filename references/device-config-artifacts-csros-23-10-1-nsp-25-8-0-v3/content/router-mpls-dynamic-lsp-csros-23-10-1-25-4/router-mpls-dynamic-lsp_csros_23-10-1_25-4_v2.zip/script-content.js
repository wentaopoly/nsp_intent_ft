var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
const icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
const gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('nsp-restconf-fwk.js'), name: 'nsp-restconf-fwk'});
var nspRestconfFwk = new NspRestconfFwk();

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})

let intentTypeName = "router-mpls-dynamic-lsp_csros_23-10-1_25-4";

// example port, sap-ingress etc..
let initialPropertyName = "mpls-DynamicLsp";


// unique identifier
let uniqueIdentifier = "sourceNodeId,displayedName";


/**
 * This function is starting point by IM for sync operation
 * @param input
 * @returns {*}
 */
function synchronize(input) {
    logger.info("-------------------- script-content.js -> synchronize() --------------------");
    logger.info("Intent Synchronisation started - input = {}", input)
    return NspIntentHelper.synchronize(input, intentTypeName, initialPropertyName, uniqueIdentifier);
}

/**
 * The function is starting point for audit operation in IM
 * @param input
 * @returns {*}
 */
function audit(input) {
    logger.info("-------------------- script-content.js -> audit() --------------------");
    logger.info("Intent Audit started - input = {}", input)
    return NspIntentHelper.audit(input, intentTypeName, initialPropertyName, uniqueIdentifier)
}

/**
 * This function returns NE-ID
 *
 * @param context
 * @returns {string}
 */
function getNeId(context) {
    logger.info("-------------------- script-content.js -> getNeId() --------------------");
    let neId;
    let target = context.getInputValues()["target"]["objectidentifier"];
    logger.info("target = {}", target)
    if (target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    logger.info("NeId : " + neId);
    return neId;
}

/**
 * The function is used in Brownfield discovery by ICM Framework
 * It discover's the configuration from the target device
 * and manipulate as per Template's default-target-data
 *
 * @see ICMFwk for more details
 * @param {*} input - the config data of a deployment
 * @returns result - the result of the operation
 */
function getTargetData(input) {
    logger.info("-------------------- script-content.js -> getTargetData() --------------------");
    logger.info("getTargetData input for brownfield = \n" + input);
    let target = input.target;
    let config = null;
    logger.info("target=" + target);
    let deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info("deviceConfig = {} ", JSON.stringify(deviceConfig));
    let data = gtdFwk.gtdSend(deviceConfig);
    logger.info("data = {}", JSON.stringify(data));
    logger.info("returning result = {}", JSON.stringify(data.msg.result));
    return data.msg.result;
}

function suggestLspName(context) {
    logger.info("suggestLspName ==> context = {}", context);
    return new NfmpSuggest().getLspName(getNeId(context));
}

function suggestEgrAccountingPolicy(context) {
    logger.info("suggestEgrAccountingPolicy ==> context = {}", context);
    return new NfmpSuggest().getEgrAccountingPolicy(getNeId(context));
}

function suggestBfdTemplate(context) {
    logger.info("suggestBfdTemplate ==> context = {}", context);
    return new NfmpSuggest().getBfdTemplate(getNeId(context));
}

function suggestPolicyName(context) {
    logger.info("suggestPolicyName ==> context = {}", context);
    return new NfmpSuggest().getPolicyName(getNeId(context));
}

function suggestResourceId(context) {
    logger.info("suggestResourceId ==> context = {}", context);
    const argsData = context.getInputValues()["arguments"];
    return new NfmpSuggest().getResourceId(getNeId(context), argsData);
}

function suggestInterfaceAddr(context) {
    logger.info("suggestInterfaceAddr ==> context = {}", context);
    var endPointInterfaceTarget = context.getInputValues()["arguments"]["__attribute"];
    var endpointSiteId;
    if (endPointInterfaceTarget == "mpls-DynamicLsp.sourceIpAddress")
    {
        endpointSiteId = getNeId(context);
    }
    else if (endPointInterfaceTarget == "mpls-DynamicLsp.destinationIpAddress")
    {
        endpointSiteId = context.getInputValues()["arguments"]["mpls-DynamicLsp"]["destinationNodeId"];
    }
    if (endpointSiteId)
    {
        return nspRestconfFwk.getNeInterfaceAddress(endpointSiteId);
    }
}

function suggestDestinationNodeId(context) {
    logger.info("suggestDestinationNodeId ==> context = {}", context);
    return new NfmpSuggest().getManagedNodeIds().filter(item => item !== getNeId(context));
}

function suggestAssociationName(context) {
    logger.info("suggestAssociationName ==> context = {}", context);
    let associationType = context.getInputValues()["arguments"]["associationType"];
    return new NfmpSuggest().getAssociationName(getNeId(context),associationType);
}

function suggestTagName(context) {
    logger.info("suggestTagName ==> context = {}", context);
    return new NfmpSuggest().getTagName(getNeId(context));
}

function suggestAdminGroups(context) {
    logger.info("suggestAdminGroups ==> context = {}", context);
    function getValueByPath(obj, path) {
        const keys = path.split(".");
        let current = obj;
        for (const key of keys) {
            if (current && typeof current === "object" && key in current) {
            current = current[key];
            } else {
            return undefined;
            }
        }
        return current;
    }
    let arg = context.getInputValues()["arguments"];
    let attributePath = arg["__attribute"];
    let extractedData = getValueByPath(arg, attributePath);
    let suggestedData = new NfmpSuggest().getAdminGroups(getNeId(context));

    if(extractedData!==undefined){
        for (let i = 0; i < extractedData.length; i++) {
            let index = suggestedData.indexOf(extractedData[i]);
            if (index !== -1) {
                suggestedData.splice(index, 1);
            }
        }
    }

    return suggestedData;
}

function suggestNetwData(context) {
    logger.info("suggestNetwData ==> context = {}", context);
    try
    {
        var neId = getNeId(context);
        ret = nspRestconfFwk.getNe(neId);
    }
    catch (e)
    {
        logger.error(" " + e.message);
    }
    return ret;
}
