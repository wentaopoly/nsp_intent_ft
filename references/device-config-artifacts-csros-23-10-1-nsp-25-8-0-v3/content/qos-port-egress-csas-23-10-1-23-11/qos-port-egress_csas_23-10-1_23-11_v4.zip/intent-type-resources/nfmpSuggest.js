load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {
    this.getPolicyName = function (neId) {
        var searchObject = {
            "fullClassName": "sasqos.PortAccessEgress",
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "attribute": [
                    "displayedName"
                ]
            }
        };

        return this.getData(searchObject, "displayedName")
    }

    this.getPolicyId= function (neId, policyName) {
        var className = "sasqos.PortAccessEgress";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName",
                    "id"
                ]
            }
        };
        return this.getData(neId, searchObject, "id");
    }

    this.getSupportAttributePolicyDetails = function (neId, className, ipPrec) {
        var searchObject = {
            "fullClassName": "",
            "filter": {
                "and": {
                    "equal":
                        [
                            {
                                "name": "isLocal",
                                "value": 0
                            },
                            {
                                "name": "isBackup",
                                "value": 0
                            }
                        ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id",
                    "displayedName"
                ]
            }
        };
        switch (className) {
            case "sasqos.Remark":
                searchObject["fullClassName"] = className;
                return this.getGlobalData(neId, searchObject, className, false, "id");
            case "sasqos.QueueMgmtPolicy":
                searchObject["fullClassName"] = className;
                return this.getGlobalData(neId, searchObject, className, false, "displayedName");
            default:
                logger.info(LOG_PREFIX + "Unknown class name : " + className);
        }
    }

    this.getGlobalData = function (target, searchObjectJson, className, ipPrec, type) {
        let nfmpFwk = new NfmpFwk();
        var result = [];
        var resultFetch = nfmpFwk.find(target, searchObjectJson);
        logger.info(LOG_PREFIX + resultFetch.response);
        var finalResponse = JSON.parse(resultFetch.response)[className];
        logger.info(LOG_PREFIX + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                if (ipPrec) {
                    if (finalResponse[index]["ipPrecClassification"] === "true") {
                        result.push(finalResponse[index][type]);
                    }
                }
                else {
                    result.push(finalResponse[index][type]);
                }
            }
        }
        result = result.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "NFMP Global Data suggest result = \n" + JSON.stringify(result));
        return result;
    }

    this.getData = function (target, searchObjectJson, type) {
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.find(target, searchObjectJson);
        logger.info(LOG_PREFIX + resultFetch.response);
        var finalResponse = JSON.parse(resultFetch.response)["sasqos.PortAccessEgress"];
        logger.info(LOG_PREFIX + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                ret.push(finalResponse[index][type]);
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "result = \n" + JSON.stringify(ret));
        return ret;
    }
}
