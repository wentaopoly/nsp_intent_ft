function MdSuggest() {
    this.getAccountingPolicyId = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/log/accounting-policy";
        return this.getData(neId, url, "policy-id");
    }

    this.getData = function (neId, url, type, policyId) {
        var mdcFwk = new MdcFwk();
        logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info("MDC resultFetch =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"]["nokia-conf:accounting-policy"];
        logger.info("finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse))
        {
            for (var index in finalResponse)
            {
                ret.push(finalResponse[index][type]);
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info("ret = \n" + JSON.stringify(ret));
        return ret;
    }
}
