load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {
    this.getSdps = function () {
        var searchObjectJson = {
            "fullClassName": "svt.Tunnel",
            "filter": {
                "filterExpression": "supportsNge=1"
            },
            "resultFilter": {
                "attributes": [
                    "sourceNodeId",
                    "destinationNodeId",
                    "pathId",
                    "objectFullName"
                ],
                "childrenFilters": []
            }
        };

        let nfmpFwk = new NfmpFwk();
        var result = {};
        var resultFetch = nfmpFwk.post("/search", searchObjectJson);
        var ret = JSON.parse(resultFetch.response);
        logger.info("***************finalResponse START******************");
        logger.info(JSON.stringify(ret));
        logger.info("***************finalResponse END******************");
        if (ret)
        {
            var data = ret.map(function (tunnel) {
                var obj = {};
                obj["path-id"] = tunnel["properties"]["pathId"];
                obj["source-id"] = tunnel["properties"]["sourceNodeId"];
                obj["destination-id"] = tunnel["properties"]["destinationNodeId"];
                obj["name"] = tunnel["properties"]["objectFullName"];
                return obj;
            });
            result["data"] = JSON.stringify(data);
        }
        logger.info("result = {}", JSON.stringify(result));
        return result
    }
    this.getkeyGroupId = function () {
        var searchObjectJson = {
            "fullClassName": "nge.KeyGroup",
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": "0.0.0.0"
                }
            },
            "resultFilter": {
                "children": {},
                "attribute": [
                    "id"
                ]
            }
        };
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        finalResponse = finalResponse["nge.KeyGroup"];
        logger.info(JSON.stringify(finalResponse));

        if (Object.keys(finalResponse).length !== 0)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            finalResponse.forEach(function (value, index, array) {
                ret.push(value["id"]);
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }
}