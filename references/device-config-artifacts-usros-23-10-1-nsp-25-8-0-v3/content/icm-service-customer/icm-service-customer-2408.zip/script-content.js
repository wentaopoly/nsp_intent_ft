var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
  "ibn" : "http://www.nokia.com/management-solutions/ibn",
  "nc" : "urn:ietf:params:xml:ns:netconf:base:1.0",
  "device-manager" : "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
  "http://www.nokia.com/management-solutions/anv-device-holders" : "anv-device-holders"
};


load({script:resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
var mdtFwk = new MdtFwk();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource('nsp-restconf-fwk.js'), name: 'nsp-restconf-fwk'});
var nspRestconfFwk = new NspRestconfFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();
load({script: resourceProvider.getResource('nspSuggest.js'), name: 'NspSuggest'})

var intentTypeName = 'icm-service-customer';
var LOG_PREFIX = "[Service Customer]: "
// example port, sap-ingress etc..
var initialPropertyName = 'customer';


// unique identifier
var uniqueIdentifier = 'customer-name';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/service';
var topologyMap = {};

function synchronize(input) {
  logger.info(LOG_PREFIX + 'Intent Synchronisation started')

  return NspIntentHelper.synchronize(input,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier,topologyMap);
}

function onAudit(target, config, svcTopo, adminState) {
  logger.info(LOG_PREFIX + 'Intent Audit started')

  return NspIntentHelper.audit(target, config, svcTopo, adminState,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier);
}

function getTargetData(input) {
  logger.info(LOG_PREFIX + "getTargetData input for brownfield = \n" + input);
  var target = input.target;
  var config = null;
  logger.info(LOG_PREFIX + "target = " + target);
  logger.info(LOG_PREFIX + "initialPropertyName = "+ initialPropertyName)
  var deviceConfig = icmFwk.getDeviceConfiguration(target,initialPropertyName);
  logger.info(LOG_PREFIX + "Device Config = "+JSON.stringify(deviceConfig));
  var data = gtdFwk.gtdSend(deviceConfig);
  return data.msg.result;
}

function suggestSites(context) {
  logger.info("suggestSites context = \n" + context);
  return new NspSuggest().getSites();
}

function suggestCustomerName(context) {
  logger.info("suggestCustomerName context = \n" + context);
  var customerId = context.getInputValues()["arguments"]["target_customer-id"];
  logger.info("User  selected Customer ID : {}, searching Customer Name associated to Customer-id - {}", customerId, customerId);
  return new NspSuggest().getCustomerName(customerId);
}

function suggestCustomerId(context) {
  logger.info("suggestCustomerId context = \n" + context);
  var customerName = context.getInputValues()["arguments"]["target_customer-name"];
  logger.info("User  selected Customer Name : {}, searching Customer ID associated to Customer Name - {}", customerName, customerName);
  return new NspSuggest().getCustomerId(customerName);
}
