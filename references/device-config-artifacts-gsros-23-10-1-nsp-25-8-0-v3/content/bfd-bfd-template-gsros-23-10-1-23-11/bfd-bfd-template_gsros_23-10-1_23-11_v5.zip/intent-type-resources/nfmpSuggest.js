load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {

    this.getBfdTemplateName = function (neId) {
        var className = "mplstp.BFDTemplate";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", searchObject);
        return this.getData(neId, searchObject, "displayedName");
    }

    this.getData = function (target, searchObjectJson, type, policyAttribute) {
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.find(target, searchObjectJson);
        logger.info(LOG_PREFIX + resultFetch.response);
        var finalResponse = JSON.parse(resultFetch.response)["mplstp.BFDTemplate"];
        logger.info(LOG_PREFIX + "finalResponse = " + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                ret.push(finalResponse[index][type]);
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "NFMP suggest result = \n" + JSON.stringify(ret));
        return ret;
    }
}