function NfmpDiscoveryHelper() {
    this.getDeviceConfiguration = function (neId, portId, initialPropertyName) {
        return {};
    }
}
