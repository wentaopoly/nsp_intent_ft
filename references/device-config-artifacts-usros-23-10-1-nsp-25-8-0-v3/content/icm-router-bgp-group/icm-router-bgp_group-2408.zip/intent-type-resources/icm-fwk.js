load({
    script: resourceProvider.getResource('mediator-fwk.js'),
    name: 'mediator-fwk'
});
nfmpFwk = new MediatorFramework("NFMP");

load({
    script: resourceProvider.getResource('nsp-restconf-fwk.js'),
    name: 'nsp-restconf-fwk'
});
nspRestconfFwk = new NspRestconfFwk();

load({
    script: resourceProvider.getResource("model-device-mapping.js"),
    name: "model-device-mapping"
});
modelDeviceMapping = new ModelDeviceMapping();


load({
    script: resourceProvider.getResource("discovery-helper-nfmp.js"),
    name: "discovery-helper-nfmp"
});
load({
    script: resourceProvider.getResource("discovery-helper-mdc.js"),
    name: "discovery-helper-mdc"
});
load({
    script: resourceProvider.getResource('mdt-fwk.js'),
    name: 'MdtFwk'
});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function ICMFwk() {

    var mdtFwk = new MdtFwk();
    var parseTarget = new ParseTarget();
    var mdcDiscoveryHelper = null;

    // get the device configuration
    this.getDeviceConfiguration = function (targetWithTemplate, deviceYangModuleName, parentXpath, initialPropertyName) {
        logger.info("ICMFwk::getDeviceConfiguration")
        return this.getTargetData(targetWithTemplate, deviceYangModuleName, parentXpath, initialPropertyName);
    }

    this.getTemplate = function (templateName) {
        logger.info("ICMFwk::getTemplate::templateName = " + templateName)
        return nspRestconfFwk.getByXpath("/nsp-icm:icm/templates/template=" + templateName);
    }

    this.getDefaultTargetData = function (templateName) {
        var templateObj = nspRestconfFwk.getByXpath("/nsp-icm:icm/templates/template=" + templateName);
        var defaultTargetData = templateObj['nsp-icm:template'][0]['target-data-struct']
        logger.info("\nICMFwk::getDefaultTargetData\n" + defaultTargetData)
        return defaultTargetData;
    }

    this.getModifiedDeviceConfig = function (templateName, discoveryHelper, deviceConfig, initialPropertyName) {
        // if it is MDCDiscoveryHelper, modify the deviceConfig else dont do anything
        var targetData = deviceConfig;
        if (discoveryHelper instanceof MdcDiscoveryHelper)
        {
            targetData[initialPropertyName] = deviceConfig;
            // delete target-identifiers from deviceConfig
            var targetIdentifiers = this.getTemplate(templateName)['nsp-icm:template'][0]['target-identifiers'];
            for (var i = 0; i < targetIdentifiers.length; i++)
            {
                var name = targetIdentifiers[i].name;
                delete targetData[initialPropertyName][name];
            }
        }
        return targetData;
    }

    this.getTargetData = function (targetWithTemplate, deviceYangModuleName, parentXpath, initialPropertyName) {
        var targetAr = targetWithTemplate.split("#");
        var templateName = targetAr[0];
        var neId = parseTarget.getNeIdFromTarget(targetWithTemplate);

        var defaultTargetData = this.getDefaultTargetData(templateName);
        var deviceConfig = this.getConfigurations(targetWithTemplate, deviceYangModuleName, parentXpath, initialPropertyName);
        if (typeof deviceConfig === 'string' && deviceConfig.indexOf('Failed to fetch service') > -1)
        {
            logger.error(deviceConfig);
            return deviceConfig;
        }
        return this.extractDeviceConfig(templateName, neId, defaultTargetData, deviceConfig, deviceYangModuleName, parentXpath, initialPropertyName);
    }

    this.getConfigurations = function (targetWithTemplate, deviceYangModuleName, parentXpath, initialPropertyName) {
        var neId = parseTarget.getNeIdFromTarget(targetWithTemplate);
        var discoveryHelper = this.getDiscoveryHelper(neId);
        return discoveryHelper.getDeviceConfiguration(targetWithTemplate, deviceYangModuleName, parentXpath, initialPropertyName);

    }

    this.getDiscoveryHelper = function (neId) {

        var managerName = mdtFwk.getManagerName(neId);
        logger.info('Device: ' + neId + ' is managed by: ' + managerName);

        switch (managerName)
        {
            case 'NFM-P':
                logger.info('Device is managed by NFMP')
                return this.createNfmpDiscoveryHelper()
                break;
            case 'MDC':
                logger.info('Device is managed by MDM')
                return this.createMdcDiscoveryHelper()
                break;
            default:
                logger.info('Device is not managed')
                throw new RuntimeException('Device is not Managed')
        }

        return ''
    }

    this.createNfmpDiscoveryHelper = function () {
        return new NfmpDiscoveryHelper();
    }

    this.createMdcDiscoveryHelper = function () {
        if (mdcDiscoveryHelper == null)
        {
            mdcDiscoveryHelper = new MdcDiscoveryHelper();
        }
        return mdcDiscoveryHelper;
    }

    this.extractDeviceConfig = function (templateName, neId, defaultTargetData, deviceConfig, deviceYangModuleName, parentXpath, initialPropertyName) {
        var discoveryHelper = this.getDiscoveryHelper(neId);
        deviceConfig = this.getModifiedDeviceConfig(templateName, discoveryHelper, deviceConfig, initialPropertyName);
        return discoveryHelper.extractDeviceConfig(defaultTargetData, deviceConfig, deviceYangModuleName, parentXpath, initialPropertyName);
    }
}
