load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }

    this.updatePointer = function(egressRemarkPolicy, pointerKey, mapExtension) {

        if (egressRemarkPolicy[pointerKey]) {
            egressRemarkPolicy[pointerKey] = mapExtension + egressRemarkPolicy[pointerKey];
        } else {
            egressRemarkPolicy[pointerKey] = "";
        }
        return egressRemarkPolicy;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        let util = new utilities();

        if (payload && payload.configInfo && payload.configInfo["ixrqos.EgressRemarkPolicy"]) {
            let egressRemarkPolicy = payload.configInfo["ixrqos.EgressRemarkPolicy"];
            if (egressRemarkPolicy["children-Set"] && egressRemarkPolicy["children-Set"]["ixrqos.EgressRemarkForwardingClass"]) {

                egressRemarkPolicy["children-Set"]["ixrqos.EgressRemarkForwardingClass"].forEach((classItem) => {
                    var prefix = "lspExp_";
                    if (classItem.lspExpExceedProf !== "default") {
                        classItem["lspExpExceedProf"] = prefix + classItem.lspExpExceedProf.split("_")[1];
                    }

                    if (classItem.lspExpInPlusProf !== "default") {
                        classItem["lspExpInPlusProf"] = prefix + classItem.lspExpInPlusProf.split("_")[1];
                    }
                });
            }
            
        let neFamily = util.getNeFamilyRelease(neId);
        let neType = util.getNeType(neFamily);
        let neVersion = util.getNeVersion(neFamily);
        let neChassisType = util.getChassisType(neFamily);
        let unsupportedAttribute = [];
        let unsupportedAttributeJsonFile = resourceProvider.getResource("unsupported-attributes.json");
        unsupportedAttributeJsonFile = JSON.parse(unsupportedAttributeJsonFile);
            for (let key in unsupportedAttributeJsonFile) {
                if (key == neType) {
                    let nodeObj = unsupportedAttributeJsonFile[key];
                    let chassisType = nodeObj[1]["chassis-types"];
                    if (chassisType.indexOf(neChassisType) !== -1) {

                        egressRemarkPolicy = this.updatePointer(egressRemarkPolicy, "fcDot1pPointer", "FCDot1pMap7250SROS:");
                        egressRemarkPolicy = this.updatePointer(egressRemarkPolicy, "fcDscpPointer", "FCDSCPMap7250SROS:");
                        egressRemarkPolicy = this.updatePointer(egressRemarkPolicy, "fcLspExpPointer", "FCLspExpMap7250SROS:");
                    }
                }
            }
        }
        return payload;
    }

   

    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {

        if (targetKey === "fcDot1pPointer" || targetKey === "fcDscpPointer" || targetKey === "fcLspExpPointer") {
            // Split the pointer string by ':''
            let splitByColon = targetValue.split(':').pop();
            targetValue = splitByColon;
        }
        if ((targetKey === "lspExpExceedProf" || targetKey === "lspExpInPlusProf") && targetValue !== "default") {
            // Split the string by '_''
            let prefix = "value_";
            let splitValue = targetValue.split('_').pop();
            targetValue = prefix + splitValue;

        }
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
}