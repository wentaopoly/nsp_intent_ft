function utilities() {
    this.setErrorResult = function (result) {
        result.setSuccess(false);
        result.setErrorCode(100);
        result.setErrorDetail("failed To set Topology.");
        return result
    }

    this.setSuccessResult = function (result,savedTopology) {
        result.setSuccess(true);
        if (savedTopology !== undefined){
            result.setTopology(savedTopology);
        }
        return result;
    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        return JSON.parse(json);
    }

    this.reportMisaligned = function (target, result, auditReport) {
        var report = JSON.parse(result.response);
        if (!report.aligned)
        {
            for (var i = 0; i < report.misalignedAttributes.length; i++)
            {
                var attributeData = report.misalignedAttributes[i];
                if (attributeData.expected == "present")
                {
                    //misaligned object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else if (attributeData.expected == "not present")
                {
                    //undesired object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                    auditReport.addMisAlignedAttribute(misalignedAttribute);
                }
            }
        }
        return auditReport
    }


    /*
    function: getBaseFdnForPort
    description: Construct the Fdn for Port and return it.
    */
    this.getBaseFdnForPort = function (target, portId) {
        if(portId.startsWith("esat"))
        {
            return this.getBaseFdnForSatelliteConnectorPort(target,portId);
        }
        var portIds = portId.split("/");
        var cardSlot;
        var xiomSlot;
        var mdaSlot;
        var connector;
        var portNumber

        portIds.forEach(function (item, index) {
            // logger.info("*********************item, index = " + item + "-----" + index);
            switch (index)
            {
                case 0:
                    cardSlot = item;
                    break;
                case 1:
                    //xiom
                    if (isNaN(item))
                    {
                        xiomSlot = item;
                    }
                    else
                    {
                        mdaSlot = item;
                    }
                    break;
                case 2:
                    //connector
                    if (isNaN(item))
                    {
                        connector = item;
                    }
                    else if(mdaSlot)
                    {
                        portNumber = item;
                    }
                    else
                    {
                        mdaSlot = item;
                    }
                    break;
                case 3:
                    //connector
                    if (isNaN(item))
                    {
                        connector = item;
                    }
                    else
                    {
                        portNumber = item;
                    }
                    break;
                case 4:
                    portNumber = item;
                    break;


            }
        });

        // logger.info("************ cardSlot =" + cardSlot + ",xiomSlot=" + xiomSlot + ",mdaSlot=" + mdaSlot + ",connector=" + connector + ",portNumber=" + portNumber);
        //"network:92.168.96.22:shelf-1:cardSlot-1:card:xioSlot-1:xiomCard:daughterCardSlot-1:daughterCard:conn-1:port-1"

        var portDn = "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card";
        if (xiomSlot)
        {
            portDn += ":xioSlot-" + xiomSlot.substring(1) + ":xiomCard";
        }
        if (mdaSlot)
        {
            portDn += ":daughterCardSlot-" + mdaSlot + ":daughterCard";
        }
        if (connector)
        {
            portDn += ":conn-" + connector.substring(1);
        }
        if (portNumber)
        {
            portDn += ":port-" + portNumber;
        }
        if (target && String(target).indexOf(':') !== -1) {
            portDn = this.modifyNeIdForIpV6(portDn, target);
        }
        logger.info("*********************portDn = " + portDn);
        return portDn;
        //return "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card:daughterCardSlot-" + mdaSlot + ":daughterCard:port-" + portNumber;
    }

    this.getBaseFdnForSatelliteConnectorPort = function (target, portId) {

        var portIds = (portId.split("-")[1]).split("/");
        var shelf = "shelf-1-5-";
        shelf += portIds[0];
        var satId =portIds[0];
        var cardSlot = "cardSlot-1:card" ;
        var mdaSlot = "daughterCardSlot-1:daughterCard";
        var portNumber = portIds[2];
        var connPortNumber = portNumber.substring(1);
        //logger.info("******satellite port = shelf = "+shelf+", portnumber = "+portNumber +"\n portid = "+ portId+"\n portids = "+ portIds);
        var portDn = "network:" + target + ":"+shelf+":" + cardSlot +":" +mdaSlot+":conn-"+connPortNumber ;
        if (target && String(target).indexOf(':') !== -1) {
            portDn = this.modifyNeIdForIpV6(portDn, target);
        }
        logger.info("SatConnPortDN = "+portDn);
        return portDn;
    }

    this.editPayload = function(fdn,properties,fullClassName,objectFullName){
        var payload  = {};
        var configInfo = {};
        configInfo["containedClassProperties"] = properties;
        configInfo["objectClassName"] = fullClassName;
        // payload["fdn"] = fdn;
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName,
            payload["configInfo"] = configInfo;
        return payload;

    }

    this.transformNfmpBreakoutType = function(intentBreakoutType){
        var nfmpBreakoutType="";
        switch(intentBreakoutType){
            case 'none':nfmpBreakoutType="none";
                break;
            case 'c1-40g':nfmpBreakoutType="c1_40g";
                break;
            case 'c4-10g':nfmpBreakoutType="c4_10g";
                break;
            case 'c1-100g':nfmpBreakoutType="c1_100g";
                break;
            case 'c4-25g':nfmpBreakoutType="c4_25g";
                break;
            case 'c10-10g':nfmpBreakoutType="c10_10g";
                break;
            case 'c1-100g-flext':nfmpBreakoutType="c1_100g_flext";
                break;
            case 'c1-400g':nfmpBreakoutType="c1_400g";
                break;
            case 'c2-100g':nfmpBreakoutType="c2_100g";
                break;
            case 'c4-100g':nfmpBreakoutType="c4_100g";
                break;
            case 'c1-10g':nfmpBreakoutType="c1_10g";
                break;
            case 'c1-1000g':nfmpBreakoutType="c1_1000g";
                break;
            case 'c1-25g':nfmpBreakoutType="c1_25g";
                break;
            case 'c1-50g':nfmpBreakoutType="c1_50g";
                break;
            case 'c8-50g':nfmpBreakoutType="c8_50g";
                break;
            case 'c1-800g':nfmpBreakoutType="c1_800g";
                break;
            case 'c3-100g':nfmpBreakoutType="c3_100g";
                break;
            case 'c1-200g':nfmpBreakoutType="c1_200g";
                break;
            case 'c8-100g':nfmpBreakoutType="c8_100g";
                break;
            case 'c2-400g':nfmpBreakoutType="c2_400g";
                break;
            case 'c1-1g':nfmpBreakoutType="c1_1g";
                break;
            case 'c2-50g':nfmpBreakoutType="c2_50g";
                break;
        }
        return nfmpBreakoutType;
    }

    this.transformToIntentBreakout = function (deviceValue){
        var intentBreakout;
        switch (deviceValue) {
            case 'none':intentBreakout="none";
                break;
            case 'c1_40g':intentBreakout="c1-40g";
                break;
            case 'c4_10g':intentBreakout="c4-10g";
                break;
            case 'c1_100g':intentBreakout="c1-100g";
                break;
            case 'c4_25g':intentBreakout="c4-25g";
                break;
            case 'c10_10g':intentBreakout="c10-10g";
                break;
            case 'c1_100g_flext':intentBreakout="c1-100g-flext";
                break;
            case 'c1_400g':intentBreakout="c1-400g";
                break;
            case 'c2_100g':intentBreakout="c2-100g";
                break;
            case 'c4_100g':intentBreakout="c4-100g";
                break;
            case 'c1_10g':intentBreakout="c1-10g";
                break;
            case 'c1_1000g':intentBreakout="c1-1000g";
                break;
            case 'c1_25g':intentBreakout="c1-25g";
                break;
            case 'c1_50g':intentBreakout="c1-50g";
                break;
            case 'c8_50g':intentBreakout="c8-50g";
                break;
            case 'c1_800g':intentBreakout="c1-800g";
                break;
            case 'c3_100g':intentBreakout="c3-100g";
                break;
            case 'c1_200g':intentBreakout="c1-200g";
                break;
            case 'c8_100g':intentBreakout="c8-100g";
                break;
            case 'c2_400g':intentBreakout="c2-400g";
                break;
            case 'c1_1g':intentBreakout="c1-1g";
                break;
            case 'c2_50g':intentBreakout="c2-50g";
                break;
        }
        return intentBreakout;
    }


    this.transformToIntentAdminState = function (deviceValue){
        var intentAdmintState;
        if(deviceValue == "portInService"){
            intentAdmintState = "enable";
        }else{
            intentAdmintState = "disable";
        }
        return intentAdmintState;
    }

    this.transformNfmpRsFecMode = function(deviceValue) {
        var intentRsFecMode;
        if(deviceValue == "cl91-514-528") {
            intentRsFecMode = "cl91_514_528";
        }
        else if(deviceValue == "cl91-514-544") {
            intentRsFecMode = "cl91_514_544";
        }
        else {
            intentRsFecMode = "none";
        }
        return intentRsFecMode;
    }

    this.transformToIntentRsFecMode = function(deviceValue) {
        var nfmpRsFecMode;
        if(deviceValue == "cl91_514_528") {
            nfmpRsFecMode = "cl91-514-528";
        }
        else if(deviceValue == "cl91_514_544") {
            nfmpRsFecMode = "cl91-514-544";
        }
        else {
            nfmpRsFecMode = "none";
        }
        return nfmpRsFecMode;
    }

    this.modifyNeIdForIpV6 = function (objectFullName, neId) {
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }
}
