load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {
  this.setErrorResult = function (result) {
    result.setSuccess(false);
    result.setErrorCode(100);
    result.setErrorDetail("failed To set Topology.");
    return result
  }
  
  this.setSuccessResult = function (result,savedTopology) {
    result.setSuccess(true);
    if (savedTopology !== undefined){
      result.setTopology(savedTopology);
    }
    return result;
  }

  this.xml2object = function (xmlElement) {
    var lXml = Java.type("org.json.XML");
    var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
    var serializer = lsImpl.createLSSerializer();
    serializer.getDomConfig().setParameter("xml-declaration", false);
    var str = serializer.writeToString(xmlElement);
    var json = lXml.toJSONObject(str).toString();
    return JSON.parse(json);
  }

  this.extractInfo = function (topology, key,i) {
    var values;
    if (topology != null && topology.getXtraInfo() != null) {
        topology.getXtraInfo().forEach(function (extraInfo) {
            if (extraInfo.getKey() == key) {
                var value = extraInfo.getValue();
                values = value.split(",")
                
            }
        });
    }
    
    if (values === undefined)
      return values
    else
      return values[i];
  }
  
  this.reportMisaligned = function (target, result, auditReport) {
    var report = JSON.parse(result.response);
    if (!report.aligned) {
      for (var i = 0; i < report.misalignedAttributes.length; i++) {
        var attributeData = report.misalignedAttributes[i];
        if (attributeData.expected == "present") {
          //misaligned object
          var objectDn = attributeData.name;
          var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
          auditReport.addMisAlignedObject(misalignedObject);
        }
        else if (attributeData.expected == "not present") {
          //undesired object
          var objectDn = attributeData.name;
          var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
          auditReport.addMisAlignedObject(misalignedObject);
        }
        else {
          var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
          auditReport.addMisAlignedAttribute(misalignedAttribute);
        }
      }
    }
    return auditReport
  }
  
  this.getBaseFdnForPort = function(target,portId){
     var portIds = portId.split("/");
     var cardSlot = portIds[0];
     var mdaSlot = portIds[1];
     var portNumber = portIds[2];
     return "network:"+target+":shelf-1:cardSlot-"+cardSlot+":card:daughterCardSlot-"+mdaSlot+":daughterCard:port-"+portNumber;
  }

  this.editPayload = function(fdn, properties, childProperties, fullClassName, objectFullName){
    var payload  = {};
    var configInfo = {};
    configInfo[fullClassName] = properties;
    configInfo[fullClassName]["children-Set"] = childProperties;
    //payload["fdn"] = fdn;
    payload["distinguishedName"] = fdn;
    payload["objectFullName"] = objectFullName;
    payload["clearOnDeployFailure"] = true;
    payload["configInfo"] = configInfo;
    logger.info(LOG_PREFIX + "All final payload : " + JSON.stringify(payload));
    return payload;
  }

  /*
   function: getQosNetworkPolicyId
   description: Getting the Policy id from target.
   */
  this.getQosNetworkPolicyId = function (target) {
    var policyId = target.split("#")[3];
    return policyId;
  }

  /*
   function: getQosNetworkPolicyName
   description: Getting the Policy Name from target.
   */
  this.getQosNetworkPolicyName = function (target) {
    var policyName = target.split("#")[2];
    return policyName;
  }

  /*
   function: delay
   description: Sometimes the object creation takes time, we can use delay for child-level operation.
   */
  this.delay = function (milliseconds){
    var date = new Date();
    date.setMilliseconds(date.getMilliseconds() + milliseconds);
    while(new Date() < date){
    }
  }

  /*
   function: getIfObjectExists
   description: returns the object for objectFullName if exists.
   */
  this.getIfObjectExists = function(className, objectFullName) {

    let nfmpFwk = new NfmpFwk();
    var expectedJson = {
      "fullClassName": className,
      "filter":{
        "equal":{
          "name":"objectFullName",
          "value": objectFullName
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          "policyName",
          "id"
        ]
      }
    };
    var ret = false;
    var resultFetch = nfmpFwk.post("/v3/search", expectedJson);
    logger.info(LOG_PREFIX + "Policy search results : " + JSON.stringify(resultFetch));
    var finalResponse = JSON.parse(resultFetch.response);
    if (JSON.stringify(finalResponse) === JSON.stringify({})) {
      logger.info(LOG_PREFIX + "Search results is empty: " + JSON.stringify(finalResponse));
      finalResponse = null;
    }
    else if (!Array.isArray(finalResponse)) {
      finalResponse = [finalResponse["niegr.Policy"]];
      logger.info(LOG_PREFIX + "Search results: " + JSON.stringify(finalResponse));
    }
    return finalResponse;
  }

  this.isObjectExists = function (className, objectFullName) {
    let nfmpFwk = new NfmpFwk();
    var ret = false;
    var searchObjectJson = {
      "fullClassName": className,
      "filter": {
        "equal": {
          "name": "objectFullName",
          "value": objectFullName
        }
      }
    };
    var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);

    logger.info(LOG_PREFIX + "Result fetch success = {}", resultFetch.success);
    var finalResponse = JSON.parse(resultFetch.response);
    if (Object.keys(finalResponse).length !== 0 && finalResponse.constructor === Object)
    {
      ret = true;
    }
    logger.info(LOG_PREFIX + "isObjectExists = {} ", ret);
    return ret;
  }

  this.transformNfmpProtocol = function(intentProtocolValue){

    var nfmpProtocolValue="";
    switch (intentProtocolValue)
    {
      case "tcp-udp":nfmpProtocolValue="UDPTCP";
        break;
      case "icmp":nfmpProtocolValue="ICMP";
        break;
      case "igmp":nfmpProtocolValue="IGMP";
        break;
      case "ip":nfmpProtocolValue="IP";
        break;
      case "tcp":nfmpProtocolValue="TCP";
        break;
      case "egp":nfmpProtocolValue="EGP";
        break;
      case "igp":nfmpProtocolValue="IGP";
        break;
      case "udp":nfmpProtocolValue="UDP";
        break;
      case "rdp":nfmpProtocolValue="RDP";
        break;
      case "ipv6":nfmpProtocolValue="IPv6";
        break;
      case "ipv6-route":nfmpProtocolValue="IPv6Route";
        break;
      case "ipv6-frag":nfmpProtocolValue="IPv6Frag";
        break;
      case "idrp":nfmpProtocolValue="IDRP";
        break;
      case "rsvp":nfmpProtocolValue="RSVP";
        break;
      case "gre":nfmpProtocolValue="GRE";
        break;
      case "ipv6-icmp":nfmpProtocolValue="IPv6_ICMP";
        break;
      case "ipv6-no-nxt":nfmpProtocolValue="IPv6_NoNxt";
        break;
      case "ipv6-opts":nfmpProtocolValue="IPv6_Opts";
        break;
      case "iso-ip":nfmpProtocolValue="ISO_IP";
        break;
      case "eigrp":nfmpProtocolValue="EIGRP";
        break;
      case "ospf-igp":nfmpProtocolValue="OSPFIGP";
        break;
      case "ether-ip":nfmpProtocolValue="ETHERIP";
        break;
      case "encap":nfmpProtocolValue="ENCAP";
        break;
      case "pnni":nfmpProtocolValue="PNNI";
        break;
      case "pim":nfmpProtocolValue="PIM";
        break;
      case "vrrp":nfmpProtocolValue="VRRP";
        break;
      case "l2tp":nfmpProtocolValue="L2TP";
        break;
      case "stp":nfmpProtocolValue="STP";
        break;
      case "ptp":nfmpProtocolValue="PTP";
        break;
      case "isis":nfmpProtocolValue="ISIS";
        break;
      case "crtp":nfmpProtocolValue="CRTP";
        break;
      case "crudp":nfmpProtocolValue="CRUDP";
        break;
      case "sctp":nfmpProtocolValue="SCTP";
        break;
      default:nfmpProtocolValue=undefined;
    }
    return nfmpProtocolValue;
  }

  this.transformProtocolBrownField = function(nfmpProtocolValue){
    var intentProtocolValue="";
    switch (nfmpProtocolValue)
    {
      case "UDPTCP":intentProtocolValue="tcp-udp";
        break;
      case "ICMP":intentProtocolValue="icmp";
        break;
      case "IGMP":intentProtocolValue="igmp";
        break;
      case "IP":intentProtocolValue="ip";
        break;
      case "TCP":intentProtocolValue="tcp";
        break;
      case "EGP":intentProtocolValue="egp";
        break;
      case "IGP":intentProtocolValue="igp";
        break;
      case "UDP":intentProtocolValue="udp";
        break;
      case "RDP":intentProtocolValue="rdp";
        break;
      case "IPv6":intentProtocolValue="ipv6";
        break;
      case "IPv6Route":intentProtocolValue="ipv6-route";
        break;
      case "IPv6Frag":intentProtocolValue="ipv6-frag";
        break;
      case "IDRP":intentProtocolValue="idrp";
        break;
      case "RSVP":intentProtocolValue="rsvp";
        break;
      case "GRE":intentProtocolValue="gre";
        break;
      case "IPv6_ICMP":intentProtocolValue="ipv6-icmp";
        break;
      case "IPv6_NoNxt":intentProtocolValue="ipv6-no-nxt";
        break;
      case "IPv6_Opts":intentProtocolValue="ipv6-opts";
        break;
      case "ISO_IP":intentProtocolValue="iso-ip";
        break;
      case "EIGRP":intentProtocolValue="eigrp";
        break;
      case "OSPFIGP":intentProtocolValue="ospf-igp";
        break;
      case "ETHERIP":intentProtocolValue="ether-ip";
        break;
      case "ENCAP":intentProtocolValue="encap";
        break;
      case "PNNI":intentProtocolValue="pnni";
        break;
      case "PIM":intentProtocolValue="pim";
        break;
      case "VRRP":intentProtocolValue="vrrp";
        break;
      case "L2TP":intentProtocolValue="l2tp";
        break;
      case "STP":intentProtocolValue="stp";
        break;
      case "PTP":intentProtocolValue="ptp";
        break;
      case "ISIS":intentProtocolValue="isis";
        break;
      case "CRTP":intentProtocolValue="crtp";
        break;
      case "CRUDP":intentProtocolValue="crudp";
        break;
      case "SCTP":intentProtocolValue="sctp";
        break;
      default:intentProtocolValue=undefined;
    }
    return intentProtocolValue;
  }
  
  this.convertValToNumBrownField = function (value) {
    if (value.startsWith("value_") || value.startsWith("lspExp_") || value.startsWith("priority_")) {
      return value.split("_")[1];
    }
    else {
      return value;
    }
  }

  this.expandIPv6Address =  function (address)
  {
    var ipv6AddressUtil = new IPv6AddressUtil();
     return ipv6AddressUtil.expandIPv6AddressForClassic(address);
  }

  this.transformFragmentGreenField = function (fragment) {
    switch (fragment) {
      case "first-only":
        return "firstOnly";
      case "non-first-only":
        return "nonFirstOnly";
      default:
        return fragment;
    }
  }

    this.modifyNeIdForIpV6 = function (objectFullName, neId) {
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }



   this.MdIpv6ValidAddresssMaskSupport = function(input) {
        if (input === undefined) {
            return undefined;
        }
        if (input.endsWith(':') || input.endsWith('::0')) {
            input += ":";
        }
        let hex = removeLeadingTrailingZeros(input)
        if(hex.indexOf('::')!==-1){
            hex=hex.replace(/(::)0+/g, '$1').replace(/:::/g, "::")
            return hex;
        }
        const hextets = hex.split(':').filter(part => part !== ''); // Remove empty parts
        let maxZeroLength = 0;
        let longestZeroIndex = -1;
        let currentZeroLength = 0;
        for (let i = 0; i < hextets.length; i++) {
            if (hextets[i] === '0') {
                currentZeroLength++;
                if (currentZeroLength > maxZeroLength) {
                    maxZeroLength = currentZeroLength;
                    longestZeroIndex = i - maxZeroLength + 1;
                }
            } else {
                currentZeroLength = 0;
            }
        }
        if (maxZeroLength > 1) {
            hextets.splice(longestZeroIndex, maxZeroLength, '::');
        }
        if (maxZeroLength === 1) {
            const zeroIndex = hextets.indexOf('0');
            const zeroCount = hextets.filter(part => part === '0').length;
            if (zeroIndex !== -1 && zeroCount === 1 && hextets.length !== 8) {
                hextets.splice(zeroIndex, 1, '::');
            }
        }

        let result = hextets.join(':').replace(/::+/g, '::');
        return result;
    }

    function removeLeadingTrailingZeros(input) {
        const parts = input.split(':');
        for (let i = 0; i < parts.length; i++) {
            if(parts[i] == ''){
                continue
            }else{
                parts[i] = removeLeadingZeros(parts[i]);
            }

        }
        return parts.join(':');
    }

    function removeLeadingZeros(part) {
        let result = '';
        let nonZeroEncountered = false;
        for (let i = 0; i < part.length; i++) {
            if (part[i] !== '0') {
                nonZeroEncountered = true;
            }
            if (nonZeroEncountered) {
                result += part[i];
            }
        }
        return result || '0';
   }

    function ipv6ToMappedIpv4WithSuffix(address){
        // Preserve CIDR suffix if present
        let cidrSuffix = '';
        if (address.indexOf('/') !== -1) {
            var splitParts = address.split('/');
            address = splitParts[0];
            cidrSuffix = '/' + splitParts[1];
        }
        address = ipv6ToMappedIpv4(address);
        return address+cidrSuffix;
    }

    function ipv6ToMappedIpv4(ipv6)
    {
        // Extract the hex part after "::ffff:"
        let hexPart = ipv6.replace("::ffff:", "");
        hexPart = hexPart.replace("::FFFF:", "");

        // Split the remaining part into two 16-bit sections
        const parts = hexPart.split(":");
        if (parts.length !== 2) {
            return ipv6;
        }

        // Convert each 16-bit hex value into two 8-bit decimal values
        const firstTwoOctets = parseInt(parts[0], 16); // Convert first 16 bits
        const lastTwoOctets = parseInt(parts[1], 16);  // Convert last 16 bits

        // Extract individual octets
        const octet1 = (firstTwoOctets >> 8) & 0xFF;
        const octet2 = firstTwoOctets & 0xFF;
        const octet3 = (lastTwoOctets >> 8) & 0xFF;
        const octet4 = lastTwoOctets & 0xFF;

        // Construct the final "::ffff:<IPv4>" format
        return "::ffff:" + octet1 + "." + octet2 + "." + octet3 + "." + octet4;
    }

    this.expandIPv6ForMd = function(address) {
        var fullAddress = "";
        var validGroupCount = 8;

        var ipv4 = "";
        var extractIpv4 = /([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})/;
        var validateIpv4 = /((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})/;
        // look for embedded ipv4
        if (validateIpv4.test(address)) {
            var groups = address.match(extractIpv4);
            for (var i = 1; i < groups.length; i++) {
                ipv4 += ("0" + (parseInt(groups[i], 10).toString(16))).slice(-2) + (i == 2 ? ":" : "");
            }
            if(!address.startsWith("::ffff") && !address.startsWith("::FFFF"))
			{
				address = address.replace(extractIpv4, ipv4);
			}
        }
        else
        {
            if(address.startsWith("::ffff") || address.startsWith("::FFFF"))
            {
                address = ipv6ToMappedIpv4WithSuffix(address)
            }
        }

        if (address.indexOf("::") == -1) // All eight groups are present.
            fullAddress = address;
        else // Consecutive groups of zeroes have been collapsed with "::".
        {
            var sides = address.split("::");
            var groupsPresent = 0;
            for (var i = 0; i < sides.length; i++) {
                groupsPresent += sides[i].split(":").length;
            }
            fullAddress += (sides[0] ? sides[0] : 0) + ":";
            for (var i = 0; i < validGroupCount - groupsPresent; i++) {
                fullAddress += "0:";
            }
            if (sides[1]) {
                fullAddress += (sides[1].split("/")[0] ? sides[1].split("/")[0] : "0") +
                    (sides[1].split("/")[1] ? "/" + sides[1].split("/")[1] : "");
            } else {
                fullAddress += "0";
            }

        }
        fullAddress = removeLeadingZeros(fullAddress);
        return fullAddress.toLowerCase();
    }
}
