<#ftl output_format="JSON">
<#setting number_format="computer">
{
<#if extraParams.name != "hopless" && extraParams["explicit-route-objects-always"]["route-object-include-exclude"].length != 0 >
    "hops":{
        "hop":[
        <#list extraParams["explicit-route-objects-always"]["route-object-include-exclude"]?values as value>
        {
            "index":${value.index},
            "address":"${value.numbered\-node\-hop.node\-id}",
             "mode": "ipv4-ipv6-address",
             "er-hop-type": "include-${value.numbered\-node\-hop.hop\-type}",
             "interface-type": "default"
        }
        <#if value?has_next>,</#if>
        </#list>
     ]
    },</#if>
    "name":"${extraParams.name}"
}