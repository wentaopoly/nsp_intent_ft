import { IntentHandlerBase }  from 'common/IntentHandlerBase.mjs';
import { NSP }  from 'common/NSP.mjs';

class IntentHandler extends (IntentHandlerBase) {
  constructor() {
    super();
    NSP.checkRelease(24, 11);
    this.ignoreChildren = [];
  }

  getDeviceModelPath(target) {
    const items = target.split('#');
    return `nokia-conf:/configure/router=${encodeURIComponent(items[2])}/mpls-labels`;
  }

  getDesiredConfig(target, intentConfigJSON) {
    const items = target.split('#');
    const config = Object.values(Object.values(JSON.parse(intentConfigJSON)[0])[0])[0];
    
    return {"nokia-conf:mpls-labels": this.cleanupConfig(config)};
  }
  
  getTargetDataHook(target, config) {
    return {"mpls-labels": config};
  }
  
  // WebUI suggest/picker callouts:

  suggestRouterName(context) {
    const target = this.getTarget(context);
    return this.getDeviceModelObjects(context, `nokia-conf:/configure/router`, "router-name");
  }



getModuleRefs() {
  return JSON.parse('{}');
}


}

new IntentHandler();