/*
 *
 * The intent of this framework is to provide a means of communicating with the NFM-P mediator.
 *
 * All responses should be in the format of
 * {
 *   success: true or false
 *   httpStatus: the http status of the request
 *   msg: a message (usually an error in the case of a failure, or the response body payload)
 * }
 *
 */
function NfmpFwk() {
    var NFMP_HOST = "nsp-mdt-nfmp-mediator-svc";
    var NFMP_PORT = "80";
    var PATH_SYNCHRONIZE = "/v3/synchronize?synchronousDeploy=true&clearOnDeployFailure=true";
    var PATH_COMPARE = "/v3/compare";
    var PATH_DELETE = "/v3/delete/";
    var PATH_SEARCH = "/v3/search";


    this.configRestClient = function () {
        restClient.setIp(NFMP_HOST);
        restClient.setPort(NFMP_PORT);
        restClient.setProtocol("http");
    };

    this.fetch = function (target, targetUrl, requestType) {
        var result = {};
        this.configRestClient();
        restClient.get(
            targetUrl,
            requestType,
            function (exception, httpStatus, response) {
                if (exception) {
                    result = {
                        success: false,
                        httpStatus: httpStatus,
                        msg:
                            "Couldn't connect to Manager of Device: " +
                            target +
                            ", got response " +
                            response,
                    };
                }
                if (httpStatus !== 200 && httpStatus !== 201) {
                    result = {
                        success: false,
                        httpStatus: httpStatus,
                        msg:
                            "Failed to fetch service from NFM-P device " +
                            target +
                            ", got response " +
                            response,
                    };
                } else {
                    result = {
                        success: true,
                        httpStatus: httpStatus,
                        msg: response,
                    };
                }
            }
        );
        return result;
    };

    this.find = function (target, jsonRequest) {
        var result = {};
        this.configRestClient();
        restClient.post(PATH_SEARCH, "application/json", JSON.stringify(jsonRequest), "application/json", function (exception, httpStatus, response) {
            if (exception != null || httpStatus >= 400) {
                result = {
                    success: false,
                    httpStatus: httpStatus,
                    msg: "Couldn't connect to Manager of Device: " + target + ", got response " + response
                };

            } else {
                result = {
                    success: true,
                    httpStatus: httpStatus,
                    response: response,
                    msg: "Deployment to NFM-P for device " + target + " was successful, got response " + response
                };
            }

        });
        log.info(null, "[NFMP-FWK] find() Search Response:" + JSON.stringify(result));
        return result;
    }

    this.deploy = function (target, payload, requestType) {
        var result = {};
        this.configRestClient();
        log.info(
            null,
            "Deploying to target: " +
            target +
            ", targetUrl: " +
            PATH_SYNCHRONIZE +
            ", payload: " +
            payload
        );
        restClient.post(
            PATH_SYNCHRONIZE,
            requestType,
            payload,
            "application/json",
            function (exception, httpStatus, response) {
                if (exception) {
                    result = {
                        success: false,
                        httpStatus: httpStatus,
                        msg:
                            "Couldn't connect to Manager of Device: " +
                            target +
                            ", got response " +
                            response,
                    };
                }
                if (httpStatus !== 200 && httpStatus !== 201 && httpStatus !== 204) {
                    result = {
                        success: false,
                        httpStatus: httpStatus,
                        msg:
                            "Failed deployment to NFM-P for device " +
                            target +
                            ", got response " +
                            response,
                    };
                } else {
                    result = {
                        success: true,
                        httpStatus: httpStatus,
                        response: response,
                        msg:
                            "Deployment to NFM-P for device " +
                            target +
                            " was successful, got response " +
                            response,
                    };
                }
            }
        );
        log.info(null, "[NFMP-FWK] deploy: Got result " + JSON.stringify(result));
        return result;
    };

    this.post = function (targetUrl, expectedJson) {
        var result = {};
        this.configRestClient();
        logger.info(
            "[NFMP-FWK] POST URL: {}, Payload: {}",
            targetUrl,
            JSON.stringify(expectedJson, null, 2)
        );
        restClient.post(
            targetUrl,
            "application/json",
            JSON.stringify(expectedJson),
            "application/json",
            function (exception, httpStatus, response) {
                result = {
                    success: false,
                    httpStatus: httpStatus,
                    msg: "null",
                };
                logger.info("[MEDIATOR-FWK] POST Response {}", response);
                if (exception) {
                    logger.error("[NFMP-FWK] POST Exception {}", exception);
                    result.msg =
                        "Couldn't connect to " +
                        this.mediatorType +
                        ", got response " +
                        response +
                        ", exception " +
                        exception;
                } else if (httpStatus !== 200 && httpStatus !== 201) {
                    result.msg =
                        "Failed deployment to " +
                        this.mediatorType +
                        ", got response " +
                        response;
                    result.response = response;
                } else {
                    result.success = true;
                    result.msg =
                        "Deployment to " +
                        this.mediatorType +
                        " was successful, got response " +
                        response;
                    result.response = response;
                }
            }
        );
        return result;
    };

    this.compare = function (target, payload, requestType) {
        var result = {};
        this.configRestClient();
        logger.info(
            "Deploying to target: " +
            target +
            ", targetUrl: " +
            PATH_COMPARE +
            ", payload: " +
            payload
        );
        restClient.post(
            PATH_COMPARE,
            requestType,
            payload,
            "application/json",
            function (exception, httpStatus, response) {
                if (exception) {
                    result = {
                        success: false,
                        httpStatus: httpStatus,
                        msg:
                            "Couldn't connect to Manager of Device: " +
                            target +
                            ", got response " +
                            response,
                    };
                }
                if (httpStatus !== 200 && httpStatus !== 201) {
                    result = {
                        success: false,
                        httpStatus: httpStatus,
                        msg:
                            "Failed deployment to NFM-P for device " +
                            target +
                            ", got response " +
                            response,
                    };
                } else {
                    result = {
                        success: true,
                        httpStatus: httpStatus,
                        response: response,
                        msg:
                            "Deployment to NFM-P for device " +
                            target +
                            " was successful, got response " +
                            response,
                    };
                }
            }
        );
        logger.info("[NFMP-FWK] deploy: Got result " + JSON.stringify(result));
        return result;
    };

    this.deployDelete = function (objectFullName, requestType) {
        var result = {};
        this.configRestClient();
        log.info(
            null,
            "Deleting: objectFullName: " +
            objectFullName +
            ", deleteUrl: " +
            PATH_DELETE +
            objectFullName
        );
        restClient.delete(
            PATH_DELETE + objectFullName + "?synchronousDeploy=true&clearOnDeployFailure=true",
            requestType,
            function (exception, httpStatus, response) {
                if (exception) {
                    result = {
                        success: false,
                        httpStatus: httpStatus,
                        msg:
                            "Couldn't connect to Manager of Device: " +
                            objectFullName +
                            ", got response " +
                            response,
                    };
                }
                if (httpStatus !== 200 && httpStatus !== 201 && httpStatus !== 204) {
                    result = {
                        success: false,
                        httpStatus: httpStatus,
                        msg:
                            "Failed deployment to NFM-P for device " +
                            objectFullName +
                            ", got response " +
                            response,
                    };
                } else {
                    result = {
                        success: true,
                        httpStatus: httpStatus,
                        msg:
                            "Deployment to NFM-P for device " +
                            objectFullName +
                            " was successful, got response " +
                            response,
                    };
                }
            }
        );
        log.info(
            null,
            "[NFMP-FWK] deployDelete: Got result " + JSON.stringify(result)
        );
        return result;
    };

    this.passThroughRequest = function (url, req) {
        var result = {};
        this.configRestClient();
        log.info(null, "Passing Through : " + url + ", with req: " + req);
        restClient.post(
            url,
            "application/xml",
            req,
            "application/xml",
            function (exception, httpStatus, response) {
                if (exception) {
                    result = {
                        success: false,
                        httpStatus: httpStatus,
                        msg:
                            "Couldn't connect to Manager of Device: " +
                            ", got response " +
                            response,
                    };
                }
                if (httpStatus !== 200 && httpStatus !== 201 && httpStatus !== 204) {
                    result = {
                        success: false,
                        httpStatus: httpStatus,
                        msg:
                            "Failed deployment to NFM-P for device " +
                            ", got response " +
                            response,
                    };
                } else {
                    result = {
                        success: true,
                        httpStatus: httpStatus,
                        msg:
                            "Deployment to NFM-P for device " +
                            " was successful, got response " +
                            response,
                    };
                }
            }
        );
        log.info(
            null,
            "[NFMP-FWK] deploy pass through: Got result " + JSON.stringify(result)
        );
        return result;
    };
}
