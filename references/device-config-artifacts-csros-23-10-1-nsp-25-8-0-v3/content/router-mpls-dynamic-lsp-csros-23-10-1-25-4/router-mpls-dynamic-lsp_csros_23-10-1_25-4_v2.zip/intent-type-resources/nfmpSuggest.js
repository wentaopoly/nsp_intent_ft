function NfmpSuggest() {

    this.getLspName = function (neId) {
        let className = "mpls.DynamicLsp";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "sourceNodeId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObject, className, "displayedName")
    }

    this.getTagName = function (neId) {
        let className = "rtr.AdminTag";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "tagName"
                ]
            }
        };
        return this.getData(searchObject, className, "tagName")
    }

    this.getLspData = function (neId, lspData ,type, name) {
        let nfmpFwk = new NfmpFwk();
        let className = "mpls.DynamicLsp";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "sourceNodeId",
                            "value": neId
                        },
                        {
                            "name": name,
                            "value": lspData
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    type
                ]
            }
        };
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        let finalResponse = JSON.parse(resultFetch.response);
        let data = (finalResponse[className] && finalResponse[className][type]);
        return data;
    }

    this.getLspIds = function (neId ,type) {
        let nfmpFwk = new NfmpFwk();
        let className = "mpls.DynamicLsp";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "sourceNodeId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    type
                ]
            }
        };
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        let finalResponse = JSON.parse(resultFetch.response);
        finalResponse = finalResponse[className];
        if(!Array.isArray(finalResponse))
        {
            finalResponse = [finalResponse];
        }
        let data = new Set();
        if (finalResponse){
            finalResponse.forEach(function(e) {
                if (e && e.pathId !== undefined) {
                    data.add(parseInt(e.pathId, 10));
                }
            });
        }
        return data;
    }

    this.getEgrAccountingPolicy = function (neId) {
        let className = "accounting.Policy";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "recordType",
                            "value": "combinedMplsLspEgress"
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        return this.getData(searchObject, className, "id")
    }

    this.getBfdTemplate = function (neId) {
        let className = "mplstp.BFDTemplate";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObject, className, "displayedName")
    }

    this.getPolicyName = function (neId) {
        let className = "mpls.ClassForwardingPolicy";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "policyName"
                ]
            }
        };
        return this.getData(searchObject, className, "policyName")
    }

    this.getAssociationName = function (neId, associationType) {
        let className = (associationType=="diversity")?"pcep.PcepPccPceAssociationDiversity":"pcep.PcepPccPceAssociationPolicy";
        let type = (associationType=="diversity")?"associationDiversityName":"associationPolicyName";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    type
                ]
            }
        };
        return this.getData(searchObject, className, type)
    }

    this.getAdminGroups = function (neId) {
        let className = "rtr.AdminGroupPolicy";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName",
                    "value"
                ]
            }
        };
        return this.getAdminGroupPolicyData(searchObject, className, "displayedName", "value")
    }

    this.getFormattedAdminGroupData = function (values,neId) {
        let className = "rtr.AdminGroupPolicy";

        function createFilterObject(values) {
            return {
                or: {
                equal: values.map(str => ({
                    name: "value",
                    value: str
                }))
                }
            };
        };

        let searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ],
                    "or": createFilterObject(values)["or"]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName",
                    "value"
                ]
            }
        };

        return this.getAdminGroupPolicyData(searchObject, className, "displayedName", "value")
    }

    this.getResourceId = function (neId, argsData) {
        let className = "mpls.Tunnel";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "sourceNodeId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "pathId",
                    "displayedName",
                    "sourceNodeId",
                    "destinationNodeId"
                ]
            }
        };

        let nfmpFwk = new NfmpFwk();
        let result = {};
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        let finalResponse = JSON.parse(resultFetch.response);
        finalResponse = finalResponse[className];
        if(!Array.isArray(finalResponse))
        {
            finalResponse = [finalResponse];
        }
        let lspData = argsData &&  argsData["__root"] && argsData["__root"]["mpls-DynamicLsp"] && argsData["__root"]["mpls-DynamicLsp"]["mpls-LspPath"];
        let currentType = argsData && argsData["type"];
        if (currentType && lspData && lspData.length > 0) {
            let blockedIds = [];
            lspData.forEach(function (config) {
                if (config && config.resourceId && config.type && config.type !== currentType) {
                    blockedIds.push(String(config.resourceId));
                }
            });
            if (blockedIds.length > 0) {
                finalResponse = finalResponse.filter(function (lsp) {
                    return blockedIds.indexOf(String(lsp.pathId)) === -1;
                });
            }
        }
        logger.info("Final Response: "+JSON.stringify(finalResponse));
        let data = finalResponse.map(function (lspPath) {
            var obj = {};
            obj["pathId"] = lspPath["pathId"];
            obj["displayedName"] = lspPath["displayedName"];
            obj["sourceNodeId"] = lspPath["sourceNodeId"];
            obj["destinationNodeId"] = lspPath["destinationNodeId"];
            return obj;
        });
        result["data"] = JSON.stringify(data);
        logger.info("Result: "+JSON.stringify(result));
        return result;
    }

    this.getManagedNodeIds = function () {
        let className = "netw.NetworkElement";
        let searchObject = {
            "fullClassName": className,
            "resultFilter": {
                "children": "",
                "attribute": [
                    "siteId"
                ]
            }
        };
        return this.getData(searchObject, className, "siteId")
    }

    this.getData = function (searchObjectJson, className, type) {
        var nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    ret.push(value[type]);
                })
            }
        }

        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

    this.getAdminGroupPolicyData = function (searchObjectJson, className, type1,type2) {
        var nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    if(Number(value[type2])<=31)
                    ret.push(value[type1]+"("+value[type2]+")");
                })
            }
        }

        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }
}
