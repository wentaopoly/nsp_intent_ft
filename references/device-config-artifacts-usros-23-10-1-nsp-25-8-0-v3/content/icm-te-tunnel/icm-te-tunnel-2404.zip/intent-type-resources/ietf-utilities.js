IetfUtilities.prototype.imLogger = null;

function IetfUtilities() {
    this.imLogger = new IntentLogger();
};

IetfUtilities.prototype.setImLogger = function (logger) {
    this.imLogger = logger;
};

IetfUtilities.prototype.getIntentTypeVersion = function (intentType, target) {
    this.imLogger.debug("[IETF-Utilities][getIntentTypeVersion] {} {}", intentType, target);
    var lIntent = ibnService.getIntent(intentType, target);
    if (lIntent) {
        this.imLogger.debug("[IETF-Utilities][getIntentTypeVersion] {} {}", lIntent.getIntentTypeVersion(), target);
        return lIntent.getIntentTypeVersion();
    } else
        new RuntimeException("Cannot resolve intent-type version intentType -  " + intentType + " target - " + target);
};

IetfUtilities.prototype.getManagerName = function (deviceName) {
    var managerInfos = mds.getAllManagersWithDevice(deviceName);
    if (managerInfos == null || managerInfos.isEmpty()) {
        this.imLogger.info("Manager not found for device ");
        return null;
    } else
        return managerInfos.get(0).getName();
};

IetfUtilities.prototype.getDeviceInfo = function (deviceName) {
    var deviceInfos = mds.getAllInfoFromDevices(deviceName);
    if (null == deviceInfos || deviceInfos.size() === 0) {
        throw new RuntimeException("Device not found :" + deviceName);
    }
    var deviceInfo = deviceInfos.get(0);
    var deviceType = deviceInfo.getFamilyTypeRelease();
    if (deviceType == null) {
        throw new RuntimeException("Device Family type and release not found for device: " + deviceName);
    }
    var typeAndVersion = deviceType.split(':');
    this.imLogger.info("[IETF-Utilities][getDeviceInfo] Device typeAndVersion:" + typeAndVersion);
    var typeAndVersionMap;
    typeAndVersionMap = {
        type: typeAndVersion[0],
        version: typeAndVersion[1]
    };
    return typeAndVersionMap;
};

IetfUtilities.prototype.getNfmpMediator = function (deviceId)
{
    managerName = this.getManagerName(deviceId);
    if(managerName === "NFM-P")
    {
        this.imLogger.info("[IETF-Utilities][getNfmpMediator] This is NFMP Mediator for device: " + deviceId);
        return new MediatorFramework("NFMP");
    }
    else //NFM-P alien mediator
    {
        this.imLogger.info("[IETF-Utilities][getNfmpMediator] This is NFMP Alien Mediator for device: " + deviceId);
        return new MediatorFramework(managerName);
    }

}



IetfUtilities.prototype.sortJSON = function (object, deviceKey) {
    for (var key in object) {
        if (deviceKey && typeof deviceKey === "function" && object[key] instanceof Array && deviceKey(key)) {
            this.imLogger.debug("[IETF-Utilities][sortJSON]  sortJSON  key {} object[key] {}", key, JSON.stringify(object[key], null, 2));
            object[key] = this.sortByThenBy(object[key], deviceKey(key));
            this.imLogger.debug("[IETF-Utilities][sortJSON]  After sortJSON  key {} object[key] {}", key, JSON.stringify(object[key], null, 2));
        }
    }
    if (object instanceof Array) {
        for (var i = 0; i < object.length; i++) {
          if(object[i] == null) 
               i=i+1;
            object[i] = this.sortJSON(object[i], deviceKey);
        }
        return object;
    } else if (typeof object != "object")
        return object;

    var keys = Object.keys(object);
    keys = keys.sort();
    var newObject = {};
    for (var i = 0; i < keys.length; i++) {
        newObject[keys[i]] = this.sortJSON(object[keys[i]], deviceKey)
    }
    return newObject;
};

IetfUtilities.prototype.sortByThenBy = function (items, keys) {
    return items.sort(function (it1, it2) {
        return compare(it1, it2, keys);
    });
};

function compare(it1, it2, keys, index) {
    index = index || 0;
    var currentKey = keys[index];
    logger.debug("[MDT-SVC-FWK] compare  it1 {} it2 {} key {} index {} currentKey {}", JSON.stringify(it1), JSON.stringify(it2), JSON.stringify(keys), index, currentKey);
    if (it1[currentKey] < it2[currentKey]) {
        return 1;
    } else if (it1[currentKey] > it2[currentKey]) {
        return -1;
    } else if (keys[index + 1]) {
        compare(it1, it2, keys, index + 1)
    } else {
        return 0;
    }
};

IetfUtilities.prototype.setTopologyExtraInfo = function (topology, key, value) {
    var found = false;
    if (topology && topology.getXtraInfo() !== null && !topology.getXtraInfo().isEmpty()) {
        topology.getXtraInfo().forEach(function (extraInfo) {
            if (extraInfo.getKey() == key) {
                extraInfo.setValue(value);
                found = true;
            }
        });
    }
    if (!found) {
        if (topology) {
            var entry = topologyFactory.createTopologyXtraInfoFrom(key, value);
            topology.addXtraInfo(entry);
        }
    }
    return topology;
};

IetfUtilities.prototype.getExtraInfo = function (key, topology) {
    var ret = null;
    if (topology && topology.getXtraInfo() !== null && !topology.getXtraInfo().isEmpty()) {
        var self = this;
        topology.getXtraInfo().forEach(function (extraInfo) {
            self.imLogger.debug("[IETF-Utilities][getExtraInfo] extraInfo {} {} ", key, extraInfo.getKey());
            if (extraInfo.getKey() != null && extraInfo.getKey() === key) {
                if (extraInfo.getValue() != null) {
                    ret = extraInfo.getValue();
                }
            }
        });
    }
    this.imLogger.debug("[IETF-Utilities][getExtraInfo]  ret {} ", ret);
    return ret;
};

