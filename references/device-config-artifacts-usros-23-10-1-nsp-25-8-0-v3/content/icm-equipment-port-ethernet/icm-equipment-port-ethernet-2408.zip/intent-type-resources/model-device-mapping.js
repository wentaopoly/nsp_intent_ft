function ModelDeviceMapping() {


    this.getMapping = function (type) {
        switch (type)
        {
            case "port":
                return this.getEthernetPortMapping();
            case "lldp":
                return this.getLldpMapping();
            case "txMgmtAddress":
                return this.getTxMgmtAddressMapping();
            default:
                return this.getEthernetPortMapping();
            //return this.get
        }
    }
    this.getEthernetPortMapping = function () {
        var mapping = {};
        mapping['port.description'] = 'equipment.PhysicalPort.description';
        mapping['port.admin-state'] = 'equipment.PhysicalPort.administrativeState';
        mapping['port.ethernet.mtu'] = 'equipment.PhysicalPort.mtuValue';
        mapping['port.ethernet.mode'] = 'equipment.PhysicalPort.mode';
        mapping['port.ethernet.l2Uplink'] = 'equipment.PhysicalPort.isl2UplinkMode'
        mapping['port.ethernet.encap-type'] = 'equipment.PhysicalPort.encapType';
        mapping['port.ethernet.speed'] = 'equipment.PhysicalPort.speed';
        mapping['port.ethernet.accounting-policy'] = 'equipment.PhysicalPort.etherAccountingPolicyObjectPointer';
        mapping['port.ethernet.collect-stats'] = 'equipment.PhysicalPort.etherCollectStats';
        mapping['port.ethernet.autonegotiate'] = "ethernetequipment.EthernetPortSpecifics.autoNegotiate";
        mapping['port.ethernet.dot1q-etype'] = "ethernetequipment.EthernetPortSpecifics.dot1qEtype";
        mapping['port.ethernet.qinq-etype'] = "ethernetequipment.EthernetPortSpecifics.qinqEtype";
        mapping['port.ethernet.pbb-etype'] = "ethernetequipment.EthernetPortSpecifics.pbbEtype";
        mapping['port.ethernet.access.accounting-policy'] = 'equipment.PhysicalPort.ethAccessAccountingPolicyObjectPointer';
        mapping['port.ethernet.access.collect-stats'] = 'equipment.PhysicalPort.ethAccessCollectStats';
        mapping['port.ethernet.network.accounting-policy'] = 'equipment.PhysicalPort.accountingPolicyObjectPointer';
        mapping['port.ethernet.network.collect-stats'] = 'equipment.PhysicalPort.collectStats';
        mapping['port.ethernet.egress.port-qos-policy.policy-name'] = 'equipment.PhysicalPort.portQosPolicyPointer';

        //Hold-Time
        mapping['port.ethernet.hold-time.units'] = 'equipment.PhysicalPort.holdTimeUnits';
        mapping['port.ethernet.hold-time.up'] = "equipment.PhysicalPort.holdTimeUp";
        mapping['port.ethernet.hold-time.down'] = "equipment.PhysicalPort.holdTimeDown";

        //DownWhenLooped
        mapping['port.ethernet.down-when-looped.admin-state'] = "ethernetequipment.EthernetPortSpecifics.downWhenLooped";
        mapping['port.ethernet.down-when-looped.use-broadcast-address'] = "ethernetequipment.EthernetPortSpecifics.useBroadCastAddress";
        mapping['port.ethernet.down-when-looped.retry-timeout'] = "ethernetequipment.EthernetPortSpecifics.retryTimeout";
        mapping['port.ethernet.down-when-looped.keep-alive'] = "ethernetequipment.EthernetPortSpecifics.keepAliveInterval";

        //ssm
        mapping['port.ethernet.ssm.admin-state'] = "ethernetequipment.EthernetPortSpecifics.ssm";
        mapping['port.ethernet.ssm.code-type'] = "ethernetequipment.EthernetPortSpecifics.codeType";
        mapping['port.ethernet.ssm.esmc-tunnel'] = "ethernetequipment.EthernetPortSpecifics.esmcTunnel";
        mapping['port.ethernet.ssm.tx-dus'] = "ethernetequipment.EthernetPortSpecifics.txDus";

        //crc-monitor
        mapping['port.ethernet.crc-monitor.window-size'] = "ethernetequipment.EthernetPortSpecifics.windowSize";
        mapping['port.ethernet.crc-monitor.signal-degrade.threshold'] = "ethernetequipment.EthernetPortSpecifics.sdThreshold";
        mapping['port.ethernet.crc-monitor.signal-degrade.multiplier'] = "ethernetequipment.EthernetPortSpecifics.sdThresholdMultiplier";
        mapping['port.ethernet.crc-monitor.signal-failure.threshold'] = "ethernetequipment.EthernetPortSpecifics.sfThreshold";
        mapping['port.ethernet.crc-monitor.signal-failure.multiplier'] = "ethernetequipment.EthernetPortSpecifics.sfThresholdMultiplier";

        return mapping;
    }

    this.getLldpMapping = function () {
        var mapping = {};
        mapping['tunnel-nearest-bridge'] = "portCfgEnableTunneling";
        mapping['notification'] = "portCfgNotifyEnable";
        mapping['port-id-subtype'] = "portCfgPortIdSubtype";
        mapping['tx-mgmt-address'] = "lldp.TransmitMgmtAddress";
        return mapping;
    }

    this.getTxMgmtAddressMapping = function () {
        var mapping = {};
        mapping['mgmt-address-system-type'] = "portCfgAddressIndex";
        mapping['admin-state'] = "portCfgManAddrTxEnabled";
        return mapping;
    }

}
