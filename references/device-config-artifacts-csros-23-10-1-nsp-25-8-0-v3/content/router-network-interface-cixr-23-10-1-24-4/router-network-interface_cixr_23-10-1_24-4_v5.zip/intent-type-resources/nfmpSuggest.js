function NfmpSuggest() {
    this.getInterfaceName = function (neId) {
        let type = "displayedName";
        let className = "rtr.NetworkInterface";
        let searchObject;
        let resultFetch;
        let data;
        let finalResult;
        let createSearchObject = function (className, nodeId) {
            let attributeList = [type];
            attributeList.push("id");
            let filter = {
                "and": {
                    "equal": [
                        {
                            "name": "nodeId",
                            "value": nodeId
                        }
                    ]
                }
            };
            return {
                "fullClassName": className,
                "filter": filter,
                "resultFilter": {
                    "children": "",
                    "attribute": attributeList
                }
            };
        };
        searchObject = createSearchObject(className, neId);
        resultFetch = nfmpFwk.post("/v3/search", searchObject);
        data = JSON.parse(resultFetch.response);
        finalResult = finalResponse(data, className, ["displayedName", "id"]);
        let result = [];
        if (finalResult.length > 0) {
            finalResult.forEach(function (value) {
                result.push(value.displayedName);
            });
        }
        logger.info("finalResponse[{}] = " + JSON.stringify(result));
        return result;
    };

    function finalResponse(responseData, className, attributes) {
        let result = [];
        if (responseData !== undefined && responseData[className] !== undefined) {
            let finalResponse = responseData[className];
            if (!Array.isArray(finalResponse)) {
                finalResponse = [finalResponse];
            }
            finalResponse.forEach(function (value) {
                let obj = {};
                attributes.forEach(attr => {
                    obj[attr] = value[attr];
                });
                result.push(obj);
            });
        }
        return result;
    }

    this.getInterfaceData = function (neId, interfaceData ,type, name) {
        let nfmpFwk = new NfmpFwk();
        let className = "rtr.NetworkInterface";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "nodeId",
                            "value": neId
                        },
                        {
                            "name": name,
                            "value": interfaceData
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    type
                ]
            }
        };
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        let finalResponse = JSON.parse(resultFetch.response);
        let data = (finalResponse[className] && finalResponse[className][type]);
        return data;
    }

    this.getNeDDoSProtectionPolicy = function (neId) {
         let className = "sitesec.DCpuProtection";
         let searchObject = {
               "fullClassName": className,
               "filter": {
                   "and": {
                       "equal": [
                            {
                               "name": "siteId",
                               "value": neId
                           }
                       ]
                   }
               },
               "resultFilter": {
                   "children": "",
                   "attribute": [
                "displayedName"
                   ]
               }
         };
         return this.getData(searchObject, className, "displayedName");
    }

    this.getNeDoSProtectionId = function (neId) {
         let className = "sitesec.DoSProtection";
         let searchObject = {
               "fullClassName": className,
               "filter": {
                   "and": {
                       "equal": [
                            {
                               "name": "siteId",
                               "value": neId
                           }
                       ]
                   }
               },
               "resultFilter": {
                   "children": "",
                   "attribute": [
                "id"
                   ]
               }
         };
         return this.getData(searchObject, className, "id");
    }

    this.getPolicyAccountingTemplate = function (neId) {
        let className = "rp.PolicyAccountingTemplate";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                            {
                               "name": "siteId",
                               "value": neId
                           }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
         return this.getData(searchObject, className, "displayedName");
    };

    this.getPolicyStatement = function (neId) {
         let className = "rp.PolicyStatement";
         let searchObject = {
               "fullClassName": className,
               "filter": {
                   "and": {
                       "equal": [
                            {
                               "name": "siteId",
                               "value": neId
                           }
                       ]
                   }
               },
               "resultFilter": {
                   "children": "",
                   "attribute": [
                "displayedName"
                   ]
               }
         };
         return this.getData(searchObject, className, "displayedName");
    };

    this.getSuggestNetworkPolicy = function (neId) {
         let className = "niegr.Policy";
         let searchObject = {
               "fullClassName": className,
               "filter": {
                   "and": {
                       "equal": [
                            {
                               "name": "siteId",
                               "value": neId
                           },
                           {
                               "name": "networkPolicyType",
                               "value": "ipInterface"
                           }
                       ]
                   }
               },
               "resultFilter": {
                   "children": "",
                   "attribute": [
                "id"
                   ]
               }
         };
         return this.getData(searchObject, className, "id");
    };

    this.getSuggestQosIngFpRedirectQGrp = function (neId) {
         let className = "qgroup.IngressQGroupPolicy";
         let searchObject = {
               "fullClassName": className,
               "filter": {
                   "and": {
                       "equal": [
                            {
                               "name": "siteId",
                               "value": neId
                           }
                       ]
                   }
               },
               "resultFilter": {
                   "children": "",
                   "attribute": [
                "displayedName"
                   ]
               }
         };
         return this.getData(searchObject, className, "displayedName");
    };

    this.getSuggestPythonPolicy = function(neId)
    {
         let className = "srpythonmgmt.PythonPolicy";
         let searchObject = {
               "fullClassName": className,
               "filter": {
                   "and": {
                       "equal": [
                            {
                               "name": "siteId",
                               "value": neId
                           }
                       ]
                   }
               },
               "resultFilter": {
                   "children": "",
                       "attribute": [
                            "displayedName"
                       ]
               }
         };
        let data = this.getData(searchObject, className, "displayedName");
        let uniqueNames = new Set();
        let filteredData = [];
        data.forEach(name => {
            if (!uniqueNames.has(name)) {
                uniqueNames.add(name);
                filteredData.push(name);
            }
        });
        return filteredData;
    }

    this.getLinkMeasurementTemplate = function(neId)
    {
         let className = "sas.LinkMeasurementTemplate";
         let searchObject = {
               "fullClassName": className,
               "filter": {
                   "and": {
                       "equal": [
                            {
                               "name": "siteId",
                               "value": neId
                           }
                       ]
                   }
               },
               "resultFilter": {
                   "children": "",
                       "attribute": [
                            "displayedName"
                       ]
               }
         };
        let data = this.getData(searchObject, className, "displayedName");
        let uniqueNames = new Set();
        let filteredData = [];
        data.forEach(name => {
            if (!uniqueNames.has(name)) {
                uniqueNames.add(name);
                filteredData.push(name);
            }
        });
        return filteredData;
    }

    this.getAccountingPolicy = function(neId)
    {
         let className = "accounting.Policy";
         let searchObject = {
               "fullClassName": className,
               "filter": {
                   "and": {
                       "equal": [
                            {
                               "name": "siteId",
                               "value": neId
                           }
                       ],
                       "or":{
                           "equal": [
                               {
                                  "name": "recordType",
                                  "value": "netInfEgressOctet"
                              },
                              {
                                  "name": "recordType",
                                  "value": "netInfEgressPkt"
                              },
                              {
                                  "name": "recordType",
                                  "value": "combinedNetInfEgress"
                              },
                              {
                                  "name": "recordType",
                                  "value": "completeNetInfIngrEgr"
                              },
                              {
                                  "name": "recordType",
                                  "value": "netInfIngressOctet"
                              },
                              {
                                  "name": "recordType",
                                  "value": "netInfIngressPkt"
                              },
                              {
                                  "name": "recordType",
                                  "value": "combinedNetInfIngress"
                              }
                          ]
                       }
                   }
               },
               "resultFilter": {
                   "children": "",
                       "attribute": [
                            "id"
                       ]
               }
         };
        let data = this.getData(searchObject, className, "id");
        let uniqueNames = new Set();
        let filteredData = [];
        data.forEach(name => {
            if (!uniqueNames.has(name)) {
                uniqueNames.add(name);
                filteredData.push(name);
            }
        });
        return filteredData;
    }
    this.getLocalDHCPServer = function(neId)
    {
         let className = "dhcp.LocalDhcpServer";
         let searchObject = {
               "fullClassName": className,
               "filter": {
                   "and": {
                       "equal": [
                            {
                               "name": "nodeId",
                               "value": neId
                            },
                            {
                               "name": "routerId",
                               "value": 1
                            }
                       ]
                   }
               },
               "resultFilter": {
                   "children": "",
                       "attribute": [
                            "displayedName"
                       ]
               }
         };
        let data = this.getData(searchObject, className, "displayedName");
        let uniqueNames = new Set();
        let filteredData = [];
        data.forEach(name => {
            if (!uniqueNames.has(name)) {
                uniqueNames.add(name);
                filteredData.push(name);
            }
        });
        return filteredData;
    }

    this.getSamplingProfile = function(neId)
    {
         let className = "cflowd.CflowdSampleProfile";
         let searchObject = {
               "fullClassName": className,
               "filter": {
                   "and": {
                       "equal": [
                            {
                               "name": "siteId",
                               "value": neId
                            }
                       ]
                   }
               },
               "resultFilter": {
                   "children": "",
                       "attribute": [
                            "profileId"
                       ]
               }
         };
        let data = this.getData(searchObject, className, "profileId");
        let uniqueNames = new Set();
        let filteredData = [];
        data.forEach(name => {
            if (!uniqueNames.has(name)) {
                uniqueNames.add(name);
                filteredData.push(name);
            }
        });
        return filteredData;
    }


    this.getData = function (searchObjectJson, className, type) {
        let nfmpFwk = new NfmpFwk();
        let ret = [];
        let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        let finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    ret.push(value[type]);
                })
            }
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

    this.getPort = function (neId) {
             let className = "netw.PhysicalInterfaceCtp";
             let searchObject = {
                   "fullClassName": className,
                   "filter": {
                       "and": {
                           "equal": [
                               {
                                   "name": "nodeId",
                                   "value": neId
                               }
                           ],
                           "notEqual": [
                               {
                                   "name": "terminatedObjectClassName",
                                   "value": "equipment.PwPort"
                               },
                               {
                                   "name": "terminatedObjectClassName",
                                   "value": "gmplsuni.TunnelGroupEndpoint"
                               },
                               {
                                   "name": "terminatedObjectClassName",
                                   "value": "equipment.ManagementPort"
                               }

                           ],
                           "or": {
                               "equal": [
                                   {
                                       "name": "locale",
                                       "value": "2"
                                   },
                                   {
                                       "name": "locale",
                                       "value": "3"
                                   }
                               ]
                           }
                       }
                   },
                  "resultFilter": {
                      "children": "",
                      "attribute": [
                          "locale",
                          "terminatingPortDisplayedName",
                          "encapType",
                          "terminatedObjectPointer"
                      ]
                  }
             };
             let nfmpFwk = new NfmpFwk();
             let result = {};
             let resultFetch = nfmpFwk.post("/v3/search", searchObject);
             let finalResponse = JSON.parse(resultFetch.response);
             finalResponse = finalResponse[className];
             if(!Array.isArray(finalResponse))
             {
                 finalResponse = [finalResponse];
             }
             logger.info(JSON.stringify(finalResponse));
             let data = finalResponse.map(function (port) {
             var obj = {};
             obj["port-name"] = port["terminatingPortDisplayedName"];
             obj["mode"] = port["locale"];
             obj["encapType"] = port["encapType"];
             obj["fdn"] = port["terminatedObjectPointer"];
             return obj;
         });
         result["data"] = JSON.stringify(data);
         return result;
        }

    this.getPortObjectFullName = function (neId, portName) {
     let className = "netw.PhysicalInterfaceCtp";
     let searchObject = {
           "fullClassName": className,
           "filter": {
               "and": {
                   "equal": [
                       {
                           "name": "nodeId",
                           "value": neId
                       },
                       {
                          "name": "terminatingPortDisplayedName",
                          "value": portName
                      }
                  ]
               }
           },
          "resultFilter": {
              "children": "",
              "attribute": [
                  "terminatedObjectPointer"
              ]
          }
     };
     let nfmpFwk = new NfmpFwk();
     let result = {};
     let resultFetch = nfmpFwk.post("/v3/search", searchObject);
     let finalResponse = JSON.parse(resultFetch.response);
     finalResponse = finalResponse[className];
     logger.info(JSON.stringify(finalResponse));
     return finalResponse["terminatedObjectPointer"];
    }

    this.getPortName = function (portPointer) {
     let className = "netw.PhysicalInterfaceCtp";
     let searchObject = {
           "fullClassName": className,
           "filter": {
               "and": {
                   "equal": [
                       {
                          "name": "terminatedObjectPointer",
                          "value": portPointer
                      }
                  ]
               }
           },
          "resultFilter": {
              "children": "",
              "attribute": [
                  "terminatingPortDisplayedName"
              ]
          }
     };
     let nfmpFwk = new NfmpFwk();
     let result = {};
     let resultFetch = nfmpFwk.post("/v3/search", searchObject);
     let finalResponse = JSON.parse(resultFetch.response);
     finalResponse = finalResponse[className];
     logger.info(JSON.stringify(finalResponse));
     return finalResponse["terminatingPortDisplayedName"];
    }
    this.getSrlgPointers = function (neId) {
       let className = "rtr.SharedRiskLinkGroup";
       let searchObject = {
           "fullClassName": className,
           "filter": {
               "and": {
                   "equal": [
                       {
                          "name": "isLocal",
                          "value": true
                       }
                   ]
               }
           },
           "resultFilter": {
               "children": "",
               "attribute": [
                   "displayedName"
               ]
           }
       };
       return this.getData(searchObject, className, "displayedName");
    };
    
    this.getEgressRemarkPolicy = function (neId) {
       let className = "ixrqos.EgressRemarkPolicy";
       let searchObject = {
           "fullClassName": className,
           "filter": {
               "and": {
                   "equal": [
                       {
                          "name": "siteId",
                          "value": neId
                       },
                       {
                          "name": "isLocal",
                          "value": true
                       }
                   ]
               }
           },
           "resultFilter": {
               "children": "",
               "attribute": [
                   "displayedName"
               ]
           }
       };
       return this.getData(searchObject, className, "displayedName");
    };
    
    this.getVlanQosPolicy = function (neId) {
       let className = "ixrqos.VlanQosPolicy";
       let searchObject = {
           "fullClassName": className,
           "filter": {
               "and": {
                   "equal": [
                       {
                          "name": "siteId",
                          "value": neId
                       },
                       {
                          "name": "isLocal",
                          "value": true
                       }
                   ]
               }
           },
           "resultFilter": {
               "children": "",
               "attribute": [
                   "displayedName"
               ]
           }
       };
       return this.getData(searchObject, className, "displayedName");
    };
    
    this.getNetworkIngressPolicy = function (neId) {
       let className = "ixrqos.NetworkIngressPolicy";
       let searchObject = {
           "fullClassName": className,
           "filter": {
               "and": {
                   "equal": [
                       {
                          "name": "siteId",
                          "value": neId
                       },
                       {
                          "name": "isLocal",
                          "value": true
                       }
                   ]
               }
           },
           "resultFilter": {
               "children": "",
               "attribute": [
                   "displayedName"
               ]
           }
       };
       return this.getData(searchObject, className, "displayedName");
    };
    
    this.getIPFilter = function (neId) {
       let className = "aclfilter.IpFilter";
       let searchObject = {
           "fullClassName": className,
           "filter": {
               "and": {
                   "equal": [
                       {
                          "name": "siteId",
                          "value": neId
                       },
                       {
                          "name": "isLocal",
                          "value": true
                       }
                   ]
               }
           },
           "resultFilter": {
               "children": "",
               "attribute": [
                   "id"
               ]
           }
       };
       return this.getData(searchObject, className, "id");
    };
    
    this.getIPv6Filter = function (neId) {
       let className = "aclfilter.Ipv6Filter";
       let searchObject = {
           "fullClassName": className,
           "filter": {
               "and": {
                   "equal": [
                       {
                          "name": "siteId",
                          "value": neId
                       },
                       {
                          "name": "isLocal",
                          "value": true
                       }
                   ]
               }
           },
           "resultFilter": {
               "children": "",
               "attribute": [
                   "id"
               ]
           }
       };
       return this.getData(searchObject, className, "id");
    };

    this.getVrrpPolicyPointer = function (neId) {
           let className = "vrrp.Policy";
           let searchObject = {
               "fullClassName": className,
               "filter": {
                   "and": {
                       "equal": [
                           {
                              "name": "isLocal",
                              "value": false
                           },
                           {
                             "name": "isBackup",
                             "value": false
                          }
                       ]
                   }
               },
               "resultFilter": {
                   "children": "",
                   "attribute": [
                       "displayedName"
                   ]
               }
           };
           return this.getData(searchObject, className, "displayedName");
        };

    this.getVrrpPolicyPointerFdn = function (neId, vrrpDisplayName) {
            //format of PolicyPointer VRRP:<ID>
         let className = "vrrp.Policy";
         let searchObject = {
               "fullClassName": className,
               "filter": {
                   "and": {
                       "equal": [
                           {
                               "name": "displayedName",
                               "value": vrrpDisplayName
                           },
                           {
                             "name": "isLocal",
                             "value": false
                          },
                          {
                            "name": "isBackup",
                            "value": false
                         }
                      ]
                   }
               },
              "resultFilter": {
                  "children": "",
                  "attribute": [
                      "id"
                  ]
              }
         };
         let nfmpFwk = new NfmpFwk();
         let result = {};
         let resultFetch = nfmpFwk.post("/v3/search", searchObject);
         let finalResponse = JSON.parse(resultFetch.response);
         finalResponse = finalResponse[className];
         logger.info(JSON.stringify(finalResponse));
         return finalResponse["id"];
    };

    this.getVrrpPolicyPointerdisplayedName = function (vrrpPolicyPointer) {
             let className = "vrrp.Policy";
             let searchObject = {
                   "fullClassName": className,
                   "filter": {
                       "and": {
                           "equal": [
                               {
                                   "name": "objectFullName",
                                   "value": vrrpPolicyPointer
                               }
                                                         ]
                       }
                   },
                  "resultFilter": {
                      "children": "",
                      "attribute": [
                          "displayedName"
                      ]
                  }
             };
             let nfmpFwk = new NfmpFwk();
             let result = {};
             let resultFetch = nfmpFwk.post("/v3/search", searchObject);
             let finalResponse = JSON.parse(resultFetch.response);
             finalResponse = finalResponse[className];
             logger.info(JSON.stringify(finalResponse));
             return finalResponse["displayedName"];
        };

    this.getMemberOperGroupName = function (neId) {
               let className = "service.OperGroup";
               let searchObject = {
                   "fullClassName": className,
                   "filter": {
                       "and": {
                           "equal": [
                               {
                                   "name": "siteId",
                                   "value": neId
                               }
                           ]
                       }
                   },
                   "resultFilter": {
                       "children": "",
                       "attribute": [
                           "groupName"
                       ]
                   }
               };
               return this.getData(searchObject, className, "groupName");
            };

    this.getMonitorOperGroupName = function(neId){
        return this.getMemberOperGroupName(neId);
    }

    this.getAdminGroups = function (neId) {
        let className = "rtr.AdminGroupPolicy";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName",
                    "value"
                ]
            }
        };
        return this.getAdminGroupPolicyData(searchObject, className, "displayedName", "value")
    }

    this.getFormattedAdminGroupData = function (values,neId) {
        let className = "rtr.AdminGroupPolicy";

        function createFilterObject(values) {
            return {
                or: {
                equal: values.map(str => ({
                    name: "value",
                    value: str
                }))
                }
            };
        };

        let searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ],
                    "or": createFilterObject(values)["or"]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName",
                    "value"
                ]
            }
        };

        return this.getAdminGroupPolicyData(searchObject, className, "displayedName", "value")
    }

    this.getAdminGroupPolicyData = function (searchObjectJson, className, type1,type2) {
        var nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    if(Number(value[type2])<=255)
                    ret.push(value[type1]+"("+value[type2]+")");
                })
            }
        }

        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }
}
