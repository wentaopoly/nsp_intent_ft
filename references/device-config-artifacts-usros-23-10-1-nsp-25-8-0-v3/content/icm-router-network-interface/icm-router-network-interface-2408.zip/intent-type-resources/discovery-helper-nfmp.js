var RuntimeException = Java.type('java.lang.RuntimeException');

load({
    script: resourceProvider.getResource("nfmp-fwk.js"),
    name: "NfmpFwk"
});
load({
    script: resourceProvider.getResource('parse-target.js'),
    name: 'ParseTarget'
});


function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();

    this.getDeviceConfiguration = function(target, initialPropertyName) 
    {
        let neId = parseTarget.getNeIdFromTarget(target);
        let interfaceName = parseTarget.getUniqueIdentifier(target);
        let searchPayLoad = this.constructSearchString(neId, interfaceName);
        let searchResponse = nfmpFwk.find(neId, searchPayLoad);
        logger.info(JSON.stringify(searchResponse));
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                throw new RuntimeException("Failed to get Network Interface :" + interfaceName+ "info from nfm-p for Ne " + neId );
            if(JSON.parse(searchResponse["response"]).length === 0)
                throw new RuntimeException("There is no Network Interface: "+ interfaceName + " on NE:" + neId );
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse[0];

    }

    this.extractDeviceConfig = function(defaultTargetData, deviceConfig, initialPropertyName, intfName )
    {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        let interfaceId = 0;
        let neId = "";
        let interfaceName = ""

        let interfaceConfig = deviceConfig['properties'];
        if (null !== interfaceConfig)
        {
            this.extractNetworkInterfaceProperties(parsedDefaultTargetData, interfaceConfig);
            interfaceId = interfaceConfig['id'];
            neId = interfaceConfig['nodeId'];
            interfaceName = interfaceConfig['displayedName'];

            if(interfaceConfig["loopbackEnabled"] == "true")
            {
                parsedDefaultTargetData["interface"]["port-binding"] = "loopback"
                parsedDefaultTargetData["interface"]["loopback"] = [null];
            }
            else
            {
                parsedDefaultTargetData["interface"]["port-binding"] = "port"
                if(interfaceConfig["portName"] && interfaceConfig["portName"] != "N/A")
                {
                    parsedDefaultTargetData["interface"]["port"] = interfaceConfig["portName"].replace("Port ", "").replace("Lag ","");
                    parsedDefaultTargetData["interface"]["inner-tag"] = interfaceConfig["innerEncapValue"];
                    parsedDefaultTargetData["interface"]["outer-tag"] = interfaceConfig["outerEncapValue"];
                }
            }
        }
        let childrenConfig = deviceConfig["children"];
        if (null !== childrenConfig && childrenConfig.length !== 0)
        {

            let primaryIpAddressData = parsedDefaultTargetData['interface']['ipv4']['primary'];
            if (primaryIpAddressData !== null)
            {
                let primaryIpAddress = this.extractPrimaryIpAddressData(primaryIpAddressData, childrenConfig);
                parsedDefaultTargetData['interface']['ipv4']['primary'] = primaryIpAddress;
            }

            let ipAddressData = parsedDefaultTargetData['interface']['ipv4']['secondary'];
            if (ipAddressData !== null && Array.isArray(ipAddressData) && ipAddressData.length !== 0)
            {
                let ipAddressArray = this.extractIpAddressData(ipAddressData, childrenConfig);
                if(ipAddressArray.length != 0)
                {
                    parsedDefaultTargetData['interface']['ipv4']['secondary'] = ipAddressArray;
                }
                else
                {
                    parsedDefaultTargetData['interface']['ipv4']['secondary'] = undefined;
                }
            }

            let ipv6AddressData = parsedDefaultTargetData['interface']['ipv6']['address'];
            if (ipv6AddressData !== null && Array.isArray(ipv6AddressData) && ipv6AddressData.length !== 0)
            {
                let ipv6AddressArray = this.extractIpv6AddressData(ipv6AddressData, childrenConfig);
                if(ipv6AddressArray.length != 0)
                {
                    parsedDefaultTargetData['interface']['ipv6']['address'] = ipv6AddressArray;
                }
                else
                {
                    parsedDefaultTargetData['interface']['ipv6']['address'] = undefined;
                }
            }

            let bfdConfigData = parsedDefaultTargetData['interface']['ipv4']['bfd'];
            if (bfdConfigData !== null)
            {
                let bfdConfig = this.extractBfdConfigData(bfdConfigData, childrenConfig);
                parsedDefaultTargetData['interface']['ipv4']['bfd'] = bfdConfig;
            }

            let bfdV6ConfigData = parsedDefaultTargetData['interface']['ipv6']['bfd'];
            if (bfdV6ConfigData !== null)
            {
                let bfdV6Config = this.extractBfdV6ConfigData(bfdV6ConfigData, childrenConfig);
                parsedDefaultTargetData['interface']['ipv6']['bfd'] = bfdV6Config;
            }
        }

        let ospfInterfaceSearchString = this.constructOspfInterfaceSearchString(neId, interfaceId, 2);
        let ospfInterfaceSearchResponse = nfmpFwk.find(neId, ospfInterfaceSearchString);
        logger.info(JSON.stringify(ospfInterfaceSearchResponse));
        if (!(ospfInterfaceSearchResponse.success && JSON.parse(ospfInterfaceSearchResponse["response"]).length !== 0))
        {
            if(!(ospfInterfaceSearchResponse.success))
                logger.info("Failed to get OSPF Interface :" + interfaceName+ "info from nfm-p for Ne " + neId );
            if(JSON.parse(ospfInterfaceSearchResponse["response"]).length === 0)
                logger.info("There is no OSPF Interface: "+ interfaceName + "on NE:" + neId );
            parsedDefaultTargetData['ospf'] = undefined;
        }
        else
        {
            ospfInterfaceSearchResponse = JSON.parse(ospfInterfaceSearchResponse["response"]);
            let ospfInterfaceConfig = ospfInterfaceSearchResponse[0];

            parsedDefaultTargetData['ospf'][0]['ospf-instance'] = ospfInterfaceConfig['properties']['instanceIndex'];
            parsedDefaultTargetData['ospf'][0]['area'][0]['area-id'] = ospfInterfaceConfig['properties']['areaId'];
            parsedDefaultTargetData['ospf'][0]['area'][0]['interface'][0]['interface-name'] = interfaceName;
            if(ospfInterfaceConfig['properties']['administrativeState'] == "ospfInterfaceEnabled")
            {
                parsedDefaultTargetData['ospf'][0]['area'][0]['interface'][0]['admin-state'] = "enable";
            }
            else
            {
                parsedDefaultTargetData['ospf'][0]['area'][0]['interface'][0]['admin-state'] = "disable";
            }
            let ospfInterfacetype = ospfInterfaceConfig['properties']['interfaceType'];

            if(ospfInterfacetype == "pointToPoint")
            {
                parsedDefaultTargetData['ospf'][0]['area'][0]['interface'][0]['interface-type'] = "point-to-point";
            }
            else if(ospfInterfacetype == "nbma")
            {
                parsedDefaultTargetData['ospf'][0]['area'][0]['interface'][0]['interface-type'] = "non-broadcast";
            }
            else
            {
                parsedDefaultTargetData['ospf'][0]['area'][0]['interface'][0]['interface-type'] = ospfInterfacetype;
            }
            if(ospfInterfaceConfig['properties']['metric'] != 0)
            {
                parsedDefaultTargetData['ospf'][0]['area'][0]['interface'][0]['metric'] = ospfInterfaceConfig['properties']['metric'];
            }
            if(ospfInterfaceConfig['properties']['mtu'] != 0)
            {
                parsedDefaultTargetData['ospf'][0]['area'][0]['interface'][0]['mtu'] = ospfInterfaceConfig['properties']['mtu'];
            }
            if(ospfInterfaceConfig['properties']['helloInterval'] != 0)
            {
                parsedDefaultTargetData['ospf'][0]['area'][0]['interface'][0]['hello-interval'] = ospfInterfaceConfig['properties']['helloInterval'];
            }
            if(ospfInterfaceConfig['properties']['routerDeadInterval'] != 0)
            {
                parsedDefaultTargetData['ospf'][0]['area'][0]['interface'][0]['dead-interval'] = ospfInterfaceConfig['properties']['routerDeadInterval'];
            }
        }

        let ospf3InterfaceSearchString = this.constructOspfInterfaceSearchString(neId, interfaceId, 3);
        let ospf3InterfaceSearchResponse = nfmpFwk.find(neId, ospf3InterfaceSearchString);
        logger.info(JSON.stringify(ospf3InterfaceSearchResponse));
        if (!(ospf3InterfaceSearchResponse.success && JSON.parse(ospf3InterfaceSearchResponse["response"]).length !== 0))
        {
            if(!(ospf3InterfaceSearchResponse.success))
                logger.info("Failed to get OSPF Interface :" + interfaceName+ "info from nfm-p for Ne " + neId );
            if(JSON.parse(ospf3InterfaceSearchResponse["response"]).length === 0)
                logger.info("There is no OSPF Interface: "+ interfaceName + "on NE:" + neId );
            parsedDefaultTargetData['ospf3'] = undefined;
        }
        else
        {
            ospf3InterfaceSearchResponse = JSON.parse(ospf3InterfaceSearchResponse["response"]);
            let ospfInterfaceConfig = ospf3InterfaceSearchResponse[0];

            parsedDefaultTargetData['ospf3'][0]['ospf-instance'] = ospfInterfaceConfig['properties']['instanceIndex'];
            parsedDefaultTargetData['ospf3'][0]['area'][0]['area-id'] = ospfInterfaceConfig['properties']['areaId'];
            parsedDefaultTargetData['ospf3'][0]['area'][0]['interface'][0]['interface-name'] = interfaceName;
            if(ospfInterfaceConfig['properties']['administrativeState'] == "ospfInterfaceEnabled")
            {
                parsedDefaultTargetData['ospf3'][0]['area'][0]['interface'][0]['admin-state'] = "enable";
            }
            else
            {
                parsedDefaultTargetData['ospf3'][0]['area'][0]['interface'][0]['admin-state'] = "disable";
            }
            let ospf3Interfacetype = ospfInterfaceConfig['properties']['interfaceType'];

            if(ospf3Interfacetype == "pointToPoint")
            {
                parsedDefaultTargetData['ospf3'][0]['area'][0]['interface'][0]['interface-type'] = "point-to-point";
            }
            else if(ospf3Interfacetype == "nbma")
            {
                parsedDefaultTargetData['ospf3'][0]['area'][0]['interface'][0]['interface-type'] = "non-broadcast";
            }
            else
            {
                parsedDefaultTargetData['ospf3'][0]['area'][0]['interface'][0]['interface-type'] = ospf3Interfacetype;
            }

            parsedDefaultTargetData['ospf3'][0]['area'][0]['interface'][0]['interface-name'] = interfaceName;

            if(ospfInterfaceConfig['properties']['metric'] != 0)
            {
                parsedDefaultTargetData['ospf3'][0]['area'][0]['interface'][0]['metric'] = ospfInterfaceConfig['properties']['metric'];
            }
            if(ospfInterfaceConfig['properties']['mtu'] != 0)
            {
                parsedDefaultTargetData['ospf3'][0]['area'][0]['interface'][0]['mtu'] = ospfInterfaceConfig['properties']['mtu'];
            }
            if(ospfInterfaceConfig['properties']['helloInterval'] != 0)
            {
                parsedDefaultTargetData['ospf3'][0]['area'][0]['interface'][0]['hello-interval'] = ospfInterfaceConfig['properties']['helloInterval'];
            }
            if(ospfInterfaceConfig['properties']['routerDeadInterval'] != 0)
            {
                parsedDefaultTargetData['ospf3'][0]['area'][0]['interface'][0]['dead-interval'] = ospfInterfaceConfig['properties']['routerDeadInterval'];
            }

        }

        let ldpInterfaceSearchString = this.constructLdpInterfaceSearchString(neId, interfaceId);
        let ldpInterfaceSearchResponse = nfmpFwk.find(neId, ldpInterfaceSearchString);
        logger.info(JSON.stringify(ldpInterfaceSearchResponse));
        if (!(ldpInterfaceSearchResponse.success && JSON.parse(ldpInterfaceSearchResponse["response"]).length !== 0))
        {
            if(!(ldpInterfaceSearchResponse.success))
                logger.info("Failed to get LDP Interface :" + interfaceName+ "info from nfm-p for Ne " + neId );
            if(JSON.parse(ldpInterfaceSearchResponse["response"]).length === 0)
                logger.info("There is no LDP Interface: "+ interfaceName + "on NE:" + neId );
            parsedDefaultTargetData['ldp'] = undefined;
        }
        else
        {
            ldpInterfaceSearchResponse = JSON.parse(ldpInterfaceSearchResponse["response"]);
            let ldpInterfaceConfig = ldpInterfaceSearchResponse[0];

            parsedDefaultTargetData['ldp']['interface-parameters']['interface'][0]['ip-int-name'] = interfaceName;
            if(ldpInterfaceConfig['properties']['administrativeState'] == "tmnxInService")
            {
                parsedDefaultTargetData['ldp']['interface-parameters']['interface'][0]['admin-state'] = "enable";
            }
            else
            {
                parsedDefaultTargetData['ldp']['interface-parameters']['interface'][0]['admin-state'] = "disable";
            }
        }

        let mplsInterfaceSearchString = this.constructMplsInterfaceSearchString(neId, interfaceId);
        let mplsInterfaceSearchResponse = nfmpFwk.find(neId, mplsInterfaceSearchString);
        logger.info(JSON.stringify(mplsInterfaceSearchResponse));
        if (!(mplsInterfaceSearchResponse.success && JSON.parse(mplsInterfaceSearchResponse["response"]).length !== 0))
        {
            if(!(mplsInterfaceSearchResponse.success))
                logger.info("Failed to get MPLS Interface :" + interfaceName+ "info from nfm-p for Ne " + neId );
            if(JSON.parse(mplsInterfaceSearchResponse["response"]).length === 0)
                logger.info("There is no MPLS Interface: "+ interfaceName + "on NE:" + neId );
            parsedDefaultTargetData['mpls'] = undefined;
        }
        else
        {
            mplsInterfaceSearchResponse = JSON.parse(mplsInterfaceSearchResponse["response"]);
            let mplsInterfaceConfig = mplsInterfaceSearchResponse[0];

            parsedDefaultTargetData['mpls']['interface'][0]['interface-name'] = interfaceName;
            if(mplsInterfaceConfig['properties']['administrativeState'] == "mplsUp")
            {
                parsedDefaultTargetData['mpls']['interface'][0]['admin-state'] = "enable";
            }
            else
            {
                parsedDefaultTargetData['mpls']['interface'][0]['admin-state'] = "disable";
            }
        }

        let rsvpInterfaceSearchString = this.constructRsvpInterfaceSearchString(neId, interfaceId);
        let rsvpInterfaceSearchResponse = nfmpFwk.find(neId, rsvpInterfaceSearchString);
        logger.info(JSON.stringify(rsvpInterfaceSearchResponse));
        if (!(rsvpInterfaceSearchResponse.success && JSON.parse(rsvpInterfaceSearchResponse["response"]).length !== 0))
        {
            if(!(rsvpInterfaceSearchResponse.success))
                logger.info("Failed to get RSVP Interface :" + interfaceName+ "info from nfm-p for Ne " + neId );
            if(JSON.parse(rsvpInterfaceSearchResponse["response"]).length === 0)
                logger.info("There is no RSVP Interface: "+ interfaceName + "on NE:" + neId );
            parsedDefaultTargetData['rsvp'] = undefined;
        }
        else
        {
            rsvpInterfaceSearchResponse = JSON.parse(rsvpInterfaceSearchResponse["response"]);
            let rsvpInterfaceConfig = rsvpInterfaceSearchResponse[0];

            parsedDefaultTargetData['rsvp']['interface'][0]['interface-name'] = interfaceName;
            if(rsvpInterfaceConfig['properties']['administrativeState'] == "rsvpIfUp")
            {
                parsedDefaultTargetData['rsvp']['interface'][0]['admin-state'] = "enable";
            }
            else
            {
                parsedDefaultTargetData['rsvp']['interface'][0]['admin-state'] = "disable";
            }
            if(rsvpInterfaceConfig['properties']['bfdEnabled'] == "true")
            {
                parsedDefaultTargetData['rsvp']['interface'][0]['bfd-liveness'] = true;
            }
            else
            {
                parsedDefaultTargetData['rsvp']['interface'][0]['bfd-liveness'] = false;
            }
            if(rsvpInterfaceConfig['properties']['helloInterval'])
            {
                parsedDefaultTargetData['rsvp']['interface'][0]['hello-interval'] =
                    parseInt(rsvpInterfaceConfig['properties']['helloInterval'], 10) / 1000;
            }

            if(rsvpInterfaceConfig['properties']['enableRefreshReduction'] == "true")
            {
                parsedDefaultTargetData['rsvp']['interface'][0]['refresh-reduction'] = new Object();
            }
            if(rsvpInterfaceConfig['properties']['enableReliableDelivery'] == "true")
            {
                parsedDefaultTargetData['rsvp']['interface'][0]['refresh-reduction']['reliable-delivery'] = true;
            }
        }

        let isisInterfaceSearchString = this.constructIsisInterfaceSearchString(neId, interfaceId);
        let isisInterfaceSearchResponse = nfmpFwk.find(neId, isisInterfaceSearchString);
        logger.info(JSON.stringify(isisInterfaceSearchResponse));
        if (!(isisInterfaceSearchResponse.success && JSON.parse(isisInterfaceSearchResponse["response"]).length !== 0))
        {
            if(!(isisInterfaceSearchResponse.success))
                logger.info("Failed to get ISIS Interface :" + interfaceName+ "info from nfm-p for Ne " + neId );
            if(JSON.parse(isisInterfaceSearchResponse["response"]).length === 0)
                logger.info("There is no ISIS Interface: "+ interfaceName + "on NE:" + neId );
            parsedDefaultTargetData['isis'] = undefined;
        }
        else
        {
            isisInterfaceSearchResponse = JSON.parse(isisInterfaceSearchResponse["response"]);
            let isisInterfaceConfig = isisInterfaceSearchResponse[0];

            parsedDefaultTargetData['isis'][0]['isis-instance'] = isisInterfaceConfig['properties']['instanceIndex'];
            parsedDefaultTargetData['isis'][0]['interface'][0]['interface-name'] = interfaceName;
            let isisAdminState = isisInterfaceConfig['properties']['administrativeState'];
            if(isisAdminState == 'isisUp')
            {
                parsedDefaultTargetData['isis'][0]['interface'][0]['admin-state'] = 'enable';
            }
            else
            {
                parsedDefaultTargetData['isis'][0]['interface'][0]['admin-state'] = 'disable';
            }

            parsedDefaultTargetData['isis'][0]['interface'][0]['bfd-liveness']['bfd-liveness.ipv4'] = undefined;
            parsedDefaultTargetData['isis'][0]['interface'][0]['bfd-liveness']['bfd-liveness.ipv6'] = undefined;
            if(isisInterfaceConfig['properties']['bfdEnabled'] == "true")
            {
                parsedDefaultTargetData['isis'][0]['interface'][0]['bfd-liveness']['ipv4'] = new Object();
                if(isisInterfaceConfig['properties']['ipv4IncludeBfdTlv'] == "true")
                {
                    parsedDefaultTargetData['isis'][0]['interface'][0]['bfd-liveness']['ipv4']['include-bfd-tlv'] = true;
                }
                else
                {
                    parsedDefaultTargetData['isis'][0]['interface'][0]['bfd-liveness']['ipv4']['include-bfd-tlv'] = false;
                }
            }
            else
            {
                parsedDefaultTargetData['isis'][0]['interface'][0]['bfd-liveness']['ipv4'] = undefined;
            }

            if(isisInterfaceConfig['properties']['ipv6BfdEnabled'] == "true")
            {
                parsedDefaultTargetData['isis'][0]['interface'][0]['bfd-liveness']['ipv6'] = new Object();
                if(isisInterfaceConfig['properties']['ipv6IncludeBfdTlv'] == "true")
                {
                    parsedDefaultTargetData['isis'][0]['interface'][0]['bfd-liveness']['ipv6']['include-bfd-tlv'] = true;
                }
                else
                {
                    parsedDefaultTargetData['isis'][0]['interface'][0]['bfd-liveness']['ipv6']['include-bfd-tlv'] = false;
                }
            }
            else
            {
                parsedDefaultTargetData['isis'][0]['interface'][0]['bfd-liveness']['ipv6'] = undefined;
            }

            parsedDefaultTargetData['isis'][0]['interface'][0]['csnp-interval'] = isisInterfaceConfig['properties']['csnpInterval'];

            let levelCapability = isisInterfaceConfig['properties']['levelCapability'];

            if(levelCapability == "level_1")
            {
                parsedDefaultTargetData['isis'][0]['interface'][0]['level-capability'] = "1";
            }
            else if(levelCapability == "level_2")
            {
                parsedDefaultTargetData['isis'][0]['interface'][0]['level-capability'] = "2";
            }
            else
            {
                parsedDefaultTargetData['isis'][0]['interface'][0]['level-capability'] = "1/2";
            }

            let interfaceType = isisInterfaceConfig['properties']['interfaceType'];

            if(interfaceType == 'point_to_point')
            {
                parsedDefaultTargetData['isis'][0]['interface'][0]['interface-type'] = "point-to-point";
            }
            else
            {
                parsedDefaultTargetData['isis'][0]['interface'][0]['interface-type'] = "broadcast";
            }

            let childrenConfig = isisInterfaceConfig["children"];
            if (null !== childrenConfig && childrenConfig.length !== 0)
            {
                for (let i = 0; i < childrenConfig.length; i++)
                {
                    let childConfig = childrenConfig[i];
                    let childClass = childConfig['fullClassName'];

                    if (childClass !== null)
                    {
                        if(childClass === 'isis.AuthenticationKey')
                        {
                            let authenticationType = childConfig['properties']['type'];
                            if(authenticationType == 'password')
                            {
                                parsedDefaultTargetData['isis'][0]['interface'][0]['hello-authentication-type'] = "password";
                            }
                            else if(authenticationType == 'md5')
                            {
                                parsedDefaultTargetData['isis'][0]['interface'][0]['hello-authentication-type'] = "message-digest";
                            }
                            else
                            {
                                parsedDefaultTargetData['isis'][0]['interface'][0]['hello-authentication-type'] = undefined;
                            }
                        }
                        if(childClass === 'isis.InterfaceLevelOneConfig')
                        {
                            parsedDefaultTargetData['isis'][0]['interface'][0]['level'][0] = new Object();
                            parsedDefaultTargetData['isis'][0]['interface'][0]['level'][0]['level-number'] = "1";
                            if(childConfig['properties']['adminMetric'] && childConfig['properties']['adminMetric'] != 0)
                            {
                                parsedDefaultTargetData['isis'][0]['interface'][0]['level'][0]['metric'] = childConfig['properties']['adminMetric'];
                            }
                        }
                        if(childClass === 'isis.InterfaceLevelTwoConfig')
                        {
                            parsedDefaultTargetData['isis'][0]['interface'][0]['level'][1] = new Object();
                            parsedDefaultTargetData['isis'][0]['interface'][0]['level'][1]['level-number'] = "2";
                            if(childConfig['properties']['adminMetric'] && childConfig['properties']['adminMetric'] != 0)
                            {
                                parsedDefaultTargetData['isis'][0]['interface'][0]['level'][1]['metric'] = childConfig['properties']['adminMetric'];
                            }
                        }
                    }
                }
            }
        }

        return parsedDefaultTargetData;
    }

    this.extractNetworkInterfaceProperties = function(defaultTargetData, interfaceConfig)
    {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object')
            {
                let mappings = modelDeviceMapping.getMapping("networkInterface");
                this.traverseAndUpdateConfig(targetKey, targetObj, interfaceConfig, mappings);
            }
        }
    }
    
    this.extractPrimaryIpAddressData = function(defaultPrimaryAddressData, childrenConfig)
    {
        let primaryAddFound = false;
        let primaryAddressDefaults = defaultPrimaryAddressData;
        let primaryAddressData = JSON.parse(JSON.stringify(primaryAddressDefaults));
        let mappings = modelDeviceMapping.getMapping("primaryIpAddress");
        for (let i = 0; i < childrenConfig.length; i++)
        {
            let childConfig = childrenConfig[i];
            let childClass = childConfig['fullClassName'];

            if (childClass !== null && childClass === 'rtr.VirtualRouterIpAddress')
            {
                let ipAddrIndex = childConfig['properties']['index']
                if( ipAddrIndex === "1")
                {
                    this.traverseAndUpdateConfig('interface.ipv4.primary', primaryAddressData, childConfig['properties'], mappings);
                    primaryAddFound = true;
                }
            }
        }
        if(!primaryAddFound)
        {
            primaryAddressData = undefined;
        }
        return primaryAddressData;
    }

    this.extractIpAddressData = function(defaultIpAddressData, childrenConfig)
    {
        let ipAddressArray = [];
        let ipAddressDefaults = defaultIpAddressData[0];
        let mappings = modelDeviceMapping.getMapping("ipAddress");
        for (let i = 0; i < childrenConfig.length; i++)
        {
            let childConfig = childrenConfig[i];
            let childClass = childConfig['fullClassName'];
            let ipAddType = childConfig['properties']['ipAddressType'];
            let ipAddrIndex = childConfig['properties']['index']
            if (childClass !== null && childClass === 'rtr.VirtualRouterIpAddress' && ipAddType === "ipv4" && ipAddrIndex !== "1")
            {
                let ipAddressData = JSON.parse(JSON.stringify(ipAddressDefaults));
                this.traverseAndUpdateConfig('interface.ipv4.secondary', ipAddressData, childConfig['properties'], mappings);
                ipAddressArray.push(ipAddressData);
            }
        }
        return ipAddressArray;
    }
    this.extractIpv6AddressData = function(defaultIpv6AddressData, childrenConfig)
    {
        let ipv6AddressArray = [];
        let ipv6AddressDefaults = defaultIpv6AddressData[0];
        let mappings = modelDeviceMapping.getMapping("ipv6Address");
        for (let i = 0; i < childrenConfig.length; i++)
        {
            let childConfig = childrenConfig[i];
            let childClass = childConfig['fullClassName'];
            let ipAddType = childConfig['properties']['ipAddressType'];
            if (childClass !== null && childClass === 'rtr.VirtualRouterIpAddress' && ipAddType === "ipv6")
            {
                let ipv6AddressData = JSON.parse(JSON.stringify(ipv6AddressDefaults));
                this.traverseAndUpdateConfig('interface.ipv6.address', ipv6AddressData, childConfig['properties'], mappings);
                ipv6AddressArray.push(ipv6AddressData);
            }
        }
        return ipv6AddressArray;
    }
    this.extractBfdConfigData = function(defaultBfdData, childrenConfig)
    {
        let bfdConfigDefaults = defaultBfdData;
        let bfdFound = false;
        let bfdConfigData = JSON.parse(JSON.stringify(bfdConfigDefaults));
        let mappings = modelDeviceMapping.getMapping("bfdConfig");
        for (let i = 0; i < childrenConfig.length; i++)
        {
            let childConfig = childrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass === 'bfd.BfdConfig')
            {
                this.traverseAndUpdateConfig('interface.ipv4.bfd', bfdConfigData, childConfig['properties'], mappings);
                bfdFound = true;
            }
        }
        if(!bfdFound)
        {
            bfdConfigData = undefined;
        }
        return bfdConfigData;
    }
    this.extractBfdV6ConfigData = function(defaultBfdV6Data, childrenConfig)
    {
        let bfdV6ConfigDefaults = defaultBfdV6Data;
        let bfdFound = false;
        let bfdV6ConfigData = JSON.parse(JSON.stringify(bfdV6ConfigDefaults));
        let mappings = modelDeviceMapping.getMapping("bfdV6Config");
        for (let i = 0; i < childrenConfig.length; i++)
        {
            let childConfig = childrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass === 'bfd.BfdV6Config')
            {
                this.traverseAndUpdateConfig('interface.ipv6.bfd', bfdV6ConfigData, childConfig['properties'], mappings);
                bfdFound = true;
            }
        }
        if(!bfdFound)
        {
            bfdV6ConfigData = undefined;
        }
        return bfdV6ConfigData;
    }

    this.traverseAndUpdateConfig = function(objKey, obj, parsedDeviceConfig, mappings)
    {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];

            let mappedKey = objKey + "." + key;
            if (mappedKey !== "interface.ipv4.secondary" && mappedKey !== "interface.ipv4.primary" &&
                mappedKey !== "interface.ipv4.bfd" && mappedKey !== "interface.ipv6.bfd"
                && mappedKey !== "interface.ipv6.address")
            {
                if (value != null && typeof value === 'object')
                {
                    this.traverseAndUpdateConfig(mappedKey, value, parsedDeviceConfig, mappings);
                }
                else
                {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }


    this.getAndUpdateFromDeviceConfig = function(mappings, mappedKey, targetKey, targetObj, parsedDeviceConfig) {
        // Get the key from mapping against targetKey
        // If the mapping key is not undefined, Get the value from deviceKey
        // if the value from deviceConfig against that mapping key is not n
        let nfmpKey = mappings[mappedKey];
        let deviceValue = parsedDeviceConfig[nfmpKey];

        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue, parsedDeviceConfig);

    }

    this.transformDeviceValue = function(mappedKey, deviceValue, parsedDeviceConfig) {
        if (deviceValue !== null) {
            switch (mappedKey)
            {
                case "interface.admin-state":
                    deviceValue = this.transformAdminState(deviceValue);
                    break;
                case "interface.ldp-sync-timer.seconds":
                    deviceValue = this.transformLdpSyncTimer(deviceValue);
                    break
                case "interface.cpu-protection":
                    deviceValue = this.transformCPUProtection(deviceValue);
                    break;
                case "interface.ipv4.bfd.admin-state":
                case "interface.ipv6.bfd.admin-state":
                    deviceValue = this.transformBfdAdminState(deviceValue);
                    break;
                case "interface.ipv4.bfd.type":
                case "interface.ipv6.bfd.type":
                    deviceValue = this.transformBfdType(deviceValue);
                    break;
                case "interface.egress.qos.vlan-qos-policy.policy-name":
                case "interface.egress.qos.egress-remark-policy.policy-name":
                case "interface.ingress.qos.network-ingress.policy-name":
                    deviceValue = this.transformIXRQoS(deviceValue);
                    break;
                case "interface.qos.network-policy":
                    deviceValue = deviceValue.replace("Network:", "");
                    break
                default:
            }
            return deviceValue;
        }
    }

    this.transformAdminState = function (deviceValue)
    {
        if(deviceValue === "vRtrIfUp")
        {
            return "enable"
        }
        return "disable";
    }
    this.transformLdpSyncTimer = function (deviceValue)
    {
        if(deviceValue)
        {
            if(deviceValue == "0")
            {
                return undefined;
            }
            else
            {
                return deviceValue;
            }
        }
        else
        {
            return undefined;
        }
    }

    this.transformCPUProtection = function (deviceValue)
    {
        if(deviceValue !== "")
        {
            return deviceValue.substring(deviceValue.indexOf(":")+1, deviceValue.length)
        }
        return "";
    }

    this.transformBfdAdminState = function (deviceValue)
    {
        if(deviceValue === "up")
        {
            return "enable"
        }
        return "disable";
    }

    this.transformBfdType = function (deviceValue)
    {
        if(deviceValue === "cpmNP")
        {
            return "cpm-np"
        }
        return deviceValue;
    }

    this.transformIXRQoS = function (deviceValue)
    {
        if(deviceValue)
        {
            let policy = deviceValue.split(":");
            if(policy.length == 2)
            {
                return policy[1];
            }
        }
        return undefined;
    }

    this.constructSearchString = function(neId, interfaceName)
    {
        let filterExpression = "nodeId='" + neId + "' AND routerId=1 AND displayedName='" +interfaceName+ "'";
        let jsonPayLoad = {
            "fullClassName": "rtr.NetworkInterface",
            "filter": {
                "filterExpression": filterExpression
            }
        };

        return jsonPayLoad;
    }

    this.constructOspfInterfaceSearchString = function(neId, interfaceId, version)
    {
        let filterExpression = "nodeId='" + neId + "' AND routerId=1 AND interfaceId='" +interfaceId+ "'"+ "AND version='"+version+"'";
        let jsonPayLoad = {
            "fullClassName": "ospf.Interface",
            "filter": {
                "filterExpression": filterExpression
            }
        };

        return jsonPayLoad;
    }

    this.constructLdpInterfaceSearchString = function(neId, interfaceId)
    {
        let filterExpression = "nodeId='" + neId + "' AND routerId=1 AND interfaceId='" +interfaceId+ "'";
        let jsonPayLoad = {
            "fullClassName": "ldp.Interface",
            "filter": {
                "filterExpression": filterExpression
            }
        };

        return jsonPayLoad;
    }

    this.constructMplsInterfaceSearchString = function(neId, interfaceId)
    {
        let filterExpression = "nodeId='" + neId + "' AND routerId=1 AND interfaceId='" +interfaceId+ "'";
        let jsonPayLoad = {
            "fullClassName": "mpls.Interface",
            "filter": {
                "filterExpression": filterExpression
            }
        };

        return jsonPayLoad;
    }

    this.constructRsvpInterfaceSearchString = function(neId, interfaceId)
    {
        let filterExpression = "nodeId='" + neId + "' AND routerId=1 AND interfaceId='" +interfaceId+ "'";
        let jsonPayLoad = {
            "fullClassName": "rsvp.Interface",
            "filter": {
                "filterExpression": filterExpression
            }
        };

        return jsonPayLoad;
    }

    this.constructIsisInterfaceSearchString = function(neId, interfaceId)
    {
        let filterExpression = "nodeId='" + neId + "' AND routerId=1 AND interfaceId='" +interfaceId+ "'";
        let jsonPayLoad = {
            "fullClassName": "isis.Interface",
            "filter": {
                "filterExpression": filterExpression
            }
        };

        return jsonPayLoad;
    }

    this.clearEmpties = function (o)
    {
        for (let k in o)
        {
            if (!o[k] || typeof o[k] !== "object")
            {
                continue
            }

            this.clearEmpties(o[k]);
            if (Object.keys(o[k]).length === 0)
            {
                delete o[k];
            }
        }
    }
}
