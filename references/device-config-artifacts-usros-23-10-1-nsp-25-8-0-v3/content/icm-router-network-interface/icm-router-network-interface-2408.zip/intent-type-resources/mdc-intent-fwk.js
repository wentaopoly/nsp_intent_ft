var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk'});
load({script: resourceProvider.getResource('traverse-fwk.js'), name: 'TraverseFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities" });
function MdcIntentFwk() {
    var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,5}(:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){6}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(\/(0|[1-9][0-9]?|1[0-1][0-9]?|12[0-8]))?$/;
    var util = new utilities();

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, routerTopologyObj) {
        var syncResult = undefined;
        var parseTarget = new ParseTarget();
        var target = parseTarget.getNeIdFromTarget(input.getTarget());

        if (input.getNetworkState().name() == "delete") {
            var traverseFwk = new TraverseFwk();
            traverseFwk.resetTheVariables();
            var interfaceName = parseTarget.getUniqueIdentifier(input.getTarget());
            var requests = [];

            var delintentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName]['ospf'];
            if (Array.isArray(delintentConfig)) {
                for (var i = 0; i < delintentConfig.length; i++) {
                    var obj = delintentConfig[i];
                    var areas = obj['area'];
                    if (Array.isArray(areas)) {
                        for (var j = 0; j < areas.length; j++) {
                            var area = areas[i];
                            var url = "nokia-conf:/configure/router=Base/ospf=" + obj['ospf-instance'] + "/area=" + area['area-id'] + "/interface=" + interfaceName;
                            var deleteObj = {};
                            deleteObj["operation"] = "delete";
                            deleteObj["edit-id"] = "edit-" + new Date().getTime();
                            deleteObj["target"] = url;
                            requests.push(deleteObj);
                        }
                    } else if (areas != undefined) {
                        var url = "nokia-conf:/configure/router=Base/ospf=" + obj['ospf-instance'] + "/area=" + areas['area-id'] + "/interface=" + interfaceName;
                        var deleteObj = {};
                        deleteObj["operation"] = "delete";
                        deleteObj["edit-id"] = "edit-" + new Date().getTime();
                        deleteObj["target"] = url;
                        requests.push(deleteObj);
                    }

                }
            } else if (delintentConfig != undefined) {
                var obj = delintentConfig;
                var areas = obj['area'];
                if (Array.isArray(areas)) {
                    for (var j = 0; j < areas.length; j++) {
                        var area = areas[i];
                        var url = "nokia-conf:/configure/router=Base/ospf=" + obj['ospf-instance'] + "/area=" + area['area-id'] + "/interface=" + interfaceName;
                        var deleteObj = {};
                        deleteObj["operation"] = "delete";
                        deleteObj["edit-id"] = "edit-" + new Date().getTime();
                        deleteObj["target"] = url;
                        requests.push(deleteObj);
                    }
                } else if (areas != undefined) {
                    var url = "nokia-conf:/configure/router=Base/ospf=" + obj['ospf-instance'] + "/area=" + areas['area-id'] + "/interface=" + interfaceName;
                    var deleteObj = {};
                    deleteObj["operation"] = "delete";
                    deleteObj["edit-id"] = "edit-" + new Date().getTime();
                    deleteObj["target"] = url;
                    requests.push(deleteObj);
                }
            }
            if (requests.length > 0) {
                result = traverseFwk.syncRequest(target, requests, result, routerTopologyObj.getSavedTopologyOspf());
            }

            requests = [];
            delintentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName]['ospf3'];
            if (Array.isArray(delintentConfig)) {
                for (var i = 0; i < delintentConfig.length; i++) {
                    var obj = delintentConfig[i];
                    var areas = obj['area'];
                    if (Array.isArray(areas)) {
                        for (var j = 0; j < areas.length; j++) {
                            var area = areas[i];
                            var url = "nokia-conf:/configure/router=Base/ospf3=" + obj['ospf-instance'] + "/area=" + area['area-id'] + "/interface=" + interfaceName;
                            var deleteObj = {};
                            deleteObj["operation"] = "delete";
                            deleteObj["edit-id"] = "edit-" + new Date().getTime();
                            deleteObj["target"] = url;
                            requests.push(deleteObj);
                        }
                    } else if (areas != undefined) {
                        var url = "nokia-conf:/configure/router=Base/ospf3=" + obj['ospf-instance'] + "/area=" + areas['area-id'] + "/interface=" + interfaceName;
                        var deleteObj = {};
                        deleteObj["operation"] = "delete";
                        deleteObj["edit-id"] = "edit-" + new Date().getTime();
                        deleteObj["target"] = url;
                        requests.push(deleteObj);
                    }

                }
            } else if (delintentConfig != undefined) {
                var obj = delintentConfig;
                var areas = obj['area'];
                if (Array.isArray(areas)) {
                    for (var j = 0; j < areas.length; j++) {
                        var area = areas[i];
                        var url = "nokia-conf:/configure/router=Base/ospf3=" + obj['ospf-instance'] + "/area=" + area['area-id'] + "/interface=" + interfaceName;
                        var deleteObj = {};
                        deleteObj["operation"] = "delete";
                        deleteObj["edit-id"] = "edit-" + new Date().getTime();
                        deleteObj["target"] = url;
                        requests.push(deleteObj);
                    }
                } else if (areas != undefined) {
                    var url = "nokia-conf:/configure/router=Base/ospf3=" + obj['ospf-instance'] + "/area=" + areas['area-id'] + "/interface=" + interfaceName;
                    var deleteObj = {};
                    deleteObj["operation"] = "delete";
                    deleteObj["edit-id"] = "edit-" + new Date().getTime();
                    deleteObj["target"] = url;
                    requests.push(deleteObj);
                }
            }
            if (requests.length > 0) {
                result = traverseFwk.syncRequest(target, requests, result, routerTopologyObj.getSavedTopologyOspf3());
            }

            requests = [];
            delintentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName]['isis'];
            if (Array.isArray(delintentConfig)) {
                for (var i = 0; i < delintentConfig.length; i++) {
                    var obj = delintentConfig[i];
                    var url = "nokia-conf:/configure/router=Base/isis=" + obj['isis-instance'] + "/interface=" + interfaceName;
                    var deleteObj = {};
                    deleteObj["operation"] = "delete";
                    deleteObj["edit-id"] = "edit-" + new Date().getTime();
                    deleteObj["target"] = url;
                    requests.push(deleteObj);
                }
            } else {
                if (delintentConfig) {
                    var obj = delintentConfig;
                    var url = "nokia-conf:/configure/router=Base/isis=" + obj['isis-instance'] + "/interface=" + interfaceName;
                    var deleteObj = {};
                    deleteObj["operation"] = "delete";
                    deleteObj["edit-id"] = "edit-" + new Date().getTime();
                    deleteObj["target"] = url;
                    requests.push(deleteObj);
                }
            }

            if (requests.length > 0) {
                result = traverseFwk.syncRequest(target, requests, result, routerTopologyObj.getSavedTopologyISIS());
            }

            requests = [];
            delintentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName]['ldp'];
            if (delintentConfig) {
                if (delintentConfig['interface-parameters']) {
                    if (delintentConfig['interface-parameters']['interface']) {
                        var deleteldpIntObj = {};
                        deleteldpIntObj["operation"] = "delete";
                        deleteldpIntObj["edit-id"] = "edit-" + new Date().getTime();
                        deleteldpIntObj["target"] = "nokia-conf:/configure/router=Base/ldp/interface-parameters/interface=" + interfaceName;
                        requests.push(deleteldpIntObj)
                        result = traverseFwk.syncRequest(target, requests, result, routerTopologyObj.getSavedTopologyLdp());
                    }
                }
            }

            requests = [];
            delintentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName]['mpls'];
            if (delintentConfig) {
                if (delintentConfig['interface']) {
                    var deleteMplsIntObj = {};
                    deleteMplsIntObj["operation"] = "delete";
                    deleteMplsIntObj["edit-id"] = "edit-" + new Date().getTime();
                    deleteMplsIntObj["target"] = "nokia-conf:/configure/router=Base/mpls/interface=" + interfaceName;
                    requests.push(deleteMplsIntObj);
                    var deleteRsvpIntObj = {};
                    deleteRsvpIntObj["operation"] = "delete";
                    deleteRsvpIntObj["edit-id"] = "edit-" + (new Date().getTime()+1);
                    deleteRsvpIntObj["target"] = "nokia-conf:/configure/router=Base/rsvp/interface=" + interfaceName;
                    requests.push(deleteRsvpIntObj);
                    result = traverseFwk.syncRequest(target, requests, result, routerTopologyObj.getSavedTopologyMpls());
                }
            }

            requests = [];
            var deleteObj = {};
            deleteObj["operation"] = "delete";
            deleteObj["edit-id"] = "edit-" + new Date().getTime();
            deleteObj["target"] = "nokia-conf:/configure/router=Base/interface=" + interfaceName;
            requests.push(deleteObj)

            result = traverseFwk.syncRequest(target, requests, result, routerTopologyObj.getSavedTopologyInterface());
            result.setTopology(null);

            return result;
        }

        var routerObjects = ['interface', 'ospf', 'ospf3', 'ldp', 'mpls', 'isis'];
        for (var i = 0; i < routerObjects.length; i++) {
            var routerObject = routerObjects[i];
            if (routerObject === 'interface') {

                if (target !== "0.0.0.0") {
                    var savedTopology = routerTopologyObj.getSavedTopologyInterface();
                    var traverseFwk = new TraverseFwk();
                    var intentConfig;
                    intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][routerObject];
                    logger.info("Configuring Network Interface")
                    intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());
                    if (intentConfig['port']) {
                        if (intentConfig['outer-tag']) {
                            intentConfig['port'] = intentConfig['port'] + ":" + intentConfig['outer-tag'];
                        }

                        if (intentConfig['inner-tag']) {
                            intentConfig['port'] = intentConfig['port'] + "." + intentConfig['inner-tag'];
                        }

                    }

                    delete intentConfig['port-binding'];
                    delete intentConfig['outer-tag'];
                    delete intentConfig['inner-tag'];

                    if (intentConfig) {
                        savedTopology = traverseFwk.traverse(target, intentConfig, savedTopology, null, parentXpath, routerObject);
                        routerTopologyObj.setSavedTopologyInterface(savedTopology);
                        //sorting delete array
                        var deleteRequests = traverseFwk.getDeleteRequests();
                        deleteRequests.sort(function (a, b) {
                            return b["target"].length - a["target"].length;
                        });

                        // concating createrequests and deleterequests
                        var createRequests = traverseFwk.getCreateRequests();
                        var requests;
                        if (deleteRequests && createRequests) {
                            requests = deleteRequests.concat(createRequests);
                        }
                        if (requests) {
                            syncResult = traverseFwk.syncRequest(target, requests, result, savedTopology);

                            if (syncResult['success'] == false) {
                                traverseFwk.resetTheVariables();
                                return syncResult;
                            }
                        }

                    }
                    logger.info("Network Interface Configuration done.")
                }
                traverseFwk.resetTheVariables();
            }

            if (routerObject === 'ldp') {

                if (target !== "0.0.0.0") {
                    var savedTopology = routerTopologyObj.getSavedTopologyLdp()
                    var traverseFwk = new TraverseFwk();
                    var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][routerObject];

                    if (intentConfig && intentConfig["interface-parameters"]) {
                        logger.info("Configuring Network Interface for LDP Protocol")
                        savedTopology = traverseFwk.traverse(target, intentConfig, savedTopology, null, parentXpath, routerObject);
                        routerTopologyObj.setSavedTopologyLdp(savedTopology);
                        //sorting delete array
                        var deleteRequests = traverseFwk.getDeleteRequests();
                        deleteRequests.sort(function (a, b) {
                            return b["target"].length - a["target"].length;
                        });

                        // concating createrequests and deleterequests
                        var createRequests = traverseFwk.getCreateRequests();
                        var requests;
                        if (deleteRequests && createRequests) {
                            requests = deleteRequests.concat(createRequests);
                        }
                        if (requests) {
                            syncResult = traverseFwk.syncRequest(target, requests, result, savedTopology);

                            if (syncResult['success'] == false) {
                                traverseFwk.resetTheVariables();
                                return syncResult;
                            }
                        }
                        logger.info("Network Interface for LDP protocol Configuration done. ")
                    }

                }
                traverseFwk.resetTheVariables();
            }

            if (routerObject === 'mpls') {

                if (target !== "0.0.0.0") {

                    var requests = []
                    var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][routerObject];

                    if (intentConfig === "") {
                        intentConfig = {};
                    }
                    var rsvpparentXpath = parentXpath;
                    var savedTopology = routerTopologyObj.getSavedTopologyMpls();
                    var traverseFwk = new TraverseFwk();

                    if (intentConfig) {
                        logger.info("Network Interface Configuration for MPLS Protocol")
                        savedTopology = traverseFwk.traverse(target, intentConfig, savedTopology, null, parentXpath, routerObject);
                        routerTopologyObj.setSavedTopologyMpls(savedTopology);
                        //sorting delete array
                        var deleteRequests = traverseFwk.getDeleteRequests();
                        deleteRequests.sort(function (a, b) {
                            return b["target"].length - a["target"].length;
                        });

                        // concating createrequests and deleterequests
                        var createRequests = traverseFwk.getCreateRequests();

                        if (deleteRequests && createRequests) {
                            requests = deleteRequests.concat(createRequests);
                        }
                    }

                    var rsvpintentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName]['rsvp'];
                    var traverseFwkRsvp = new TraverseFwk();
                    var savedTopologyRsvp = routerTopologyObj.getSavedTopologyRsvp();
                    if (rsvpintentConfig === "") {
                        rsvpintentConfig = {};
                    }

                    if (rsvpintentConfig) {
                        logger.info("Network Interface configuration for RSVP protocol")
                        savedTopologyRsvp = traverseFwkRsvp.traverse(target, rsvpintentConfig, savedTopologyRsvp, null, rsvpparentXpath, 'rsvp');
                        routerTopologyObj.setSavedTopologyRsvp(savedTopologyRsvp);
                        //sorting delete array
                        var rsvpdeleteRequests = traverseFwkRsvp.getDeleteRequests();
                        rsvpdeleteRequests.sort(function (a, b) {
                            return b["target"].length - a["target"].length;
                        });

                        // concating createrequests and deleterequests
                        var rsvpReq = [];
                        var rsvpcreateRequests = traverseFwkRsvp.getCreateRequests();
                        if (rsvpdeleteRequests && rsvpcreateRequests) {
                            rsvpReq = rsvpdeleteRequests.concat(rsvpcreateRequests);
                        }
                        requests = requests.concat(rsvpReq);
                    }

                    if (requests.length > 0) {
                        if (rsvpintentConfig) {
                            syncResult = traverseFwkRsvp.syncRequest(target, requests, result, savedTopologyRsvp);
                            if (syncResult['success'] == false) {
                                traverseFwkRsvp.resetTheVariables();
                                return syncResult;
                            }
                        } else {
                            syncResult = traverseFwk.syncRequest(target, requests, result, savedTopology);
                            if (syncResult['success'] == false) {
                                traverseFwk.resetTheVariables();
                                return syncResult;
                            }
                        }

                        logger.info("Network Interface for MPLS/RSVP protocol Configuration done. ")
                    }

                    traverseFwk.resetTheVariables();
                    traverseFwkRsvp.resetTheVariables();
                }
            }

            if (routerObject === 'isis') {

                if (target !== "0.0.0.0") {
                    var traverseFwk = new TraverseFwk();
                    var intentConfig;
                    intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][routerObject];

                    if (Array.isArray(intentConfig)) {

                        for (var isisI = 0; isisI < intentConfig.length; isisI++) {
                            logger.info("Network Interface configuration for ISIS protocol")
                            var isisInstance = intentConfig[isisI];
                            var savedTopology = routerTopologyObj.getSavedTopologyISIS();
                            savedTopology = traverseFwk.traverse(target, isisInstance, savedTopology, null, parentXpath, routerObject);
                            routerTopologyObj.setSavedTopologyISIS(savedTopology);

                            //sorting delete array
                            var deleteRequests = traverseFwk.getDeleteRequests();

                            var deleteReqObjects = [];
                            for (var delCount = 0; delCount < deleteRequests.length; delCount++) {
                                var delReqObj = deleteRequests[delCount];
                                var targetUrl = delReqObj['target'].split('/');
                                var cmpUrl = '';
                                for (var tCount = 0; tCount < targetUrl.length; tCount++) {
                                    cmpUrl = cmpUrl + "/" + targetUrl[tCount].split('=')[0];
                                }

                                if ("/nokia-conf:/configure/router/isis" !== cmpUrl) {
                                    deleteReqObjects.push(delReqObj)
                                }

                            }
                            deleteRequests = deleteReqObjects;

                            deleteRequests.sort(function (a, b) {
                                return b["target"].length - a["target"].length;
                            });

                            // concating createrequests and deleterequests
                            var createRequests = traverseFwk.getCreateRequests();
                            var requests;
                            if (deleteRequests && createRequests) {
                                requests = deleteRequests.concat(createRequests);
                            }
                            if (requests) {
                                syncResult = traverseFwk.syncRequest(target, requests, result, savedTopology);

                                if (syncResult['success'] == false) {
                                    traverseFwk.resetTheVariables();
                                    return syncResult;
                                }
                            }
                            logger.info("Network Interface for ISIS protocol Configuration done. ")
                            traverseFwk.resetTheVariables();

                        }
                    } else {
                        var isisInstance = intentConfig;
                        if (isisInstance) {
                            logger.info("Network Interface configuration for ISIS protocol")
                            var savedTopology = routerTopologyObj.getSavedTopologyISIS();
                            savedTopology = traverseFwk.traverse(target, isisInstance, savedTopology, null, parentXpath, routerObject);
                            routerTopologyObj.setSavedTopologyISIS(savedTopology);

                            //sorting delete array
                            var deleteRequests = traverseFwk.getDeleteRequests();

                            var deleteReqObjects = [];
                            for (var delCount = 0; delCount < deleteRequests.length; delCount++) {
                                var delReqObj = deleteRequests[delCount];
                                var targetUrl = delReqObj['target'].split('/');
                                var cmpUrl = '';
                                for (var tCount = 0; tCount < targetUrl.length; tCount++) {
                                    cmpUrl = cmpUrl + "/" + targetUrl[tCount].split('=')[0];
                                }

                                if ("/nokia-conf:/configure/router/isis" !== cmpUrl) {
                                    deleteReqObjects.push(delReqObj);
                                }

                            }
                            deleteRequests = deleteReqObjects;

                            deleteRequests.sort(function (a, b) {
                                return b["target"].length - a["target"].length;
                            });

                            // concating createrequests and deleterequests
                            var createRequests = traverseFwk.getCreateRequests();
                            var requests;
                            if (deleteRequests && createRequests) {
                                requests = deleteRequests.concat(createRequests);
                            }
                            if (requests) {
                                syncResult = traverseFwk.syncRequest(target, requests, result, savedTopology);

                                if (syncResult['success'] == false) {
                                    traverseFwk.resetTheVariables();
                                    return syncResult;
                                }
                            }
                            logger.info("Network Interface for ISIS protocol Configuration done. ")
                            traverseFwk.resetTheVariables();
                        }
                    }

                }
                traverseFwk.resetTheVariables();
            }

            if (routerObject === 'ospf') {

                if (target !== "0.0.0.0") {
                    var traverseFwk = new TraverseFwk();
                    var intentConfig;
                    intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][routerObject];

                    if (Array.isArray(intentConfig)) {

                        for (var ospfI = 0; ospfI < intentConfig.length; ospfI++) {
                            logger.info("Network Interface configuration for OSPF protocol")
                            var ospfInstance = intentConfig[ospfI];
                            var savedTopology = routerTopologyObj.getSavedTopologyOspf();
                            savedTopology = traverseFwk.traverse(target, ospfInstance, savedTopology, null, parentXpath, routerObject);
                            routerTopologyObj.setSavedTopologyOspf(savedTopology);

                            //sorting delete array
                            var deleteRequests = traverseFwk.getDeleteRequests();

                            var deleteReqObjects = [];
                            for (var delCount = 0; delCount < deleteRequests.length; delCount++) {
                                var delReqObj = deleteRequests[delCount];
                                var targetUrl = delReqObj['target'].split('/');
                                var cmpUrl = '';
                                for (var tCount = 0; tCount < targetUrl.length; tCount++) {
                                    cmpUrl = cmpUrl + "/" + targetUrl[tCount].split('=')[0];
                                }

                                if ("/nokia-conf:/configure/router/ospf" !== cmpUrl) {
                                    if ("/nokia-conf:/configure/router/ospf/area" !== cmpUrl) {
                                        deleteReqObjects.push(delReqObj)
                                    }
                                }

                            }
                            deleteRequests = deleteReqObjects;

                            deleteRequests.sort(function (a, b) {
                                return b["target"].length - a["target"].length;
                            });

                            // concating createrequests and deleterequests
                            var createRequests = traverseFwk.getCreateRequests();
                            var requests;
                            if (deleteRequests && createRequests) {
                                requests = deleteRequests.concat(createRequests);
                            }
                            if (requests) {
                                syncResult = traverseFwk.syncRequest(target, requests, result, savedTopology);

                                if (syncResult['success'] == false) {
                                    traverseFwk.resetTheVariables();
                                    return syncResult;
                                }
                            }
                            logger.info("Network Interface for OSPF protocol Configuration done. ")
                            traverseFwk.resetTheVariables();

                        }
                    } else {
                        var ospfInstance = intentConfig;
                        if (ospfInstance) {
                            logger.info("Network Interface configuration for OSPF protocol")
                            var savedTopology = routerTopologyObj.getSavedTopologyOspf();
                            savedTopology = traverseFwk.traverse(target, ospfInstance, savedTopology, null, parentXpath, routerObject);
                            routerTopologyObj.setSavedTopologyOspf(savedTopology);

                            //sorting delete array
                            var deleteRequests = traverseFwk.getDeleteRequests();

                            var deleteReqObjects = [];
                            for (var delCount = 0; delCount < deleteRequests.length; delCount++) {
                                var delReqObj = deleteRequests[delCount];
                                var targetUrl = delReqObj['target'].split('/');
                                var cmpUrl = '';
                                for (var tCount = 0; tCount < targetUrl.length; tCount++) {
                                    cmpUrl = cmpUrl + "/" + targetUrl[tCount].split('=')[0];
                                }

                                if ("/nokia-conf:/configure/router/ospf" !== cmpUrl) {
                                    if ("/nokia-conf:/configure/router/ospf/area" !== cmpUrl) {
                                        deleteReqObjects.push(delReqObj)
                                    }
                                }

                            }
                            deleteRequests = deleteReqObjects;

                            deleteRequests.sort(function (a, b) {
                                return b["target"].length - a["target"].length;
                            });

                            // concating createrequests and deleterequests
                            var createRequests = traverseFwk.getCreateRequests();
                            var requests;
                            if (deleteRequests && createRequests) {
                                requests = deleteRequests.concat(createRequests);
                            }
                            if (requests) {
                                syncResult = traverseFwk.syncRequest(target, requests, result, savedTopology);

                                if (syncResult['success'] == false) {
                                    traverseFwk.resetTheVariables();
                                    return syncResult;
                                }
                            }
                            logger.info("Network Interface for OSPF protocol Configuration done. ")
                            traverseFwk.resetTheVariables();
                        }
                    }

                }
                traverseFwk.resetTheVariables();
            }

            if (routerObject === 'ospf3') {
                if (target !== "0.0.0.0") {
                    var traverseFwk = new TraverseFwk();
                    var intentConfig;
                    intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][routerObject];

                    if (Array.isArray(intentConfig)) {
                        for (var ospf3Inst = 0; ospf3Inst < intentConfig.length; ospf3Inst++) {
                            logger.info("Network Interface configuration for OSPF3 protocol")
                            var ospf3Instance = intentConfig[ospf3Inst];
                            var savedTopology = routerTopologyObj.getSavedTopologyOspf3();
                            savedTopology = traverseFwk.traverse(target, ospf3Instance, savedTopology, null, parentXpath, routerObject);
                            routerTopologyObj.setSavedTopologyOspf3(savedTopology);
                            //sorting delete array
                            var deleteRequests = traverseFwk.getDeleteRequests();

                            var deleteReqObjects = [];
                            for (var delCount = 0; delCount < deleteRequests.length; delCount++) {
                                var delReqObj = deleteRequests[delCount];
                                var targetUrl = delReqObj['target'].split('/');
                                var cmpUrl = '';
                                for (var tCount = 0; tCount < targetUrl.length; tCount++) {
                                    cmpUrl = cmpUrl + "/" + targetUrl[tCount].split('=')[0];
                                }

                                if ("/nokia-conf:/configure/router/ospf3" !== cmpUrl) {
                                    if ("/nokia-conf:/configure/router/ospf3/area" !== cmpUrl) {
                                        deleteReqObjects.push(delReqObj)
                                    }
                                }

                            }
                            deleteRequests = deleteReqObjects;

                            deleteRequests.sort(function (a, b) {
                                return b["target"].length - a["target"].length;
                            });

                            // concating createrequests and deleterequests
                            var createRequests = traverseFwk.getCreateRequests();
                            var requests;
                            if (deleteRequests && createRequests) {
                                requests = deleteRequests.concat(createRequests);
                            }
                            if (requests) {
                                syncResult = traverseFwk.syncRequest(target, requests, result, savedTopology);

                                if (syncResult['success'] == false) {
                                    traverseFwk.resetTheVariables();
                                    return syncResult;
                                }
                            }
                            logger.info("Network Interface for OSPF3 protocol Configuration done. ")
                            traverseFwk.resetTheVariables();
                        }
                    } else {
                        var ospf3Instance = intentConfig;
                        if (ospf3Instance) {
                            logger.info("Network Interface configuration for OSPF3 protocol")
                            var savedTopology = routerTopologyObj.getSavedTopologyOspf3();
                            savedTopology = traverseFwk.traverse(target, ospf3Instance, savedTopology, null, parentXpath, routerObject);
                            routerTopologyObj.setSavedTopologyOspf3(savedTopology);
                            //sorting delete array
                            var deleteRequests = traverseFwk.getDeleteRequests();

                            var deleteReqObjects = [];
                            for (var delCount = 0; delCount < deleteRequests.length; delCount++) {
                                var delReqObj = deleteRequests[delCount];
                                var targetUrl = delReqObj['target'].split('/');
                                var cmpUrl = '';
                                for (var tCount = 0; tCount < targetUrl.length; tCount++) {
                                    cmpUrl = cmpUrl + "/" + targetUrl[tCount].split('=')[0];
                                }

                                if ("/nokia-conf:/configure/router/ospf3" !== cmpUrl) {
                                    if ("/nokia-conf:/configure/router/ospf3/area" !== cmpUrl) {
                                        deleteReqObjects.push(delReqObj)
                                    }
                                }

                            }
                            deleteRequests = deleteReqObjects;

                            deleteRequests.sort(function (a, b) {
                                return b["target"].length - a["target"].length;
                            });

                            // concating createrequests and deleterequests
                            var createRequests = traverseFwk.getCreateRequests();
                            var requests;
                            if (deleteRequests && createRequests) {
                                requests = deleteRequests.concat(createRequests);
                            }
                            if (requests) {
                                syncResult = traverseFwk.syncRequest(target, requests, result, savedTopology);

                                if (syncResult['success'] == false) {
                                    traverseFwk.resetTheVariables();
                                    return syncResult;
                                }
                            }
                            logger.info("Network Interface for OSPF3 protocol Configuration done. ")
                        }
                    }
                }
                traverseFwk.resetTheVariables();
            }
        }

        return syncResult;
    }

    this.audit = function (target, config, svcTopo, adminState, report, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, routerTopologyObj) {

        var routerObjects = ['interface', 'ospf', 'ospf3', 'ldp', 'mpls', 'rsvp', 'isis'];
        var parseTarget = new ParseTarget();
        for (var i = 0; i < routerObjects.length; i++) {
            var routerObj = routerObjects[i];
            var currentConfig = this.xml2object(config)['configuration'][intentTypeName][routerObj];
            currentConfig = this.expandIPv6(currentConfig);
            if (currentConfig) {
                var traverseFwk = new TraverseFwk();
                if (routerObj === 'interface') {
                    currentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
                    svcTopo = routerTopologyObj.getSavedTopologyInterface();
                }

                if (routerObj === 'ldp') {
                    svcTopo = routerTopologyObj.getSavedTopologyLdp();
                }

                if (routerObj === 'mpls') {
                    svcTopo = routerTopologyObj.getSavedTopologyMpls();
                }

                if (routerObj === 'rsvp') {
                    svcTopo = routerTopologyObj.getSavedTopologyRsvp();
                }

                if (routerObj === 'ospf') {
                    svcTopo = routerTopologyObj.getSavedTopologyOspf();
                }

                if (routerObj === 'ospf3') {
                    svcTopo = routerTopologyObj.getSavedTopologyOspf3();
                }

                if (routerObj === 'isis') {
                    svcTopo = routerTopologyObj.getSavedTopologyISIS();
                    delete currentConfig['interface']['hello-authentication-key'];
                }

                var targetNeId = parseTarget.getNeIdFromTarget(target);
                if (currentConfig['port']) {
                    if (currentConfig['outer-tag']) {
                        currentConfig['port'] = currentConfig['port'] + ":" + currentConfig['outer-tag'];

                        if (currentConfig['inner-tag']) {
                            currentConfig['port'] = currentConfig['port'] + "." + currentConfig['inner-tag'];
                        }
                    }
                }

                delete currentConfig['port-binding'];
                delete currentConfig['outer-tag'];
                delete currentConfig['inner-tag'];

                if (targetNeId !== "0.0.0.0") {
                    if (Array.isArray(currentConfig)) {
                        for (var r = 0; r < currentConfig.length; r++) {
                            svcTopo = traverseFwk.traverse(targetNeId, currentConfig[r], svcTopo, report, parentXpath, routerObj);
                        }

                    } else {
                        svcTopo = traverseFwk.traverse(targetNeId, currentConfig, svcTopo, report, parentXpath, routerObj);
                    }

                    // reseting the variables
                    traverseFwk.resetTheVariables();
                }
            }
        }

        return report;

    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }

    this.expandIPv6 = function (obj) {
        for (var key in obj) {
            if (typeof obj[key] === 'object' && obj[key] !== null) {
                this.expandIPv6(obj[key]);
            } else if (typeof obj[key] === 'string' && this.matchExact(ipv6Regex, obj[key])) {
                obj[key] = this.expandIPv6AddressForMd(obj[key]);
            }
        }
      return obj
    }

    this.matchExact = function(r, str) {
        var match = str.match(r);
        return match && str === match[0];
    }

    this.expandIPv6AddressForMd = function (input) {
        var expanded = util.expandIPv6ForMd(input);
        expanded = util.MdIpv6ValidAddresssMaskSupport(expanded);
        return expanded;
    };
}
