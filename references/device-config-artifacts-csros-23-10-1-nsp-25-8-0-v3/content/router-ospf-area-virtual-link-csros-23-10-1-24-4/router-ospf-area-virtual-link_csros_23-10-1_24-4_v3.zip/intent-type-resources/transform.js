function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
     if(intentConfig.instanceIndex==0){
        objectFullName = objectFullName.replace(/ospf-[^:]+-instance-[^:]+/, "ospf-v2");
      }else{
           objectFullName = objectFullName.replace(/ospf-[^:]+?(?=-instance)/,"ospf-v2");
      }
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
     let instanceIndex = uniqueIdentifierValues[0];
     let areaId = uniqueIdentifierValues[1];
     let virtualNeighborRouterId = uniqueIdentifierValues[2];
     let transitAreaId = uniqueIdentifierValues[3];
     if(instanceIndex==0){
        objectFullName= objectFullName.replace(/router-[^:]+/, "router-1").replace(/ospf-[^:]+/, "ospf-v2").replace(/areaSite-[^:]+/, `areaSite-${areaId}`).replace(/virtualLink-[^:]+/, `virtualLink-${transitAreaId}-${virtualNeighborRouterId}`);
     }else{
        objectFullName= objectFullName.replace(/router-[^:]+/, "router-1").replace(/ospf-[^:]+?(?=-instance)/,"ospf-v2").replace(/instance-[^:]+/,`instance-${instanceIndex}`).replace(/areaSite-[^:]+/, `areaSite-${areaId}`).replace(/virtualLink-[^:]+/, `virtualLink-${transitAreaId}-${virtualNeighborRouterId}`);
     }
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
      if(intentConfig.instanceIndex==0){
        fdn = fdn.replace(/ospf-[^:]+-instance-[^:]+/, "ospf-v2");
      }
      else{
        fdn=fdn.replace(/ospf-[^:]+?(?=-instance)/,"ospf-v2");
      }
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
      if (payload.configInfo) {
            if (payload.configInfo["ospf.VirtualLink"]) {
                let ospfVirtualLink = payload.configInfo["ospf.VirtualLink"];
                if (ospfVirtualLink.authKeychain) {
                  if (!ospfVirtualLink.authKeychain.toString().startsWith("KeyChain:")) {
                    let nfmpNameExtension = "KeyChain:"
                    let authKeychainData  = nfmpNameExtension + ospfVirtualLink.authKeychain;
                    ospfVirtualLink.authKeychain = authKeychainData;
                  }
                } else payload.configInfo["ospf.VirtualLink"].authKeychain = '';
                if ((isAudit && ospfVirtualLink.authenticationKey) || (ospfVirtualLink.authenticationKey == '')) {
                    delete ospfVirtualLink.authenticationKey;
                }
                if (ospfVirtualLink["children-Set"] && ospfVirtualLink["children-Set"]["ospf.Md5Key"]&& ospfVirtualLink["children-Set"]["ospf.Md5Key"]) {
                for (var j in ospfVirtualLink["children-Set"]["ospf.Md5Key"]) {
                let md5KeyItem = ospfVirtualLink["children-Set"]["ospf.Md5Key"][j];
                if (((isAudit) && (md5KeyItem.hasOwnProperty("key"))) || (md5KeyItem.hasOwnProperty("key") == '')) {
                    delete md5KeyItem["key"];
                }
               }
              }
            }
        }
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey) {
       if (xpath === "authKeychain") {
           targetValue = brownFieldNfmpNameSupport(targetValue, "KeyChain:");
       } else if (xpath === "authenticationKey") {
          targetValue = ''
       }
       function brownFieldNfmpNameSupport(input, nameExtension) {
         if (input !== undefined && input.startsWith(nameExtension)) {
            var input1 = input.replace(nameExtension, "");
            return input1;
         }
         return input;
        }
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
}