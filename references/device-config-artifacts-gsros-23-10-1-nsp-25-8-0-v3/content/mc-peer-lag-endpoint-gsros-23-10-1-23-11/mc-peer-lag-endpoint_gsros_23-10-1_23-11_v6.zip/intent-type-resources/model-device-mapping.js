function ModelDeviceMapping() {
    this.getMcPeerMapping = function () {
        var mapping = {};
        mapping['peer.endPointADetails.admin-state'] = 'firstSiteAdministrativeState';
        mapping['peer.endPointADetails.description'] = 'firstSiteDescription';
        mapping['peer.endPointADetails.peer-name'] = 'firstSitePeerName';
        mapping['peer.endPointADetails.warm-standby'] = 'firstSiteWarmStandby';
        mapping['peer.endPointBDetails.admin-state'] = 'secondSiteAdministrativeState';
        mapping['peer.endPointBDetails.description'] = 'secondSiteDescription';
        mapping['peer.endPointBDetails.peer-name'] = 'secondSitePeerName';
        mapping['peer.endPointBDetails.warm-standby'] = 'secondSiteWarmStandby';
        mapping['peer.sync.admin-state'] = "commonSyncAdminState";
        mapping['peer.sync.endPointADetails.admin-state'] = "syncAdminStateFirstSiteRO";
        mapping['peer.sync.endPointBDetails.admin-state'] = "syncAdminStateSecondSiteRO";
        mapping['peer.sync.igmp'] = "igmp";
        mapping['peer.sync.igmpSnooping'] = "igmpSnooping";
        mapping['peer.sync.subscriberManagement'] = "subscriberManagement";
        mapping['peer.sync.subscriberManagementPPPoE'] = "subscriberManagementPPPoE";
        mapping['peer.sync.srrp'] = "srrp";
        mapping['peer.sync.mcRing'] = "mcRing";
        mapping['peer.sync.mcMld'] = "mcMld";
        mapping['peer.sync.mldSnooping'] = "mldSnooping";
        mapping['peer.sync.mcPimSnooping'] = "mcPimSnooping";
        mapping['peer.sync.subscriberHostTracking'] = "subscriberHostTracking";
        mapping['peer.sync.mcIPSec'] = "mcIPSec";
        mapping['peer.sync.mcDhcpServer'] = "mcDhcpServer";
        mapping['peer.sync.mcPythonCache'] = "mcPythonCache";
        mapping['peer.sync.mcDiameterProxy'] = "mcDiameterProxy";
        mapping['peer.sync.mcL2tp'] = "mcL2tp";
        mapping['peer.sync.mcKeyChainName'] = "mcKeyChainName";
        mapping['peer.enable-mc-ipsec'] = 'enableMcIPSec';
        return mapping;
    }

    this.getMcLagPeerSpecificsMapping = function () {
        var mapping = {};
        mapping['peer.mc-lag.endPointADetails.admin-state'] = 'administrativeState';
        mapping['peer.mc-lag.endPointADetails.keep-alive-interval'] = 'keepAliveInterval';
        mapping['peer.mc-lag.endPointADetails.hold-on-neighbor-failure'] = 'holdOnNeighborFailure';
        mapping['peer.mc-lag.endPointBDetails.admin-state'] = 'administrativeState';
        mapping['peer.mc-lag.endPointBDetails.keep-alive-interval'] = 'keepAliveInterval';
        mapping['peer.mc-lag.endPointBDetails.hold-on-neighbor-failure'] = 'holdOnNeighborFailure';
        return mapping;
    }

    this.getMcLagMapping = function () {
        var mapping = {};
        mapping['peer.mc-lag.lag.lag-name'] = 'firstLagId';
        mapping['peer.mc-lag.lag.lacp-key'] = 'lacpKey';
        mapping['peer.mc-lag.lag.system-id'] = 'systemId';
        mapping['peer.mc-lag.lag.system-priority'] = 'systemPriority';
        mapping['peer.mc-lag.lag.remote-lag'] = 'secondLagId';
        mapping['peer.mc-lag.lag.source-bmac-lsb'] = 'srcBMacLSB';
        return mapping;
    }

    this.getMcEndpointMapping = function () {
            var mapping = {};
            //mapping['peer.enable-mc-endpoint'] = 'firstLagId';
            mapping['peer.mc-endpoint.description'] = 'description';
            mapping['peer.mc-endpoint.endPointADetails.admin-state'] = 'firstSiteAdministrativeState';
            mapping['peer.mc-endpoint.endPointADetails.system-priority'] = 'firstSiteSystemPriority';
            mapping['peer.mc-endpoint.endPointADetails.keep-alive-interval'] = 'firstSiteKeepAliveInterval';
            mapping['peer.mc-endpoint.endPointADetails.hold-on-neighbor-failure'] = 'firstSiteHoldOnNeighborFailure';
            mapping['peer.mc-endpoint.endPointADetails.passive-mode'] = 'firstSitePassiveMode';
            mapping['peer.mc-endpoint.endPointADetails.boot-timer'] = 'firstSiteBootTimer';
            mapping['peer.mc-endpoint.endPointADetails.bfd'] = 'firstSiteBfdEnabled';
            mapping['peer.mc-endpoint.endPointBDetails.admin-state'] = 'secondSiteAdministrativeState';
            mapping['peer.mc-endpoint.endPointBDetails.system-priority'] = 'secondSiteSystemPriority';
            mapping['peer.mc-endpoint.endPointBDetails.keep-alive-interval'] = 'secondSiteKeepAliveInterval';
            mapping['peer.mc-endpoint.endPointBDetails.hold-on-neighbor-failure'] = 'secondSiteHoldOnNeighborFailure';
            mapping['peer.mc-endpoint.endPointBDetails.passive-mode'] = 'secondSitePassiveMode';
            mapping['peer.mc-endpoint.endPointBDetails.boot-timer'] = 'secondSiteBootTimer';
            mapping['peer.mc-endpoint.endPointBDetails.bfd'] = 'secondSiteBfdEnabled';
            return mapping;
        }

    this.getMcIpsecMapping = function () {
            var mapping = {};
            mapping['peer.mc-ipsec.endPointADetails.bfd-liveness'] = 'bfdEnable';
            mapping['peer.mc-ipsec.endPointADetails.keep-alive-interval'] = 'keepAliveInterval';
            mapping['peer.mc-ipsec.endPointADetails.hold-on-neighbor-failure'] = 'holdOnNeighborFailure';
            mapping['peer.mc-ipsec.endPointADetails.discovery-interval.interval-secs'] = 'discoveryInterval';
            mapping['peer.mc-ipsec.endPointADetails.discovery-interval.boot'] = 'discoveryIntervalBoot';

            mapping['peer.mc-ipsec.endPointBDetails.bfd-liveness'] = 'bfdEnable';
            mapping['peer.mc-ipsec.endPointBDetails.keep-alive-interval'] = 'keepAliveInterval';
            mapping['peer.mc-ipsec.endPointBDetails.hold-on-neighbor-failure'] = 'holdOnNeighborFailure';
            mapping['peer.mc-ipsec.endPointBDetails.discovery-interval.interval-secs'] = 'discoveryInterval';
            mapping['peer.mc-ipsec.endPointBDetails.discovery-interval.boot'] = 'discoveryIntervalBoot';
            return mapping;
    }

    this.getMcIpsecTunnelGroupMapping = function () {
        var mapping = {};
        mapping['peer.mc-ipsec.tunnelGroup.tunnelGroupSyncTag'] = 'tunnelGroupSyncTag';
        mapping['peer.mc-ipsec.tunnelGroup.firstTunnelGroupId'] = 'firstTunnelGroupId';
        mapping['peer.mc-ipsec.tunnelGroup.firstSiteAdministrativeState'] = 'firstSiteAdministrativeState';
        mapping['peer.mc-ipsec.tunnelGroup.firstSitePriority'] = 'firstSitePriority';
        mapping['peer.mc-ipsec.tunnelGroup.secondTunnelGroupId'] = 'secondTunnelGroupId';
        mapping['peer.mc-ipsec.tunnelGroup.secondSiteAdministrativeState'] = 'secondSiteAdministrativeState';
        mapping['peer.mc-ipsec.tunnelGroup.secondSitePriority'] = 'secondSitePriority';
        return mapping;
    }

    this.getMcIpsecDomainAMapping = function () {
        var mapping = {};
        mapping['peer.mc-ipsec.endPointADetails.domain.id'] = 'domainId';
        mapping['peer.mc-ipsec.endPointADetails.domain.admin-state'] = 'administrativeState';
        return mapping;
    }

    this.getMcIpsecDomainBMapping = function () {
        var mapping = {};
        mapping['peer.mc-ipsec.endPointBDetails.domain.id'] = 'domainId';
        mapping['peer.mc-ipsec.endPointBDetails.domain.admin-state'] = 'administrativeState';
        return mapping;
    }

    this.getMcRingGroupMapping = function () {
        var mapping = {};
        mapping["peer.mc-ring.ringGroup.ringName"] = 'ringName';
        return mapping;
    }

    this.getMcRingMapping = function () {
        var mapping = {};
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.admin-state"] = 'administrativeState';
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.in-band-control-path.admin-state"] = 'ibrccAdministrativeState';
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.in-band-control-path.max-debounce-time"] = 'ibrccDebounceMaxTime';
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.in-band-control-path.dst-ip"] = 'ibrccDestinationIpAddr';
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.in-band-control-path.service-name"] = 'ibrccServiceName';
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.in-band-control-path.interface"] = 'ibrccInterfaceName';

        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.admin-state"] = 'administrativeState';
        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.in-band-control-path.admin-state"] = 'ibrccAdministrativeState';
        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.in-band-control-path.max-debounce-time"] = 'ibrccDebounceMaxTime';
        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.in-band-control-path.dst-ip"] = 'ibrccDestinationIpAddr';
        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.in-band-control-path.service-name"] = 'ibrccServiceName';
        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.in-band-control-path.interface"] = 'ibrccInterfaceName';
        return mapping;
    }

    this.getMcRingPathBMapping = function () {
        var mapping = {};
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.path-b.range.start"] = 'startVlan';
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.path-b.range.end"] = 'endVlan';

        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.path-b.range.start"] = 'startVlan';
        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.path-b.range.end"] = 'endVlan';
        return mapping;
    }

    this.getMcRingPathExclMapping = function () {
        var mapping = {};
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.path-excl.range.start"] = 'startVlan';
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.path-excl.range.end"] = 'endVlan';

        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.path-excl.range.start"] = 'startVlan';
        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.path-excl.range.end"] = 'endVlan';
        return mapping;
    }

    this.getMcRingNodeMapping = function () {
        var mapping = {};
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.ring-node.name"] = 'ringNodeName';
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.ring-node.admin-state"] = 'administrativeState';
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.ring-node.interval"] = 'rncvInterval';
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.ring-node.rncvServiceId"] = 'rncvServiceId';
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.ring-node.rncvOuterEncapValue"] = 'rncvOuterEncapValue';
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.ring-node.rncvInnerEncapValue"] = 'rncvInnerEncapValue';
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.ring-node.dst-ip"] = 'rncvDestinationIpAddr';
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.ring-node.src-ip"] = 'rncvSourceIpAddr';
        mapping["peer.mc-ring.ringGroup.endPointADetails.ring.ring-node.src-mac"] = 'rncvSourceMacAddr';

        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.ring-node.name"] = 'ringNodeName';
        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.ring-node.admin-state"] = 'administrativeState';
        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.ring-node.interval"] = 'rncvInterval';
        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.ring-node.rncvServiceId"] = 'rncvServiceId';
        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.ring-node.rncvOuterEncapValue"] = 'rncvOuterEncapValue';
        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.ring-node.rncvInnerEncapValue"] = 'rncvInnerEncapValue';
        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.ring-node.dst-ip"] = 'rncvDestinationIpAddr';
        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.ring-node.src-ip"] = 'rncvSourceIpAddr';
        mapping["peer.mc-ring.ringGroup.endPointBDetails.ring.ring-node.src-mac"] = 'rncvSourceMacAddr';
        return mapping;
    }

}