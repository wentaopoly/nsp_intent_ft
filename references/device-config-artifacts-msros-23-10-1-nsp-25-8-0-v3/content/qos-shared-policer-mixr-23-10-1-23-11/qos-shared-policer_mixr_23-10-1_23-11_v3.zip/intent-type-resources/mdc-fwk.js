/*
 *
 * The intent of this framework is to provide a means of communicating with the MDC mediator.
 *
 * All responses should be in the format of
 * {
 *   success: true or false
 *   httpStatus: the http status of the request
 *   msg: a message (usually an error in the case of a failure, or the response body payload)
 * }
 *
 */
function MdcFwk() {
  MDC_HOST = "nsp-mdt-mdc-mediator-svc";
  MDC_PORT = "80";

  /**
   *
   * @param {*} url
   * @param {*} deviceId
   * @param {*} httpMethod
   */
  this.configRestClient = function (url, deviceId, httpMethod) {
    logger.info(
      "[MDC-FWK] Calling MDC " +
        MDC_HOST +
        ":" +
        MDC_PORT +
        " with url " +
        url +
        " against device " +
        deviceId +
        " as HTTP " +
        httpMethod
    );
    restClient.setIp(MDC_HOST);
    restClient.setPort(MDC_PORT);
    restClient.setProtocol("http");
  };

  /**
   *
   * @param {*} deviceName
   * @param {*} targetUrl
   * @returns
   */
  this.fetch = function (deviceName, targetUrl) {
    var result = {};
    this.configRestClient(targetUrl, deviceName, "GET");
    restClient.get(
      targetUrl,
      "application/json",
      function (exception, httpStatus, response) {
        if (exception) {
          result = {
            success: false,
            httpStatus: httpStatus,
            msg:
              "Couldn't connect to Manager of Device: " +
              deviceName +
              ", got response " +
              response,
          };
        }
        if (httpStatus !== 200 && httpStatus !== 201) {
          result = {
            success: false,
            httpStatus: httpStatus,
            msg:
              "Failed to fetch service from MDC device " +
              deviceName +
              ", got response " +
              response,
          };
        } else {
          result = {
            success: true,
            httpStatus: httpStatus,
            msg: JSON.parse(response),
          };
        }
      }
    );
    return result;
  };

  /**
   *
   * @param {*} deviceName
   * @param {*} targetUrl
   * @param {*} payload
   * @returns
   */
  this.deploy = function (deviceName, targetUrl, payload) {
    var result = {};
    this.configRestClient(targetUrl, deviceName, "PATCH");
    logger.info(
      "Deploying: deviceName: " +
        deviceName +
        ", targetUrl: " +
        targetUrl +
        ", payload: " +
        payload
    );
    restClient.patch(
      targetUrl,
      "application/yang-patch+json",
      payload,
      "application/json",
      function (exception, httpStatus, response) {
        if (exception) {
          result = {
            success: false,
            httpStatus: httpStatus,
            msg:
              "Couldn't connect to Manager of Device: " +
              deviceName +
              ", got response " +
              response,
          };
        }
        if (httpStatus !== 200 && httpStatus !== 201) {
          result = {
            success: false,
            httpStatus: httpStatus,
            msg:
              "Failed deployment to MDC for device " +
              deviceName +
              ", got response " +
              response,
          };
        } else {
          result = {
            success: true,
            httpStatus: httpStatus,
            msg:
              "Deployment to MDC for device " +
              deviceName +
              " was successful, got response " +
              response,
          };
        }
      }
    );

    logger.info("[MDC-FWK] deploy: Got result " + JSON.stringify(result));
    return result;
  };

  /**
   * Delete a node in a device
   * @param {*} deviceName
   * @param {*} deleteUrl
   * @returns
   */
  this.delete = function (deviceName, deleteUrl) {
    var result = {};
    this.configRestClient(deleteUrl, deviceName, "DELETE");
    logger.info(
      "Deleting: deviceName: " + deviceName + ", deleteUrl: " + deleteUrl
    );
    restClient.delete(
      deleteUrl,
      "application/json",
      function (exception, httpStatus, response) {
        if (exception) {
          result = {
            success: false,
            httpStatus: httpStatus,
            msg:
              "Couldn't connect to Manager of Device: " +
              deviceName +
              ", got response " +
              response,
          };
        }
        if (httpStatus !== 200 && httpStatus !== 201 && httpStatus !== 204) {
          result = {
            success: false,
            httpStatus: httpStatus,
            msg:
              "Failed deployment to MDC for device " +
              deviceName +
              ", got response " +
              response,
          };
        } else {
          result = {
            success: true,
            httpStatus: httpStatus,
            msg:
              "Deployment to MDC for device " +
              deviceName +
              " was successful, got response " +
              response,
          };
        }
      }
    );
    logger.info("[MDC-FWK] delete: Got result " + JSON.stringify(result));
    return result;
  };

  /**
   * TODO This duplicate function, delete it later
   * @param {*} deviceName
   * @param {*} deleteUrl
   * @returns
   */
  this.deployDelete = function (deviceName, deleteUrl) {
    var result = {};
    this.configRestClient(deleteUrl, deviceName, "DELETE");
    logger.info(
      "Deleting: deviceName: " + deviceName + ", deleteUrl: " + deleteUrl
    );
    restClient.delete(
      deleteUrl,
      "application/json",
      function (exception, httpStatus, response) {
        if (exception) {
          result = {
            success: false,
            httpStatus: httpStatus,
            msg:
              "Couldn't connect to Manager of Device: " +
              deviceName +
              ", got response " +
              response,
          };
        }
        if (httpStatus !== 200 && httpStatus !== 201 && httpStatus !== 204) {
          result = {
            success: false,
            httpStatus: httpStatus,
            msg:
              "Failed deployment to MDC for device " +
              deviceName +
              ", got response " +
              response,
          };
        } else {
          result = {
            success: true,
            httpStatus: httpStatus,
            msg:
              "Deployment to MDC for device " +
              deviceName +
              " was successful, got response " +
              response,
          };
        }
      }
    );
    logger.info("[MDC-FWK] deployDelete: Got result " + JSON.stringify(result));
    return result;
  };

  /**
   * TODO, we can remove such code
   * @param {*} context
   * @param {*} deviceId
   * @param {*} mustBeAccess
   * @param {*} validEncapTypes
   * @returns
   */
  this.suggestSRonMDCPortIds = function (
    context,
    deviceId,
    mustBeAccess,
    validEncapTypes
  ) {
    var returnVal = {};
    // Should be changed to a state call once depth works
    var portUrl =
      "restconf/data/network-device-mgr:network-devices/network-device=" +
      deviceId +
      "/root/nokia-conf:/configure/port?depth=1";

    var searchQuery = context.getSearchQuery();
    var fetchResult = this.fetch(deviceId, portUrl);
    if (fetchResult.success) {
      fetchResult.msg["nokia-conf:port"].forEach(function (port) {
        var portId = port["port-id"];
        var portMode;
        var portEncap;
        if (port["ethernet"]) {
          portMode = port["ethernet"]["mode"];
          portEncap = port["ethernet"]["encap-type"];
        }

        logger.info(
          "port-id, mode, encap = {" +
            portId +
            ", " +
            portMode +
            ", " +
            portEncap +
            "}"
        );
        if (
          (!mustBeAccess || portMode === "access") &&
          (!validEncapTypes || validEncapTypes.indexOf(portEncap) > -1)
        ) {
          if (searchQuery) {
            if (port.startsWith(searchQuery)) {
              returnVal[portId] = portId;
            }
          } else {
            returnVal[portId] = portId;
          }
        }
      });
    }
    return returnVal;
  };
}
