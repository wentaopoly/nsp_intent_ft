function ModelDeviceMapping()
{
  this.getMapping = function(type)
  {
    switch(type)
    {
      case "IPv6filter":
        return this.getIPv6FilterMapping();
      case "IPv6filterEntry":
        return this.getIPv6FilterEntryMapping();
      default:
        return this.getIPv6FilterMapping();
    }
  }
  this.getIPv6FilterMapping = function ()
  {
    var mapping = {};
    mapping['ipv6-filter.description'] = 'description';
    mapping['ipv6-filter.default-action'] = 'defaultAction';
    mapping['ipv6-filter.scope'] = 'scope';
    mapping['ipv6-filter.type'] = 'type';
    mapping['ipv6-filter.chain-to-system-filter'] = 'chainToSystemFilter';
    mapping['ipv6-filter.shared-policer'] = 'sharedPolicer';
    return mapping;
  }

  this.getIPv6FilterEntryMapping = function ()
  {
    var mapping = {};
    mapping['ipv6-filter.entry.entry-id'] = 'id';
    mapping['ipv6-filter.entry.description'] = 'description';

    return mapping;
  }

}
