function ModelDeviceMapping() {
    this.getSchPolicyMapping = function () {
        var mapping = {};
        mapping['scheduler-policy.description'] = 'description';
        mapping['scheduler-policy.mode'] = 'mode';
        return mapping;
    }
}
