function ModelDeviceMapping() {
    this.getSchPolicyMapping = function () {
        var mapping = {};
        mapping['scheduler-policy.description'] = 'description';
        mapping['scheduler-policy.frame-based-accounting'] = 'schedulerPolicyFrameBasedAccnt';
        return mapping;
    }

    this.getTierMapping = function () {
        var mapping = {};
        mapping['scheduler-policy.tier.tier-id'] = 'tier';
        mapping['scheduler-policy.tier.parent-location'] = 'tier1ParentLoc';
        return mapping;
    }

    this.getSchedulerMapping = function () {
        var mapping = {};
        mapping['scheduler-policy.tier.scheduler.scheduler-name'] = 'displayedName';
        mapping['scheduler-policy.tier.scheduler.description'] = 'description';
        mapping['scheduler-policy.tier.scheduler.limit-unused-bandwidth'] = 'limitUnusedBandwidth';
        mapping['scheduler-policy.tier.scheduler.port-parent.level'] = 'portParentLevel';
        mapping['scheduler-policy.tier.scheduler.port-parent.weight'] = 'portParentWeight';
        mapping['scheduler-policy.tier.scheduler.port-parent.cir-level'] = 'portParentCirLevel';
        mapping['scheduler-policy.tier.scheduler.port-parent.cir-weight'] = 'portParentCirWeight';
        mapping['scheduler-policy.tier.scheduler.scheduler-parent.scheduler-name'] = 'nextSchedulerName';
        mapping['scheduler-policy.tier.scheduler.scheduler-parent.level'] = 'level';
        mapping['scheduler-policy.tier.scheduler.scheduler-parent.weight'] = 'weight';
        mapping['scheduler-policy.tier.scheduler.scheduler-parent.cir-level'] = 'cirLevel';
        mapping['scheduler-policy.tier.scheduler.scheduler-parent.cir-weight'] = 'cirWeight';
        mapping['scheduler-policy.tier.scheduler.percent-rate.pir'] = 'pirPercent';
        mapping['scheduler-policy.tier.scheduler.percent-rate.cir'] = 'cirPercent';
        mapping['scheduler-policy.tier.scheduler.percent-rate.reference-rate'] = 'rateType';
        mapping['scheduler-policy.tier.scheduler.rate.pir'] = 'pir';
        mapping['scheduler-policy.tier.scheduler.rate.cir'] = 'cir';
        return mapping;
    }
}
