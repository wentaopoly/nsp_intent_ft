var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});

load({ script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk' });

load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

load({script: resourceProvider.getResource("model-device-mapping.js"), name: "model-device-mapping"});

load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});


var full_class_name = "ixrqos.NetworkIngressPolicy";
var network_ingress_policy_name = "displayedName";
var policy_fdn = "NetworkIngressPolicy7250SROS";

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let mdcFwk = new MdcFwk();
    let parseTarget = new ParseTarget();
    let modelDeviceMapping = new ModelDeviceMapping();
    let util = new utilities();

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let policyName = parseTarget.getUniqueIdentifier(target);
        let objectFullName = policy_fdn + ":" + policyName;
        let localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        logger.info(LOG_PREFIX + "localPolicyFullName: " + localPolicyFullName);
        let resultFetch = nfmpFwk.post("/v3/search", this.constructSearchString(full_class_name, localPolicyFullName));
        if (!resultFetch.success) {
            throw new RuntimeException("Failed to find policy : " + policyName + " on NE " + neId);
        }
        let finalResponse = JSON.parse(resultFetch.response);
        if (JSON.stringify(finalResponse) === JSON.stringify({})) {
            throw new RuntimeException("search results is empty for policy : " + policyName + " finalResponse: " + JSON.stringify(finalResponse));
        }
        else if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse[full_class_name]];
            logger.info(LOG_PREFIX + "Search results: " + JSON.stringify(finalResponse));
        }
        return finalResponse[0];
    }

    this.constructSearchString = function (className, objectFullName) {
        let searchJson = {
            "fullClassName": className,
            "filter":{
                "equal":{
                    "name":"objectFullName",
                    "value": objectFullName
                }
            }
        };
        return searchJson;
    }

    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedTargetData = JSON.parse(defaultTargetData)[initialPropertyName];
        let loadingTargetData = JSON.parse(JSON.stringify(parsedTargetData));
        this.extractNonChildProperties(parsedTargetData, deviceConfig);
        let qosNetIngressChildConfigs = deviceConfig["children-Set"];
        for (let childAttribute in qosNetIngressChildConfigs) {
            switch (childAttribute) {
                case "ixrqos.NetworkIngressForwardingClass":
                    {
                        let netIngressFcConfig = qosNetIngressChildConfigs[childAttribute];
                        parsedTargetData["fc"] = this.extractDeviceProperties(netIngressFcConfig, loadingTargetData["fc"][0], "network-ingress.fc");
                        break;
                    }
                case "ixrqos.NetworkIngressPolicer":
                    {
                        let netIngressPolicerConfig = qosNetIngressChildConfigs[childAttribute];
                        parsedTargetData["policer"] = this.extractDeviceProperties(netIngressPolicerConfig, loadingTargetData["policer"][0], "network-ingress.policer");
                        break;
                    }
            }
        }

        let finalTargetData = {};
        finalTargetData[initialPropertyName] = parsedTargetData;
        logger.info(LOG_PREFIX + "Intent data after updating from NFMP: \n" + JSON.stringify(finalTargetData));
        return finalTargetData;
    }

    this.extractNonChildProperties = function (parsedTargetData, deviceConfig) {
        let netIngressMapping = modelDeviceMapping.getNetIngressNonChildQosMapping();
        this.traverseAndUpdateConfig("network-ingress", parsedTargetData, deviceConfig, netIngressMapping);
        delete parsedTargetData["fc"];
        delete parsedTargetData["policer"];
        logger.info(LOG_PREFIX + "Updated non child properties - " + JSON.stringify(parsedTargetData));
    }

    this.extractDeviceProperties = function (configData, defaultDataObj, keyPrefix) {
        let configDataArray = [];
        let mappings = modelDeviceMapping.getMapping(keyPrefix);
        if (!Array.isArray(configData)) {
            configData = [configData];
        }
        for (let idx in configData) {
            let configDataObj = configData[idx];
            let defData = JSON.parse(JSON.stringify(defaultDataObj));
            this.traverseAndUpdateConfig(keyPrefix, defData, configDataObj, mappings);
            configDataArray.push(defData);
        }
        logger.info(LOG_PREFIX + "parsedTargetData for: " + keyPrefix + ": " + JSON.stringify(configDataArray));
        return configDataArray;
    }

    this.traverseAndUpdateConfig = function (objKey, defDataObj, deviceConfig, mappings) {
        let keys = Object.keys(defDataObj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = defDataObj[key];

            let mappedKey = objKey + "." + key;
            if ((mappedKey !== "network-ingress.fc") && (mappedKey !== "network-ingress.policer"))
            {
                if (value != null && typeof value === "object") {
                    this.traverseAndUpdateConfig(mappedKey, value, deviceConfig, mappings);
                }
                else {
                    let nfmpKey = mappings[mappedKey];
                    defDataObj[key] = this.transformDeviceValue(mappedKey, deviceConfig[nfmpKey]);
                }
            }
        }
        return defDataObj;
    }

    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue != null) {
            switch (mappedKey) {
                case "network-ingress.policer.stat-mode":
                    deviceValue = util.transformPolicerStatModeBf(deviceValue);
                    break;
                case "network-ingress.policer.cbs":
                case "network-ingress.policer.mbs":
                    if (deviceValue === "-1") {
                        deviceValue = "auto";
                    }
                    break;
                case "network-ingress.policer.rate.pir":
                case "network-ingress.policer.rate.cir":
                    if (deviceValue === "-1") {
                        deviceValue = "max"
                    }
            }
            return deviceValue;
        }
    }
}