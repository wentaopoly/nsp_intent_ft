var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
const icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
const gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})

let intentTypeName = "router-mpls-interface_csros_23-10-1_24-4";

// example port, sap-ingress etc..
let initialPropertyName = "mpls-Interface";


// unique identifier
let uniqueIdentifier = "interfaceId";


/**
 * This function is starting point by IM for sync operation
 * @param input
 * @returns {*}
 */
function synchronize(input) {
    logger.info("-------------------- script-content.js -> synchronize() --------------------");
    logger.info("Intent Synchronisation started - input = {}", input)
    return NspIntentHelper.synchronize(input, intentTypeName, initialPropertyName, uniqueIdentifier);
}

/**
 * The function is starting point for audit operation in IM
 * @param input
 * @returns {*}
 */
function audit(input) {
    logger.info("-------------------- script-content.js -> audit() --------------------");
    logger.info("Intent Audit started - input = {}", input)
    return NspIntentHelper.audit(input, intentTypeName, initialPropertyName, uniqueIdentifier)
}

/**
 * This function returns NE-ID
 *
 * @param context
 * @returns {string}
 */
function getNeId(context) {
    let neId;
    let target = context.getInputValues()["target"]["objectidentifier"];
    logger.info("target : {}", target)
    if (!target) {
        target = context.getInputValues()["arguments"]["__root"]["target_objectidentifier"];
    }
    if (target) {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        } else {
            neId = target;
        }
    }
    logger.info("NeId identified " + " : {}", neId);
    return neId;
}

/**
 * The function is used in Brownfield discovery by ICM Framework
 * It discover's the configuration from the target device
 * and manipulate as per Template's default-target-data
 *
 * @see ICMFwk for more details
 * @param {*} input - the config data of a deployment
 * @returns result - the result of the operation
 */
function getTargetData(input) {
    logger.info("-------------------- script-content.js -> getTargetData() --------------------");
    logger.info("getTargetData input for brownfield = \n" + input);
    let target = input.target;
    let config = null;
    logger.info("target=" + target);
    let deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info("deviceConfig = {} ", JSON.stringify(deviceConfig));
    let data = gtdFwk.gtdSend(deviceConfig);
    logger.info("data = {}", JSON.stringify(data));
    logger.info("returning result = {}", JSON.stringify(data.msg.result));
    return data.msg.result;
}

function getSRLG(context){
    logger.info("SuggestSRLG ==> context = {}", context);
  return new NfmpSuggest().get_SRLG_Names(getNeId(context));
}

function suggestInterfaceName(context) {
    logger.info("SuggestDisplayedName ==> context = {}", context);
    let actionData= context.getInputValues()["action"]
    logger.info("ACTION ",actionData)
    let neId = getNeId(context);
    return new NfmpSuggest().getInterfaceName(neId, actionData);
}

function suggestAdminGroups(context) {
    logger.info("suggestAdminGroups ==> context = {}", context);
    function getValueByPath(obj, path) {
        const keys = path.split(".");
        let current = obj;
        for (const key of keys) {
            if (current && typeof current === "object" && key in current) {
            current = current[key];
            } else {
            return undefined;
            }
        }
        return current;
    }
    let arg = context.getInputValues()["arguments"];
    let attributePath = arg["__attribute"];
    let extractedData = getValueByPath(arg, attributePath);
    let suggestedData = new NfmpSuggest().getAdminGroups(getNeId(context));

    if(extractedData!==undefined){
        for (let i = 0; i < extractedData.length; i++) {
            let index = suggestedData.indexOf(extractedData[i]);
            if (index !== -1) {
                suggestedData.splice(index, 1);
            }
        }
    }

    return suggestedData;
}

