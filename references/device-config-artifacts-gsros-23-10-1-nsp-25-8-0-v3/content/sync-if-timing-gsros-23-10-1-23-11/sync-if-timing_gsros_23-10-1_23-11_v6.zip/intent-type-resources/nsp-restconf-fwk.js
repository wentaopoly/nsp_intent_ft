load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'MediatorFramework'});

function NspRestconfFwk() {
    this.mediatorFwk = new MediatorFramework("NSP");
}

NspRestconfFwk.prototype.RESTCONF_HOST = "restconf-gateway";
NspRestconfFwk.prototype.RESTCONF_PORT = "443";
NspRestconfFwk.prototype.mediatorFwk = null;
NspRestconfFwk.prototype.NSP_RESTCONF_INVENTORY_FIND_URL = "/restconf/operations/nsp-inventory:find";

NspRestconfFwk.prototype.constructURL = function (path, method) {
    var url = "https://" + this.RESTCONF_HOST + ":" + this.RESTCONF_PORT + path;
    logger.info("[RestconfFwk] {}Calling restconf via NSP Mediator: {}", method, url);
    return url;
};

NspRestconfFwk.prototype.findByXpath = function (xPath, depth, fields) {
    if (!depth)
    {
        depth = 3;
    }
    var url = this.constructURL(this.NSP_RESTCONF_INVENTORY_FIND_URL, "POST");
    var input = {};
    var ret = null;
    input["xpath-filter"] = xPath;
    input["depth"] = depth;
    if (fields !== undefined)
        input["fields"] = fields;
    var requestBody = {};
    requestBody["input"] = input;

    var response = this.mediatorFwk.post(url, requestBody);
    logger.info("[RestconfFwk][findByXpath] response = {}", JSON.stringify(response));

    if (response.httpStatus === 200 && response)
    {
        var lRes = JSON.parse(response["response"]);
        if (lRes && lRes["nsp-inventory:output"])
        {
            var data = JSON.parse(response["response"])["nsp-inventory:output"]["data"];
            if (data.length !== 0)
                ret = data;
        }
    }
    return ret;
};

NspRestconfFwk.prototype.getPorts = function (neId) {
    if (!neId)
    {
        return [];
    }
    else
    {
        //var portXPath = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/hardware-component/port";
        var portXPath = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/hardware-component/" +
            "port[boolean(port-details[port-type!='connector-port'])]" +
            "[not(contains('name','/u'))]" +
            "[boolean (parent[nsp-model:schema-nodeid='/nsp-equipment:network/network-element/hardware-component/shelf']" +
            "[not(contains('component-id','shelf=1-6-'))]" +
            "[not(contains('component-id','shelf=1-5-'))]) or " +
            "boolean(parent[nsp-model:schema-nodeid='/nsp-equipment:network/network-element/hardware-component/port']) or " +
            "boolean(parent[nsp-model:schema-nodeid='/nsp-equipment:network/network-element/hardware-component/card']" +
            "[not(containsIgnoreCase('name','Processor'))])]";
        var ret = this.findByXpath(portXPath, 3, "name;description;port-details");
        var result = {};
        if (ret)
        {
            var data = ret.map(function (port) {
                var obj = {};
                obj["port-id"] = (port["name"].replace("Port", "")).trim();
                obj["description"] = port["description"];
                if (port["port-details"])
                {
                    obj["encapType"] = port["port-details"][0]["encap-type"]
                    obj["mode"] = port["port-details"][0]["port-mode"]
                }
                if (port["encap-type"])
                {
                    obj["encapType"] = port["encap-type"];
                }
                if (port["mode"])
                {
                    obj["mode"] = port["port-mode"];
                }
                return obj;
            });
            result["data"] = JSON.stringify(data);
        }
        return result
    }
};

NspRestconfFwk.prototype.getByXpath = function (xPath) {
    var url = this.constructURL("/restconf/data" + xPath, "GET");
    var response = this.mediatorFwk.fetch(url);
    logger.debug("[RestconfFwk][getByXpath] response = {}", JSON.stringify(response));
    if (response.httpStatus === 200)
    {
        return response["response"];
    }
    else
    {
        return null;
    }
};