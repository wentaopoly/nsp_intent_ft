load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'MediatorFramework'});

function NspRestconfFwk() {
    this.mediatorFwk = new MediatorFramework("NSP");
}

NspRestconfFwk.prototype.RESTCONF_HOST = "restconf-gateway";
NspRestconfFwk.prototype.RESTCONF_PORT = "443";
NspRestconfFwk.prototype.mediatorFwk = null;
NspRestconfFwk.prototype.NSP_RESTCONF_INVENTORY_FIND_URL = "/restconf/operations/nsp-inventory:find";

NspRestconfFwk.prototype.constructURL = function (path, method) {
    var url = "https://" + this.RESTCONF_HOST + ":" + this.RESTCONF_PORT + path;
    logger.info("[RestconfFwk] {}Calling restconf via NSP Mediator: {}", method, url);
    return url;
};

NspRestconfFwk.prototype.getByXpath = function (xPath) {
    var url = this.constructURL("/restconf/data" + xPath, "GET");
    var response = this.mediatorFwk.fetch(url);
    logger.debug("[RestconfFwk][getByXpath] response = {}", JSON.stringify(response));
    if (response.httpStatus === 200) {
        return response["response"];
    } else {
        return null;
    }
};

NspRestconfFwk.prototype.findByXpath = function (xPath, depth, fields) {
    if (!depth)
    {
        depth = 3;
    }
    var url = this.constructURL(this.NSP_RESTCONF_INVENTORY_FIND_URL, "POST");
    var input = {};
    var ret = null;
    input["xpath-filter"] = xPath;
    input["depth"] = depth;
    if (fields !== undefined)
        input["fields"] = fields;
    var requestBody = {};
    requestBody["input"] = input;

    var response = this.mediatorFwk.post(url, requestBody);
    logger.info("[RestconfFwk][findByXpath] response = {}", JSON.stringify(response));

    if (response.httpStatus === 200 && response)
    {
        var lRes = JSON.parse(response["response"]);
        if (lRes && lRes["nsp-inventory:output"])
        {
            var data = JSON.parse(response["response"])["nsp-inventory:output"]["data"];
            if (data.length !== 0)
                ret = data;
        }
    }
    return ret;
};

NspRestconfFwk.prototype.findByXpathPaginated = function (xPath, depth, fields, offset) {
    if (!depth) depth = 3;
    if (!offset) offset = 0;
    var limit = 300;
    var url = this.constructURL(this.NSP_RESTCONF_INVENTORY_FIND_URL, "POST");
    var input = {};
    var ret = [];
    input["xpath-filter"] = xPath;
    input["depth"] = depth;
    if (fields !== undefined)
        input["fields"] = fields;
    input["offset"] = offset;
    input["limit"] = limit;
    var requestBody = {};
    requestBody["input"] = input;

    var response = this.mediatorFwk.post(url, requestBody);
    logger.info("[RestconfFwk][findByXpathPaginated] response = {}", JSON.stringify(response));

    if (response.httpStatus === 200 && response)
    {
        var lRes = JSON.parse(response["response"]);
        if (lRes && lRes["nsp-inventory:output"])
        {
            var data = lRes["nsp-inventory:output"]["data"];
            if (data.length !== 0)
            {
                ret = ret.concat(data);
            }
            if ((lRes["nsp-inventory:output"]["end-index"] + 1) !== lRes["nsp-inventory:output"]["total-count"])
            {
                ret = ret.concat(this.findByXpathPaginated(xPath, depth, fields, lRes["nsp-inventory:output"]["end-index"] + 1));
            }
        }
    }
    return ret;
};

NspRestconfFwk.prototype.getNe = function (neIdFilter) {
  var xPath = "/nsp-equipment:network/network-element";
  var result = {};
  var data = this.findByXpath(xPath, 3, "ne-name;ne-id;ip-address;product;type;communication-state;source-type;version");
  if (data) {
    var ret = data.map(function (ne) {
      var obj = {};
     if (ne["ne-id"] !== neIdFilter && ne["source-type"] == "nfmp" && (ne["product"] == '7750 SR' || ne["product"] == '7450 ESS' || ne["product"] == '7950 XRS' || ne["product"] == '7250 IXR' || ne["product"] == '7705 SAR' || ne["product"] == '7705 SAR H' || ne["product"] == '7210 SAS K' || ne["product"] == '7210 SAS Mxp' || ne["product"] == '7210 SAS R' || ne["product"] == '7210 SAS S/Sx' || ne["product"] == '7210 SAS T')){
        obj["deviceId"] = ne["ne-id"];
        obj["deviceName"] = ne["ne-name"];
        obj["ipAddress"] = ne["ip-address"]
        obj["product"] = ne["product"];
        obj["type"] = ne["type"];
        obj["communicationState"] = ne["communication-state"];
        obj["version"] = ne ["version"];
        return obj;
      }
      return null;
    }).filter(obj => obj !== null);
      result["data"] = JSON.stringify(ret);
  }
  return result;
};

NspRestconfFwk.prototype.getNeInterfaceAddress = function (neid) {
    var xPath;
    if (neid)
    {
        xPath = "/nsp-network:network/node[node-id='" + neid + "']/node-root/openconfig-interfaces:interfaces/interface/subinterfaces/subinterface/openconfig-if-ip:ipv4/addresses/address/config";
    }
    var result = [];
    var data = this.findByXpathPaginated(xPath, 3, 'ip');
    if (data)
    {
        var ret = data.map(function (ne) {
            result.push(ne["ip"]);

        });

    }
    return result;
};

NspRestconfFwk.prototype.getByXpath = function (xPath) {
    var url = this.constructURL("/restconf/data" + xPath, "GET");
    var response = this.mediatorFwk.fetch(url);
    logger.debug("[RestconfFwk][getByXpath] response = {}", JSON.stringify(response));
    if (response.httpStatus === 200)
    {
        return response["response"];
    }
    else
    {
        return null;
    }
};