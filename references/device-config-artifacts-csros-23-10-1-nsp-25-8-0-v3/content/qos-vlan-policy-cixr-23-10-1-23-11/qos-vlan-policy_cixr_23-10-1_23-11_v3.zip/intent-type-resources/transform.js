function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        localObjectFullName = ifIpv6AddrExist(localObjectFullName);
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        objectFullName = ifIpv6AddrExist(objectFullName);
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
       if (payload.configInfo) {
           if (payload.configInfo["ixrqos.VlanQosPolicy"]) {
              let vlanQosPolicyData = payload.configInfo["ixrqos.VlanQosPolicy"];
              const vlanQosQueueData = vlanQosPolicyData && vlanQosPolicyData["children-Set"] && vlanQosPolicyData["children-Set"]["ixrqos.VlanQosQueue"];
                if (vlanQosQueueData) {
                   vlanQosQueueData.forEach(vlanQosQueueMgmtPolicyPointer => {
                     if (vlanQosQueueMgmtPolicyPointer.hasOwnProperty("queueMgmtPolicyPointer") && (!vlanQosQueueMgmtPolicyPointer.queueMgmtPolicyPointer.toString().startsWith("QueueMgmtPolicy7250SROS:"))) {
                      let nfmpNameExtension = "QueueMgmtPolicy7250SROS:";
                        vlanQosQueueMgmtPolicyPointer.queueMgmtPolicyPointer = nfmpNameExtension + vlanQosQueueMgmtPolicyPointer.queueMgmtPolicyPointer;
                     }
                   });
                }
                if (vlanQosQueueData) {
                   vlanQosQueueData.forEach(config => {
                     if (config.hasOwnProperty("lowLatency") && (config.lowLatency=== false)) {
                        config.lowLatency = "false";
                     }else if(config.hasOwnProperty("lowLatency") && (config.lowLatency=== true)){
                       config.lowLatency = "true";
                     }
                   });
                }
           }
       }
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
      if(xpath == "ixrqos-VlanQosQueue.pirPercent" || xpath == "ixrqos-VlanQosQueue.cirPercent")
       {
          if(targetValue && !isNaN(targetValue) && !targetValue.contains("."))
          {
              targetValue = Number(targetValue);
             targetValue = targetValue.toFixed(1);
          }
       }
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
       if (xpath === "queueMgmtPolicyPointer") {
           targetValue = brownFieldNfmpNameSupport(targetValue, "QueueMgmtPolicy7250SROS:");
       }
       function brownFieldNfmpNameSupport(input, nameExtension) {
         if (input !== undefined && input.startsWith(nameExtension)) {
            var input1 = input.replace(nameExtension, "");
            return input1;
         }
         return input;
        }
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
    function ifIpv6AddrExist(input) {
      let firstColonIndex = input.indexOf(':') + 1;
      let lastColonIndex = input.lastIndexOf(':') - 22;
      let ip = input.substring(firstColonIndex, lastColonIndex);
      ip = ip.replaceAll(':', '_');
      let result = input.substring(0, firstColonIndex) + ip + input.substring(lastColonIndex);
      return result;
   }
}