var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});



function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();
    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let policyId = util.getSapIngressPolicyID(target);
        let policyName = parseTarget.getUniqueIdentifier(target);
        let className = "aingr.Policy";
        let objectFullName = "network:" + neId + ":Access Ingress:" + policyId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        let searchPayLoad = this.constructSearchString(className, objectFullName);
        let searchResponse = nfmpFwk.post("/v3/search", searchPayLoad);
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0)) {
            if (!(searchResponse.success)) throw new RuntimeException("Failed to get SAP ingress info from nfm-p for Ne " + neId + " and SAP Ingress Policy Id: " + policyId);
            if (JSON.parse(searchResponse["response"]).length === 0) throw new RuntimeException("There is no SAP Ingress with Name:" + policyName + " and Id:" + policyId);
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse;

    }

    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        logger.info("PARSED DEFAULT TARGET DATA : " + JSON.stringify(parsedDefaultTargetData));
        logger.info("DEVICE CONFIG : " + JSON.stringify(deviceConfig));
        let sapIngressConfig = deviceConfig['aingr.Policy'];
        let neId=util.extractIPAddress(deviceConfig['aingr.Policy']['objectFullName']);
        if (null !== sapIngressConfig && sapIngressConfig !== undefined) {
            this.extractPolicyLevelProperties(parsedDefaultTargetData, sapIngressConfig);
        }
        let childrenConfig = sapIngressConfig['children-Set'];
        if (undefined !== childrenConfig && null !== childrenConfig && childrenConfig.length !== 0) {
            let macCriteriaEntryData = parsedDefaultTargetData['sap-ingress']['mac-criteria']['entry'];
            if (macCriteriaEntryData !== null && macCriteriaEntryData.length !== 0) {
                let childMacCriteriaConfig = childrenConfig["aingr.MacMatch"];
                if (childMacCriteriaConfig != undefined && childMacCriteriaConfig.length != 0) {
                    let macCriteriaEntryArray = this.extractMacCriteriaEntryData(macCriteriaEntryData, childMacCriteriaConfig);
                    parsedDefaultTargetData['sap-ingress']['mac-criteria']['entry'] = macCriteriaEntryArray;
                } else {
                    delete parsedDefaultTargetData['sap-ingress']['mac-criteria'];
                }
            }
            let ipCriteriaEntryData = parsedDefaultTargetData['sap-ingress']['ip-criteria']['entry'];
            if (ipCriteriaEntryData !== null && ipCriteriaEntryData.length !== 0) {
                let childIpCriteriaConfig = childrenConfig["aingr.IpMatch"];
                if (childIpCriteriaConfig != undefined && childIpCriteriaConfig.length != 0) {
                    let ipCriteriaEntryArray = this.extractIpCriteriaEntryData(ipCriteriaEntryData, childIpCriteriaConfig);
                    parsedDefaultTargetData['sap-ingress']['ip-criteria']['entry'] = ipCriteriaEntryArray;
                } else {
                    delete parsedDefaultTargetData['sap-ingress']['ip-criteria'];
                }
            }
            let ipv6CriteriaEntryData = parsedDefaultTargetData['sap-ingress']['ipv6-criteria']['entry'];
            if (ipv6CriteriaEntryData !== null && ipv6CriteriaEntryData.length !== 0) {
                let childIpv6CriteriaConfig = childrenConfig["aingr.Ipv6Match"];
                if (childIpv6CriteriaConfig != undefined && childIpv6CriteriaConfig.length != 0) {
                    let ipv6CriteriaEntryArray = this.extractIPv6CriteriaEntryData(ipv6CriteriaEntryData, childIpv6CriteriaConfig);
                    parsedDefaultTargetData['sap-ingress']['ipv6-criteria']['entry'] = ipv6CriteriaEntryArray;
                } else {
                    delete parsedDefaultTargetData['sap-ingress']['ipv6-criteria'];
                }
            }
            let fcData = parsedDefaultTargetData['sap-ingress']['fc'];
            if (fcData !== null && Array.isArray(fcData) && fcData.length !== 0) {
                let childFcConfig = childrenConfig["aingr.ForwardingClass"];
                if (childFcConfig != undefined && childFcConfig.length != 0) {
                    let fcArray = this.extractFcData(fcData, childFcConfig);
                    parsedDefaultTargetData['sap-ingress']['fc'] = fcArray;
                } else {
                    delete parsedDefaultTargetData['sap-ingress']['fc'];
                }
            }
            let policerData = parsedDefaultTargetData['sap-ingress']['policer'];
            if (policerData !== null && Array.isArray(policerData) && policerData.length !== 0) {
                let childPolicerConfig = childrenConfig["aingr.Policer"];
                if (childPolicerConfig != undefined && childPolicerConfig.length != 0) {
                    let policerDataArray = this.extractPolicerData(policerData, childPolicerConfig);
                    parsedDefaultTargetData['sap-ingress']['policer'] = policerDataArray;
                } else {
                    delete parsedDefaultTargetData['sap-ingress']['policer'];
                }
            }
        }
        if(sapIngressConfig && !sapIngressConfig['children-Set']){
           delete parsedDefaultTargetData['sap-ingress']['policer'];
           delete parsedDefaultTargetData['sap-ingress']['fc'];
           delete parsedDefaultTargetData['sap-ingress']['ipv6-criteria'];
           delete parsedDefaultTargetData ['sap-ingress']['ip-criteria'];
           delete parsedDefaultTargetData['sap-ingress']['mac-criteria'];
        }
        return parsedDefaultTargetData;
    }

    this.extractPolicyLevelProperties = function (defaultTargetData, sapIngressConfig) {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++) {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object') {
                let mappings = modelDeviceMapping.getSapIngressMapping();
                this.traverseAndUpdateConfig(targetKey, targetObj, sapIngressConfig, mappings);
            }
        }
    }

    this.extractMacCriteriaEntryData = function (defaultMacCriteriaEntry, childrenConfigeration) {
        let macCriteriaEntryDefaults = defaultMacCriteriaEntry[0];
        let macCriteriaEntryArray = [];
        if (childrenConfigeration !== undefined && childrenConfigeration !== null) {
            if (Array.isArray(childrenConfigeration)) {
                for (let i = 0; i < childrenConfigeration.length; i++) {
                    let childConfig = childrenConfigeration[i];
                    let macCriteriaEntryData = this.MacCriteriaEntryData(macCriteriaEntryDefaults, childConfig);
                    macCriteriaEntryArray.push(macCriteriaEntryData);
                }
            } else {
                let childConfig = childrenConfigeration;
                let macCriteriaEntryData = this.MacCriteriaEntryData(macCriteriaEntryDefaults, childConfig);
                macCriteriaEntryArray.push(macCriteriaEntryData);

            }
        }
        return macCriteriaEntryArray;
    }

    this.MacCriteriaEntryData = function (macCriteriaEntryDefaults, childConfig) {
        let macCriteriaEntryData = JSON.parse(JSON.stringify(macCriteriaEntryDefaults));
        macCriteriaEntryData['entry-id'] = childConfig['id'];
        macCriteriaEntryData['description'] = childConfig['description'];
        macCriteriaEntryData['match']['frame-type'] = util.transformBrownfieldProtocol(childConfig['frameType']);
        if (childConfig['sourceMacAddress'] === '00-00-00-00-00-00' && childConfig['sourceMacAddressMask'] === '00-00-00-00-00-00') {
            macCriteriaEntryData['match']['src-mac'] = undefined;
        } else {
            macCriteriaEntryData['match']['src-mac']['address'] = util.brownFieldNfmpValidMacAddress(childConfig['sourceMacAddress']);
            macCriteriaEntryData['match']['src-mac']['mask'] = util.brownFieldNfmpValidMacAddress(childConfig['sourceMacAddressMask']);
        }
        if (childConfig['destinationMacAddress'] === '00-00-00-00-00-00' && childConfig['destinationMacAddressMask'] === '00-00-00-00-00-00') {
            macCriteriaEntryData['match']['dst-mac'] = undefined;
        } else {
            macCriteriaEntryData['match']['dst-mac']['address'] = util.brownFieldNfmpValidMacAddress(childConfig['destinationMacAddress']);
            macCriteriaEntryData['match']['dst-mac']['mask'] = util.brownFieldNfmpValidMacAddress(childConfig['destinationMacAddressMask']);
        }
        if (childConfig['dot1pValue'] === 'default' && childConfig['dot1pMask'] === 'priority_0') {
            macCriteriaEntryData['match']['dot1p'] = undefined;
        } else {
            macCriteriaEntryData['match']['dot1p']['priority'] = util.brownFieldNfmpdot1p(childConfig['dot1pValue']);
            macCriteriaEntryData['match']['dot1p']['mask'] = util.brownFieldNfmpdot1p(childConfig['dot1pMask']);
        }
        if (childConfig['ethernetType'] === '-1') {
            macCriteriaEntryData['match']['etype'] = undefined;
        } else if (childConfig['ethernetType']) {
            let eType = childConfig['ethernetType'];
            macCriteriaEntryData['match']['etype'] = "0x" + Number(eType).toString(16);
        }
        if (childConfig['forwardingClass']) {
            macCriteriaEntryData["action"]["fc"] = childConfig['forwardingClass'];
        }
        this.clearEmptiesAndNull(macCriteriaEntryData);

        return macCriteriaEntryData;

    }

    this.extractIpCriteriaEntryData = function (defaultIpCriteriaEntry, childrenConfigeration) {
        let ipCriteriaEntryDefaults = defaultIpCriteriaEntry[0];
        let ipCriteriaEntryArray = [];
        if (Array.isArray(childrenConfigeration)) {
            for (let i = 0; i < childrenConfigeration.length; i++) {
                let childConfig = childrenConfigeration[i];
                let ipCriteriaEntryData = this.IPCriteriaEntryData(ipCriteriaEntryDefaults, childConfig);
                ipCriteriaEntryArray.push(ipCriteriaEntryData);
            }
        } else {
            let childConfig = childrenConfigeration;
            let ipCriteriaEntryData = this.IPCriteriaEntryData(ipCriteriaEntryDefaults, childConfig);
            ipCriteriaEntryArray.push(ipCriteriaEntryData);

        }
        return ipCriteriaEntryArray;
    }
    this.IPCriteriaEntryData = function (ipCriteriaEntryDefaults, childConfig) {
        let ipCriteriaEntryData = JSON.parse(JSON.stringify(ipCriteriaEntryDefaults));
        ipCriteriaEntryData['entry-id'] = childConfig['id'];
        ipCriteriaEntryData['description'] = childConfig['description'];
        if (childConfig['dscp'] && childConfig['dscp'] != "default") {
            ipCriteriaEntryData["match"]["dscp"] = childConfig['dscp'];
        }
        if (childConfig['sourceIpAddress'] === '0.0.0.0' && childConfig['sourceIpAddressMask'] === 'ipAddrMask0') {
            ipCriteriaEntryData['match']['src-ip'] = undefined;
        } else {
            if (childConfig['sourceIpAddress'] && childConfig['sourceIpAddressMask'] && childConfig['sourceIpAddress'] !== "0.0.0.0" && childConfig['sourceIpAddressMask'] !== "ipAddrMask0") {
                ipCriteriaEntryData['match']['src-ip']['address'] = childConfig['sourceIpAddress'] + "/" + childConfig['sourceIpAddressMask'].replace("ipAddrMask", "");
            } else {
                ipCriteriaEntryData['match']['src-ip']['address'] = childConfig['sourceIpAddress'];
            }
            if (childConfig["sourceIpAddressFullMask"] && childConfig["sourceIpAddressFullMask"] !== '0.0.0.0' && childConfig['sourceIpAddressMask'] === "ipAddrMask0") {
                ipCriteriaEntryData['match']['src-ip']['mask'] = childConfig['sourceIpAddressFullMask'];
            }
        }
        if (childConfig['destinationIpAddress'] === '0.0.0.0' && childConfig['destinationIpAddressMask'] === 'ipAddrMask0') {
            ipCriteriaEntryData['match']['dst-ip'] = undefined;
        } else {
            if (childConfig['destinationIpAddress'] && childConfig['destinationIpAddressMask'] && childConfig['destinationIpAddress'] !== "0.0.0.0" && childConfig['destinationIpAddressMask'] !== "ipAddrMask0") {
                ipCriteriaEntryData['match']['dst-ip']['address'] = childConfig['destinationIpAddress'] + "/" + childConfig['destinationIpAddressMask'].replace("ipAddrMask", "");

            } else {
                ipCriteriaEntryData['match']['dst-ip']['address'] = childConfig['destinationIpAddress'];
            }
            if (childConfig["destinationIpAddressFullMask"] && childConfig["destinationIpAddressFullMask"] !== '0.0.0.0' && childConfig['destinationIpAddressMask']==="ipAddrMask0") {
                ipCriteriaEntryData['match']['dst-ip']['mask'] = childConfig['destinationIpAddressFullMask'];
            }
        }

        if (childConfig['sourcePort1'] === 'NONE') {
            ipCriteriaEntryData['match']['src-port'] = undefined;
        } else if (childConfig['sourcePort1'] !== "0") {
            ipCriteriaEntryData['match']['src-port']['eq'] = childConfig['sourcePort1'];
        }
        if (childConfig['destinationPort1'] === 'NONE') {
            ipCriteriaEntryData['match']['dst-port'] = undefined;
        } else if (childConfig['destinationPort1'] !== "0") {
            ipCriteriaEntryData['match']['dst-port']['eq'] = childConfig['destinationPort1'];

        }
        if (childConfig['forwardingClass']) {
            ipCriteriaEntryData["action"]["fc"] = childConfig['forwardingClass'];
        }
        this.clearEmptiesAndNull(ipCriteriaEntryData);
        return ipCriteriaEntryData;
    }
    this.extractIPv6CriteriaEntryData = function (defaultIpv6CriteriaEntry, childrenConfigeration) {
        let ipv6CriteriaEntryDefaults = defaultIpv6CriteriaEntry[0];
        let ipv6CriteriaEntryArray = [];
        if (Array.isArray(childrenConfigeration)) {
            for (let i = 0; i < childrenConfigeration.length; i++) {
                let childConfig = childrenConfigeration[i];
                let IPv6CriteriaEntryData = this.IPv6CriteriaEntryData(ipv6CriteriaEntryDefaults, childConfig);
                ipv6CriteriaEntryArray.push(IPv6CriteriaEntryData);
            }
        } else {
            let childConfig = childrenConfigeration;
            let IPv6CriteriaEntryData = this.IPv6CriteriaEntryData(ipv6CriteriaEntryDefaults, childConfig);
            ipv6CriteriaEntryArray.push(IPv6CriteriaEntryData);

        }
        return ipv6CriteriaEntryArray;
    }
    this.IPv6CriteriaEntryData = function (IPv6FilterEntryDeviceConfig, childConfig) {
        let ipv6CriteriaEntryData = JSON.parse(JSON.stringify(IPv6FilterEntryDeviceConfig));
        ipv6CriteriaEntryData['entry-id'] = childConfig['id'];
        ipv6CriteriaEntryData['description'] = childConfig['description'];
        if (childConfig['sourceIpAddress'] === '0:0:0:0:0:0:0:0' && childConfig['sourceIpAddressMask'] === '0') {
            ipv6CriteriaEntryData['match']['src-ip'] = undefined;
        } else {
            if (childConfig['sourceIpAddress'] && childConfig['sourceIpAddressMask'] && childConfig['sourceIpAddress'] !== "0:0:0:0:0:0:0:0" && childConfig['sourceIpAddressMask'] !== "0") {
                ipv6CriteriaEntryData['match']['src-ip']['address'] = childConfig['sourceIpAddress'] + "/" + childConfig['sourceIpAddressMask'];
            } else {
                ipv6CriteriaEntryData['match']['src-ip']['address'] = childConfig['sourceIpAddress'];
            }
            if (childConfig["sourceIpAddressFullMask"] && childConfig["sourceIpAddressFullMask"] !== '0:0:0:0:0:0:0:0' && childConfig['sourceIpAddressMask']==="0") {
                ipv6CriteriaEntryData['match']['src-ip']['mask'] = childConfig['sourceIpAddressFullMask'];
            }
        }
        if (childConfig['destinationIpAddress'] === '0:0:0:0:0:0:0:0' && childConfig['destinationIpAddressMask'] === '0') {
            ipv6CriteriaEntryData['match']['dst-ip'] = undefined;
        } else {
            if (childConfig['destinationIpAddress'] && childConfig['destinationIpAddressMask'] && childConfig['destinationIpAddress'] !== "0:0:0:0:0:0:0:0" && childConfig['destinationIpAddressMask'] !== "0") {
                ipv6CriteriaEntryData['match']['dst-ip']['address'] = childConfig['destinationIpAddress'] + "/" + childConfig['destinationIpAddressMask'];

            } else {
                ipv6CriteriaEntryData['match']['dst-ip']['address'] = childConfig['destinationIpAddress'];
            }
            if (childConfig["destinationIpAddressFullMask"] && childConfig["destinationIpAddressFullMask"] !== '0:0:0:0:0:0:0:0' &&  childConfig['destinationIpAddressMask']==="0") {
                ipv6CriteriaEntryData['match']['dst-ip']['mask'] = childConfig['destinationIpAddressFullMask'];
            }
        }
        if (childConfig['dscp'] && childConfig['dscp'] != "default") {
            ipv6CriteriaEntryData["match"]["dscp"] = childConfig['dscp'];
        }
        if (childConfig['forwardingClass']) {
            ipv6CriteriaEntryData['action']['fc'] = childConfig['forwardingClass']
        }
        this.clearEmptiesAndNull(ipv6CriteriaEntryData);
        return ipv6CriteriaEntryData;
    }

    this.extractPolicerData = function (policerData, childrenConfigeration) {
        let policerConfigData = policerData[0];
        let policerConfigArray = [];
        if (Array.isArray(childrenConfigeration)) {
            for (let i = 0; i < childrenConfigeration.length; i++) {
                let childConfig = childrenConfigeration[i];
                let PolicerConfigDataPayload = this.PolicerConfigeration(policerConfigData, childConfig);
                policerConfigArray.push(PolicerConfigDataPayload);
            }
        } else {
            let childConfig = childrenConfigeration;
            let PolicerConfigDataPayload = this.PolicerConfigeration(policerConfigData, childConfig);
            policerConfigArray.push(PolicerConfigDataPayload);

        }
        return policerConfigArray;
    }

    this.PolicerConfigeration = function (defaultpolicerConfigData, childConfig) {
        let policerConfigData = JSON.parse(JSON.stringify(defaultpolicerConfigData));
        if (childConfig["id"]) {
            policerConfigData["policer-id"] = childConfig["id"];
        }
        if (childConfig["description"]) {
            policerConfigData["description"] = childConfig["description"];
        }
        if (childConfig["statsMode"]) {
            policerConfigData["stat-mode"] = util.transformPolicerStatModeBf(childConfig["statsMode"]);
        }
        if (childConfig["mbs"]) {
            if (childConfig["mbs"] === "-1") {
                policerConfigData["mbs"] = "auto";
            } else {
                policerConfigData["mbs"] = childConfig["mbs"]
            }
        }
        if (childConfig["cbs"]) {
            if (childConfig["cbs"] === "-1") {
                policerConfigData["cbs"] = "auto";
            } else {
                policerConfigData["cbs"] = childConfig["cbs"];
            }
        }
        if (childConfig["adminPir"]) {
            if (childConfig["adminPir"] === "-1") {
                policerConfigData["rate"]["pir"] = "max";
            } else {
                policerConfigData["rate"]["pir"] = childConfig["adminPir"];

            }
        }
        if (childConfig["adminCir"]) {
            if (childConfig["adminCir"] === "-1") {
                policerConfigData["rate"]["cir"] = "max";
            } else {
                policerConfigData["rate"]["cir"] = childConfig["adminCir"];
            }
        }
        if (childConfig["cirAdaptation"]) {
            policerConfigData["adaptation-rule"]["cir"] = childConfig["cirAdaptation"];

        }
        if (childConfig["pirAdaptation"]) {
            policerConfigData["adaptation-rule"]["pir"] = childConfig["pirAdaptation"];
        }
        this.clearEmptiesAndNull(policerConfigData);
        return policerConfigData

    }
    this.extractFcData = function (fcData, childrenConfigeration) {
        let fcConfigData = fcData[0];
        let policerConfigArray = [];
        if (Array.isArray(childrenConfigeration)) {
            for (let i = 0; i < childrenConfigeration.length; i++) {
                let childConfig = childrenConfigeration[i];
                let forwardingClassConfigDataPayload = this.forwardingClassConfigeration(fcConfigData, childConfig);
                policerConfigArray.push(forwardingClassConfigDataPayload);
            }
        } else {
            let childConfig = childrenConfigeration;
            let forwardingClassConfigDataPayload = this.forwardingClassConfigeration(fcConfigData, childConfig);
            policerConfigArray.push(forwardingClassConfigDataPayload);

        }
        return policerConfigArray;
    }

    this.forwardingClassConfigeration = function (defaultFCConfigData, childConfig) {
        let ForwardingClassData = JSON.parse(JSON.stringify(defaultFCConfigData));
        if (childConfig['forwardingClass']) {
            ForwardingClassData['fc-name'] = childConfig['forwardingClass'];
        }
        if (childConfig['multicastPolicerId'] && childConfig['multicastPolicerId'] !== '0') {
            ForwardingClassData['multicast-policer'] = childConfig['multicastPolicerId'];
        }
        if (childConfig['broadcastPolicerId'] && childConfig['broadcastPolicerId'] !== '0') {
            ForwardingClassData['broadcast-policer'] = childConfig['broadcastPolicerId'];
        }
        if (childConfig['unknownPolicerId'] && childConfig['unknownPolicerId'] !== '0') {
            ForwardingClassData['unknown-policer'] = childConfig['unknownPolicerId'];
        }
        this.clearEmptiesAndNull(ForwardingClassData);
        return ForwardingClassData;
    }
    this.traverseAndUpdateConfig = function (objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "sap-ingress.mac-criteria.entry" &&  mappedKey !=="sap-ingress.ip-criteria.entry" &&  mappedKey !=="sap-ingress.ipv6-criteria.entry" && mappedKey !=="sap-ingress.policer" && mappedKey !=="sap-ingress.fc") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }


    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, parsedDeviceConfig) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = parsedDeviceConfig[nfmpKey];
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue, parsedDeviceConfig);

    }

    this.transformDeviceValue = function (mappedKey, deviceValue, parsedDeviceConfig) {
        if (deviceValue !== null) {
            switch (mappedKey) {
                case "sap-ingress.policer-allocation":
                    deviceValue = util.nfmpPolicerAllocationBf(deviceValue);
                    break;
                case "sap-ingress.mac-criteria.type":
                    deviceValue = util.transformBFCriteriaType(deviceValue);
                    break;
                case "sap-ingress.ipv6-criteria.type":
                    deviceValue = util.transformBFCriteriaType(deviceValue);
                    break;
                case "sap-ingress.ip-criteria.type":
                    deviceValue = util.transformBFCriteriaType(deviceValue);
                    break;
                default:
            }
            return deviceValue;
        }
    }

    this.constructSearchString = function (className, objectFullName) {
        let searchJson = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        return searchJson;
    }

    this.clearEmptiesAndNull = function (o) {
        for (let k in o) {
            if (o[k] === null) {
                delete o[k];
            }
            if (!o[k] || typeof o[k] !== "object") {
                continue
            }

            this.clearEmptiesAndNull(o[k]);
            if (Object.keys(o[k]).length === 0) {
                delete o[k];
            }
        }
    }
}
