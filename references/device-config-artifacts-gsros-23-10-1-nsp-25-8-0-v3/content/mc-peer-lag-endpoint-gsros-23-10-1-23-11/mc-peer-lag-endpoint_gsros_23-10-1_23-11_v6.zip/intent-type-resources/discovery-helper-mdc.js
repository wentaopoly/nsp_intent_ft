var RuntimeException = Java.type('java.lang.RuntimeException');

load({
    script: resourceProvider.getResource('mdc-fwk.js'),
    name: 'MdcFwk'
});
load({
    script: resourceProvider.getResource('parse-target.js'),
    name: 'ParseTarget'
});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
function MdcDiscoveryHelper() {
    let mdcFwk = new MdcFwk();
    let util = new utilities();
    let parseTarget = new ParseTarget();

    this.getDeviceConfiguration = function (targetWithTemplate, initialPropertyName) {

        let endPointA = targetWithTemplate.split("#")[2];
        let endPointAPeer = targetWithTemplate.split("#")[3];
        let endPointB = targetWithTemplate.split("#")[4];
        let endPointBPeer = targetWithTemplate.split("#")[5];

        let endPointAUrl = "/restconf/data/network-device-mgr:network-devices/network-device=" + endPointA + "/root/nokia-conf:/configure/redundancy/multi-chassis/" + initialPropertyName + "=" + endPointBPeer;

        let endPointAResult = mdcFwk.fetch(endPointA, endPointAUrl);
        let configFromEndpointA = endPointAResult.msg["nokia-conf:" + initialPropertyName];
        if (configFromEndpointA == undefined) {
            throw new RuntimeException("cannot get configuration from device " + endPointA);
        }
        let endPointAData = configFromEndpointA[0];

        let endPointBUrl = "/restconf/data/network-device-mgr:network-devices/network-device=" + endPointB + "/root/nokia-conf:/configure/redundancy/multi-chassis/" + initialPropertyName + "=" + endPointAPeer;
        let endPointBResult = mdcFwk.fetch(endPointB, endPointBUrl);
        let configFromEndpointB = endPointBResult.msg["nokia-conf:" + initialPropertyName];
        if (configFromEndpointB == undefined) {
            throw new RuntimeException("cannot get configuration from device " + endPointB);
        }
        let endPointBData = configFromEndpointB[0];

        let endPointAdetails = {};
        endPointAdetails['admin-state'] = endPointAData['admin-state'];
        endPointAdetails['description'] = endPointAData['description'];
        endPointAdetails['authentication-key'] = endPointAData['authentication-key'];
        endPointAdetails['peer-name'] = endPointAData['peer-name'];

        let endPointBdetails = {};
        endPointBdetails['admin-state'] = endPointBData['admin-state'];
        endPointBdetails['description'] = endPointBData['description'];
        endPointBdetails['authentication-key'] = endPointBData['authentication-key'];
        endPointBdetails['peer-name'] = endPointBData['peer-name'];

        let sync = {};

        if(endPointAData["sync"])
        {
            sync['endPointADetails'] = {};
            sync['endPointADetails']['admin-state'] = endPointAData["sync"]["admin-state"];
            sync['endPointADetails']['igmp'] = endPointAData["sync"]["igmp"];
            sync['endPointADetails']['igmp-snooping'] = endPointAData["sync"]["igmp-snooping"];
            sync['endPointADetails']['ipsec'] = endPointAData["sync"]["ipsec"];
            sync['endPointADetails']['l2tp'] = endPointAData["sync"]["l2tp"];
            sync['endPointADetails']['local-dhcp-server'] = endPointAData["sync"]["local-dhcp-server"];
            sync['endPointADetails']['mc-ring'] = endPointAData["sync"]["mc-ring"];
            sync['endPointADetails']['mld'] = endPointAData["sync"]["mld"];
            sync['endPointADetails']['mld-snooping'] = endPointAData["sync"]["mld-snooping"];
            sync['endPointADetails']['python'] = endPointAData["sync"]["python"];
            sync['endPointADetails']['srrp'] = endPointAData["sync"]["srrp"];
            sync['endPointADetails']['sub-host-trk'] = endPointAData["sync"]["sub-host-trk"];
            sync['endPointADetails']['nat'] = endPointAData["sync"]["nat"];
            sync['endPointADetails']['pim-snooping'] = endPointAData["sync"]["pim-snooping"];
            sync['endPointADetails']['sub-mgmt'] = endPointAData["sync"]["sub-mgmt"];
            sync['endPointADetails']['transport-encryption'] = endPointAData["sync"]["transport-encryption"];
            sync['endPointADetails']['tags'] = endPointAData["sync"]["tags"];
            sync['endPointADetails']['tunnel-group'] = endPointAData["sync"]["tunnel-group"];
            sync['endPointADetails']['track-srrp'] = endPointAData["sync"]["track-srrp"];
            sync['endPointADetails']['diameter-node'] = endPointAData["sync"]["diameter-node"];
        }
        if(endPointBData["sync"])
        {
            sync['endPointBDetails'] = {};
            sync['endPointBDetails']['admin-state'] = endPointBData["sync"]["admin-state"];
            sync['endPointBDetails']['igmp'] = endPointBData["sync"]["igmp"];
            sync['endPointBDetails']['igmp-snooping'] = endPointBData["sync"]["igmp-snooping"];
            sync['endPointBDetails']['ipsec'] = endPointBData["sync"]["ipsec"];
            sync['endPointBDetails']['l2tp'] = endPointBData["sync"]["l2tp"];
            sync['endPointBDetails']['local-dhcp-server'] = endPointBData["sync"]["local-dhcp-server"];
            sync['endPointBDetails']['mc-ring'] = endPointBData["sync"]["mc-ring"];
            sync['endPointBDetails']['mld'] = endPointBData["sync"]["mld"];
            sync['endPointBDetails']['mld-snooping'] = endPointBData["sync"]["mld-snooping"];
            sync['endPointBDetails']['python'] = endPointBData["sync"]["python"];
            sync['endPointBDetails']['srrp'] = endPointBData["sync"]["srrp"];
            sync['endPointBDetails']['sub-host-trk'] = endPointBData["sync"]["sub-host-trk"];
            sync['endPointBDetails']['nat'] = endPointBData["sync"]["nat"];
            sync['endPointBDetails']['pim-snooping'] = endPointBData["sync"]["pim-snooping"];
            sync['endPointBDetails']['sub-mgmt'] = endPointBData["sync"]["sub-mgmt"];
            sync['endPointBDetails']['transport-encryption'] = endPointBData["sync"]["transport-encryption"];
            sync['endPointBDetails']['tags'] = endPointBData["sync"]["tags"];
            sync['endPointBDetails']['tunnel-group'] = endPointBData["sync"]["tunnel-group"];
            sync['endPointBDetails']['track-srrp'] = endPointBData["sync"]["track-srrp"];
            sync['endPointBDetails']['diameter-node'] = endPointBData["sync"]["diameter-node"];
        }

        if(endPointAData["sync"] && endPointAData["sync"]["admin-state"] == "enable" &&
             endPointBData["sync"] && endPointBData["sync"]["admin-state"] == "enable")
        {
            sync["admin-state"] = "enable";
        }
        else
        {
            sync["admin-state"] = "disable";
        }

        let mcLag = {};
        let endPointAMclag = {};
        if(endPointAData['mc-lag'])
        {
            endPointAMclag['admin-state'] = endPointAData['mc-lag']['admin-state']
            endPointAMclag['keep-alive-interval'] = endPointAData['mc-lag']['keep-alive-interval']
            endPointAMclag['hold-on-neighbor-failure'] = endPointAData['mc-lag']['hold-on-neighbor-failure']
        }
        let endPointBMclag = {};
        if(endPointBData['mc-lag'])
        {
            endPointBMclag['admin-state'] = endPointBData['mc-lag']['admin-state']
            endPointBMclag['keep-alive-interval'] = endPointBData['mc-lag']['keep-alive-interval']
            endPointBMclag['hold-on-neighbor-failure'] = endPointBData['mc-lag']['hold-on-neighbor-failure']
        }

        let lags = [];
        if(endPointAData['mc-lag'])
        {
            let endPointALags = endPointAData['mc-lag']['lag']
            if (endPointALags && endPointALags.length) {
                if(!Array.isArray(endPointALags))
                {
                    endPointALags = [endPointALags];
                }
                for (let i = 0; i < endPointALags.length; i++) {
                    let objInfo = endPointALags[i];
                    let lagObj = {};
                    lagObj["lag-name"] = objInfo["lag-name"];
                    lagObj["lacp-key"] = objInfo["lacp-key"];
                    lagObj["system-id"] = objInfo["system-id"];
                    lagObj["system-priority"] = objInfo["system-priority"];
                    lagObj["remote-lag"] = objInfo["remote-lag"];
                    lags.push(lagObj);
                }

            }
        }

        /* else {
            logger.info("*******************else--------if (endPointALags && endPointALags.length)");
            let lagObj = {};
            lagObj["lag-name"] = endPointALags["lag-name"];
            lagObj["lacp-key"] = endPointALags["lacp-key"];
            lagObj["system-id"] = endPointALags["system-id"];
            lagObj["system-priority"] = endPointALags["system-priority"];
            lagObj["remote-lag"] = endPointALags["remote-lag"];
            lags.push(lagObj);
        }*/

        mcLag['endPointADetails'] = endPointAMclag;
        mcLag['endPointBDetails'] = endPointBMclag;
        mcLag['lag'] = lags;

        let peer = {};
        peer['endPointADetails'] = endPointAdetails;
        peer['endPointBDetails'] = endPointBdetails;
        peer['mc-lag'] = mcLag;
        peer["sync"] = sync;

        //mc-endpoint
        let endpointAMcEndpointData  = endPointAData['mc-endpoint'];
        let endpointBMcEndpointData  = endPointBData['mc-endpoint'];

        if(endpointAMcEndpointData || endpointBMcEndpointData)
        {
            peer['enable-mc-endpoint'] = true;
            peer['mc-endpoint']={};
            if(endpointAMcEndpointData && Object.keys(endpointAMcEndpointData).length !== 0)
            {
                let endPointAMcEndpoint = {};
                endPointAMcEndpoint['admin-state'] = endpointAMcEndpointData['admin-state'];
                endPointAMcEndpoint['system-priority'] = endpointAMcEndpointData['system-priority'];
                endPointAMcEndpoint['hold-on-neighbor-failure'] = endpointAMcEndpointData['hold-on-neighbor-failure'];
                endPointAMcEndpoint['keep-alive-interval'] = endpointAMcEndpointData['keep-alive-interval'];
                endPointAMcEndpoint['boot-timer'] = endpointAMcEndpointData['boot-timer'];
                endPointAMcEndpoint['passive-mode'] = endpointAMcEndpointData['passive-mode'];
                endPointAMcEndpoint['bfd'] = endpointAMcEndpointData['bfd'];
                peer['mc-endpoint']['endPointADetails'] = endPointAMcEndpoint;
            }
            if(endpointBMcEndpointData && Object.keys(endpointBMcEndpointData).length !== 0)
            {
                let endPointBMcEndpoint = {};
                endPointBMcEndpoint['admin-state'] = endpointBMcEndpointData['admin-state'];
                endPointBMcEndpoint['system-priority'] = endpointBMcEndpointData['system-priority'];
                endPointBMcEndpoint['hold-on-neighbor-failure'] = endpointBMcEndpointData['hold-on-neighbor-failure'];
                endPointBMcEndpoint['keep-alive-interval'] = endpointBMcEndpointData['keep-alive-interval'];
                endPointBMcEndpoint['boot-timer'] = endpointBMcEndpointData['boot-timer'];
                endPointBMcEndpoint['passive-mode'] = endpointBMcEndpointData['passive-mode'];
                endPointBMcEndpoint['bfd'] = endpointBMcEndpointData['bfd'];
                peer['mc-endpoint']['endPointBDetails'] = endPointBMcEndpoint;
            }
        }
        else
        {
           peer['enable-mc-endpoint'] = false;
        }

        //mc-ipsec
        let endPointAMcIpsecData  = endPointAData['mc-ipsec'];
        let endPointBMcIpsecData  = endPointBData['mc-ipsec'];

        if(endPointAMcIpsecData || endPointBMcIpsecData)
        {
            peer['enable-mc-ipsec'] = true;
            peer['mc-ipsec']={};
            let mcIpsecTunnelConfig = {};
            if(endPointAMcIpsecData && Object.keys(endPointAMcIpsecData).length !== 0)
            {
                let endPointAMcIpsec = {};
                if (endPointAMcIpsecData['tunnel-group']) {
                    var tunnelGroupConfig = [];
                    if (!Array.isArray(endPointAMcIpsecData['tunnel-group'])) {
                        endPointAMcIpsecData['tunnel-group'] = [endPointAMcIpsecData['tunnel-group']];
                    }
                    if (!Array.isArray(endPointBMcIpsecData['tunnel-group'])) {
                        endPointBMcIpsecData['tunnel-group'] = [endPointBMcIpsecData['tunnel-group']];
                    }
                   if(endPointAMcIpsecData["tunnel-group"].length === endPointBMcIpsecData["tunnel-group"].length){
                    for (var index in endPointAMcIpsecData["tunnel-group"]) {
                        var tunnelGroupDataA = endPointAMcIpsecData["tunnel-group"][index];
                        var tunnelGroupDataB = endPointBMcIpsecData["tunnel-group"][index];
                        var item = {};
                        if (tunnelGroupDataA["tunnel-group-id"]) {
                            item["firstTunnelGroupId"] = tunnelGroupDataA["tunnel-group-id"];
                        }
                        if (tunnelGroupDataA["admin-state"]) {
                            item["firstSiteAdministrativeState"] = util.convertToNfmpAdminstarteState(tunnelGroupDataA["admin-state"]);
                        }
                        if (tunnelGroupDataA["peer-group"]) {
                            item["firstSitePeerGroup"] = tunnelGroupDataA["peer-group"];
                        }
                        if (tunnelGroupDataA["priority"]) {
                            item["firstSitePriority"] = tunnelGroupDataA["priority"];
                        }
                        if (tunnelGroupDataB["tunnel-group-id"]) {
                            item["secondTunnelGroupId"] = tunnelGroupDataB["tunnel-group-id"];
                        }
                        if (tunnelGroupDataB["admin-state"]) {
                            item["secondSiteAdministrativeState"] = util.convertToNfmpAdminstarteState(tunnelGroupDataB["admin-state"]);
                        }
                        if (tunnelGroupDataB["peer-group"]) {
                            item["secondSitePeerGroup"] = tunnelGroupDataB["peer-group"];
                        }
                        if (tunnelGroupDataB["priority"]) {
                            item["secondSitePriority"] = tunnelGroupDataB["priority"];
                        }
                        tunnelGroupConfig.push(item);
                    }
                    mcIpsecTunnelConfig['tunnelGroup'] = tunnelGroupConfig;
                }
               }
                peer['mc-ipsec'] = mcIpsecTunnelConfig;
                endPointAMcIpsec['bfd-liveness'] = endPointAMcIpsecData['bfd-liveness'];
                endPointAMcIpsec['keep-alive-interval'] = endPointAMcIpsecData['keep-alive-interval'];
                endPointAMcIpsec['hold-on-neighbor-failure'] = endPointAMcIpsecData['hold-on-neighbor-failure'];
                var discoveryIntervalAData = endPointAMcIpsecData['discovery-interval'];
                if(discoveryIntervalAData){
                    endPointAMcIpsec['discovery-interval'] = {}
                    if(discoveryIntervalAData['interval-secs']){
                        endPointAMcIpsec['discovery-interval']['interval-secs'] = discoveryIntervalAData['interval-secs'];
                    }
                    if(discoveryIntervalAData['boot']){
                        endPointAMcIpsec['discovery-interval']['boot'] = discoveryIntervalAData['boot'];
                    }
                }
                if (endPointAMcIpsecData['domain']) {
                     var domainADetails = [];
                     if (!Array.isArray(endPointAMcIpsecData['domain'])) {
                        endPointAMcIpsecData['domain'] = [endPointAMcIpsecData['domain']];
                     }
                     for (var index in endPointAMcIpsecData["domain"]) {
                        var domainListDataA = endPointAMcIpsecData["domain"][index];
                        var item = {};
                        if (domainListDataA["id"]) {
                            item["id"] = domainListDataA["id"];
                        }
                        if (domainListDataA["admin-state"]) {
                            item["admin-state"] = domainListDataA["admin-state"];
                        }
                        domainADetails.push(item);
                     }
                    endPointAMcIpsec['domain'] = domainADetails;
                }
                peer['mc-ipsec']['endPointADetails'] = endPointAMcIpsec;
            }
            if(endPointBMcIpsecData && Object.keys(endPointBMcIpsecData).length !== 0)
            {
                let endPointBMcIpsec = {};
                endPointBMcIpsec['bfd-liveness'] = endPointBMcIpsecData['bfd-liveness'];
                endPointBMcIpsec['keep-alive-interval'] = endPointBMcIpsecData['keep-alive-interval'];
                endPointBMcIpsec['hold-on-neighbor-failure'] = endPointBMcIpsecData['hold-on-neighbor-failure'];
                var discoveryIntervalBData = endPointBMcIpsecData['discovery-interval'];
                if(discoveryIntervalBData){
                    endPointBMcIpsec['discovery-interval'] = {}
                    if(discoveryIntervalBData['interval-secs']){
                        endPointBMcIpsec['discovery-interval']['interval-secs'] = discoveryIntervalBData['interval-secs'];
                    }
                    if(discoveryIntervalBData['boot']){
                        endPointBMcIpsec['discovery-interval']['boot'] = discoveryIntervalBData['boot'];
                    }
                }
                if (endPointBMcIpsecData['domain']) {
                    var domainBDetails = [];
                    if (!Array.isArray(endPointBMcIpsecData['domain'])) {
                        endPointBMcIpsecData['domain'] = [endPointBMcIpsecData['domain']];
                    }
                    for (var index in endPointBMcIpsecData["domain"]) {
                        let domainListDataB = endPointBMcIpsecData["domain"][index];
                        var item = {};
                        if (domainListDataB["id"]) {
                            item["id"] = domainListDataB["id"];
                        }
                        if (domainListDataB["admin-state"]) {
                            item["admin-state"] = domainListDataB["admin-state"];
                        }
                        domainBDetails.push(item);
                    }
                    endPointBMcIpsec['domain'] = domainBDetails;
                }
                peer['mc-ipsec']['endPointBDetails'] = endPointBMcIpsec;
            }
        }
        else
        {
           peer['enable-mc-ipsec'] = false;
        }

        //mc-ring
        let endPointAMcRingData,endPointBMcRingData;
        if(endPointAData['mc-ring'] && endPointAData['mc-ring']['ring'])
        {
            endPointAMcRingData  = endPointAData['mc-ring']['ring'];
        }
        if(endPointBData['mc-ring'] && endPointBData['mc-ring']['ring'])
        {
            endPointBMcRingData  = endPointBData['mc-ring']['ring'];
        }
        peer["mc-ring"] = {}
        if(endPointAMcRingData!= undefined && endPointBMcRingData!=undefined)
        {
            var ringGroupConfig = [];
            if (!Array.isArray(endPointAMcRingData)) {
                endPointAMcRingData = [endPointAMcRingData];
            }
            if (!Array.isArray(endPointBMcRingData)) {
                endPointBMcRingData = [endPointBMcRingData];
            }
            //sort both endpoints based on key 'sync-tag'
            endPointAMcRingData.sort((a, b) => a['sync-tag'].localeCompare(b['sync-tag']));
            endPointBMcRingData.sort((a, b) => a['sync-tag'].localeCompare(b['sync-tag']));

            for (var indexA in endPointAMcRingData) {
                var ringGroupDataA = endPointAMcRingData[indexA];
                for(var indexB in endPointBMcRingData) {
                    var ringGroupDataB = endPointBMcRingData[indexB];
                    var item = {};

                    if(ringGroupDataA['sync-tag'] === ringGroupDataB['sync-tag']) {
                        item["ringName"] = ringGroupDataA['sync-tag'];
                        //endPointADetails
                        item["endPointADetails"] = {};
                        item["endPointADetails"]["ring"] = {};
                        if(ringGroupDataA["admin-state"]) item["endPointADetails"]["ring"]["admin-state"] = ringGroupDataA["admin-state"];
                        if(ringGroupDataA["type"]) item["endPointADetails"]["ring"]["type"] = ringGroupDataA["type"];
                        if(ringGroupDataA["in-band-control-path"]) item["endPointADetails"]["ring"]["in-band-control-path"] = ringGroupDataA["in-band-control-path"];
                        if(ringGroupDataA["path-b"]) item["endPointADetails"]["ring"]["path-b"] = ringGroupDataA["path-b"];
                        if(ringGroupDataA["path-excl"]) item["endPointADetails"]["ring"]["path-excl"] = ringGroupDataA["path-excl"];
                        if(ringGroupDataA["srrp-instance"]) item["endPointADetails"]["ring"]["srrp-instance"] = ringGroupDataA["srrp-instance"];
                        if(ringGroupDataA["ring-node"]) item["endPointADetails"]["ring"]["ring-node"] = ringGroupDataA["ring-node"];
                        //endPointBDetails
                        item["endPointBDetails"] = {};
                        item["endPointBDetails"]["ring"] = {};
                        if(ringGroupDataB["admin-state"]) item["endPointBDetails"]["ring"]["admin-state"] = ringGroupDataB["admin-state"];
                        if(ringGroupDataB["type"]) item["endPointBDetails"]["ring"]["type"] = ringGroupDataB["type"];
                        if(ringGroupDataB["in-band-control-path"]) item["endPointBDetails"]["ring"]["in-band-control-path"] = ringGroupDataB["in-band-control-path"];
                        if(ringGroupDataB["path-b"]) item["endPointBDetails"]["ring"]["path-b"] = ringGroupDataB["path-b"];
                        if(ringGroupDataB["path-excl"]) item["endPointBDetails"]["ring"]["path-excl"] = ringGroupDataB["path-excl"];
                        if(ringGroupDataB["srrp-instance"]) item["endPointBDetails"]["ring"]["srrp-instance"] = ringGroupDataB["srrp-instance"];
                        if(ringGroupDataB["ring-node"]) item["endPointBDetails"]["ring"]["ring-node"] = ringGroupDataB["ring-node"];

                        ringGroupConfig.push(item);
                        break;
                    }
                }
            }

            peer["mc-ring"]["ringGroup"] = ringGroupConfig;
        }


        return peer;
    }

    this.extractDeviceConfig = function (targetData, deviceConfig, initialPropertyName) {
        let parsedTargetData = JSON.parse(targetData);
        let config = parsedTargetData[initialPropertyName];
        if(!config ["mc-ring"]["ringGroup"][0]["endPointADetails"]["ring"]["path-b"]["range"]) {
            config ["mc-ring"]["ringGroup"][0]["endPointADetails"]["ring"]["path-b"]["range"] = [{"start": null,"end": null}];
        }
        if(!config ["mc-ring"]["ringGroup"][0]["endPointADetails"]["ring"]["path-excl"]["range"]) {
            config ["mc-ring"]["ringGroup"][0]["endPointADetails"]["ring"]["path-excl"]["range"] = [{"start": null,"end": null}];
        }
        if(!config ["mc-ring"]["ringGroup"][0]["endPointADetails"]["ring"]["srrp-instance"]) {
            config ["mc-ring"]["ringGroup"][0]["endPointADetails"]["ring"]["srrp-instance"] = [{"id": null}];
        }
        if(!config ["mc-ring"]["ringGroup"][0]["endPointADetails"]["ring"]["ring-node"]) {
            config ["mc-ring"]["ringGroup"][0]["endPointADetails"]["ring"]["ring-node"] = [{"name": null,"src-mac": null,"service-name": null,"dst-ip": null,"src-ip": null,"vlan": null,"interval": null,"admin-state": null}];
        }
        if(!config ["mc-ring"]["ringGroup"][0]["endPointBDetails"]["ring"]["path-b"]["range"]) {
            config ["mc-ring"]["ringGroup"][0]["endPointBDetails"]["ring"]["path-b"]["range"] = [{"start": null,"end": null}];
        }
        if(!config ["mc-ring"]["ringGroup"][0]["endPointBDetails"]["ring"]["path-excl"]["range"]) {
            config ["mc-ring"]["ringGroup"][0]["endPointBDetails"]["ring"]["path-excl"]["range"] = [{"start": null,"end": null}];
        }
        if(!config ["mc-ring"]["ringGroup"][0]["endPointBDetails"]["ring"]["srrp-instance"]) {
            config ["mc-ring"]["ringGroup"][0]["endPointBDetails"]["ring"]["srrp-instance"] = [{"id": null}];
        }
        if(!config ["mc-ring"]["ringGroup"][0]["endPointBDetails"]["ring"]["ring-node"]) {
            config ["mc-ring"]["ringGroup"][0]["endPointBDetails"]["ring"]["ring-node"] = [{"name": null,"src-mac": null,"service-name": null,"dst-ip": null,"src-ip": null,"vlan": null,"interval": null,"admin-state": null}];
        }
        let mergedTargetData = this.traverse(config, deviceConfig);
        parsedTargetData[initialPropertyName] = mergedTargetData;
        return parsedTargetData;
    }

    this.traverse = function (targetData, deviceConfig) {
        if (targetData !== null && targetData !== undefined) {
            let keys = Object.keys(targetData);
            for (let i = 0; i < keys.length; i++) {
                let propertyName = keys[i];
                let deviceValue = deviceConfig[propertyName];

                if (deviceValue != undefined && Array.isArray(deviceValue)) {
                    targetData[propertyName] = this.ArrayTraverse(targetData[propertyName], deviceValue, []);
                } else if (deviceValue != undefined && typeof deviceValue === 'object') {
                    targetData[propertyName] = this.containerTraverse(targetData[propertyName], deviceValue, {});
                } else {
                    targetData[propertyName] = deviceValue
                }
            }

        }
        return targetData;
    }

    this.ArrayTraverse = function (arrayTargetData, arrayDeviceConfigData, arrayData) {
        for (let i = 0; i < arrayDeviceConfigData.length; i++) {
            let arrayObject = {};
            let keys = Object.keys(arrayTargetData[0]);
            for (let j = 0; j < keys.length; j++) {
                let propertyName = keys[j];
                let deviceValue = arrayDeviceConfigData[i][propertyName];
                if (deviceValue != null && deviceValue != undefined && Array.isArray(deviceValue)) {
                    arrayObject[propertyName] = this.ArrayTraverse(arrayTargetData[0][propertyName], deviceValue, []);
                } else if (deviceValue != null && deviceValue != undefined && typeof deviceValue === 'object') {
                    arrayObject[propertyName] = this.containerTraverse(arrayTargetData[0][propertyName], deviceValue, {});

                } else {
                    arrayObject[propertyName] = deviceValue
                }
            }
            arrayData.push(arrayObject);
        }

        return arrayData;
    }

    this.containerTraverse = function (containerTargetData, containerDeviceConfigData, targetContainer) {
        let keys = Object.keys(containerTargetData);
        for (let i = 0; i < keys.length; i++) {
            let propertyName = keys[i];
            let deviceValue = containerDeviceConfigData[propertyName];
            if (deviceValue != null && deviceValue != undefined && Array.isArray(deviceValue)) {
                if (this.isAtrributeLeafList(deviceValue)) {
                    targetContainer[propertyName] = deviceValue;
                } else {
                    targetContainer[propertyName] = this.ArrayTraverse(containerTargetData[propertyName], deviceValue, []);
                }

            } else if (deviceValue != null && deviceValue != undefined && typeof deviceValue === 'object') {
                targetContainer[propertyName] = this.containerTraverse(containerTargetData[propertyName], deviceValue, {});
            } else {
                targetContainer[propertyName] = deviceValue
            }
        }
        return targetContainer;
    }

    this.isAtrributeLeafList = function (leaflistData) {
        let isLeaflist = true;
        for (let i = 0; i < leaflistData.length; i++) {

            if (leaflistData[i] != null && typeof leaflistData[i] == 'object') {
                isLeaflist = false;
                break;
            }
        }
        return isLeaflist;
    }

    this.cipherSpecialCharacterInKey = function (key) {
        return key.replaceAll("/", "%2F").replaceAll(":", "%3A");
    }
}