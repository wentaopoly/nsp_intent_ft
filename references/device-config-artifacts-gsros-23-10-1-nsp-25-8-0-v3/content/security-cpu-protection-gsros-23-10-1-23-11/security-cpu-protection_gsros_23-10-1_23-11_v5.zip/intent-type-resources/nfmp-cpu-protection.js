var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpCpuProtection() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var isAudit = false;
    var isEdit = false;

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        logger.info("input = \n" + input + "-------" + result + "-------" + intentTypeName + "-------" + initialPropertyName + "-------" + uniqueIdentifier);
        // code to handle delete
        if (input.getNetworkState().name() == "delete")
        {
            logger.info("Calling syncDelete");
            return this.syncDelete(input, result);
        }
        // code to handle sync
        var savedTopology = input.getCurrentTopology();
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyId = parseTarget.getUniqueIdentifier(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        logger.info("Policy ID = " + policyId);
        intentConfig["policyId"] = policyId;
        this.createOrModify(neId, intentConfig);
        return util.setSuccessResult(result, savedTopology);
    }
    this.audit = function (target, config, svcTopo, adminState, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        logger.info("AUDIT STARTED");
        var savedTopology = svcTopo;
        savedObjects = {};
        currentObjects = {};
        isAudit = true;
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        intentConfig["policyId"] = parseTarget.getUniqueIdentifier(target);
        var neId = parseTarget.getNeIdFromTarget(target);
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        if (intentConfig)
        {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }
        return auditReport
    }
    this.auditAndCompare = function (neID, intentConfig, auditReport) {
        var cpuPolicyPayload = this.createPolicyLevelPayLoad(neID, intentConfig);
        var result = this.auditRequest(neID, cpuPolicyPayload);
        auditReport = util.reportMisaligned(neID, result, auditReport);
        return auditReport;
    }
    this.auditRequest = function (neId, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }
    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('input json: ' + json)
        return JSON.parse(json);
    }
    this.syncDelete = function (input, result) {
        var neID = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyId = parseTarget.getUniqueIdentifier(input.getTarget());
        var objectFullName = "network:" + neID + ":NE DoS Protection:" + policyId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neID);
        logger.info("Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }
    this.createOrModify = function (neID, intentConfig) {
        var cpuPolicyPayload = this.createPolicyLevelPayLoad(neID, intentConfig);
        var result = this.modifyRequest(neID, cpuPolicyPayload);
        // distribute the policy to the local
        // Distribute Global Policy to Ne in Target
        if (!isEdit)
        {
            let distributeResult = this.distributePolicy(neID, intentConfig, false);
            if (!distributeResult.success)
            {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }
            util.delay(2000);
            // Changing SyncWithGlobal To Local Edit Only
            distributeResult = this.distributePolicy(neID, intentConfig, true);
            if (!distributeResult.success)
            {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }
        }
        return result;
    }
    this.modifyRequest = function (target, payload) {
        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            logger.error("Error while deploying the request {}", JSON.stringify(result.msg));
		    let objFullName = payload["objectFullName"];
		    objFullName = util.modifyNeIdForIpV6(objFullName, target);
		    if(!(objFullName.indexOf("network") !== -1))
		    {
                logger.info("Redeploying the request ...  ");
                result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
                if (!result.success)
                {
                    throw new RuntimeException(result.msg)
                }
		    }
		    else
		    {
                throw new RuntimeException(result.msg)
		    }
        }
        return result;
    }
    this.createPolicyLevelPayLoad = function (neID, intentConfig) {
        var fullClassName = "sitesec.DoSProtection";
        var policyFdn = "NE DoS Protection";
        var objectFullName = "NE DoS Protection:" + intentConfig["policyId"];
        var localPolicyFullName = "network:" + neID + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neID);
        if (util.isObjectExists(fullClassName, localPolicyFullName) || isAudit)
        {
            objectFullName = localPolicyFullName;
            if (!isAudit)
            {
                isEdit = true;
            }
        }
        var properties = {};
        properties["id"] = intentConfig["policyId"];
        properties["description"] = intentConfig["description"];
        properties["overallRateLimit"] = util.convertRateGreenField(intentConfig["overall-rate"]);
        if (intentConfig["alarm"])
        {
            properties["polAlarm"] = intentConfig["alarm"].toString();
        }
        else
        {
            properties["polAlarm"] = "false";
        }
        properties["packetRateLimit"] = util.convertRateGreenField(intentConfig["per-source-rate"]);
        properties["outProfileRate"] = util.convertRateGreenField(intentConfig["out-profile-rate"]["pir"]);
        if (intentConfig["out-profile-rate"]["log-events"])
        {
            properties["outProfRateLogEvnt"] = intentConfig["out-profile-rate"]["log-events"].toString();
        }
        else
        {
            properties["outProfRateLogEvnt"] = "false";
        }
        if (intentConfig["per-source-parameters"]["ip-src-monitoring"]["limit-dhcp-ci-addr-zero"])
        {
            properties["limDhcpCiAddrZero"] = intentConfig["per-source-parameters"]["ip-src-monitoring"]["limit-dhcp-ci-addr-zero"].toString();
        }
        else
        {
            properties["limDhcpCiAddrZero"] = "false";
        }
        var childProperties = [];
        if (intentConfig["eth-cfm"]["entry"])
        {
            if (!Array.isArray(intentConfig["eth-cfm"]["entry"]))
            {
                intentConfig["eth-cfm"]["entry"] = [intentConfig["eth-cfm"]["entry"]];
            }
            for (var index in intentConfig["eth-cfm"]["entry"])
            {
                var intentEthCfmConfig = intentConfig["eth-cfm"]["entry"][index];
                var ethCfmPayload = this.createEthCfmPayLoad(neID, objectFullName, intentEthCfmConfig);
                childProperties.push(ethCfmPayload);
            }
        }
        var policyLevelPayload = util.editPayload(policyFdn, properties, childProperties, fullClassName, objectFullName);
        return policyLevelPayload;
    }
    this.createEthCfmPayLoad = function (neID, objectFullName, intentEthCfmConfig) {
        logger.info("Creating ETH CFM payload for \nneID={},\nObjectFullName={},\nIntent ETHCFM Config={}", neID, objectFullName, JSON.stringify(intentEthCfmConfig));
        var fullClassName = "sitesec.CfmRateLimiting";
        var properties = {};
        properties["id"] = intentEthCfmConfig["id"];
        properties["packetRateLimit"] = util.convertRateGreenField(intentEthCfmConfig["pir"]);
        var levelSet = [];
        if (!Array.isArray(intentEthCfmConfig["level"]))
        {
            intentEthCfmConfig["level"] = [intentEthCfmConfig["level"]];
        }
        for (var index in intentEthCfmConfig["level"])
        {
            var levels = intentEthCfmConfig["level"][index];
            logger.info("levels = {}", JSON.stringify(levels))
            levelSet = levelSet.concat(util.levelRange(levels.start, levels.end));
        }
        logger.info("levelSet = {}", JSON.stringify(levelSet))
        properties["levelSet"] = levelSet;
        var opcodeSet = [];
        if (!Array.isArray(intentEthCfmConfig["opcode"]))
        {
            intentEthCfmConfig["opcode"] = [intentEthCfmConfig["opcode"]];
        }
        for (var index in intentEthCfmConfig["opcode"])
        {
            var opcodes = intentEthCfmConfig["opcode"][index];
            logger.info("opcode = {}", JSON.stringify(opcodes))
            opcodeSet = opcodeSet.concat(util.opcodeRange(opcodes.start, opcodes.end));
        }
        logger.info("opcodeSet = {}", JSON.stringify(opcodeSet))
        properties["opCodeSet"] = opcodeSet;

        return this.createChildObjectPayload(fullClassName, properties);
    }
    this.distributePolicy = function (nodeIp, intentConfig, localEdit) {
        logger.info(" localEdit: " + localEdit);
        var objectFullName = "NE DoS Protection:" + intentConfig["policyId"];
        var xmlReq = utilityService.processTemplate(resourceProvider.getResource(localEdit ? "distribute_local_edit.ftl" : "distribute.xml"), {
            nodeIp: nodeIp,
            objectFullName: objectFullName
        });
        logger.info(xmlReq);
        return nfmpFwk.passThroughRequest('/', xmlReq);
    }
    this.createChildObjectPayload = function (fullClassName, properties) {
        var childObjectPayLoad = {};
        childObjectPayLoad['objectClassName'] = fullClassName;
        childObjectPayLoad['containedClassProperties'] = properties;
        return childObjectPayLoad;
    }
}
