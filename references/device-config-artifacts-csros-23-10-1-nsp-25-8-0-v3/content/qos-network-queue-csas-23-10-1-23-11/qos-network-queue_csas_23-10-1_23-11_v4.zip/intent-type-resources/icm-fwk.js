load({
    script: resourceProvider.getResource('mediator-fwk.js'),
    name: 'mediator-fwk'
});
nfmpFwk = new MediatorFramework("NFMP");

load({
    script: resourceProvider.getResource('nsp-restconf-fwk.js'),
    name: 'nsp-restconf-fwk'
});
nspRestconfFwk = new NspRestconfFwk();

load({
    script: resourceProvider.getResource("model-device-mapping.js"),
    name: "model-device-mapping"
});
modelDeviceMapping = new ModelDeviceMapping();


load({
    script: resourceProvider.getResource("discovery-helper-nfmp.js"),
    name: "discovery-helper-nfmp"
});
load({
    script: resourceProvider.getResource('mdt-fwk.js'),
    name: 'MdtFwk'
});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

//discoveryHelper = new NfmpDiscoveryHelper();

function ICMFwk() {

    var mdtFwk = new MdtFwk();
    var parseTarget = new ParseTarget();

    // get the device configuration
    this.getDeviceConfiguration = function (targetWithTemplate, initialPropertyName) {
        var targetData = this.getTargetData(targetWithTemplate, initialPropertyName);
        return targetData;
    }

    this.getTemplate = function (templateName) {
        return nspRestconfFwk.getByXpath("/nsp-icm:icm/templates/template=" + templateName);
    }

    this.getDefaultTargetData = function (templateName) {
        var templateObj = nspRestconfFwk.getByXpath("/nsp-icm:icm/templates/template=" + templateName);
        //var defaultTargetData = templateObj['nsp-icm:template'][0]['default-target-data'];
        var defaultTargetData = templateObj['nsp-icm:template'][0]['target-data-struct'];
        return defaultTargetData;
    }

    this.getModifiedDeviceConfig = function (templateName, discoveryHelper, deviceConfig, initialPropertyName) {
        var targetData = deviceConfig;
        return targetData;
    }

    this.getTargetData = function (targetWithTemplate, initialPropertyName) {
        var targetAr = targetWithTemplate.split("#");
        var templateName = targetAr[0];
        var neId = parseTarget.getNeIdFromTarget(targetWithTemplate);

        var defaultTargetData = this.getDefaultTargetData(templateName);
        var deviceConfig = this.getConfigurations(targetWithTemplate, initialPropertyName);
        if (typeof deviceConfig === 'string' && deviceConfig.indexOf('Failed to fetch service') > -1)
        {
            logger.error(deviceConfig);
            return deviceConfig;
        }
        return this.extractDeviceConfig(templateName, neId, defaultTargetData, deviceConfig, initialPropertyName);
    }

    this.getConfigurations = function (targetWithTemplate, initialPropertyName) {
        var neId = parseTarget.getNeIdFromTarget(targetWithTemplate);
        var discoveryHelper = this.getDiscoveryHelper(neId);
        return discoveryHelper.getDeviceConfiguration(targetWithTemplate, initialPropertyName);

    }

    this.getDiscoveryHelper = function (neId) {

        var managerName = mdtFwk.getManagerName(neId);
        logger.info('Device: ' + neId + ' is managed by: ' + managerName);

        switch (managerName)
        {
            case 'NFM-P':
                logger.info('Device is managed by NFMP')
                return this.createNfmpDiscoveryHelper()
                break;
            default:
                logger.info('Device is not managed')
                throw new RuntimeException('Device is not Managed')
        }

        return ''
    }

    this.createNfmpDiscoveryHelper = function () {
        return new NfmpDiscoveryHelper();
    }

    this.extractDeviceConfig = function (templateName, neId, defaultTargetData, deviceConfig, initialPropertyName) {
        var discoveryHelper = this.getDiscoveryHelper(neId);
        deviceConfig = this.getModifiedDeviceConfig(templateName, discoveryHelper, deviceConfig, initialPropertyName);
        return discoveryHelper.extractDeviceConfig(defaultTargetData, deviceConfig, initialPropertyName);
    }

}
