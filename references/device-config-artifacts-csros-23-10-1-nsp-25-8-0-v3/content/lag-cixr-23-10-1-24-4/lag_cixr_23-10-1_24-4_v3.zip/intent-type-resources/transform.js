load({ script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil' });
load({ script: resourceProvider.getResource("nfmpSuggest.js"), name: "NfmpSuggest" });
function transformData() {
    const nfmpSuggest = new NfmpSuggest();
    const ipv6AddressUtil = new IPv6AddressUtil();
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
  this.transformPayloadGreenField = function (payload, neId, isAudit) {
       if (!payload.configInfo["lag.Interface"].hasOwnProperty("monitorOperGroupName")) {
        // Add the property with a null value to clear
          payload.configInfo["lag.Interface"].monitorOperGroupName = '';
       }
       payload = ipv6AddressUtil.expandIPv6(payload);
       if (payload.configInfo["lag.Interface"].hasOwnProperty("children-Set")) {
          let childrenSet = payload.configInfo["lag.Interface"]["children-Set"];
          if (childrenSet.hasOwnProperty("lag.PortTermination")) {
             childrenSet["lag.PortTermination"].forEach(portTermination => {
                if (portTermination.memberName) {
                   let portPointer = nfmpSuggest.getPortData(neId, portTermination.memberName, "objectFullName");
                   portTermination.portPointer = portPointer;
                }
             });
          }
          if (payload.configInfo && payload.configInfo["lag.Interface"] && payload.configInfo["lag.Interface"]["children-Set"] && payload.configInfo["lag.Interface"]["children-Set"]["lag.LinkMapProfile"]) {
             payload.configInfo["lag.Interface"]["children-Set"]["lag.LinkMapProfile"].forEach(data => {
                if (data["children-Set"] && data["children-Set"]["lag.LinkMapProfilePort"]) {
                   data["children-Set"]["lag.LinkMapProfilePort"].forEach(linkMapProfilePort => {
                      if (linkMapProfilePort.portId) {
                         let portData = nfmpSuggest.getPortData(neId, linkMapProfilePort.portId, "snmpPortId");
                         linkMapProfilePort.portId = portData;
                      }
                   });
                }
             });
          }
          if (payload.configInfo && payload.configInfo["lag.Interface"] && payload.configInfo["lag.Interface"]["children-Set"] && payload.configInfo["lag.Interface"]["children-Set"]["lag.SharedQueueVlanPolicy"]) {
             payload.configInfo["lag.Interface"]["children-Set"]["lag.SharedQueueVlanPolicy"].forEach(lagSharedQueueVlanPolicy => {
                if (lagSharedQueueVlanPolicy.vlanQosPolicyName) {
                   let vlanQosPolicyName ="default";
                 if (lagSharedQueueVlanPolicy["vlanQosPolicyName"].startsWith(vlanQosPolicyName)) {
                        lagSharedQueueVlanPolicy.vlanQosPolicyPtr = "VlanQosPolicy7250SROS:default";
                    }else{
                        let vlanQosPolicyPtrData = nfmpSuggest.getDataforGf(neId, lagSharedQueueVlanPolicy.vlanQosPolicyName, "ixrqos.VlanQosPolicy","displayedName","objectFullName","origin");
                        lagSharedQueueVlanPolicy.vlanQosPolicyPtr = vlanQosPolicyPtrData;
                   }
                }
             });
          }
       }
       return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
      if(xpath == "lag-SharedQueueVlanPolicy.percentageRateCIR" || xpath == "lag-SharedQueueVlanPolicy.percentageRatePIR")
       {
          if(targetValue && !isNaN(targetValue) && !targetValue.contains("."))
          {
              targetValue = Number(targetValue);
             targetValue = targetValue.toFixed(1);
          }
       }
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, deviceConfig) {
       let neId= deviceConfig["siteId"];
       if (xpath == "lag-LinkMapProfile.lag-LinkMapProfilePort.portId") {
          let portName = nfmpSuggest.getPortDataForBF(neId, targetValue);
          if (portName) {
             targetValue = portName;
          }
       }
       return targetValue;
    }
}