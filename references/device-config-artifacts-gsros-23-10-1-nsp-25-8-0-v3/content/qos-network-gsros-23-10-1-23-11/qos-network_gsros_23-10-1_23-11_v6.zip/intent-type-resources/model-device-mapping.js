function ModelDeviceMapping() {

  this.getMapping = function(type){
    switch(type){
      case "ingress.fc":
          return this.getIngressFcMapping();
      case "ingress.dot1p":
        return this.getIngressDot1pMapping();
      case "ingress.dscp":
        return this.getIngressDscpMapping();
      case "ingress.lsp-exp":
        return this.getIngressLspExpMapping();
      case "egress.dscp":
        return this.getEgressDscpMapping();
      case "egress.prec":
        return this.getEgressPrecMapping();
      case "egress.fc":
        return this.getEgressFcMapping();
      case "egress.ip-criteria":
        return this.getEgressIpCriteriaMapping();
      case "egress.ipv6-criteria":
          return this.getEgressIpv6CriteriaMapping();
      case "ring.dot1p":
        return this.getRingDot1pMapping();
      default:
          logger.info(LOG_PREFIX + "getMapping() mapping not specified - " + type);
    }
  }

  this.getNonChildNetworkQosMapping = function () {
    var mapping = {};
    mapping["network.description"] = "description";
    mapping["network.scope"] = "scope";
    return mapping;
  }

  this.getNonChildIngressMapping = function () {
    var mapping = {};
    mapping["ingress.ler-use-dscp"] = "lerUseDscp";
    mapping["ingress.default-action.fc"] = "defaultFc";
    mapping["ingress.default-action.profile"] = "defaultProfile";
    return mapping;
  }

  this.getEgressFcMapping = function () {
    var mapping = {};
    mapping["egress.fc.fc-name"] = "forwardingClass";
    mapping["egress.fc.dot1p-in-profile"] = "dot1pInProfile";
    mapping["egress.fc.dot1p-out-profile"] = "dot1pOutProfile";
    mapping["egress.fc.dscp-in-profile"] = "dscpInProfile";
    mapping["egress.fc.dscp-out-profile"] = "dscpOutProfile";
    mapping["egress.fc.lsp-exp-in-profile"] = "lspExpInProfile";
    mapping["egress.fc.lsp-exp-out-profile"] = "lspExpOutProfile";
    mapping["egress.fc.de-mark.force"] = "forceDeValue";
    mapping["egress.fc.port-redirect-group.queue"] = "redirectQGrpQid";
    mapping["egress.fc.port-redirect-group.policer"] = "redirectQGrpPolicerId";
    return mapping;
  }

  this.getEgressPrecMapping = function () {
    var mapping = {};
    mapping["egress.prec.prec-value"] = "prec";
    mapping["egress.prec.fc"] = "forwardingClass";
    mapping["egress.prec.profile"] = "profile";
    return mapping;
  }

  this.getEgressDscpMapping = function () {
    var mapping = {};
    mapping["egress.dscp.dscp-name"] = "dscp";
    mapping["egress.dscp.fc"] = "forwardingClass";
    mapping["egress.dscp.profile"] = "profile";
    return mapping;
  }

  this.getIngressLspExpMapping = function () {
    var mapping = {};
    mapping["ingress.lsp-exp.lsp-exp-value"] = "lspExp";
    mapping["ingress.lsp-exp.fc"] = "forwardingClass";
    mapping["ingress.lsp-exp.profile"] = "profile";
    return mapping;
  }

  this.getIngressDscpMapping = function () {
    var mapping = {};
    mapping["ingress.dscp.dscp-name"] = "dscp";
    mapping["ingress.dscp.fc"] = "forwardingClass";
    mapping["ingress.dscp.profile"] = "profile";
    return mapping;
  }

  this.getIngressDot1pMapping = function () {
    var mapping = {};
    mapping["ingress.dot1p.dot1p-value"] = "dot1p";
    mapping["ingress.dot1p.fc"] = "forwardingClass";
    mapping["ingress.dot1p.profile"] = "profile";
    return mapping;
  }

  this.getIngressFcMapping = function () {
    var mapping = {};
    mapping["ingress.fc.fc-name"] = "forwardingClass";
    mapping["ingress.fc.fp-redirect-group.multicast-policer"] = "fpMulticastPolicerId";
    mapping["ingress.fc.fp-redirect-group.policer"] = "fpPolicerId";
    mapping["ingress.fc.fp-redirect-group.broadcast-policer"] = "fpBroadcastPolicerId";
    mapping["ingress.fc.fp-redirect-group.unknown-policer"] = "fpUnknownPolicerId";
    return mapping;
  }

  this.getRingDot1pMapping = function () {
    var mapping = {};
    mapping["ring.dot1p.dot1p-priority"] = "ringdot1p";
    mapping["ring.dot1p.profile"] = "ringprofile";
    mapping["ring.dot1p.queue"] = "queueId";
    return mapping;
  }

  this.getEgressIpCriteriaMapping = function () {
    var mapping = {};
    mapping["egress.ip-criteria.entry.match.dst-ip.ip-prefix-list"] = "dstIpPrefixListPointer";
    mapping["egress.ip-criteria.entry.match.src-ip.ip-prefix-list"] = "srcIpPrefixListPointer";
    return mapping;
  }
  this.getEgressIpv6CriteriaMapping = function () {
    var mapping = {};
    mapping["egress.ipv6-criteria.entry.match.dst-ip.ipv6-prefix-list"] = "dstIpPrefixListPointer";
    mapping["egress.ipv6-criteria.entry.match.src-ip.ipv6-prefix-list"] = "srcIpPrefixListPointer";
    return mapping;
  }
}
