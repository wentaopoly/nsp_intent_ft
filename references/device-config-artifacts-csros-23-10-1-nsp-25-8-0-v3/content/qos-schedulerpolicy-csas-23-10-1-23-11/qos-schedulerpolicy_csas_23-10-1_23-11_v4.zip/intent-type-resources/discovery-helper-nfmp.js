var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});


function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();
    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let schedulerPolicyName = target.split("#")[2];
        let searchPayLoad = this.constructSearchString(neId, schedulerPolicyName);
        let searchResponse = nfmpFwk.post("/v3/search", searchPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find Scheduler Policy  : " + schedulerPolicyName + " on NE " + neId);
        }
        searchResponse = JSON.parse(searchResponse.response);
        logger.info("searchResponse = {}", JSON.stringify(searchResponse));
        return searchResponse;
    }
    this.constructSearchString = function (neId, schedulerPolicyName) {
        let objectFullName = "network:" + neId + ":sasPortSchedulerPolicy:" + schedulerPolicyName;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        let fullClassName = "sasqos.PortScheduler";
        let jsonPayLoad = {
            "fullClassName": fullClassName,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        return jsonPayLoad;
    }
    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        deviceConfig = deviceConfig["sasqos.PortScheduler"];
        logger.info("***********************************deviceConfig***********************************************");
        logger.info(JSON.stringify(deviceConfig));
        logger.info("************************************parsedDefaultTargetData***********************************");
        logger.info(JSON.stringify(parsedDefaultTargetData));
        logger.info("**************************************************END******************************************");
        if (null !== deviceConfig)
        {
            this.extractSchPolicyProperties(parsedDefaultTargetData, deviceConfig);
            let queueWeights = this.extractQueueWeightsProperties(deviceConfig);
            parsedDefaultTargetData['scheduler-policy']['queue-weights'] = queueWeights;
        }
        this.clearEmpties(parsedDefaultTargetData);
        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData));
        return parsedDefaultTargetData;
    }
    this.extractSchPolicyProperties = function (defaultTargetData, deviceConfig) {
        let keys = Object.keys(defaultTargetData);
        //logger.info("keys = " + keys)
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj))
            if (targetObj !== null && typeof targetObj === 'object')
            {
                this.traverseAndUpdateConfig(targetKey, targetObj, deviceConfig);
            }
        }
        return defaultTargetData;
    }
    this.extractQueueWeightsProperties = function (deviceConfig) {
        let queueWeights = [];
        for (let i = 1; i <= 8; i++)
        {
            let queueWeightId = "queue" + i + "Weight";
            let queueWeight = deviceConfig[queueWeightId];
            if (queueWeight)
            {
                let queueWeightTarget = {
                    "queue-id": i,
                    "weight": queueWeight
                }
                queueWeights.push(queueWeightTarget);
            }
        }
        return queueWeights;
    }
    this.traverseAndUpdateConfig = function (objKey, obj, deviceConfig) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            let mappings;

            //logger.info("**********mappedKey = " + mappedKey);
            mappings = modelDeviceMapping.getSchPolicyMapping();
            if (value != null && typeof value === 'object')
            {
                continue;
            }
            else
            {
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, deviceConfig);
            }

        }
        return obj;
    }
    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, deviceConfigData) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = deviceConfigData[nfmpKey];
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[targetKey] = (deviceValue) ? this.transformDeviceValue(mappedKey, deviceValue) : deviceValue;
    }
    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue !== null)
        {
            switch (mappedKey)
            {
                case "scheduler-policy.mode":
                    deviceValue = util.convertModeBrownField(deviceValue);
                    break;
            }
            return deviceValue;
        }
    }
    this.clearEmpties = function (o) {
        for (let k in o)
        {
            if (!o[k] || typeof o[k] !== "object")
            {
                continue
            }

            this.clearEmpties(o[k]);
            if (Object.keys(o[k]).length === 0)
            {
                delete o[k];
            }
        }
    }
}
