function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        if(targetKey == "groupListPointer") {
            targetValue = "tlsClientGroupList:tlscgl-" + targetValue;
        }
        else if(targetKey == "cipherListPointer") {
            targetValue = "tlsClientCipherList:tlsccl-" + targetValue;
        }
        else if(targetKey == "trustAnchorProfilePointer") {
            targetValue = "tlsTrustAnchorProfile:tlstap-" + targetValue;
        }
        else if(targetKey == "signatureListPointer") {
            targetValue = "tlsClientSignatureList:tlscsl-" + targetValue;
        }
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
        if(targetKey == "groupListPointer") {
            targetValue = targetValue.split("tlsClientGroupList:tlscgl-")[1];
        }
        else if(targetKey == "cipherListPointer") {
            targetValue = targetValue.split("tlsClientCipherList:tlsccl-")[1];
        }
        else if(targetKey == "trustAnchorProfilePointer") {
            targetValue = targetValue.split("tlsTrustAnchorProfile:tlstap-")[1];
        }
        else if(targetKey == "signatureListPointer") {
            targetValue = targetValue.split("tlsClientSignatureList:tlscsl-")[1];
        }
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
}