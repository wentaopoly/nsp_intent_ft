var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource("model-device-mapping.js"), name: "model-device-mapping"});


function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();
    let modelDeviceMapping = new ModelDeviceMapping();

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let networkQueuePolicyName = target.split("#")[2];
        let searchPayLoad = this.constructSearchString(neId, networkQueuePolicyName);
        let searchResponse = nfmpFwk.post("/v3/search", searchPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find Network Queue Policy  : " + networkQueuePolicyName + " on NE " + neId);
        }
        searchResponse = JSON.parse(searchResponse.response);
        logger.info("searchResponse = {}", JSON.stringify(searchResponse));
        return searchResponse;
    }
    this.constructSearchString = function (neId, networkQueuePolicyName) {
        let objectFullName = "network:" + neId + ":sasNetworkQueue:" + networkQueuePolicyName;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        let fullClassName = "sasqos.NQueue";
        let jsonPayLoad = {
            "fullClassName": fullClassName,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        return jsonPayLoad;
    }
    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        let queues = {};
        let fcs = {};
        let nQueueConfig = deviceConfig["sasqos.NQueue"];
        if (deviceConfig["sasqos.NQueue"]["children-Set"])
        {
            if (deviceConfig["sasqos.NQueue"]["children-Set"]["sasqos.NQueueEntry"])
            {
                queues = deviceConfig["sasqos.NQueue"]["children-Set"]["sasqos.NQueueEntry"];
                if (!Array.isArray(queues))
                {
                    queues = [queues];
                }
            }
            if (deviceConfig["sasqos.NQueue"]["children-Set"]["sasqos.NQueueForwardingClass"])
            {
                fcs = deviceConfig["sasqos.NQueue"]["children-Set"]["sasqos.NQueueForwardingClass"]
                if (!Array.isArray(fcs))
                {
                    fcs = [fcs];
                }
            }
        }
        deviceConfig = {
            "nQueueConfig": nQueueConfig,
            "queues": queues,
            "fcs": fcs
        }

        logger.info("***********************************deviceConfig***********************************************");
        logger.info(JSON.stringify(deviceConfig));
        logger.info("************************************parsedDefaultTargetData***********************************");
        logger.info(JSON.stringify(parsedDefaultTargetData));
        logger.info("**************************************************END******************************************");
        if (null !== deviceConfig)
        {
            extractNQueuePolicyProperties(parsedDefaultTargetData, deviceConfig["nQueueConfig"]);
            let queue = extractQueueProperties(parsedDefaultTargetData['network-queue']['queue'], deviceConfig["queues"]);
            parsedDefaultTargetData['network-queue']['queue'] = queue;
            if(parsedDefaultTargetData['network-queue']['fc'])
            {
                let fc = extractFcProperties(parsedDefaultTargetData['network-queue']['fc'], deviceConfig["fcs"]);
                parsedDefaultTargetData['network-queue']['fc'] = fc;
            }
        }
        clearEmpties(parsedDefaultTargetData);
        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData));
        return parsedDefaultTargetData;
    }

    function extractNQueuePolicyProperties(defaultTargetData, deviceConfig) {
        let keys = Object.keys(defaultTargetData);
        let mappings = modelDeviceMapping.getNQueuePolicyMapping();
        //logger.info("keys = " + keys)
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj))
            if (targetObj !== null && typeof targetObj === 'object')
            {
                traverseAndUpdateConfig(targetKey, targetObj, deviceConfig, mappings);
            }
        }
        return defaultTargetData;
    }

    function extractQueueProperties(queueTargetData, deviceConfig) {
        let queueArray = [];
        let queueData = queueTargetData[0];
        let mappings = modelDeviceMapping.getQueueMapping();
        for (let i = 0; i < deviceConfig.length; i++)
        {
            let deviceQueueConfig = deviceConfig[i];
            let keys = Object.keys(queueData);
            logger.info("keys = " + keys);
            for (let j = 0; j < keys.length; j++)
            {
                let targetKey = keys[j];
                let targetObj = queueData[targetKey];
                let mappedKey = "queue." + targetKey;
                //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj) + "\nmappedKey = " + mappedKey);
                if (targetObj != null && typeof targetObj === 'object')
                {
                    traverseAndUpdateConfig(targetKey, targetObj, deviceQueueConfig, mappings);
                }
                else
                {
                    getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, queueData, deviceQueueConfig);
                }
            }
            queueArray.push(JSON.parse(JSON.stringify(queueData)));
        }
        return queueArray;
    }

    function extractFcProperties(fcTargetData, deviceConfig) {
        let fcArray = [];
        let fcData = fcTargetData[0];
        let mappings = modelDeviceMapping.getFcMapping();
        for (let i = 0; i < deviceConfig.length; i++)
        {
            let deviceFcConfig = deviceConfig[i];
            let keys = Object.keys(fcData);
            logger.info("keys = " + keys);
            for (let j = 0; j < keys.length; j++)
            {
                let targetKey = keys[j];
                let targetObj = fcData[targetKey];
                let mappedKey = "fc." + targetKey;
                //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj) + "\nmappedKey = " + mappedKey);
                if (targetObj != null && typeof targetObj === 'object')
                {
                    traverseAndUpdateConfig(targetKey, targetObj, deviceFcConfig, mappings);
                }
                else
                {
                    getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, fcData, deviceFcConfig);
                }
            }
            fcArray.push(JSON.parse(JSON.stringify(fcData)));
        }
        return fcArray;
    }

    function traverseAndUpdateConfig(objKey, obj, deviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            let deviceConfigData;
            //let mappings;

            //logger.info("**********mappedKey = " + mappedKey);
            //mappings = modelDeviceMapping.getNQueuePolicyMapping();
            if (value != null && typeof value === 'object')
            {
                continue;
            }
            else
            {
                getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, deviceConfig);
            }

        }
        return obj;
    }

    function getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, targetObj, deviceConfigData) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = deviceConfigData[nfmpKey];
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[targetKey] = (deviceValue) ? transformDeviceValue(mappedKey, deviceValue) : deviceValue;
    }

    function transformDeviceValue(mappedKey, deviceValue) {
        if (deviceValue !== null)
        {
            switch (mappedKey)
            {
                case "queue.queue-management-policy":
                    deviceValue = util.convertQueueMgmtPolicyBrownField(deviceValue);
                    break;
                case "queue.slope-policy":
                    deviceValue = util.convertSlopePolicyBrownField(deviceValue);
                    break;
            }
            return deviceValue;
        }
    }

    function clearEmpties(o) {
        for (let k in o)
        {
            if (!o[k] || typeof o[k] !== "object")
            {
                continue
            }

            clearEmpties(o[k]);
            if (Object.keys(o[k]).length === 0)
            {
                delete o[k];
            }
        }
    }
}
