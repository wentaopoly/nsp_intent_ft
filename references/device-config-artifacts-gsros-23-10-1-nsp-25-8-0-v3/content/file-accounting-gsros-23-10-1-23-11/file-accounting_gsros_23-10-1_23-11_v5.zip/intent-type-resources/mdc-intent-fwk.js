var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk'});
load({script: resourceProvider.getResource('traverse-fwk.js'), name: 'TraverseFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});

function MdcIntentFwk() {

    var intentDeviationObj = new IntentDeviceDeviation();

    this.restResponseHandler = function (exception, httpStatus, response) {
        logger.info("[IntentMgr] REST response : " + response);
        logger.info("[IntentMgr] REST httpStatus : " + httpStatus);
        if (exception) {
            throw new RuntimeException("Couldn't connect to device proxy for ; Response: " + response);
        }
        ;
        if (httpStatus !== 200 && httpStatus !== 201) {
            throw new RuntimeException("Failed to access device  using MDC; Response: " + response);
        }
        ;
        restResponse = JSON.parse(response);
    };

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {

        var traverseFwk = new TraverseFwk();
        var parseTarget = new ParseTarget();
        var target = parseTarget.getNeIdFromTarget(input.getTarget());

        var neFamily = intentDeviationObj.getNeFamilyRelease(target);
        var neVersion = intentDeviationObj.getNeVersion(neFamily);
        var neType = intentDeviationObj.getNeType(neFamily);

        // saved topology
        var savedTopology = input.getCurrentTopology();

        if (savedTopology == null) {
            savedTopology = topologyFactory.createServiceTopology();
        }

        if (input.getNetworkState().name() == "delete") {
            logger.info(JSON.stringify(savedTopology));
            traverseFwk.resetTheVariables();
            result = traverseFwk.deleteAllFromTopology(savedTopology, target, result);
            return result;

        }

        var intentConfig;

        if (target !== "0.0.0.0") {
            var intentConfig;
            var shouldPush = true;
            intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
            intentConfig['accounting-policy']["policy-id"] = parseTarget.getUniqueIdentifier(input.getTarget());

            //accounting-policy-name & logMemory is not needed for MD Nodes
            delete intentConfig['accounting-policy']['accounting-policy-name'];
            delete intentConfig['accounting-policy']['logMemory'];

            //file-id till 21.x, file-policy-name from 22.x
            if (neVersion.startsWith("19.") || neVersion.startsWith("20.") || neVersion.startsWith("21.")) {
                delete intentConfig['file']['file-policy-name'];
                if (intentConfig['file']['file-id']) {
                    var destination = {};
                    destination["file"] = intentConfig['file']['file-id'];
                    intentConfig['accounting-policy']['destination'] = destination;
                }
            } else {
                delete intentConfig['file']['file-id'];
                if (intentConfig['file']['file-policy-name']) {
                    var destination = {};
                    destination["file"] = intentConfig['file']['file-policy-name'];
                    intentConfig['accounting-policy']['destination'] = destination;
                }
            }

            if (intentConfig) {
                intentConfig = intentDeviationObj.removeIntentConfig(intentConfig, target);
                savedTopology = traverseFwk.traverse(target, intentConfig, savedTopology, null, parentXpath, initialPropertyName);

                //sorting delete array
                var deleteRequests = traverseFwk.getDeleteRequests();
                var deleteReqObjects = [];
                for (var delCount = 0; delCount < deleteRequests.length; delCount++) {
                    var delReqObj = deleteRequests[delCount];
                    var targetUrl = delReqObj['target'].split('/');
                    var cmpUrl = '';
                    for (var tCount = 0; tCount < targetUrl.length; tCount++) {
                        cmpUrl = cmpUrl + "/" + targetUrl[tCount].split('=')[0];
                    }
                    if ("/nokia-conf:/configure/log/accounting-policy/custom-record/ref-queue/id" === cmpUrl ||
                    "/nokia-conf:/configure/log/accounting-policy/custom-record/ref-policer/id" === cmpUrl) {
                        shouldPush = false;
                    }
                    if (shouldPush) {
                        deleteReqObjects.push(delReqObj);
                    }

                }
                deleteRequests = deleteReqObjects;
                deleteRequests.sort(function (a, b) {
                    return b["target"].length - a["target"].length;
                });

                // concating createrequests and deleterequests
                var createRequests = traverseFwk.getCreateRequests();
                var requests;
                if (deleteRequests && createRequests) {
                    requests = createRequests.concat(deleteRequests);
                }
                if (requests) {
                    result = traverseFwk.syncRequest(target, requests, result, savedTopology);
                }

            } else {

                result = traverseFwk.deleteAllFromTopology(savedTopology, target, result);
            }

        }
        traverseFwk.resetTheVariables();
        return result;
    }

    this.audit = function (target, config, svcTopo, adminState, report, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        var currentConfig;
        var traverseFwk = new TraverseFwk();
        var parseTarget = new ParseTarget();
        currentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        currentConfig['accounting-policy']["policy-id"] = parseTarget.getUniqueIdentifier(target);
        var target = parseTarget.getNeIdFromTarget(target);

        var neFamily = intentDeviationObj.getNeFamilyRelease(target);
        var neVersion = intentDeviationObj.getNeVersion(neFamily);
        var neType = intentDeviationObj.getNeType(neFamily);

        //accounting-policy-name is not needed for MD Nodes
        delete currentConfig['accounting-policy']['accounting-policy-name'];

        //file-id till 21.x, file-policy-name from 22.x
        if (neVersion.startsWith("19.") || neVersion.startsWith("20.") || neVersion.startsWith("21.")) {
            delete currentConfig['file']['file-policy-name'];
        } else {
            delete currentConfig['file']['file-id'];
        }


        if (target !== "0.0.0.0") {
            currentConfig = intentDeviationObj.removeIntentConfig(currentConfig, target);
            svcTopo = traverseFwk.traverse(target, currentConfig, svcTopo, report, parentXpath, initialPropertyName);
            // reseting the variables
            traverseFwk.resetTheVariables();
        }

        return report;

    }

    this.getNodes = function (context) {
        var returnVal = []
        var url = "/restconf/meta/api/v1/nes"
        try {
            var managerList = []
            var managers = mds.getAllManagersOfType("REST");
            managers.forEach(function (manager) {
                if (mds.getManagerByName(manager).getConnectivityState().toString() === 'CONNECTED') {
                    managerList.push(manager)
                }
            })

            var devices = mds.getAllManagedDevicesFrom(managerList);

            devices.forEach(function (device) {
                returnVal.push(device.getName());
            });

            return returnVal;
        } catch (e) {
            logger.info("Exception *******************  : " + e);
            return {
                "Device Not Found": "Device Not Found"
            }
        }
    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }
}
