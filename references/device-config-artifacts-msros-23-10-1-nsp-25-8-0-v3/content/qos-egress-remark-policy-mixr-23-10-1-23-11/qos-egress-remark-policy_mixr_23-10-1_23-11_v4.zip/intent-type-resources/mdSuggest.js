function MdSuggest() {
    
   this.getDisplayedName = function (neId) {
      logger.info("getDisplayedName ==> neId = {}", neId);
      const url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/egress-remark-policy?fields=egress-remark-policy-name";
      return this.getData(neId, url, "egress-remark-policy-name", "nokia-conf:egress-remark-policy");
   }

   this.getDot1pMapName = function (neId) {
      logger.info("getDot1pMapName ==> neId = {}", neId);
      const url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/fc-dot1p-map?fields=fc-dot1p-map-name";
      return this.getData(neId, url, "fc-dot1p-map-name", "nokia-conf:fc-dot1p-map");
   }
   this.getFCDscpMapName = function (neId) {
      logger.info("getFCDscpMapName ==> neId = {}", neId);
      const url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/fc-dscp-map?fields=fc-dscp-map-name";
      return this.getData(neId, url, "fc-dscp-map-name", "nokia-conf:fc-dscp-map");
   }
   this.getFCLspExpMapName = function (neId) {
      logger.info("getFCLspExpMapName ==> neId = {}", neId);
      const url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/fc-lsp-exp-map?fields=fc-lsp-exp-map-name";
      return this.getData(neId, url, "fc-lsp-exp-map-name", "nokia-conf:fc-lsp-exp-map");
   }

   this.getData = function (neId, url, type, configName) {
      var mdcFwk = new MdcFwk();
      var resultFetch = mdcFwk.fetch(neId, url);
      var finalResponse = resultFetch["msg"][configName];
      const ret = Array.isArray(finalResponse) ? finalResponse.map(Data => Data[type]).filter(value => value != null) : [];
      logger.info("getData() of [" + configName + "] values = \n" + JSON.stringify(ret));
      return ret;
   }
}
