function utilities() {
    this.setSuccessResult = function (result, savedTopology) {
        result.setSuccess(true);
        if (savedTopology !== undefined)
        {
            result.setTopology(savedTopology);
        }
        return result;
    }

    /**
     * Generates audit report
     * @param target
     * @param result
     * @param auditReport
     * @returns {*}
     */
    this.reportMisaligned = function (target, result, auditReport) {
        let report = JSON.parse(result.response);
        if (!report.aligned)
        {
            for (let i = 0; i < report.misalignedAttributes.length; i++)
            {
                let attributeData = report.misalignedAttributes[i];
                if (attributeData.expected == "present")
                {
                    //misaligned object
                    let objectDn = attributeData.name;
                    let misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else if (attributeData.expected == "not present")
                {
                    //undesired object
                    let objectDn = attributeData.name;
                    let misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    if(!(attributeData.expected == "N/A" && attributeData.actual == ""))
                    {
                        let misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                        if(attributeData.name.endsWith("|enableServers"))
                        {
                            if(JSON.stringify(attributeData.expected.sort()) === JSON.stringify(attributeData.actual.sort()))
                            {
                                continue;
                            }
                        }
                        auditReport.addMisAlignedAttribute(misalignedAttribute);
                    }
                }

            }
        }
        return auditReport
    }

    /**
     * Payload to mdt-mediator
     * @param fdn
     * @param fullClassName
     * @param objectFullName
     * @param intentConfig
     * @returns {{}}
     */
    this.editPayload = function (fdn, fullClassName, objectFullName, intentConfig) {
        let payload = {};
        let configInfo = {};
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName;
        payload["clearOnDeployFailure"] = true;
        configInfo[fullClassName] = intentConfig;
        payload["configInfo"] = configInfo;
        return payload;
    }
    /**
     * Distributes global policy to local
     * @param neId
     * @param objectFullName
     * @param isLocalEdit
     * @returns {{}}
     */
    this.distribute = function (neId, objectFullName, isLocalEdit) {
        let payload = {};
        let policyDefination = "policy.PolicyDefinition.distributeV2";
        if (isLocalEdit)
        {
            policyDefination = "policy.PolicyDefinition.setDistributionModeToLocalEditOnly";
        }
        payload[policyDefination] = {};
        payload[policyDefination]["clearOnDeployFailure"] = true;
        payload[policyDefination]["deployer"] = "immediate";
        payload[policyDefination]["instanceFullName"] = objectFullName;
        payload[policyDefination]["siteIds"] = {};
        payload[policyDefination]["siteIds"]["string"] = neId;
        return payload;
    }

    /**
     * Check and returns boolean if NFMP Object exists
     * @param className
     * @param objectFullName
     * @returns {boolean}
     */
    this.isObjectExists = function (className, objectFullName) {
        let nfmpFwk = new NfmpFwk();
        let ret = false;
        let searchObjectJson = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);

        logger.info("isObjectExists data = {}", JSON.stringify(resultFetch));

        let finalResponse = JSON.parse(resultFetch.response);
        logger.info("Final response of search = {}", JSON.stringify(finalResponse));
        if (Object.keys(finalResponse).length !== 0 && finalResponse.constructor === Object)
        {
            ret = true;
        }
        logger.info("isObjectExists = {} ", ret);
        return ret;
    }

    /**
     * Delays the execution
     * Sometimes the object creation takes time, we can use delay for child-level operation.
     * @param milliseconds
     */
    this.delay = function (milliseconds) {
        let date = new Date();
        date.setMilliseconds(date.getMilliseconds() + milliseconds);
        while (new Date() < date)
        {
        }
    }

    /**
     * Returns Port fdn
     * @param target
     * @param portId
     * @returns {string}
     */
    this.getBaseFdnForPort = function (target, portId) {
        if (portId.startsWith("esat"))
        {
            return this.getBaseFdnForSatellitePort(target, portId);
        }
        let portIds = portId.split("/");
        let cardSlot;
        let xiomSlot;
        let mdaSlot;
        let connector;
        let portNumber

        portIds.forEach(function (item, index) {
            // logger.info("*********************item, index = " + item + "-----" + index);
            switch (index)
            {
                case 0:
                    cardSlot = item;
                    break;
                case 1:
                    //xiom
                    if (isNaN(item))
                    {
                        xiomSlot = item;
                    }
                    else
                    {
                        mdaSlot = item;
                    }
                    break;
                case 2:
                    //connector
                    if (isNaN(item))
                    {
                        connector = item;
                    }
                    else if (mdaSlot)
                    {
                        portNumber = item;
                    }
                    else
                    {
                        mdaSlot = item;
                    }
                    break;
                case 3:
                    //connector
                    if (isNaN(item))
                    {
                        connector = item;
                    }
                    else
                    {
                        portNumber = item;
                    }
                    break;
                case 4:
                    portNumber = item;
                    break;


            }
        });

        // logger.info("************ cardSlot =" + cardSlot + ",xiomSlot=" + xiomSlot + ",mdaSlot=" + mdaSlot + ",connector=" + connector + ",portNumber=" + portNumber);
        //"network:92.168.96.22:shelf-1:cardSlot-1:card:xioSlot-1:xiomCard:daughterCardSlot-1:daughterCard:conn-1:port-1"

        let portDn = "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card";
        if (xiomSlot)
        {
            portDn += ":xioSlot-" + xiomSlot.substring(1) + ":xiomCard";
        }
        if (mdaSlot)
        {
            portDn += ":daughterCardSlot-" + mdaSlot + ":daughterCard";
        }
        if (connector)
        {
            portDn += ":conn-" + connector.substring(1);
        }
        if (portNumber)
        {
            portDn += ":port-" + portNumber;
        }
        if (target && String(target).indexOf(':') !== -1) {
          portDn = this.modifyNeIdForIpV6(portDn, target);
        }
        logger.info("*********************portDn = " + portDn);
        return portDn;
        //return "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card:daughterCardSlot-" + mdaSlot + ":daughterCard:port-" + portNumber;
    }

    /**
     * returns satellite port fdn
     * @param target
     * @param portId
     * @returns {string}
     */
    this.getBaseFdnForSatellitePort = function (target, portId) {
        let portIds = (portId.split("-")[1]).split("/");
        let shelf = "shelf-1-5-";
        shelf += portIds[0];
        let satId = portIds[0];
        let cardSlot = "cardSlot-1:card";
        let mdaSlot = "daughterCardSlot-1:daughterCard";
        let portNumber = portIds[2];
        let snmpPortId = this.getSatellitePortSnmpId(satId, 1, portNumber, false, 5)
        //logger.info("******satellite port = shelf = "+shelf+", portnumber = "+portNumber +"\n portid = "+ portId+"\n portids = "+ portIds);
        let portDn = "network:" + target + ":" + shelf + ":" + cardSlot + ":" + mdaSlot + ":port-" + snmpPortId;
        if (target && String(target).indexOf(':') !== -1) {
            portDn = this.modifyNeIdForIpV6(portDn, target);
        }
        logger.info("SatPortDN = " + portDn);
        return portDn;
    }

    /**
     * returns satellite port snmp-id or if-index
     * @param aInSatId
     * @param aInSlotId
     * @param aInPortId
     * @param aInUplink
     * @param aInPhyShelfClass
     * @returns {number}
     */
    this.getSatellitePortSnmpId = function (aInSatId, aInSlotId, aInPortId, aInUplink, aInPhyShelfClass) {
        let aInSnmpIndex = aInPortId;
        let lUplinkBit = 0;
        if (aInUplink)
        {
            lUplinkBit = 1;
        }
        let lSatId = aInSatId << 16;
        let lSlotId = aInSlotId << 11;
        let lUplink = lUplinkBit << 10;
        let lSat = 136 << 23;
        aInSnmpIndex = lSat | lSatId | lSlotId | lUplink | aInSnmpIndex;
        return aInSnmpIndex;
    }

    this.getNeFamilyRelease = function (target) {
        var neId = target;
        var returnNeType = ''
        try
        {
            var managerList = []
            var managers = mds.getAllManagersOfType("REST");
            managers.forEach(function (manager) {
                if (mds.getManagerByName(manager).getConnectivityState().toString() === 'CONNECTED')
                {
                    managerList.push(manager)
                }
            });
            var devices = mds.getAllManagedDevicesFrom(managerList);
            devices.forEach(function (device) {
                var deviceName = device.getName();
                //logger.info(device);
                var result = deviceName.localeCompare(neId);
                if (result == 0)
                {
                    returnNeType = device.getFamilyTypeRelease();
                    return returnNeType;
                }
            });
            return returnNeType;
        } catch (e)
        {
            logger.error(null, "Exception *******************  : " + e);
            return {
                "Device Not Found": "Device Not Found"
            }
        }
    }
    this.getNeType = function (neFamily) {
        var neFamilyArr = neFamily.split(":");
        return neFamilyArr[0];
    }
    this.getNeVersion = function (neFamily) {
        var neFamilyArr = neFamily.split(":");
        return neFamilyArr[1];
    }
    this.getChassisType = function (neFamily) {
        var neFamilyArr = neFamily.split(":");
        return neFamilyArr[2];
    }
    this.removeNullAndEmptyKeys = function (obj) {
        for (let key in obj)
        {
            if (obj[key] === null || (typeof obj[key] === 'object' && Object.keys(obj[key]).length === 0))
            {
                delete obj[key];
            }
            else if (typeof obj[key] === 'object')
            {
                this.removeNullAndEmptyKeys(obj[key]); // Recursively process nested objects
            }
        }
    }
    this.removeKeysId = function (obj) {
        for (let key in obj)
        {
            if (key === "key-id")
            {
                delete obj[key];
            }
            else if (typeof obj[key] === 'object')
            {
                this.removeKeysId(obj[key]); // Recursively process nested objects
            }
        }
    }
    this.removeUnsupportedAttributes = function (intentConfig, neId) {
        logger.info("-------------------- util-fwk.js -> removeUnsupportedAttributes() --------------------");
        let neFamily = this.getNeFamilyRelease(neId);
        let neType = this.getNeType(neFamily);
        let neVersion = this.getNeVersion(neFamily);
        let neChassisType = this.getChassisType(neFamily);
        let unsupportedAttribute = [];
        let unsupportedAttributeJsonFile = resourceProvider.getResource("unsupported-attributes.json");
        unsupportedAttributeJsonFile = JSON.parse(unsupportedAttributeJsonFile);
        for (let key in unsupportedAttributeJsonFile)
        {
            if (key == neType)
            {
                let nodeObj = unsupportedAttributeJsonFile[key];
                for (let nodeKey of nodeObj)
                {
                    let chassisType = nodeKey["chassis-types"]
                    if (chassisType.length === 0 || chassisType.indexOf(neChassisType) !== -1)
                    {
                        let neVersions = nodeKey["versions"]
                        if (neVersions.length === 0 || neVersions.indexOf(neVersion) !== -1)
                        {
                            let unsupportedAttributeList = nodeKey["unsupported-attributes"]
                            unsupportedAttribute = unsupportedAttribute.concat(unsupportedAttributeList)
                        }
                    }
                }
            }
        }
        logger.info("unsupportedAttribute = {}", JSON.stringify(unsupportedAttribute));
        if (unsupportedAttribute.length !== 0)
        {
            removeAttributes(intentConfig, unsupportedAttribute)
        }
    }
    removeAttributes = function (intentConfig, unsupportedAttribute, parent) {
        //logger.info("-------------------- util-fwk.js -> removeAttributes() --------------------");
        for (var key in intentConfig)
        {
            let attribute = key;
            if (parent)
            {
                attribute = parent + "." + key;
            }
            if (unsupportedAttribute.indexOf(attribute) !== -1)
            {
                logger.info("removing  = {}", key);
                delete intentConfig[key];
            }
            else if (typeof intentConfig[key] === 'object')
            {
                if (Array.isArray(intentConfig[key]))
                {
                    intentConfig[key].forEach(function (item) {
                        removeAttributes(item, unsupportedAttribute, key)
                    });
                }
                else
                {
                    removeAttributes(intentConfig[key], unsupportedAttribute, key);
                }
            }
        }
    }

    this.modifyNeIdForIpV6 = function (objectFullName, neId) {
        logger.info("modifying NeId For IpV6");
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }
}
