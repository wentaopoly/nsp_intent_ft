function NfmpSuggest(){

  this.getPolicyName = function (neId) {
        var className = "rp.Damping";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "dampingName"
                ]
            }
        };
        logger.info("final search object = {}", searchObject);
        return this.getSuggestData(searchObject, className, "dampingName");
  }

  this.getSuggestData = function (searchObjectJson, searchClass, propertyName)
         {

             var nfmpFwk = new NfmpFwk();
             var ret = [];
             var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
             logger.info("RESULT FETCH IS : " + JSON.stringify(resultFetch));
             var finalResponse = JSON.parse(resultFetch.response);
             logger.info("FINAL RESPONSE IS : " + JSON.stringify(finalResponse));
             finalResponse = finalResponse[searchClass];
             logger.info("FINAL RESPONSE IS : " + JSON.stringify(finalResponse));

             if (Object.keys(finalResponse).length !== 0)
             {
                 if (!Array.isArray(finalResponse))
                 {
                     finalResponse = [finalResponse];
                 }
                 finalResponse.forEach(function (value, index, array) {
                     ret.push(value[propertyName]);
                 })
             }
             logger.info("result = {}", JSON.stringify(ret));
             return ret;
         }

}
