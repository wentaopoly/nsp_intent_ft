<#ftl output_format="JSON">
<#setting number_format="computer">

{
  "name": "${extraParams.name}"
  <#if extraParams.name != "hopless" && extraParams["explicit-route-objects-always"]["route-object-include-exclude"].length != 0 >
  ,"path-list": [
    <#list extraParams["explicit-route-objects-always"]["route-object-include-exclude"]?values as value>
    {
       
      "name": "${value.numbered\-node\-hop.node\-id}",
      "${value.numbered\-node\-hop.hop\-type}": [null]
    }<#if value?has_next>,</#if>
    </#list>
  ]
  </#if>
}
