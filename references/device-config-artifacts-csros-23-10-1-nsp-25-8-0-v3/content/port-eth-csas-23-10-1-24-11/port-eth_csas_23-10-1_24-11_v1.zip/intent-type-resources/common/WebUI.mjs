/******************************************************************************
 * Backend functions for WebUI forms to create/update intents
 *
 * (c) 2025 by Nokia
 ******************************************************************************/

import { NSP } from "common/NSP.mjs";

const HashMap = Java.type("java.util.HashMap");
const Arrays = Java.type("java.util.Arrays");

/**
 * This class implements common callouts for WebUI SchemaForm components
 * and corresponding helpers. To be used for pickers (leafref) and suggest
 * (auto-complete) including intent target components.
 */

export class WebUI
{
  constructor() {
  }

  /**
   * Extracts the target component from context provided by WebUI callout
   * Implementation supposed to work with _target (new) and target (deprecated).
   * In case of nest views, method will extrat target from __root container.
   *
   * @param {ValueProviderContext} context
   * @returns object or string
   *
   */

  getTarget(context) {
    logger.info("WebUI::getTarget({})", context.getInputValues().toJSONString());

    if (context.getInputValues().arguments.containsKey("__root")) {
      const root = context.getInputValues().arguments.__root;
      const target = Object.fromEntries(root.keySet().toArray().filter(entry => entry.startsWith('target_')).map(entry => [entry.slice(7), root[entry]]));
      if (Object.keys(target).length > 0) return target;
    }

    if (context.getInputValues().arguments.containsKey("__parent")) {
      let root = context.getInputValues().arguments;
      while (root.containsKey('__parent')) { root = root.__parent; }
      const target = Object.fromEntries(root.keySet().toArray().filter(entry => entry.startsWith('target_')).map(entry => [entry.slice(7), root[entry]]));
      if (Object.keys(target).length > 0) return target;
    }

    let target;
    if (context.getInputValues().containsKey("_target"))
      target = context.getInputValues()._target;
    else
      target = context.getInputValues().target;

    if (typeof target === "object")
      return Object.fromEntries(target.keySet().toArray().map(key => [key, target[key]]));

    return target;
  }

  /**
   * Helper function to extract ne-id from target or intent-model instance
   *
   * Search order:
   *  - Check if target contains `objectidentifier` (common for ICM intents)
   *  - Check if target contains `ne-id` (or known aliases)
   *  - Check for top-level root attributes name `ne-id` (or known aliases)
   *  - Hierarchical bottom>root lookup for `ne-id` (or aliases), starting attribute to be entered
   *
   * @param {ValueProviderContext} context
   * @returns neId (or undefined)
   */

  getNeId(context) {
    logger.info("WebUI::getNeId({})", context.getInputValues().toJSONString());
    const target = this.getTarget(context);
    const args = context.getInputValues().arguments;

    const aliases = ["ne-id", "neId", "site-id", "siteId", "node-id", "nodeId", "device-id", "deviceId", "site", "node", "device", "endpoint"];

    if (typeof target === "object") {
      if ("objectidentifier" in target) {
        const found = target.objectidentifier.match(/ne-id='([^']+)'/);
        if (found)
          return found[1];
        else
          return target.objectidentifier;
      }

      if ("ne-id" in target)
        return target['ne-id'];

      for (const key of aliases)
        if (key in target) return target[key];
    }

    // Check schema-form (intent-model) for root elements

    for (const key of aliases)
      if (args.containsKey(key)) return args[key];

    // Check schema-form (intent-model) hierarchy

    let path = context.getInputValues().arguments.__attribute;
    while (path.lastIndexOf(".") > -1) {
      path = path.substr(0, path.lastIndexOf("."));
      let parent = args;
      path.split(".").forEach( elem => parent = parent[elem] );
      for (const key of aliases)
        if (parent.containsKey(key)) return parent[key];
    }

    if (typeof target === "string" && target.length > 0)
      return target; // assumption that target is ne-id

    logger.error("ne-id not found in target/args");
    return undefined;
  }

  /**
   * WebUI callout to get the list of objects from NSP inventory.
   *
   * Notes:
   *  - Access-control applies!
   *  - Action `nsp-inventory:find` enforces pagination (max: 1000 entries)
   *  - ComponentType is used to decide about return format (picker vs suggest)
   *
   * @param {ValueProviderContext} context
   * @param {Object} options
   * @param {string} key
   *
   * @returns Response using HashMap
   */

  inventoryCallout(context, options, key) {
    const startTS = Date.now();
    logger.info("WebUI::inventoryCallout()");

    const token = context.getInputValues().arguments.__token;
    const result = NSP.inventoryFind(options, true, token);

    const rvalue = new HashMap();
    if (result.success)
      if (context.getInputValues().arguments.__componentType === "leafRef")
        // output format is leafRef
        result.response.forEach(entry => rvalue.put(entry[key], entry));
      else
        // output format for autoComplete
        result.response.forEach(entry => rvalue.put(entry[key], entry[key]));

    const duration = Date.now()-startTS;
    logger.info("WebUI::inventoryCallout() finished within {} ms", duration|0);

    return rvalue;
  }

  /**
   * WebUI callout to get the list of nodes.
   *
   * to be used for component/type: leafref (picker)
   *
   * @param {ValueProviderContext} context
   * @returns Suggestion data in Map format
   */

  getNodes(context) {
    const options = {
      "xpath-filter": "/nsp-equipment:network/network-element",
      "fields": "ne-id;ne-name;type;version;ip-address"
    };

    return this.inventoryCallout(context, options, "ne-id");
  }

  /**
   * WebUI callout to get the list of ethernet ports of a device.
   *
   * to be used for component/type: leafref (picker)
   *
   * @param {ValueProviderContext} context
   * @returns Suggestion data in Map format
   */

  getPorts(context) {
    const neId = this.getNeId(context);
    if (typeof neId === "string" && neId.length > 0) {
      const filter = "[boolean(port-details[port-type='ethernet-port'])]";
      const options = {
        "xpath-filter": `/nsp-equipment:network/network-element[ne-id='${neId}']/hardware-component/port${filter}`,
        "fields": "name;description;port-details",
        "limit": 1000,
        "depth": 3
      };
      return this.inventoryCallout(context, options, "name");
    }

    logger.error("WebUI::getPorts() skipped! Select ne-id first!");
    return new HashMap();
  }

  /**
   * WebUI callout to get suggest data from NFMP based on a JSON search object.
   *
   * @param {string} neId - Network element ID.
   * @param {Object} searchObjectJson - Search parameters to send in the POST request.
   * @param {string} className - The key in the response object to extract data from.
   * @param {string} type - The field to extract from each item in the response array.
   * @returns Suggestion data in Map format
   */
  getData(neId, searchObjectJson, className, type) {
    const ret = new HashMap(),
        resultFetch = NSP.nfmpPOST(neId, "/v3/search", searchObjectJson);
    let finalResponse = JSON.parse(resultFetch.response);
    logger.info("finalResponse = {}", JSON.stringify(finalResponse));
    finalResponse = finalResponse[className];
    logger.info("finalResponse[{}] = {}", className, JSON.stringify(finalResponse));
    if (finalResponse !== undefined) {
      if (!Array.isArray(finalResponse)) {
        finalResponse = [finalResponse];
      }
      if (Object.keys(finalResponse).length) {
        finalResponse.forEach((value, index) => {
          ret.set(index, value[type]);
        });
      }
    }
    logger.info("result = {}", JSON.stringify([...ret]));
    return ret;
  }

  /**
   * WebUI callout to get the list of all managed devices (neId) from all REST
   * mediators registered with the intent engine.
   *
   * Notes:
   *  - Method will retun all nodes (no access-control, pagination)
   *  - To be used for autoComplete component
   *
   * @param {ValueProviderContext} context
   * @returns Suggestion data in Map format
   */

  suggestDevicesFromAllMediators(context) {
    const startTS = Date.now();
    logger.info("WebUI::suggestDevicesFromAllMediators()");

    // get connected mediators
    const mediators = [];
    mds.getAllManagersOfType("REST").forEach(mediator => {
      if (mds.getManagerByName(mediator).getConnectivityState().toString() === "CONNECTED")
        mediators.push(mediator);
    });

    // get managed devices from mediator(s)
    const devices = mds.getAllManagedDevicesFrom(Arrays.asList(mediators));

    const rvalue = new HashMap();
    devices.forEach(device => rvalue.put(device.getName(), device.getName()));

    const duration = Date.now()-startTS;
    logger.info("WebUI::suggestDevicesFromAllMediators() finished within {} ms", duration|0);

    return rvalue;
  }
}
