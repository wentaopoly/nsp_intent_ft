var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk'});
load({script: resourceProvider.getResource('traverse-fwk.js'), name: 'TraverseFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
load({script: resourceProvider.getResource('intentConfigValueReplacer.js'), name: 'IntentConfigValueReplacer'});

function MdcIntentFwk() {
    var intentDeviationObj = new IntentDeviceDeviation();
    var intentConfigValueReplacerObj = new IntentConfigValueReplacer();

    this.restResponseHandler = function (exception, httpStatus, response) {
        logger.info("[IntentMgr] REST response : " + response);
        logger.info("[IntentMgr] REST httpStatus : " + httpStatus);
        if (exception) {
            throw new RuntimeException("Couldn't connect to device proxy for ; Response: " + response);
        }
        if (httpStatus !== 200 && httpStatus !== 201) {
            throw new RuntimeException("Failed to access device  using MDC; Response: " + response);
        }
        restResponse = JSON.parse(response);
    };

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {

        var traverseFwk = new TraverseFwk();
        var parseTarget = new ParseTarget();
        var target = parseTarget.getNeIdFromTarget(input.getTarget());

        // saved topology
        var savedTopology = input.getCurrentTopology();

        if (savedTopology == null) {
            savedTopology = topologyFactory.createServiceTopology();
        }


        if (input.getNetworkState().name() == "delete") {
            traverseFwk.resetTheVariables();
            var requests = [];
            var deleteMacfilterObj = {};
            deleteMacfilterObj["operation"] = "delete";
            deleteMacfilterObj["edit-id"] = "edit-" + new Date().getTime();
            deleteMacfilterObj["target"] = "nokia-conf:/configure/filter/mac-filter=" + parseTarget.getUniqueIdentifier(input.getTarget());
            requests.push(deleteMacfilterObj)
            result = traverseFwk.syncRequest(target, requests, result, savedTopology);
            result.setTopology(null);
            return result;

        }

        if (target !== "0.0.0.0") {
            var intentConfig;
            intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
            var filterName = input.getTarget().split("#")[2];
            var filterId = input.getTarget().split("#")[3];
            var shouldPush = true;
            intentConfig["filter-name"] = filterName;
            intentConfig['filter-id'] = parseInt(filterId);

            //Removing deviations info
            intentConfig = intentDeviationObj.removeIntentConfig(intentConfig, target);
            //Replace Values
            //intentConfig = intentConfigValueReplacerObj.replaceConfigValue(intentConfig);
            if (intentConfig) {
                savedTopology = traverseFwk.traverse(target, intentConfig, savedTopology, null, parentXpath, initialPropertyName);
                //sorting delete array
                var deleteRequests = traverseFwk.getDeleteRequests();
                var deleteReqObjects = [];
                for (var delCount = 0; delCount < deleteRequests.length; delCount++) {
                    var delReqObj = deleteRequests[delCount];
                    var targetUrl = delReqObj['target'].split('/');
                    var cmpUrl = '';
                    for (var tCount = 0; tCount < targetUrl.length; tCount++) {
                        cmpUrl = cmpUrl + "/" + targetUrl[tCount].split('=')[0];
                    }
                    if ("/nokia-conf:/configure/filter/mac-filter/entry/match/isid/range" === cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/match/isid/range/start" === cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/match/isid/range/end" === cmpUrl ||"/nokia-conf:/configure/filter/mac-filter/entry/match/isid/value"===cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/action/http-redirect"===cmpUrl|| "/nokia-conf:/configure/filter/mac-filter/entry/action/http-redirect/url"===cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/action/forward/sap"=== cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/action/forward/sap/sap-id"=== cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/action/forward/sap/vpls" === cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/action/forward/esi-l2"===cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/action/forward/esi-l2/esi-value" === cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/action/forward/esi-l2/vpls"=== cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/action/forward/sdp"=== cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/action/forward/sdp/sdp-bind-id"=== cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/action/forward/sdp/vpls"=== cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/action/secondary/forward/sap"=== cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/action/secondary/forward/sap/sap-id" === cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/action/secondary/forward/sap/vpls"
                        === cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/action/secondary/forward/sdp"=== cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/action/secondary/forward/sdp/sdp-bind-id"=== cmpUrl || "/nokia-conf:/configure/filter/mac-filter/entry/action/secondary/forward/sdp/vpls"=== cmpUrl ) {
                        shouldPush = false;
                    }
                    if (shouldPush) {
                        deleteReqObjects.push(delReqObj);
                    }

                }
                deleteRequests = deleteReqObjects;
                deleteRequests.sort(function (a, b) {
                    return b["target"].length - a["target"].length;
                });

                //concating createrequests and deleterequests
                var createRequests = traverseFwk.getCreateRequests();
                var requests;
                if (deleteRequests && createRequests) {
                    requests = createRequests.concat(deleteRequests);
                }
                if (requests) {
                    result = traverseFwk.syncRequest(target, requests, result, savedTopology);
                }

            } else {

                result = traverseFwk.deleteAllFromTopology(savedTopology, target, result);
            }

        }
        traverseFwk.resetTheVariables();
        return result;
    }

    this.audit = function (target, config, svcTopo, adminState, report, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        var currentConfig;
        var traverseFwk = new TraverseFwk();
        var parseTarget = new ParseTarget();
        var targetNeId = parseTarget.getNeIdFromTarget(target);

        if (target !== "0.0.0.0") {
            currentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
            if (!currentConfig) {
                currentConfig = {}
            }
            var filterName = target.split("#")[2];
            currentConfig["filter-name"] = filterName;
            currentConfig = intentDeviationObj.removeIntentConfig(currentConfig, targetNeId);

            svcTopo = traverseFwk.traverse(targetNeId, currentConfig, svcTopo, report, parentXpath, initialPropertyName);
            // reseting the variables
            traverseFwk.resetTheVariables();
        }

        return report;

    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }
}
