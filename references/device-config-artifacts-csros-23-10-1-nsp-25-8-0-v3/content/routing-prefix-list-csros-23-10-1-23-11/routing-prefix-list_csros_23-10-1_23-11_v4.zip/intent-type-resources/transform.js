load({ script: resourceProvider.getResource("nfmpSuggest.js"), name: "NfmpSuggest" });
load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
function transformData() {
    let ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(\/(0|[1-9][0-9]?|1[0-1][0-9]?|12[0-8]))?$/;
    let jsonFile = resourceProvider.getResource("meta-data/property-meta-data.json");
    jsonFile = JSON.parse(jsonFile);
    const nfmpSuggest = new NfmpSuggest();
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        return payload;
    }
    this.isJsonCompletelyEmpty = function(obj) {
      // Check if the object itself is empty
      if (Object.keys(obj).length === 0) {
        return true;
      }

      // Check each property
      for (let key in obj) {
        if (obj.hasOwnProperty(key)) {
          // If the property is an object, check it recursively
          if (typeof obj[key] === 'object' && obj[key] !== null) {
            if (!this.isJsonCompletelyEmpty(obj[key])) {
              return false;
            }
          } else {
            // If the property is not an object (or it's a non-null primitive value), it's not empty
            return false;
          }
        }
      }
      // If all properties are empty objects or there are no properties, the object is empty
      return true;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        let ipv6AddrUtil = new IPv6AddressUtil();
        if(isAudit)
        {
            if(xpath == "rp-PrefixListMember.prefix" || xpath == "rp-PrefixListMember.rp-ToPrefixListMember.prefix" || xpath == "rp-PrefixListMember.rp-PrefixListMemberAddressMask.addressMask")
            {
                if(ipv6AddrUtil.matchExact(ipv6Regex, targetValue))
                {
                    targetValue = ipv6AddrUtil.expandIPv6AddressForClassic(targetValue);
                }
            }

        }
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig) {
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
}