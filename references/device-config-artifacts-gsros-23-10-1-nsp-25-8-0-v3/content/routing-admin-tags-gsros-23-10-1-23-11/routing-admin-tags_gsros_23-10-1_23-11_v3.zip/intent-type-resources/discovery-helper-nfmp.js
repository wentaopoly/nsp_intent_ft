var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource("model-device-mapping.js"), name: "model-device-mapping"});


function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let modelDeviceMapping = new ModelDeviceMapping();
    let util = new utilities();
    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let searchPayLoadAdminTag = this.constructSearchString(neId, "rtr.AdminTag");
        let searchResponseAdminTag = nfmpFwk.post("/v3/search", searchPayLoadAdminTag);
        if (!searchResponseAdminTag.success)
        {
            logger.error("Failed to find Admin-tags on NE " + neId);
        }
        searchResponseAdminTag = JSON.parse(searchResponseAdminTag.response);

        let searchPayLoadAdminTagPolicy = this.constructSearchString(neId, "rtr.AdminTagPolicy");
        let searchResponseAdminTagPolicy = nfmpFwk.post("/v3/search", searchPayLoadAdminTagPolicy);
        if (!searchResponseAdminTagPolicy.success)
        {
            logger.error("Failed to find Admin-tag-policies on NE " + neId);
        }
        searchResponseAdminTagPolicy = JSON.parse(searchResponseAdminTagPolicy.response);

        let deviceConfig = {
            "admin-tag": searchResponseAdminTag["rtr.AdminTag"] ? searchResponseAdminTag["rtr.AdminTag"] : [],
            "admin-tag-policy": searchResponseAdminTagPolicy["rtr.AdminTagPolicy"] ? searchResponseAdminTagPolicy["rtr.AdminTagPolicy"] : []
        };
        return deviceConfig;
    }
    this.constructSearchString = function (neId, fullClassName) {
        let jsonPayLoad = {
            "fullClassName": fullClassName,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            }
        };
        return jsonPayLoad;
    }
    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        logger.info("***********************************deviceConfig***********************************************");
        logger.info(JSON.stringify(deviceConfig));
        logger.info("************************************parsedDefaultTargetData***********************************");
        logger.info(JSON.stringify(parsedDefaultTargetData));
        logger.info("**************************************************END******************************************");
        if (null !== deviceConfig)
        {
            let adminTagArray = this.extractAdminTagProperties(parsedDefaultTargetData["admin-tags"]["admin-tag"], deviceConfig["admin-tag"]);
            parsedDefaultTargetData["admin-tags"]["admin-tag"] = adminTagArray;

            let adminTagPolicyArray = this.extractAdminTagPolicyProperties(parsedDefaultTargetData["admin-tags"]["route-admin-tag-policy"], deviceConfig["admin-tag-policy"]);
            parsedDefaultTargetData["admin-tags"]["route-admin-tag-policy"] = adminTagPolicyArray;
        }
        this.clearEmpties(parsedDefaultTargetData);
        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData));
        return parsedDefaultTargetData;
    }
    this.extractAdminTagProperties = function (defaultTargetData, deviceConfig) {
        let adminTagArray = [];
        if (!Array.isArray(deviceConfig))
        {
            deviceConfig = [deviceConfig];
        }
        let adminTagData = defaultTargetData[0];
        let mappings = modelDeviceMapping.getAdminTagMapping();
        for (let i = 0; i < deviceConfig.length; i++)
        {
            let deviceAdminTagConfig = deviceConfig[i];
            let keys = Object.keys(adminTagData);
            logger.info("keys = " + keys);
            for (let j = 0; j < keys.length; j++)
            {
                let targetKey = keys[j];
                let targetObj = adminTagData[targetKey];
                let mappedKey = "admin-tags.admin-tag." + targetKey;
                //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj) + "\nmappedKey = " + mappedKey);
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, adminTagData, deviceAdminTagConfig);
            }
            adminTagArray.push(JSON.parse(JSON.stringify(adminTagData)));
        }
        return adminTagArray;
    }
    this.extractAdminTagPolicyProperties = function (defaultTargetData, deviceConfig) {
        let adminTagPolicyArray = [];
        if (!Array.isArray(deviceConfig))
        {
            deviceConfig = [deviceConfig];
        }
        let adminTagPolicyData = defaultTargetData[0];
        let adminTagPolicyDataClone = JSON.parse(JSON.stringify(adminTagPolicyData));
        let mappings = modelDeviceMapping.getAdminTagPolicyMapping();
        for (let i = 0; i < deviceConfig.length; i++)
        {
            let deviceAdminTagPolicyConfig = deviceConfig[i];
            let keys = Object.keys(adminTagPolicyDataClone);
            logger.info("keys = " + keys);
            for (let j = 0; j < keys.length; j++)
            {
                let targetKey = keys[j];
                let targetObj = adminTagPolicyDataClone[targetKey];
                let mappedKey = "admin-tags.route-admin-tag-policy." + targetKey;
                //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj) + "\nmappedKey = " + mappedKey);
                if (targetObj != null && typeof targetObj === 'object')
                {
                    if (targetKey === "include")
                    {
                        logger.info("extracting include data");
                        let adminTagPolicyIncludeArray = []
                        if (deviceAdminTagPolicyConfig["children-Set"])
                        {
                            if (deviceAdminTagPolicyConfig["children-Set"]["rtr.IncludeAdminTag"])
                            {
                                adminTagPolicyIncludeArray = this.extractIncludeExcludeProperties(targetObj, deviceAdminTagPolicyConfig["children-Set"]["rtr.IncludeAdminTag"]);
                            }
                        }
                        adminTagPolicyData[targetKey] = adminTagPolicyIncludeArray;
                    }
                    if (targetKey === "exclude")
                    {
                        logger.info("extracting exclude data");
                        let adminTagPolicyExcludeArray = [];
                        if (deviceAdminTagPolicyConfig["children-Set"])
                        {
                            if (deviceAdminTagPolicyConfig["children-Set"]["rtr.ExcludeAdminTag"])
                            {
                                adminTagPolicyExcludeArray = this.extractIncludeExcludeProperties(targetObj, deviceAdminTagPolicyConfig["children-Set"]["rtr.ExcludeAdminTag"]);
                            }
                        }
                        adminTagPolicyData[targetKey] = adminTagPolicyExcludeArray;
                    }
                }
                else
                {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, adminTagPolicyData, deviceAdminTagPolicyConfig);
                }
            }
            adminTagPolicyArray.push(JSON.parse(JSON.stringify(adminTagPolicyData)));
        }
        return adminTagPolicyArray;
    }
    this.extractIncludeExcludeProperties = function (defaultTargetData, deviceConfig) {
        let includeExcludeArray = [];
        if (!Array.isArray(deviceConfig))
        {
            deviceConfig = [deviceConfig];
        }
        let includeExcludeTargetData = defaultTargetData[0];
        let includeExcludeTargetDataClone = JSON.parse(JSON.stringify(defaultTargetData[0]));
        let mappings = modelDeviceMapping.getAdminTagPolicyMapping();
        for (let i = 0; i < deviceConfig.length; i++)
        {
            let includeExcludedeviceConfig = deviceConfig[i];
            let keys = Object.keys(includeExcludeTargetDataClone);
            logger.info("keys = " + keys);
            for (let j = 0; j < keys.length; j++)
            {
                let targetKey = keys[j];
                let targetObj = includeExcludeTargetDataClone[targetKey];
                let mappedKey = "admin-tags.route-admin-tag-policy." + targetKey;
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, includeExcludeTargetData, includeExcludedeviceConfig);
            }
            includeExcludeArray.push(JSON.parse(JSON.stringify(includeExcludeTargetData)));
        }
        return includeExcludeArray;

    }
    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, deviceConfig) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = deviceConfig[nfmpKey];
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);
    }
    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue !== null)
        {
            return deviceValue;
        }
    }


    this.clearEmpties = function (o) {
        for (let k in o)
        {
            if (!o[k] || typeof o[k] !== "object")
            {
                continue
            }

            this.clearEmpties(o[k]);
            if (Object.keys(o[k]).length === 0)
            {
                delete o[k];
            }
        }
    }
}
