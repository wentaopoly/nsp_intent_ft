var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let policyId = target.split("#")[2];
        let policyName = parseTarget.getUniqueIdentifier(target);
        let neId = parseTarget.getNeIdFromTarget(target);
        let className = "sasqos.PortAccessIngress";
        let objectFullName = "network:" + neId + ":sasPortAccessIngressPolicy:" + policyId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        let searchPayLoad = this.constructSearchString(className, objectFullName);
        let searchResponse = nfmpFwk.post("/v3/search", searchPayLoad);
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0)) {
            if (!(searchResponse.success)) throw new RuntimeException("Failed to get Port Ingress Policy info from nfm-p for Ne " + neId + " and Port Ingress Policy Id: " + policyId);
            if (JSON.parse(searchResponse["response"]).length === 0) throw new RuntimeException("There is no Port Ingress with Name:" + policyName + " and Id:" + policyId);
        }
        searchResponse = JSON.parse(searchResponse.response);
        logger.info("searchResponse = {}", JSON.stringify(searchResponse));
        return searchResponse;
    }

    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        logger.info("the parseTargetData" + JSON.stringify(parsedDefaultTargetData));
        let sasIngressConfig = deviceConfig['sasqos.PortAccessIngress'];
        if (null !== sasIngressConfig && sasIngressConfig !== undefined) {
            this.extractPolicyLevelProperties(parsedDefaultTargetData, sasIngressConfig);
        }
        let childrenConfig = sasIngressConfig['children-Set'];
        if (undefined !== childrenConfig && null !== childrenConfig && childrenConfig.length !== 0) {
            let fcData = parsedDefaultTargetData['port-qos-ingress']['fc'];
            if (fcData !== null && Array.isArray(fcData) && fcData.length !== 0) {
                let childFcConfig = childrenConfig['sasqos.PortAccessIngressForwardingClass'];
                if (childFcConfig != undefined && childFcConfig.length != 0) {
                    let fcArray = this.extractFcData(fcData, childFcConfig);
                    parsedDefaultTargetData['port-qos-ingress']["fc"] = fcArray;
                } else {
                    delete parsedDefaultTargetData['port-qos-ingress']["fc"];
                }
            }

            let meterData = parsedDefaultTargetData['port-qos-ingress']['meter'];
            if (meterData !== null && Array.isArray(meterData) && meterData.length !== 0) {
                let childMeterConfig = childrenConfig['sasqos.PortAccessIngressMeter'];
                if (childMeterConfig != undefined && childMeterConfig.length != 0) {
                    let meterDataArray = this.extractMeterData(meterData, childMeterConfig);
                    parsedDefaultTargetData['port-qos-ingress']['meter'] = meterDataArray;
                } else {
                    delete parsedDefaultTargetData['port-qos-ingress']['meter'];
                }
            }

        }
        return parsedDefaultTargetData;
    }

    this.extractPolicyLevelProperties = function (defaultTargetData, PortIngressConfig) {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++) {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object') {
                let mappings = modelDeviceMapping.getPortIngressMapping();
                this.traverseAndUpdateConfig(targetKey, targetObj, PortIngressConfig, mappings);
            }
        }
    }

    this.extractFcData = function (defaultFcEntry, childrenConfiguration) {
        let fcEntryDefaults = defaultFcEntry[0];
        let fcEntryArray = [];
        if (childrenConfiguration !== undefined && childrenConfiguration !== null) {
            if (Array.isArray(childrenConfiguration)) {
                for (let i = 0; i < childrenConfiguration.length; i++) {
                    let childConfig = childrenConfiguration[i];
                    let fcEntryData = this.fcEntryData(fcEntryDefaults, childConfig);
                    fcEntryArray.push(fcEntryData);
                }
            } else {
                let childConfig = childrenConfiguration;
                let fcEntryData = this.fcEntryData(fcEntryDefaults, childConfig);
                fcEntryArray.push(fcEntryData);
            }
        }
        return fcEntryArray;
    }
    this.fcEntryData = function (fcEntryDefaults, childConfig) {
        let ForwardingClassData = JSON.parse(JSON.stringify(fcEntryDefaults));
        if (childConfig['forwardingClass']) {
            ForwardingClassData['fc-name'] = childConfig['forwardingClass'];
        }
        if (childConfig['meterId'] && childConfig['meterId'] !== '0') {
            ForwardingClassData['meter-id'] = childConfig['meterId'];
        }
        if (childConfig['multicastMeterId'] && childConfig['multicastMeterId'] !== '0') {
            ForwardingClassData['multicast-meter-id'] = childConfig['multicastMeterId'];
        }
        this.clearEmptiesAndNull(ForwardingClassData);
        return ForwardingClassData;
    }

    this.extractMeterData = function (defaultMeterEntry, childrenConfiguration) {
        let meterEntryDefaults = defaultMeterEntry[0];
        let meterEntryArray = [];
        if (childrenConfiguration !== undefined && childrenConfiguration !== null) {
            if (Array.isArray(childrenConfiguration)) {
                for (let i = 0; i < childrenConfiguration.length; i++) {
                    let childConfig = childrenConfiguration[i];
                    let meterEntryData = this.MeterData(meterEntryDefaults, childConfig);
                    meterEntryArray.push(meterEntryData);
                }
            } else {
                let childConfig = childrenConfiguration;
                let meterEntryData = this.MeterData(meterEntryDefaults, childConfig);
                meterEntryArray.push(meterEntryData);
            }
        }
        return meterEntryArray;
    }

    this.MeterData = function (meterEntryDefaults, childConfig) {
        let meterEntryData = JSON.parse(JSON.stringify(meterEntryDefaults));
        meterEntryData['meter-id'] = childConfig['id'];
        meterEntryData['rate-mode'] = util.bftransformRateMode(childConfig['rateMode']);
        meterEntryData['color-mode'] = util.bftransformColorMode(childConfig['colorMode']);
        if (childConfig["pir"]) {
            if (childConfig["pir"] === "-1") {
                meterEntryData["rate"]["pir"] = "max";
            } else {
                meterEntryData["rate"]["pir"] = childConfig["pir"];

            }
        }
        if (childConfig["cir"]) {
            if (childConfig["cir"] === "-1") {
                meterEntryData["rate"]["cir"] = "max";
            } else {
                meterEntryData["rate"]["cir"] = childConfig["cir"];
            }
        }
        if (childConfig["cirAdaptation"]) {
            meterEntryData["adaptation-rule"]["cir"] = childConfig["cirAdaptation"];

        }
        if (childConfig["pirAdaptation"]) {
            meterEntryData["adaptation-rule"]["pir"] = childConfig["pirAdaptation"];
        }
        if (childConfig["mbsType"]) {
            meterEntryData["mbs-type"] = childConfig["mbsType"];
        }
        if (childConfig["cbsType"]) {
            meterEntryData["cbs-type"] = childConfig["cbsType"];
        }
        if (childConfig["mbsType"]==="kbits") {
            if (childConfig["mbs"]) {
                if (childConfig["mbs"] === "-1") {
                    meterEntryData["mbs"] = "Default";
                } else {
                    meterEntryData["mbs"] = childConfig["mbs"]
                }
            }
        }
        if (childConfig["mbsType"]==="kbytes") {
            if (childConfig["mbs"]) {
                if (childConfig["mbsKiloBytes"] === "-1") {
                    meterEntryData["mbs"] = "Default";
                } else {
                    meterEntryData["mbs"] = childConfig["mbsKiloBytes"]
                }
            }
        }
        if (childConfig["mbsType"]==="bytes") {
            if (childConfig["mbs"]) {
                if (childConfig["mbsBytes"] === "-1") {
                    meterEntryData["mbs"] = "Default";
                } else {
                    meterEntryData["mbs"] = childConfig["mbsBytes"]
                }
            }
        }
        if (childConfig["cbsType"]==="kbits") {
            if (childConfig["cbs"]) {
                if (childConfig["cbs"] === "-1") {
                    meterEntryData["cbs"] = "Default";
                } else {
                    meterEntryData["cbs"] = childConfig["cbs"];
                }
            }
        }
        if (childConfig["cbsType"]==="kbytes") {
            if (childConfig["cbsKiloBytes"]) {
                if (childConfig["cbsKiloBytes"] === "-1") {
                    meterEntryData["cbs"] = "Default";
                } else {
                    meterEntryData["cbs"] = childConfig["cbsKiloBytes"];
                }
            }
        }
        if (childConfig["cbsType"]==="bytes") {
            if (childConfig["cbsBytes"]) {
                if (childConfig["cbsBytes"] === "-1") {
                    meterEntryData["cbs"] = "Default";
                } else {
                    meterEntryData["cbs"] = childConfig["cbsBytes"];
                }
            }
        }
        if (childConfig["mCast"]) {
            meterEntryData["multi-point"] = childConfig["mCast"];
        }
        this.clearEmptiesAndNull(meterEntryData);
        return meterEntryData
    }

    this.traverseAndUpdateConfig = function (objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port-qos-ingress.meter" && mappedKey !== "port-qos-ingress.fc") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, parsedDeviceConfig) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = parsedDeviceConfig[nfmpKey];
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue, parsedDeviceConfig);

    }

    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue !== null) {
            switch (mappedKey) {
                case"port-qos-ingress.counter-mode":
                    deviceValue = util.bftransformCounterMode(deviceValue);
                    break;
                case "port-qos-ingress.table-classification-criteria":
                    deviceValue = util.bfconvertToTableClassificationCriteria(deviceValue);
                    break;
                case "port-qos-ingress.dscp-classification":
                    deviceValue = util.bfNfmpDscpClassification(deviceValue);
                    break;
                case "port-qos-ingress.dot1p-classification":
                    deviceValue = util.bfNfmpDot1pClassification(deviceValue);
                    break;
            }
            return deviceValue;
        }
    }

    this.constructSearchString = function (fullClassName, objectFullName) {
        let jsonPayLoad = {
            "fullClassName": fullClassName,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        return jsonPayLoad;
    }

    this.clearEmptiesAndNull = function (o) {
        for (let k in o) {
            if (o[k] === null) {
                delete o[k];
            }
            if (!o[k] || typeof o[k] !== "object") {
                continue
            }

            this.clearEmptiesAndNull(o[k]);
            if (Object.keys(o[k]).length === 0) {
                delete o[k];
            }
        }
    }
}
