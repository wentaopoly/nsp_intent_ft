var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};


load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

var intentTypeName = 'icm-system-security_cpm';

// example port, sap-ingress etc..
var initialPropertyName = 'cpm-filter';


// unique identifier
var uniqueIdentifier = 'cpm';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/system/security';

var topologyInfo = {};

function synchronize(input) {
    logger.info('Intent Synchronisation started')

    return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, topologyInfo);
}

function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started')

    return NspIntentHelper.audit(target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, topologyInfo);
}

function getTargetData(input) {
    logger.info("getTargetData input for brownfield = \n" + input);
    var target = input.target;
    var config = null;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info(JSON.stringify(deviceConfig));
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}

function suggestCpmQueues(context) {
    var cpmQueues = [];
    var queueData = context['inputValues']['arguments']['__parent']['cpm-queue']['queue'];
    for (var queueCount = 0; queueCount < queueData.length; queueCount++) {
        cpmQueues.push(queueData[queueCount]['queue-id']);
    }
    return cpmQueues;
}
function suggestCPM()
{
    var ret = [];
    ret.push("cpm");
    return ret;
}


