function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig) {
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
}