var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
NspIntentHelper = new NspIntentHelper();

load({script:resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})

var LOG_PREFIX = "[Network QOS 7210]: "

var intentTypeName = 'qos-network_csas_23-10-1_23-11';

var initialPropertyName = 'network';

var parentXpath = 'configure/qos';

// unique identifier
var uniqueIdentifier = 'network-policy-name';
function synchronize(input) {
    logger.info(LOG_PREFIX + "Intent Synchronisation started for Network QOS Policy SAS 7210");
    return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}
function audit(input) {
    logger.info(LOG_PREFIX + "Intent Audit started for Network QOS Policy SAS 7210");
    logger.info("******* config Audit ===== {}", input);
    return NspIntentHelper.audit(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}
function suggestPolicyId(context) {
    logger.info(LOG_PREFIX + "suggestPolicyId context = \n" + context);
    var policyId = context.getInputValues()["arguments"]["target_id"];
    logger.info(LOG_PREFIX + "User selected Policy : {}, searching Policy ID associated to Policy - {}", policyId, policyId);
    var neId = getNeId(context);
    return new NfmpSuggest().getPolicyId(neId, policyId, "nwPolicyId");
}

function suggestNwManagerId(context) {
    logger.info(LOG_PREFIX + "suggestNwManagerId context = \n" + context);
    var policyId = context.getInputValues()["arguments"]["target_nwPolicyId"];
    logger.info(LOG_PREFIX + "User selected Policy : {}, searching Nw Manager Policy ID associated to Policy - {}", policyId, policyId);
    var neId = getNeId(context);
    return new NfmpSuggest().getPolicyId(neId, policyId, "id");
}

function suggestMplsLspExpProfileMapPolicyId(context) {
    var neId = getNeId(context);
    var className = "sasqos.MplsLspExpMap";
    logger.info(LOG_PREFIX + "********** suggestMplsLspExpProfileMapPolicyId ********* ");
    return new NfmpSuggest().getSupportAttributePolicyDetails(neId, className, false);
}

function suggestDot1pClassificationPolicyId(context) {
    var neId = getNeId(context);
    var className = "sasqos.Dot1pClassification";
    logger.info(LOG_PREFIX + "********** suggestDot1pClassificationPolicyId ********* ");
    return new NfmpSuggest().getSupportAttributePolicyDetails(neId, className, false);
}

function suggestDscpClassificationPolicyId(context) {
    var neId = getNeId(context);
    var className = "sasqos.DSCPClassification";
    logger.info(LOG_PREFIX + "********** suggestDscpClassificationPolicyId ********* ");
    return new NfmpSuggest().getSupportAttributePolicyDetails(neId, className, false);
}

function suggestMplsLspExpClassificationPolicyId(context) {
    var neId = getNeId(context);
    var className = "sasqos.MplsLspExpClassification";
    logger.info(LOG_PREFIX + "********** suggestMplsLspExpClassificationPolicyId ********* ");
    return new NfmpSuggest().getSupportAttributePolicyDetails(neId, className, false);
}

function suggestSlopePolicy(context) {
    var neId = getNeId(context);
    var className = "sasqos.SlopePolicy";
    logger.info(LOG_PREFIX + "********** suggestSlopePolicy ********* ");
    return new NfmpSuggest().getSupportAttributePolicyDetails(neId, className, false);
}

function suggestRemarkingPolicy(context) {
    var neId = getNeId(context);
    var className = "sasqos.Remark";
    logger.info(LOG_PREFIX + "********** suggestRemarkingPolicy ********* ");
    return new NfmpSuggest().getSupportAttributePolicyDetails(neId, className, false);
}

function suggestIngressFcMeter(context) {
    var result = [];
    var meterConfig = JSON.parse(context.getInputValues())["arguments"]["__parent"]["network"]["ingress"]["meter"];
    if (!Array.isArray(meterConfig)) {
        meterConfig = [meterConfig];
    }
    for (var index in meterConfig) {
        var meterObj = meterConfig[index];
        if (meterObj["multipoint"] === "false" || meterObj["multipoint"] === false) {
            result.push(meterObj["meter-id"])
        }
    }
    return result;
}

function suggestIngressFcMultiCastMeter(context) {
    var result = [];
    var meterConfig = JSON.parse(context.getInputValues())["arguments"]["__parent"]["network"]["ingress"]["meter"];
    if (!Array.isArray(meterConfig)) {
        meterConfig = [meterConfig];
    }
    for (var index in meterConfig) {
        var meterObj = meterConfig[index];
        if (meterObj["multipoint"] === "true" || meterObj["multipoint"] === true) {
            result.push(meterObj["meter-id"])
        }
    }
    return result;
}

function suggestQueueId(context) {
    var result = [];
    var queueConfig = JSON.parse(context.getInputValues())["arguments"]["__parent"]["network"]["ingress"]["queue"];
    if (!Array.isArray(queueConfig)) {
        queueConfig = [queueConfig];
    }
    for (var index in queueConfig) {
        result.push(queueConfig[index]["queue-id"])
    }
    return result;
}

function getNeId(context) {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    logger.info(target)
    if (target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    logger.info(LOG_PREFIX + "NeId : " + neId);
    return neId;
}
function getTargetData(input) {
    logger.info(LOG_PREFIX + "getTargetData input for brownfield = \n" + input);
    var target = input.target;
    var config = null;
    logger.info(LOG_PREFIX + "target = " + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info(JSON.stringify(deviceConfig));
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}

