var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);

        let searchPayLoad = this.constructSearchString(neId);
        let searchResponse = nfmpFwk.post("search", searchPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find IEEE-PTP-CLOCK  on NE " + neId);
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse[0];
    }

    this.constructSearchString = function (neId) {
        let fullName = "fullName = 'network:" + neId + ":ptp'"
        let jsonPayLoad = {
            "filter": {
                "filterExpression": fullName
            },
            "fullClassName": "ptp.IEEEPTPClock"
        };
        return jsonPayLoad;
    }

    this.extractDeviceConfig = function (defaultTargetData, fullDeviceConfig, initialPropertyName) {
        let ptpConfig;
        let ptpPortConfig = [];

        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        ptpConfig = fullDeviceConfig['properties'];
        let ptpChildrenConfig = fullDeviceConfig['children'];

        ptpChildrenConfig.forEach(function (element) {
            if (element.fullClassName === 'ptp.IEEEPTPPort')
            {
                ptpPortConfig.push(element['properties']);
            }
        });

        let deviceConfig = {
            "ptpConfig": ptpConfig,
            "ptpPortConfig": ptpPortConfig
        };
        if (null !== ptpConfig)
        {
            this.extractPtpProperties(parsedDefaultTargetData, deviceConfig);
        }
        let portData = parsedDefaultTargetData['ptp']['port'];
        if (portData !== null && Array.isArray(portData) && portData.length !== 0)
        {
            let lagPortArray = this.extractPtpPortProperties(parsedDefaultTargetData['ptp']['port'], deviceConfig);
            parsedDefaultTargetData['ptp']['port'] = lagPortArray;
        }

        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData))
        return parsedDefaultTargetData;
    }

    this.extractPtpProperties = function (defaultTargetData, deviceConfig) {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object')
            {
                let mappings = modelDeviceMapping.getPtpMapping();
                this.traverseAndUpdateConfig(targetKey, targetObj, mappings, deviceConfig);
            }
        }
        return defaultTargetData;
    }

    this.extractPtpPortProperties = function (ptpPortTargetData, deviceConfig) {
        //logger.info("ptpPortTargetData = \n" + JSON.stringify(ptpPortTargetData) + "\n\n\nptpPortConfig = \n" + JSON.stringify(ptpPortConfig));
        let ptpPortArray = [];
        let portData = ptpPortTargetData[0];
        let mappings = modelDeviceMapping.getPtpPortMapping();
        for (let i = 0; i < deviceConfig.ptpPortConfig.length; i++)
        {
            let devicePortConfig = deviceConfig.ptpPortConfig[i];
            let keys = Object.keys(portData);
            logger.info("keys = " + keys);
            for (let j = 0; j < keys.length; j++)
            {
                let targetKey = keys[j];
                let targetObj = portData[targetKey];
                let mappedKey = "ptp.port." + targetKey;
                //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj) + "\nmappedKey = " + mappedKey);
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, portData, devicePortConfig);
            }
            ptpPortArray.push(JSON.parse(JSON.stringify(portData)));
        }
        return ptpPortArray;
    }

    this.traverseAndUpdateConfig = function (objKey, obj, mappings, deviceConfig) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "ptp.port")
            {
                if (value != null && typeof value === 'object')
                {
                    this.traverseAndUpdateConfig(mappedKey, value, mappings, deviceConfig);
                }
                else
                {
                    // call for each key with string value
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, deviceConfig);
                }
            }
        }
        return obj;
    }


    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, deviceConfig) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = "";
        if (mappedKey.startsWith("ptp.port."))
        {
            deviceValue = deviceConfig[nfmpKey];
        }
        else
        {
            deviceValue = deviceConfig.ptpConfig[nfmpKey];
        }
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);
    }

    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue !== null)
        {
            switch (mappedKey)
            {
                case "ptp.admin-state":
                case "ptp.port.admin-state":
                    deviceValue = util.convertAdminStateBrownField(deviceValue);
                    break;
                case "ptp.clock-type":
                    deviceValue = util.convertClockTypeBrownField(deviceValue);
                    break;
                case "ptp.profile":
                    deviceValue = util.convertProfileBrownField(deviceValue);
                    break;
                case "ptp.port.port-id":
                    deviceValue = deviceValue.replace("Port ", "");
                    break;
                case "ptp.port.address":
                    deviceValue = util.convertAddressBrownField(deviceValue);
                    break;
                case "ptp.port.log-delay-interval":
                case "ptp.port.log-sync-interval":
                    deviceValue = util.convertIntervalBrownField(deviceValue);
                    break;
            }
            return deviceValue;
        }
    }

}
