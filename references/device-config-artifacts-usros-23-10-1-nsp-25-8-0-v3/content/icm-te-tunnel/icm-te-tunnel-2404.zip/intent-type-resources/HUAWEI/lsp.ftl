<#ftl output_format="JSON">
<#setting number_format="computer">
{
  "name": "Tunnel${target?keep_after("_")}",
  "class": "main-interface",
  "type": "Tunnel",
  "number":  "${target?keep_after("_")}",
  "description":"${config["description"]}",
  <#if config["admin-state"] == "tunnel-admin-state-down">
    "admin-status": "down",
  <#else>
    "admin-status": "up",
  </#if>
  
  "ipv4":{
    "unnumbered-address":{
      "unnumbered-if-name": "LoopBack0"
    }
  },
  "tunnel-protocol": {
    "te-tunnel": {
      "common-attributes": {
        "tunnel-id": ${target?keep_after("_")},
        "egress-lsr-id": "${config["destination"]}",
        "reserved-for-binding": false,
        "signal-protocol": "rsvp-te",
        "lsp-tp-outbound": false,
        <#if default?has_content>
          <#if default["statistic-enable"]?has_content>
            "statistic-enable": ${default["statistic-enable"]?c}
          <#else>
            "statistic-enable": false
          </#if>
        <#else>
          "statistic-enable": false
        </#if>
      },

      "rsvp-te": {
        "class-type": "ct0",
        "best-effort-enable": "true",
        "lsp-paths": {
          "lsp-path": [
            {
              "path-type": "best-effort",
              "hop-limit": 32,
              "include-any": "0x0",
              "exclude-any": "0x0"
            }
          ]
        },
        <#if default?has_content>
            <#if default["bfd-enable"]?has_content>
                <#if default["bfd-enable"] == true>
                    "bfd-for-lsp": {
                        "ability": "enable",
                        <#if default["bfd-min-tx-interval"]?has_content>
                          "min-tx-interval": ${default["bfd-min-tx-interval"]},
                        <#else>
                          "min-tx-interval": 20000,
                        </#if>
                        <#if default["bfd-min-rx-interval"]?has_content>
                          "min-rx-interval": ${default["bfd-min-rx-interval"]}
                        <#else>
                          "min-rx-interval": 20000
                        </#if>
                    },
                <#else>
                    "bfd-for-lsp": {
                        "ability": "enable",
                        "min-tx-interval": 20000,
                        "min-rx-interval": 20000
                    },
                </#if>
            <#else>
                "bfd-for-lsp": {
                    "ability": "enable",
                    "min-tx-interval": 20000,
                    "min-rx-interval": 20000
                },
            </#if>
        <#else>
            "bfd-for-lsp": {
                "ability": "enable",
                "min-tx-interval": 20000,
                "min-rx-interval": 20000
            },
        </#if>

        "record-route": "record-label"
        <#if config["reoptimize-timer"]?has_content>
            ,
            "reoptimization": true,
            "reoptimization-frequency": ${config["reoptimize-timer"]}
        </#if>

        <#if extraParams.primary?size != 0>
          <#list extraParams.primary?values as value>  
            ,
            "bandwidth": ${value.bandwidth}
            <#if value["conf"]["setup-priority"]??>
              ,
              "setup-priority" : ${value["conf"]["setup-priority"]}
            </#if>
            <#if value["conf"]["hold-priority"]??>
              ,
              "hold-priority" : ${value["conf"]["hold-priority"]}
            </#if>
          </#list>
        </#if>

        <#if config["protection"]["enable"] == true>
          ,
          "fast-reroute" : {    
            "enable": true,
            "mode": "facility-backup"
          }
        <#else>
          ,
          "fast-reroute" : {    
            "enable": false
          }
        </#if>

        <#if extraParams.primary?size != 0 || extraParams.secondary?size != 0 >
          ,
          <#assign randomNumber1 = ((1?int) + ((.now?long / 1000) % 32))>
          <#assign randomNumber2 = ((1?int) + ((.now?long / 10000) % 32))>
          "lsp-paths":{
            "lsp-path":[
              <#if extraParams.primary?size != 0>
                <#list extraParams.primary?values as value>
                {           
                  "path-type": "primary",
                  "explicit-path-name": "${value.name}",
                  <#if default?has_content> 
                    <#if default["hop-limit"]?has_content>
                      "hop-limit": ${default["hop-limit"]},
                    <#else>
                    "hop-limit": 32,
                    </#if>
                  <#else> 
                    "hop-limit": 32,
                  </#if>

                  <#if value.includeAdminGroup? has_content>
                    "include-any-affinity-name": [
                      <#list value.includeAdminGroup?values as includeVal>
                        "${includeVal}"
                        <#if includeVal?has_next>,</#if>  
                      </#list>
                    ],
                  </#if>

                  <#if value.excludeAdminGroup? has_content>
                    "exclude-affinity-name": [
                      <#list value.excludeAdminGroup?values as excludeVal>
                        "${excludeVal}"
                        <#if excludeVal?has_next>,</#if>  
                      </#list>
                    ],
                  </#if>
                
                  "include-any": "0x0",
                  "exclude-any": "0x0"
                }
                </#list>
              </#if> 
                    
              <#if extraParams.secondary?size != 0>
                <#list extraParams.secondary?values as value>
                  <#if value.isStandby>
                  ,
                  {
                    "path-type": "hot-standby",

                    <#if value.includeAdminGroup? has_content>
                      "include-any-affinity-name": [
                        <#list value.includeAdminGroup?values as includeVal>
                          "${includeVal}"
                          <#if includeVal?has_next>,</#if>  
                        </#list>
                      ],
                    </#if>
                    <#if value.excludeAdminGroup? has_content>
                      "exclude-affinity-name": [
                        <#list value.excludeAdminGroup?values as excludeVal>
                          "${excludeVal}"
                          <#if excludeVal?has_next>,</#if>  
                        </#list>
                      ],
                    </#if>
                    "include-any": "0x0",
                    "exclude-any": "0x0",
                    "explicit-path-name":"${value.name}"
                  }
                  <#else>
                  ,
                  {
                    "path-type": "ordinary",
                    <#if value.includeAdminGroup? has_content>
                      "include-any-affinity-name": [
                        <#list value.includeAdminGroup?values as includeVal>
                          "${includeVal}"
                          <#if includeVal?has_next>,</#if>  
                        </#list>
                      ],
                    </#if>
                    <#if value.excludeAdminGroup? has_content>
                      "exclude-affinity-name": [
                        <#list value.excludeAdminGroup?values as excludeVal>
                          "${excludeVal}"
                          <#if excludeVal?has_next>,</#if>  
                        </#list>
                      ],
                    </#if>
                    "include-any": "0x0",
                    "exclude-any": "0x0",
                    "explicit-path-name":"${value.name}"
                  }
                  </#if>
                </#list>
              </#if>
            ]
          }

          <#if extraParams.secondary?size != 0>
            <#list extraParams.secondary?values as value>
              <#if value.isStandby>
                ,
                "hotstandby": {
                  <#if value.wtr? has_content>
                    "wtr": ${value.wtr},
                  </#if>
                  "revertive-mode": "revertive",
                  "path-overlap": false,
                  "dynamic-bandwidth": false
                }
              </#if>
            </#list>
          </#if>

          <#else>
            ,
            "lsp-paths":{
              "lsp-path":[
                {
                  "path-type": "primary",
                  "include-any": "0x0",
                  "exclude-any": "0x0"
                }
              ]
            }

            <#if extraParams.hopless?size != 0>
              <#list extraParams.hopless?values as value>
                <#if value["bandwidth"]??>
                  ,
                  "bandwidth": 0
                </#if>
                <#if value["setupPriority"]??>
                  ,
                  "setup-priority" : ${value["setupPriority"]}
                </#if>
                <#if value["setupPriority"]??>
                  ,
                  "hold-priority" : ${value["holdPriorioty"]}
                </#if>
              </#list>
            </#if>
          </#if>
          }
        }
    }
}