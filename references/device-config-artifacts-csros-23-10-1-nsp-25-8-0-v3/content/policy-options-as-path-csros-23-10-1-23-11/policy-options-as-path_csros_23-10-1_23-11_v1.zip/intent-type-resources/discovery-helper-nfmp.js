var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource("transform.js"), name: "transformData"});

function NfmpDiscoveryHelper() {
    const nfmpFwk = new NfmpFwk();
    const parseTarget = new ParseTarget();
    const util = new utilities();
    const transform = new transformData();
    let jsonFile = resourceProvider.getResource("meta-data/property-meta-data.json");
    jsonFile = JSON.parse(jsonFile);
    let objectFullNameJsonFile = resourceProvider.getResource("objectFullName.json");
    objectFullNameJsonFile = JSON.parse(objectFullNameJsonFile);
    let fullDeviceConfig;

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let uniqueIdentifierValues = parseTarget.getUniqueIdentifier(target);
        let fullClassName = initialPropertyName.replace("-", ".");
        let objectFullName = objectFullNameJsonFile["brownFieldObjectFullName"];
        objectFullName = this.getObjectFullName(objectFullName, uniqueIdentifierValues, neId);
        //transform objectFullName if needed
        if (neId && String(neId).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        }
        objectFullName = transform.transformObjectFullNameBrownField(objectFullName, uniqueIdentifierValues, neId);
        logger.info("objectFullName = {}", objectFullName);
        let searchPayLoad = this.constructSearchString(neId, objectFullName, fullClassName);
        let searchResponse = nfmpFwk.post("/v3/search", searchPayLoad);
        logger.info("searchResponse == {} ", JSON.stringify(searchResponse))
        let finalResponse = JSON.parse(searchResponse.response);
        logger.info("Final response of search = {}", JSON.stringify(finalResponse));
        if (!searchResponse.success || !(Object.keys(finalResponse).length !== 0 && finalResponse.constructor === Object))
        {
            throw new RuntimeException("Failed to find the object : objectFullName = " + objectFullName + ", fullClassName = " + fullClassName);
        }
        return finalResponse;
    }
    this.constructSearchString = function (neId, objectFullName, fullClassName) {
        let jsonPayLoad = {
            "fullClassName": fullClassName,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        }
        return jsonPayLoad;
    }
    this.getObjectFullName = function (objectFullName, uniqueIdentifierValues, neId) {
        objectFullName = objectFullName.replace(/\*/g, "");
        let result = objectFullName;
        let inputString = objectFullName;
        let indexCounter = 0;
        // Find the index of the first '$'
        let dollarIndex = inputString.indexOf('$');
        while (dollarIndex !== -1)
        {
            let nextHyphenIndex = inputString.indexOf('-', dollarIndex);
            let nextColonIndex = inputString.indexOf(':', dollarIndex);
            let nextHashIndex = inputString.indexOf('#', dollarIndex);
            // Find the minimum index among hyphen, colon, and end of string
            let endIndex = inputString.length;
            if (nextHyphenIndex !== -1)
            {
                endIndex = Math.min(endIndex, nextHyphenIndex);
            }
            if (nextColonIndex !== -1)
            {
                endIndex = Math.min(endIndex, nextColonIndex);
            }
            if (nextHashIndex !== -1)
            {
                endIndex = Math.min(endIndex, nextHashIndex);
            }
            // Extract the substring between '$' and the determined end index
            let substring = inputString.substring(dollarIndex + 1, endIndex);
            let replaceSubstring = inputString.substring(dollarIndex, endIndex);
            let value = uniqueIdentifierValues[indexCounter];
            indexCounter = indexCounter + 1;
            if (substring === "systemAddress")
            {
                value = neId;
                indexCounter = indexCounter - 1;
            }
            //for non satellite shelf the default shelfId = 1
            if (inputString.indexOf(":shelf-$id") !== -1 && substring === "id") {
                value = 1;
                indexCounter = indexCounter - 1;
            }
            //for Router instance id the default routingInstanceId = 1
            if (inputString.indexOf(":router-$routingInstanceId") !== -1 && substring === "routingInstanceId") {
                value = 1;
                indexCounter = indexCounter - 1;
            }
            result = result.replace(replaceSubstring, value)
            // Move the search index to the character after the last '-'
            dollarIndex = inputString.indexOf('$', dollarIndex + 1);
        }
        return result
    }
    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName, targetWithTemplate) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        logger.info("***********************************deviceConfig***********************************************");
        logger.info(JSON.stringify(deviceConfig));
        logger.info("************************************parsedDefaultTargetData***********************************");
        logger.info(JSON.stringify(parsedDefaultTargetData));
        logger.info("**************************************************END******************************************");
        if (null !== deviceConfig)
        {
            fullDeviceConfig = deviceConfig[initialPropertyName.replace("-", ".")];
            traverseProperties(targetWithTemplate, parsedDefaultTargetData[initialPropertyName], deviceConfig[initialPropertyName.replace("-", ".")]);
        }
        removeNullAndEmptyKeys(parsedDefaultTargetData);
        clearEmpties(parsedDefaultTargetData);
        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData));
        return parsedDefaultTargetData;
    }

    function traverseProperties(targetWithTemplate, parsedDefaultTargetData, deviceConfig, xpath) {
        if (deviceConfig)
        {
            let keys = Object.keys(parsedDefaultTargetData);
            for (let i = 0; i < keys.length; i++)
            {
                let targetKey = keys[i];
                let targetValue = parsedDefaultTargetData[targetKey];
                let attributeDataType = jsonFile[targetKey];
                let isMapSetList = false;
                if (attributeDataType)
                {
                    let attributeDataTypeInfo = attributeDataType["dataTypeInfo"];
                    if (attributeDataTypeInfo)
                    {
                        let type = attributeDataTypeInfo["type"]
                        if (type === 'map' || type === 'set' || type === 'list')
                        {
                            isMapSetList = true;
                        }
                    }
                }

                if (targetValue !== null && typeof targetValue === 'object' && !isMapSetList)
                {
                    let keyId = 1;
                    if (deviceConfig["children-Set"])
                    {
                        let parentXpath;
                        if (xpath)
                        {
                            parentXpath = xpath + "." + targetKey;
                        }
                        else
                        {
                            parentXpath = targetKey;
                        }

                        if (Array.isArray(targetValue))
                        {
                            let obj = JSON.parse(JSON.stringify(targetValue[0]));
                            if (deviceConfig["children-Set"])
                            {
                                let deviceChildConfig = deviceConfig["children-Set"][targetKey.replace("-", ".")];
                                if (!Array.isArray(deviceChildConfig))
                                {
                                    deviceChildConfig = [deviceChildConfig];
                                }
                                for (let index in deviceChildConfig)
                                {
                                    let objClone = JSON.parse(JSON.stringify(obj));
                                    if (deviceChildConfig[index])
                                    {
                                        if (objClone.hasOwnProperty("key-id"))
                                        {
                                            objClone["key-id"] = keyId++;
                                        }

                                        traverseProperties(targetWithTemplate, objClone, deviceChildConfig[index], parentXpath);
                                    }
                                    targetValue[index] = objClone;
                                }
                            }
                        }
                        else
                        {
                            traverseProperties(targetWithTemplate, parsedDefaultTargetData[targetKey], deviceConfig["children-Set"][targetKey.replace("-", ".")], parentXpath);
                        }
                    }
                }
                else
                {
                    let parentXpath;
                    if (xpath)
                    {
                        parentXpath = xpath + "." + targetKey;
                    }
                    else
                    {
                        parentXpath = targetKey;
                    }
                    if (typeof deviceConfig[targetKey] === 'object')
                    {
                        if (targetKey.indexOf("-") === -1)
                        {
                            let data = deviceConfig[targetKey];
                            if (Array.isArray(data))
                            {
                                if(isMapSetList)
                                {
                                    let dataType = jsonFile[targetKey]["dataTypeInfo"]["type"];
                                    if (dataType === "set" || dataType === "list")
                                    {
                                        let keyTypeValue = [];
                                        let keyType = jsonFile[targetKey]["dataTypeInfo"]["typeListProperties"]["type"];
                                        keyType = keyType.toLowerCase();
                                        keyType = transform.transformSetListKeyTypeBrownfield(parentXpath, keyType);
                                        data.forEach(obj => {
                                            let setListObj = {};
                                            setListObj[keyType] = obj;
                                            keyTypeValue.push(setListObj);
                                        });
                                        let deviceValue = keyTypeValue;
                                        deviceValue = transform.transformTargetValueBrownField(parentXpath, deviceValue, targetKey, fullDeviceConfig, targetWithTemplate);
                                        parsedDefaultTargetData[targetKey] = deviceValue;
                                    }
                                    else if (dataType === "map")
                                    {
                                        let deviceValue = data;
                                        deviceValue = transform.transformTargetValueBrownField(parentXpath, deviceValue, targetKey, fullDeviceConfig, targetWithTemplate);
                                        parsedDefaultTargetData[targetKey] = deviceValue;
                                    }
                                }
                                else
                                {
                                    let bitData = "";
                                    for (let index in data)
                                    {
                                        bitData = data[index] + " " + bitData;
                                    }
                                    let deviceValue = bitData.trim();
                                    deviceValue = transform.transformTargetValueBrownField(parentXpath, deviceValue, targetKey, fullDeviceConfig, targetWithTemplate);
                                    parsedDefaultTargetData[targetKey] = deviceValue;
                                }
                            }
                            else
                            {
                                let deviceValue = data;
                                deviceValue = transform.transformTargetValueBrownField(parentXpath, deviceValue, targetKey, fullDeviceConfig, targetWithTemplate);
                                parsedDefaultTargetData[targetKey] = deviceValue;
                            }
                        }
                    }
                    else if (targetKey !== "key-id")
                    {
                        if (deviceConfig[targetKey] && deviceConfig[targetKey].length > 0)
                        {
                            let deviceValue = deviceConfig[targetKey];
                            deviceValue = transform.transformTargetValueBrownField(parentXpath, deviceValue, targetKey, fullDeviceConfig, targetWithTemplate);
                            parsedDefaultTargetData[targetKey] = deviceValue;
                        }
                    }
                }
                logger.info("targetKey = {}, targetValue = {}, deviceConfig = {}", targetKey, JSON.stringify(targetValue), JSON.stringify(deviceConfig[targetKey]));
            }
        }
    }

    function clearEmpties(o) {
        for (let k in o)
        {
            if (!o[k] || typeof o[k] !== "object")
            {
                continue
            }
            clearEmpties(o[k]);
            if (Object.keys(o[k]).length === 0)
            {
                delete o[k];
            }
        }
    }

    function removeNullAndEmptyKeys(obj) {
        for (let key in obj)
        {
            if (obj[key] === null || (typeof obj[key] === 'object' && Object.keys(obj[key]).length === 0))
            {
                delete obj[key];
            }
            else if (typeof obj[key] === 'object')
            {
                removeNullAndEmptyKeys(obj[key]); // Recursively process nested objects
            }
        }
    }
}