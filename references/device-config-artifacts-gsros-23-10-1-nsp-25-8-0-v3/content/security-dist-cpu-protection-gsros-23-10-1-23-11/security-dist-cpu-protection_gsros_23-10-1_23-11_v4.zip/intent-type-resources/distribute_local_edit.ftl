<policy.PolicyDefinition.setDistributionModeToLocalEditOnly xmlns="xmlapi_1.0">
<deployer>immediate</deployer>
<instanceFullName>${objectFullName}</instanceFullName>
<siteIds>
<string>${nodeIp}</string>
</siteIds>
</policy.PolicyDefinition.setDistributionModeToLocalEditOnly>
