var RuntimeException = Java.type("java.lang.RuntimeException");
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});

var full_class_name = "ixrqos.NetworkIngressPolicy";
var network_ingress_policy_name = "displayedName";
var policy_fdn = "NetworkIngressPolicy7250SROS";

function NfmpNetworkIngressFwk() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var isAudit = false;
    var isLocalExists = false;
    var isGlobalExists = false;
    var isEdit = false;

    this.synchronize = function(input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        // code to handle delete
        if (input.getNetworkState().name() == "delete") {
            logger.info(LOG_PREFIX + "Calling syncDelete");
            return this.syncDelete(input, result);
        }

        var savedTopology = input.getCurrentTopology();
        logger.info(LOG_PREFIX + "Saved Topology = "+savedTopology);
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyName = parseTarget.getUniqueIdentifier(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        intentConfig = this.removeEmptyContainers("", intentConfig,"", target);
        intentConfig[network_ingress_policy_name] = policyName;
        logger.info(LOG_PREFIX + "Configuration of 7250 to be pushed = "+JSON.stringify(intentConfig));
        logger.info(LOG_PREFIX + "Target device = " + target);
        logger.info(LOG_PREFIX + "Target Qos Network = " + policyName);
        this.createOrModify(target, intentConfig);
        // code to handle sync
        return util.setSuccessResult(result, savedTopology);
    };

    this.createOrModify = function (target, intentConfig) {
        var objectFullName = policy_fdn + ":" + intentConfig[network_ingress_policy_name];
        var localPolicyFullName = "network:" + target + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, target);
        logger.info(LOG_PREFIX + "Searching if any local policy exists on NE: " + target);
        var localPolicy = util.getIfObjectExists(full_class_name, localPolicyFullName);
        logger.info(LOG_PREFIX + "localPolicy: " + JSON.stringify(localPolicy));
        var result;
        var qosNetworkIngressPayload;
        var distributeResult;

        if (localPolicy != null) {
            isLocalExists = true;
            isGlobalExists = true;
            if (localPolicy[0]["displayedName"] !== intentConfig[network_ingress_policy_name]) {
                throw new RuntimeException("Already there exists a policy on " + target +
                    " with policy name " + localPolicy[0]["displayedName"]);
            }
            qosNetworkIngressPayload = this.createQosNetworkIngressPolicyPayload(target, intentConfig, isLocalExists, null);
            result = this.modifyRequest(target, qosNetworkIngressPayload);
            if (!util.isObjectExists(full_class_name, localPolicyFullName)) {
                throw new RuntimeException('Unable to Create/Distribute Policy: ' + intentConfig[network_ingress_policy_name] +
                    ", Kindly check the intent configuration");
            }
        }
        else {
            logger.info(LOG_PREFIX + "Unable to find the local policy, Trying to fetch global policy if available");
            var globalPolicy = util.getIfObjectExists(full_class_name, objectFullName);
            if (globalPolicy != null) {
                isGlobalExists = true;
                if (globalPolicy[0]["displayedName"] !== intentConfig[network_ingress_policy_name]) {
                    logger.info(LOG_PREFIX + "createOrModify(): There exists a Network Ingress global policy in NFMP with policy name " +
                        globalPolicy[0]["displayedName"] + " on " + target);
                    logger.info(LOG_PREFIX + "createOrModify(): Updating Network Ingress global policy name to " +
                        intentConfig[network_ingress_policy_name] + "on " + target);
                    this.updateNetworkQosPolicyName(target, objectFullName, intentConfig[network_ingress_policy_name]);
                }

                distributeResult = this.distributePolicy(target, objectFullName, false);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributeResult = this.distributePolicy(target, objectFullName, true);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                logger.info(LOG_PREFIX + "checking distribution of existing global policy");
                if (!util.isObjectExists(full_class_name, localPolicyFullName)) {
                    throw new RuntimeException("Unable to Distribute existing Global Policy: " + intentConfig[network_ingress_policy_name] +
                        ", Kindly check the Global Policy configuration");
                }
                logger.info(LOG_PREFIX + "distribution of existing global policy was successful, updating with intent configuration");
                qosNetworkIngressPayload = this.createQosNetworkIngressPolicyPayload(target, intentConfig, true, null);
                result = this.modifyRequest(target, qosNetworkIngressPayload);
                if (!util.isObjectExists(full_class_name, localPolicyFullName)) {
                    throw new RuntimeException('Unable to Create/Distribute Policy: ' + intentConfig[network_ingress_policy_name] +
                        ", Kindly check the intent configuration");
                }
            }
            else {
                //distributing empty policy
                logger.info(LOG_PREFIX + "Unable to find the Global Policy, distributing empty policy and updating");
                qosNetworkIngressPayload = this.createQosNetworkIngressPolicyPayload(target, intentConfig, false, null);
                result = this.modifyRequest(target, qosNetworkIngressPayload);
                distributeResult = this.distributePolicy(target, objectFullName, false);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributeResult = this.distributePolicy(target, objectFullName, true);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                //updating the local policy with intent configuration
                qosNetworkIngressPayload = this.createQosNetworkIngressPolicyPayload(target, intentConfig, true, null);
                result = this.modifyRequest(target, qosNetworkIngressPayload);
            }
        }
        return result;
    }

    this.updateNetworkQosPolicyName = function (neId, objectFullName, policyName) {
        var payload = {};
        var configInfo = {};
        var properties = {};
        properties["displayedName"] = policyName;

        configInfo[full_class_name] = properties;
        payload["distinguishedName"] = policy_fdn;
        payload["objectFullName"] = objectFullName;
        payload["clearOnDeployFailure"] = true;
        payload["configInfo"] = configInfo;
        logger.info(LOG_PREFIX + "Payload for updating Global Policy name : " + JSON.stringify(payload));
        return this.modifyRequest(neId, payload);
    }

    this.createQosNetworkIngressPolicyPayload = function (target, intentConfig, isLocalExists, policyObject) {
        var objectFullName = policy_fdn + ":" + intentConfig[network_ingress_policy_name];
        var localPolicyFullName = "network:" + target + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, target);
        if (isAudit || isLocalExists) {
            objectFullName = localPolicyFullName;
        }

        var properties = {};
        var childProperties = {};
        properties["displayedName"] = intentConfig[network_ingress_policy_name];

        if (isLocalExists) {
            for (var attribute in intentConfig) {
                switch (attribute) {
                    case "description":
                        properties["description"] = intentConfig["description"];
                        break;
                    case "scope":
                        properties["scope"] = intentConfig["scope"];
                        break;
                    case "policer-allocation":
                        properties["policerAllocation"] = util.transformPoilcerAllocationGf(intentConfig["policer-allocation"]);
                        break;
                    case "ingress-classification-policy":
                        properties["ingClassificationPolicy"] = intentConfig["ingress-classification-policy"];
                        break;
                    case "fc":
                        this.createFcPayload(target, intentConfig, childProperties);
                        break;
                    case "policer":
                        this.createPolicerPayload(target, intentConfig, childProperties);
                        break;
                }
            }
        }
        return util.editPayload(policy_fdn, properties, childProperties, full_class_name, objectFullName);
    }

    this.createFcPayload = function (target, intentConfig, childProperties) {
        var fcArray = [];
        var fcClassName = "ixrqos.NetworkIngressForwardingClass";
        if (!Array.isArray(intentConfig["fc"])) {
            intentConfig["fc"] = [intentConfig["fc"]];
        }
        for (var idx in intentConfig["fc"]) {
            var fcConfig = intentConfig["fc"][idx];
            var fcPropObj = {};
            for (var attrib in fcConfig) {
                switch (attrib) {
                    case "fc-name":
                        fcPropObj["forwardingClass"] = fcConfig["fc-name"];
                        break;
                    case "multicast-policer":
                        fcPropObj["multicastPolicerId"] = fcConfig["multicast-policer"];
                        break;
                }
            }
            fcArray.push(fcPropObj);
        }
        childProperties[fcClassName] = fcArray;
    }

    this.createPolicerPayload = function (target, intentConfig, childProperties) {
        var policerArray = [];
        var policerClassName = "ixrqos.NetworkIngressPolicer";
        if (!Array.isArray(intentConfig["policer"])) {
            intentConfig["policer"] = [intentConfig["policer"]];
        }
        for (var idx in intentConfig["policer"]) {
            var policerConfig = intentConfig["policer"][idx];
            var policerPropObj = {};
            for (var attrib in policerConfig) {
                switch (attrib) {
                    case "policer-id":
                        policerPropObj["id"] = policerConfig["policer-id"];
                        break;
                    case "stat-mode":
                        policerPropObj["statMode"] = util.transformPolicerStatModeGf(policerConfig["stat-mode"]);
                        break;
                    case "cbs":
                        if (policerConfig["cbs"] === "auto") {
                            policerPropObj["cbs"] = -1;
                        }
                        else {
                            policerPropObj["cbs"] = policerConfig["cbs"];
                        }
                        break;
                    case "mbs":
                        if (policerConfig["mbs"] === "auto") {
                            policerPropObj["mbs"] = -1;
                        }
                        else {
                            policerPropObj["mbs"] = policerConfig["mbs"];
                        }
                        break;
                    case "adaptation-rule":
                        policerPropObj["pirAdaptation"] = policerConfig["adaptation-rule"]["pir"];
                        policerPropObj["cirAdaptation"] = policerConfig["adaptation-rule"]["cir"];
                        break;
                    case "rate":
                        if (policerConfig["rate"]["pir"] === "max") {
                            policerPropObj["pir"] = -1;
                        }
                        else {
                            policerPropObj["pir"] = policerConfig["rate"]["pir"]
                        }
                        if (policerConfig["rate"]["cir"] === "max") {
                            policerPropObj["cir"] = -1;
                        }
                        else {
                            policerPropObj["cir"] = policerConfig["rate"]["cir"];
                        }
                        break;
                }
            }
            policerArray.push(policerPropObj);
        }
        childProperties[policerClassName] = policerArray;
    }

    this.modifyRequest = function (neId, payload) {
        logger.info(LOG_PREFIX + "Sending the modify request for MDT");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
           logger.error("Error result = {}",JSON.stringify(result));
           let errorMsg = result.msg;
           if(errorMsg.indexOf("object already exists") !== -1)
           {
               logger.info("Global policy Object already exists, Re-checking the Policy existence ");
               //util.delay(2000);
               let configInfo = payload.configInfo;
               let fullClassName;
               for (let key in configInfo) {
                 if (configInfo.hasOwnProperty(key)) {
                   fullClassName = key;
                   break;
                 }
               }
               let objectFullName = payload.objectFullName;
               objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
               logger.info("fullClassName = {}",fullClassName);
               logger.info("objectFullName = {}",objectFullName);
               if (!util.isObjectExists(fullClassName, objectFullName))
               {
                   throw new RuntimeException("Global Policy Object Not Found!!!");
               }
           }
           else
           {
               throw new RuntimeException(result.msg);
           }
        }
        return result;
    }

    this.distributePolicy = function(nodeIp, objectFullName, localEdit) {
        logger.info(LOG_PREFIX + "localEdit : " + localEdit);
        var payload = {};
        if (localEdit === false) {
            payload["policy.PolicyDefinition.distributeV2"] = {};
            payload["policy.PolicyDefinition.distributeV2"]["clearOnDeployFailure"] = true;
            payload["policy.PolicyDefinition.distributeV2"]["deployer"] = "immediate";
            payload["policy.PolicyDefinition.distributeV2"]["instanceFullName"] = objectFullName;
            payload["policy.PolicyDefinition.distributeV2"]["siteIds"] = {};
            payload["policy.PolicyDefinition.distributeV2"]["siteIds"]["string"] = nodeIp;
            logger.info(LOG_PREFIX + objectFullName + ": policy distribute Payload: " + JSON.stringify(payload));
        }
        else {
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"] = {};
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["clearOnDeployFailure"] = true;
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["deployer"] = "immediate";
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["instanceFullName"] = objectFullName;
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["siteIds"] = {};
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["siteIds"]["string"] = nodeIp;
            logger.info(LOG_PREFIX + objectFullName + ": policy switch to local edit only Payload for " + nodeIp+ " : " + JSON.stringify(payload));
        }

        return nfmpFwk.post("/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true", payload);
    }

    this.syncDelete = function (input, result) {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyName = parseTarget.getUniqueIdentifier(input.getTarget());
        var objectFullName = policy_fdn + ":" + policyName;
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        var localPolicy = util.getIfObjectExists(full_class_name, localPolicyFullName);
        logger.info(LOG_PREFIX + "Deleting search response : " + JSON.stringify(localPolicy));
        if (localPolicy !== null) {
            logger.info(LOG_PREFIX + "syncDelete(): Deleting " + localPolicyFullName);
            var deleteResult = nfmpFwk.deployDelete(localPolicyFullName, "application/json");
            if (!deleteResult.success) {
                logger.info(LOG_PREFIX + "syncDelete(): Unable to Delete: " + deleteResult.msg);
                throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
            }
            result.setSuccess(true);
        }
        else {
            logger.info(LOG_PREFIX + "syncDelete(): There is no Network Ingress QoS policy with Name:" +
                policyName + " on " + neId);
            result.setSuccess(false);
        }
    }

    this.audit = function(target, config, svcTopo, adminState, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        var savedTopology = svcTopo;
        isAudit = true;
        var neId = parseTarget.getNeIdFromTarget(target);
        var policyName = parseTarget.getUniqueIdentifier(target);
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        intentConfig = this.removeEmptyContainers("",intentConfig,"",neId);
        logger.info(LOG_PREFIX + "auditing configuration = "+JSON.stringify(intentConfig));
        logger.info(LOG_PREFIX + "Target device = " + neId);
        logger.info(LOG_PREFIX + "Target Network QoS = " + policyName);
        intentConfig[network_ingress_policy_name] = policyName;
        if (intentConfig) {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else {
            throw "configuration not available in the intent";
        }
        return auditReport;
    }

    this.auditAndCompare = function (target, intentConfig, auditReport) {

        var networkIngressQosPayload = this.createQosNetworkIngressPolicyPayload(target, intentConfig, true, null);
        var result = this.auditRequest(target, networkIngressQosPayload);
        auditReport = util.reportMisaligned(target, result, auditReport);
        return auditReport;
    }

    this.auditRequest = function (target, payLoad) {
        logger.info(LOG_PREFIX + "Sending the audit request for mdt");
        logger.info(JSON.stringify(payLoad));
        var result = nfmpFwk.compare(target, JSON.stringify(payLoad), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.xml2object = function(xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: '+ json)
        return JSON.parse(json);
    }

    this.removeEmptyContainers= function(prop, intentJson, path, target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop,intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop,intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }

}
