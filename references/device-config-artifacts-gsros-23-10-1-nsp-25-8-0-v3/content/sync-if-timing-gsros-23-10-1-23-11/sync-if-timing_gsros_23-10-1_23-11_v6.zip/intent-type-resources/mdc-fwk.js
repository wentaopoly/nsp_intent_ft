/*
*
* The intent of this framework is to provide a means of communicating with the MDC mediator.
*
* All responses should be in the format of
* {
*   success: true or false
*   httpStatus: the http status of the request
*   msg: a message (usually an error in the case of a failure, or the response body payload)
* }
*
 */
function MdcFwk() {

    MDC_HOST = "nsp-mdt-mdc-mediator-svc";
    MDC_PORT = "80";

    this.configRestClient = function(url, deviceId, httpMethod) {
        log.info(null, "[MDC-FWK] Calling MDC " + MDC_HOST + ":" + MDC_PORT +
            " with url " + url + " against device " + deviceId + " as HTTP " + httpMethod);
        restClient.setIp(MDC_HOST);
        restClient.setPort(MDC_PORT);
        restClient.setProtocol("http");
    };

    this.fetch = function (deviceName, targetUrl) {
        var result = {};
        this.configRestClient(targetUrl, deviceName, "GET");
        restClient.get(targetUrl,"application/json", function (exception, httpStatus, response) {
            if (exception) {
                result = {
                    success: false,
                    httpStatus: httpStatus,
                    msg: "Couldn't connect to Manager of Device: " + deviceName + ", got response " + response
                };
            }
            if (httpStatus !== 200 && httpStatus !== 201) {
                result = {
                    success: false,
                    httpStatus: httpStatus,
                    msg: "Failed to fetch service from MDC device " + deviceName + ", got response " + response
                };
            }
            else
            {
                result = {
                    success: true,
                    httpStatus: httpStatus,
                    msg: JSON.parse(response)
                };
            }
        });
        return result;
    };

    this.deploy = function(deviceName, targetUrl, expectedJson) {
        var result = {};
        this.configRestClient(targetUrl, deviceName, "PATCH");
        log.info(null, "Deploying: deviceName: " + deviceName + ", targetUrl: " + targetUrl + ", expectedJson: " + expectedJson);
        restClient.patch(targetUrl,"application/yang-patch+json", expectedJson,"application/json", function (exception, httpStatus, response) {
            if (exception) {
                result = {
                    success: false,
                    httpStatus: httpStatus,
                    msg: "Couldn't connect to Manager of Device: " + deviceName + ", got response " + response
                };
            }
            if (httpStatus !== 200 && httpStatus !== 201) {
                result = {
                    success: false,
                    httpStatus: httpStatus,
                    msg: "Failed deployment to MDC for device " + deviceName + ", got response " + response
                };
            }
            else
            {
                result = {
                    success: true,
                    httpStatus: httpStatus,
                    msg: "Deployment to MDC for device " + deviceName + " was successful, got response " + response
                };
            }
        });

        log.info(null, "[MDC-FWK] deploy: Got result " + JSON.stringify(result));
        return result;
    };

    this.deployDelete = function(deviceName, deleteUrl){
        var result = {};
        this.configRestClient(deleteUrl, deviceName, "DELETE");
        log.info(null, "Deleting: deviceName: " + deviceName + ", deleteUrl: " + deleteUrl);
        restClient.delete(deleteUrl,"application/json", function (exception, httpStatus, response) {
            if (exception) {
                result = {
                    success: false,
                    httpStatus: httpStatus,
                    msg: "Couldn't connect to Manager of Device: " + deviceName + ", got response " + response
                };
            }
            if (httpStatus !== 200 && httpStatus !== 201 && httpStatus !== 204) {
                result = {
                    success: false,
                    httpStatus: httpStatus,
                    msg: "Failed deployment to MDC for device " + deviceName + ", got response " + response
                };
            }
            else
            {
                result = {
                    success: true,
                    httpStatus: httpStatus,
                    msg: "Deployment to MDC for device " + deviceName + " was successful, got response " + response
                };
            }
        });
        log.info(null, "[MDC-FWK] deployDelete: Got result " + JSON.stringify(result));
        return result;
    };

}
