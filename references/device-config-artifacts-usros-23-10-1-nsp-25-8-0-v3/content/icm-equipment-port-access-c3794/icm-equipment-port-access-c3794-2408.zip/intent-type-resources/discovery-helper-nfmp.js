var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"),name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'),name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"),name: "utilities"});

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();
    let isDataChannelFramed=false;

    this.getDeviceConfiguration = function(target, initialPropertyName) {

        let neId = parseTarget.getNeIdFromTarget(target);
        let portId = parseTarget.getUniqueIdentifier(target);
        let searchPayLoad = this.constructSearchString(neId, portId);
        let searchResponse = nfmpFwk.find(neId, searchPayLoad);
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                throw new RuntimeException("Failed to get Port info from nfm-p for Ne " + neId + " and Port Id: " + portId);
            if(JSON.parse(searchResponse["response"]).length === 0)
                throw new RuntimeException("There is no port with Port Id:"+portId);
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse[0];

    }

    this.extractDeviceConfig = function(defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        let portconfig = deviceConfig['properties'];
        if (null !== portconfig) {
            this.extractPortProperties(parsedDefaultTargetData, portconfig);
        }
        let childrenConfig = deviceConfig["children"];
        if (null !== childrenConfig && childrenConfig.length !== 0) {

            let defaultDataChannelData = parsedDefaultTargetData['port']['dataChannel'];
            if (defaultDataChannelData !== null && defaultDataChannelData.length !== 0) {
                let dataChannelExtractedConfig = this.extractDataChannelProperties(defaultDataChannelData, childrenConfig);
                parsedDefaultTargetData['port']['dataChannel']=dataChannelExtractedConfig;
            }
        }
        return parsedDefaultTargetData;
    }

    this.extractDataChannelProperties = function(defaultDataChannelData, childrenConfig) {
        let mappings = modelDeviceMapping.getMapping("dataChannel");
        let isDataChannelInConfig = false;
        for (let i = 0; i < childrenConfig.length; i++) {
            let childConfig = childrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass ==='tdmequipment.DataChannel') {
                isDataChannelInConfig = true;
                this.traverseAndUpdateDataChannelConfig('port.dataChannel', defaultDataChannelData, childConfig['properties'], mappings);
                this.extractDataChannelSpecificsProperties(defaultDataChannelData,childConfig["children"]);
                let ds0ChannelGroupData = defaultDataChannelData['ds0Channel-group'];
                if(ds0ChannelGroupData !== null && ds0ChannelGroupData.length !== 0) {
                    let ds0ChannelGroupArray = this.extractDs0ChannelGroupProperties(ds0ChannelGroupData,childConfig["children"]);
                    defaultDataChannelData['ds0Channel-group'] = ds0ChannelGroupArray;
                }
            }
        }
        if(!isDataChannelInConfig){
            return undefined;
        }

        return defaultDataChannelData;

    }

    this.extractDataChannelSpecificsProperties = function(defaultdataChannelSpecificsData, dataChannelChildrenConfig) {
        let mappings = modelDeviceMapping.getMapping("dataChannelSpecifics");
        for (let i = 0; i < dataChannelChildrenConfig.length; i++) {
            let childConfig = dataChannelChildrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass ==='tdmequipment.DataChannelSpecifics') {
                this.traverseAndUpdateDataChannelSpecificsConfig('port.dataChannel', defaultdataChannelSpecificsData, childConfig['properties'], mappings);
                if(childConfig['properties']["dataFraming"] == "framed" ){
                    isDataChannelFramed=true;
                }
            }
        }
        return defaultdataChannelSpecificsData;
    }

    this.extractDs0ChannelGroupProperties = function(defaultDs0ChannelGroupData,dataChannelChildrenConfig) {
        let ds0ChannelGroupArray =[];
        let ds0ChannelGroupDefaults = defaultDs0ChannelGroupData[0];
        let mappings = modelDeviceMapping.getMapping("ds0Channel-group");

        for (let i = 0; i < dataChannelChildrenConfig.length; i++) {
            let childConfig = dataChannelChildrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass ==='tdmequipment.DS0ChannelGroup') {
                let ds0ChannelGroupData = JSON.parse(JSON.stringify(ds0ChannelGroupDefaults));
                this.traverseAndUpdateDS0ChannelGroupConfig('port.dataChannel.ds0Channel-group', ds0ChannelGroupData, childConfig['properties'], mappings);
                this.extractDS0ChannelGroupSpecificsProperties(ds0ChannelGroupData,childConfig["children"]);
                ds0ChannelGroupArray.push(ds0ChannelGroupData)
            }
        }

        return ds0ChannelGroupArray;
    }

    this.extractDS0ChannelGroupSpecificsProperties = function(defaultDs0ChannelGroupSpecificsData,ds0ChannelGroupChildrenConfig){
        let mappings = modelDeviceMapping.getMapping("ds0ChannelGroupSpecifics");
        for (let i = 0; i < ds0ChannelGroupChildrenConfig.length; i++) {
            let childConfig = ds0ChannelGroupChildrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass ==='tdmequipment.DS0ChannelGroupSpecifics') {
                this.traverseAndUpdateDS0ChannelGroupSpecificsConfig('port.dataChannel.ds0Channel-group', defaultDs0ChannelGroupSpecificsData, childConfig['properties'], mappings);
            }
        }

        return defaultDs0ChannelGroupSpecificsData;
    }

    this.extractPortProperties = function(defaultTargetData, portConfig) {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++) {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object') {
                let mappings = modelDeviceMapping.getMapping("port");
                this.traverseAndUpdatePortConfig(targetKey, targetObj, portConfig, mappings);
            }
        }
        return defaultTargetData;
    }

    this.traverseAndUpdatePortConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.dataChannel") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdatePortConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.traverseAndUpdateDataChannelConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.dataChannel.framing" && mappedKey !== "port.dataChannel.ds0Channel-group") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateDataChannelConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.traverseAndUpdateDataChannelSpecificsConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];

            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.dataChannel.admin-state" && mappedKey !== "port.dataChannel.ds0Channel-group") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateDataChannelSpecificsConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.traverseAndUpdateDS0ChannelGroupConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.dataChannel.ds0Channel-group.timeslots") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateDS0ChannelGroupConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.traverseAndUpdateDS0ChannelGroupSpecificsConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.dataChannel.ds0Channel-group.channel-group-id" && mappedKey !== "port.dataChannel.ds0Channel-group.admin-state") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateDS0ChannelGroupSpecificsConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.getAndUpdateFromDeviceConfig = function(mappings, mappedKey, targetKey, targetObj, parsedDeviceConfig) {
        // Get the key from mapping against targetKey
        // If the mapping key is not undefined, Get the value from deviceKey
        // if the value from deviceConfig against that mapping key is not n
        let nfmpKey = mappings[mappedKey];
        let deviceValue = parsedDeviceConfig[nfmpKey];

        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);
    }

    this.transformDeviceValue = function(mappedKey, deviceValue) {
        if (deviceValue !== null) {
            switch (mappedKey) {
                case "port.admin-state":
                case "port.dataChannel.admin-state":
                case "port.dataChannel.ds0Channel-group.admin-state":
                    deviceValue = this.transformAdminStateValue(deviceValue);
                    break;
                case "port.dataChannel.ds0Channel-group.timeslots":
                    deviceValue = this.transformTimeSlotsValue(deviceValue);
                    break;
            }
            return deviceValue;
        }
    }

    this.constructSearchString = function(neId, portId) {
        let portFullName =  util.getBaseFdnForPort(neId, portId);
        let filterExpression = "siteId='" + neId + "' AND fullName='" + portFullName + "'";
        let jsonPayLoad = {
            "fullClassName": "equipment.PhysicalPort",
            "filter": {
                "filterExpression": filterExpression
            }
        };

        return jsonPayLoad;
    }

    this.transformAdminStateValue = function(deviceValue) {
        switch (deviceValue) {
            case "portInService":
                return "Up";
            case "portOutOfService":
                return 'Down';
        }
    }

    this.transformTimeSlotsValue = function(deviceValue) {
        let timeSlotValue = "";
        if(!Array.isArray(deviceValue)){
            deviceValue = [deviceValue];
        }
        for(let index in deviceValue){
            timeSlotValue=timeSlotValue+deviceValue[index]+" ";
        }
        timeSlotValue = timeSlotValue.replace(/\s*$/,'');
        if(!isDataChannelFramed && timeSlotValue == "ts32 ts31 ts30 ts29 ts28 ts27 ts26 ts25 ts24 ts23 ts22 ts21 ts20 ts19 ts18 ts17 ts16 ts15 ts14 ts13 ts12 ts11 ts10 ts9 ts8 ts7 ts6 ts5 ts4 ts3 ts2 ts1"){
            timeSlotValue = "ts12 ts11 ts10 ts9 ts8 ts7 ts6 ts5 ts4 ts3 ts2 ts1";
        }
        return timeSlotValue;
    }

}
