function NfmpSuggest() {

  this.getData = function (searchObjectJson, className, type) {
        var nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    if(!value[type].startsWith("_tmnx_"))
                    {
                        ret.push(value[type]);
                    }
                })
            }
        }

        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

    this.getDisplayedName = function (neId) {
        var className = "sitesec.TlsClientProfile";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "displayedName");
    }

    this.getGroupList = function (neId) {
        var className = "sitesec.TlsClientGroupList";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "displayedName");
    }

    this.getCertificateProfile = function (neId) {
        var className = "sitesec.TlsCertificateProfile";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "displayedName");
    }

    this.getSignatureList = function (neId) {
        var className = "sitesec.TlsClientSignatureList";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "displayedName");
    }

    this.getCipherList = function (neId) {
        var className = "sitesec.TlsClientCipherList";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "displayedName");
    }

    this.getTrustAnchorProfile = function (neId) {
        var className = "sitesec.TlsTrustAnchorProfile";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "displayedName");
    }
}
