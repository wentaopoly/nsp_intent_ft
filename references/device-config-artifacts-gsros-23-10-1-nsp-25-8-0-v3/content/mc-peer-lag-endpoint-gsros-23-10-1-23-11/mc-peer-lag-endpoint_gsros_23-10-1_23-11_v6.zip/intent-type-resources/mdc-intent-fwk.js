var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk'});
load({script: resourceProvider.getResource('traverse-fwk.js'), name: 'TraverseFwk'});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
load({script: resourceProvider.getResource('intentConfigValueReplacer.js'), name: 'IntentConfigValueReplacer'});
load({script: resourceProvider.getResource('mc-lag-converter.js'), name: 'McLagConverter'});

function MdcIntentFwk() {

    var intentDeviationObj = new IntentDeviceDeviation();
    var intentConfigValueReplacerObj = new IntentConfigValueReplacer();

    this.restResponseHandler = function (exception, httpStatus, response) {
        logger.info("[IntentMgr] REST response : " + response);
        logger.info("[IntentMgr] REST httpStatus : " + httpStatus);
        if (exception) {
            throw new RuntimeException("Couldn't connect to device proxy for ; Response: " + response);
        }

        if (httpStatus !== 200 && httpStatus !== 201) {
            throw new RuntimeException("Failed to access device  using MDC; Response: " + response);
        }

        restResponse = JSON.parse(response);
    };

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, topologyInfo) {

        var target = input.getTarget();
        var targetAttrs = target.split('#');
        var endPointA = targetAttrs[2];
        var endPointB = targetAttrs[4];

        if (target !== "0.0.0.0") {

            var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];

            var mclagConverter = new McLagConverter()
            var convertedConfig = mclagConverter.convertIntentConfigToDeviceSpecific(target, intentConfig, false);

            var traverseFwk = new TraverseFwk();

            if (input.getNetworkState().name() == "delete") {

                traverseFwk.resetTheVariables();
                var requests = [];
                var deleteObj = {};
                deleteObj["operation"] = "delete";
                deleteObj["edit-id"] = "edit-" + new Date().getTime();
                deleteObj["target"] = "nokia-conf:/configure/redundancy/multi-chassis/peer=" + targetAttrs[5];
                requests.push(deleteObj)
                result = traverseFwk.syncRequest(endPointA, requests, result, topologyInfo.getSavedTopologyA());
                result.setTopology(null);
                if (result['success']) {
                    requests = [];
                    deleteObj = {};
                    deleteObj["operation"] = "delete";
                    deleteObj["edit-id"] = "edit-" + new Date().getTime();
                    deleteObj["target"] = "nokia-conf:/configure/redundancy/multi-chassis/peer=" + targetAttrs[3];
                    requests.push(deleteObj)
                    result = traverseFwk.syncRequest(endPointB, requests, result, topologyInfo.getSavedTopologyB());
                    result.setTopology(null);
                }
                return result;
            }

            var topologyA = this.deployInformation(convertedConfig['endpointA'], result, endPointA, traverseFwk, topologyInfo.getSavedTopologyA(), parentXpath, initialPropertyName);
            topologyInfo.setSavedTopologyA(topologyA);

            if (result['success']) {
                var topologyB = this.deployInformation(convertedConfig['endpointB'], result, endPointB, traverseFwk, topologyInfo.getSavedTopologyB(), parentXpath, initialPropertyName)
                topologyInfo.setSavedTopologyB(topologyB);
            }

        }

        return result;
    }

    this.deployInformation = function (intentConfig, result, target, traverseFwk, savedTopology, parentXpath, initialPropertyName) {
        //Removing deviations info
        intentConfig = intentDeviationObj.removeIntentConfig(intentConfig, target);
        //Replace Values
        intentConfig = intentConfigValueReplacerObj.replaceConfigValue(intentConfig);
        if (intentConfig) {
            savedTopology = traverseFwk.traverse(target, intentConfig, savedTopology, null, parentXpath, initialPropertyName);

            //sorting delete array
            var deleteRequests = traverseFwk.getDeleteRequests();
            deleteRequests.sort(function (a, b) {
                return b["target"].length - a["target"].length;
            });

            // concating createrequests and deleterequests
            var createRequests = traverseFwk.getCreateRequests();
            var requests;
            if (deleteRequests && createRequests) {
                //requests = createRequests.concat(deleteRequests);
                requests = deleteRequests.concat(createRequests);
            }
            if (requests) {
                result = traverseFwk.syncRequest(target, requests, result, savedTopology);
            }

        } else {

            result = traverseFwk.deleteAllFromTopology(savedTopology, target, result);
        }

        traverseFwk.resetTheVariables();

        return savedTopology;
    }

    this.audit = function (target, config, svcTopo, adminState, report, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {

        var targetAttrs = target.split('#');
        var endPointA = targetAttrs[2];
        var endPointB = targetAttrs[4];

        var currentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        var traverseFwk = new TraverseFwk();

        var mclagConverter = new McLagConverter()
        var convertedConfig = mclagConverter.convertIntentConfigToDeviceSpecific(target, currentConfig, true);

        if (endPointA !== "0.0.0.0") {
            //Ignoring deviations compare
            var endPointAConfig = intentDeviationObj.removeIntentConfig(convertedConfig['endpointA'], endPointA);
            //Replace Values
            endPointAConfig = intentConfigValueReplacerObj.replaceConfigValue(endPointAConfig);
            svcTopo = traverseFwk.traverse(endPointA, endPointAConfig, svcTopo, report, parentXpath, initialPropertyName);
            // reseting the variables
            traverseFwk.resetTheVariables();
        }

        if (endPointB !== "0.0.0.0") {
            //Ignoring deviations compare
            var endPointBConfig = intentDeviationObj.removeIntentConfig(convertedConfig['endpointB'], endPointB);
            //Replace Values
            endPointBConfig = intentConfigValueReplacerObj.replaceConfigValue(endPointBConfig);
            svcTopo = traverseFwk.traverse(endPointB, endPointBConfig, svcTopo, report, parentXpath, initialPropertyName);
            // reseting the variables
            traverseFwk.resetTheVariables();
        }

        return report;

    }

    this.getNodes = function (context) {
        var returnVal = []
        var url = "/restconf/meta/api/v1/nes"
        try {
            var managerList = []
            var managers = mds.getAllManagersOfType("REST");
            managers.forEach(function (manager) {
                if (mds.getManagerByName(manager).getConnectivityState().toString() === 'CONNECTED') {
                    managerList.push(manager)
                }
            })

            var devices = mds.getAllManagedDevicesFrom(managerList);

            devices.forEach(function (device) {
                returnVal.push(device.getName());
            });

            return returnVal;
        } catch (e) {
            logger.info("Exception *******************  : " + e);
            return {
                "Device Not Found": "Device Not Found"
            }
        }
    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }
}
