
function ModelDeviceMapping() {
    this.getMapping = function(type){
        switch (type) {
            case "metwork-ingress":
                return this.getNetIngressNonChildQosMapping();
            case "network-ingress.fc":
                return this.getNetIngressFcMapping();
            case "network-ingress.policer":
                return this.getNetIngressPolicerMapping();
            default:
                logger.info(LOG_PREFIX + "getMapping() mapping not specified - " + type);
        }
    }

    this.getNetIngressNonChildQosMapping = function () {
        var mapping = {};
        mapping["network-ingress.description"] = "description";
        mapping["network-ingress.scope"] = "scope";
        mapping["network-ingress.policer-allocation"] = "policerAllocation";
        mapping["network-ingress.ingress-classification-policy"] = "ingClassificationPolicy";
        return mapping;
    }

    this.getNetIngressFcMapping = function () {
        var mapping = {};
        mapping["network-ingress.fc.fc-name"] = "forwardingClass";
        mapping["network-ingress.fc.multicast-policer"] = "multicastPolicerId";
        return mapping;
    }

    this.getNetIngressPolicerMapping = function () {
        var mapping = {};
        mapping["network-ingress.policer.policer-id"] = "id";
        mapping["network-ingress.policer.stat-mode"] = "statMode";
        mapping["network-ingress.policer.cbs"] = "cbs";
        mapping["network-ingress.policer.mbs"] = "mbs";
        mapping["network-ingress.policer.adaptation-rule.pir"] = "pirAdaptation";
        mapping["network-ingress.policer.adaptation-rule.cir"] = "cirAdaptation";
        mapping["network-ingress.policer.rate.pir"] = "pir";
        mapping["network-ingress.policer.rate.cir"] = "cir";
        return mapping;
    }
}
