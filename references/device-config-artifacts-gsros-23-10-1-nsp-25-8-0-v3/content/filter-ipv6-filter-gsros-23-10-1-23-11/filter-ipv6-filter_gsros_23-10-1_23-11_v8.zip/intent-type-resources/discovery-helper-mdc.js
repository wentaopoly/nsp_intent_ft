var RuntimeException = Java.type('java.lang.RuntimeException');

load({
    script: resourceProvider.getResource('mdc-fwk.js'),
    name: 'MdcFwk'
});

load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

load({
    script: resourceProvider.getResource("util-fwk.js"),
    name: "utilities"
});


function MdcDiscoveryHelper() {
    let mdcFwk = new MdcFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    let brownFieldMdcMetadata = JSON.parse(resourceProvider.getResource("meta-data.json"));

    this.getDeviceConfiguration = function (targetWithTemplate, deviceYangModuleName, parentXpath, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(targetWithTemplate);
        let filterName = util.getIpFilterName(targetWithTemplate);
        let filterId = util.getIpFilterId(targetWithTemplate);
        let url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/filter/" + initialPropertyName + "=" + filterName;
        let getResult = mdcFwk.fetch(neId, url);
        let configFromDevice = getResult.msg["nokia-conf:" + initialPropertyName];
        if (configFromDevice == undefined) {
            throw new RuntimeException("cannot get configuration from device");
        }
        if (Array.isArray(configFromDevice)) {
            let lFilterId = configFromDevice[0]['filter-id'];
            if (lFilterId) {
                if (parseInt(lFilterId) !== parseInt(filterId)) throw "There is no ipv6-filter with Name:" + filterName + " and Id:" + filterId;
                return configFromDevice[0];
            } else throw "There is no ip-filter with Name:" + filterName + " and Id:" + filterId;

        } else {
            throw "cannot get configuration from device"
        }
    }

    this.extractDeviceConfig = function (targetData, deviceConfig, deviceYangModuleName, parentXpath, initialPropertyName) {
        let parsedTargetData = JSON.parse(targetData);
        let config = parsedTargetData[initialPropertyName];
        let yangXPath = "";
        if (parentXpath == "") {
            yangXPath = deviceYangModuleName + ":/" + initialPropertyName;
        } else {
            yangXPath = deviceYangModuleName + ":/" + parentXpath.split("=")[0] + "/" + initialPropertyName;
        }

        let mergedTargetData = this.traverse(config, deviceConfig, yangXPath);
        parsedTargetData[initialPropertyName] = mergedTargetData;
        return parsedTargetData;
    }

    this.traverse = function (targetData, deviceConfig, yangXPath) {
        if (targetData !== null && targetData !== undefined) {
            let keys = Object.keys(targetData);
            for (let i = 0; i < keys.length; i++) {
                let propertyName = keys[i];
                let deviceValue = deviceConfig[propertyName];
                let lYangXPath = yangXPath + "/" + propertyName;
                if (deviceValue == undefined || deviceValue == null) {
                    if (brownFieldMdcMetadata[lYangXPath]) {
                        let metaDataAttr = brownFieldMdcMetadata[lYangXPath];
                        if (metaDataAttr["name"]) {
                            deviceValue = deviceConfig[metaDataAttr["name"]]
                        }
                    }
                }
                logger.info("MdcDiscoveryHelper::traverse::lYangXPath = " + lYangXPath);
                if (deviceValue != undefined && Array.isArray(deviceValue)) {
                    logger.info("MdcDiscoveryHelper::traverse::lYangXPath device value is List")
                    targetData[propertyName] = this.ArrayTraverse(targetData[propertyName], deviceValue, [], lYangXPath);
                } else if (deviceValue != undefined && typeof deviceValue === 'object') {
                    logger.info("MdcDiscoveryHelper::traverse::lYangXPath device value is Container")
                    targetData[propertyName] = this.containerTraverse(targetData[propertyName], deviceValue, {}, lYangXPath);
                } else {
                    logger.info("MdcDiscoveryHelper::traverse::lYangXPath device value is Leaf")
                    targetData[propertyName] = deviceValue
                }
            }

        }
        return targetData;
    }

    this.ArrayTraverse = function (arrayTargetData, arrayDeviceConfigData, arrayData, yangXPath) {
        for (let i = 0; i < arrayDeviceConfigData.length; i++) {
            let arrayObject = {};
            let keys = Object.keys(arrayTargetData[0]);
            for (let j = 0; j < keys.length; j++) {
                let propertyName = keys[j];
                let deviceValue = arrayDeviceConfigData[i][propertyName];
                let lYangXPath = yangXPath + "/" + propertyName;
                if (deviceValue == undefined || deviceValue == null) {
                    if (brownFieldMdcMetadata[lYangXPath]) {
                        let metaDataAttr = brownFieldMdcMetadata[lYangXPath];
                        if (metaDataAttr["name"]) {
                            deviceValue = arrayDeviceConfigData[i][metaDataAttr["name"]]
                        }
                    }
                }
                logger.info("MdcDiscoveryHelper::ArrayTraverse::lYangXPath = " + lYangXPath)
                if (deviceValue != null && deviceValue != undefined && Array.isArray(deviceValue)) {
                    logger.info("MdcDiscoveryHelper::ArrayTraverse::lYangXPath device value is List")
                    arrayObject[propertyName] = this.ArrayTraverse(arrayTargetData[0][propertyName], deviceValue, [], lYangXPath);
                } else if (deviceValue != null && deviceValue != undefined && typeof deviceValue === 'object') {
                    logger.info("MdcDiscoveryHelper::ArrayTraverse::lYangXPath device value is container")
                    arrayObject[propertyName] = this.containerTraverse(arrayTargetData[0][propertyName], deviceValue, {}, lYangXPath);

                } else {
                    logger.info("MdcDiscoveryHelper::ArrayTraverse::lYangXPath device value is leaf")
                    arrayObject[propertyName] = deviceValue;
                }
            }
            arrayData.push(arrayObject);
        }

        return arrayData;
    }

    this.containerTraverse = function (containerTargetData, containerDeviceConfigData, targetContainer, yangXPath) {
        let keys = Object.keys(containerTargetData);
        for (let i = 0; i < keys.length; i++) {
            let propertyName = keys[i];
            let deviceValue = containerDeviceConfigData[propertyName];

            let lYangXPath = yangXPath + "/" + propertyName;
            if (deviceValue == undefined || deviceValue == null) {
                if (brownFieldMdcMetadata[lYangXPath]) {
                    let metaDataAttr = brownFieldMdcMetadata[lYangXPath];
                    if (metaDataAttr["name"]) {
                        deviceValue = containerDeviceConfigData[metaDataAttr["name"]]
                    }
                }
            }
            logger.info("MdcDiscoveryHelper::containerTraverse::lYangXPath = " + lYangXPath);
            if (deviceValue != null && deviceValue != undefined && Array.isArray(deviceValue)) {
                if (this.isAtrributeLeafList(deviceValue)) {
                    logger.info("MdcDiscoveryHelper::containerTraverse::lYangXPath device value is leaf-list");
                    targetContainer[propertyName] = deviceValue;
                } else {
                    logger.info("MdcDiscoveryHelper::containerTraverse::lYangXPath device value is list");
                    targetContainer[propertyName] = this.ArrayTraverse(containerTargetData[propertyName], deviceValue, [], lYangXPath);
                }

            } else if (deviceValue != null && deviceValue != undefined && typeof deviceValue === 'object') {
                logger.info("MdcDiscoveryHelper::containerTraverse::lYangXPath device value is container");
                targetContainer[propertyName] = this.containerTraverse(containerTargetData[propertyName], deviceValue, {}, lYangXPath);
            } else {
                logger.info("MdcDiscoveryHelper::containerTraverse::lYangXPath device value is leaf");
                targetContainer[propertyName] = deviceValue;
            }
        }
        return targetContainer;
    }

    this.isAtrributeLeafList = function (leaflistData) {
        let isLeaflist = true;
        for (let i = 0; i < leaflistData.length; i++) {
            if (leaflistData[i] != null && typeof leaflistData[i] == 'object') {
                isLeaflist = false;
                break;
            }
        }
        return isLeaflist;
    }

    this.cipherSpecialCharacterInKey = function (key) {
        return key.replaceAll("/", "%2F").replaceAll(":", "%3A");
    }

    this.deviceValueConversionMethod = function (valueInfo) {
        if (typeof valueInfo == "string") {
            let values = valueInfo.split(":");
            if (values.length == 2) {
                return values[1];
            }
            return valueInfo;
        }
        return valueInfo;
    }
}
