var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpPort() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    let nfmpFwk = new NfmpFwk();
    var savedTopology;

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        // setting up topology
        if (input.getNetworkState().name() == "delete")
        {
            result.setSuccess(true);
            return result;
        }

        savedTopology = input.getCurrentTopology();
        var parseTarget = new ParseTarget();
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target port = " + intentConfig[uniqueIdentifier]);
        this.createOrModify(target, intentConfig[uniqueIdentifier], intentConfig);
        result.setTopology(savedTopology);
        if (savedTopology)
        {
            result.getTopology().setXtraInfo(savedTopology.getXtraInfo());
        }
        return util.setSuccessResult(result, savedTopology);
    }


    this.audit = function (target, config, svcTopo, adminState, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        var savedTopology = svcTopo;
        var parseTarget = new ParseTarget();
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        var target = parseTarget.getNeIdFromTarget(target);
        intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target port = " + intentConfig[uniqueIdentifier]);
        if (intentConfig)
        {
            this.auditAndCompare(target, intentConfig[uniqueIdentifier], intentConfig, auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }

    }


    this.createOrModify = function (target, portId, intentConfig) {

        // port level attributes
        var portLevelPayload = this.portLevel(target, portId, intentConfig,"sync", false);

        var result = this.modifyRequest(target, portLevelPayload);

        //on mode change - mtuValue resets to default, needs it to be redeploy
        if(intentConfig["ethernet"] && intentConfig["ethernet"]["mtu"]){
            portLevelPayload = this.portLevel(target, portId, intentConfig,"sync", true);
            result = this.modifyRequest(target, portLevelPayload);
        }

        // ethernet level attributes
        if (intentConfig["ethernet"])
        {
            var ethernetLevelPayload = this.ethernetLevel(target, portId, intentConfig);

            result = this.modifyRequest(target, ethernetLevelPayload);

            if (intentConfig["ethernet"]["lldp"])
            {
                this.ethernetPortLldp(target, portId, intentConfig, "sync", null);
            }
        }
        return result;
    }

    this.auditAndCompare = function (target, portId, intentConfig, auditReport) {

        // port level attributes
        var portLevelPayload = this.portLevel(target, portId, intentConfig, "audit", false);

        var result = this.auditRequest(target, portLevelPayload);
        // adding miss aligned attributes
        auditReport = util.reportMisaligned(target, result, auditReport);
        // ethernet level attributes
        if (intentConfig["ethernet"])
        {
            var ethernetLevelPayload = this.ethernetLevel(target, portId, intentConfig);
            result = this.auditRequest(target, ethernetLevelPayload);
            // adding miss aligned attributes
            auditReport = util.reportMisaligned(target, result, auditReport);
            if (intentConfig["ethernet"]["lldp"])
            {
                this.ethernetPortLldp(target, portId, intentConfig, "audit", auditReport);
            }
        }
        return auditReport;
    }

    this.portLevel = function (target, portId, intentConfig, actionType, redeployMtu) {

        var properties = {};

        // full class name for port and ethernet are same
        var fullClassName = "equipment.PhysicalPort";
        // portlevel and ethernet level attributes have the same fdn
        var portLevelFdn = util.getBaseFdnForPort(target, portId);
        // objectFullName is same as fdn for port level
        var objectFullName = portLevelFdn;
        if(actionType == "sync" && redeployMtu){
            properties["mtuValue"] = intentConfig["ethernet"]["mtu"];
        }
        else
        {
            // adminstate
            (intentConfig["admin-state"] == "enable") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";

            properties["description"] = intentConfig["description"];

            if (intentConfig["ethernet"])
            {
                properties = this.ethernetPortLevel(target, fullClassName, portLevelFdn, intentConfig, properties);
            }
        }

        var portLevelPayload = util.editPayload(portLevelFdn, properties, fullClassName, objectFullName);
        return portLevelPayload;
    }


    this.ethernetLevel = function (target, portId, intentConfig) {
        if (savedTopology == null)
        {
            logger.info("Creating topology to save CRC-monitor values");
            savedTopology = topologyFactory.createServiceTopology();
        }
        var properties = {};
        var intentEthernet = intentConfig["ethernet"];
        var fullClassName = "ethernetequipment.EthernetPortSpecifics";
        var ethernetLevelFdn = util.getBaseFdnForPort(target, portId);
        // objectFullName is same as fdn for port level
        var objectFullName = ethernetLevelFdn + ":etherPort";

        if (intentEthernet["autonegotiate"] !== undefined)
        {
            properties["autoNegotiate"] = (intentEthernet["autonegotiate"]).toString();
        }
        if (intentEthernet["dot1q-etype"])
            properties["dot1qEtype"] = parseInt(intentEthernet["dot1q-etype"]);
        if (intentEthernet["qinq-etype"])
            properties["qinqEtype"] = parseInt(intentEthernet["qinq-etype"]);
        if (intentEthernet["pbb-etype"])
            properties["pbbEtype"] = parseInt(intentEthernet["pbb-etype"]);
        if (intentEthernet["down-when-looped"])
        {
            properties["downWhenLooped"] = (intentEthernet["down-when-looped"]["admin-state"] == "enable") ? "enabled" : "disabled";
            if (properties["downWhenLooped"] == "enabled")
            {
                properties["keepAliveInterval"] = intentEthernet["down-when-looped"]["keep-alive"];
                properties["retryTimeout"] = intentEthernet["down-when-looped"]["retry-timeout"];
            }
            if (intentEthernet["down-when-looped"]["use-broadcast-address"] !== undefined)
            {
                properties["useBroadCastAddress"] = (intentEthernet["down-when-looped"]["use-broadcast-address"]).toString();
            }
            else
            {
                properties["useBroadCastAddress"] = "false";
            }
        }
        else
        {
            properties["useBroadCastAddress"] = "false";
        }

        if (intentEthernet["ssm"])
        {
            (intentEthernet["ssm"]["admin-state"] == "enable") ? properties["ssm"] = "true" : properties["ssm"] = "false";
            properties["codeType"] = intentEthernet["ssm"]["code-type"];
            if (intentEthernet["ssm"]["tx-dus"] !== undefined)
            {
                properties["txDus"] = intentEthernet["ssm"]["tx-dus"].toString();
            }
            else
            {
                properties["txDus"] = "false";
            }
            if (intentEthernet["ssm"]["esmc-tunnel"] !== undefined)
            {
                properties["esmcTunnel"] = intentEthernet["ssm"]["esmc-tunnel"].toString();
            }
            else
            {
                properties["esmcTunnel"] = "false";
            }
        }
        else
        {
            properties["txDus"] = "false";
            properties["esmcTunnel"] = "false";
        }
        //crc-monitor

        /* properties["sdThreshold"] = 0;
         properties["sdThresholdMultiplier"] = 1;
         properties["sfThreshold"] = 0;
         properties["sfThresholdMultiplier"] = 1;*/

        if (intentEthernet["crc-monitor"])
        {
            properties["windowSize"] = intentEthernet["crc-monitor"]["window-size"];
            if (intentEthernet["crc-monitor"]["signal-degrade"])
            {
                if (intentEthernet["crc-monitor"]["signal-degrade"]["threshold"])
                {
                    properties["sdThreshold"] = intentEthernet["crc-monitor"]["signal-degrade"]["threshold"];
                    this.removetoplogyXtraInfo("sdThreshold");
                    savedTopology.addXtraInfo(topologyFactory.createTopologyXtraInfoFrom("sdThreshold", properties["sdThreshold"]));
                }
                else
                {
                    if (savedTopology && savedTopology.getXtraInfo() !== null && !savedTopology.getXtraInfo().isEmpty())
                    {
                        this.setDefaultCrcValue("sdThreshold", properties, 0);
                    }
                }
                if (intentEthernet["crc-monitor"]["signal-degrade"]["multiplier"])
                {
                    properties["sdThresholdMultiplier"] = intentEthernet["crc-monitor"]["signal-degrade"]["multiplier"];
                    this.removetoplogyXtraInfo("sdThresholdMultiplier");
                    savedTopology.addXtraInfo(topologyFactory.createTopologyXtraInfoFrom("sdThresholdMultiplier", properties["sdThresholdMultiplier"]));
                }
                else
                {
                    if (savedTopology && savedTopology.getXtraInfo() !== null && !savedTopology.getXtraInfo().isEmpty())
                    {
                        this.setDefaultCrcValue("sdThresholdMultiplier", properties, 1);
                    }
                }
            }
            else
            {
                if (savedTopology && savedTopology.getXtraInfo() !== null && !savedTopology.getXtraInfo().isEmpty())
                {
                    this.setDefaultCrcValue("sdThreshold", properties, 0);
                    this.setDefaultCrcValue("sdThresholdMultiplier", properties, 1);

                }
            }
            if (intentEthernet["crc-monitor"]["signal-failure"])
            {
                if (intentEthernet["crc-monitor"]["signal-failure"]["threshold"])
                {
                    properties["sfThreshold"] = intentEthernet["crc-monitor"]["signal-failure"]["threshold"];
                    this.removetoplogyXtraInfo("sfThreshold");
                    savedTopology.addXtraInfo(topologyFactory.createTopologyXtraInfoFrom("sfThreshold", properties["sfThreshold"]));
                }
                else
                {
                    if (savedTopology && savedTopology.getXtraInfo() !== null && !savedTopology.getXtraInfo().isEmpty())
                    {
                        this.setDefaultCrcValue("sfThreshold", properties, 0);
                    }
                }
                if (intentEthernet["crc-monitor"]["signal-failure"]["multiplier"])
                {
                    properties["sfThresholdMultiplier"] = intentEthernet["crc-monitor"]["signal-failure"]["multiplier"];
                    this.removetoplogyXtraInfo("sfThresholdMultiplier");
                    savedTopology.addXtraInfo(topologyFactory.createTopologyXtraInfoFrom("sfThresholdMultiplier", properties["sfThresholdMultiplier"]));
                }
                else
                {
                    if (savedTopology && savedTopology.getXtraInfo() !== null && !savedTopology.getXtraInfo().isEmpty())
                    {
                        this.setDefaultCrcValue("sfThresholdMultiplier", properties, 1);
                    }
                }
            }
            else
            {
                if (savedTopology && savedTopology.getXtraInfo() !== null && !savedTopology.getXtraInfo().isEmpty())
                {
                    this.setDefaultCrcValue("sfThreshold", properties, 0);
                    this.setDefaultCrcValue("sfThresholdMultiplier", properties, 1);

                }
            }
        }
        else
        {
            if (savedTopology && savedTopology.getXtraInfo() !== null && !savedTopology.getXtraInfo().isEmpty())
            {
                this.setDefaultCrcValue("sdThreshold", properties, 0);
                this.setDefaultCrcValue("sdThresholdMultiplier", properties, 1);
                this.setDefaultCrcValue("sfThreshold", properties, 0);
                this.setDefaultCrcValue("sfThresholdMultiplier", properties, 1);

            }
        }
        logger.info("ethernetLevelPayload properties == \n{}", JSON.stringify(properties));
        var ethernetLevelPayload = util.editPayload(ethernetLevelFdn, properties, fullClassName, objectFullName);
        return ethernetLevelPayload;

    }

    this.ethernetPortLevel = function (target, fullClassName, portLevelFdn, intentConfig, properties) {

        var intentEthernet = intentConfig["ethernet"];
        properties["mtuValue"] = intentEthernet["mtu"];

        properties["mode"] = intentEthernet["mode"];
        if (intentEthernet["l2Uplink"] !== undefined)
        {
            properties["isl2UplinkMode"] = intentEthernet["l2Uplink"];
        }
        else
        {
            properties["isl2UplinkMode"] = false;
        }
        // concating with ethernet for classic type speed
        if (intentEthernet["speed"] && intentEthernet["speed"] !== null)
        {
            properties["speed"] = "ethernet" + intentEthernet["speed"];
        }

        if (intentEthernet["hold-time"])
        {
            properties["holdTimeUp"] = intentEthernet["hold-time"]["up"];
            properties["holdTimeDown"] = intentEthernet["hold-time"]["down"];
            properties["holdTimeUnits"] = intentEthernet["hold-time"]["units"];
        }
        properties["encapType"] = this.getClassicEncapType(intentEthernet["encap-type"]);

        //ethernet Accounting policy
        if (intentEthernet["accounting-policy"])
        {
            properties["etherAccountingPolicyObjectPointer"] = "Accounting:" + intentEthernet["accounting-policy"];
        }
        else
        {
            properties["etherAccountingPolicyObjectPointer"] = "";
        }
        if (intentEthernet["collect-stats"])
        {
            properties["etherCollectStats"] = intentEthernet["collect-stats"];
        }
        else
        {
            properties["etherCollectStats"] = false;
        }

        //ethernet Access Accounting policy
        if (intentEthernet["access"])
        {
            if (intentEthernet["access"]["accounting-policy"])
            {
                properties["ethAccessAccountingPolicyObjectPointer"] = "Accounting:" + intentEthernet["access"]["accounting-policy"];
            }
            else
            {
                properties["ethAccessAccountingPolicyObjectPointer"] = "";
            }
            if (intentEthernet["access"]["collect-stats"])
            {
                properties["ethAccessCollectStats"] = intentEthernet["access"]["collect-stats"];
            }
            else
            {
                properties["ethAccessCollectStats"] = false;
            }
        }
        else
        {
            properties["ethAccessCollectStats"] = false;
        }

        //ethernet Network Accounting policy
        if (intentEthernet["network"])
        {
            if (intentEthernet["network"]["accounting-policy"])
            {
                properties["accountingPolicyObjectPointer"] = "Accounting:" + intentEthernet["network"]["accounting-policy"];
            }
            else
            {
                properties["accountingPolicyObjectPointer"] = "";
            }
            if (intentEthernet["network"]["collect-stats"])
            {
                properties["collectStats"] = intentEthernet["network"]["collect-stats"];
            }
            else
            {
                properties["collectStats"] = false;
            }
        }
        else
        {
            properties["collectStats"] = false;
        }

        //ethernet Egress Port QOS Policy
        if (intentEthernet["egress"])
        {
            if (intentEthernet["egress"]["port-qos-policy"]["policy-name"])
            {
                properties["portQosPolicyPointer"] = "PortQosPolicy7250SROS:" + intentEthernet["egress"]["port-qos-policy"]["policy-name"];
            }
        }
        return properties;
    }

    this.ethernetPortLldp = function (target, portId, intentConfig, actionType, auditReport) {
        var portLevelFdn = util.getBaseFdnForPort(target, portId);
        if (!Array.isArray(intentConfig["ethernet"]["lldp"]["dest-mac"]))
        {
            intentConfig["ethernet"]["lldp"]["dest-mac"] = [intentConfig["ethernet"]["lldp"]["dest-mac"]];
        }
        for (var index in intentConfig["ethernet"]["lldp"]["dest-mac"])
        {
            var lldp = intentConfig["ethernet"]["lldp"]["dest-mac"][index];
            var lldpMacType = lldp["mac-type"];
            logger.info("MAC-type = " + lldpMacType);
            var properties = {};
            var objectFullName = "";
            var fullClassName = "";
            switch (lldpMacType)
            {
                case "nearest-bridge" :
                    objectFullName = portLevelFdn + ":lldpportconfiguration-Nearest-Bridge";
                    fullClassName = "lldp.LLDPNearestBridgePortConfiguration";
                    properties = this.nearestBridge(target, fullClassName, portLevelFdn, lldp, properties, actionType);
                    break;
                case "nearest-non-tpmr" :
                    objectFullName = portLevelFdn + ":lldpportconfiguration-Nearest-Non-TPMR";
                    fullClassName = "lldp.LLDPNearestNonTpmrPortConfiguration";
                    properties = this.nearestNonTpmr(target, fullClassName, portLevelFdn, lldp, properties, actionType);
                    break;
                case "nearest-customer":
                    objectFullName = portLevelFdn + ":lldpportconfiguration-Nearest-Customer";
                    fullClassName = "lldp.LLDPNearestCustomerPortConfiguration"
                    properties = this.nearestCustomer(target, fullClassName, portLevelFdn, lldp, properties, actionType);
                    break;
            }
            var lldpPayload = util.editPayload(portLevelFdn, properties, fullClassName, objectFullName);

            if (actionType == "audit" && auditReport)
            {
                var result = this.auditRequest(target, lldpPayload);
                auditReport = util.reportMisaligned(target, result, auditReport);
            }
            else
            {
                var result = this.modifyRequest(target, lldpPayload);
            }


            this.txManagementAddress(lldp, objectFullName, target, auditReport, actionType, portLevelFdn);
        }

    }

    this.nearestBridge = function (target, fullClassName, portLevelFdn, bridgeConfig, properties, actionType) {

        this.lldpCommonProperties(bridgeConfig, properties, actionType);
        if (bridgeConfig["tunnel-nearest-bridge"] !== undefined)
        {
            properties["portCfgEnableTunneling"] = (bridgeConfig["tunnel-nearest-bridge"]).toString();
        }
        else
        {
            properties["portCfgEnableTunneling"] = "false";
        }
        return properties;

    }

    this.nearestNonTpmr = function (target, fullClassName, portLevelFdn, nonTpmrConfig, properties, actionType) {

        this.lldpCommonProperties(nonTpmrConfig, properties, actionType);
        return properties;

    }

    this.nearestCustomer = function (target, fullClassName, portLevelFdn, customerConfig, properties, actionType) {

        this.lldpCommonProperties(customerConfig, properties, actionType);
        return properties;

    }


    this.lldpCommonProperties = function (lldpInstance, properties, actionType) {

        if (lldpInstance["transmit"] && lldpInstance["receive"] && lldpInstance["transmit"] !== "" && lldpInstance["receive"] !== ""
            && lldpInstance["receive"] == true && lldpInstance["transmit"] == true)
        {
            properties["portCfgAdminStatus"] = "txAndRx";
        }
        else if (lldpInstance["receive"] && lldpInstance["receive"] !== "" && lldpInstance["receive"] == true)
        {
            properties["portCfgAdminStatus"] = "rxOnly";
        }
        else if (lldpInstance["transmit"] && lldpInstance["transmit"] !== "" && lldpInstance["transmit"] == true)
        {
            properties["portCfgAdminStatus"] = "txOnly";
        }
        else
        {
            properties["portCfgAdminStatus"] = "disabled";
        }


        if (lldpInstance["notification"] !== undefined)
        {
            properties["portCfgNotifyEnable"] = (lldpInstance["notification"]).toString();
        }
        else
        {
            properties["portCfgNotifyEnable"] = "false";
        }
        properties["portCfgPortIdSubtype"] = this.getPortIdSubType(lldpInstance["port-id-subtype"]);

        // need to enable later
        properties["portCfgTLVsTxEnable"] = this.lldpTlvsEnable(lldpInstance["tx-tlvs"], actionType);

        return properties;

    }

    this.txManagementAddress = function (lldpInstance, lldpObjectFullName, target, auditReport, actionType, portLevelFdn) {
        if (lldpInstance["tx-mgmt-address"])
        {
            if (!Array.isArray(lldpInstance["tx-mgmt-address"]))
            {
                lldpInstance["tx-mgmt-address"] = [lldpInstance["tx-mgmt-address"]];
            }
            for (var index in lldpInstance["tx-mgmt-address"])
            {
                var managementAddress = lldpInstance["tx-mgmt-address"][index];
                properties = {};
                var objectFullName = lldpObjectFullName;
                switch (managementAddress["mgmt-address-system-type"])
                {
                    case "oob":
                        objectFullName = objectFullName + ":-0";
                        break;
                    case "system":
                        objectFullName = objectFullName + ":-1";
                        break;
                    case "system-ipv6":
                        objectFullName = objectFullName + ":-2";
                        break;
                    case "oob-ipv6":
                        objectFullName = objectFullName + ":-3";
                        break;
                }

                if (managementAddress["admin-state"] && managementAddress["admin-state"] != "")
                {
                    properties["portCfgManAddrTxEnabled"] = managementAddress["admin-state"] + "d";
                }
                fullClassName = "lldp.TransmitMgmtAddress";
                var mgmtAddressPayload = util.editPayload(portLevelFdn, properties, fullClassName, objectFullName);
                if (actionType == "audit" && auditReport)
                {
                    result = this.auditRequest(target, mgmtAddressPayload);
                    auditReport = util.reportMisaligned(target, result, auditReport);
                }
                else
                {
                    var result = this.modifyRequest(target, mgmtAddressPayload);
                }
            }
        }
    }
    this.lldpTlvsEnable = function (lldpTlvs, actionType) {
        var portCfgTLVsTxEnable = [];
        if (lldpTlvs && lldpTlvs != "")
        {
            if (lldpTlvs["sys-cap"] == true)
            {
                portCfgTLVsTxEnable.push("sysCap");
            }
            if (lldpTlvs["sys-desc"] == true)
            {
                portCfgTLVsTxEnable.push("sysDesc");
            }
            if (lldpTlvs["sys-name"] == true)
            {
                portCfgTLVsTxEnable.push("sysName");
            }
            if (lldpTlvs["port-desc"] == true)
            {
                portCfgTLVsTxEnable.push("portDesc");
            }
        }
        if (actionType == "audit" && portCfgTLVsTxEnable.length == 0)
        {
            return "";
        }
        return portCfgTLVsTxEnable;
    }

    this.getPortIdSubType = function (portIdSubType) {
        var classicPortIdSubType = null;
        switch (portIdSubType)
        {
            case "tx-if-alias" :
                classicPortIdSubType = "interfaceAlias";
                break;
            case "tx-if-name" :
                classicPortIdSubType = "interfaceName";
                break;
            default :
                classicPortIdSubType = "local";
        }
        return classicPortIdSubType;

    }
    this.getClassicEncapType = function (encapType) {
        var classicEncapType = null;
        switch (encapType)
        {
            case "dot1q" :
                classicEncapType = "qEncap";
                break;
            case "qinq" :
                classicEncapType = "qinqEncap";
                break;
            default :
                classicEncapType = "nullEncap";
        }
        return classicEncapType;
    }

    this.auditRequest = function (target, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;

    }

    this.modifyRequest = function (target, payload) {
        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;

    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }

    this.removeEmptyContainers = function (prop, intentJson, path, target) {

        if (Array.isArray(intentJson))
        {
            var object = [];
            for (var prop in intentJson)
            {
                var value = this.removeEmptyContainers(prop, intentJson[prop], path, target);
                if (value)
                {
                    object.push(value);
                }

            }
            if (Object.keys(object).length !== 0)
            {
                return object;
            }
        }
        else if (typeof intentJson == 'object')
        {
            var object = {};
            for (var prop in intentJson)
            {
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop, intentJson[prop], pPath, target);
                if ((value && value !== null) || value == 0)
                {
                    object[prop] = value;
                }

            }
            if (Object.keys(object).length !== 0)
            {
                return object;
            }
        }
        else
        {
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if (intentJson !== undefined && intentJson !== "")
            {
                return intentJson;
            }

            return null;
        }
    }
    this.setDefaultCrcValue = function (key, properties, value) {
        savedTopology.getXtraInfo().forEach(function (xtraInfo, index) {
            if (xtraInfo.getKey() === key)
            {
                properties[key] = value;
            }
        });
        this.removetoplogyXtraInfo(key);
    }
    this.removetoplogyXtraInfo = function (key) {
        if (savedTopology && savedTopology.getXtraInfo() !== null && !savedTopology.getXtraInfo().isEmpty())
        {
            var xtraInfos = savedTopology.getXtraInfo();
            for (var i = 0; i < xtraInfos.size(); i++)
            {
                if (xtraInfos.get(i).getKey() == key)
                {
                    xtraInfos.remove(i);
                    break;
                }
            }
        }
    }
}
