load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
load({script: resourceProvider.getResource('mdc-intent-fwk.js'), name: 'MdcIntentFwk'})
load({script: resourceProvider.getResource('nfmp-cpu-protection.js'), name: 'NfmpCpuProtection'})
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'})

function NspIntentHelper() {

    var mdtFwk = new MdtFwk();

    this.synchronize = function (input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {

        logger.info('Nsp Intent Helper -> Synchronise');
        try
        {

            var result = synchronizeResultFactory.createSynchronizeResult();

            var instanceFwk = this.navigateInstance(input.getTarget());

            instanceFwk.synchronize(input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);

            return result
        } catch (e)
        {
            logger.info('Error Occured while Synchronising with error: ' + e)
            throw new RuntimeException('Error Executing Intent: ' + e)
        }
    }

    this.audit = function (target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {

        try
        {
            var instanceFwk = this.navigateInstance(target);
            logger.info('instanceFwk ' + instanceFwk)

            var report = auditFactory.createAuditReport(null, null);

            //Calling the audit of respective fwk
            instanceFwk.audit(target, config, svcTopo, adminState, report, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);

            return report
        } catch (e)
        {
            logger.info('Error Occured while Auditing with error: ' + e)
            throw new RuntimeException('Error Executing Intent: ' + e)
        }
    }

    this.navigateInstance = function (target) {


        var managerName = mdtFwk.getManagerName(new ParseTarget().getNeIdFromTarget(target));

        logger.info('Device: ' + target + ' is managed by: ' + managerName);

        switch (managerName)
        {
            case 'NFM-P':
                logger.info('Device is managed by NFMP')
                return this.createNfmpInstance()
                break;
            case 'MDC':
                logger.info('Device is managed by MDM')
                return this.createMdcInstance()
                break;
            default:
                logger.info('Device is not managed')
                throw new RuntimeException('Device is not Managed')
        }

        return ''
    }

    this.createNfmpInstance = function () {
        return new NfmpCpuProtection()
    }

    this.createMdcInstance = function () {
        return new MdcIntentFwk()
    }

}
