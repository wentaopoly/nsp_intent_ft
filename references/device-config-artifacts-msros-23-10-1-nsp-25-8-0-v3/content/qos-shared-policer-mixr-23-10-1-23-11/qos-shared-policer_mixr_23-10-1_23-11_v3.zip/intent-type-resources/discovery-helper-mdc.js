var RuntimeException = Java.type("java.lang.RuntimeException");

load({
  script: resourceProvider.getResource("parse-target.js"),
  name: "ParseTarget",
});

function MdcDiscoveryHelper() {
  /**
   *
   * @param {*} targetWithTemplate
   * @param {*} deviceYangModuleName
   * @param {*} parentXpath
   * @param {*} intentContainer
   * @returns
   */
  this.getDeviceConfiguration = function (
    targetWithTemplate,
    deviceYangModuleName,
    parentXpath,
    intentContainer
  ) {
    var parseTarget = new ParseTarget();
    var neId = parseTarget.getNeIdFromTarget(targetWithTemplate);
    var targetIdentifier = parseTarget.getUniqueIdentifier(targetWithTemplate);
    let deviceConfig = commonUtil.getDeviceConfig(
      neId,
      parentXpath,
      intentContainer,
      deviceYangModuleName,
      targetIdentifier
    );
    return deviceConfig;
  };

  /**
   *
   * @param {*} targetDataStruct
   * @param {*} deviceConfig
   * @param {*} deviceYangModuleName
   * @param {*} parentXpath
   * @param {*} intentContainer
   * @returns configuration from device, copying only the keys in the targetDataStruct
   */
  this.extractDeviceConfig = function (
    targetDataStruct,
    deviceConfig,
    intentContainer,
    neId
  ) {
    var parsedStruct = JSON.parse(targetDataStruct);
    var structKeys = Object.keys(parsedStruct[intentContainer]);
    let neTypeAndVersion = mdtFwk.getTypeAndVersion(neId);
    let isSRLinux = commonUtil.isSRLinux(neTypeAndVersion["type"]);
    if (isSRLinux) {
      logger.info("Device is SRL ");
      // remove module references from deviceConfig
      commonUtil.removeModuleRef(deviceConfig);
    }
    let ccpiedValues = _.pick(deviceConfig, structKeys);
    let config = {};
    config[intentContainer] = ccpiedValues;
    return config;
  };

  /**
   *
   * @param {*} key
   * @returns
   */
  this.cipherSpecialCharacterInKey = function (key) {
    return commonUtil.encodeString(key);
  };
}
