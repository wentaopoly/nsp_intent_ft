var RuntimeException = Java.type("java.lang.RuntimeException");

var prefixToNsMap = {
  ibn: "http://www.nokia.com/management-solutions/ibn",
  nc: "urn:ietf:params:xml:ns:netconf:base:1.0",
  "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
  "http://www.nokia.com/management-solutions/anv-device-holders":
    "anv-device-holders",
};

load({
  script: resourceProvider.getResource("nsp-intent-helper.js"),
  name: "nsp-intent-helper",
});
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
var mdtFwk =  new MdtFwk();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('mdSuggest.js'), name: 'MdSuggest'})

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})

var LOG_PREFIX = "[IPv6 Filter]: "

var intentTypeName = 'filter-ipv6-filter_gsros_23-10-1_23-11';

// example port, sap-ingress etc..
var initialPropertyName = 'ipv6-filter';

var deviceYangModuleName = 'nokia-conf';

// unique identifier
var uniqueIdentifier = 'filterName';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/filter';

function synchronize(input) {
  logger.info("Intent Synchronisation started");

  return NspIntentHelper.synchronize(
    input,
    intentTypeName,
    parentXpath,
    initialPropertyName,
    uniqueIdentifier,
    deviceYangModuleName
  );
}

function onAudit(target, config, svcTopo, adminState) {
  logger.info("Intent Audit started");

  return NspIntentHelper.audit(
    target,
    config,
    svcTopo,
    adminState,
    intentTypeName,
    parentXpath,
    initialPropertyName,
    uniqueIdentifier,
    deviceYangModuleName
  );
}

function suggestFilterName(context) {
  logger.info(LOG_PREFIX + "suggestFilterName context = \n" + context);
  var filterId;
  if (context.getInputValues()["arguments"]["__attribute"] === "target_filterName") {
    filterId = context.getInputValues()["arguments"]["target_id"];
  }
  else {
    filterId = context.getInputValues()["target"]["id"];
  }
  logger.info(LOG_PREFIX + "User selected Filter ID : {}, searching filter Name associated to Filter-id - {}", filterId, filterId);
  var neId = getNeId(context);
  return navigateInstance(neId).getFilterName(neId, filterId);
}

function suggestFilterId(context) {
  logger.info(LOG_PREFIX + "suggestFilterId context = \n" + context);
  var filterName;
  if (context.getInputValues()["arguments"]["__attribute"] === "target_id") {
    filterName = context.getInputValues()["arguments"]["target_filterName"];
  }
  else {
    filterName = context.getInputValues()["target"]["network-filterName"];
  }
  logger.info(LOG_PREFIX + "User selected Filter Name : {}, searching Filter ID associated to Filter Name - {}", filterName, filterName);
  var neId = getNeId(context);
  return navigateInstance(neId).getFilterId(neId, filterName);
}

function suggestFilterLog(context) {
  logger.info("suggest Filter Log Context = \n" + context);
  var neId = getNeId(context);
  return navigateInstance(neId).getFilterLog(neId);
}

function suggestSampleProfile(context) {
  logger.info("suggest Sample Profile Context = \n" + context);
  var neId = getNeId(context);
  return navigateInstance(neId).getSampleProfile(neId);
}

function suggestPrefixList(context) {
  logger.info("suggest Prefix List Context = \n" + context);
  var neId = getNeId(context);
  return navigateInstance(neId).getPrefixList(neId);
}

function suggestPortList(context) {
  logger.info("suggest Port List Context = \n" + context);
  var neId = getNeId(context);
  return navigateInstance(neId).getPortList(neId);
}

function suggestGreTunnel(context) {
  logger.info("suggest GRE Tunnel Context = \n" + context);
  var neId = getNeId(context);
  return navigateInstance(neId).getGreTunnel(neId);
}

function suggestRoutingInstance(context) {
  logger.info("suggest Routing instances = \n" + context);
  var neId = getNeId(context);
  return navigateInstance(neId).getRoutingInstances(neId);
}

function suggestVPRNService(context) {
  logger.info("suggest VPRN Service Context = \n" + context);
  var neId = getNeId(context);
  return navigateInstance(neId).getVPRNServices(neId);
}

function suggestVPLSService(context) {
  logger.info("suggest VPLS Service Context = \n" + context);
  var neId = getNeId(context);
  return navigateInstance(neId).getVPLSServices(neId);
}

function suggestLSP(context) {
  logger.info("suggest LSP Context = \n" + context);
  var neId = getNeId(context);
  return navigateInstance(neId).getLSPs(neId);
}

function suggestOfSwitch(context) {
  logger.info("suggest Of Switch = \n" +context);
  var neId = getNeId(context);
  return navigateInstance(neId).getOfSwitch(neId);
}

function suggestEmbedFilter(context) {
  logger.info("suggest Of Switch = \n" +context);
  var neId = getNeId(context);
  return navigateInstance(neId).getEmbedFilter(neId);
}

function getNeId(context) {
  var neId;
  var target = context.getInputValues()["target"]["objectidentifier"];
  logger.info(LOG_PREFIX + "target : {}", target)
  if ((target == undefined || target == "") && context.getInputValues()["arguments"]["__root"])
  {
    target = context.getInputValues()["arguments"]["__root"]["target_objectidentifier"];
  }
  if((target == undefined || target == "") && context.getInputValues()["arguments"]["__parent"])
  {
    target = context.getInputValues()["arguments"]["__parent"]["target_objectidentifier"];
  }
  if(target)
  {
    if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
      neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
    }
    else {
      neId = target;
    }
  }
  logger.info(LOG_PREFIX + "NeId identified " + " : {}", neId);
  return neId;
}

function navigateInstance(neId) {
  var managerName = mdtFwk.getManagerName(neId);
  logger.info(LOG_PREFIX + 'Device: ' + neId + ' is managed by: ' + managerName);
  switch (managerName) {
    case "NFM-P":
      logger.info(LOG_PREFIX + 'Device is managed by NFMP');
      return new NfmpSuggest();
      break;
    case "MDC":
      logger.info(LOG_PREFIX + 'Device is managed by MDC');
      return new MdSuggest();
      break;
    default:
      logger.info(LOG_PREFIX + 'Device is not managed')
      throw new RuntimeException(LOG_PREFIX + 'Device is not Managed')
  }
  return '';
}


function getTargetData(input) {
  logger.info(input);
  var target = input.target;
  var config = null;
  logger.info("target=" + target);
  var deviceConfig = icmFwk.getDeviceConfiguration(target, deviceYangModuleName, parentXpath, initialPropertyName);
  logger.info(JSON.stringify(deviceConfig));
  var data = gtdFwk.gtdSend(deviceConfig);
  return data.msg.result;
}

