function NfmpSuggest() {
    this.getMemberOperGroup = function (neId) {
        let searchObjectJson = {
            "fullClassName": "service.OperGroup",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "groupName"
                ]
            }
        };
        return this.getSuggestData(searchObjectJson, "service.OperGroup", "groupName");
    }

    this.getReservedLabelBlock = function (neId) {
        let searchObjectJson = {
            "fullClassName": "mpls.ReservedLabelBlock",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "labelBlockName"
                ]
            }
        };
        return this.getSuggestData(searchObjectJson, "mpls.ReservedLabelBlock", "labelBlockName");
    }

    this.getRslbBlockData = function (neId, labelBlockName,attributeName) {
        let fullClassName = "mpls.ReservedLabelBlock";
        let searchObjectJson = {
            "fullClassName": fullClassName,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "labelBlockName",
                            "value": labelBlockName
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    attributeName
                ]
            }
        };
      let nfmpFwk = new NfmpFwk();
      let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
      let finalResponse = JSON.parse(resultFetch.response);
      let data = (finalResponse && finalResponse[fullClassName] && finalResponse[fullClassName][attributeName]);
      return data;
    }

    this.getEthSegPwPort = function (neId) {
        let searchObjectJson = {
            "fullClassName": "equipment.PwPort",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ],
                    "notEqual": [
                       {
                           "name": "mode",
                           "value": "network"
                       }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id","name","mode","encapType"
                ]
            }
        };
        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var response = JSON.parse(resultFetch.response)["equipment.PwPort"];
        if (response && !Array.isArray(response)) {
          response = [response];
        }
        let result = {};
        let data= [];
        if (response) {
         data = response.map(function (pwPortDetails) {
           let obj = {};
           if (pwPortDetails["id"] && pwPortDetails["name"] && pwPortDetails["mode"] && pwPortDetails["encapType"]) {
              obj["ethSegPwPortId"]= pwPortDetails["id"];
              obj["name"] = pwPortDetails["name"];
              if(pwPortDetails["encapType"]=== "nullEncap"){
                obj["encapType"] = "Null";
              }else if(pwPortDetails["encapType"]=== "qEncap"){
                obj["encapType"] = "Dot1Q";
              }else if(pwPortDetails["encapType"]=== "qinqEncap"){
                obj["encapType"] = "QinQ";
              }
              if(pwPortDetails["mode"]=== "access"){
                obj["mode"] = "Access";
              }else if(pwPortDetails["mode"]=== "hybrid"){
                obj["mode"] = "Hybrid";
              }
              return obj
           }
           return null;
        }).filter(obj => obj !== null);

        result["data"] = JSON.stringify(data);
    }
    logger.info("Processed data: " + JSON.stringify(result));
    return result;
    };

    this.getSdpData = function (neId) {
        let searchObjectJson = {
            "fullClassName": "svt.Tunnel",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "fromNodeId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "pathId","displayedName","underlyingTransport"
                ]
            }
        };
    let nfmpFwk = new NfmpFwk();
    let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
    var response = JSON.parse(resultFetch.response)["svt.Tunnel"];
    if (response && !Array.isArray(response)) {
       response = [response];
    }
    let result = {};
    let data= [];
     if (response) {
         data = response.map(function (sdpDetails) {
           let obj = {};
           if (sdpDetails["pathId"] && sdpDetails["displayedName"] && sdpDetails["underlyingTransport"]) {
              obj["id"]= sdpDetails["pathId"];
              obj["ethSegSdpIdPointer"] = sdpDetails["displayedName"];
              obj["underlyingTransport"] = sdpDetails["underlyingTransport"];
              return obj
           }
           return null;
        }).filter(obj => obj !== null);

        result["data"] = JSON.stringify(data);
    }
    return result;
    };


    this.getSuggestData = function (searchObjectJson, searchClass, propertyName)
    {

        let nfmpFwk = new NfmpFwk();
        let ret = [];
        let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        let finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        finalResponse = finalResponse[searchClass];
        logger.info(JSON.stringify(finalResponse));

        if (Object.keys(finalResponse).length !== 0)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            finalResponse.forEach(function (value, index, array) {
                ret.push(value[propertyName]);
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

   this.getLagData = function (neId) {
    let searchObjectJson = {
        "fullClassName": "lag.Interface",
        "filter": {
            "and": {
                "equal": [
                    {
                        "name": "siteId",
                        "value": neId
                    }
                ],
                "notEqual": [
                    {
                        "name": "mode",
                        "value": "network"
                    }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": ["lagId", "lagNameId", "encapType","mode"]
        }
    };
    let nfmpFwk = new NfmpFwk();
    let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
    var response = JSON.parse(resultFetch.response)["lag.Interface"];
    if (response && !Array.isArray(response)) {
        response = [response];
    }
    let result = {};
    let data= [];
    logger.info("the response data"+JSON.stringify(response))
    if (response) {
         data = response.map(function (lagDetails) {
           let obj = {};
           if (lagDetails["lagId"] && lagDetails["lagNameId"] && lagDetails["encapType"]) {
              obj["ethSegLagIdPointer"]= lagDetails["lagId"];
              obj["lagNameId"] = lagDetails["lagNameId"];
              obj["mode"] = lagDetails["mode"];
              if(lagDetails["encapType"]=== "nullEncap"){
                obj["encapType"] = "Null";
              }else if(lagDetails["encapType"]=== "qEncap"){
                obj["encapType"] = "Dot1Q";
              }else if(lagDetails["encapType"]=== "qinqEncap"){
                obj["encapType"] = "QinQ";
              }
              if(lagDetails["mode"]=== "access"){
                obj["mode"] = "Access";
              }else if(lagDetails["mode"]=== "hybrid"){
                obj["mode"] = "Hybrid";
              }
              return obj
           }
           return null;
        }).filter(obj => obj !== null);

        result["data"] = JSON.stringify(data);
    }
    logger.info("Processed data: " + JSON.stringify(result));
    return result;
    };

    this.getPort = function(neId, mode, encapType) {
    let searchObjectJson1 = {
        "fullClassName": "equipment.PhysicalPort",
        "filter": {
            "and": {
                "equal": [{
                    "name": "siteId",
                    "value": neId
                }],
                "notEqual": [
                    {
                        "name": "mode",
                        "value": "network"
                    }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": [
                "portName",
                "snmpPortId",
                "encapType",
                "mode"
            ]
        }
    };
    let searchObjectJson2 = {
        "fullClassName": "pxc.PortCrossConnectSubPort",
        "filter": {
            "and": {
                "equal": [{
                    "name": "siteId",
                    "value": neId
                }],
                "notEqual": [
                    {
                        "name": "mode",
                        "value": "network"
                    }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": [
                "displayedName",
                "snmpPortId",
                "encapType",
                "mode"
            ]
        }
    };
    let nfmpFwk = new NfmpFwk();
    let data;
    let resultFetch1 = nfmpFwk.post("/v3/search", searchObjectJson1);
    let resultFetch2 = nfmpFwk.post("/v3/search", searchObjectJson2);
    var finalResponse1 = JSON.parse(resultFetch1.response)["equipment.PhysicalPort"];
    var finalResponse2 = JSON.parse(resultFetch2.response)["pxc.PortCrossConnectSubPort"];
	if(finalResponse1 && finalResponse2){
	  let finalResponse= finalResponse1.concat(finalResponse2);
	    data = processResponse(finalResponse);
	   return data;
    }else if(finalResponse1){
       data = processResponse(finalResponse1);
	 return data
	}else if(finalResponse2) {
	  data = processResponse(finalResponse2);
	  return data;
	}
   }

   function processResponse(response) {
    let result={};
    let data=[];
    if (response && !Array.isArray(response)) {
        response = [response];
    }
    if (response) {
        data = response.map(function(portDetails) {
            let obj = {};
            if ((portDetails["portName"] || portDetails["displayedName"]) &&  portDetails["snmpPortId"] && portDetails["mode"] && portDetails["encapType"]) {
                obj["ethSegPortIdPointer"] = portDetails["portName"] || portDetails["displayedName"];
                obj["interfaceId"] = portDetails["snmpPortId"];
                obj["mode"] = portDetails["mode"];
                if(portDetails["encapType"]=== "nullEncap"){
                  obj["encapType"] = "Null";
                }else if(portDetails["encapType"]=== "qEncap"){
                  obj["encapType"] = "Dot1Q";
                }else if(portDetails["encapType"]=== "qinqEncap"){
                  obj["encapType"] = "QinQ";
                }
                if(portDetails["mode"]=== "access"){
                  obj["mode"] = "Access";
                }else if(portDetails["mode"]=== "hybrid"){
                  obj["mode"] = "Hybrid";
                }
                return obj;
            }
            return null;
        }).filter(obj => obj !== null);
         result["data"] = JSON.stringify(data);
    }
    logger.info("Processed data: " +JSON.stringify(result));
    return result;
   }

   this.getPortData = function (neId, port, attribute) {
     let fullClassName = port.startsWith("pxc-") ? "pxc.PortCrossConnectSubPort" : "equipment.PhysicalPort";
     let attributeName = port.startsWith("pxc-") ? "displayedName" : "portName";
     let searchObjectJson = {
         "fullClassName": fullClassName,
         "filter": {
             "and": {
                 "equal": [
                     { "name": "siteId", "value": neId },
                     { "name": attributeName, "value": port }
                 ]
             }
         },
         "resultFilter": {
             "children": "",
             "attribute": [attribute]
         }
     };
     let nfmpFwk = new NfmpFwk();
     let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
     let finalResponse = JSON.parse(resultFetch.response);
     let data = (finalResponse && finalResponse[fullClassName] && finalResponse[fullClassName][attribute]);
     return data;
   };


   this.getData = function (neId, ethSegPointer, fullClassName, attributeName, networkId) {
      let searchObjectJson = {
          "fullClassName": fullClassName,
          "filter": {
              "and": {
                  "equal": [
                      { "name": networkId, "value": neId },
                      { "name": attributeName, "value": ethSegPointer }
                  ]
              }
          },
          "resultFilter": {
              "children": "",
              "attribute": ["objectFullName"]
          }
      };
      let nfmpFwk = new NfmpFwk();
      let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
      let finalResponse = JSON.parse(resultFetch.response);
      let data = (finalResponse && finalResponse[fullClassName] && finalResponse[fullClassName]["objectFullName"]);
      return data;
   };

   this.getDataForBF = function (neId, ethSegPointer, fullClassName, searchAttribute, networkId) {
      let searchObjectJson = {
          "fullClassName": fullClassName,
          "filter": {
              "and": {
                  "equal": [
                      { "name": networkId, "value": neId },
                      { "name": "objectFullName", "value": ethSegPointer }
                  ]
              }
          },
          "resultFilter": {
              "children": "",
              "attribute": [searchAttribute]
          }
      };
      let nfmpFwk = new NfmpFwk();
      let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
      let finalResponse = JSON.parse(resultFetch.response);
      let data = (finalResponse && finalResponse[fullClassName] && finalResponse[fullClassName][searchAttribute]);
      return data;
   };

   this.getPortDataForBF = function(neId, objectFullName) {
       let searchObjectJson1 = {
           "fullClassName": "equipment.PhysicalPort",
           "filter": {
               "and": {
                   "equal": [
                       { "name": "siteId", "value": neId },
                       { "name": "objectFullName", "value": objectFullName }
                   ]
               }
           },
           "resultFilter": {
               "children": "",
               "attribute": ["portName"]
           }
       };
       let searchObjectJson2 = {
           "fullClassName": "pxc.PortCrossConnectSubPort",
           "filter": {
               "and": {
                   "equal": [
                       { "name": "siteId", "value": neId },
                       { "name": "objectFullName", "value": objectFullName }
                   ]
               }
           },
           "resultFilter": {
               "children": "",
               "attribute": ["portName"]
           }
       };
       let nfmpFwk = new NfmpFwk();       
       let resultFetch1 = nfmpFwk.post("/v3/search", searchObjectJson1);
       let resultFetch2 = nfmpFwk.post("/v3/search", searchObjectJson2);
       var finalResponse1 = JSON.parse(resultFetch1.response)["equipment.PhysicalPort"];
       var finalResponse2 = JSON.parse(resultFetch2.response)["pxc.PortCrossConnectSubPort"];
       let data;
       if (finalResponse1 && finalResponse1.portName) {
           data = finalResponse1.portName;
       } else if (finalResponse2 && finalResponse2.portName) {
           data = finalResponse2.portName;
       }
       return data;
   };

}