var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});


function NfmpBGPGroup()
{

    var savedObjects;
    var currentObjects;
    var isAudit = false;
    var mdtfwk = new MdtFwk();
    var util = new utilities();
    var mapFwk = new MapFwk();
    let nfmpFwk = new NfmpFwk();
    var parseTarget = new ParseTarget();
    var objectPropMap = {};

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier)
    {
        // code to handle delete
        if (input.getNetworkState().name() === "delete")
        {
            return this.syncDelete(input, result);
        }

        var savedTopology = input.getCurrentTopology();
        logger.info(savedTopology);
        savedObjects = {};
        currentObjects = {};
        isAudit = false;
        //loading the saved objects from topology
        this.loadSavedObjectsFromTopology(savedTopology);

        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName];
        //intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        if (!intentConfig)
        {
            intentConfig = Object.create({});
            intentConfig[initialPropertyName] = Object.create({});
        }
        intentConfig[initialPropertyName][uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());

        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target BGP Group = " + intentConfig[initialPropertyName][uniqueIdentifier]);

        this.createOrModify(target, intentConfig);
        var currentTopo = this.loadCurrentObjectsToTopology(target);

        result = util.setSuccessResult(result, currentTopo);
        return result;
    }

    this.audit = function (target, config, svcTopo, adminState, auditReport, intentTypeName, xpath, initialPropertyName, uniqueIdentifier)
    {
        var savedTopology = svcTopo;
        savedObjects = {};
        currentObjects = {};
        isAudit = true;
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName];
        //intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        if (!intentConfig)
        {
            intentConfig = Object.create({});
            intentConfig[initialPropertyName] = Object.create({});
        }
        intentConfig[initialPropertyName][uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        var neId = parseTarget.getNeIdFromTarget(target);
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target BGP Group = " + intentConfig[initialPropertyName][uniqueIdentifier]);

        if (intentConfig)
        {
            this.auditAndCompare(neId, intentConfig, auditReport);
        } else
        {
            throw "configuration not available in the intent";
        }

        return auditReport
    }

    this.auditAndCompare = function (target, intentConfig, auditReport)
    {
        var bgpGroupPayload = this.createBGPGroupLevelPayLoad(target, intentConfig, true);
        var result = this.auditRequest(target, bgpGroupPayload);
        auditReport = util.reportMisaligned(target, result, auditReport, objectPropMap);
        objectPropMap = {};
        return auditReport;
    }

    this.createOrModify = function (target, intentConfig)
    {
        var bgpGroupPayload = this.createBGPGroupLevelPayLoad(target, intentConfig);

        var result = this.modifyRequest(target, bgpGroupPayload);
        return result;
    }

    this.createBGPGroupLevelPayLoad = function (target, intentConfig)
    {
        var nodeType = mdtfwk.getTypeAndVersion(target);
        var bgpGroupConfig = intentConfig["group"];
        var fullClassName = "bgp.PeerGroup";
        var bgpFdn = "network:" + target + ":router-1:bgp";
        if (target && String(target).indexOf(':') !== -1) {
            bgpFdn = util.modifyNeIdForIpV6(bgpFdn, target);
        }
        var objectFullName = bgpFdn + ":group-" + bgpGroupConfig["group-name"];
        var properties = {};
        properties["inheritanceMask"] = {};
        var inheritanceMaskBits = [];
        properties["groupName"] = bgpGroupConfig["group-name"];
        if(bgpGroupConfig["admin-state"] != "enable")
        {
            inheritanceMaskBits.push("administrativeState");
            properties["administrativeState"] = "bgpDown";
        }

        properties["connectRetryTime"] = bgpGroupConfig["connect-retry"];
        if(bgpGroupConfig["connect-retry"])
        {
            inheritanceMaskBits.push("connectRetryTime");
        }

        properties["keepAlive"] = bgpGroupConfig["keepalive"];
        if(bgpGroupConfig["keepalive"])
        {
            inheritanceMaskBits.push("keepAlive");
        }

        properties["damping"] = bgpGroupConfig["damping"];
        if(bgpGroupConfig["damping"])
        {
            inheritanceMaskBits.push("damping");
        }

        properties["localPreference"] = bgpGroupConfig["local-preference"];
        if(bgpGroupConfig["local-preference"])
        {
            inheritanceMaskBits.push("localPreference");
        }

        properties["minRouteAdvertisement"] = bgpGroupConfig["min-route-advertisement"];
        if(bgpGroupConfig["min-route-advertisement"])
        {
            inheritanceMaskBits.push("minRouteAdvertisement");
        }

        properties["loopDetect"] = util.transformLoopDetect(bgpGroupConfig["loop-detect"]);
        if(bgpGroupConfig["loop-detect"])
        {
            inheritanceMaskBits.push("loopDetect");
        }

        if(bgpGroupConfig["aggregator-id-zero"])
        {
            inheritanceMaskBits.push("aggregatorIdZero");
            properties["aggregatorIdZero"] = bgpGroupConfig["aggregator-id-zero"];
        }

        properties["preference"] = bgpGroupConfig["preference"];
        if(bgpGroupConfig["preference"])
        {
            inheritanceMaskBits.push("preference");
        }

        properties["multiHop"] = bgpGroupConfig["multihop"];
        if(bgpGroupConfig["multihop"])
        {
            inheritanceMaskBits.push("multiHop");
        }

        if(!nodeType["type"].startsWith("7210"))
        {
            if(bgpGroupConfig["client-reflect"] == undefined || bgpGroupConfig["client-reflect"] == false)
            {
                inheritanceMaskBits.push("disableClientReflect");
                properties["disableClientReflect"] = true;
            }
        }
        if(bgpGroupConfig["vpn-apply-export"])
        {
            inheritanceMaskBits.push("vpnApplyExport");
            properties["vpnApplyExport"] = bgpGroupConfig["vpn-apply-export"];
        }

        if(bgpGroupConfig["vpn-apply-import"])
        {
            inheritanceMaskBits.push("vpnApplyImport");
            properties["vpnApplyImport"] = bgpGroupConfig["vpn-apply-import"];
        }

        if(!nodeType["type"].startsWith("7705"))
        {
            if(bgpGroupConfig["asn-4-byte"] == undefined || bgpGroupConfig["asn-4-byte"] == false)
            {
                inheritanceMaskBits.push("disable4ByteASN");
                properties["disable4ByteASN"] = true;
            }
        }

        if(bgpGroupConfig["path-mtu-discovery"])
        {
            inheritanceMaskBits.push("pathMtuDiscovery");
            properties["pathMtuDiscovery"] = bgpGroupConfig["path-mtu-discovery"];
        }

        if(bgpGroupConfig["hold-time"])
        {
            if(bgpGroupConfig["hold-time"]["seconds"])
            {
                properties["holdTime"] = bgpGroupConfig["hold-time"]["seconds"];
                inheritanceMaskBits.push("holdTime");
            }
            if(bgpGroupConfig["hold-time"]["minimum-hold-time"])
            {
                properties["minHoldTime"] = bgpGroupConfig["hold-time"]["minimum-hold-time"];
            }
        }

        if(bgpGroupConfig["family"])
        {
            var family = {};
            var familyBits = [];
            for (var familyType in bgpGroupConfig["family"])
            {
                if(bgpGroupConfig["family"][familyType])
                {
                    familyBits.push(util.getNfmpFamilyName(familyType));
                }
            }
            if(familyBits.length > 0)
            {
                if(isAudit == false)
                {
                    family["bit"] = familyBits;
                    properties["family"] = family;
                }
                else
                {
                    properties["family"] = familyBits;
                }
                inheritanceMaskBits.push("family");
            }
        }

        if(bgpGroupConfig["remove-private"])
        {
            if(bgpGroupConfig["remove-private"]["limited"] ||
                bgpGroupConfig["remove-private"]["skip-peer-as"])
            {
                inheritanceMaskBits.push("removePrivateAS");
                properties["removePrivateAS"] = true;
                properties["removePrivateASLmtd"] = bgpGroupConfig["remove-private"]["limited"];
                properties["removePrivateSkipPeerAs"] = bgpGroupConfig["remove-private"]["skip-peer-as"];
            }
        }

        if(bgpGroupConfig["cluster"])
        {
            if(bgpGroupConfig["cluster"]["cluster-id"])
            {
                inheritanceMaskBits.push("clusterId");
                properties["clusterId"] = bgpGroupConfig["cluster"]["cluster-id"];
            }
        }

        if(bgpGroupConfig["local-as"])
        {
            if(bgpGroupConfig["local-as"]["as-number"])
            {
                inheritanceMaskBits.push("localAS");
                properties["localAS"] = bgpGroupConfig["local-as"]["as-number"];
            }
            if(bgpGroupConfig["local-as"]["private"])
            {
                inheritanceMaskBits.push("localASPrivate");
                properties["localASPrivate"] = bgpGroupConfig["local-as"]["private"];
            }
        }

        if(bgpGroupConfig["graceful-restart"])
        {
            inheritanceMaskBits.push("gracefulRestart");
            properties["gracefulRestart"] = true;
            if(bgpGroupConfig["graceful-restart"]["restart-time"])
            {
                properties["grRestartTime"] = bgpGroupConfig["graceful-restart"]["restart-time"];
            }
            if(bgpGroupConfig["graceful-restart"]["stale-routes-time"])
            {
                properties["staleRoutesTime"] = bgpGroupConfig["graceful-restart"]["stale-routes-time"];
            }
        }

        if(bgpGroupConfig["outbound-route-filtering"])
        {
            if(bgpGroupConfig["outbound-route-filtering"]["extended-community"])
            {
                if(bgpGroupConfig["outbound-route-filtering"]["extended-community"]["accept-orf"])
                {
                    inheritanceMaskBits.push("acceptOrf");
                    properties["acceptOrf"] = bgpGroupConfig["outbound-route-filtering"]["extended-community"]["accept-orf"];
                }
                if (bgpGroupConfig["outbound-route-filtering"]["extended-community"]["send-orf"] == "")
                {
                    inheritanceMaskBits.push("sendOrf");
                    properties["sendOrf"] = true;
                }
            }
        }
        var childProperties = {};

        if(isAudit == false)
        {
            var md5AuthKey = {};
            if(bgpGroupConfig["authentication-key"])
            {
                md5AuthKey["inheritanceMask"] = {};
                md5AuthKey["inheritanceMask"]["bit"] = ["md5Auth", "md5AuthKey"];
                md5AuthKey["type"] = "md5";
                md5AuthKey["key"] = bgpGroupConfig["authentication-key"];
            }

            childProperties["bgp.Md5Key"] = md5AuthKey;
        }

        var groupImportPolicies = {};
        if(bgpGroupConfig["import"] && bgpGroupConfig["import"]["policy"])
        {
            inheritanceMaskBits.push("importPolicy1");
            if (!Array.isArray(bgpGroupConfig["import"]["policy"]))
            {
                bgpGroupConfig["import"]["policy"] = [bgpGroupConfig["import"]["policy"]];
            }

            for (var index in bgpGroupConfig["import"]["policy"])
            {
                groupImportPolicies["policy"+(parseInt(index)+1)] = bgpGroupConfig["import"]["policy"][index];
            }
            for (var i= bgpGroupConfig["import"]["policy"].length + 1; i<=15; i++)
            {
                groupImportPolicies["policy"+i] = ""
            }
            if(isAudit == false)
            {
                groupImportPolicies["inheritanceMask"] = {};
                groupImportPolicies["inheritanceMask"]["bit"] = ["policy1","policy2","policy3","policy4","policy5"];
                groupImportPolicies["inheritValue"] = false;
            }
        }
        else
        {
            if(isAudit == false)
            {
                groupImportPolicies["inheritanceMask"] = undefined;
                groupImportPolicies["inheritValue"] = true;
            }
        }
        childProperties["bgp.GroupImportPolicy"] = groupImportPolicies;

        var groupExportPolicies = {};
        if(bgpGroupConfig["export"] && bgpGroupConfig["export"]["policy"])
        {
            inheritanceMaskBits.push("exportPolicy1");
            if (!Array.isArray(bgpGroupConfig["export"]["policy"]))
            {
                bgpGroupConfig["export"]["policy"] = [bgpGroupConfig["export"]["policy"]];
            }

            for (var index in bgpGroupConfig["export"]["policy"])
            {
                groupExportPolicies["policy"+(parseInt(index)+1)] = bgpGroupConfig["export"]["policy"][index];
            }
            for (var i= bgpGroupConfig["export"]["policy"].length + 1; i<=15; i++)
            {
                groupExportPolicies["policy"+i] = ""
            }
            if(isAudit == false)
            {
                groupExportPolicies["inheritanceMask"] = {};
                groupExportPolicies["inheritanceMask"]["bit"] = ["policy1","policy2","policy3","policy4","policy5"];
                groupExportPolicies["inheritValue"] = false;
            }
        }
        else
        {
            if(isAudit == false)
            {
                groupExportPolicies["inheritanceMask"] = undefined;
                groupExportPolicies["inheritValue"] = true;
            }
        }
        childProperties["bgp.GroupExportPolicy"] = groupExportPolicies;

        if(isAudit == true)
        {
            properties["inheritanceMask"] = inheritanceMaskBits;
            objectPropMap[fullClassName + "|" +objectFullName] = properties
        }
        else
        {
            properties["inheritanceMask"]["bit"] = inheritanceMaskBits;
        }

        var bgpNeighboursPayload = [];
        if (intentConfig["neighbor"])
        {
            if (!Array.isArray(intentConfig["neighbor"]))
            {
                intentConfig["neighbor"] = [intentConfig["neighbor"]];
            }
            var bgpNeighboursPayload = [];
            for (var index in intentConfig["neighbor"])
            {
                var bgpNeighbourConfig = intentConfig["neighbor"][index];
                var bgpNeighbourFullName = objectFullName + ":" + "peer-" + bgpNeighbourConfig["ip-address"];
                //keeping key and value same as object full name of the queue
                mapFwk.set(currentObjects, bgpNeighbourFullName, bgpNeighbourFullName);
                var neighbourPayload = this.createbgpNeighbourPayLoad(target, bgpNeighbourConfig, bgpGroupConfig["group-name"]);
                bgpNeighboursPayload.push(neighbourPayload);
            }
        }
        childProperties["bgp.Peer"] = bgpNeighboursPayload;

        var bgpGroupLevelPayload = util.editPayload(bgpFdn, properties, childProperties, fullClassName, objectFullName);
        return bgpGroupLevelPayload;
    }

    this.createbgpNeighbourPayLoad = function (target, neighbourConfig, groupName)
    {
        var nodeType = mdtfwk.getTypeAndVersion(target);
        var fullClassName = "bgp.Peer";
        var bgpGroupFdn = "network:" + target + ":router-1:bgp" + ":group-" + groupName;
        if (target && String(target).indexOf(':') !== -1) {
            bgpGroupFdn = util.modifyNeIdForIpV6(bgpGroupFdn, target);
        }
        var properties = {};

        if(neighbourConfig["ip-address"])
        {
            var objectFullName = "";
            if(this.isValidIPv6Address(neighbourConfig["ip-address"]))
            {
                properties["peerAddress"] = util.expandIPv6Address(neighbourConfig["ip-address"]);
                objectFullName = bgpGroupFdn + ":peer-" + (properties["peerAddress"]).replaceAll(":", "_");
                properties["peerAddressType"] = "ipv6";
            }
            else
            {
                properties["peerAddress"] = neighbourConfig["ip-address"];
                objectFullName = bgpGroupFdn + ":peer-" + properties["peerAddress"];
                properties["peerAddressType"] = "ipv4";
            }
        }
        properties["inheritanceMask"] = {};
        var inheritanceMaskBits = [];

        if(neighbourConfig["admin-state"] != "enable")
        {
            inheritanceMaskBits.push("administrativeState");
            properties["administrativeState"] = "bgpDown";
        }

        if(neighbourConfig["connect-retry"])
        {
            properties["connectRetryTime"] = neighbourConfig["connect-retry"];
            inheritanceMaskBits.push("connectRetryTime");
        }

        if(neighbourConfig["keepalive"])
        {
            properties["keepAlive"] = neighbourConfig["keepalive"];
            inheritanceMaskBits.push("keepAlive");
        }

        if(neighbourConfig["damping"])
        {
            properties["damping"] = neighbourConfig["damping"];
            inheritanceMaskBits.push("damping");
        }

        if(neighbourConfig["local-preference"])
        {
            properties["localPreference"] = neighbourConfig["local-preference"];
            inheritanceMaskBits.push("localPreference");
        }

        if(neighbourConfig["min-route-advertisement"])
        {
            properties["minRouteAdvertisement"] = neighbourConfig["min-route-advertisement"];
            inheritanceMaskBits.push("minRouteAdvertisement");
        }

        if(neighbourConfig["loop-detect"])
        {
            properties["loopDetect"] = util.transformLoopDetect(neighbourConfig["loop-detect"]);
            inheritanceMaskBits.push("loopDetect");
        }

        if(neighbourConfig["aggregator-id-zero"])
        {
            inheritanceMaskBits.push("aggregatorIdZero");
            properties["aggregatorIdZero"] = neighbourConfig["aggregator-id-zero"];
        }

        properties["preference"] = neighbourConfig["preference"];
        if(neighbourConfig["preference"])
        {
            inheritanceMaskBits.push("preference");
        }

        properties["multiHop"] = neighbourConfig["multihop"];
        if(neighbourConfig["multihop"])
        {
            inheritanceMaskBits.push("multiHop");
        }

        if(!nodeType["type"].startsWith("7210"))
        {
            if(neighbourConfig["client-reflect"] == undefined || neighbourConfig["client-reflect"] == false)
            {
                inheritanceMaskBits.push("disableClientReflect");
                properties["disableClientReflect"] = true;
            }
        }

        if(neighbourConfig["vpn-apply-export"])
        {
            inheritanceMaskBits.push("vpnApplyExport");
            properties["vpnApplyExport"] = neighbourConfig["vpn-apply-export"];
        }

        if(neighbourConfig["vpn-apply-import"])
        {
            inheritanceMaskBits.push("vpnApplyImport");
            properties["vpnApplyImport"] = neighbourConfig["vpn-apply-import"];
        }

        if(!nodeType["type"].startsWith("7705"))
        {
            if(neighbourConfig["asn-4-byte"] == undefined || neighbourConfig["asn-4-byte"] == false)
            {
                inheritanceMaskBits.push("disable4ByteASN");
                properties["disable4ByteASN"] = true;
            }
        }

        if(neighbourConfig["local-address"])
        {
            if(this.isValidIPAddress(neighbourConfig["local-address"]) ||
                this.isValidIPv6Address(neighbourConfig["local-address"]))
            {
                if(neighbourConfig["local-address"] != "0.0.0.0" &&
                    neighbourConfig["local-address"] !="0:0:0:0:0:0:0:0")
                {

                    inheritanceMaskBits.push("localAddress");
                    inheritanceMaskBits.push("localAddressType");
                    if(this.isValidIPv6Address(neighbourConfig["local-address"]))
                    {
                        properties["localAddress"] = util.expandIPv6Address(neighbourConfig["local-address"]);
                    }
                    else
                    {
                        properties["localAddress"] = neighbourConfig["local-address"];
                    }
                }
            }
        }

        if(neighbourConfig["l2vpn-cisco-interop"])
        {
            inheritanceMaskBits.push("l2vpnCiscoInterop");
            properties["l2vpnCiscoInterop"] = neighbourConfig["l2vpn-cisco-interop"];
        }

        if(neighbourConfig["next-hop-self"])
        {
            inheritanceMaskBits.push("nextHopSelf");
            properties["nextHopSelf"] = neighbourConfig["next-hop-self"];
        }

        if(neighbourConfig["passive"])
        {
            inheritanceMaskBits.push("passive");
            properties["passive"] = neighbourConfig["passive"];
        }

        if(neighbourConfig["peer-as"])
        {
            inheritanceMaskBits.push("peerAS");
            properties["peerAS"] = neighbourConfig["peer-as"];
        }

        if(!nodeType["type"].startsWith("7705"))
        {
            if(neighbourConfig["capability-negotiation"] == undefined || neighbourConfig["capability-negotiation"] == false)
            {
                inheritanceMaskBits.push("disableCapabilityNegotiation");
                properties["disableCapabilityNegotiation"] = true;
            }
        }

        if(neighbourConfig["hold-time"])
        {
            if(neighbourConfig["hold-time"]["seconds"])
            {
                properties["holdTime"] = neighbourConfig["hold-time"]["seconds"];
                inheritanceMaskBits.push("holdTime");
            }
            if(neighbourConfig["hold-time"]["minimum-hold-time"])
            {
                properties["minHoldTime"] = neighbourConfig["hold-time"]["minimum-hold-time"];
            }
        }

        if(neighbourConfig["family"])
        {
            var family = {};
            var familyBits = [];
            for (var familyType in neighbourConfig["family"])
            {
                if(neighbourConfig["family"][familyType])
                {
                    familyBits.push(util.getNfmpFamilyName(familyType));
                }
            }
            if(familyBits.length > 0)
            {
                if(isAudit == false)
                {
                    family["bit"] = familyBits;
                    properties["family"] = family;
                }
                else
                {
                    properties["family"] = familyBits;
                }
                inheritanceMaskBits.push("family");
            }
        }

        if(neighbourConfig["remove-private"])
        {
            if(neighbourConfig["remove-private"]["limited"] ||
                neighbourConfig["remove-private"]["skip-peer-as"])
            {
                inheritanceMaskBits.push("removePrivateAS");
                properties["removePrivateAS"] = true;
                properties["removePrivateASLmtd"] = neighbourConfig["remove-private"]["limited"];
                properties["removePrivateSkipPeerAs"] = neighbourConfig["remove-private"]["skip-peer-as"];
            }
        }

        if(neighbourConfig["cluster"])
        {
            if(neighbourConfig["cluster"]["cluster-id"])
            {
                inheritanceMaskBits.push("clusterId");
                properties["clusterId"] = neighbourConfig["cluster"]["cluster-id"];
            }
        }

        if(neighbourConfig["local-as"])
        {
            if(neighbourConfig["local-as"]["as-number"])
            {
                inheritanceMaskBits.push("localAS");
                properties["localAS"] = neighbourConfig["local-as"]["as-number"];
            }
            if(neighbourConfig["local-as"]["private"])
            {
                inheritanceMaskBits.push("localASPrivate");
                properties["localASPrivate"] = neighbourConfig["local-as"]["private"];
            }
        }

        if(neighbourConfig["graceful-restart"])
        {
            inheritanceMaskBits.push("gracefulRestart");
            properties["gracefulRestart"] = true;
            if(neighbourConfig["graceful-restart"]["restart-time"])
            {
                properties["grRestartTime"] = neighbourConfig["graceful-restart"]["restart-time"];
            }
            if(neighbourConfig["graceful-restart"]["stale-routes-time"])
            {
                properties["staleRoutesTime"] = neighbourConfig["graceful-restart"]["stale-routes-time"];
            }
        }

        if(neighbourConfig["outbound-route-filtering"])
        {
            if(neighbourConfig["outbound-route-filtering"]["extended-community"])
            {
                if(neighbourConfig["outbound-route-filtering"]["extended-community"]["accept-orf"])
                {
                    inheritanceMaskBits.push("acceptOrf");
                    properties["acceptOrf"] = neighbourConfig["outbound-route-filtering"]["extended-community"]["accept-orf"];
                }
                if(neighbourConfig["outbound-route-filtering"]["extended-community"]["send-orf"] == "")
                {
                    inheritanceMaskBits.push("sendOrf");
                    properties["sendOrf"] = true;
                }
            }
        }

        var childProperties = {};

        if(isAudit == false)
        {
            var md5AuthKey = {};
            if(neighbourConfig["authentication-key"])
            {
                md5AuthKey["inheritanceMask"] = {};
                md5AuthKey["inheritanceMask"]["bit"] = ["md5Auth", "md5AuthKey"];
                md5AuthKey["type"] = "md5";
                md5AuthKey["key"] = neighbourConfig["authentication-key"];
            }

            childProperties["bgp.Md5Key"] = md5AuthKey;
        }

        var peerImportPolicies = {};
        if(neighbourConfig["import"] && neighbourConfig["import"]["policy"])
        {
            inheritanceMaskBits.push("importPolicy1");
            if (!Array.isArray(neighbourConfig["import"]["policy"]))
            {
                neighbourConfig["import"]["policy"] = [neighbourConfig["import"]["policy"]];
            }

            for (var index in neighbourConfig["import"]["policy"])
            {
                peerImportPolicies["policy"+(parseInt(index)+1)] = neighbourConfig["import"]["policy"][index];
            }
            for (var i= neighbourConfig["import"]["policy"].length + 1; i<=15; i++)
            {
                peerImportPolicies["policy"+i] = ""
            }
            if(isAudit == false)
            {
                peerImportPolicies["inheritanceMask"] = {};
                peerImportPolicies["inheritanceMask"]["bit"] = ["policy1","policy2","policy3","policy4","policy5"];
                peerImportPolicies["inheritValue"] = false;
            }
        }
        else
        {
            if(isAudit == false)
            {
                peerImportPolicies["inheritanceMask"] = undefined;
                peerImportPolicies["inheritValue"] = true;
            }
        }
        childProperties["bgp.PeerImportPolicy"] = peerImportPolicies;

        var peerExportPolicies = {};
        if(neighbourConfig["export"] && neighbourConfig["export"]["policy"])
        {
            inheritanceMaskBits.push("exportPolicy1");
            if (!Array.isArray(neighbourConfig["export"]["policy"]))
            {
                neighbourConfig["export"]["policy"] = [neighbourConfig["export"]["policy"]];
            }

            for (var index in neighbourConfig["export"]["policy"])
            {
                peerExportPolicies["policy"+(parseInt(index)+1)] = neighbourConfig["export"]["policy"][index];
            }
            for (var i= neighbourConfig["export"]["policy"].length + 1; i<=15; i++)
            {
                peerExportPolicies["policy"+i] = ""
            }
            if(isAudit == false)
            {
                peerExportPolicies["inheritanceMask"] = {};
                peerExportPolicies["inheritanceMask"]["bit"] = ["policy1","policy2","policy3","policy4","policy5"];
                peerExportPolicies["inheritValue"] = false;
            }
        }
        else
        {
            if(isAudit == false)
            {
                peerExportPolicies["inheritanceMask"] = undefined;
                peerExportPolicies["inheritValue"] = true;
            }
        }
        childProperties["bgp.PeerExportPolicy"] = peerExportPolicies;

        if(isAudit == true)
        {
            properties["inheritanceMask"] = inheritanceMaskBits;
            objectPropMap[fullClassName+ "|" +objectFullName] = properties
        }
        else
        {
            properties["inheritanceMask"]["bit"] = inheritanceMaskBits;
        }

        var peerPrefixLimits = [];
        if(neighbourConfig["prefix-limit"])
        {
            if (!Array.isArray(neighbourConfig["prefix-limit"]))
            {
                neighbourConfig["prefix-limit"] = [neighbourConfig["prefix-limit"]];
            }

            for (var index in neighbourConfig["prefix-limit"])
            {
                var properties1 = {};
                var prefixLimit = neighbourConfig["prefix-limit"][index];
                properties1["family"] = util.getNfmpPrefixFamilyName(prefixLimit["family"]);
                properties1["prefixLogOnly"] = prefixLimit["log-only"];
                properties1["prefixLimit"] = prefixLimit["maximum"];
                properties1["prefixThreshold"] = prefixLimit["threshold"];
                if(prefixLimit["log-only"] == true)
                {
                    if(!nodeType["type"].startsWith("7210"))
                    {
                        properties1["prefixIdleTimeOut"] = 0;
                    }
                }
                else
                {
                    properties1["prefixIdleTimeOut"] = prefixLimit["idle-timeout"];
                }
                properties1["postImport"] = prefixLimit["post-import"];
                peerPrefixLimits.push(properties1);
            }
        }
        childProperties["bgp.PrefixLimit"] = peerPrefixLimits;
        properties["children-Set"] = childProperties;

        return properties;
    }

    this.syncDelete = function (input, result)
    {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var bgpGroupName = parseTarget.getUniqueIdentifier(input.getTarget());

        var objectFullName = "network:" + neId + ":router-1:bgp:group-" + bgpGroupName;
        if (neId && String(neId).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        }
        logger.info("[NFMP-BGP-GROUP] syncDelete(): Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success)
        {
            logger.info("[NFMP-BGP-GROUP] syncDelete(): Unable to Delete: " + deleteResult.msg);
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }

    this.modifyRequest = function (target, payload)
    {

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.xml2object = function (xmlElement)
    {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }

    this.removeEmptyContainers = function (prop, intentJson, path, target)
    {

        if (Array.isArray(intentJson))
        {
            var object = [];
            for (var prop in intentJson)
            {
                var value = this.removeEmptyContainers(prop, intentJson[prop], path, target);
                if (value)
                {
                    object.push(value);
                }

            }
            if (Object.keys(object).length !== 0)
            {
                return object;
            }
        } else if (typeof intentJson == 'object')
        {
            var object = {};
            for (var prop in intentJson)
            {
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop, intentJson[prop], pPath, target);
                if ((value && value !== null) || value == 0)
                {
                    object[prop] = value;
                }

            }
            if (Object.keys(object).length !== 0)
            {
                return object;
            }
        } else
        {
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if (intentJson !== undefined && intentJson !== "")
            {
                return intentJson;
            }

            return null;
        }
    }

    this.loadSavedObjectsFromTopology = function (savedTopology)
    {

        if (savedTopology)
        {
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0)
            {
                topoObjects.forEach(function (topoObject)
                {
                    mapFwk.set(savedObjects, topoObject.getObjectType(), topoObject.getObjectRelativeObjectID());
                });
            }
        }

    }

    this.loadCurrentObjectsToTopology = function (target)
    {

        var currentTopo = topologyFactory.createServiceTopology();
        if (Object.keys(currentObjects).length)
        {
            for (var key in currentObjects)
            {
                objectId = mapFwk.get(currentObjects, key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key, objectId, "INFRASTRUCTURE", target, ""));
            }
        }
        return currentTopo;

    }

    this.auditRequest = function (target, payload)
    {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.isValidIPAddress = function(ipAddress)
    {
        if (/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(ipAddress))
        {
            return (true);
        }
        return (false);
    }

    this.isValidIPv6Address = function(ipAddress)
    {
        if (/^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$|^::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})$|^([0-9a-fA-F]{1,4}:){1,7}:$|^fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}$|^::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})%[0-9a-zA-Z]{1,}$|^:((:[0-9a-fA-F]{1,4}){1,7}|:)$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,5}|:)$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,4}|:)$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,3}|:)$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,2}|:)$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1}|:)$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,2})$|^(([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,2})$|^([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])$|^:((:[0-9a-fA-F]{1,4}){1,7}|:)$/.test(ipAddress))
        {
            return (true);
        }
        return (false);
    }
}
