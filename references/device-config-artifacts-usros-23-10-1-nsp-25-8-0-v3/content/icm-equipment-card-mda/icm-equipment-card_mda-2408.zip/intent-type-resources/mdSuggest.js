function MdSuggest() {
    this.getCardTypes = function (neId, slotId) {
        var url = "/restconf/meta/api/v1/model/schema/" + neId + "/nokia-conf:/configure/card";
        return this.getData(neId, url, "card-type");
    }
    this.getMdaTypes = function (neId, slotId, xiomSlotId, mdaSlotId) {
        var url = "/restconf/meta/api/v1/model/schema/" + neId + "/nokia-conf:/configure/card/mda";
        if (xiomSlotId)
        {
            url = "/restconf/meta/api/v1/model/schema/" + neId + "/nokia-conf:/configure/card/xiom/mda";
        }
        return this.getData(neId, url, "mda-type");
    }
    this.getXiomTypes = function (neId, slotId, xiomSlotId) {
        var url = "/restconf/meta/api/v1/model/schema/" + neId + "/nokia-conf:/configure/card/xiom";
        return this.getData(neId, url, "xiom-type");
    }

    this.getData = function (neId, url, slot) {
        var mdcFwk = new MdcFwk();
        logger.info("MdSuggest--getData---neId={}, url={}", neId, url);
        var result = [];
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info("MDC resultFetch =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");

        var finalResponse = resultFetch.msg.attributes;
        logger.info("finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse))
        {
            for (var index in finalResponse)
            {
                var config = finalResponse[index];
                if (config['name'] === slot)
                {
                    var type = config['enum'];
                    //logger.info("Type = " + JSON.stringify(type));
                    if (Array.isArray(type))
                    {
                        for (var typeIndex in type)
                        {
                            //logger.info("Type = " + type[typeIndex]['name'])
                            ret.push(type[typeIndex]['name'])
                        }
                    }
                }
            }
        }
        if (!Array.isArray(ret))
        {
            ret = [ret];
        }
        //logger.info("ret = \n" + JSON.stringify(ret));
        var data = ret.map(function (slotType) {
            logger.info(slotType);
            var obj = {};
            obj[slot] = slotType;
            return obj;
        });
        logger.info("data = \n" + JSON.stringify(data));
        logger.info("Sorting the data");
        data.sort((a, b) => {
            if (a[slot] < b[slot]) {
            return -1;
            }
            if (a[slot] > b[slot]) {
            return 1;
            }
            return 0;
        });
        logger.info("data after sorting= \n" + JSON.stringify(data));
        result["data"] = JSON.stringify(data);
        logger.info("result = \n" + JSON.stringify(result));
        return result;
    }
}