
function CommonUtil() {
  /**
   * Get deviceConfig
   * @param {*} neId
   * @param {*} rootXPath
   * @param {*} intentContainer
   * @param {*} deviceYangModuleName
   * @returns
   */
  const getDeviceConfig = (
    neId,
    rootXPath,
    intentContainer,
    deviceYangModuleName,
    uniqueIdentifierValue
  ) => {
    let url = getUrl(
      neId,
      rootXPath,
      intentContainer,
      deviceYangModuleName,
      uniqueIdentifierValue
    );
    logger.info("url " + url);
    let deviceConfigResult = mdcFwk.fetch(neId, url);
    if (!deviceConfigResult["success"]) {
      throw new RuntimeException(deviceConfigResult["msg"]);
    }
    let containerKey;
    if(rootXPath.endsWith(":")){
      let moduleRef = getModuleRef(rootXPath);
      if(moduleRef){
        containerKey = moduleRef + ":" + intentContainer;
      }else {
         containerKey = deviceYangModuleName + ":" + intentContainer;
      }
    }else {
      containerKey = deviceYangModuleName + ":" + intentContainer;
    }
   
    let deviceConfig = deviceConfigResult["msg"][containerKey][0];
    logger.info("deviceConfig " + JSON.stringify(deviceConfig));
    return deviceConfig;
  };

  /**
   * Get the url for mdc
   * @param {} target
   * @returns
   */
  const getDeviceUrl = (target) => {
    return (
      "/restconf/data/network-device-mgr:network-devices/network-device=" +
      target +
      "/root/"
    );
  };

  /**
   *
   * @param {*} neId
   * @param {*} rootXPath
   * @param {*} intentContainer
   * @param {*} uniqueIdentifierValue
   * @returns
   */
  const getUrl = (
    neId,
    rootXPath,
    intentContainer,
    deviceYangModuleName,
    uniqueIdentifierValue
  ) => {
    let url = "";
    logger.info("------ Generating url ------");
    logger.info("neId device " + neId);
    logger.info("rootXPath " + rootXPath);
    logger.info("intentContainer " + intentContainer);
    logger.info("uniqueIdentifierValue " + uniqueIdentifierValue);

    if (!isFalsy(rootXPath)) {
      // module reference case in rootXPath
      if (rootXPath.endsWith(":")) {
        url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/${deviceYangModuleName}:/${rootXPath}${intentContainer}`;
      } else {
        url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/${deviceYangModuleName}:/${rootXPath}/${intentContainer}`;
      }
    } else {
      url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/${deviceYangModuleName}:/${intentContainer}`;
    }

    if (!isFalsy(uniqueIdentifierValue)) {
      logger.info("uniqueIdentifierValue " + uniqueIdentifierValue);
      url = url + "=" + encodeString(uniqueIdentifierValue);
    }
    url = url + "?content=config";
    logger.info("------ Generating url done and url is ------" + url);
    return url;
  };

  /**
   *
   * @param {*} value
   * @returns
   */
  const isFalsy = (value) => {
    if (value === undefined || value === null || value === "") {
      return true;
    } else {
      return false;
    }
  };

  /**
   * Encode the string
   * @param {*} key
   * @returns
   */
  const encodeString = (str) => {
    let new_array = [];
    let new_str;
    if (_.isArray(str)) {
      str.forEach((identifier) => {
        new_array.push(identifier.replace(/\//g,"%2F").replace(/:/g,"%3A"));
      })
      new_str = new_array.join(",").toString();
    } else {
      new_str = str.replace(/\//g, "%2F").replace(/:/g,"%3A");
    }
    return new_str;
  };

  /**
   * Check if the neType is SRLinux
   * @param {} neType
   * @returns
   */
  function isSRLinux(neType) {
    const regex = /SRLinux/g;
    const matches = neType && neType.match(regex);
    return matches ? true : false;
  }

  /**
   * Remove the moduleRef from deviceConf
   * @param {} deviceConf - the deviceConf
   */
  const removeModuleRef = (deviceConf) => {
    if (deviceConf != null) {
      if(_.isArray(deviceConf)){
        deviceConf.forEach(config => {
          removeModuleRef(config)
        })
      } else if(typeof deviceConf === "object"){
        let keys = Object.keys(deviceConf);
        keys.forEach((key) => {
          // top level key
          key = replaceKey(key, deviceConf)
          let value = deviceConf[key];
          if (Array.isArray(value)) {
            // iterate over each element in the array
            value.forEach((v, index) => {
              if(typeof v ==="object"){
              removeModuleRef(v);
              }else {
                // when value is array with integer or string
                let newValue = getValue(v);
                value[index] = newValue;
              }
            });
          } else if (typeof value === "object") {
            // recurse
            removeModuleRef(value);
          } else {
            if (value && _.includes(value, ":")) {
              replaceValue(key, value, deviceConf)
            }
          }
        });
      }else {
        if (deviceConf && _.includes(deviceConf, ":")) {
          replaceValue(key, value, deviceConf)
        }
      }
    } 
  };


  /**
   * remove the moduleReference from the key and replace it in the object
   * @param {*} key 
   * @param {*} object 
   */
  const replaceKey = (key, object) => {
    if (key && _.includes(key, ":")) {
      let newKey;
      let m = key.split(":")
      if (m.length > 2) {
        // this is case with multiple colon in the key
        let parts = key.split(':');
        parts.shift();
        newKey = parts.join(':');
      } else {
        newKey = m[1];
      }
      const descriptor = Object.getOwnPropertyDescriptor(object, key);
      if (descriptor) {
        Object.defineProperty(object, newKey, descriptor);
        delete object[key];
      }
      key = newKey;
    }
    return key;
  }

  /**
   * remove moduleRef in the value
   * @param {*} key 
   * @param {*} value 
   * @param {*} deviceConf 
   */
  const replaceValue = (key, value, deviceConf) => {
    if (_.includes(value, ":")) {
      let count = value.split(":").length;
      if(count <= 2){
        value = value.split(":")[1];
      }else {
        if(_.includes(value, "srl_")){
          value = value.substring(value.indexOf(value.split(":")[1]))
        }
        //value = value.split(":")[1];
      }
      deviceConf[key] = value;
    }
  }

  /**
   * remove moduleRef in the value
   * @param {*} key 
   * @param {*} value 
   * @param {*} deviceConf 
   */
  const getValue = (value) => {
    if (_.includes(value, ":")) {
      let count = value.split(":").length;
      if(count <= 2){
        if(_.includes(value, "srl_")){
          value = value.split(":")[1];
        }
      }else {
        if(_.includes(value, "srl_")){
          value = value.substring(value.indexOf(value.split(":")[1]))
        }
      }
    }
    return value;
  }
  
  /**
   * Get the module reference from rootXPath
   * @param {*} rootXPath 
   * @returns 
   */
  const getModuleRef = (rootXPath) => {
    let lastIndexOfColon = rootXPath.lastIndexOf(":");
    let lastIndexOfSlash = rootXPath.lastIndexOf("/");
    let moduleRef = rootXPath.substring(lastIndexOfSlash + 1, lastIndexOfColon);
    logger.info("moduleRef " + moduleRef);
    return moduleRef;
  }

  const prefixToSubnetConvert = (prefixval)=> {
    if (prefixval != undefined && prefixval && prefixval <= 32 && !isNaN(prefixval)) {
        var submask = [],
            converstion;
        for (var i = 0; i < 4; i++) {
            converstion = Math.min(prefixval, 8);
            submask.push(256 - Math.pow(2, 8 - converstion));
            prefixval -= converstion;
        }
        return submask.join('.');
    }
};

const subnetToPrefixConvert = (submask) => {
    var submaskArr = submask.split(".");
    var prefixval = 0;
    for (var i = 0; i < submaskArr.length; i++) {
        var subnetval = parseInt(submaskArr[i]);
        if (subnetval == 255) {
            prefixval += 8;
        } else if (subnetval < 255) {
            var bitArr = [128, 64, 32, 16, 8, 4, 2, 1];
            if (subnetval == bitArr[0]) {
                prefixval += 1;
            } else if (bitArr[0] < subnetval) {
                var bitcount = 0;
                for (var j = 0; j < bitArr.length; j++) {
                    bitcount += bitArr[j];
                    prefixval += 1;
                    if (subnetval == bitcount) {
                        break;
                    }

                }
            }
        } else {
            prefixval += 0;
        }
    }
    return prefixval;
};

  this.getDeviceConfig = getDeviceConfig;
  this.getDeviceUrl = getDeviceUrl;
  this.getUrl = getUrl;
  this.encodeString = encodeString;
  this.isSRLinux = isSRLinux;
  this.removeModuleRef = removeModuleRef;
  this.prefixToSubnetConvert = prefixToSubnetConvert;
  this.subnetToPrefixConvert = subnetToPrefixConvert;
}

// hackish way to use CommonUtil in test, due to non-support of export in IM
testCommonUtil = CommonUtil;
