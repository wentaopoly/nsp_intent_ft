/*
 *
 * The intent of this framework is to provide a set of useful helper methods that
 * can be used while writing intents for MDT.
 *
 */

function MdtFwk() {
  /**
    Get Manager information in JSON format for given device ip
    Input : device IP 
    out put:  ManagerConfig 
  */
  this.getManagerConfig = function (deviceName) {
    var managerInfos = mds.getAllManagersWithDevice(deviceName);
    if (managerInfos == null || managerInfos.isEmpty()) {
      throw new RuntimeException("Manager not found for device " + deviceName);
    }

    var managerInfo = managerInfos.get(0);
    var managerConfig = {
      ip: managerInfo.getIp(),
      port: managerInfo.getPort(),
      name: managerInfo.getName(),
    };
    return managerConfig;
  };

  /**
   *
   * @param {*} deviceName
   * @returns
   */
  this.getManagerName = function (deviceName) {
    var managerConfig = this.getManagerConfig(deviceName);
    logger.info("Manager info: " + JSON.stringify(managerConfig));
    return managerConfig.name;
  };

  /**
   *
   * @param {*} context
   * @param {*} deviceTypes
   * @returns
   */
  this.suggestDeviceNames = function (context, deviceTypes) {
    var returnVal = {};
    var Collectors = Java.type("java.util.stream.Collectors");

    var managerNames = mds.getAllManagersOfType("REST");
    var devices;
    if (managerNames) {
      var managedDevices = mds.getAllManagedDevicesFrom(managerNames);
      devices = managedDevices
        .stream()
        .filter(function (device) {
          var family = device.getFamilyTypeRelease().split(":")[0];
          return deviceTypes.indexOf(family) !== -1;
        })
        .map(function (device) {
          return device.getName();
        })
        .collect(Collectors.toList());
    }
    if (devices) {
      var searchQuery = context.getSearchQuery();
      devices.forEach(function (device) {
        if (searchQuery) {
          if (device.startsWith(searchQuery)) {
            returnVal[device] = device;
          }
        } else {
          returnVal[device] = device;
        }
      });
    }
    return returnVal;
  };

  /**
   *
   * @param {*} deviceName
   * @returns
   */
  this.getTypeAndVersion = function (deviceName) {
    this.checkManagerConnectionState(deviceName);
    var deviceInfos = mds.getAllInfoFromDevices(deviceName);
    logger.info("[MDT-FWK] deviceInfos" + deviceInfos);
    if (null == deviceInfos || deviceInfos.size() === 0) {
      throw new RuntimeException("Device not found :" + deviceName);
    }
    var deviceInfo = deviceInfos.get(0);
    var deviceType = deviceInfo.getFamilyTypeRelease();
    if (deviceType == null) {
      throw new RuntimeException(
        "Device Family type and release not found for device: " + deviceName
      );
    }
    var typeAndVersion = deviceType.split(":");
    logger.info("[MDT-FWK] Device typeAndVersion:" + typeAndVersion);
    var typeAndVersionMap;
    typeAndVersionMap = {
      type: typeAndVersion[0],
      version: typeAndVersion[1],
    };
    return typeAndVersionMap;
  };

  /**
   *
   * @param {*} deviceName
   */
  this.checkManagerConnectionState = function (deviceName) {
    var managerInfos = mds.getAllManagersWithDevice(deviceName);
    if (managerInfos == null || managerInfos.isEmpty()) {
      throw new RuntimeException("Manager not found for device " + deviceName);
    }
    var managerInfo = managerInfos.get(0);
    if (managerInfo.getConnectivityState().toString() === "DISCONNECTED") {
      var managerType = managerInfo.getType().toString();
      var managerName = managerInfo.getName();
      if (managerType === "MDC") {
        throw new RuntimeException("Can't connect to MDC :" + managerName);
      } else {
        throw new RuntimeException("Can't connect to Manager : " + managerName);
      }
    }
  };

  /**
   *
   * @param {*} node
   * @param {*} ns
   * @param {*} tagName
   * @returns
   */
  this.extractElement = function (node, ns, tagName) {
    return this.extractElement(node, ns, tagName, false);
  };

  /**
   *
   * @param {*} node
   * @param {*} ns
   * @param {*} tagName
   * @param {*} raw
   * @returns
   */
  this.extractElement = function (node, ns, tagName, raw) {
    var element = node.getElementsByTagNameNS(ns, tagName);
    if (raw) {
      return element;
    }
    if (element) {
      var item = element.item(0);
      if (item) {
        return item.getTextContent().trim();
      }
    }
    logger.info(null, "Failed to extract element: " + tagName);
    return "";
  };

  /**
   * TODO document what this function takes and what it returns
   * @param target The intent-instance-name or serviceName
   * @param specificConfig
   * @param serviceId The serviceId
   * */

  this.getTopoObjects = function (
    target,
    specificConfig,
    serviceId,
    serviceType,
    serviceIdKey
  ) {
    var myTopo = topologyFactory.createServiceTopology();
    this.addTopologyExtraInfo(
      myTopo,
      target,
      serviceId,
      serviceType,
      serviceIdKey
    );
    var nodalArgsMap = this.groupEndpointsForNode(specificConfig);
    for (var device in nodalArgsMap) {
      var deviceName = device;
      var endpoints = nodalArgsMap[device];
      for (i = 0; i < endpoints.length; i++) {
        var interfaceName = "";
        if (endpoints[i].innerTag == "-1") {
          interfaceName =
            "Interface " + endpoints[i].portId + ":" + endpoints[i].outerTag;
        } else {
          interfaceName =
            "Interface " +
            endpoints[i].portId +
            ":" +
            endpoints[i].outerTag +
            ":" +
            endpoints[i].innerTag;
        }
        logger.info(null, "Building Topology for Interface: " + interfaceName);
        myTopo.addTopologyObject(
          this.createTopoObject(
            "Sap",
            deviceName + ":" + "anv:Sap" + "=" + interfaceName,
            "SUBSCRIBER"
          )
        );
      }
    }
    return myTopo;
  };

  /**
   * method sets the extra Info on the Intent topology object.
   *
   * @param svcTopo The intent topology object created using topologyFactory.createServiceTopology();
   *
   * @param target The intent-intance-name
   *
   * @param serviceId The serviceId
   *
   * @param serviceType The intent-type
   *
   * @param serviceIdKey The key to identify serviceId within topology extra info list
   *
   * @returns the extra info set on the intent topology object
   */
  this.addTopologyExtraInfo = function (
    svcTopo,
    target,
    serviceId,
    serviceType,
    serviceIdKey
  ) {
    xtraInfoList = new java.util.ArrayList();
    var xtraInfo = topologyFactory.createTopologyXtraInfoFrom(
      serviceIdKey,
      serviceId
    );
    xtraInfo.setTarget(target);
    xtraInfo.setIntentType(serviceType);
    xtraInfoList.add(xtraInfo);
    svcTopo.setXtraInfo(xtraInfoList);

    return svcTopo.getXtraInfo();
  };

  /**
   * @param topology =  The Intent Topology Object created using topologyFactory.createServiceTopology();
   * @param propName - the key to identify the property within the intent topology extra info
   */
  this.getPropertyFromTopology = function (topology, propName) {
    var result = null;

    if (!(typeof topology.getXtraInfo === "function")) {
      logger.error(
        null,
        "[MDT-FWK] Cannot compute service id. object doesn't have a function named getXtraInfo"
      );
      return result;
    }

    if (topology.getXtraInfo() === null || topology.getXtraInfo().isEmpty()) {
      logger.error(
        null,
        "[MDT-FWK] Cannot compute service id. xtraInfo is : " +
          topology.getXtraInfo()
      );
      return result;
    }
    topology.getXtraInfo().forEach(function (extraInfo) {
      if (
        !(typeof extraInfo.getKey === "function") ||
        !(typeof extraInfo.getValue === "function")
      ) {
        logger.error(
          null,
          "[MDT-FWK] Unable to compute serviceId. extraInfo doesn't have either getKey or getValue"
        );
        return result;
      }
      if (extraInfo.getKey() != null && extraInfo.getKey() === propName) {
        if (extraInfo.getValue() != null) {
          result = extraInfo.getValue();
        }
      }
    });

    return result;
  };

  /**
   * method takes the config object and returns a map of deviceId:[{"deviceId":"", "portId": "", "innerTag":"","outerTag":""}]
   * config must have an array element called 'endpoints' with following keys
   * "endpoints":[
   { "device-id":{"#text":"11.11.11.11"},"port-id":{"#text":"1/1/60"},"inner-vlan-tag":{"#text":"99"},"outer-vlan-tag":{"#text":"99"}},
   { "device-id":{"#text":"33.33.33.33"},"port-id":{"#text":"1/1/60"},"inner-vlan-tag":{"#text":"99"},"outer-vlan-tag":{"#text":"99"}}]}}
   ]
   */
  this.groupEndpointsForNode = function (config, serviceNS) {
    var nodalArgsMap = {};
    var endpointElements = this.extractElement(
      config,
      serviceNS,
      "endpoints",
      true
    );
    logger.info(
      null,
      "[MDT-FWK] Number of endpoint elements found: " +
        endpointElements.getLength()
    );
    var endpointElementsLen = endpointElements.getLength();
    for (i = 0; i < endpointElementsLen; i++) {
      var element = this.extractElement(
        endpointElements.item(i),
        serviceNS,
        "device-id",
        true
      ).item(0);
      if (element === null || element === undefined) {
        logger.info(
          null,
          "[MDT-FWK] device-id is null. Cannot group endpoints by device-id",
          true
        );
        return nodalArgsMap;
      }
      var deviceId = element.getTextContent();

      element = this.extractElement(
        endpointElements.item(i),
        serviceNS,
        "port-id",
        true
      ).item(0);
      if (element === null || element === undefined) {
        logger.info(
          null,
          "[MDT-FWK] port-id is null. Cannot group endpoints by device-id"
        );
        return nodalArgsMap;
      }

      var portId = element.getTextContent();

      element = this.extractElement(
        endpointElements.item(i),
        serviceNS,
        "inner-vlan-tag",
        true
      ).item(0);
      var innerTag =
        element === null || element === undefined
          ? -1
          : element.getTextContent();

      element = this.extractElement(
        endpointElements.item(i),
        serviceNS,
        "outer-vlan-tag",
        true
      ).item(0);
      var outerTag =
        element === null || element === undefined
          ? -1
          : element.getTextContent();

      logger.info(null, "[MDT-FWK] Endpoint deviceId: " + deviceId);
      logger.info(null, "[MDT-FWK] Endpoint port-id: " + portId);
      logger.info(null, "[MDT-FWK] Endpoint inner-vlan-tag: " + innerTag);
      logger.info(null, "[MDT-FWK] Endpoint outer-vlan-tag: " + outerTag);

      var endpoint = {
        deviceId: deviceId,
        portId: portId,
        innerTag: innerTag,
        outerTag: outerTag,
      };

      if (!(deviceId in nodalArgsMap)) {
        nodalArgsMap[deviceId] = [];
      }
      nodalArgsMap[deviceId].push(endpoint);
    }
    return nodalArgsMap;
  };

  /**
   *
   * @param {*} objType
   * @param {*} objId
   * @param {*} side
   * @returns
   */
  this.createTopoObject = function (objType, objId, side) {
    return topologyFactory.createTopologyObjectFrom(objType, objId, side);
  };

  /**
   *
   * @param {*} topology
   * @returns
   */
  this.getServiceIdFromTopology = function (topology) {
    var serviceId = -1;
    if (topology.getXtraInfo() !== null && !topology.getXtraInfo().isEmpty()) {
      topology.getXtraInfo().forEach(function (extraInfo) {
        logger.info(null, "KEY is :" + extraInfo.getKey());
        logger.info(null, "VALUE is :" + extraInfo.getValue());
        if (extraInfo.getKey() != null && extraInfo.getKey() === "service-id") {
          if (extraInfo.getValue() != null) {
            serviceId = extraInfo.getValue();
          }
        }
      });
    }
    return serviceId;
  };

  /**
   *
   * @param {*} topology
   * @returns
   */
  this.getDeviceIdsFromTopology = function (topology) {
    var deviceIdList = [];

    var topoList = topology.getTopologyObjects();
    logger.info(null, "topoList = " + topoList);
    for (index = 0; index < topoList.length; index++) {
      var topoObject = topoList[index];
      logger.info(null, "topoObject = " + topoObject);

      var deviceId = topoObject.getObjectDeviceName();
      if (deviceIdList.indexOf(deviceId) === -1) {
        deviceIdList.push(deviceId);
      }
    }

    return deviceIdList;
  };

  /**
   *
   * @param {*} topology
   * @returns
   */
  this.getInterfacesFromTopology = function (topology) {
    var interfacesMap = {};

    var topoList = topology.getTopologyObjects();
    logger.info(null, "topoList = " + topoList);
    for (index = 0; index < topoList.length; index++) {
      var topoObject = topoList[index];
      logger.info(null, "topoObject = " + topoObject);

      var deviceId = topoObject.getObjectDeviceName();
      var objectId = JSON.parse(topoObject.getObjectRelativeObjectID());
      logger.info(null, "objectId = " + objectId);

      if (typeof interfacesMap[deviceId] === "undefined") {
        interfacesMap[deviceId] = [objectId];
      } else {
        interfacesMap[deviceId].push(objectId);
      }
    }

    logger.info(null, "interfacesMap = " + JSON.stringify(interfacesMap));
    return interfacesMap;
  };

  /**
   *
   * @param {*} deviceName
   * @param {*} target
   * @param {*} deviceType
   * @param {*} deviceVersion
   * @param {*} extraParams
   * @returns
   */
  this.getTemplateMappings = function (
    deviceName,
    target,
    deviceType,
    deviceVersion,
    extraParams
  ) {
    var templateEntry = {};
    var templateMappings = utilityService.processTemplate(
      resourceProvider.getResource("templateMappings.json"),
      { deviceName: deviceName, target: target, extraParams: extraParams }
    );
    logger.info(
      null,
      "[MDT-FWK] Template Mappings for device " +
        deviceName +
        " : " +
        templateMappings
    );
    var json = JSON.parse(templateMappings);
    json.forEach(function (element) {
      logger.info(
        null,
        "[MDT-FWK] DeviceType: " + deviceType + ", ElementType: " + element.type
      );
      logger.info(
        null,
        "[MDT-FWK] DeviceVersion: " +
          deviceType +
          ", ElementVersion: " +
          element.version
      );

      if (deviceType === element.type && deviceVersion === element.version) {
        templateEntry = element;
      }
    });
    return templateEntry;
  };

  /**
   *
   * @param {*} expectedJson
   * @param {*} nodeJson
   * @param {*} objKey
   * @param {*} auditReport
   * @param {*} auditFactory
   */
  this.auditJson = function (
    expectedJson,
    nodeJson,
    objKey,
    auditReport,
    auditFactory
  ) {
    logger.info(
      null,
      "[MDT-FWK] auditJson {expected, node}: {" +
        JSON.stringify(expectedJson) +
        ", " +
        JSON.stringify(nodeJson) +
        "}"
    );
    logger.info(
      null,
      "[MDT-FWK] Object.keys(expectedJson).length = " +
        Object.keys(expectedJson).length
    );
    logger.info(
      null,
      "[MDT-FWK] Object.keys(nodeJson).length = " + Object.keys(nodeJson).length
    );

    var biggestKeySetObj = expectedJson;
    if (Object.keys(nodeJson).length > Object.keys(expectedJson).length) {
      biggestKeySetObj = nodeJson;
    }

    var totalKeys = Object.keys(nodeJson);
    Object.keys(expectedJson).forEach(function (key) {
      if (totalKeys.indexOf(key) === -1) {
        totalKeys.push(key);
      }
    });
    totalKeys.forEach(function (key) {
      logger.info(
        null,
        "[MDT-FWK] BiggestKeySet loop: values for " +
          key +
          " are {expected, node}: {" +
          expectedJson[key] +
          ", " +
          nodeJson[key] +
          "}"
      );
      if (
        typeof expectedJson[key] === "object" &&
        typeof nodeJson[key] === "object"
      ) {
        logger.info(null, "[MDT-FWK] Found JSON child => " + key);
        new MdtFwk().auditJson(
          expectedJson[key],
          nodeJson[key],
          objKey + ":" + key,
          auditReport,
          auditFactory
        );
      } else {
        logger.info(
          null,
          "[MDT-FWK] Values for " +
            key +
            " are {expected, node}: {" +
            expectedJson[key] +
            ", " +
            nodeJson[key] +
            "}"
        );
        if (expectedJson[key] === nodeJson[key]) {
          logger.info(null, "[MDT-FWK] Values for " + key + " are the same.");
        } else {
          logger.info(
            null,
            "[MDT-FWK] Values for " + key + " are the different."
          );
          var expectedValue =
            Object.keys(expectedJson).indexOf(key) !== -1
              ? expectedJson[key]
              : "{empty}";
          var actualValue =
            Object.keys(nodeJson).indexOf(key) !== -1
              ? nodeJson[key]
              : "{empty}";
          if (typeof expectedValue === "object") {
            expectedValue = JSON.stringify(expectedValue);
          }
          if (typeof actualValue === "object") {
            actualValue = JSON.stringify(actualValue);
          }
          auditReport.addMisAlignedAttribute(
            auditFactory.createMisAlignedAttribute(
              key,
              expectedValue,
              actualValue,
              objKey
            )
          );
        }
      }
    });
  };
}
