function ModelDeviceMapping() {
    this.getLagMapping = function () {
        var mapping = {};
        mapping['lag.admin-state'] = 'administrativeState';
        mapping['lag.description'] = 'description';
        mapping['lag.encap-type'] = 'encapType';
        mapping['lag.mode'] = 'mode';
        mapping['lag.port-type'] = 'lagPortType';
        mapping['lag.lacp-xmit-interval'] = 'lacpTransmitInterval';
        mapping['lag.lacp-xmit-stdby'] = 'lacpXmitStdby';
        mapping['lag.port-threshold.value'] = 'portThreshold';
        mapping['lag.port-threshold.action'] = 'portThresholdAction';
        mapping['lag.port-threshold.cost'] = 'portThresholdStaticCost';
        mapping['lag.per-link-hash.enablePerLinkHash'] = 'perLinkHashing';
        mapping['lag.per-link-hash.weighted.enableWeighted'] = 'perLinkHashWeighted';
        mapping['lag.per-link-hash.weighted.auto-rebalance'] = 'autoRebalance';
        return mapping;
    }

    this.getLagLacpMapping = function () {
        var mapping = {};
        mapping['lag.lacp.enableLacp'] = 'administrativeState';
        mapping['lag.lacp.mode'] = 'lacpMode';
        mapping['lag.lacp.administrative-key'] = 'actorAdminKey';
        mapping['lag.lacp.system-id'] = 'lagSystemId';
        mapping['lag.lacp.system-priority'] = 'lagSystemPriority';
        return mapping;
    }

    this.getLagPortMapping = function () {
        var mapping = {};
        mapping['lag.port.port-id'] = 'memberName';
        mapping['lag.port.priority'] = 'priority';
        mapping['lag.port.sub-group'] = 'subGroupId';
        mapping['lag.port.hash-weight'] = 'hashWeight';
        return mapping;
    }
    this.getLagBfdMapping = function(){
        var mapping={};
        mapping['lag.bfd-liveness.ipv4.admin-state'] = 'adiminState';
        mapping['lag.bfd-liveness.ipv4.local-ip-address'] = 'localIP';
        mapping['lag.bfd-liveness.ipv4.remote-ip-address'] = 'remoteIP';
        mapping['lag.bfd-liveness.ipv4.receive-interval'] = 'receiveInterval';
        mapping['lag.bfd-liveness.ipv4.transmit-interval'] = 'transmitInterval';
        mapping['lag.bfd-liveness.ipv4.max-admin-down-time'] = 'maxAdminDownTime';
        mapping['lag.bfd-liveness.ipv4.max-setup-time'] = 'maxSetupTime';
        mapping['lag.bfd-liveness.ipv4.multiplier'] = 'multiplier';
        return mapping;
    }
    this.getLagBfdIpv6Mapping = function(){
        var mapping={};
        mapping['lag.bfd-liveness.ipv6.admin-state'] = 'adiminState';
        mapping['lag.bfd-liveness.ipv6.local-ip-address'] = 'localIP';
        mapping['lag.bfd-liveness.ipv6.remote-ip-address'] = 'remoteIP';
        mapping['lag.bfd-liveness.ipv6.receive-interval'] = 'receiveInterval';
        mapping['lag.bfd-liveness.ipv6.transmit-interval'] = 'transmitInterval';
        mapping['lag.bfd-liveness.ipv6.max-admin-down-time'] = 'maxAdminDownTime';
        mapping['lag.bfd-liveness.ipv6.max-setup-time'] = 'maxSetupTime';
        mapping['lag.bfd-liveness.ipv6.multiplier'] = 'multiplier';
        return mapping;
    }
}
