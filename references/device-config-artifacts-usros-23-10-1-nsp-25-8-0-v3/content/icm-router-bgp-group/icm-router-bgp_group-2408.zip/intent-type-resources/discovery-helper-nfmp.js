var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});

load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});


function NfmpDiscoveryHelper(){
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let bgpGroupName = parseTarget.getUniqueIdentifier(target);
        let fullClassName = "bgp.PeerGroup";
        let objectFullName = "network:" + neId + ":router-1:bgp:group-"+bgpGroupName;
        if (neId && String(neId).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        }
        logger.info(LOG_PREFIX + "BGP Group Full Name: " + objectFullName);

        let resultFetch = nfmpFwk.post("/v3/search", this.constructSearchString(fullClassName, objectFullName));
        if (!resultFetch.success) {
            throw new RuntimeException("Failed to find BGP Group: " + bgpGroupName + " on NE " + neId);
        }
        let finalResponse = JSON.parse(resultFetch.response);
        if (JSON.stringify(finalResponse) === JSON.stringify({})) {
            throw new RuntimeException("search results is empty for BGP Group: " + bgpGroupName + " finalResponse: " + JSON.stringify(finalResponse));
        }
        else if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse["bgp.PeerGroup"]];
            logger.info(LOG_PREFIX + "Search results: " + JSON.stringify(finalResponse));
        }
        return finalResponse[0];
    }

    this.constructSearchString = function (className, objectFullName) {
        let searchJson = {
            "fullClassName": className,
            "filter":{
                "equal":{
                    "name":"objectFullName",
                    "value": objectFullName
                }
            }
        };
        return searchJson;
    }

    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedTargetData = JSON.parse(defaultTargetData);
        let loadingTargetData = JSON.parse(JSON.stringify(parsedTargetData));
        logger.info(LOG_PREFIX + "defaultTargetData: ");
        logger.info(defaultTargetData);
        this.extractBgpGroupProperties(parsedTargetData, deviceConfig);
        let inheritanceMask = deviceConfig["inheritanceMask"];
        inheritanceMask = inheritanceMask.toString();
        let bgpGroupChildConfigs = deviceConfig["children-Set"];
        let isPeersAvailable = false;
        for (let childAttribute in bgpGroupChildConfigs) {
            switch (childAttribute) {
                case "bgp.Peer":
                    {
                        isPeersAvailable = true;
                        let bgpPeerConfig = bgpGroupChildConfigs[childAttribute];
                        if(bgpPeerConfig == undefined)
                        {
                            parsedTargetData["neighbor"] = undefined;
                            break;
                        }
                        let resPeerConfig = [];
                        if(!Array.isArray(bgpPeerConfig))
                        {
                            bgpPeerConfig = [bgpPeerConfig];
                        }
                        for (let index in bgpPeerConfig)
                        {
                            let neighbour = this.extractDeviceProperties(bgpPeerConfig[index], loadingTargetData["neighbor"][0], "neighbor")[0];
                            let peerInheritanceMask = bgpPeerConfig[index]["inheritanceMask"];
                            peerInheritanceMask = peerInheritanceMask.toString();
                            if(bgpPeerConfig[index]["family"] && peerInheritanceMask.contains("family"))
                            {
                                neighbour["family"] = {};
                                if(!Array.isArray(bgpPeerConfig[index]["family"]))
                                {
                                    bgpPeerConfig[index]["family"] = [bgpPeerConfig[index]["family"]];
                                }
                                for (let familyName in bgpPeerConfig[index]["family"])
                                {
                                    neighbour["family"][util.getIntentFamilyName(bgpPeerConfig[index]["family"][familyName])] = true;
                                }
                            }
                            let bgpPeerChildConfigs = bgpPeerConfig[index]["children-Set"];
                            let isPrefixLimitAvailable = false;
                            for (let childAttribute in bgpPeerChildConfigs)
                            {
                                switch (childAttribute)
                                {
                                    case "bgp.PeerImportPolicy":
                                        if(peerInheritanceMask.contains("importPolicy1"))
                                        {
                                            let peerImportPolicyConfig = bgpPeerChildConfigs[childAttribute];
                                            neighbour["import"] = {};
                                            neighbour["import"]["policy"] = this.extractBGPImportExportPolicies(peerImportPolicyConfig)
                                        }
                                        else
                                        {
                                            neighbour["import"] = undefined;
                                        }
                                        break;
                                    case "bgp.PeerExportPolicy":
                                        if(peerInheritanceMask.contains("exportPolicy1"))
                                        {
                                            let peerExportPolicyConfig = bgpPeerChildConfigs[childAttribute];
                                            neighbour["export"] = {};
                                            neighbour["export"]["policy"] = this.extractBGPImportExportPolicies(peerExportPolicyConfig)
                                        }
                                        else
                                        {
                                            neighbour["export"] = undefined;
                                        }
                                        break;
                                    case "bgp.PrefixLimit":
                                        {
                                            isPrefixLimitAvailable = true;
                                            let peerPrefixLimit = bgpPeerChildConfigs[childAttribute];
                                            neighbour["prefix-limit"] = this.extractDeviceProperties(peerPrefixLimit, loadingTargetData["neighbor"][0]["prefix-limit"][0], "neighbor.prefix-limit");
                                            break;
                                        }
                                }
                            }
                            if(isPrefixLimitAvailable == false)
                            {
                                neighbour["prefix-limit"] = undefined;
                            }
                            resPeerConfig.push(neighbour);
                        }
                        parsedTargetData["neighbor"] = resPeerConfig;
                        break;
                    }
                case "bgp.GroupImportPolicy":
                    if(inheritanceMask.contains("importPolicy1"))
                    {
                        let groupImportPolicyConfig = bgpGroupChildConfigs[childAttribute];
                        parsedTargetData["group"]["import"] = {};
                        parsedTargetData["group"]["import"]["policy"] = this.extractBGPImportExportPolicies(groupImportPolicyConfig)
                    }
                    else
                    {
                        parsedTargetData["group"]["import"] = undefined;
                    }
                    break;
                case "bgp.GroupExportPolicy":
                    if(inheritanceMask.contains("exportPolicy1"))
                    {
                        let groupExportPolicyConfig = bgpGroupChildConfigs[childAttribute];
                        parsedTargetData["group"]["export"] = {};
                        parsedTargetData["group"]["export"]["policy"] = this.extractBGPImportExportPolicies(groupExportPolicyConfig)
                    }
                    else
                    {
                        parsedTargetData["group"]["export"] = undefined;
                    }
                    break;
            }
        }
        if(isPeersAvailable == false)
        {
            parsedTargetData["neighbor"] = undefined;
        }
        let finalTargetData = {};
        this.clearEmptiesAndNull(parsedTargetData);
        finalTargetData = parsedTargetData;
        logger.info(LOG_PREFIX + "Intent data after updating from NFMP: \n" + JSON.stringify(finalTargetData));
        return finalTargetData;
    }

    this.extractBGPImportExportPolicies = function (bgpImportExportPolicies)
    {
        if(bgpImportExportPolicies == undefined)
        {
            return undefined;
        }
        let policies = [];
        for(let i = 1; i<=15; i++)
        {
            if(bgpImportExportPolicies["policy"+i])
            {
                policies.push(bgpImportExportPolicies["policy"+i])
            }
        }
        return policies;
    }

    this.extractBgpGroupProperties = function (parsedTargetData, deviceConfig) {
        let bgpGroupMapping = modelDeviceMapping.getBGPGroupMapping();
        this.traverseAndUpdateConfig("group", parsedTargetData["group"], deviceConfig, bgpGroupMapping);
        let inheritanceMask = deviceConfig["inheritanceMask"];
        inheritanceMask = inheritanceMask.toString();
        if(deviceConfig["family"] && inheritanceMask.contains("family"))
        {
            parsedTargetData["group"]["family"] = {};
            if(!Array.isArray(deviceConfig["family"]))
            {
                deviceConfig["family"] = [deviceConfig["family"]];
            }
            for (let familyName in deviceConfig["family"])
            {
                parsedTargetData["group"]["family"][util.getIntentFamilyName(deviceConfig["family"][familyName])] = true;
            }
        }
        logger.info(LOG_PREFIX + "Updated BGP Group properties - " + JSON.stringify(parsedTargetData));
    }

    this.extractDeviceProperties = function (configData, defaultDataObj, keyPrefix) {
        let configDataArray = [];
        let mappings = modelDeviceMapping.getMapping(keyPrefix);
        if (!Array.isArray(configData)) {
            configData = [configData];
        }

        for (let idx in configData) {
            let configDataObj = configData[idx];
            let defData = JSON.parse(JSON.stringify(defaultDataObj));
            this.traverseAndUpdateConfig(keyPrefix, defData, configDataObj, mappings);
            configDataArray.push(defData);
        }
        logger.info(LOG_PREFIX + "parsedTargetData for: " + keyPrefix + ": " + JSON.stringify(configDataArray));
        return configDataArray;
    }

    this.traverseAndUpdateConfig = function (objKey, defDataObj, deviceConfig, mappings) {
        let keys = Object.keys(defDataObj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = defDataObj[key];

            let mappedKey = objKey + "." + key;
            if (mappedKey !== "neighbor.prefix-limit")
            {
                if (value != null && typeof value === "object") {
                    this.traverseAndUpdateConfig(mappedKey, value, deviceConfig, mappings);
                }
                else {
                    let nfmpKey = mappings[mappedKey];
                    defDataObj[key] = this.transformDeviceValue(mappedKey, nfmpKey, deviceConfig[nfmpKey], deviceConfig["inheritanceMask"]);
                }
            }
        }
        return defDataObj;
    }

    this.transformDeviceValue = function (mappedKey, nfmpKey, deviceValue, inheritanceMask) {
        if(inheritanceMask != undefined)
        {
            inheritanceMask = inheritanceMask.toString();
        }
        else
        {
            inheritanceMask = "";
        }
        if (deviceValue !== null) {
            switch (mappedKey) {
                case "group.loop-detect":
                    if(!inheritanceMask.contains(nfmpKey))
                    {
                        return undefined;
                    }
                    else
                    {
                        return util.transformIntentLoopDetect(deviceValue);
                    }
                case "neighbor.loop-detect":
                    if(!inheritanceMask.contains(nfmpKey))
                    {
                        return undefined;
                    }
                    else
                    {
                        return util.transformIntentLoopDetect(deviceValue);
                    }
                case "group.admin-state":
                    deviceValue = util.transformIntentBGPAdminState(deviceValue);
                    break;
                case "neighbor.admin-state":
                    deviceValue = util.transformIntentBGPAdminState(deviceValue);
                    break;
                case "group.connect-retry":
                case "group.min-route-advertisement":
                case "group.preference":
                case "group.local-as.as-number":
                case "group.multihop":
                case "group.keepalive":
                case "group.damping":
                case "group.local-preference":
                case "group.aggregator-id-zero":
                case "group.vpn-apply-export":
                case "group.vpn-apply-import":
                case "group.path-mtu-discovery":
                case "group.cluster.cluster-id":
                case "group.local-as.private":
                case "group.outbound-route-filtering.extended-community.accept-orf":
                case "group.outbound-route-filtering.extended-community.send-orf":
                case "neighbor.connect-retry":
                case "neighbor.min-route-advertisement":
                case "neighbor.preference":
                case "neighbor.multihop":
                case "neighbor.peer-as":
                case "neighbor.keepalive":
                case "neighbor.damping":
                case "neighbor.local-preference":
                case "neighbor.aggregator-id-zero":
                case "neighbor.vpn-apply-export":
                case "neighbor.vpn-apply-import":
                case "neighbor.local-address":
                case "neighbor.l2vpn-cisco-interop":
                case "neighbor.next-hop-self":
                case "neighbor.passive":
                case "neighbor.cluster.cluster-id":
                case "neighbor.local-as.as-number":
                case "neighbor.local-as.private":
                case "neighbor.outbound-route-filtering.extended-community.accept-orf":
                case "neighbor.outbound-route-filtering.extended-community.send-orf":
                    if(!inheritanceMask.contains(nfmpKey))
                    {
                        return undefined;
                    }
                    else
                    {
                        return deviceValue
                    }

                case "group.client-reflect":
                case "neighbor.client-reflect":
                case "group.asn-4-byte":
                case "neighbor.asn-4-byte":
                case "neighbor.capability-negotiation":
                    if(!inheritanceMask.contains(nfmpKey))
                    {
                        return true;
                    }
                    else
                    {
                        return undefined;
                    }
                case "group.hold-time.seconds":
                case "group.hold-time.minimum-hold-time":
                case "neighbor.hold-time.seconds":
                case "neighbor.hold-time.minimum-hold-time":
                {
                    if(!inheritanceMask.contains("holdTime"))
                    {
                        return undefined;
                    }
                    else
                    {
                        return deviceValue
                    }
                }

                case "group.remove-private.limited":
                case "group.remove-private.skip-peer-as":
                case "neighbor.remove-private.limited":
                case "neighbor.remove-private.skip-peer-as":
                    if(!inheritanceMask.contains("removePrivateAS"))
                    {
                        return undefined;
                    }
                    else
                    {
                        return deviceValue
                    }
                case "group.graceful-restart.restart-time":
                case "group.graceful-restart.stale-routes-time":
                case "neighbor.graceful-restart.restart-time":
                case "neighbor.graceful-restart.stale-routes-time":
                    if(!inheritanceMask.contains("gracefulRestart"))
                    {
                        return undefined;
                    }
                    else
                    {
                        return deviceValue
                    }
                case "neighbor.prefix-limit.maximum":
                case "neighbor.prefix-limit.threshold":
                case "neighbor.prefix-limit.idle-timeout":
                    if(deviceValue == null || deviceValue == 0)
                    {
                        return undefined;
                    }
                    else
                    {
                        return deviceValue;
                    }
                    break;
                case "neighbor.prefix-limit.family":
                    return util.getIntentPrefixFamilyName(deviceValue);
                default:
                    return deviceValue;
            }
            return deviceValue;
        }
    }
    this.clearEmptiesAndNull = function (o)
    {
        for (let k in o)
        {
            if(!Array.isArray(o) && o[k] === null)
            {
                delete o[k];
            }
            if (!o[k] || typeof o[k] !== "object")
            {
                continue
            }

            this.clearEmptiesAndNull(o[k]);
            if (Object.keys(o[k]).length === 0)
            {
                delete o[k];
            }
        }
    }
}