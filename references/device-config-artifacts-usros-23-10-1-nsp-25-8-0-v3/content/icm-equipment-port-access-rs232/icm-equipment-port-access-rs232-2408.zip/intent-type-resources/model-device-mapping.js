function ModelDeviceMapping() {

    this.getMapping = function(type){
        switch(type){
            case "port":
                return this.getPortMapping();
            case "serialChannel":
                return this.getSerialChannelMapping();
            case "serialSocket":
                return this.getSerialSocketMapping();
            case "serialChannelSpecifics":
                return this.getSerialChannelSpecificsMapping();
            case "ds0Channel-group":
                return this.getDs0ChannelGroupMapping();
            default:
                return this.getPortMapping();
        }
    }

    this.getPortMapping = function() {
        var mapping = {};
        mapping['port.admin-state'] = 'administrativeState';
        mapping['port.description'] = 'description';

        return mapping;
    }

    this.getSerialChannelMapping = function() {
        var mapping = {};
        mapping['port.serialChannel.admin-state'] = 'administrativeState';
        mapping['port.serialChannel.serial-socket-enabled'] = 'serialSocket';

        return mapping;
    }

    this.getSerialSocketMapping = function() {
        var mapping = {};
        mapping['port.serialChannel.socket.admin-state'] = 'administrativeState';
        mapping['port.serialChannel.socket.description'] = 'description';

        return mapping;

    }

    this.getSerialChannelSpecificsMapping = function() {
        var mapping = {};
        mapping['port.serialChannel.speed'] = 'speed';
        mapping['port.serialChannel.device-mode'] = 'serialMode';

        return mapping;
    }

    this.getDs0ChannelGroupMapping = function() {
        var mapping = {};
        mapping['port.serialChannel.ds0Channel-group.channel-group-id'] = 'displayedLocalChannelId';
        mapping['port.serialChannel.ds0Channel-group.admin-state'] = 'administrativeState';
        mapping['port.serialChannel.ds0Channel-group.description'] = 'description';
        mapping['port.serialChannel.ds0Channel-group.encapType'] = 'encapType';

        return mapping;
    }

}
