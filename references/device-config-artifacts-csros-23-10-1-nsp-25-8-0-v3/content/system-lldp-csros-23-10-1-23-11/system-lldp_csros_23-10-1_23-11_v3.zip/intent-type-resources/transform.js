function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return this.transformIPv6Address(objectFullName);
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return this.transformIPv6Address(objectFullName);
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return this.transformIPv6Address(fdn);
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformIPv6Address =  function (str) {
        let ipv6Pattern = /([a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}/g;
        if (ipv6Pattern.test(str)) {
            let modifiedStr = str.replace(ipv6Pattern, (match) => {
                return match.replace(/:/g, '_');
            });
            return modifiedStr;
        }
        return str;
    }
}