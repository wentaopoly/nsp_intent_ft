var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {

    this.setSuccessResult = function (result, savedTopology) {
        result.setSuccess(true);
        if (savedTopology !== undefined) {
            result.setTopology(savedTopology);
        }
        return result;
    }

    this.reportMisaligned = function (target, result, auditReport) {
        var report = JSON.parse(result.response);
        if (!report.aligned) {
            for (var i = 0; i < report.misalignedAttributes.length; i++) {
                var attributeData = report.misalignedAttributes[i];
                if((attributeData.name).indexOf("from-criteria|family") > -1)
                {
                    for (var index in attributeData.expected)
                    {
                        var family =attributeData.expected[index];
                        var index =attributeData.expected.indexOf(family);

                        if (~index) {
                            attributeData.expected[index] = this.getIntentFamilyName(family);
                        }
                    }
                    for (var index in attributeData.actual)
                    {
                        var family =attributeData.actual[index];
                        var index =attributeData.actual.indexOf(family);

                        if (~index) {
                            attributeData.actual[index] = this.getIntentFamilyName(family);
                        }
                    }
                }
                if((attributeData.name).indexOf('from-criteria|protocol') > -1 || (attributeData.name).indexOf('to-criteria|protocol') > -1)
                {
                    for (var index in attributeData.expected)
                    {
                        var family =attributeData.expected[index];
                        var index =attributeData.expected.indexOf(family);

                        if (~index) {
                            attributeData.expected[index] = this.getIntentProtocolName(family);
                        }
                    }
                    for (var index in attributeData.actual)
                    {
                        var family =attributeData.actual[index];
                        var index =attributeData.actual.indexOf(family);

                        if (~index) {
                            attributeData.actual[index] = this.getIntentProtocolName(family);
                        }
                    }
                }
                if (attributeData.expected == "present")
                {
                    //misaligned object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else if (attributeData.expected == "not present")
                {
                    //undesired object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                    auditReport.addMisAlignedAttribute(misalignedAttribute);
                }
            }
        }
        return auditReport
    }

    /*
     function: isObjectExists
     description: To Check the Object exists or not.
     */
    this.isObjectExists = function (className, objectFullName) {

        let nfmpFwk = new NfmpFwk();
        var expectedJson = {
            "fullClassName": className,
            "filter": {
                "filterExpression": "fullName='" + objectFullName + "'"
            }
        };
        var ret = false;
        var resultFetch = nfmpFwk.post("search", expectedJson);
        var finalResponse = JSON.parse(resultFetch.response);

        logger.info(JSON.stringify(finalResponse));

        if (Array.isArray(finalResponse)) {
            ret = true;
        }

        return ret;
    }

    /*
     function: getIfObjectExists
     description: returns the object for objectFullName if exists.
     */
    this.getIfObjectExists = function (className, objectFullName) {

        let nfmpFwk = new NfmpFwk();
        var expectedJson = {
            "fullClassName": className,
            "filter": {
                "filterExpression": "fullName='" + objectFullName + "'"
            }
        };
        var ret = false;
        var resultFetch = nfmpFwk.post("search", expectedJson);
        var finalResponse = JSON.parse(resultFetch.response);

        if (Array.isArray(finalResponse)) {
            return finalResponse;
        }


        return null;
    }

    /*
     function: delay
     description: Sometimes the object creation takes time, we can use delay for child-level operation.
     */
    this.delay = function (milliseconds) {
        var date = new Date();
        date.setMilliseconds(date.getMilliseconds() + milliseconds);
        while (new Date() < date) {
        }
    }

    this.editPayload = function (fdn, properties, childProperties, fullClassName, objectFullName) {

        var payload = {};
        var configInfo = {};
        configInfo["containedClassProperties"] = properties;
        configInfo["containmentInfo"] = childProperties;
        configInfo["objectClassName"] = fullClassName;
        //payload["fdn"] = fdn;
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName,
            payload["configInfo"] = configInfo;
        return payload;

    }
    this.editChildPayload = function (properties, childProperties, fullClassName, objectFullName) {

        var payload = {};
        payload["containedClassProperties"] = properties;
        payload["containmentInfo"] = childProperties;
        payload["objectClassName"] = fullClassName;
        payload["objectFullName"] = objectFullName;

        return payload;

    }

    this.getNfmpProtocolName = function (protocol)
    {
        switch (protocol)
        {
            case "bgp": return "bgp";
            case "ldp": return "ldp";
            case "isis": return "isis";
            case "ospf": return "ospf";
            case "bgp-vpn": return "bgpVpn";
            case "bgp-label": return "bgpLabel";
            default: return protocol;
        }
    }

    this.getIntentProtocolName = function (protocol)
    {
        switch (protocol)
        {
            case "bgp": return "bgp";
            case "ldp": return "ldp";
            case "isis": return "isis";
            case "ospf": return "ospf";
            case "bgpVpn": return "bgp-vpn";
            case "bgpLabel": return "bgp-label";
            default: return protocol;
        }
    }

    this.getNfmpFamilyName = function (family)
    {
        switch (family)
        {
            case "ipv4": return "ipv4Unicast";
            case "ipv6": return "ipv6Unicast";
            case "vpn-ipv4": return "ipv4Vpn";
            case "vpn-ipv6": return "ipv6Vpn";
            case "mcast-ipv4": return "ipv4Multicast";
            case "mcast-ipv6": return "ipv6Multicast";
            default: return family;
        }
    }

    this.getIntentFamilyName = function (family)
    {
        switch (family)
        {
            case "ipv4Unicast": return "ipv4";
            case "ipv6Unicast": return "ipv6";
            case "ipv4Vpn": return "vpn-ipv4";
            case "ipv6Vpn": return "vpn-ipv6";
            case "ipv4Multicast": return "mcast-ipv4";
            case "ipv6Multicast": return "mcast-ipv6";
            default: return family;
        }
    }

  this.modifyNeIdForIpV6 = function (objectFullName, neId) {
     logger.info("modifying NeId For IpV6");
     objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
     return objectFullName;
  }
}
