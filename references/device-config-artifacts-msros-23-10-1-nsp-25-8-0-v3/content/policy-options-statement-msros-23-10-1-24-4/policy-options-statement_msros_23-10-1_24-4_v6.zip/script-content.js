var RuntimeException = Java.type("java.lang.RuntimeException");

var prefixToNsMap = {
  ibn: "http://www.nokia.com/management-solutions/ibn",
  nc: "urn:ietf:params:xml:ns:netconf:base:1.0",
  "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
  "http://www.nokia.com/management-solutions/anv-device-holders":
    "anv-device-holders",
};

load({ script: resourceProvider.getResource("mdc-fwk.js"), name: "MdcFwk" });
const mdcFwk = new MdcFwk();

load({ script: resourceProvider.getResource("mdt-fwk.js"), name: "MdtFwk" });
var mdtFwk = new MdtFwk();

load({
  script: resourceProvider.getResource("parse-target.js"),
  name: "ParseTarget",
});
var parsedTarget = new ParseTarget();

/**
 * Load lodash and create object as underscore(_)
 */
load({
  script: resourceProvider.getResource("lodash.js"),
  name: "Lodash",
});
const _ = new Lodash();

/**
 * Load Deep-diff and create object as DeepDiff
 */
load({
  script: resourceProvider.getResource("deep-diff.js"),
  name: "DeepDiff",
});
const deepDiff = new DeepDiff();

/**
 *
 * Load and instantiate UtilFwk
 * @see UtilFwk
 */
load({
  script: resourceProvider.getResource("util-fwk.js"),
  name: "UtilFwk",
});
const utilFwk = new UtilFwk();

/**
 *
 * Load and instantiate ICMFwk
 * It contain ICM framework specific functions
 *
 * @see ICMFwk
 */
load({ script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk" });
const icmFwk = new ICMFwk();

/**
 * Load and instance IcmServiceFwk
 *
 * @see GtdFWk
 */
load({
  script: resourceProvider.getResource("icm-service-fwk.js"),
  name: "icm-service-fwk",
});
const icmServiceFwk = new IcmServiceFwk();

/**
 *
 */
load({
  script: resourceProvider.getResource("parse-target.js"),
  name: "ParseTarget",
});
var parsedTarget = new ParseTarget();

load({
  script: resourceProvider.getResource("common-utils.js"),
  name: "CommonUtil",
});

load({
  script: resourceProvider.getResource("custom-hooks.js"),
  name: "CustomHooks",
});

load({script: resourceProvider.getResource('mdSuggest.js'), name: 'mdSuggest'});

const customHooks = new CustomHooks();
var commonUtil = new CommonUtil();

const metadata = JSON.parse(resourceProvider.getResource("meta-data.json"));

var intentTypeName = 'policy-options-statement_msros_23-10-1_24-4';

/**
 * The node which you would like to configure.
 * example port, sap-ingress etc.
 * In the intent-yang, you will see this as a container
 * which encapsulates all the different type of nodes
 */
var intentContainer = 'policy-statement';

var deviceYangModuleName = 'nokia-conf';

// unique identifier
var uniqueIdentifier = 'name';

// example "configure" , "configure/qos" etc..
var rootXPath = 'configure/policy-options';

/**
 *
 * @param {*} input
 */
function validate(input) {
  logger.info("--------------Intent validate --------------");
  var config = formatConfig(input.getJsonIntentConfiguration());
  logger.info("config " + config);
}

/**
 *
 * This function is starting point by IM for sync operation
 *
 * @param {*} input
 * @returns
 */
function synchronize(input) {
  /**
   * Deployment of intents to the network, called for synchronize operations.
   * Used to apply create, update, delete and reconcile to managed devices.
   *
   * All created objects are remembered/restored as part of topology/extra-data
   * to apply house-keeping operations.
   *
   **/
  logger.info("--------------Intent Synchronisation started--------------");
  logger.info("input " + input);
  logger.info("intentTypeName " + intentTypeName);
  logger.info("rootXPath " + rootXPath);
  logger.info("intentContainer " + intentContainer);
  logger.info("uniqueIdentifier " + uniqueIdentifier);
  logger.info("deviceYangModuleName " + deviceYangModuleName);

  // TODO, so far the code is handling single intentContainer
  // but there can be multuple top level containers like the case of cpm-filter having ip-filter, ipv6-filter and mac-filter
  // format the config as per your use-case
  var config = formatConfig(input.getJsonIntentConfiguration());
  logger.info("config " + config);

  var target = input.getTarget();
  var state = input.getNetworkState().name();
  logger.info("state " + state);
  var startTime = new Date().getTime();
  var syncResult = synchronizeResultFactory.createSynchronizeResult();
  logger.info(
    intentTypeName + ":synchronize(" + target + ") in state " + state
  );
  // current topology
  var topology = input.getCurrentTopology();
  if (topology == null) {
    topology = topologyFactory.createServiceTopology();
  }
  logger.info("topology " + JSON.stringify(topology));
  var resp = utilFwk.synchronize(
    target,
    config,
    intentTypeName,
    rootXPath,
    intentContainer,
    uniqueIdentifier,
    deviceYangModuleName,
    topology,
    state,
    syncResult
  );
  var endTime = Date.now();
  var timeTaken = (endTime - startTime) / 1000; // seconds
  logger.info(
    "Time taken to synchronize " + timeTaken + " seconds for intent " + target
  );
  var endTime = Date.now();
  var timeTaken = (endTime - startTime) / 1000; // seconds
  logger.info("Time taken to synchronize " + timeTaken);
  logger.info("--------------Intent Synchronisation done--------------");
  return resp;
}

/**
 *
 * The function is starting point for audit operation in IM
 *
 * @param {*} input
 * @returns auditReport
 */
function audit(input) {
  logger.info("-------------- Intent Audit --------------");
  var startTime = new Date().getTime();
  var target = input.getTarget();
  var key = intentTypeName + ":" + intentTypeName;
  var intentConfig = JSON.parse(input.getJsonIntentConfiguration())[0][key][
    intentContainer
  ];
  var state = input.getNetworkState().name();
  var topology = input.getCurrentTopology();

  logger.info("target " + target);
  logger.info("topology " + topology);
  logger.info("state " + state);
  logger.info("intentConfig " + JSON.stringify(intentConfig));
  let auditReport = utilFwk.audit(
    target,
    intentConfig,
    topology,
    state,
    intentTypeName,
    rootXPath,
    intentContainer,
    uniqueIdentifier,
    deviceYangModuleName
  );
  var endTime = Date.now();
  var timeTaken = (endTime - startTime) / 1000; // seconds
  logger.info(
    "Time taken to audit " + timeTaken + " seconds for intent " + target
  );
  return auditReport;
}

/**
 *
 * The function is used in Brownfield disscovery by ICM FW
 * It discover the configuration from the target device
 * and manipulate as per Template's default-target-data
 *
 *
 * @see ICMFwk for more details
 * @param {*} input - the config data of a deployment
 * @returns result - the result of the operation
 */
function getTargetData(input) {
  logger.info("-------- Intent getTargetData started ------");
  logger.info(JSON.stringify(input));
  var target = input.target;
  logger.info("target=" + target);
  var deviceConfig = icmFwk.getDeviceConfiguration(
    target,
    deviceYangModuleName,
    rootXPath,
    intentContainer
  );
  logger.info(JSON.stringify(deviceConfig));
  var data = icmServiceFwk.gtdSend(deviceConfig);
  logger.info(JSON.stringify(data));
  logger.info(JSON.stringify(data.msg.result));
  return data.msg.result;
}

/**
 *
 * If there are multiple containers at in intent-yang for intentContainer name,
 * the config returned by the scriptEnginer is array
 *
 * @param {*} config
 * @returns
 */
const formatConfig = (config) => {
  if (Array.isArray(config)) {
    return config[0];
  } else {
    return config;
  }
};

function getNeId(context) {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    logger.info("target : {}", target)
    if (!target) {
        target = context.getInputValues()["arguments"]["__root"]["target_objectidentifier"];
    }
    if (target) {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        } else {
            neId = target;
        }
    }
    logger.info("NeId identified " + " : {}", neId);
    return neId;
}

function suggestPolicyStatementName(context) {
  return new MdSuggest().getPolicyStatementName(getNeId(context));
}

function suggestService(context) {
  return new MdSuggest().getService(getNeId(context));
}

function suggestMRIpInt(context) {
  var fwdService;
  var policyStatement = context.getInputValues()["arguments"]["policy-statement"];
  if(policyStatement){
    fwdService = policyStatement["default-action"] && policyStatement["default-action"]["multicast-redirection"] && policyStatement["default-action"]["multicast-redirection"]["fwd-service"];
  }
  return new MdSuggest().getIpIntData(getNeId(context), fwdService);
}

function suggestActionMRIpInt(context) {
  var fwdService;
  var action = context.getInputValues()["arguments"]["action"];
  if(action){
    fwdService = action["multicast-redirection"] && action["multicast-redirection"]["fwd-service"];
  }
  return new MdSuggest().getIpIntData(getNeId(context), fwdService);
}

function suggestIsIpIntName(context) {
  var service;
  var from = context.getInputValues()["arguments"]["from"];
  if(from){
    service = from["interface-subnets"] && from["interface-subnets"]["service"];
  }
  return new MdSuggest().getIpIntData(getNeId(context), service);
}

function suggestCommunityData(context) {
  return new MdSuggest().getCommunityData(getNeId(context));
}

function suggestDampingData(context) {
  return new MdSuggest().getDampingData(getNeId(context));
}

function suggestNatPolicy(context) {
  return new MdSuggest().getNatPolicy(getNeId(context));
}

function suggestAsPathData(context) {
  return new MdSuggest().getAsPathData(getNeId(context));
}

function suggestAsPathGroup(context) {
  return new MdSuggest().getAsPathGroup(getNeId(context));
}

function suggestSrv6MicroSegmentLocator(context) {
  return new MdSuggest().getSrv6MSLocator(getNeId(context));
}

function suggestSrv6Locator(context) {
  return new MdSuggest().getSrv6Locator(getNeId(context));
}

function suggestAdminTagPolicy(context) {
  return new MdSuggest().getRouteAdminTagPolicy(getNeId(context));
}

function suggestPrefixList(context) {
  return new MdSuggest().getPrefixList(getNeId(context));
}

function suggestPLOPrefixList(context) {
  return new MdSuggest().getPLOPrefixList(getNeId(context));
}

function suggestInterface(context) {
  return new MdSuggest().getInterface(getNeId(context));
}

function suggestRouteDistinguisherList(context) {
  return new MdSuggest().getRouteDistinguisherList(getNeId(context));
}

function suggestPolicy(context) {
  return new MdSuggest().getPolicyStatementName(getNeId(context));
}

function suggestSrMaintenancePolicy(context) {
  return new MdSuggest().getSrMaintenancePolicy(getNeId(context));
}