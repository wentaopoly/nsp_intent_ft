load({ script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil' });
load({ script: resourceProvider.getResource("nfmpSuggest.js"), name: "NfmpSuggest" });
function transformData() {
    const nfmpSuggest = new NfmpSuggest();
    const ipv6AddressUtil = new IPv6AddressUtil();
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
  this.transformPayloadGreenField = function (payload, neId, isAudit) {
        let neFamily = util.getNeFamilyRelease(neId);
        let neType = util.getNeType(neFamily);
        if(payload && payload["objectFullName"] && neType.startsWith("7705")) {
            let isIpv6Exist = false;
            let result = this.isObjectExists("lag.Interface", payload["objectFullName"]);
            let finalResponse = JSON.parse(result.response);
            if(finalResponse && finalResponse["lag.Interface"]){
                if (finalResponse["lag.Interface"] && finalResponse["lag.Interface"]["children-Set"] && finalResponse["lag.Interface"]["children-Set"]["lag.BFDConfiguration"]) {
                    const bfdConfigData = finalResponse["lag.Interface"]["children-Set"]["lag.BFDConfiguration"];
                    for (let i = 0; i < bfdConfigData.length; i++) {
                        if (bfdConfigData[i].familyType === "ipv6") {
                            isIpv6Exist = true;
                            break;
                        }
                    }
                }
            }
            if(!result.success || !isIpv6Exist){
                if(payload && payload["configInfo"]){
                    if (payload["configInfo"]["lag.Interface"] && payload["configInfo"]["lag.Interface"]["children-Set"] && payload["configInfo"]["lag.Interface"]["children-Set"]["lag.BFDConfiguration"]) {
                        const bfdConfigs = payload["configInfo"]["lag.Interface"]["children-Set"]["lag.BFDConfiguration"];
                        for (let i = 0; i < bfdConfigs.length; i++) {
                            if (bfdConfigs[i].familyType === "ipv6") {
                                bfdConfigs.splice(i, 1);
                                i--;
                            }
                        }
                    }
                }
            }
        }
        if(payload["configInfo"] && payload["configInfo"]["lag.Interface"] && payload["configInfo"]["lag.Interface"]["lagNameId"]  && neType.startsWith("7705")) {
            delete payload["configInfo"]["lag.Interface"]["lagNameId"];
        }
       if (!payload.configInfo["lag.Interface"].hasOwnProperty("monitorOperGroupName")) {
        // Add the property with a null value to clear
          payload.configInfo["lag.Interface"].monitorOperGroupName = '';
       }
       payload = ipv6AddressUtil.expandIPv6(payload);
       if (payload.configInfo["lag.Interface"].hasOwnProperty("children-Set")) {
          let childrenSet = payload.configInfo["lag.Interface"]["children-Set"];
          if (childrenSet.hasOwnProperty("lag.PortTermination")) {
             childrenSet["lag.PortTermination"].forEach(portTermination => {
                if (portTermination.memberName) {
                   let portPointer = nfmpSuggest.getPortData(neId, portTermination.memberName, "objectFullName");
                   portTermination.portPointer = portPointer;
                }
             });
          }
          if (payload.configInfo && payload.configInfo["lag.Interface"] && payload.configInfo["lag.Interface"]["children-Set"] && payload.configInfo["lag.Interface"]["children-Set"]["lag.LinkMapProfile"]) {
             payload.configInfo["lag.Interface"]["children-Set"]["lag.LinkMapProfile"].forEach(data => {
                if (data["children-Set"] && data["children-Set"]["lag.LinkMapProfilePort"]) {
                   data["children-Set"]["lag.LinkMapProfilePort"].forEach(linkMapProfilePort => {
                      if (linkMapProfilePort.portId) {
                         let portData = nfmpSuggest.getPortData(neId, linkMapProfilePort.portId, "snmpPortId");
                         linkMapProfilePort.portId = portData;
                      }
                   });
                }
             });
          }
       }
       return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, deviceConfig) {
       let neId= deviceConfig["siteId"];
       if (xpath == "lag-LinkMapProfile.lag-LinkMapProfilePort.portId") {
          let portName = nfmpSuggest.getPortDataForBF(neId, targetValue);
          if (portName) {
             targetValue = portName;
          }
       }
       return targetValue;
    }

    this.isObjectExists = function (className, objectFullName) {
        let nfmpFwk = new NfmpFwk();
        let searchObjectJson = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        logger.info("Searched Result = {}", JSON.stringify(resultFetch));
        return resultFetch;
    }
}