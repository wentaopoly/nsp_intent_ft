var RuntimeException = Java.type('java.lang.RuntimeException');

load({
    script: resourceProvider.getResource('mdc-fwk.js'),
    name: 'MdcFwk'
});
load({
    script: resourceProvider.getResource('parse-target.js'),
    name: 'ParseTarget'
});


function MdcDiscoveryHelper() {

    let mdcFwk = new MdcFwk();
    let parseTarget = new ParseTarget();

    let neId;
    let interfaceName;

    this.getDeviceConfiguration = function (targetWithTemplate, initialPropertyName) {

        neId = parseTarget.getNeIdFromTarget(targetWithTemplate);
        interfaceName = parseTarget.getUniqueIdentifier(targetWithTemplate);
        let url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base/" + initialPropertyName + "=" + interfaceName;
        let getResult = mdcFwk.fetch(neId, url);
        let configFromDevice = getResult.msg["nokia-conf:" + initialPropertyName];
        if (configFromDevice == undefined) {
            throw "cannot get configuration from device"
        }

        if (configFromDevice[0]['loopback']) {
            configFromDevice[0]['loopback'] = "";
        }

        return configFromDevice[0];
    }

    this.extractDeviceConfig = function (targetData, deviceConfig, initialPropertyName,intfName) {
        let parsedTargetData = JSON.parse(targetData);
        let url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base";
        let getResult = mdcFwk.fetch(neId, url);
        let configFromDevice = getResult.msg["nokia-conf:router"][0];
        if (configFromDevice == undefined) {
            throw "cannot get configuration from device"
        }

        let interfaces = configFromDevice['interface'];
        let networkInterface = undefined;
        for (let i = 0; i < interfaces.length; i++) {

            if (interfaces[i]['interface-name'] === intfName) {
                networkInterface = interfaces[i];
                break;
            }

        }

        if (networkInterface == undefined) {
            throw "cannot get configuration from device"
        }

        configFromDevice['interface'] = networkInterface;

        if (configFromDevice['interface']['loopback']) {
            configFromDevice['interface']['loopback'] = "";
        }

        let ospfWithInterface = [];
        let shouldAddOspf = false;
        let ospfList = configFromDevice['ospf'];
        if (ospfList) {
            for (let ospfCount = 0; ospfCount < ospfList.length; ospfCount++) {
                let ospfInstanceObj = ospfList[ospfCount];
                let areaList = ospfInstanceObj['area'];
                if (areaList) {
                    let areaWithInterface = [];
                    let shouldAddArea = false;
                    for (let areaCount = 0; areaCount < areaList.length; areaCount++) {
                        let ospfInterfaceList = areaList[areaCount]['interface'];
                        if (ospfInterfaceList) {
                            logger.info("MdcDiscoveryHelper -> extractDeviceConfig-> networkInterface  ***************** :: " + JSON.stringify(intfName));
                            let ospfInterface = this.getProtocolInterface(intfName, ospfInterfaceList);
                            logger.info("MdcDiscoveryHelper -> extractDeviceConfig-> ospfInterface  ***************** :: " + ospfInterface);

                            if (ospfInterface) {
                                areaList[areaCount]['interface'] = [ospfInterface];
                                shouldAddOspf = true;
                                shouldAddArea = true;
                            } else {
                                delete areaList[areaCount]['interface'];
                            }
                        }

                        if (shouldAddArea) {
                            areaWithInterface.push(areaList[areaCount]);
                            break;
                        }
                    }
                    ospfInstanceObj['area'] = areaWithInterface;
                }

                if (shouldAddOspf) {
                    ospfWithInterface.push(ospfInstanceObj);
                    break;
                }
            }
        }
        configFromDevice['ospf'] = ospfWithInterface;

        let ospf3List = configFromDevice['ospf3'];
        let ospf3WithInterface = []
        let shouldAddospf3 = false;
        if (ospf3List) {
            for (let ospf3Count = 0; ospf3Count < ospf3List.length; ospf3Count++) {
                let ospf3InstanceObj = ospf3List[ospf3Count];
                let area3List = ospf3InstanceObj['area'];
                let area3WithInterface = [];
                let shouldAddarea3 = false;
                if (area3List) {
                    for (let area3Count = 0; area3Count < area3List.length; area3Count++) {
                        let ospf3InterfaceList = area3List[area3Count]['interface'];
                        if (ospf3InterfaceList) {
                            let ospf3Interface = this.getProtocolInterface(intfName, ospf3InterfaceList);
                            if (ospf3Interface) {
                                area3List[area3Count]['interface'] = [ospf3Interface];
                                shouldAddospf3 = true;
                                shouldAddarea3 = true;
                            } else {
                                delete area3List[area3Count]['interface'];
                            }
                        }
                        if (shouldAddarea3) {
                            area3WithInterface.push(area3List[area3Count]);
                            break;
                        }
                    }

                    ospf3InstanceObj['area'] = area3WithInterface;
                }

                if (shouldAddospf3) {
                    ospf3WithInterface.push(ospf3InstanceObj);
                    break;
                }
            }
        }
        configFromDevice['ospf3'] = ospf3WithInterface;

        let isLdpRequired = true;
        if (configFromDevice['ldp']) {
            if (configFromDevice['ldp']['interface-parameters']) {
                if (configFromDevice['ldp']['interface-parameters']['interface']) {
                    let ldpInterfaces = configFromDevice['ldp']['interface-parameters']['interface'];
                    let ldpInterface = this.getLdpProtocolInterface(intfName, ldpInterfaces);
                    if (ldpInterface) {
                        configFromDevice['ldp']['interface-parameters']['interface'] = [ldpInterface];
                    } else {
                        configFromDevice['ldp']['interface-parameters']['interface'] = [];
                    }
                }
            }
        } else {
            isLdpRequired = false;
        }

        let isMplsRsvpRequired = true;
        if (configFromDevice['mpls']) {
            let mplsInterfaceList = configFromDevice['mpls']['interface'];
            if (mplsInterfaceList) {
                let mplsInterface = this.getProtocolInterface(intfName, mplsInterfaceList);
                if (mplsInterface) {
                    configFromDevice['mpls']['interface'] = [mplsInterface]
                    let rsvpInterfaceList = configFromDevice['rsvp']['interface'];
                    if (rsvpInterfaceList) {
                        let rsvpInterface = this.getProtocolInterface(intfName, rsvpInterfaceList);
                        if (rsvpInterface) {
                            configFromDevice['rsvp']['interface'] = [rsvpInterface];
                        }
                    } else {
                        configFromDevice['rsvp']['interface'] = [];
                    }
                } else {
                    configFromDevice['mpls']['interface'] = [];
                    configFromDevice['rsvp']['interface'] = [];
                }
            }
        } else {
            isMplsRsvpRequired = false;
        }

        let isIsisInstanceHaveInterface = false;
        if (configFromDevice['isis']) {
            let isisInstances = configFromDevice['isis'];
            let isisInstance = undefined;

            for (let isisI = 0; isisI < isisInstances.length; isisI++) {
                isisInstance = isisInstances[isisI];
                let isisInterfaces = isisInstance['interface'];
                let isisInterface = this.getProtocolInterface(intfName, isisInterfaces);
                if (isisInterface) {
                    isisInstance['interface'] = [isisInterface];
                    isIsisInstanceHaveInterface = true;
                    configFromDevice['isis'] = [isisInstance];
                    break;
                }
            }

        }


        let routerObjects = ['interface', 'ospf', 'ospf3', 'ldp', 'mpls', 'rsvp', 'isis'];
        for (let i = 0; i < routerObjects.length; i++) {
            let routerObj = routerObjects[i];
            let config = JSON.stringify(parsedTargetData[routerObj][0]);
            if ((routerObj === 'ospf' || routerObj === 'ospf3' || routerObj === 'isis') && configFromDevice[routerObj] != undefined) {
                let stringData = '['
                for (let j = 0; j < configFromDevice[routerObj].length; j++) {
                    let deviceConfigObj = configFromDevice[routerObj][j];
                    let infoObj = this.traverse(JSON.parse(config), deviceConfigObj);
                    stringData = stringData + JSON.stringify(infoObj);
                    if (configFromDevice[routerObj].length - 1 != j) {
                        stringData = stringData + ","
                    }
                }
                stringData = stringData + "]";
                parsedTargetData[routerObj] = JSON.parse(stringData);

            } else {
                let config = parsedTargetData[routerObj];
                let deviceConfigObj = configFromDevice[routerObj];
                let mergedTargetData = this.traverse(config, deviceConfigObj);
                parsedTargetData[routerObj] = mergedTargetData;
            }


        }

        if (parsedTargetData['interface']['loopback'] || parsedTargetData['interface']['loopback'] === "") {
            parsedTargetData['interface']['port-binding'] = "loopback";
        } else {
            parsedTargetData['interface']['port-binding'] = "port";
            if (parsedTargetData['interface']['port']) {
                let portData = parsedTargetData['interface']['port'].split(':');
                parsedTargetData['interface']['port'] = portData[0];
                if (portData[1]) {
                    let tags = portData[1].split('.');
                    parsedTargetData['interface']['outer-tag'] = tags[0];
                    parsedTargetData['interface']['inner-tag'] = tags[1];
                }
            }
        }

        if (!isLdpRequired) {
            delete parsedTargetData['ldp']
        }

        if (!isMplsRsvpRequired) {
            delete parsedTargetData['mpls'];
            delete parsedTargetData['rsvp'];
        }

        if(!isIsisInstanceHaveInterface)
        {
            delete parsedTargetData['isis'];
        }

        return parsedTargetData;
    }

    this.getProtocolInterface = function (nwInterfaceName, interfaceList) {
        let protocolInterface = undefined;
        if (interfaceList) {
            for (let i = 0; i < interfaceList.length; i++) {
                if (interfaceList[i]['interface-name'] === nwInterfaceName) {
                    protocolInterface = interfaceList[i];
                    break;
                }
            }
        }
        return protocolInterface;
    }

    this.getLdpProtocolInterface = function (nwInterfaceName, interfaceList) {
        let protocolInterface = undefined;
        if (interfaceList) {
            for (let i = 0; i < interfaceList.length; i++) {
                if (interfaceList[i]['ip-int-name'] === nwInterfaceName) {
                    protocolInterface = interfaceList[i];
                    break;
                }
            }
        }
        return protocolInterface;
    }


    this.traverse = function (targetData, deviceConfig) {

        if (targetData !== null && targetData !== undefined && deviceConfig !== null && deviceConfig !== undefined) {
            let keys = Object.keys(targetData);
            for (let i = 0; i < keys.length; i++) {
                let propertyName = keys[i];
                let deviceValue = deviceConfig[propertyName];
                if (deviceValue != undefined && Array.isArray(deviceValue)) {
                    targetData[propertyName] = this.ArrayTraverse(targetData[propertyName], deviceValue, []);
                } else if (deviceValue != undefined && typeof deviceValue === 'object') {
                    targetData[propertyName] = this.containerTraverse(targetData[propertyName], deviceValue, {});
                } else {
                    targetData[propertyName] = deviceValue
                }
            }

        }
        return targetData;
    }

    this.ArrayTraverse = function (arrayTargetData, arrayDeviceConfigData, arrayData) {
        if (arrayTargetData != undefined && arrayTargetData != '') {
            for (let i = 0; i < arrayDeviceConfigData.length; i++) {
                let arrayObject = {};
                let keys = Object.keys(arrayTargetData[0]);
                logger.info("keys :: " + keys);
                for (let j = 0; j < keys.length; j++) {
                    let propertyName = keys[j];
                    let deviceValue = arrayDeviceConfigData[i][propertyName];
                    if (deviceValue != null && deviceValue != undefined && Array.isArray(deviceValue)) {
                        if (arrayTargetData[0][propertyName] != null) {
                            arrayObject[propertyName] = this.ArrayTraverse(arrayTargetData[0][propertyName], deviceValue, []);
                        }

                    } else if (deviceValue != null && deviceValue != undefined && typeof deviceValue === 'object') {
                        arrayObject[propertyName] = this.containerTraverse(arrayTargetData[0][propertyName], deviceValue, {});

                    } else {
                        arrayObject[propertyName] = deviceValue
                    }
                }
                arrayData.push(arrayObject);
            }
        }

        return arrayData;
    }

    this.containerTraverse = function (containerTargetData, containerDeviceConfigData, targetContainer) {
        let keys = Object.keys(containerTargetData);
        for (let i = 0; i < keys.length; i++) {
            let propertyName = keys[i];
            let deviceValue = containerDeviceConfigData[propertyName];
            if (deviceValue != null && deviceValue != undefined && Array.isArray(deviceValue)) {
                if (this.isAtrributeLeafList(deviceValue)) {
                    targetContainer[propertyName] = deviceValue;
                } else {
                    targetContainer[propertyName] = this.ArrayTraverse(containerTargetData[propertyName], deviceValue, []);
                }

            } else if (deviceValue != null && deviceValue != undefined && typeof deviceValue === 'object') {
                targetContainer[propertyName] = this.containerTraverse(containerTargetData[propertyName], deviceValue, {});
            } else {
                targetContainer[propertyName] = deviceValue
            }
        }
        return targetContainer;
    }

    this.isAtrributeLeafList = function (leaflistData) {
        let isLeaflist = true;
        for (let i = 0; i < leaflistData.length; i++) {

            if (leaflistData[i] != null && typeof leaflistData[i] == 'object') {
                isLeaflist = false;
                break;
            }
        }
        return isLeaflist;
    }

}
