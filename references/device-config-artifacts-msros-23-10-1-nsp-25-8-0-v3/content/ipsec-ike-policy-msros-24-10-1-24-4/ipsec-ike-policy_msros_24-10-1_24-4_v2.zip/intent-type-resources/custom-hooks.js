function CustomHooks() {
    /**
   * PreAudit Hook
   */
  const preAudit = (inputObj) => {
     /**
     * Write your custom preAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer, 
     *          uniqueIdentifier, deviceYangModuleName
     *           
     */
    
    logger.info("[CUSTOM-HOOKS] preAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

    var target = inputObj["target"];
    var intentConfig = inputObj["intentConfig"];
    var neId = parseTarget.getNeIdFromTarget(target);
    intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
    logger.info("preAudit intent config after removing deviation attributes: " + JSON.stringify(intentConfig));
    inputObj["intentConfig"] = intentConfig;
    let config = inputObj["intentConfig"];
    if(config && config["ike-transform"]) {
      config["ike-transform"].sort();
      let con = [];
      config["ike-transform"].forEach((item) => {
        con.push(JSON.parse(item));
      });
      config["ike-transform"] = con;
    }
    inputObj["intentConfig"] = config;
  };

  /**
   * PostAudit Hook
   */
  const postAudit = (inputObj) => {
    /**
     * Write your custom postAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName, auditReport
     *
     */

    logger.info("[CUSTOM-HOOKS] postAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
  };

  /**
   * PreSync Hook
   */
  const preSync = (inputObj) => {
    /**
     * Write your custom preSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] preSync call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));


    let config = JSON.parse(inputObj["config"]);
    if(config && config[0]["ipsec-ike-policy_msros_24-10-1_24-4:ipsec-ike-policy_msros_24-10-1_24-4"] && config[0]["ipsec-ike-policy_msros_24-10-1_24-4:ipsec-ike-policy_msros_24-10-1_24-4"]["ike-policy"] && config[0]["ipsec-ike-policy_msros_24-10-1_24-4:ipsec-ike-policy_msros_24-10-1_24-4"]["ike-policy"]["ike-version-1"] && config[0]["ipsec-ike-policy_msros_24-10-1_24-4:ipsec-ike-policy_msros_24-10-1_24-4"]["ike-policy"]["ike-version-1"]["ph1-responder-delete-notify"] == false && JSON.stringify(config[0]["ipsec-ike-policy_msros_24-10-1_24-4:ipsec-ike-policy_msros_24-10-1_24-4"]["ike-policy"]["limit-init-exchange"]) != {}) {
      delete config[0]["ipsec-ike-policy_msros_24-10-1_24-4:ipsec-ike-policy_msros_24-10-1_24-4"]["ike-policy"]["ike-version-1"]["ph1-responder-delete-notify"];
    }
    inputObj["config"] = JSON.stringify(config);

    var target = inputObj["target"];
    config = this.removeEmptyContainers("", config, "", target);

    if(config[0]["ipsec-ike-policy_msros_24-10-1_24-4:ipsec-ike-policy_msros_24-10-1_24-4"] && config[0]["ipsec-ike-policy_msros_24-10-1_24-4:ipsec-ike-policy_msros_24-10-1_24-4"]["ike-policy"]  && config[0]["ipsec-ike-policy_msros_24-10-1_24-4:ipsec-ike-policy_msros_24-10-1_24-4"]["ike-policy"]["ike-transform"]) {
      let configTrans = config[0]["ipsec-ike-policy_msros_24-10-1_24-4:ipsec-ike-policy_msros_24-10-1_24-4"]["ike-policy"]["ike-transform"];
      configTrans.sort();
      config[0]["ipsec-ike-policy_msros_24-10-1_24-4:ipsec-ike-policy_msros_24-10-1_24-4"]["ike-policy"]["ike-transform"] = configTrans;
    }

    if(config && config[0]["ipsec-ike-policy_msros_24-10-1_24-4:ipsec-ike-policy_msros_24-10-1_24-4"] && config[0]["ipsec-ike-policy_msros_24-10-1_24-4:ipsec-ike-policy_msros_24-10-1_24-4"]["ike-policy"] && config[0]["ipsec-ike-policy_msros_24-10-1_24-4:ipsec-ike-policy_msros_24-10-1_24-4"]["ike-policy"]["ike-version-2"] == undefined && config[0]["ipsec-ike-policy_msros_24-10-1_24-4:ipsec-ike-policy_msros_24-10-1_24-4"]["ike-policy"]["limit-init-exchange"] != undefined){

      throw new RuntimeException('The Limit Init Exchange feature is supported only when IKE Version 2 is configured. Ensure that IKEv2 is enabled to utilize this functionality.');
    }

    inputObj["config"] = JSON.stringify(config);
    return JSON.stringify(inputObj);
  };

  /**
   * PostSync Hook
   */
  const postSync = (inputObj) => {
    /**
     * Write your custom postSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] postSync call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

  };

  /**
   *
   * PostDiscovery Hook
   */
  const postDiscovery = (inputObj) => {
    /**
     * Write your custom postDiscovery logic here
     * inputObj by default contains the following keys:
     *        deviceConfig, intentContainer, neId,
     *        targetDataStruct, templateName, deviceYangModuleName
     */

    logger.info("[CUSTOM-HOOKS] postDiscovery call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

  }

  this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }

  this.preAudit = preAudit;
  this.postAudit = postAudit;
  this.preSync = preSync;
  this.postSync = postSync;
  this.postDiscovery = postDiscovery;

}
