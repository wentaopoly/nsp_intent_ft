var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
const icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
const gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})

load({script: resourceProvider.getResource("mdt-fwk.js"), name: "MdtFwk"});
var mdtFwk = new MdtFwk();

load({script: resourceProvider.getResource('nsp-restconf-fwk.js'), name: 'nsp-restconf-fwk'});
var nspRestconfFwk = new NspRestconfFwk();

let intentTypeName = "lag_cixr_23-10-1_24-4";

// example port, sap-ingress etc..
let initialPropertyName = "lag-Interface";


// unique identifier
let uniqueIdentifier = "lagId,lagNameId";

var LOG_PREFIX="[logical-lag-sr-classic]:"
/**
 * This function is starting point by IM for sync operation
 * @param input
 * @returns {*}
 */
function synchronize(input) {
    logger.info("-------------------- script-content.js -> synchronize() --------------------");
    logger.info("Intent Synchronisation started - input = {}", input)
    return NspIntentHelper.synchronize(input, intentTypeName, initialPropertyName, uniqueIdentifier);
}

/**
 * The function is starting point for audit operation in IM
 * @param input
 * @returns {*}
 */
function audit(input) {
    logger.info("-------------------- script-content.js -> audit() --------------------");
    logger.info("Intent Audit started - input = {}", input)
    return NspIntentHelper.audit(input, intentTypeName, initialPropertyName, uniqueIdentifier)
}

/**
 * This function returns NE-ID
 *
 * @param context
 * @returns {string}
 */
function getNeId(context) {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    logger.info("target : {}", target)
    if (!target) {
        target = context.getInputValues()["arguments"]["__root"]["target_objectidentifier"];
    }
    if (target) {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        } else {
            neId = target;
        }
    }
    logger.info("NeId : " + neId);
    return neId;
}

/**
 * The function is used in Brownfield discovery by ICM Framework
 * It discover's the configuration from the target device
 * and manipulate as per Template's default-target-data
 *
 * @see ICMFwk for more details
 * @param {*} input - the config data of a deployment
 * @returns result - the result of the operation
 */
function getTargetData(input) {
    logger.info("-------------------- script-content.js -> getTargetData() --------------------");
    logger.info("getTargetData input for brownfield = \n" + input);
    let target = input.target;
    let config = null;
    logger.info("target=" + target);
    let deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info("deviceConfig = {} ", JSON.stringify(deviceConfig));
    let data = gtdFwk.gtdSend(deviceConfig);
    logger.info("data = {}", JSON.stringify(data));
    logger.info("returning result = {}", JSON.stringify(data.msg.result));
    return data.msg.result;
}

function SuggestLagId(context) {
    logger.info("suggest Lag ID Context = \n" + context);
    var neId = getNeId(context);
    let lagName = undefined;
    var templateName = context.getInputValues()["target"]["templatename"];
    if(context.getInputValues()["target"]["target"])
    {
        lagName = context.getInputValues()["target"]["target"][templateName]["target_lagNameId"]
    }
    else
    {
        lagName = context.getInputValues()["target"]["lagNameId"]
    }
    return navigateInstance(neId).getLagId(neId,lagName);
}

function SuggestLagName(context) {
    logger.info("suggest Lag Name Context = \n" + context);
    var neId = getNeId(context);
    let lagId = undefined;
    var templateName = context.getInputValues()["target"]["templatename"];
    if(context.getInputValues()["target"]["target"])
    {
        lagId = context.getInputValues()["target"]["target"][templateName]["target_lagId"]
    }
    else
    {
        lagId = context.getInputValues()["target"]["lagId"]
    }
    return navigateInstance(neId).getLagName(neId,lagId);
}

function suggestMonitorOperGroup(context) {
    logger.info("suggest Monitor Oper Group Context = \n" + context);
    var neId = getNeId(context);
    return navigateInstance(neId).getMonitorOperGroup(neId);
}

function suggestUNIProfile(context) {
    logger.info("suggest UNI Profile Context = \n" + context);
    var neId = getNeId(context);
    return navigateInstance(neId).getUNIProfile(neId);
}

function suggestVlanQosPolicy(context) {
    return new NfmpSuggest().getVlanQosPolicy(getNeId(context));
}

function suggestPortName(context) {
    var data;
    var portData=[];
    var inputValues = context.getInputValues()["arguments"]["__root"];
    data = inputValues["__parent"] && inputValues["__parent"]["lag-Interface"] && inputValues["__parent"]["lag-Interface"]["lag-PortTermination"];
    if (!data) {
        data = inputValues["lag-Interface"] && inputValues["lag-Interface"]["lag-PortTermination"];
    }
    data.forEach(function (portObject) {
        logger.info("Port Name In Input : " + portObject['memberName']);
        portData.push(portObject['memberName']);
    });
    return portData;
}

function suggestPortIds(context) {
    logger.info("suggest Port Context = \n" + context);
    let neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    if (target)
    {
        neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
    }
    else
    {
        neId = context.getInputValues()["arguments"]["__parent"]["target_objectidentifier"];
    }
    var mode = context.getInputValues()["arguments"]["__parent"]["lag-Interface"]["mode"];
    var encapType = context.getInputValues()["arguments"]["__parent"]["lag-Interface"]["encapType"];
    return navigateInstance(neId).getPortIds(neId,mode,encapType);
}

function navigateInstance(neId) {
    var managerName = mdtFwk.getManagerName(neId);
    logger.info(LOG_PREFIX + 'Device: ' + neId + ' is managed by: ' + managerName);
    switch (managerName) {
        case "NFM-P":
            logger.info(LOG_PREFIX + 'Device is managed by NFMP');
            return new NfmpSuggest();
            break;
        default:
            logger.info(LOG_PREFIX + 'Device is not managed')
            throw new RuntimeException(LOG_PREFIX + 'Device is not Managed')
    }
    return '';
}
