load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {
    this.setSuccessResult = function (result, savedTopology) {
        result.setSuccess(true);
        if (savedTopology !== undefined)
        {
            result.setTopology(savedTopology);
        }
        return result;
    }
    this.reportMisaligned = function (target, result, auditReport) {
        var report = JSON.parse(result.response);
        if (!report.aligned)
        {
            for (var i = 0; i < report.misalignedAttributes.length; i++)
            {
                var attributeData = report.misalignedAttributes[i];
                if (attributeData.expected == "present")
                {
                    //misaligned object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else if (attributeData.expected == "not present")
                {
                    //undesired object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                    auditReport.addMisAlignedAttribute(misalignedAttribute);
                }

            }
        }
        return auditReport
    }
    this.editPayload = function (fdn, properties, childProperties, fullClassName, objectFullName) {
        var payload = {};
        var configInfo = {};
        configInfo["containedClassProperties"] = properties;
        configInfo["containmentInfo"] = childProperties;
        configInfo["objectClassName"] = fullClassName;
        //payload["fdn"] = fdn;
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName;
        payload["configInfo"] = configInfo;
        return payload;

    }
    /*
       function: isObjectExists
       description: To Check the Object exists or not.
  */
    this.isObjectExists = function (className, objectFullName) {
        let nfmpFwk = new NfmpFwk();
        var ret = false;
        var searchObjectJson = {
            "fullClassName": className,
            "filter": {
                "filterExpression": "fullName='" + objectFullName + "'"
            }
        };
        var resultFetch = nfmpFwk.post("search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse))
        {
            ret = true;
        }
        return ret;
    }

    /*
       function: delay
       description: Sometimes the object creation takes time, we can use delay for child-level operation.
    */
    this.delay = function (milliseconds) {
        var date = new Date();
        date.setMilliseconds(date.getMilliseconds() + milliseconds);
        while (new Date() < date)
        {
        }
    }
    this.convertPolicyTypeGreenField = function (policyType) {
        if (policyType == "access-network")
        {
            return "accessnetwork";
        }
        return policyType;
    }
    this.convertPolicyTypeBrownField = function (policyType) {
        if (policyType == "accessnetwork")
        {
            return "access-network";
        }
        return policyType;
    }
    this.convertLogEventsTypeGreenField = function (logEventType) {
        if (logEventType == false)
        {
            return "none";
        }
        else if (logEventType == true)
        {
            return "enable";
        }
        return logEventType;
    }
    this.convertLogEventsTypeBrownField = function (logEventType) {
        if (logEventType == "none")
        {
            return false;
        }
        else if (logEventType == "enable")
        {
            return true;
        }
        return logEventType;
    }
    this.convertExceedActionGreenField = function (exceedAction) {
        if (exceedAction == "low-priority")
        {
            return "lowPriority";
        }
        return exceedAction;
    }
    this.convertExceedActionBrownField = function (exceedAction) {
        if (exceedAction == "lowPriority")
        {
            return "low-priority";
        }
        return exceedAction;
    }
    this.convertHoldDownDurationGreenField = function (holdDownDuration) {
        if (holdDownDuration == "indefinite")
        {
            return "-1";
        }
        else if (holdDownDuration == "none")
        {
            return "0";
        }
        return holdDownDuration;
    }
    this.convertHoldDownDurationBrownField = function (holdDownDuration) {
        if (holdDownDuration == "-1")
        {
            return "indefinite";
        }
        else if (holdDownDuration == "0")
        {
            return "none";
        }
        return holdDownDuration;
    }
    this.convertRateGreenField = function (rate) {
        if (rate == "max")
        {
            return "-1";
        }
        return rate;
    }
    this.convertRateBrownField = function (rate) {
        if (rate == "-1")
        {
            return "max";
        }
        return rate;
    }
    this.convertProtocolTypeGreenField = function (protocolType) {
        if (protocolType === "http-redirect")
        {
            return "httpRedirect";
        }
        else if (protocolType === "pppoe-pppoa")
        {
            return "pppoePppoa";
        }
        else if (protocolType === "all-unspecified")
        {
            return "allUnspecified";
        }
        else if (protocolType === "mpls-ttl")
        {
            return "mplsTtl";
        }
        else if (protocolType === "bfd-cpm")
        {
            return "bfdCpm";
        }
        else if (protocolType === "eth-cfm")
        {
            return "ethCfm";
        }
        else if (protocolType === "icmp-ping-check")
        {
            return "icmpPingCheck";
        }
        else if (protocolType === "multi-chassis")
        {
            return "multiChassis";
        }else if (protocolType === "multi-chassis-sync")
        {
            return "multiChassisSync";
        }
        return protocolType;
    }
    this.convertProtocolTypeBrownField = function (protocolType) {
        if (protocolType === "httpRedirect")
        {
            return "http-redirect";
        }
        else if (protocolType === "pppoePppoa")
        {
            return "pppoe-pppoa";
        }
        else if (protocolType === "allUnspecified")
        {
            return "all-unspecified";
        }
        else if (protocolType === "mplsTtl")
        {
            return "mpls-ttl";
        }
        else if (protocolType === "bfdCpm")
        {
            return "bfd-cpm";
        }
        else if (protocolType === "ethCfm")
        {
            return "eth-cfm";
        }
        else if (protocolType === "icmpPingCheck")
        {
            return "icmp-ping-check";
        }
        else if (protocolType === "multiChassis")
        {
            return "multi-chassis";
        }else if (protocolType === "multiChassisSync")
        {
            return "multi-chassis-sync";
        }
        return protocolType;
    }
    this.LogEvent = function (ConfigurationData, Type) {
        var Str="false";
        if (Type!=="protocol" && ConfigurationData['log-events'] === false) {
            ConfigurationData['log-events'] = Str;
        }else if(Type==="protocol" && ConfigurationData['dynamic-parameters'] && ConfigurationData['dynamic-parameters']['log-events'] === false){
            ConfigurationData['dynamic-parameters']['log-events']=Str;
        }
        return ConfigurationData;
    }

    this.modifyNeIdForIpV6 = function (objectFullName, neId) {
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }
}
