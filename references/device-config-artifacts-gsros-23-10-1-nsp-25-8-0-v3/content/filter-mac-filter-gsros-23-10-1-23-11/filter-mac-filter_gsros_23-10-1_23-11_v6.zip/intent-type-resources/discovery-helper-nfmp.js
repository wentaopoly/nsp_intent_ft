var RuntimeException = Java.type('java.lang.RuntimeException');

load({
    script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"
});
load({
    script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'
});
load({
    script: resourceProvider.getResource("util-fwk.js"), name: "utilities"
});


function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let filterId = util.getMacFilterId(target);
        let filterName = util.getMacFilterName(target);
        let className = "aclfilter.MacFilter";
        let objectFullName = "network:" + neId + ":MAC Filter:" + filterId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        let searchPayLoad = this.constructSearchString(className, objectFullName);
        let searchResponse = nfmpFwk.find(neId, searchPayLoad);
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0)) {
            if (!(searchResponse.success)) throw new RuntimeException("Failed to get Mac filter info from nfm-p for Ne " + neId + " and Mac filter Id: " + filterId);
            if (JSON.parse(searchResponse["response"]).length === 0) throw new RuntimeException("There is no Mac filter with Name:" + filterName + " and Id:" + filterId);
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse;

    }
    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        logger.info("PARSED DEFAULT TARGET DATA : " + JSON.stringify(parsedDefaultTargetData));
        logger.info("DEVICE CONFIG : " + JSON.stringify(deviceConfig));
        let macFilterConfig = deviceConfig['aclfilter.MacFilter'];
        if (null !== macFilterConfig && macFilterConfig!==undefined) {
            this.extractMacFilterProperties(parsedDefaultTargetData, macFilterConfig);
        }
        let childrenConfig = macFilterConfig["children-Set"];
        if (undefined !== childrenConfig && null !== childrenConfig && childrenConfig.length !== 0) {

            let macFilterEntryData = parsedDefaultTargetData['mac-filter']['entry'];
            if (macFilterEntryData !== null && macFilterEntryData.length !== 0) {
                let macFilterEntryArray = this.extractMacFilterEntryData(macFilterEntryData, childrenConfig);
                parsedDefaultTargetData['mac-filter']['entry'] = macFilterEntryArray;
            }
        } else {
            delete parsedDefaultTargetData['mac-filter']['entry'];
        }
        return parsedDefaultTargetData;
    }

    this.extractMacFilterProperties = function (defaultTargetData, macFilterConfig) {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++) {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object') {
                let mappings = modelDeviceMapping.getMacFilterMapping();
                this.traverseAndUpdateConfig(targetKey, targetObj, macFilterConfig, mappings);
            }
        }
    }

    this.extractMacFilterEntryData = function (defaultMacFilterEntry, childrenConfig) {
        let macFilterEntryDefaults = defaultMacFilterEntry[0];
        let macFilterEntryArray = [];
        let childrenConfigeration = childrenConfig["aclfilter.MacFilterEntry"];
        if (Array.isArray(childrenConfigeration)) {
            for (let i = 0; i < childrenConfigeration.length; i++) {
                let childConfig = childrenConfigeration[i];
                let macFilterEntryData = this.MacFilterEntryData(macFilterEntryDefaults, childConfig);
                macFilterEntryArray.push(macFilterEntryData);
            }
        } else {
            let childConfig = childrenConfigeration;
            let macFilterEntryData = this.MacFilterEntryData(macFilterEntryDefaults, childConfig);
            macFilterEntryArray.push(macFilterEntryData);

        }
        return macFilterEntryArray;
    }
    this.MacFilterEntryData = function (macFilterEntryDefaults, childConfig) {
        let macFilterEntryData = JSON.parse(JSON.stringify(macFilterEntryDefaults));
        macFilterEntryData['entry-id'] = childConfig['id'];
        macFilterEntryData['description'] = childConfig['description'];
        macFilterEntryData['pbr-down-action-override'] = util.brownFieldTransformNfmpPbrName(childConfig['pbrDownActionOvr']);
        macFilterEntryData['match']['snap-oui'] = util.brownFieldTransformNfmpSnapOuiName(childConfig['snapOui']);
        macFilterEntryData['match']['frame-type'] = util.transformBrownfieldProtocol(childConfig['frameType']);
        if(childConfig['collectStats']!=="false"){
            macFilterEntryData['collect-stats'] = childConfig['collectStats'];
        }
        if (childConfig['stickyDestHoldTimeUp'] == '-1') {
            macFilterEntryData['sticky-dest'] = undefined;
        } else {
            macFilterEntryData['sticky-dest'] = childConfig['stickyDestHoldTimeUp'];
        }
        if (childConfig['snapPid'] === '-1') {
            macFilterEntryData['match']['snap-pid'] = undefined;
        } else {
            macFilterEntryData['match']['snap-pid'] = childConfig['snapPid'];
        }

        if (childConfig['sourceMacAddress'] === '00-00-00-00-00-00' && childConfig['sourceMacAddressMask'] === '00-00-00-00-00-00') {
            macFilterEntryData['match']['src-mac'] = undefined;
        } else {
            macFilterEntryData['match']['src-mac']['address'] = util.brownFieldNfmpValidMacAddress(childConfig['sourceMacAddress']);
            macFilterEntryData['match']['src-mac']['mask'] = util.brownFieldNfmpValidMacAddress(childConfig['sourceMacAddressMask']);
        }
        if (childConfig['destinationMacAddress'] === '00-00-00-00-00-00' && childConfig['destinationMacAddressMask'] === '00-00-00-00-00-00') {
            macFilterEntryData['match']['dst-mac'] = undefined;
        } else {
            macFilterEntryData['match']['dst-mac']['address'] = util.brownFieldNfmpValidMacAddress(childConfig['destinationMacAddress']);
            macFilterEntryData['match']['dst-mac']['mask'] = util.brownFieldNfmpValidMacAddress(childConfig['destinationMacAddressMask']);
        }
        if (childConfig['dot1pValue'] === 'default' && childConfig['dot1pMask'] === 'priority_0') {
            macFilterEntryData['match']['dot1p'] = undefined;
        } else {
            macFilterEntryData['match']['dot1p']['priority'] = util.brownFieldNfmpdot1p(childConfig['dot1pValue']);
            macFilterEntryData['match']['dot1p']['mask'] = util.brownFieldNfmpdot1p(childConfig['dot1pMask']);
        }
        if (childConfig['ssap'] === '-1' && childConfig['ssapMask'] === '-1') {
            macFilterEntryData['match']['llc-ssap'] = undefined;
        } else {
            macFilterEntryData['match']['llc-ssap']['ssap'] = childConfig['ssap']
            macFilterEntryData['match']['llc-ssap']['mask'] = childConfig['ssapMask'];
        }
        if (childConfig['dsap'] === '-1' && childConfig['dsapMask'] === '-1') {
            macFilterEntryData['match']['llc-dsap'] = undefined;
        } else {
            macFilterEntryData['match']['llc-dsap']['dsap'] = childConfig['dsap'];
            macFilterEntryData['match']['llc-dsap']['mask'] = childConfig['dsapMask'];
        }
        if (childConfig['innerTagValue'] === '-1' && childConfig['innerTagMask'] === '4095') {
            macFilterEntryData['match']['inner-tag'] = undefined;
        } else {
            macFilterEntryData['match']['inner-tag']['tag'] = childConfig['innerTagValue'];
            macFilterEntryData['match']['inner-tag']['mask'] = childConfig['innerTagMask'];
        }
        if (childConfig['outerTagValue'] === '-1' && childConfig['outerTagMask'] === '4095') {
            macFilterEntryData['match']['outer-tag'] = undefined;
        } else {
            macFilterEntryData['match']['outer-tag']['tag'] = childConfig['outerTagValue'];
            macFilterEntryData['match']['outer-tag']['mask'] = childConfig['outerTagMask'];
        }
        if (childConfig['isidLow'] === '-1' && childConfig['isidHigh'] === '-1') {
            macFilterEntryData['match']['isid'] = undefined;
        } else if(childConfig['isidLow']===childConfig['isidHigh']){
            //Both Low and High Value are Equal assuming High Value
            macFilterEntryData['match']['isid']['value'] = childConfig['isidHigh'];
        }else{
            macFilterEntryData['match']['isid']['range']['start'] = childConfig['isidLow'];
            macFilterEntryData['match']['isid']['range']['end'] = childConfig['isidHigh'];
        }
        if (childConfig['ethernetType'] === '-1') {
            macFilterEntryData['match']['etype'] = undefined;
        } else if(childConfig['ethernetType']) {
            let eType=childConfig['ethernetType'];
            macFilterEntryData['match']['etype'] = "0x" + Number(eType).toString(16);
        }
        if (childConfig['logId'] === '0') {
            macFilterEntryData['log'] = undefined;

        } else {
            macFilterEntryData['log'] = childConfig['logId'];
        }
        this.clearEmptiesAndNull(macFilterEntryData);
        macFilterEntryData['action'] = new Object();
        if (childConfig['action'] == 'forward') {
            macFilterEntryData['action']['accept'] = [null];
        } else if (childConfig['action'] == 'drop') {
            macFilterEntryData['action']['drop'] = [null];
        } else if (childConfig['action'] == 'ignoreMatch') {
            macFilterEntryData['action']['ignore-match'] = [null];
        } else if (childConfig['action'] == 'httpredirect') {
            macFilterEntryData['action']['http-redirect'] = new Object();
            macFilterEntryData['action']['http-redirect']['url'] = childConfig["redirectURL"];
        } else if (childConfig['action'] == "ratelimit") {
            macFilterEntryData['action']['accept'] = [null];
            macFilterEntryData['action']['rate-limit'] = new Object();
            if (childConfig['rateLimit'] == '-1') {
                macFilterEntryData['action']['rate-limit']['pir'] = "max";
            } else if (childConfig['rateLimit'] !== undefined) {
                macFilterEntryData['action']['rate-limit']['pir'] = childConfig['rateLimit'];
            } else {
                macFilterEntryData['action']['rate-limit'] = undefined;

            }
        }
        if (childConfig['action'] == 'forward') {
            if(childConfig['forwardFcType']){
                macFilterEntryData['action']["fc"] = new Object();
                macFilterEntryData["action"]["fc"]=childConfig['forwardFcType'];
            }
        }
        if (childConfig['fwdSapPortName'] !== 'N/A') {
            macFilterEntryData['action']['forward'] = new Object();
            macFilterEntryData['action']['forward']['sap'] = new Object();
            if (childConfig['fwdSapPortName'] === 'N/A') {
                macFilterEntryData['action']['forward']['sap'] = undefined;
            } else if (childConfig['fwdSapPortName'] !== 'N/A' && childConfig['fwdSapOuterEncapValue'] === '0' && childConfig['fwdSapInnerEncapValue'] === '0') {
                macFilterEntryData['action']['forward']['sap']['sap-id'] = childConfig['fwdSapPortName'];
            } else {
                macFilterEntryData['action']['forward']['sap']['sap-id'] = util.brownFieldSap(childConfig['fwdSapPortName'], childConfig['fwdSapOuterEncapValue'], childConfig['fwdSapInnerEncapValue'], childConfig['fwdSapEncapType']);
            }
        }
        if (childConfig['fwdSdpBindPathId'] !== '0' && childConfig['fwdSdpBindVcId'] !== '0') {
            macFilterEntryData['action']['forward'] = new Object();
            macFilterEntryData['action']['forward']['sdp'] = new Object();
            if (childConfig['fwdSdpBindPathId'] === '0' && childConfig['fwdSdpBindVcId'] === '0') {
                macFilterEntryData['action']['forward']['sdp'] = undefined;
            } else {
                macFilterEntryData['action']['forward']['sdp']['sdp-bind-id'] = childConfig['fwdSdpBindPathId'] + ':' + childConfig['fwdSdpBindVcId'];
            }
        }
        if (childConfig['secondaryFwdSapPortName'] !== 'N/A'&& childConfig['secondaryAction']!=='none') {
            macFilterEntryData['action']['secondary'] = new Object();
            macFilterEntryData['action']['secondary']['forward'] = new Object();
            macFilterEntryData['action']['secondary']['forward']['sap'] = new Object();
            if (childConfig['secondaryFwdSapPortName'] === 'N/A') {
                macFilterEntryData['action']['secondary']['forward']['sap'] = undefined;
            } else if (childConfig['secondaryFwdSapPortName'] !== 'N/A' && childConfig['secondaryFwdSapOuterEncapValue'] === '0' && childConfig['secondaryFwdSapInnerEncapValue'] === '0') {
                macFilterEntryData['action']['secondary']['forward']['sap']['sap-id'] = childConfig['secondaryFwdSapPortName'];
            } else {
                macFilterEntryData['action']['secondary']['forward']['sap']['sap-id'] = util.brownFieldSap(childConfig['secondaryFwdSapPortName'], childConfig['secondaryFwdSapOuterEncapValue'], childConfig['secondaryFwdSapInnerEncapValue'], childConfig['secondaryFwdSapEncapType']);
            }
        }
        if (childConfig['secondaryFwdSdpBindPathId'] !== '0' && childConfig['secondaryFwdSdpBindVcId'] !== '0' && childConfig['secondaryAction']!=='none') {
            macFilterEntryData['action']['secondary'] = new Object();
            macFilterEntryData['action']['secondary']['forward'] = new Object();
            macFilterEntryData['action']['secondary']['forward']['sdp'] = new Object();
            if (childConfig['secondaryFwdSdpBindPathId'] === '0' && childConfig['secondaryFwdSdpBindVcId'] === '0') {
                macFilterEntryData['action']['secondary']['forward']['sdp'] = undefined;
            } else {
                macFilterEntryData['action']['secondary']['forward']['sdp']['sdp-bind-id'] = childConfig['secondaryFwdSdpBindPathId'] + ':' + childConfig['secondaryFwdSdpBindVcId'];
            }
        }
        if (childConfig['action'] === 'forwardEsi') {
            macFilterEntryData['action']['forward'] = new Object();
            macFilterEntryData['action']['forward']['esi-l2'] = new Object();
            if (childConfig['fwdEsiValue'] === '00:00:00:00:00:00:00:00:00:00' && childConfig['fwdEsiVplsServicePointer'] == "") {
                macFilterEntryData['action']['forward']['esi-l2'] = undefined;
            } else {
                macFilterEntryData['action']['forward']['esi-l2']['esi-value'] = childConfig['fwdEsiValue'];
                macFilterEntryData['action']['forward']['esi-l2']['vpls'] = childConfig['fwdEsiVplsServicePointer'];
            }
        }
        return macFilterEntryData;

    }

    this.traverseAndUpdateConfig = function (objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "mac-filter.entry") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }


    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, parsedDeviceConfig) {
        // Get the key from mapping against targetKey
        // If the mapping key is not undefined, Get the value from deviceKey
        // if the value from deviceConfig against that mapping key is not n
        let nfmpKey = mappings[mappedKey];
        let deviceValue = parsedDeviceConfig[nfmpKey];
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue, parsedDeviceConfig);

    }

    this.transformDeviceValue = function (mappedKey, deviceValue, parsedDeviceConfig) {
        if (deviceValue !== null) {
            switch (mappedKey) {
                case "mac-filter.default-action":
                    deviceValue = util.transformIntentDefaultAction(deviceValue);
                    break;
                default:
            }
            return deviceValue;
        }
    }


    this.constructSearchString = function (className, objectFullName) {
        let searchJson = {
            "fullClassName": className, "filter": {
                "equal": {
                    "name": "objectFullName", "value": objectFullName
                }
            }
        };
        return searchJson;
    }

    this.clearEmptiesAndNull = function (o) {
        for (let k in o) {
            if (o[k] === null) {
                delete o[k];
            }
            if (!o[k] || typeof o[k] !== "object") {
                continue
            }

            this.clearEmptiesAndNull(o[k]);
            if (Object.keys(o[k]).length === 0) {
                delete o[k];
            }
        }
    }
}
