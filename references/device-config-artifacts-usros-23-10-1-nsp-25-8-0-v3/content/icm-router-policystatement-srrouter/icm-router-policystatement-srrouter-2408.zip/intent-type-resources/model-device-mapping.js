function ModelDeviceMapping() {

  this.getMapping = function(type){
    switch(type){
      case "policy":
        return this.getPolicyStatementMapping();
      case "entry":
        return this.getPolicyStatementEntryMapping();
      case "entryAction":
        return this.getPolicyStatementEntryActionMapping();
      case "entryAddCommunity":
        return this.getPolicyStatementEntryAddCommunityMapping();
      case "fromCriteria":
        return this.getPolicyStatementEntryFromCriteriaMapping();
      case "fromCriteriaPrefixList":
        return this.getPolicyStatementEntryFromCriteriaPrefixListMapping();
      case "toCriteria":
        return this.getPolicyStatementEntryToCriteriaMapping();
      default:
        return this.getPolicyStatementMapping();
        //return this.get
    }
  }

  this.getPolicyStatementMapping = function() {
    var mapping = {};
    mapping['policy-statement.default-action.action-type'] = 'action';

    return mapping;
  }

  this.getPolicyStatementEntryMapping = function() {
    var mapping = {};
    mapping['policy-statement.entry.entry-id'] = 'entryId';
    mapping['policy-statement.entry.description'] = 'description';

    return mapping;
  }

  this.getPolicyStatementEntryActionMapping = function() {
    var mapping = {};
    mapping['policy-statement.entry.action.local-preference'] = 'localPreference';
    mapping['policy-statement.entry.action.preference'] = 'preference';

    return mapping;
  }

  this.getPolicyStatementEntryAddCommunityMapping = function() {
    var mapping = {};
    mapping['policy-statement.entry.action.community.add'] = 'addCommunityName';

    return mapping;
  }

  this.getPolicyStatementEntryFromCriteriaMapping = function() {
    var mapping = {};
    mapping['policy-statement.entry.from.family'] = 'family';
    mapping['policy-statement.entry.from.protocol.name'] = 'protocolBits';

    return mapping;
  }

  this.getPolicyStatementEntryFromCriteriaPrefixListMapping = function() {
    var mapping = {};
    mapping['policy-statement.entry.from.prefix-list'] = 'addPrefixListMemberName';

    return mapping;
  }

  this.getPolicyStatementEntryToCriteriaMapping = function() {
    var mapping = {};
    mapping['policy-statement.entry.to.protocol.name'] = 'protocolBits';

    return mapping;
  }
}
