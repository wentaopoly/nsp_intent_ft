load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {

  this.getData = function (searchObjectJson, className, type) {
        var nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        logger.info("resultFetch = {}",JSON.stringify(resultFetch));
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    if(!value[type].startsWith("_tmnx_"))
                    {
                        ret.push(value[type]);
                    }
                })
            }
        }

        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

    this.getZone = function (neId) {
        var className = "securitypolicy.Zone";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "id");
    }

    this.getSourceNetworkInterface = function (neId, zoneId) {
        var className = "rtr.NetworkInterface";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "nodeId",
                            "value": neId
                        },
                        {
                          "name": "zoneId",
                          "value": zoneId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "displayedName");
    }

    this.getSecurityPolicyPointer = function (neId) {
        logger.info("NEID " + neId);
        var className = "securitypolicy.Policy";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "id");
    }

    this.getSecurityLog = function (neId) {
        var className = "nodelog.SecurityLog";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "id");
    }

    this.getVPRNService = function (neId) {
        var className = "vprn.Site";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "serviceId"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "serviceId");
    }

    this.getVPRNServiceID = function (neId, vprnId) {
        var className = "vprn.Site";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "serviceId",
                            "value": vprnId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "svcComponentId"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        var responseKey = className;
        var finalResponse = JSON.parse(resultFetch.response);
        var data = (finalResponse[responseKey] && finalResponse[responseKey]["svcComponentId"]);
        return data;
    }

    this.getVPRNID = function (neId, epipeId) {
        var className = "vprn.Site";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "svcComponentId",
                            "value": epipeId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "serviceId"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        logger.info("RESULT FETCH : " + JSON.stringify(resultFetch));
        var responseKey = className;
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("FINAL RESPONSE : " + JSON.stringify(finalResponse));
        var data = (finalResponse[responseKey] && finalResponse[responseKey]["serviceId"]);
        logger.info("FINAL DATA : " + JSON.stringify(data));
        return data;
    }

    this.getIESService = function (neId) {
        var className = "ies.Site";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "serviceId"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "serviceId");
    }

    this.getIESServiceID = function (neId, iesId) {
        var className = "ies.Site";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "serviceId",
                            "value": iesId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "svcComponentId"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        var responseKey = className;
        var finalResponse = JSON.parse(resultFetch.response);
        var data = (finalResponse[responseKey] && finalResponse[responseKey]["svcComponentId"]);
        return data;
    }

    this.getIESID = function (neId, epipeId) {
        var className = "ies.Site";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "svcComponentId",
                            "value": epipeId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "serviceId"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        logger.info("RESULT FETCH : " + JSON.stringify(resultFetch));
        var responseKey = className;
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("FINAL RESPONSE : " + JSON.stringify(finalResponse));
        var data = (finalResponse[responseKey] && finalResponse[responseKey]["serviceId"]);
        logger.info("FINAL DATA : " + JSON.stringify(data));
        return data;
    }

    this.getVPLSService = function (neId) {
        var className = "vpls.Site";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "serviceId"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "serviceId");
    }

    this.getVPLSServiceID = function (neId, vplsId) {
        var className = "vpls.Site";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "serviceId",
                            "value": vplsId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "svcComponentId"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        var responseKey = className;
        var finalResponse = JSON.parse(resultFetch.response);
        var data = (finalResponse[responseKey] && finalResponse[responseKey]["svcComponentId"]);
        return data;
    }

    this.getVPLSID = function (neId, epipeId) {
        var className = "vpls.Site";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "svcComponentId",
                            "value": epipeId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "serviceId"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        logger.info("RESULT FETCH : " + JSON.stringify(resultFetch));
        var responseKey = className;
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("FINAL RESPONSE : " + JSON.stringify(finalResponse));
        var data = (finalResponse[responseKey] && finalResponse[responseKey]["serviceId"]);
        logger.info("FINAL DATA : " + JSON.stringify(data));
        return data;
    }

    this.getMVPLSService = function (neId) {
        var className = "mvpls.Site";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "serviceId"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "serviceId");
    }

    this.getMVPLSServiceID = function (neId, mvplsId) {
        var className = "mvpls.Site";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "serviceId",
                            "value": mvplsId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "svcComponentId"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        var responseKey = className;
        var finalResponse = JSON.parse(resultFetch.response);
        var data = (finalResponse[responseKey] && finalResponse[responseKey]["svcComponentId"]);
        return data;
    }

    this.getMVPLSID = function (neId, epipeId) {
        var className = "mvpls.Site";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "svcComponentId",
                            "value": epipeId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "serviceId"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        logger.info("RESULT FETCH : " + JSON.stringify(resultFetch));
        var responseKey = className;
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("FINAL RESPONSE : " + JSON.stringify(finalResponse));
        var data = (finalResponse[responseKey] && finalResponse[responseKey]["serviceId"]);
        logger.info("FINAL DATA : " + JSON.stringify(data));
        return data;
    }

    this.getEPIPEService = function (neId) {
        var className = "epipe.Site";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "serviceId"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "serviceId");
    }

    this.getEPIPEServiceID = function (neId, epipeId) {
        var className = "epipe.Site";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "serviceId",
                            "value": epipeId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "svcComponentId"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        logger.info("RESULT FETCH : " + JSON.stringify(resultFetch));
        var responseKey = className;
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("FINAL RESPONSE : " + JSON.stringify(finalResponse));
        var data = (finalResponse[responseKey] && finalResponse[responseKey]["svcComponentId"]);
        logger.info("FINAL DATA : " + JSON.stringify(data));
        return data;
    }

    this.getEPIPEID = function (neId, epipeId) {
        var className = "epipe.Site";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "svcComponentId",
                            "value": epipeId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "serviceId"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        logger.info("RESULT FETCH : " + JSON.stringify(resultFetch));
        var responseKey = className;
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("FINAL RESPONSE : " + JSON.stringify(finalResponse));
        var data = (finalResponse[responseKey] && finalResponse[responseKey]["serviceId"]);
        logger.info("FINAL DATA : " + JSON.stringify(data));
        return data;
    }

    this.getSourceVPRNL3AccessInterface = function (neId, zoneId) {
        var className = "vprn.L3AccessInterface";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "nodeId",
                            "value": neId
                        },
                        {
                          "name": "zoneId",
                          "value": zoneId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "displayedName");
    }

    this.getSourceIESL3AccessInterface = function (neId, zoneId) {
        var className = "ies.L3AccessInterface";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "nodeId",
                            "value": neId
                        },
                        {
                          "name": "zoneId",
                          "value": zoneId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "displayedName");
    }

    this.getObjectFullNameNetworkInterface = function(neId, networkId) {
      var className = "rtr.NetworkInterface";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "nodeId",
                            "value": neId
                        },
                        {
                          "name": "displayedName",
                          "value": networkId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "objectFullName"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));

        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        var responseKey = className;
        var finalResponse = JSON.parse(resultFetch.response);
        var data = (finalResponse[responseKey] && finalResponse[responseKey]["objectFullName"]);
        return data;
        //return this.getData(searchObject, className, "objectFullName")[0];
    }

    this.getVPRNInterface = function(neId, networkId) {
      var className = "vprn.L3AccessInterface";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "nodeId",
                            "value": neId
                        },
                        {
                          "name": "displayedName",
                          "value": networkId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "objectFullName"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));

        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        var responseKey = className;
        var finalResponse = JSON.parse(resultFetch.response);
        var data = (finalResponse[responseKey] && finalResponse[responseKey]["objectFullName"]);
        return data;
        //return this.getData(searchObject, className, "objectFullName")[0];
    }

    this.getVPRNInterfaceID = function(neId, networkId) {
      var className = "vprn.L3AccessInterface";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "nodeId",
                            "value": neId
                        },
                        {
                          "name": "objectFullName",
                          "value": networkId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));

        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        var responseKey = className;
        var finalResponse = JSON.parse(resultFetch.response);
        var data = (finalResponse[responseKey] && finalResponse[responseKey]["displayedName"]);
        return data;
        //return this.getData(searchObject, className, "objectFullName")[0];
    }

    this.getIESInterface = function(neId, networkId) {
      var className = "ies.L3AccessInterface";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "nodeId",
                            "value": neId
                        },
                        {
                          "name": "displayedName",
                          "value": networkId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "objectFullName"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));

        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        var responseKey = className;
        var finalResponse = JSON.parse(resultFetch.response);
        var data = (finalResponse[responseKey] && finalResponse[responseKey]["objectFullName"]);
        return data;
        //return this.getData(searchObject, className, "objectFullName")[0];
    }

    this.getIESInterfaceID = function(neId, networkId) {
      var className = "ies.L3AccessInterface";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "nodeId",
                            "value": neId
                        },
                        {
                          "name": "objectFullName",
                          "value": networkId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));

        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        var responseKey = className;
        var finalResponse = JSON.parse(resultFetch.response);
        var data = (finalResponse[responseKey] && finalResponse[responseKey]["displayedName"]);
        return data;
        //return this.getData(searchObject, className, "objectFullName")[0];
    }

    this.getInterfacePointerID = function(neId, networkId) {
      var className = "rtr.NetworkInterface";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "nodeId",
                            "value": neId
                        },
                        {
                          "name": "objectFullName",
                          "value": networkId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info("final search object = {}", JSON.stringify(searchObject));

        let nfmpFwk = new NfmpFwk();
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        var responseKey = className;
        var finalResponse = JSON.parse(resultFetch.response);
        var data = (finalResponse[responseKey] && finalResponse[responseKey]["displayedName"]);
        return data;
        //return this.getData(searchObject, className, "objectFullName")[0];
    }
}
