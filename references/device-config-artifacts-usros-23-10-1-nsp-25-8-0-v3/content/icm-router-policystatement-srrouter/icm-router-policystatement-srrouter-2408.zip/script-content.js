var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};


load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

var intentTypeName = 'icm-router-policystatement-srrouter';
var initialPropertyName = 'policy-statement';
var parentXpath = 'configure/policy-options';
var uniqueIdentifier = 'name';

function synchronize(input) {
    logger.info('Intent Synchronisation started')

    return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started')

    return NspIntentHelper.audit(target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier)
}

function suggestProtocol(context) {

    var protocals = [];
    protocals.push('bgp');
    protocals.push('isis');
    protocals.push('ospf');
    protocals.push('bgp-vpn');
    protocals.push('ldp');
    protocals.push('bgp-label')
    return protocals;
}

function suggestFamily(context) {

    var family = [];
    family.push('ipv4');
    family.push('ipv6');
    family.push('vpn-ipv4');
    family.push('vpn-ipv6');
    family.push('mcast-ipv4');
    family.push('mcast-ipv6');

    return family;
}

function getTargetData(input) {
    logger.info(input);
    var target = input.target;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}