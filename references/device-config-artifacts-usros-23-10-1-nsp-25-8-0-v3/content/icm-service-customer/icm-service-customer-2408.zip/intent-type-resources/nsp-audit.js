load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
function NSPAudit()
{
    var util = new utilities();
    this.handleAudit = function (target, config, svcTopo, adminState, report, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier)
    {
        var intentConfig = util.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        var customerID = target.split("#")[3];
        intentConfig[uniqueIdentifier] = target.split("#")[2];
        intentConfig['customer-id'] = parseInt(customerID);
        if (intentConfig['customer-name'] != undefined )
        {
            intentConfig['customer-name'] = intentConfig['customer-name'].toString();
        }
        if (intentConfig['description'] != undefined )
        {
            intentConfig['description'] = intentConfig['description'].toString();
        }
        if (intentConfig['contact'] != undefined )
        {
            intentConfig['contact'] = intentConfig['contact'].toString();
        }
        if (intentConfig['phone'] != undefined )
        {
            intentConfig['phone'] = intentConfig['phone'].toString();
        }

        logger.info("Audit Config = {}",JSON.stringify(intentConfig))

        var configFromNsp = nspRestconfFwk.getNspCustomer(customerID);

        logger.info("Customer Data From NSP : "+JSON.stringify(configFromNsp))

        this.compare(parentXpath,initialPropertyName,report,intentConfig,configFromNsp);

    }

    this.compare = function(parentXpath, initialPropertyName, report, intentJson,targetJson)
    {
        for (var key in intentJson)
        {
            if(key != "sites" && intentJson[key] !== targetJson[key])
            {
                report.addMisAlignedAttribute(auditFactory.createMisAlignedAttribute(parentXpath + "/" + initialPropertyName + "/" + key, intentJson[key], targetJson[key], "NSP"));
            }
            else if (key == "sites")
            {
                if(!Array.isArray(intentJson[key]))
                {
                    intentJson[key] = [intentJson[key]];
                }
                if(!Array.isArray(targetJson[key]))
                {
                    targetJson[key] = [targetJson[key]];
                }
                for (var i in intentJson[key])
                {
                    var site = intentJson[key][i];
                    if(!this.includes(site,targetJson[key]))
                    {
                        var atrName = parentXpath + "/" + initialPropertyName + "/" + key + "/" + JSON.stringify(site);
                        report.addMisAlignedObject(auditFactory.createMisAlignedObject(atrName, false));
                    }
                }
                if(targetJson[key].length > 0)
                {
                    for(var index in targetJson[key])
                    {
                        var site = targetJson[key][index];
                        var atrName = parentXpath + "/" + initialPropertyName + "/" + key + "/" + JSON.stringify(site);
                        report.addMisAlignedObject(auditFactory.createMisAlignedObject(atrName, true));
                    }
                }
            }
        }
    }

    this.includes = function(obj,arr)
    {
        for (var item in arr)
        {
            if(JSON.stringify(obj) === JSON.stringify(arr[item]))
            {
                delete arr[item];
                return true
            }
        }
        return false
    }

}