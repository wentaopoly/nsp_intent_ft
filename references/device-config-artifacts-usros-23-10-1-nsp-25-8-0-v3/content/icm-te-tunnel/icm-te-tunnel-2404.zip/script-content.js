var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource('ietf-intent-helper.js'), name: 'ietf-intent-helper.js'});
load({script: resourceProvider.getResource('intent-logger.js'), name: 'intent-logger.js'});
var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders" : "anv-device-holders"
};
var prefixToNsMap = {
    "ibn" : "http://www.nokia.com/management-solutions/ibn",
    "nc" : "urn:ietf:params:xml:ns:netconf:base:1.0"
};

load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'mediator-fwk.js'});
var nspMediator = new MediatorFramework("NSP");

var imfwk = new IntentHelper();
var imLogger = new IntentLogger();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource("nspSuggest.js"), name: "NspSuggest"})
nspSuggest = new NspSuggest();

var extensionConfigObject = {
    getDevicesInvolved: function() {
        var requestContext = requestScope.get();
        var intentConfigJson = requestContext.get("intentConfigJson");
        imLogger.debug("[script-content][getDevicesInvolved] intentConfigJson {}",  JSON.stringify(intentConfigJson));
        var ret = [];
        if (intentConfigJson["source"]){
            ret.push(intentConfigJson["source"]);
        } else
            throw new RuntimeException('Tunnel Source not found');

        if (intentConfigJson["bidirectional"] == true && intentConfigJson["destination"] ){
            ret.push(intentConfigJson["destination"]);
        }

        imLogger.info("[script-content][getDevicesInvolved] {}",  JSON.stringify(ret));
        return ret;
    },

    setIntentTypeNameAndVersion: function() {
        var requestContext = requestScope.get();
        requestContext.put("intentType", "ietf-te-tunnel");
        var lVersion = ietfUtils.getIntentTypeVersion("ietf-te-tunnel",requestContext.get("target"));
        if (!lVersion){ //BrownField case
            lVersion = 1
        }
        requestContext.put("intentTypeVersion", lVersion);
    }
};

imfwk.setExtensionConfig(extensionConfigObject);
icmFwk.setExtensionConfig(extensionConfigObject);

function synchronize(input) {
    return imfwk.synchronize(input);
}

function audit(input) {
    return imfwk.audit(input);
}

function validate(input) {
    //imfwk.validate(input);
}

function getTargetData(input) {
    logger.info("getTargetData: Brownfield invoked, input = {}", input);
    var requestContext = icmFwk.setRequestContext(input);
    imLogger.info("[script-content][getTargetData] {}",  requestContext);
    var target = input.target;
    var config = null;
    var deviceConfig = icmFwk.getDeviceConfiguration(target,requestContext);
    logger.info(JSON.stringify(deviceConfig));
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}

function suggestSites(context) {
    logger.info("suggestSites: context = {} ", context);
    var neId = getNeId(context);
    logger.info("suggestSites: neId = {} ", neId);
    var attribute = context.getInputValues()["arguments"]["__attribute"];
    logger.info("suggestSites: attribute = {} ", attribute);
    var result = [];
    if(attribute == "source") {
        result.push(neId);
    }else {
        result = nspSuggest.getSites(neId);
    }
    logger.info("suggestSites: result = {} ", JSON.stringify(result));
    return result;
}

function getNeId(context) {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    logger.info(target)
    if (target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    logger.info("NeId : " + neId);
    return neId;
}