load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
load({script: resourceProvider.getResource("parse-target.js"), name: "ParseTarget"});
load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
var parseTarget = new ParseTarget();
function CustomHooks() {
var ipv6AddressUtil = new IPv6AddressUtil();
var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,5}(:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){6}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(\/(0|[1-9][0-9]?|1[0-1][0-9]?|12[0-8]))?$/;
    /**
   * PreAudit Hook
   */
  const preAudit = (inputObj) => {
     /**
     * Write your custom preAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName
     *
     */

    let target = inputObj.target;
    let intentConfig = inputObj.intentConfig;
    logger.info("[CUSTOM-HOOKS] preAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
    logger.info("preAudit call for Subinterface intent config deviation");
    var intentDeviationObj = new IntentDeviceDeviation();
    var neId = parseTarget.getNeIdFromTarget(target);
    intentConfig = intentDeviationObj.removeIntentConfig(JSON.stringify(intentConfig), neId);
    intentConfig = this.expandIPv6(intentConfig);
    logger.info("preAudit intent config after removing deviation attributes: " + JSON.stringify(intentConfig));
    inputObj.intentConfig = intentConfig;
    return inputObj;
  };

  /**
   * PostAudit Hook
   */
  const postAudit = (inputObj) => {
    /**
     * Write your custom postAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName, auditReport
     *
     */

    logger.info("[CUSTOM-HOOKS] postAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));


  };

  /**
   * PreSync Hook
   */
  const preSync = (inputObj) => {
    /**
     * Write your custom preSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] preSync call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));


    let target = inputObj.target;
    let intentTypeName = inputObj.intentTypeName;
    let intentContainer = inputObj.intentContainer;


    let config = JSON.parse(inputObj.config);
    config = this.expandIPv6(config);
    logger.info("preSync call for Ipv4 intent deviation implementation");
    var intentDeviationObj = new IntentDeviceDeviation();
    var neId = parseTarget.getNeIdFromTarget(target)
    //config = JSON.parse(config);
    if (!Array.isArray(config)) {
        config = [config];
    }
    let preSyncConf = [];
    for (var index in config) {
        let configObj = JSON.stringify(config[index][intentTypeName + ":" + intentTypeName][intentContainer]);
        let deviatedObj = intentDeviationObj.removeIntentConfig(configObj, neId);
        let finalConfigObj = {};
        let intentKey = intentTypeName + ":" + intentTypeName
        finalConfigObj[intentKey] = {};
        finalConfigObj[intentKey][intentContainer] = deviatedObj;
        preSyncConf.push(finalConfigObj);
    }
    inputObj.config = JSON.stringify(preSyncConf);
    logger.info("intent config after removing deviation attributes: " + JSON.stringify(preSyncConf));
    return JSON.stringify(inputObj);
  };

  /**
   * PostSync Hook
   */
  const postSync = (inputObj) => {
    /**
     * Write your custom postSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] postSync call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));


  };

  /**
   *
   * PostDiscovery Hook
   */
  const postDiscovery = (inputObj) => {
    /**
     * Write your custom postDiscovery logic here
     * inputObj by default contains the following keys:
     *        deviceConfig, intentContainer, neId,
     *        targetDataStruct, templateName, deviceYangModuleName
     */

    logger.info("[CUSTOM-HOOKS] postDiscovery call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

    let deviceConfig = inputObj.deviceConfig;

    if(deviceConfig["loopback"]) {
      deviceConfig["loopback"] = true;
    }
    if(deviceConfig["interface"] && deviceConfig["interface"]["ipv4"] && deviceConfig["interface"]["ipv4"]["unnumbered"] && deviceConfig["interface"]["ipv4"]["unnumbered"]["system"]) {
      deviceConfig["interface"]["ipv4"]["unnumbered"]["system"] = true;
    }

  }

   this.expandIPv6 = function (obj) {
        for (var key in obj) {
            if (typeof obj[key] === 'object' && obj[key] !== null) {
                this.expandIPv6(obj[key]);
            } else if (typeof obj[key] === 'string' && this.matchExact(ipv6Regex, obj[key])) {
                obj[key] = this.expandIPv6AddressForMd(obj[key]);
        }
      }
      return obj
    }
    this.matchExact = function(r, str) {
       var match = str.match(r);
       return match && str === match[0];
    }

    this.expandIPv6AddressForMd = function (input) {
       var expanded = ipv6AddressUtil.expandIPv6Address(input);
       expanded = ipv6AddressUtil.MdIpv6ValidAddresssMaskSupport(expanded);
       return expanded;
    };

  this.preAudit = preAudit;
  this.postAudit = postAudit;
  this.preSync = preSync;
  this.postSync = postSync;
  this.postDiscovery = postDiscovery;

}
