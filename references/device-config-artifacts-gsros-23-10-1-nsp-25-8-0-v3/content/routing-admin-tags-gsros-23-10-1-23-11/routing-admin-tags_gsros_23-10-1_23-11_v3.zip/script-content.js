var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();

var intentTypeName = 'routing-admin-tags_gsros_23-10-1_23-11';

// example port, sap-ingress etc..
var initialPropertyName = 'admin-tags';

// unique identifier
var uniqueIdentifier = 'admin-tag';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/routing-options';

function synchronize(input) {
    logger.info('Intent Synchronisation started')
    return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

/*function audit(input) {
    logger.info('Intent Audit started')
    return NspIntentHelper.audit(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}*/

function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started')
    logger.info('Intent Audit started -------- target =  {}\n, config = {}\n, svcTopo = {}\n, adminState = {}\n', target, config, svcTopo, adminState)
    logger.info('Intent Audit started -------- target =  {}\n, config = {}\n, svcTopo = {}\n, adminState = {}\n', JSON.stringify(target), JSON.stringify(config), JSON.stringify(svcTopo), JSON.stringify(adminState))

    return NspIntentHelper.audit(target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function suggestAdminTag(context) {
    logger.info("suggestAdminTag =>\n" + context)
    return ["admin-tag"];
}

function suggestAdminTags(context) {
    logger.info(context);
    var result = [];
    var inp = JSON.parse(context['inputValues'])
    var adminTagList = inp['arguments']['__parent']['__parent']['admin-tags'];

    if (adminTagList)
    {
        var adminTags = adminTagList['admin-tag'];
        logger.info(adminTags);
        logger.info(JSON.stringify(adminTags));

        if (!Array.isArray(adminTags))
        {
            adminTags = [adminTags];
        }
        for (var i = 0; i < adminTags.length; i++)
        {
            logger.info("adminTags[i] = {}", JSON.stringify(adminTags[i]['tag']))
            result.push(adminTags[i]['tag']);
        }
    }
    return result;
}

function getTargetData(input) {
    logger.info(input);
    var target = input.target;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}
