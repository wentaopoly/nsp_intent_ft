function MdSuggest() {

    this.getInterfaceName = function (neId) {
        const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router/interface?fields=interface-name`;
        return this.getSuggestData(neId, url, "nokia-conf:interface", "interface-name");
    }

    this.getSuggestData = function(neId, url, initialProperty, propertyName) {
        const mdcFwk = new MdcFwk();
        const resultFetch = mdcFwk.fetch(neId, url);
        const finalResponse = resultFetch.msg[initialProperty];
        const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data[propertyName]).filter(value => value != null):[];
        logger.info("ret =", JSON.stringify(ret));
        return ret;
    }
}
