var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk'});
load({ script: resourceProvider.getResource('traverse-fwk.js'), name: 'TraverseFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function MdcIntentFwk() {
    
    this.restResponseHandler = function(exception, httpStatus, response) {
        logger.info("[IntentMgr] REST response : " + response);
        logger.info("[IntentMgr] REST httpStatus : " + httpStatus);
        if (exception) {
            throw new RuntimeException("Couldn't connect to device proxy for ; Response: "+response);
        };
        if (httpStatus !== 200 && httpStatus !== 201) {
            throw new RuntimeException("Failed to access device  using MDC; Response: "+response);
        };
        restResponse = JSON.parse(response);
    };

    this.synchronize = function(input, result,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {
     
      var traverseFwk = new TraverseFwk();
      var parseTarget = new ParseTarget();
      var target = parseTarget.getNeIdFromTarget(input.getTarget());
      
      // saved topology
      var savedTopology = input.getCurrentTopology();

      if(savedTopology == null){
            savedTopology = topologyFactory.createServiceTopology();
      }
      
      if (input.getNetworkState().name() == "delete"){
          logger.info(JSON.stringify(savedTopology));
          traverseFwk.resetTheVariables();
          result = traverseFwk.deleteAllFromTopology(savedTopology,target,result);
          return result;
        
      }
  
      var intentConfig;
     
      if(target !== "0.0.0.0"){
            var intentConfig;
            intentConfig  = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
            intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget()); 
            if (intentConfig){
                savedTopology = traverseFwk.traverse(target,intentConfig,savedTopology,null,parentXpath,initialPropertyName);
              
              //sorting delete array
                var deleteRequests = traverseFwk.getDeleteRequests();
                deleteRequests.sort(function(a, b){
                                return b["target"].length - a["target"].length;
                });

              // concating createrequests and deleterequests
                var createRequests = traverseFwk.getCreateRequests();
                var requests;
                if(deleteRequests && createRequests){
                    requests = createRequests.concat(deleteRequests);
                }
                if ( requests ){
                    result = traverseFwk.syncRequest(target,requests,result,savedTopology);
                }
          
            }else{  
                   
                    result = traverseFwk.deleteAllFromTopology(savedTopology,target,result); 
            }
        
       }
      traverseFwk.resetTheVariables();
      return result;
    }

    this.audit = function(target, config, svcTopo, adminState, report,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {
      var currentConfig;
      var traverseFwk = new TraverseFwk();
      var parseTarget = new ParseTarget();
      currentConfig  = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
      currentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
      var target = parseTarget.getNeIdFromTarget(target); 
      if(target !== "0.0.0.0"){
         
         svcTopo = traverseFwk.traverse(target,currentConfig,svcTopo,report,parentXpath,initialPropertyName);
         // reseting the variables
         traverseFwk.resetTheVariables();
      }
      
      return report;
      
    }

    this.getNodes = function(context) {
      var returnVal = []
      var url = "/restconf/meta/api/v1/nes"
      try {
        var managerList = []
        var managers = mds.getAllManagersOfType("REST");
        managers.forEach(function (manager) {
          if (mds.getManagerByName(manager).getConnectivityState().toString() === 'CONNECTED') {
            managerList.push(manager)
          }
        })

        var devices = mds.getAllManagedDevicesFrom(managerList);
        
        devices.forEach(function (device) {
          returnVal.push(device.getName());
        });
        
        return returnVal;
      } catch (e) {
        logger.info("Exception *******************  : " + e);
        return {
          "Device Not Found": "Device Not Found"
        }
      }
    }

    this.xml2object = function(xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: '+ json)
        return JSON.parse(json);
    }
}
