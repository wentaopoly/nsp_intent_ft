load({script: resourceProvider.getResource("parse-target.js"), name: "ParseTarget"});
load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
function CustomHooks() {
var ipv6AddressUtil = new IPv6AddressUtil();
    /**
   * PreAudit Hook
   */
  const preAudit = (inputObj) => {
     /**
     * Write your custom preAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName
     *
     */

    logger.info("[CUSTOM-HOOKS] preAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
    var target = inputObj["target"];
    var intentConfig = inputObj["intentConfig"];
    var neId = parseTarget.getNeIdFromTarget(target);
    intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
    if (intentConfig && intentConfig["key-exchange"] && intentConfig["key-exchange"]["dynamic"]) {
        var dynamic = intentConfig["key-exchange"]["dynamic"];
        if (Array.isArray(dynamic["ipsec-transform"])) {
            var convertedList = [];
            dynamic["ipsec-transform"].forEach(function(item) {
                convertedList.push(Number(item));
            });
            dynamic["ipsec-transform"] = convertedList;
        }
        if (dynamic["id"] && dynamic["id"]["ipv6"]) {
            dynamic["id"]["ipv6"] = this.expandIPv6AddressForMd(dynamic["id"]["ipv6"]);
        }
    }
    logger.info("preAudit intent config after removing deviation attributes: " + JSON.stringify(intentConfig));
    return intentConfig;
  };

  /**
   * PostAudit Hook
   */
  const postAudit = (inputObj) => {
    /**
     * Write your custom postAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName, auditReport
     *
     */

    logger.info("[CUSTOM-HOOKS] postAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));


  };

  /**
   * PreSync Hook
   */
    /**
     * PreSync Hook
     */
    const preSync = (inputObj) => {
        /**
         * Write your custom preSync logic here
         * inputObj by default contains the following keys:
         *          target, config, intentTypeName, rootXPath,
         *          intentContainer, uniqueIdentifier, deviceYangModuleName
         *          topology, state, syncResult
         */
        logger.info("[CUSTOM-HOOKS] preSync call");
        var config = JSON.parse(inputObj["config"]);
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(config));
        var target = inputObj["target"];
        config = this.removeEmptyContainers("", config, "", target);
        var intentTypeName = inputObj["intentTypeName"];
        var intentContainer = inputObj["intentContainer"];
        var neId = parseTarget.getNeIdFromTarget(target);
        if (!Array.isArray(config)) {
            config = [config];
        }
        let preSyncConf = [];
        for (var index in config) {
            var confObj= config[index][intentTypeName + ":" + intentTypeName][intentContainer];
            let finalConfigObj = {};
            let intentKey = intentTypeName + ":" + intentTypeName
            finalConfigObj[intentKey] = {};
            finalConfigObj[intentKey][intentContainer] = confObj;
            preSyncConf.push(finalConfigObj);
        }
        logger.info("intent config after removing deviation attributes: " + JSON.stringify(preSyncConf));
        return JSON.stringify(preSyncConf);
    };

  /**
   * PostSync Hook
   */
  const postSync = (inputObj) => {
    /**
     * Write your custom postSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] postSync call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

  };

  /**
   *
   * PostDiscovery Hook
   */
  const postDiscovery = (inputObj) => {
    /**
     * Write your custom postDiscovery logic here
     * inputObj by default contains the following keys:
     *        deviceConfig, intentContainer, neId,
     *        targetDataStruct, templateName, deviceYangModuleName
     */

    logger.info("[CUSTOM-HOOKS] postDiscovery call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

  }
    this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }


    this.expandIPv6AddressForMd = function (input) {
        var expanded = ipv6AddressUtil.expandIPv6Address(input);
        expanded = ipv6AddressUtil.MdIpv6ValidAddresssMaskSupport(expanded);
        return expanded;
    };

  this.preAudit = preAudit;
  this.postAudit = postAudit;
  this.preSync = preSync;
  this.postSync = postSync;
  this.postDiscovery = postDiscovery;

}
