function ParseTarget(){

    this.getNeIdFromTarget = function(target){
        if(String(target).indexOf("ne-id") !== -1 ){
            var nedId = target.split("#")[1];
            var result = nedId.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'","").split("=")[1];
            logger.info("NeId = " + result);
            return result;
        }else{
            var neid = target.split("#")[1];
            logger.info("NeId = " + neid);
            return neid;
        }
    }

    this.getUniqueIdentifier = function(target){

        //write code here
        var uniqueIdentifier = target.split("#")[2];
        return uniqueIdentifier;

    }
}


