function IPv6AddressUtil()
{
    var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,5}(:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){6}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(\/(0|[1-9][0-9]?|1[0-1][0-9]?|12[0-8]))?$/;
    this.matchExact = function(r, str) {
        var match = str.match(r);
        return match && str === match[0];
    }
     this.expandIPv6 = function(intentJSON) {
        this.traverse(intentJSON);
        return intentJSON;
    }

    this.expandIPv6AddressForClassic =  function (address)
    {
        var fullAddress = "";
        var validGroupCount = 8;

        var ipv4 = "";
        var extractIpv4 = /([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})/;
        var validateIpv4 = /((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})/;
        // look for embedded ipv4
        if(validateIpv4.test(address))
        {
            var groups = address.match(extractIpv4);
            for(var i=1; i<groups.length; i++)
            {
                ipv4 += ("0" + (parseInt(groups[i], 10).toString(16)) ).slice(-2) + ( i==2 ? ":" : "" );
            }
            address = address.replace(extractIpv4, ipv4);
        }

        if(address.indexOf("::") == -1) // All eight groups are present.
            fullAddress = address;
        else // Consecutive groups of zeroes have been collapsed with "::".
        {
            var sides = address.split("::");
            var groupsPresent = 0;
            for(var i=0; i<sides.length; i++)
            {
                groupsPresent += sides[i].split(":").length;
            }
            fullAddress += (sides[0]? sides[0]:0) + ":";
            for(var i=0; i<validGroupCount-groupsPresent; i++)
            {
                fullAddress += "0:";
            }
            if(sides[1])
            {
                fullAddress += (sides[1].split("/")[0]?sides[1].split("/")[0]:"0")
                    + (sides[1].split("/")[1]?"/"+sides[1].split("/")[1]:"");
            }
            else
            {
                fullAddress += "0";
            }

        }
        fullAddress = this.removeLeadingZerosFromIPv6(fullAddress);
        return fullAddress.toUpperCase();
    }

    this.expandIPv6Address = function(address)
    {
        var fullAddress = "";
        var validGroupCount = 8;

        var ipv4 = "";
        var extractIpv4 = /([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})/;
        var validateIpv4 = /((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})/;

        // look for embedded ipv4
        if(validateIpv4.test(address))
        {
            var groups = address.match(extractIpv4);
            for(var i=1; i<groups.length; i++)
            {
                ipv4 += ("0" + (parseInt(groups[i], 10).toString(16)) ).slice(-2) + ( i==2 ? ":" : "" );
            }
            address = address.replace(extractIpv4, ipv4);
        }

        fullAddress = this.removeLeadingZerosFromIPv6(address);
        return fullAddress;
    }
    this.removeLeadingZerosFromIPv6 = function (ipv6Address) {
        var octets = ipv6Address.split(':');
        var modifiedOctets = [];

        for (var i = 0; i < octets.length; i++) {
            var segment = octets[i];
            if (segment === '') {
                modifiedOctets.push('');
            } else {
                if(segment.contains("/"))
                {
                    if(segment.split("/")[0])
                    {
                        modifiedOctets.push(parseInt(segment.split("/")[0], 16).toString(16) +"/" +segment.split("/")[1]);
                    }
                    else
                    {
                        modifiedOctets.push("/" +segment.split("/")[1]);
                    }

                }
                else
                {
                    modifiedOctets.push(parseInt(segment, 16).toString(16));
                }

            }
        }

        // Join the modified octets back into an IPv6 address
        var modifiedIPv6 = modifiedOctets.join(':');

        return modifiedIPv6;
    }

    this.traverse = function (obj) {
        for (var key in obj) {
            if (typeof obj[key] === 'object' && obj[key] !== null) {
                this.traverse(obj[key]);
            } else if (typeof obj[key] === 'string' && this.matchExact(ipv6Regex, obj[key])) {
                obj[key] = this.expandIPv6Address(obj[key]);
            }
        }
    }
}


