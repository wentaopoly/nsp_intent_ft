function ModelDeviceMapping() {
  this.getSapIngressMapping = function () {
    var mapping = {};
    mapping['sap-ingress.policer-allocation'] = 'policerAllocation';
    mapping['sap-ingress.scope'] = 'scope';
    mapping['sap-ingress.description'] = 'description';
    mapping['sap-ingress.ingress-classification-policy'] = 'ingClassificationPolicy';
    mapping['sap-ingress.policer-allocation']='policerAllocation';
    mapping['sap-ingress.mac-criteria.type']='macCritType';
    mapping['sap-ingress.ipv6-criteria.type']='ipv6CritType';
    mapping['sap-ingress.ip-criteria.type']='ipCritType';
    return mapping;
  }
}



