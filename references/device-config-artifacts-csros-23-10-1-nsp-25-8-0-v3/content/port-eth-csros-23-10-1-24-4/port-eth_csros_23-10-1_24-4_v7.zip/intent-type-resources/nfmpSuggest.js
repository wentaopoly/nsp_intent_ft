function NfmpSuggest() {

    this.getPolicyDefinitionName = function (neId) {
        var className = "policy.PolicyDefinition";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "isBackup",
                            "value": "false"
                        },
                        {
                            "name": "policyType",
                            "value": "portScheduler"
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, "portscheduler.Policy", "displayedName");
        return ret
    }

    this.getNetworkQueueObjectName = function (neId) {
        var className = "nqueue.Policy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "isBackup",
                            "value": "false"
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getUNIProfileName = function () {
        var className = "ethernetservice.UniProfile";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "isBackup",
                    "value": "false"
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getPortEgrHsmdaSchedulerPolicyName = function (neId) {
        var className = "portscheduler.HsmdaSchedulerPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                      "name": "siteId",
                      "value": neId
                  }, {
                        "name": "isBackup",
                        "value": "false"
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getL2ProfileName = function (neId) {
        var className = "layer2.L2Profile";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                      "name": "siteId",
                      "value": neId
                  }, {
                        "name": "isBackup",
                        "value": "false"
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getHsSchedulerName = function (neId) {
        var className = "hsqos.HsSchedulerPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                            "name": "siteId",
                            "value": neId
                        }, {
                        "name": "isBackup",
                        "value": "false"
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getHsPortPoolName = function (neId) {
        var className = "hsqos.HsPortPoolPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                            "name": "siteId",
                            "value": neId
                        }, {
                        "name": "isBackup",
                        "value": "false"
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getPortRmdName = function (neId) {
        var className = "rmd.AccessInterface";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getSapName = function (neId,snmpPortId) {
        var className = "service.L2AccessInterface";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                        "name": "nodeId",
                        "value": neId
                    }, {
                        "name": "portId",
                        "value": snmpPortId
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getVlanFilterName = function () {
        var className = "aclfilter.FilterDefinition";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                        "name": "isLocal",
                        "value": "false"
                    }, {
                        "name": "isBackup",
                        "value": "false"
                    }, {
                        "name": "filterType",
                        "value": "filterType_vlan"
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getShaperPolicyName = function (neId) {
        var className = "shaperqos.ShaperPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                            "name": "siteId",
                            "value": neId
                        }, {
                        "name": "isBackup",
                        "value": "false"
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getSystemOperGroupName = function (neId) {
        var className = "netw.SystemOperGroup";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getEgressQGroupPolicyName = function (neId) {
        var className = "qgroup.EgressQGroupPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                      "name": "siteId",
                      "value": neId
                    }, {
                        "name": "isBackup",
                        "value": "false"
                    }, {
                        "name": "policyType",
                        "value": "egressQGroup"
                    }],
                    "notEqual": [{
                        "name": "displayedName",
                        "value": "_tmnx_nat_egr_q_grp"
                    }, {
                        "name": "displayedName",
                        "value": "_tmnx_lns_esm_egr_q_grp"
                    }, {
                        "name": "displayedName",
                        "value": "policer-output-queues"
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getAccountingPolicyId = function (neId,mode) {
        var className = "accounting.Policy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": [
                    {
                        "equal": [
                            {
                                "name": "siteId",
                                "value": neId
                            }
                        ],
                        "or": {
                            "equal": [
                                {
                                    "name": "recordType",
                                    "value": "netEgressOctet"
                                },
                                {
                                    "name": "recordType",
                                    "value": "netIngressOctet"
                                },
                                {
                                    "name": "recordType",
                                    "value": "completeNetIngrEgr"
                                },
                                {
                                    "name": "recordType",
                                    "value": "combinedNetInEgOctet"
                                },
                                {
                                    "name": "recordType",
                                    "value": "netIngressPkt"
                                },
                                {
                                    "name": "recordType",
                                    "value": "netEgressPkt"
                                }
                            ]
                        }
                    }
                ]
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        if (mode == "access"){
            searchObject =  {
                "fullClassName": className,
                "filter": {
                    "and": [
                        {
                            "equal": [
                                {
                                    "name": "siteId",
                                    "value": neId
                                }
                            ],
                            "or": {
                                "equal": [
                                    {
                                        "name": "recordType",
                                        "value": "netIngressOctet"
                                    },
                                    {
                                        "name": "recordType",
                                        "value": "netIngressPkt"
                                    }
                                ]
                            }
                        }
                    ]
                },
                "resultFilter": {
                    "children": "",
                    "attribute": [
                        "id"
                    ]
                }
            };
        }
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "id");
        return ret
    }

    this.getEthAccessAccountingPolicyId = function (neId) {
        var className = "accounting.Policy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "or": {
                    "and": {
                        "equal": [{
                            "name": "isLocal",
                            "value": "false"
                        }, {
                            "name": "isBackup",
                            "value": "false"
                        }]
                    },

                    "and": {
                        "equal": {
                            "name": "siteId",
                            "value": neId
                        },
                        "or": {
                            "equal": [{
                                "name": "recordType",
                                "value": "accessEgressPkt"
                            }, {
                                "name": "recordType",
                                "value": "accessEgressOctet"
                            }, {
                                "name": "recordType",
                                "value": "combinedAccessEgress"
                            }]
                        }
                    }
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "id");
        return ret
    }

    this.getEtherAccountingPolicyId = function (neId) {
        var className = "accounting.Policy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "recordType",
                            "value": "completeEthernetPort"
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "id");
        return ret
    }

    this.getQGroupAccountingPolicyId = function (neId) {
        var className = "accounting.Policy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "or": {
                    "and": {
                        "equal": [
                            {
                                "name": "isLocal",
                                "value": "false"
                            },
                            {
                                "name": "isBackup",
                                "value": "false"
                            }
                        ]
                    },
                    "and": {
                        "equal": {
                            "name": "siteId",
                            "value": neId
                        },
                        "or": {
                            "equal": [
                                {
                                    "name": "recordType",
                                    "value": "queueGroupOctets"
                                },
                                {
                                    "name": "recordType",
                                    "value": "queueGroupPackets"
                                },
                                {
                                    "name": "recordType",
                                    "value": "combinedQueueGroup"
                                }
                            ]
                        }
                    }
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "id");
        return ret
    }

    this.getSchedulerPolicyName = function (neId) {
        var className = "vs.Policy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                          "name": "siteId",
                          "value": neId
                      }, {
                        "name": "isBackup",
                        "value": "false"
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getHsmdaEgressSecondaryShaperName = function (neId,shelfId,snmpPortId) {
        var className = "ethernetequipment.HsmdaEgressSecondaryShaper";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                        "name": "siteId",
                        "value": neId
                    }, {
                        "name": "shelfId",
                        "value": shelfId
                    }, {
                        "name": "snmpPortId",
                        "value": snmpPortId
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getHsmdaWrrPolicyName = function (neId) {
        var className = "portscheduler.HsmdaWrrPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                      "name": "siteId",
                      "value": neId
                  }, {
                        "name": "isBackup",
                        "value": "false"
                    }, {
                        "name": "policyType",
                        "value": "HsmdaWrrPolicy"
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getEgressQueueId = function (neId,queueGroupPolicyName) {
        var className = "qgroup.EgressQueue";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "containingPolicyDisplayedName",
                            "value": queueGroupPolicyName
                        },
                        {
                        "name": "siteId",
                        "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "id");
        return ret
    }

    this.getschedulerName = function (neId) {
        var className = "vs.Entry";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getIngressQGroupPolicyName = function (neId) {
        var className = "qgroup.IngressQGroupPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                      "name": "siteId",
                      "value": neId
                  }, {
                        "name": "isBackup",
                        "value": "false"
                    }, {
                        "name": "policyType",
                        "value": "ingressQGroup"
                    }],
                    "notEqual": [{
                        "name": "displayedName",
                        "value": "_tmnx_nat_ing_q_grp"
                    }, {
                        "name": "displayedName",
                        "value": "_tmnx_lns_esm_ing_q_grp"
                    }, {
                        "name": "displayedName",
                        "value": "_tmnx_nat_ing_q_grp_v2"
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getIngressQueueId = function (neId,queueGroupPolicyName) {
        var className = "qgroup.IngressQueue";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "containingPolicyDisplayedName",
                            "value": queueGroupPolicyName
                        },
                        {
                        "name": "siteId",
                        "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "id");
        return ret
    }

    this.getPolicerControlPolicyName = function (neId) {
        var className = "policing.PolicerControl";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                      "name": "siteId",
                      "value": neId
                  }, {
                        "name": "isBackup",
                        "value": "false"
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getRadiusServerPolicyName = function (neId) {
        var className = "aaa.RadiusServerPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                      "name": "siteId",
                      "value": neId
                  }, {
                        "name": "isBackup",
                        "value": "false"
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getPortName = function (neId) {
        var className = "equipment.PhysicalPort";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "portName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "portName");
        return ret
    }

    this.getMacPolicyId = function (neId) {
        var className = "MacPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                      "name": "siteId",
                      "value": neId
                  }, {
                        "name": "isBackup",
                        "value": "false"
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "id");
        return ret
    }

    this.getCaName = function (neId) {
        var className = "macsec.CASite";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "caName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "caName");
        return ret
    }

    this.getPortSchedulerPolicyName = function (neId) {
        var className = "portscheduler.Policy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                      "name": "siteId",
                      "value": neId
                  }, {
                        "name": "isBackup",
                        "value": "false"
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getHwAggShaperSchedulerPolicyName = function (neId) {
        var className = "hwaggshapersched.HwAggShaperSchedulerPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [{
                      "name": "siteId",
                      "value": neId
                  }, {
                        "name": "isBackup",
                        "value": "false"
                    }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getSlopePolicyName = function (neId) {
        var className = "slope.Policy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "isLocal",
                            "value": "true"
                        },
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getMonitorOperGroupName = function (neId) {
        var className = "service.OperGroup";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "equal":{
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "groupName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "groupName");
        return ret
    }

    this.getSchedulerName = function (neId,schedulerPolicyName) {
        var className = "vs.Entry";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "isLocal",
                            "value": "true"
                        },
                        {
                            "name": "isBackup",
                            "value": "false"
                        },
                        {
                            "name": "containingPolicyDisplayedName",
                            "value": schedulerPolicyName
                        },
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getData = function (searchObjectJson, className, type) {
        var nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    ret.push(value[type]);
                })
            }
        }

        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

}