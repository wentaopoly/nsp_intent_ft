/********************************************************************************
 * DEVICE-SPECIFIC INTENT-TYPE USED FOR NSP DEVICE CONFIGURATION (ICM)
 *   Vendor: Nokia
 *   Device families: 7750 SR, 7450 ESS, 7950 XRS, 7705 SAR, 7250 IXR
 *   Device version: 23.10.R1
 *
 * (c) 2025 by Nokia
 ********************************************************************************/
import {IntentHandlerBase} from 'common/IntentHandlerBase.mjs';
import {NSP} from 'common/NSP.mjs';
const HashMap = Java.type("java.util.HashMap");

class IntentHandler extends(IntentHandlerBase) {

	constructor() {
		super();
		this.greenFieldObjectFullName = "network:$systemAddress:shelf-$id:cardSlot-$slotId:card:daughterCardSlot-$daughterCardSlotId:daughterCard:port-$portId";
		this.greenFieldFDN = "network:$systemAddress:shelf-$id:cardSlot-$slotId:card:daughterCardSlot-$daughterCardSlotId:daughterCard";
		this.brownFieldObjectFullName = "network:$systemAddress:shelf-$id:cardSlot-$slotId:card:daughterCardSlot-$daughterCardSlotId:daughterCard:port-$portId";
		this.isPolicyIntent = false;
		this.initialPropertyName = "equipment-PhysicalPort";
		this.uniqueIdentifier = "portId";
		NSP.checkRelease(24, 11);
	}

    getBaseFdnForPort = function (target, portId) {
        if (portId.startsWith("esat"))
        {
            return this.getBaseFdnForSatellitePort(target, portId);
        }
        let portIds = portId.split("/");
        let cardSlot;
        let xiomSlot;
        let mdaSlot;
        let connector;
        let portNumber

        portIds.forEach(function (item, index) {
            // logger.info("*********************item, index = " + item + "-----" + index);
            switch (index)
            {
                case 0:
                    cardSlot = item;
                    break;
                case 1:
                    //xiom
                    if (isNaN(item))
                    {
                        xiomSlot = item;
                    }
                    else
                    {
                        mdaSlot = item;
                    }
                    break;
                case 2:
                    //connector
                    if (isNaN(item))
                    {
                        connector = item;
                    }
                    else if (mdaSlot)
                    {
                        portNumber = item;
                    }
                    else
                    {
                        mdaSlot = item;
                    }
                    break;
                case 3:
                    //connector
                    if (isNaN(item))
                    {
                        connector = item;
                    }
                    else
                    {
                        portNumber = item;
                    }
                    break;
                case 4:
                    portNumber = item;
                    break;


            }
        });

        let portDn = "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card";
        if (xiomSlot)
        {
            portDn += ":xioSlot-" + xiomSlot.substring(1) + ":xiomCard";
        }
        if (mdaSlot)
        {
            portDn += ":daughterCardSlot-" + mdaSlot + ":daughterCard";
        }
        if (connector)
        {
            portDn += ":conn-" + connector.substring(1);
        }
        if (portNumber)
        {
            portDn += ":port-" + portNumber;
        }
        if (target && String(target).indexOf(':') !== -1) {
          portDn = this.modifyNeIdForIpV6(portDn, target);
        }
        logger.info("*********************portDn = " + portDn);
        return portDn;
    }

    modifyNeIdForIpV6 = function (objectFullName, neId) {
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }

	//overwrite
	transformPayloadGreenField(payload, neId, isAudit) {
		let portAttrib = this.getPortAttributes(payload["objectFullName"], neId);
        if(payload["configInfo"]["equipment.PhysicalPort"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["macsec.MacsecInterface"]) {
            for (var index in payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["macsec.MacsecInterface"]) {
                if(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["macsec.MacsecInterface"][index] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["macsec.MacsecInterface"][index]["snmpPortId"]) {
                    delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["macsec.MacsecInterface"][index]["snmpPortId"];
                }
            }
        }
        if(isAudit) {
            payload["configInfo"]["equipment.PhysicalPort"]["portId"] = payload["configInfo"]["equipment.PhysicalPort"]["portId"].split("/")[2];
			if (!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["monitorOperGroupPointer"]) {
				payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["monitorOperGroupPointer"] = '';
			}
			if (!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["operGroupPointer"]) {
				payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["operGroupPointer"] = '';
			}
        }
		if (!isAudit) {
			if (!payload["configInfo"]["equipment.PhysicalPort"]["accountingPolicyObjectPointer"]) {
				payload["configInfo"]["equipment.PhysicalPort"]["accountingPolicyObjectPointer"] = '';
			}
			if (!payload["configInfo"]["equipment.PhysicalPort"]["ethAccessAccountingPolicyObjectPointer"]) {
				payload["configInfo"]["equipment.PhysicalPort"]["ethAccessAccountingPolicyObjectPointer"] = '';
			}
			if (!payload["configInfo"]["equipment.PhysicalPort"]["etherAccountingPolicyObjectPointer"]) {
				payload["configInfo"]["equipment.PhysicalPort"]["etherAccountingPolicyObjectPointer"] = '';
			}
			if (!payload["configInfo"]["equipment.PhysicalPort"]["monitorOperGroupPtr"]) {
				payload["configInfo"]["equipment.PhysicalPort"]["monitorOperGroupPtr"] = '';
			}
			if (!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["monitorOperGroupPointer"]) {
				payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["monitorOperGroupPointer"] = '';
			}
			if (!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["operGroupPointer"]) {
				payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["operGroupPointer"] = '';
			}
			if (payload["configInfo"]["equipment.PhysicalPort"]["otuEnable"] == "enable" && util.isObjectExists("ethernetequipment.OtuInterface", payload["distinguishedName"] + ":otu")) {
				if (portAttrib["otuEnable"] == "enable" && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.OtuInterface"]) {
					delete payload["configInfo"]["equipment.PhysicalPort"]["otuEnable"];
				}
			}
			if (portAttrib["iomType"] == "card_iom4_e_hs") {
				if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["slope.QosPool"]) {
					delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["slope.QosPool"];
				}
			}
			if (portAttrib["isPrimaryLagMember"] == "false" && portAttrib["lagMembershipId"] != 0) {
				if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["slope.QosPool"]) {
					for (var index in payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["slope.QosPool"]) {
						var qosPoolConfig = payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["slope.QosPool"][index];
						if (qosPoolConfig["slopePolicyPointer"]) {
							delete qosPoolConfig["slopePolicyPointer"];
						}
						if (qosPoolConfig["reservedCbs"]) {
							delete qosPoolConfig["reservedCbs"];
						}
						payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["slope.QosPool"][index] = qosPoolConfig;
					}
				}
			}
			if (portAttrib["administrativeState"] == "portInService" && (portAttrib["specificCardType"] == "card_imm1_oc768_tun" || portAttrib["specificCardType"] == "card_imm1_40gb_xp_tun" || portAttrib["specificCardType"] == "mda_m1_10gb_dwdm_tun" || portAttrib["specificCardType"] == "mda_m2_10gb_xp_xfp_wt" || portAttrib["specificCardType"] == "mda_imm1_oc768_tun" || portAttrib["specificCardType"] == "mda_imm1_40gb_xp_tun" || portAttrib["specificCardType"] == "mda_imm_p1_100g_tun" || portAttrib["specificCardType"] == "mda_imm_p1_100g_tun_b" || portAttrib["specificCardType"] == "mda_x2_100g_tun" || portAttrib["cardSubType"] == "pss_aluWdm260scx2OTU4Card" || portAttrib["cardSubType"] == "pss_aluWdm130scx10Card")) {
				if (portAttrib["otuEnable"] == "enable") {
					if (portAttrib["dwdmChannel"] == "0") {
						delete payload["configInfo"]["equipment.PhysicalPort"]["administrativeState"];
					}
				}
			}
		}
		if (payload["configInfo"]["equipment.PhysicalPort"]["ols"] != "enabled") {
			delete payload["configInfo"]["equipment.PhysicalPort"]["olsEgAmpGain"];
		}
		if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]) {
			if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestNonTpmrPortConfiguration"]) {
				if (!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestNonTpmrPortConfiguration"]["portCfgTLVsTxEnable"] || payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestNonTpmrPortConfiguration"]["portCfgTLVsTxEnable"].length == 0) {
					payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestNonTpmrPortConfiguration"]["portCfgTLVsTxEnable"] = {
						"bit": []
					};
					if (isAudit) {
						payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestNonTpmrPortConfiguration"]["portCfgTLVsTxEnable"] = "";
					}
				}
			}
			if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestCustomerPortConfiguration"]) {
				if (!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestCustomerPortConfiguration"]["portCfgTLVsTxEnable"] || payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestCustomerPortConfiguration"]["portCfgTLVsTxEnable"].length == 0) {
					payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestCustomerPortConfiguration"]["portCfgTLVsTxEnable"] = {
						"bit": []
					};
					if (isAudit) {
						payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestCustomerPortConfiguration"]["portCfgTLVsTxEnable"] = "";
					}
				}
			}
			if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]) {
				if (!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["portCfgTLVsTxEnable"] || payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["portCfgTLVsTxEnable"].length == 0) {
					payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["portCfgTLVsTxEnable"] = {
						"bit": []
					};
					if (isAudit) {
						payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["portCfgTLVsTxEnable"] = "";
					}
				}
				if (!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["medPortConfigTLVsTxEnable"] || payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["medPortConfigTLVsTxEnable"].length == 0) {
					payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["medPortConfigTLVsTxEnable"] = {
						"bit": []
					};
					if (isAudit) {
						payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["medPortConfigTLVsTxEnable"] = "";
					}
				}
			}
			if (payload["configInfo"]["equipment.PhysicalPort"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]) {

                let neFamily = mds.getAllInfoFromDevices(neId).get(0).getFamilyTypeRelease();
                let neType = neFamily.split(":")[0];
                let neVersion = neFamily.split(":")[1];
                let neChassisType = neFamily.split(":")[2];

				if (!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["reportAlarmBits"] || payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["reportAlarmBits"].length == 0) {

					payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["reportAlarmBits"] = {
						"bit": []
					};
					if (isAudit) {
						payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["reportAlarmBits"] = "";
					}


                    if(neChassisType == "7210 SAS-D-6F-4T" || /^7210 SAS-K/.test(neChassisType)) {

                        if(payload["configInfo"]["equipment.PhysicalPort"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"] && (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["reportAlarmBits"] == "" || (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["reportAlarmBits"]?.bit && Array.isArray(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["reportAlarmBits"]["bit"]) && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["reportAlarmBits"]["bit"].length === 0))) {
                            delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["reportAlarmBits"];
                        }
                    }

				}
				if (!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["addressedCapability"] || payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["addressedCapability"].length == 0) {
					payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["addressedCapability"] = {
						"bit": []
					};
					if (isAudit) {
						payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["addressedCapability"] = "";
					}
				}
			}
			if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.CoherentOpticalCfg"]) {
				if (!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.CoherentOpticalCfg"]["cohOptPortCfgAlarms"] || payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.CoherentOpticalCfg"]["cohOptPortCfgAlarms"].length == 0) {
					payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.CoherentOpticalCfg"]["cohOptPortCfgAlarms"] = {
						"bit": []
					};
					if (isAudit) {
						payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.CoherentOpticalCfg"]["cohOptPortCfgAlarms"] = "";
					}
				}
			}
			if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.OtuInterface"]) {
				if (!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.OtuInterface"]["cfgAlarms"] || payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.OtuInterface"]["cfgAlarms"].length == 0) {
					payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.OtuInterface"]["cfgAlarms"] = {
						"bit": []
					};
					if (isAudit) {
						payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.OtuInterface"]["cfgAlarms"] = "";
					}
				}
			}
			if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortMonitorSpecifics"]) {
				if (!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortMonitorSpecifics"]["reportAlarmBits"] || payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortMonitorSpecifics"]["reportAlarmBits"].length == 0) {
					payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortMonitorSpecifics"]["reportAlarmBits"] = {
						"bit": []
					};
					if (isAudit) {
						payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortMonitorSpecifics"]["reportAlarmBits"] = "";
					}
				}
			}
		}
		if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.AccessIngrQGroup"]) {
			for (var index in payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.AccessIngrQGroup"]) {
				var accessIngrQGroupConfig = payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.AccessIngrQGroup"][index];
				if (accessIngrQGroupConfig["queueGroupPolicyPointer"]) {
					accessIngrQGroupConfig["queueGroupName"] = accessIngrQGroupConfig["queueGroupPolicyPointer"].replace('ingressQGroup:', '');
				}
				if (!accessIngrQGroupConfig["schedulerPolicyPointer"]) {
					accessIngrQGroupConfig["schedulerPolicyPointer"] = '';
				}
				if (!accessIngrQGroupConfig["accountingPolicyPointer"]) {
					accessIngrQGroupConfig["accountingPolicyPointer"] = '';
				}
				if (accessIngrQGroupConfig["children-Set"] && accessIngrQGroupConfig["children-Set"]["ethernetequipment.AccessIngrQOverride"]) {
					for (var indx in accessIngrQGroupConfig["children-Set"]["ethernetequipment.AccessIngrQOverride"]) {
						var accessIngrQOverrideConfig = accessIngrQGroupConfig["children-Set"]["ethernetequipment.AccessIngrQOverride"][indx];
						if (!accessIngrQOverrideConfig["queueGroupName"]) {
							accessIngrQOverrideConfig["queueGroupName"] = accessIngrQGroupConfig["queueGroupName"];
						}
						accessIngrQGroupConfig["children-Set"]["ethernetequipment.AccessIngrQOverride"][indx] = accessIngrQOverrideConfig;
					}
				}
				payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.AccessIngrQGroup"][index] = accessIngrQGroupConfig;
			}
		}
		if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.NetworkEgrQGroup"]) {
			for (var index in payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.NetworkEgrQGroup"]) {
				var networkEgrQGroupConfig = payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.NetworkEgrQGroup"][index];
				if (networkEgrQGroupConfig["queueGroupPolicyPointer"]) {
					networkEgrQGroupConfig["queueGroupName"] = networkEgrQGroupConfig["queueGroupPolicyPointer"].replace('egressQGroup:', '');
				}
				if (!networkEgrQGroupConfig["policerControlPolicyPointer"]) {
					networkEgrQGroupConfig["policerControlPolicyPointer"] = '';
				}
				if (!networkEgrQGroupConfig["schedulerPolicyPointer"]) {
					networkEgrQGroupConfig["schedulerPolicyPointer"] = '';
				}
				if (!networkEgrQGroupConfig["accountingPolicyPointer"]) {
					networkEgrQGroupConfig["accountingPolicyPointer"] = '';
				}
				if (networkEgrQGroupConfig["children-Set"] && networkEgrQGroupConfig["children-Set"]["ethernetequipment.NetworkEgrQOverride"]) {
					for (var indx in networkEgrQGroupConfig["children-Set"]["ethernetequipment.NetworkEgrQOverride"]) {
						var networkEgrQOverrideConfig = networkEgrQGroupConfig["children-Set"]["ethernetequipment.NetworkEgrQOverride"][indx];
						if (!networkEgrQOverrideConfig["queueGroupName"]) {
							networkEgrQOverrideConfig["queueGroupName"] = networkEgrQGroupConfig["queueGroupName"];
						}
						networkEgrQGroupConfig["children-Set"]["ethernetequipment.NetworkEgrQOverride"][indx] = networkEgrQOverrideConfig;
					}
				}
				payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.NetworkEgrQGroup"][index] = networkEgrQGroupConfig;
			}
		}
		if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.AccessEgrQGroup"]) {
			for (var index in payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.AccessEgrQGroup"]) {
				var accessEgrQGroupConfig = payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.AccessEgrQGroup"][index];
				if (accessEgrQGroupConfig["queueGroupPolicyPointer"]) {
					accessEgrQGroupConfig["queueGroupName"] = accessEgrQGroupConfig["queueGroupPolicyPointer"].replace('egressQGroup:', '');
				}
				if (!accessEgrQGroupConfig["schedulerPolicyPointer"]) {
					accessEgrQGroupConfig["schedulerPolicyPointer"] = '';
				}
				if (!accessEgrQGroupConfig["accountingPolicyPointer"]) {
					accessEgrQGroupConfig["accountingPolicyPointer"] = '';
				}
				if (accessEgrQGroupConfig["children-Set"] && accessEgrQGroupConfig["children-Set"]["ethernetequipment.AccessEgrQOverride"]) {
					for (var indx in accessEgrQGroupConfig["children-Set"]["ethernetequipment.AccessEgrQOverride"]) {
						var accessEgrQOverrideConfig = accessEgrQGroupConfig["children-Set"]["ethernetequipment.AccessEgrQOverride"][indx];
						if (!accessEgrQOverrideConfig["queueGroupName"]) {
							accessEgrQOverrideConfig["queueGroupName"] = accessEgrQGroupConfig["queueGroupName"];
						}
						accessEgrQGroupConfig["children-Set"]["ethernetequipment.AccessEgrQOverride"][indx] = accessEgrQOverrideConfig;
					}
				}
				payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.AccessEgrQGroup"][index] = accessEgrQGroupConfig;
			}
		}
		if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["equipment.EgrSchVirtualPort"]) {
			for (var index in payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["equipment.EgrSchVirtualPort"]) {
				var egrSchVirtualPortConfig = payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["equipment.EgrSchVirtualPort"][index];
				if (!egrSchVirtualPortConfig["portSchedulerPolicyPointer"]) {
					egrSchVirtualPortConfig["portSchedulerPolicyPointer"] = '';
				}
				if (!egrSchVirtualPortConfig["schedulerPolicyPointer"]) {
					egrSchVirtualPortConfig["schedulerPolicyPointer"] = '';
				}
				payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["equipment.EgrSchVirtualPort"][index] = egrSchVirtualPortConfig;
			}
		}
		if (payload["configInfo"]["equipment.PhysicalPort"]["otuEnable"] == "disable") {
			if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.OtuInterface"]) {
				delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.OtuInterface"];
			}
		}
		if (payload["configInfo"]["equipment.PhysicalPort"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]  && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["networkMode"] != "wan") {
			if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortSpecifics"]) {
				delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortSpecifics"];
			}
			if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortOverheadSpecifics"]) {
				delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortOverheadSpecifics"];
			}
			if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortMonitorSpecifics"]) {
				delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortMonitorSpecifics"];
			}
		}
		if (payload["configInfo"]["equipment.PhysicalPort"]["transceiverDco"] == "disabled" && (portAttrib["specificCardType"] == "mda_me1_100gb_cfp2" || portAttrib["specificCardType"] == "mda_x4_100g_cfp2" || portAttrib["specificCardType"] == "mda_maxp1_100gb_cfp2" || portAttrib["specificCardType"] == "mda_maxp1_100gb_cfp" || portAttrib["specificCardType"] == "mda_cx2_100g_cfp" || portAttrib["specificCardType"] == "mda_imm_p1_100g_cfp" || portAttrib["specificCardType"] == "mda_m4_10g_sfp_plus_1_100g_cfp2")) {
			if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]) {
				if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.PortDwdmConfig"]) {
					delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.PortDwdmConfig"];
				}
				if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.CoherentOpticalCfg"]) {
					delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.CoherentOpticalCfg"];
				}
			}
		}

        //Removing readOnly properties from the payload
        if(payload["configInfo"]["equipment.PhysicalPort"]["portClass"]) {
            delete payload["configInfo"]["equipment.PhysicalPort"]["portClass"];
        }
        if(payload["configInfo"]["equipment.PhysicalPort"]["specificCardType"]) {
            delete payload["configInfo"]["equipment.PhysicalPort"]["specificCardType"];
        }
        if(payload["configInfo"]["equipment.PhysicalPort"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["children-Set"]["lldp.TransmitMgmtAddress"]) {
            for (var index in payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["children-Set"]["lldp.TransmitMgmtAddress"]) {
			    delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["children-Set"]["lldp.TransmitMgmtAddress"][index]["portCfgManAddress"];
		    }
        }
        if(payload["configInfo"]["equipment.PhysicalPort"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestCustomerPortConfiguration"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestCustomerPortConfiguration"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestCustomerPortConfiguration"]["children-Set"]["lldp.TransmitMgmtAddress"]) {
            for (var index in payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestCustomerPortConfiguration"]["children-Set"]["lldp.TransmitMgmtAddress"]) {
			    delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestCustomerPortConfiguration"]["children-Set"]["lldp.TransmitMgmtAddress"][index]["portCfgManAddress"];
		    }
        }
        if(payload["configInfo"]["equipment.PhysicalPort"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestNonTpmrPortConfiguration"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestNonTpmrPortConfiguration"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestNonTpmrPortConfiguration"]["children-Set"]["lldp.TransmitMgmtAddress"]) {
            for (var index in payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestNonTpmrPortConfiguration"]["children-Set"]["lldp.TransmitMgmtAddress"]) {
			    delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestNonTpmrPortConfiguration"]["children-Set"]["lldp.TransmitMgmtAddress"][index]["portCfgManAddress"];
		    }
        }
		return payload;
	}

	getPortAttributes(objectFullName, neId) {
		var className = "equipment.PhysicalPort";
		var searchObject = {
			"fullClassName": className,
			"filter": {
				"equal": {
					"name": "objectFullName",
					"value": objectFullName
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": ["iomType", "lagMembershipId", "isPrimaryLagMember", "administrativeState", "specificCardType", "cardSubType", "otuEnable", "dwdmChannel"]
			}
		};
		var resultFetch = NSP.nfmpPOST(neId, "/v3/search", searchObject);
		var finalResponse = JSON.parse(resultFetch.response);
		logger.info("finalResponse = {}", JSON.stringify(finalResponse));
		finalResponse = finalResponse[className];
		logger.info("finalResponse[{}] = {}", className, JSON.stringify(finalResponse));
		var result = {}
		var iomType = "";
		if (finalResponse !== undefined) {
			result["iomType"] = finalResponse["iomType"][0];
			result["lagMembershipId"] = finalResponse['lagMembershipId'];
			result["isPrimaryLagMember"] = finalResponse['isPrimaryLagMember'];
			result["administrativeState"] = finalResponse['administrativeState'];
			result["specificCardType"] = finalResponse['specificCardType'][0];
			result["cardSubType"] = finalResponse['cardSubType'];
			result["otuEnable"] = finalResponse['otuEnable'];
			result["dwdmChannel"] = finalResponse['dwdmChannel'];
		}
		logger.info("result = {}", JSON.stringify(result))
		return result;
	}

	transformTargetValueGreenField(xpath, targetValue, targetKey, neId, isAudit, objectFullName) {
        if(isAudit){
            if(xpath == "holdTimeUp" || xpath == "holdTimeDown" || xpath== "mtuValue" || xpath == "ddmEventSuppression" || xpath == "collectStats" || xpath == "dot3OamInterval" || xpath == "dwdmChannel" || xpath =="reportAlarmBits" || xpath == "enableDei"){
                targetValue = JSON.stringify(targetValue);
            }
            if(xpath == "lldpMedTLVsTxEnable"){
                    if(targetValue.length == 0){
                        targetValue =[];
                    }
            }
        }

		if (xpath == "portSchedulerPolicyObjectPointer" || xpath == "equipment-EgrSchVirtualPort.portSchedulerPolicyPointer") {
			targetValue = 'Port Scheduler:' + targetValue;
		}
        if(xpath == "macsec-MacsecInterface.portPointer") {
            targetValue = objectFullName;
        }
		if (xpath == "networkQueueObjectPointer") {
			targetValue = 'network:' + neId + ':Network Queue:' + targetValue;
			if (neId && String(neId).indexOf(':') !== -1) {
                targetValue = targetValue.replace(neId, neId.replaceAll(":","_"));
            }
		}
		if (xpath == "accountingPolicyObjectPointer" || xpath == "etherAccountingPolicyObjectPointer" || xpath == "ethAccessAccountingPolicyObjectPointer" || xpath == "ethernetequipment-AccessIngrQGroup.accountingPolicyPointer" || xpath == "ethernetequipment-AccessEgrQGroup.accountingPolicyPointer" || xpath == "ethernetequipment-NetworkEgrQGroup.accountingPolicyPointer") {
			targetValue = 'Accounting:' + targetValue;
		}
		if (xpath == "ethernetequipment-AccessEgrQGroup.queueGroupPolicyPointer" || xpath == "ethernetequipment-NetworkEgrQGroup.queueGroupPolicyPointer") {
			targetValue = 'egressQGroup:' + targetValue;
		}
		if (xpath == "ethernetequipment-AccessIngrQGroup.queueGroupPolicyPointer") {
			targetValue = 'ingressQGroup:' + targetValue;
		}
		if (xpath == "ethernetequipment-AccessEgrQGroup.schedulerPolicyPointer" || xpath == "ethernetequipment-AccessIngrQGroup.schedulerPolicyPointer" || xpath == "ethernetequipment-NetworkEgrQGroup.schedulerPolicyPointer" || xpath == "equipment-EgrSchVirtualPort.schedulerPolicyPointer") {
			targetValue = 'Scheduler:' + targetValue;
		}
		if (xpath == "hsPortPoolPointer") {
			targetValue = 'hsPortPoolPolicy:' + targetValue;
		}
		if (xpath == "ethernetequipment-NetworkEgrQGroup.policerControlPolicyPointer") {
			targetValue = 'hPolicing:' + targetValue;
		}
		if (xpath == "radiusServerPolicyAuthPointer" || xpath == "radiusServerPolicyAcctPointer") {
			targetValue = 'network:' + neId + ':radiusServerPolicy:' + targetValue;
			if (neId && String(neId).indexOf(':') !== -1) {
                targetValue = targetValue.replace(neId, neId.replaceAll(":","_"));
            }
		}
		if (xpath == "sasqos-QosPool.slopePolicyPointer") {
			targetValue = 'sasSlope:' + targetValue;
		}
		if (xpath == "monitorOperGroupPtr") {
			targetValue = 'network:' + neId + ':svcgr-' + targetValue;
			if (neId && String(neId).indexOf(':') !== -1) {
                targetValue = targetValue.replace(neId, neId.replaceAll(":","_"));
            }
		}
		if (xpath == "ethernetequipment-EthernetPortSpecifics.operGroupPointer" || xpath == "ethernetequipment-EthernetPortSpecifics.monitorOperGroupPointer") {
			targetValue = 'network:' + neId + ':sOprGrp-' + targetValue;
			if (neId && String(neId).indexOf(':') !== -1) {
                targetValue = targetValue.replace(neId, neId.replaceAll(":","_"));
            }
		}
        if (xpath == "accessuplink-AccessUplinkSpecifics.accessEgressPolicy") {
            targetValue = 'sasPortAccessEgress:' + targetValue;
        }
        if (xpath == "accessuplink-AccessUplinkSpecifics.sasPortAccessIngressPolicy") {
            targetValue = 'sasPortAccessIngressPolicy:' + targetValue;
        }
        if (xpath == "accessuplink-AccessUplinkSpecifics.networkPolicy") {
            targetValue = 'sasNetwork:' + targetValue;
        }
        if (xpath == "accessuplink-AccessUplinkSpecifics.networkQueueObjectPointer") {
            targetValue = 'sasNetworkQueue:' + targetValue;
        }
        if (xpath == "accessuplink-AccessUplinkSpecifics.portSchedulerPolicy") {
            targetValue = 'sasPortSchedulerPolicy:' + targetValue;
        }
         if(xpath == "ethernetequipment-PortAccessEgrQOverride.queueMgmtPolicyOverride"){
            targetValue = 'sasQueueMgmtPolicy:' + targetValue;
        }

        if(xpath == "accessuplink-AccessUplinkSpecifics.dscpClassificationPointer"){
            targetValue = 'sasDSCPClassification:Dscp-' + targetValue;
        }

        if ((xpath == "lldp-LLDPPortConfigExtn.lldpMedPolicy1") ||
            (xpath == "lldp-LLDPPortConfigExtn.lldpMedPolicy2") ||
            (xpath == "lldp-LLDPPortConfigExtn.lldpMedPolicy3") ||
            (xpath == "lldp-LLDPPortConfigExtn.lldpMedPolicy4")) {
            targetValue = 'lldpMedNetworkPolicy:' + targetValue;
        }
		if (xpath == "olsEgAmpGain" || xpath == "ethernetequipment-AccessIngrQGroup.ethernetequipment-AccessIngrQOverride.violationThreshold" || xpath == "ethernetequipment-NetworkEgrQGroup.ethernetequipment-NetworkEgrQOverride.violationThreshold" || xpath == "ethernetequipment-AccessEgrQGroup.ethernetequipment-AccessEgrQOverride.violationThreshold" || xpath == "cohOptPortCfgTxPower" || xpath == "cohOptPortCfgRxLosThresh") {
			if (targetValue && !isNaN(targetValue) && !targetValue.toString().includes(".")) {
				targetValue = Number(targetValue);
				targetValue = targetValue.toFixed(1);
			}
		}
		return targetValue;
	}

	transformTargetValueBrownField(xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {

        if(xpath == "ethernetequipment-EthernetPortSpecifics.reportAlarmBits" ) {
        }
        if(xpath == "macsec-MacsecInterface.portPointer") {
            targetValue = fullDeviceConfig["portName"];
        }

		if (xpath == "portSchedulerPolicyObjectPointer" || xpath == "equipment-EgrSchVirtualPort.portSchedulerPolicyPointer") {
			targetValue = targetValue.replace('Port Scheduler:', '');
		}
		if (xpath == "networkQueueObjectPointer") {
			targetValue = targetValue.split(':Network Queue:')[1];
		}
		if (xpath == "accountingPolicyObjectPointer" || xpath == "etherAccountingPolicyObjectPointer" || xpath == "ethAccessAccountingPolicyObjectPointer" || xpath == "ethernetequipment-AccessIngrQGroup.accountingPolicyPointer" || xpath == "ethernetequipment-AccessEgrQGroup.accountingPolicyPointer" || xpath == "ethernetequipment-NetworkEgrQGroup.accountingPolicyPointer") {
			targetValue = targetValue.replace('Accounting:', '');
		}
		if (xpath == "ethernetequipment-AccessEgrQGroup.queueGroupPolicyPointer" || xpath == "ethernetequipment-NetworkEgrQGroup.queueGroupPolicyPointer") {
			targetValue = targetValue.replace('egressQGroup:', '');
		}
		if (xpath == "ethernetequipment-AccessIngrQGroup.queueGroupPolicyPointer") {
			targetValue = targetValue.replace('ingressQGroup:', '');
		}
		if (xpath == "ethernetequipment-AccessEgrQGroup.schedulerPolicyPointer" || xpath == "ethernetequipment-AccessIngrQGroup.schedulerPolicyPointer" || xpath == "ethernetequipment-NetworkEgrQGroup.schedulerPolicyPointer" || xpath == "equipment-EgrSchVirtualPort.schedulerPolicyPointer") {
			targetValue = targetValue.replace('Scheduler:', '');
		}
		if (xpath == "hsPortPoolPointer") {
			targetValue = targetValue.replace('hsPortPoolPolicy:', '');
		}
		if (xpath == "ethernetequipment-NetworkEgrQGroup.policerControlPolicyPointer") {
			targetValue = targetValue.replace('hPolicing:', '');
		}
		if (xpath == "pae802_1x-PaePortAuthenticatorSpecifics.radiusServerPolicyAuthPointer" || xpath == "pae802_1x-PaePortAuthenticatorSpecifics.radiusServerPolicyAcctPointer") {
			targetValue = targetValue.split(':radiusServerPolicy:')[1];
		}
		if (xpath == "sasqos-QosPool.slopePolicyPointer") {
			const lastIndex = targetValue.lastIndexOf(':');
			if (lastIndex !== -1) {
				targetValue = targetValue.replace(targetValue.slice(0, lastIndex + 1), '');
			}
		}
		if (xpath == "monitorOperGroupPtr") {
			targetValue = targetValue.split(':svcgr-')[1];
		}
		if (xpath == "ethernetequipment-EthernetPortSpecifics.operGroupPointer" || xpath == "ethernetequipment-EthernetPortSpecifics.monitorOperGroupPointer") {
            targetValue = targetValue.split(':sOprGrp-')[1];
		}
        if (xpath == "accessuplink-AccessUplinkSpecifics.accessEgressPolicy") {
            targetValue = targetValue.replace('sasPortAccessEgress:', '');
        }
        if (xpath == "accessuplink-AccessUplinkSpecifics.sasPortAccessIngressPolicy") {
            targetValue = targetValue.replace('sasPortAccessIngressPolicy:', '');
        }
        if (xpath == "accessuplink-AccessUplinkSpecifics.networkPolicy") {
            targetValue = targetValue.replace('sasNetwork:', '');
        }
        if (xpath == "accessuplink-AccessUplinkSpecifics.networkQueueObjectPointer") {
            targetValue = targetValue.replace('sasNetworkQueue:', '');
        }
        if (xpath == "accessuplink-AccessUplinkSpecifics.portSchedulerPolicy") {
            targetValue = targetValue.replace('sasPortSchedulerPolicy:', '');
        }

          if(xpath == "ethernetequipment-PortAccessEgrQOverride.queueMgmtPolicyOverride"){
            targetValue = targetValue.replace('sasQueueMgmtPolicy:', '');
        }

         if(xpath == "accessuplink-AccessUplinkSpecifics.dscpClassificationPointer"){
            targetValue = targetValue.replace('sasDSCPClassification:Dscp-', '');
        }

        if ((xpath == "lldp-LLDPPortConfigExtn.lldpMedPolicy1") ||
            (xpath == "lldp-LLDPPortConfigExtn.lldpMedPolicy2") ||
            (xpath == "lldp-LLDPPortConfigExtn.lldpMedPolicy3") ||
            (xpath == "lldp-LLDPPortConfigExtn.lldpMedPolicy4")) {
            targetValue = targetValue.replace('lldpMedNetworkPolicy:', '');
        }
		if (xpath == "olsEgAmpGain" && targetValue == 2500.0) {
			targetValue = targetValue / 100;
		}
		return targetValue;
	}

	transformIntentConfig(intentConfig) {
		if (!(intentConfig["specificCardType"] == "mda_me16_25g_sfp28_plus_2_100g_qsfp28" || intentConfig["specificCardType"] == "mda_me12_10gb_1gb_sfp_plus" || intentConfig["specificCardType"] == "mda_me2_100gb_qsfp28_msec" || intentConfig["specificCardType"] == "mda_me8_10gb_25gb_sfp_plus_28" || intentConfig["specificCardType"] == "mda_maxp10_10_1_gb_msec_sfp_plus" || intentConfig["specificCardType"] == "mda_7210_k8sfp_4tx" || intentConfig["specificCardType"] == "mda_7210_k3sfp_8combo" || intentConfig["specificCardType"] == "mda_imm48_sfp_2_100g_qsfp28" || intentConfig["specificCardType"] == "mda_imm36_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m10_10g_sfp_plus" || intentConfig["specificCardType"] == "mda_m6_10g_sfp_plus_1_100g_qsfp28" || intentConfig["specificCardType"] == "mdas_ms16_100g_sfpdd_plus_4_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m14_10g_sfp_plus_plus_4_1g_tx" || intentConfig["specificCardType"] == "mda_m6_10g_sfp_plus_1_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m10_10g_sfp_plus" || intentConfig["specificCardType"] == "mdas_ms8_100gb_sfpdd_plus_2_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m6_10g_sfp_plus_4_25g_sfp28" || intentConfig["specificCardType"] == "mda_m18_25g_sfp28" || intentConfig["specificCardType"] == "mda_m2_cfp2_dco" || intentConfig["specificCardType"] == "mda_7210_m16tx_6sfp_2sfpp" || intentConfig["specificCardType"] == "mda_m1_400g_qsfpdd_plus_1_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m46_10g_sfp_plus" || intentConfig["specificCardType"] == "mda_m4_10g_sfp_plus_1_100g_cfp2" || intentConfig["specificCardType"] == "mda_m20_10g_sfp_plus" || intentConfig["specificCardType"] == "mda_m24_800g_qsfpdd_1")) {
			if (intentConfig["macsec-MacsecPort"]) {
				delete intentConfig["macsec-MacsecPort"];
			}
		}

		if (!(intentConfig["portClass"] == "faste" || intentConfig["portClass"] == "gige" || intentConfig["portClass"] == "xgige" || intentConfig["portClass"] == "variableEthernet" || intentConfig["portClass"] == "cgige" || intentConfig["portClass"] == "cdgige" || intentConfig["portClass"] == "xlgige" || intentConfig["portClass"] == "xlcgige" || intentConfig["portClass"] == "xxvgige" || intentConfig["portClass"] == "terabite" || intentConfig["portClass"] == "lgige")) {
			if (intentConfig["pae802_1x-PaePortSpecifics"]) {
				delete intentConfig["pae802_1x-PaePortSpecifics"];
			}
			if (intentConfig["pae802_1x-PaePortAuthenticatorSpecifics"]) {
				delete intentConfig["pae802_1x-PaePortAuthenticatorSpecifics"];
			}
		}

		if (!(( intentConfig["portClass"] == "xlcgige" || intentConfig["portClass"] == "xgige" || intentConfig["portClass"] == "variableEthernet" || intentConfig["specificCardType"] != "mda_a2_10gb_xfp" && intentConfig["specificCardType"] != "mda_a2_10gb_xfp" && intentConfig["portCategory"] == "ethernet") || intentConfig["portCategory"] == "dslPort" || (intentConfig["portCategory"] == "wdmPort" && intentConfig["portClass"] == "xgige"))) {
			if (intentConfig["ethernetequipment-Dot3Oam"]) {
				delete intentConfig["ethernetequipment-Dot3Oam"];
			}
		}
		if (!(intentConfig["portClass"] == "faste" || intentConfig["portClass"] == "gige" || intentConfig["portClass"] == "xgige" || intentConfig["portClass"] == "variableEthernet" || intentConfig["portClass"] == "cgige" || intentConfig["portClass"] == "cdgige" || intentConfig["portClass"] == "vsme" || intentConfig["portClass"] == "xlgige" || intentConfig["portClass"] == "xlcgige" || intentConfig["portClass"] == "2xgige" || intentConfig["portClass"] == "xxvgige" || intentConfig["portClass"] == "lgige" || intentConfig["portClass"] == "terabite" || intentConfig["portClass"] == "tsp" || intentConfig["portClass"] == "cpri3" || intentConfig["portClass"] == "cpri5" || intentConfig["portClass"] == "cpri6" || intentConfig["portClass"] == "cpri7" || intentConfig["portClass"] == "cpri8" || intentConfig["portClass"] == "cpri10" || intentConfig["portClass"] == "obsai4" || intentConfig["portClass"] == "obsai8" || ((intentConfig["specificCardType"] == "mda_a2_10gb_xfp" || intentConfig["specificCardType"] == "mda_p2_10gb_xfp") && intentConfig["portClass"] == "virtualPort"))) {

			if (intentConfig["ethernetequipment-EthernetPortSpecifics"]) {
				delete intentConfig["ethernetequipment-EthernetPortSpecifics"];
			}
		}
		if (!(intentConfig["portClass"] == "faste" || intentConfig["portClass"] == "gige" || intentConfig["portClass"] == "xgige" || intentConfig["portClass"] == "xxvgige" || intentConfig["portClass"] == "variableEthernet" || intentConfig["portClass"] == "cdgige" || intentConfig["portClass"] == "xlgige" || intentConfig["portClass"] == "xlcgige" || intentConfig["portClass"] == "terabite" || intentConfig["portClass"] == "lgige" || intentConfig["portClass"] == "tsp" || intentConfig["portClass"] == "cpri3" || intentConfig["portClass"] == "cpri5" || intentConfig["portClass"] == "cpri6" || intentConfig["portClass"] == "cpri7" || intentConfig["portClass"] == "cpri8" || intentConfig["portClass"] == "cpri10" || intentConfig["portClass"] == "obsai4" || intentConfig["portClass"] == "obsai8" || (intentConfig["portClass"] == "cgige" && intentConfig["cardSubType"] != "pss_aluWdm260scx2OTU4Card"))) {
			if (intentConfig["lldp-LLDPNearestNonTpmrPortConfiguration"]) {
				delete intentConfig["lldp-LLDPNearestNonTpmrPortConfiguration"];
			}
			if (intentConfig["lldp-LLDPNearestCustomerPortConfiguration"]) {
				delete intentConfig["lldp-LLDPNearestCustomerPortConfiguration"];
			}
		}
		if (!(intentConfig["portClass"] == "faste" || intentConfig["portClass"] == "gige" || intentConfig["portClass"] == "xgige" || intentConfig["portClass"] == "variableEthernet" || intentConfig["portClass"] == "cgige" || intentConfig["portClass"] == "cdgige" || intentConfig["portClass"] == "xlgige" || intentConfig["portClass"] == "xlcgige" || intentConfig["portClass"] == "xxvgige" || intentConfig["portClass"] == "terabite" || intentConfig["portClass"] == "lgige" || intentConfig["portClass"] == "tsp" || intentConfig["portClass"] == "cpri3" || intentConfig["portClass"] == "cpri5" || intentConfig["portClass"] == "cpri6" || intentConfig["portClass"] == "cpri7" || intentConfig["portClass"] == "cpri8" || intentConfig["portClass"] == "cpri10" || intentConfig["portClass"] == "obsai4" || intentConfig["portClass"] == "obsai8")) {
			if (intentConfig["lldp-LLDPNearestBridgePortConfiguration"]) {
				delete intentConfig["lldp-LLDPNearestBridgePortConfiguration"];
			}
		}
		if (!(intentConfig["specificCardType"] == "mda_m1_10gb_dwdm_tun" || intentConfig["specificCardType"] == "mda_imm1_oc768_tun" || intentConfig["specificCardType"] == "mda_imm1_40gb_xp_tun" || intentConfig["specificCardType"] == "mda_imm_p1_100g_tun" || intentConfig["specificCardType"] == "mda_imm_p1_100g_tun_b" || intentConfig["specificCardType"] == "mda_me10_10gb_sfp_plus" || intentConfig["specificCardType"] == "mda_me1_100gb_cfp2" || intentConfig["specificCardType"] == "mda_me6_10gb_sfp_plus" || intentConfig["cardSubType"] == "pss_aluWdm260scx2OTU4Card" || intentConfig["cardSubType"] == "pss_aluWdm130scx10Card" || intentConfig["specificCardType"] == "mda_x2_100g_tun" || intentConfig["specificCardType"] == "mda_me1_100gb_cfp2" || intentConfig["specificCardType"] == "mda_x4_100g_cfp2" || intentConfig["specificCardType"] == "mda_me3_200gb_cfp2_dco" || intentConfig["specificCardType"] == "mda_x6_200g_cfp2_dco" || intentConfig["specificCardType"] == "mdas_ms6_200gb_cfp2_dco" || intentConfig["specificCardType"] == "mdas_ms3_200gb_cfp2_dco" || intentConfig["specificCardType"] == "mda_maxp1_100gb_cfp2")) {
			if (intentConfig["ethernetequipment-OtuInterface"]) {
				delete intentConfig["ethernetequipment-OtuInterface"];
			}
		}
		if (!(intentConfig["specificCardType"] == "mda_m1_10gb_dwdm_tun" || intentConfig["specificCardType"] == "mda_imm1_oc768_tun" || intentConfig["specificCardType"] == "mda_imm12_10gb_sf" || intentConfig["specificCardType"] == "mda_imm_p6_10g_sfp" || intentConfig["specificCardType"] == "mda_imm_p10_10g_sfp" || intentConfig["specificCardType"] == "mda_cx20_10g_sfp" || intentConfig["specificCardType"] == "mda_x40_10g_sfp" || intentConfig["specificCardType"] == "mda_imm40_10gb_sfp" || intentConfig["specificCardType"] == "mda_imm1_40gb_xp_tun" || intentConfig["specificCardType"] == "mda_m2_10gb_xp_xfp_wt" || intentConfig["specificCardType"] == "mda_m4_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_ma4_10gb_sfp_plus" || intentConfig["specificCardType"] == "mda_maxp10_10gb_sfp_plus" || intentConfig["specificCardType"] == "mda_maxp10_10_1_gb_msec_sfp_plus" || intentConfig["specificCardType"] == "mda_maxp1_100gb_cfp" || intentConfig["specificCardType"] == "mda_maxp1_100gb_cfp2" || intentConfig["specificCardType"] == "mda_maxp1_100gb_cfp4" || intentConfig["specificCardType"] == "mda_m2_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_m1_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_m1_10gb_hs_xfp_b" || intentConfig["specificCardType"] == "mda_m1_10gb_xfp" || intentConfig["specificCardType"] == "mda_m2_10gb_xfp" || intentConfig["specificCardType"] == "mda_m10_1gb_plus_1_10gb" || intentConfig["specificCardType"] == "mda_imm4_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_imm5_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_imm2_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_icm2_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_m2_oc192_xp_xfp" || intentConfig["specificCardType"] == "mda_imm_p1_100g_tun" || intentConfig["specificCardType"] == "mda_imm_p1_100g_tun_b" || intentConfig["specificCardType"] == "mda_me10_10gb_sfp_plus" || intentConfig["specificCardType"] == "mda_me6_10gb_sfp_plus" || intentConfig["specificCardType"] == "mda_x2_100g_tun" || intentConfig["specificCardType"] == "mda_me1_100gb_cfp2" || intentConfig["specificCardType"] == "mda_x4_100g_cfp2" || intentConfig["specificCardType"] == "mda_me12_10gb_1gb_sfp_plus" || intentConfig["specificCardType"] == "mda_me8_10gb_25gb_sfp_plus_28" || intentConfig["specificCardType"] == "mda_maxp1_100gb_cfp2" || ((intentConfig["specificCardType"] == "mda_a2_10gb_xfp" || intentConfig["specificCardType"] == "mda_p2_10gb_xfp") && intentConfig["portCategory"] == "ethernet") || intentConfig["specificCardType"] == "mda_imm48_sfp_2_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m10_10g_sfp_plus" || intentConfig["specificCardType"] == "mda_m6_10g_sfp_plus_1_100g_cfp4" || intentConfig["specificCardType"] == "mda_m6_10g_sfp_plus_1_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m6_10g_sfp_plus_4_25g_sfp28" || intentConfig["specificCardType"] == "mda_m4_10g_sfp_plus_1_100g_cfp2" || intentConfig["specificCardType"] == "mda_m48_10g_sfp_plus_6_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m24_sfp_plus_8_sfp28_2_qsfp28" || intentConfig["specificCardType"] == "mda_m14_10g_sfp_plus_plus_4_1g_tx" || (intentConfig["specificCardType"] == "mda_esat" && intentConfig["portClass"] == "xlcgige") || (intentConfig["specificCardType"] == "mda_m4_1g_tx_plus_20_1g_sfp_plus_6_10g_sfp_plus" && intentConfig["portClass"] == "xlcgige") || intentConfig["specificCardType"] == "mda_cx2_100g_cfp" || intentConfig["specificCardType"] == "mda_imm_p1_100g_cfp" || intentConfig["specificCardType"] == "mda_m10_1g_sfp_plus_2_10g_sfp_plus" || (intentConfig["specificCardType"] == "mda_maxp6_10gb_sfp_1_40gb_qsfp" && intentConfig["portClass"] == "xgige") || intentConfig["specificCardType"] == "mda_x40_10g_sfp_ptp" || intentConfig["specificCardType"] == "mda_m4_10g_sfp_plus_1_100g_cfp2")) {
			if (intentConfig["ethernetequipment-PortDwdmConfig"]) {
				delete intentConfig["ethernetequipment-PortDwdmConfig"];
			}
		}
		if (!(intentConfig["specificCardType"] == "mda_imm_p1_100g_tun" || intentConfig["specificCardType"] == "mda_imm_p1_100g_tun_b" || intentConfig["cardSubType"] == "pss_aluWdm260scx2OTU4Card" || intentConfig["cardSubType"] == "pss_aluWdm130scx10Card" || intentConfig["specificCardType"] == "mda_x2_100g_tun" || intentConfig["specificCardType"] == "mda_me1_100gb_cfp2" || intentConfig["specificCardType"] == "mda_x4_100g_cfp2" || intentConfig["specificCardType"] == "mda_maxp1_100gb_cfp2" || intentConfig["specificCardType"] == "mda_cx2_100g_cfp" || intentConfig["specificCardType"] == "mda_imm_p1_100g_cfp" || intentConfig["specificCardType"] == "mda_m4_10g_sfp_plus_1_100g_cfp2" || intentConfig["specificCardType"] == "mda_maxp1_100gb_cfp")) {
			if (intentConfig["ethernetequipment-CoherentOpticalCfg"]) {
				delete intentConfig["ethernetequipment-CoherentOpticalCfg"];
			}
		}
		if (!(intentConfig["portClass"] == "sonet" || (intentConfig["specificCardType"] == "mda_m1_xgige" || intentConfig["specificCardType"] == "mda_m20_xgige_vsr" || intentConfig["specificCardType"] == "mda_m1_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_m2_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_m4_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_ma4_10gb_sfp_plus" || intentConfig["specificCardType"] == "mda_maxp10_10gb_sfp_plus" || intentConfig["specificCardType"] == "mda_maxp10_10_1_gb_msec_sfp_plus" || intentConfig["specificCardType"] == "mda_ma2_10gb_sfp_12_1gb_sfp" || intentConfig["specificCardType"] == "mda_imm5_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_imm4_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_imm2_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_m1_10gb_dwdm_tun" || intentConfig["specificCardType"] == "mda_icm2_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_imm1_100gb_cfp" || intentConfig["specificCardType"] == "mda_imm12_10gb_sf" || intentConfig["specificCardType"] == "mda_p10_1gb_p1_10gb_xmda_sfp_sar18" || intentConfig["specificCardType"] == "mda_cx20_10g_sfp" || intentConfig["specificCardType"] == "mda_x40_10g_sfp" || intentConfig["specificCardType"] == "mda_imm_p6_10g_sfp" || intentConfig["specificCardType"] == "mda_imm_p10_10g_sfp" || intentConfig["specificCardType"] == "mda_imm_p20_1gb_sfp" || intentConfig["specificCardType"] == "mda_m2_10gb_xp_xfp_wt" || intentConfig["specificCardType"] == "mda_m12_1gb_plus_2_10gb_xp" || intentConfig["specificCardType"] == "mda_imm40_10gb_sfp" || intentConfig["specificCardType"] == "mda_maxp6_10gb_sfp_1_40gb_qsfp" || intentConfig["specificCardType"] == "mda_me10_10gb_sfp_plus" || intentConfig["specificCardType"] == "mda_me6_10gb_sfp_plus" || intentConfig["specificCardType"] == "mda_me12_10gb_1gb_sfp_plus" || intentConfig["specificCardType"] == "mda_me8_10gb_25gb_sfp_plus_28" || intentConfig["specificCardType"] == "mdas_mse_24_200g_sfpdd" || intentConfig["specificCardType"] == "xma_x2_s18_800g_qsfpdd" || intentConfig["specificCardType"] == "mdas_mse6_400g_cfp2_dco" || intentConfig["specificCardType"] == "mdas_mse14_800g_plus_4_400g" || intentConfig["specificCardType"] == "mdas_mse6_800g_qsfpdd" || ((intentConfig["specificCardType"] == "mda_a2_10gb_xfp" || intentConfig["specificCardType"] == "mda_p2_10gb_xfp") && intentConfig["portClass"] != "virtualPort") || intentConfig["specificCardType"] == "mda_p10_1gb_p1_10gb_xmda_sfp_sar18_v2" || ((intentConfig["specificCardType"] == "mda_a6_eth_10g" || intentConfig["specificCardType"] == "mda_p4_eth" || intentConfig["specificCardType"] == "mda_i7_mix_eth" || intentConfig["specificCardType"] == "mda_a6_eth_10g_e") && intentConfig["portClass"] != "variableEthernet") || intentConfig["specificCardType"] == "mda_imm48_sfp_2_100g_qsfp28" || intentConfig["specificCardType"] == "mda_imm36_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m6_10g_sfp_plus_1_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m10_10g_sfp_plus" || intentConfig["specificCardType"] == "mda_m4_10g_sfp_plus_1_100g_cfp2" || intentConfig["specificCardType"] == "mda_m24_sfp_plus_8_sfp28_2_qsfp28" || intentConfig["specificCardType"] == "mda_m14_10g_sfp_plus_plus_4_1g_tx" || intentConfig["specificCardType"] == "mda_m12_sfp28_plus_2_qsfp28" || intentConfig["specificCardType"] == "mda_m2_qsfpdd_plus_2_qsfp28_plus_24_sfp28" || intentConfig["specificCardType"] == "mda_m48_10g_sfp_plus_6_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m32_qsfp28_plus_4_qsfpdd" || intentConfig["specificCardType"] == "mda_m6_qsfpdd_plus_48_sfp56" || intentConfig["specificCardType"] == "mda_m4_1g_tx_plus_20_1g_sfp_plus_6_10g_sfp_plus" || intentConfig["specificCardType"] == "mda_m18_25g_sfp28" || intentConfig["specificCardType"] == "mda_m1_400g_qsfpdd_plus_1_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m5_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m2_cfp2_dco" || intentConfig["specificCardType"] == "mda_m20_10g_sfp_plus" || intentConfig["specificCardType"] == "mda_m10_50g_sfp56" || intentConfig["specificCardType"] == "mda_m46_10g_sfp_plus" || intentConfig["specificCardType"] == "mda_m32_1g_csfp" || intentConfig["specificCardType"] == "mda_m80_1g_csfp"))) {
			if (!((intentConfig["specificCardType"] == "card_mpr_9500_p2stm" || intentConfig["specificCardType"] == "card_mpr_9500_p2stmchan") && (intentConfig["portUsage"] == "sfpe" || intentConfig["portUsage"] == "sfpo"))) {
				if (intentConfig["sonetequipment-SonetPortSpecifics"]) {
					delete intentConfig["sonetequipment-SonetPortSpecifics"];
				}
			}
			if (intentConfig["sonetequipment-SonetPortOverheadSpecifics"]) {
				delete intentConfig["sonetequipment-SonetPortOverheadSpecifics"];
			}
			if (intentConfig["sonetequipment-SonetPortMonitorSpecifics"]) {
				delete intentConfig["sonetequipment-SonetPortMonitorSpecifics"];
			}
		}
	}

reportMisaligned(target, result, auditReport) {
    const report = JSON.parse(result.response);
    if (!report.aligned) {
      report.misalignedAttributes.forEach(attributeData => {
        const name = attributeData.name;
        const expected = attributeData.expected;
        const actual = attributeData.actual;

        const isSpecialArray =
          name.includes("addressedCapability") ||
          name.includes("reportAlarmBits") ||
          name.includes("dot3PortConfigTLVsTxEnable") ||
          name.includes("portCfgTLVsTxEnable") ||
          name.includes("medPortConfigTLVsTxEnable") ||
          name.includes("aisMegLevel") ||
          name.includes("ccmTlvIgnore") ||
          name.includes("lmmFcCollectionInProfile") ||
          name.includes("soamPriorities") ||
          name.includes("lmmFcCollection") ||
          name.includes("cfgAlarms") ||
          name.includes("cohOptPortCfgAlarms");

        if (isSpecialArray && this.arraysAreEqual(expected, actual)) return;

        if (name.includes("slopePolicyPointer") && expected !== actual) {
          const expectedSuffix = expected?.substring(expected.lastIndexOf(":") + 1);
          const actualSuffix = actual?.substring(actual.lastIndexOf(":") + 1);
          if (expectedSuffix === "default" && actualSuffix === "default") return;
        }

        if (expected === "present") {
          auditReport.addMisAlignedObject(auditFactory.createMisAlignedObject(name, false));
        } else if (expected === "not present") {
          auditReport.addMisAlignedObject(auditFactory.createMisAlignedObject(name, true));
        } else {
          // Convert expected and actual to string representations for the Java method
          const expectedString = (typeof expected === 'object' && expected !== null)
                                 ? JSON.stringify(expected)
                                 : String(expected);
          const actualString = (typeof actual === 'object' && actual !== null)
                               ? JSON.stringify(actual)
                               : String(actual);

          auditReport.addMisAlignedAttribute(auditFactory.createMisAlignedAttribute(name, expectedString, actualString, target));
        }
      });
    }
    return auditReport;
};
	arraysAreEqual(arr1, arr2) {
		arr1 = Array.isArray(arr1) ? arr1 : [arr1];
		arr2 = Array.isArray(arr2) ? arr2 : [arr2];
		if (arr1.length !== arr2.length) return false;
		const sortedArr1 = arr1.slice().sort();
		const sortedArr2 = arr2.slice().sort();
		return sortedArr1.every((v, i) => v === sortedArr2[i]);
	};

	// WebUI suggest/picker callouts:
	suggestPolicyDefinitionName(context) {
		logger.info("suggestPolicyDefinitionName context = \n" + context);
		let className = "policy.PolicyDefinition",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}, {
						"name": "policyType",
						"value": "portScheduler"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestPortSchedulerOverridePortSchedulerName(context) {
		logger.info("suggestPortSchedulerOverridePortSchedulerName context = \n" + context);
		return [context.getInputValues()["arguments"]["__parent"]["equipment-PhysicalPort"]["portSchedulerPolicyObjectPointer"]];
	}

	suggestNetworkQueueObjectName(context) {
		logger.info("suggestNetworkQueueObjectName context = \n" + context);
		let className = "nqueue.Policy",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestUNIProfileName(context) {
		logger.info("suggestUNIProfileName context = \n" + context);
		let className = "ethernetservice.UniProfile",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"equal": {
					"name": "isBackup",
					"value": "false"
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestPortEgrHsmdaSchedulerPolicyName(context) {
		logger.info("suggestPortEgrHsmdaSchedulerPolicyName context = \n" + context);
		let className = "portscheduler.HsmdaSchedulerPolicy",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestL2ProfileName(context) {
		logger.info("suggestL2ProfileName context = \n" + context);
		let className = "layer2.L2Profile",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestHsSchedulerName(context) {
		logger.info("suggestHsSchedulerName context = \n" + context);
		let className = "hsqos.HsSchedulerPolicy",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestHsPortPoolName(context) {
		logger.info("suggestHsPortPoolName context = \n" + context);
		let className = "hsqos.HsPortPoolPolicy",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestPortRmdName(context) {
		logger.info("suggestPortRmdName context = \n" + context);
		let className = "rmd.AccessInterface",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"equal": {
					"name": "siteId",
					"value": neId
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestSapName(context) {
		logger.info("suggestSapName context = \n" + context);
		let className = "service.L2AccessInterface",
			neId = this.getNeId(context),
			attribute = "displayedName",
			snmpPortId = this.getSnmpPortId((context.getInputValues()["target"]["portId"]).replace("Port", ""));
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "nodeId",
						"value": neId
					}, {
						"name": "portId",
						"value": snmpPortId
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestVlanFilterName(context) {
		logger.info("suggestVlanFilterName context = \n" + context);
		let className = "aclfilter.FilterDefinition",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}, {
						"name": "filterType",
						"value": "filterType_vlan"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestShaperPolicyName(context) {
		logger.info("suggestShaperPolicyName context = \n" + context);
		let className = "shaperqos.ShaperPolicy",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestSystemOperGroupName(context) {
		logger.info("suggestSystemOperGroupName context = \n" + context);
		let className = "netw.SystemOperGroup",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"equal": {
					"name": "siteId",
					"value": neId
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestEgressQGroupPolicyName(context) {
		logger.info("suggestEgressQGroupPolicyName context = \n" + context);
		let className = "qgroup.EgressQGroupPolicy",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}, {
						"name": "policyType",
						"value": "egressQGroup"
					}],
					"notEqual": [{
						"name": "displayedName",
						"value": "_tmnx_nat_egr_q_grp"
					}, {
						"name": "displayedName",
						"value": "_tmnx_lns_esm_egr_q_grp"
					}, {
						"name": "displayedName",
						"value": "policer-output-queues"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestAccessEgrQueueGroupName(context) {
		logger.info("suggestAccessEgrQueueGroupName context = \n" + context);
		return [context.getInputValues()["arguments"]["__parent"]["queueGroupPolicyPointer"]];
	}

	suggestNetworkEgrQueueGroupName(context) {
		logger.info("suggestNetworkEgrQueueGroupName context = \n" + context);
		return [context.getInputValues()["arguments"]["__parent"]["queueGroupPolicyPointer"]];
	}

	suggestAccountingPolicyId(context) {
		logger.info("suggestAccountingPolicyId context = \n" + context);
		let className = "accounting.Policy",
			neId = this.getNeId(context),
			attribute = "id",
			mode = context.getInputValues()["arguments"]["equipment-PhysicalPort"]["mode"],
            isUplink = context.getInputValues()["arguments"]["equipment-PhysicalPort"]["isl2UplinkMode"];
        let searchObject;
        if(isUplink != false || mode == "network" || mode == "hybrid"){
            searchObject = {
			"fullClassName": className,
			"filter": {
				"and": [{
					"equal": [{
                        "name": "isLocal",
						"value": "false"
                    }],
					"or": {
						"equal": [{
							"name": "recordType",
							"value": "netEgressOctet"
						}, {
							"name": "recordType",
							"value": "netIngressOctet"
						}, {
							"name": "recordType",
							"value": "completeNetIngrEgr"
						}, {
							"name": "recordType",
							"value": "combinedNetInEgOctet"
						}, {
							"name": "recordType",
							"value": "netIngressPkt"
						}, {
							"name": "recordType",
							"value": "netEgressPkt"
						}]
					}
				}]
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		}
        };
		if (mode == "access" && isUplink != true) {
			searchObject = {
				"fullClassName": className,
				"filter": {
					"and": [{
						"equal": [{
                        "name": "isLocal",
						"value": "false"
                    }],
						"or": {
							"equal": [{
								"name": "recordType",
								"value": "accessEgressPkt"
							}, {
								"name": "recordType",
								"value": "accessEgressOctet"
							}, {
								"name": "recordType",
								"value": "accessIngressOct"
							}, {
								"name": "recordType",
								"value": "accessIngressPkt"
							}
                            ]
						}
					}]
				},
				"resultFilter": {
					"children": "",
					"attribute": [attribute]
				}
			};
		}
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestEthAccessAccountingPolicyId(context) {
		logger.info("suggestEthAccessAccountingPolicyId context = \n" + context);
		let className = "accounting.Policy",
			neId = this.getNeId(context),
			attribute = "id";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"or": {
					"and": {
						"equal": [{
							"name": "isLocal",
							"value": "false"
						}, {
							"name": "isBackup",
							"value": "false"
						}]
					},
					"and": {
						"equal": {
							"name": "siteId",
							"value": neId
						},
						"or": {
							"equal": [{
								"name": "recordType",
								"value": "accessEgressPkt"
							}, {
								"name": "recordType",
								"value": "accessEgressOctet"
							}, {
								"name": "recordType",
								"value": "combinedAccessEgress"
							}]
						}
					}
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestEtherAccountingPolicyId(context) {
		logger.info("suggestEtherAccountingPolicyId context = \n" + context);
		let className = "accounting.Policy",
			neId = this.getNeId(context),
			attribute = "id";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "siteId",
						"value": neId
					}, {
						"name": "recordType",
						"value": "completeEthernetPort"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestQGroupAccountingPolicyId(context) {
		logger.info("suggestQGroupAccountingPolicyId context = \n" + context);
		let className = "accounting.Policy",
			neId = this.getNeId(context),
			attribute = "id";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"or": {
					"and": {
						"equal": [{
							"name": "isLocal",
							"value": "false"
						}, {
							"name": "isBackup",
							"value": "false"
						}]
					},
					"and": {
						"equal": {
							"name": "siteId",
							"value": neId
						},
						"or": {
							"equal": [{
								"name": "recordType",
								"value": "queueGroupOctets"
							}, {
								"name": "recordType",
								"value": "queueGroupPackets"
							}, {
								"name": "recordType",
								"value": "combinedQueueGroup"
							}]
						}
					}
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

suggestQueueMgmtPolicy(context){
    logger.info("suggestQueueMgmtPolicy context = \n" + context);
		let className = "sasqos.QueueMgmtPolicy",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
}
	suggestSchedulerPolicyName(context) {
		logger.info("suggestSchedulerPolicyName context = \n" + context);
		let className = "vs.Policy",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestHsmdaEgressSecondaryShaperName(context) {
		logger.info("suggestHsmdaEgressSecondaryShaperName context = \n" + context);
		let className = "ethernetequipment.HsmdaEgressSecondaryShaper",
			neId = this.getNeId(context),
			attribute = "displayedName",
			target = context.getInputValues()["target"]["objectidentifier"],
			portId = context.getInputValues()["target"]["portId"],
			snmpPortId = getSnmpPortId(portId.replace("Port", "")),
			shelfId;
		var splittedTarget = target.split("/");
		for (let i = 4; i < splittedTarget.length; i++) {
			if (splittedTarget[i].indexOf("shelf=") != -1) {
				shelfId = splittedTarget[i].split("shelf=")[1];
			}
		}
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "siteId",
						"value": neId
					}, {
						"name": "shelfId",
						"value": shelfId
					}, {
						"name": "snmpPortId",
						"value": snmpPortId
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	getSnmpPortId(portId) {
		let portIds = portId.split("/"),
			cardSlot, xiomSlot, mdaSlot, connector, portNumber
		portIds.forEach(function(item, index) {
			switch (index) {
				case 0:
					cardSlot = item;
					break;
				case 1:
					//xiom
					if (isNaN(item)) {
						xiomSlot = item;
					} else {
						mdaSlot = item;
					}
					break;
				case 2:
					//connector
					if (isNaN(item)) {
						connector = item;
					} else if (mdaSlot) {
						portNumber = item;
					} else {
						mdaSlot = item;
					}
					break;
				case 3:
					//connector
					if (isNaN(item)) {
						connector = item;
					} else {
						portNumber = item;
					}
					break;
				case 4:
					portNumber = item;
					break;
			}
		});
		var snmpPortId = cardSlot << 25;
		snmpPortId |= (mdaSlot << 21);
		snmpPortId |= (portNumber << 15);
		return snmpPortId;
	}

	suggestHsmdaWrrPolicyName(context) {
		logger.info("suggestHsmdaWrrPolicyName context = \n" + context);
		let className = "portscheduler.HsmdaWrrPolicy",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}, {
						"name": "policyType",
						"value": "HsmdaWrrPolicy"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestEgressQueueId(context) {
		logger.info("suggestEgressQueueId context = \n" + context);
		let className = "qgroup.EgressQueue",
			neId = this.getNeId(context),
			attribute = "id",
			queueGroupPolicyName = context.getInputValues()["arguments"]["__parent"]["queueGroupPolicyPointer"];
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "containingPolicyDisplayedName",
						"value": queueGroupPolicyName
					}, {
						"name": "siteId",
						"value": neId
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		var ret = this.getData(neId, searchObject, className, attribute);
		var accessEgrQOverrides = context.getInputValues()["arguments"]["__parent"]["ethernetequipment-AccessEgrQOverride"];
		for (var index in accessEgrQOverrides) {
			ret = ret.filter(el => el !== accessEgrQOverrides[index]["queueId"]);
		}
		return ret
	}

	suggestNetworkEgrQueueId(context) {
		logger.info("suggestNetworkEgrQueueId context = \n" + context);
		let className = "qgroup.EgressQueue",
			neId = this.getNeId(context),
			attribute = "id",
			queueGroupPolicyName = context.getInputValues()["arguments"]["__parent"]["queueGroupPolicyPointer"];
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "containingPolicyDisplayedName",
						"value": queueGroupPolicyName
					}, {
						"name": "siteId",
						"value": neId
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		var ret = this.getData(neId, searchObject, className, attribute);
		var networkEgrOverrides = context.getInputValues()["arguments"]["__parent"]["ethernetequipment-NetworkEgrQOverride"];
		for (var index in networkEgrOverrides) {
			ret = ret.filter(el => el !== networkEgrOverrides[index]["queueId"]);
		}
		return ret
	}

	suggestschedulerName(context) {
		logger.info("suggestschedulerName context = \n" + context);
		let className = "vs.Entry",
			neId = this.getNeId(context),
			attribute = "displayedName",
			schedulerPolicyName = context.getInputValues()["arguments"]["__parent"]["schedulerPolicyPointer"];
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "true"
					}, {
						"name": "isBackup",
						"value": "false"
					}, {
						"name": "containingPolicyDisplayedName",
						"value": schedulerPolicyName
					}, {
						"name": "siteId",
						"value": neId
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestIngressQGroupPolicyName(context) {
		logger.info("suggestIngressQGroupPolicyName context = \n" + context);
		let className = "qgroup.IngressQGroupPolicy",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}, {
						"name": "policyType",
						"value": "ingressQGroup"
					}],
					"notEqual": [{
						"name": "displayedName",
						"value": "_tmnx_nat_ing_q_grp"
					}, {
						"name": "displayedName",
						"value": "_tmnx_lns_esm_ing_q_grp"
					}, {
						"name": "displayedName",
						"value": "_tmnx_nat_ing_q_grp_v2"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestAccessIngrQGroupPolicyName(context) {
		logger.info("suggestAccessIngrQGroupPolicyName context = \n" + context);
		return [context.getInputValues()["arguments"]["__parent"]["queueGroupPolicyPointer"]];
	}

	suggestIngressQueueId(context) {
		logger.info("suggestIngressQueueId context = \n" + context);
		let className = "qgroup.IngressQueue",
			neId = this.getNeId(context),
			attribute = "id",
			queueGroupPolicyName = context.getInputValues()["arguments"]["__parent"]["queueGroupPolicyPointer"];
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "containingPolicyDisplayedName",
						"value": queueGroupPolicyName
					}, {
						"name": "siteId",
						"value": neId
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		var ret = this.getData(neId, searchObject, className, attribute);
		var accessIngrQOverrides = context.getInputValues()["arguments"]["__parent"]["ethernetequipment-AccessIngrQOverride"];
		for (var index in accessIngrQOverrides) {
			ret = ret.filter(el => el !== accessIngrQOverrides[index]["queueId"]);
		}
		return ret
	}

	suggestPolicerControlPolicyName(context) {
		logger.info("suggestPolicerControlPolicyName context = \n" + context);
		let className = "policing.PolicerControl",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestRadiusServerPolicyName(context) {
		logger.info("suggestRadiusServerPolicyName context = \n" + context);
		let className = "aaa.RadiusServerPolicy",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestPortName(context) {
		logger.info("suggestPortName context = \n" + context);
		let className = "equipment.PhysicalPort",
			neId = this.getNeId(context),
			attribute = "portName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"equal": {
					"name": "siteId",
					"value": neId
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestMacPolicyId(context) {
		logger.info("suggestMacPolicyId context = \n" + context);
		let className = "MacPolicy",
			neId = this.getNeId(context),
			attribute = "id";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestCaName(context) {
		logger.info("suggestCaName context = \n" + context);
		let className = "macsec.CASite",
			neId = this.getNeId(context),
			attribute = "caName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"equal": {
					"name": "siteId",
					"value": neId
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestPortSchedulerPolicyName(context) {
		logger.info("suggestPortSchedulerPolicyName context = \n" + context);
		let className = "portscheduler.Policy",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestHwAggShaperSchedulerPolicyName(context) {
		logger.info("suggestHwAggShaperSchedulerPolicyName context = \n" + context);
		let className = "hwaggshapersched.HwAggShaperSchedulerPolicy",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "false"
					}, {
						"name": "isBackup",
						"value": "false"
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestSlopePolicyName(context) {
		logger.info("suggestSlopePolicyName context = \n" + context);
		let className = "sasqos.SlopePolicy",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "isLocal",
						"value": "true"
					}, {
						"name": "siteId",
						"value": neId
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestMonitorOperGroupName(context) {
		logger.info("suggestMonitorOperGroupName context = \n" + context);
		let className = "service.OperGroup",
			neId = this.getNeId(context),
			attribute = "groupName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"equal": {
					"name": "siteId",
					"value": neId
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestPortShgPointer(context) {
		logger.info("suggestPortShgPointer context = \n" + context);
		let className = "shg.Port",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"equal": {
					"name": "siteId",
					"value": neId
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestAccessEgressPolicy(context) {
		logger.info("suggestAccessEgressPolicy context = \n" + context);
		let className = "sasqos.PortAccessEgress",
			neId = this.getNeId(context),
			attribute = "id";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"equal": {
					"name": "isLocal",
					"value": "false"
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}
	suggestSasPortAccessIngressPolicy(context) {
		logger.info("suggestSasPortAccessIngressPolicy context = \n" + context);
		let className = "sasqos.PortAccessIngress",
			neId = this.getNeId(context),
			attribute = "id";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"equal": {
					"name": "siteId",
					"value": neId
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestNetworkQueueObjectPointer(context) {
		logger.info("suggestNetworkQueueObjectPointer context = \n" + context);
		let className = "sasqos.NQueue",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"equal": {
					"name": "siteId",
					"value": neId
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestNetworkPolicy(context) {
		logger.info("suggestNetworkPolicy context = \n" + context);
		let className = "sasqos.Network",
			neId = this.getNeId(context),
			attribute = "id";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"equal": {
					"name": "siteId",
					"value": neId
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestPortSchedulerPolicy(context) {
		logger.info("suggestPortSchedulerPolicy context = \n" + context);
		let className = "sasqos.PortScheduler",
			neId = this.getNeId(context),
			attribute = "displayedName";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"equal": {
					"name": "siteId",
					"value": neId
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestDwdmChannel(context) {
		logger.info("suggestDwdmChannel context = \n" + context);
		const ret = new HashMap();
		let dwdmChannels = ["0","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49","50","51","52","53","54","55","56","57","58","59","60","61","175","185","195","205","215","225","235","245","255","265","275","285","295","305","315","325","335","345","355","365","375","385","395","405","415","425","435","445","455","465","475","485","495","505","515","525","535","545","555","565","575","585","595","605"];
		dwdmChannels.forEach((value, index) => {
          ret.set(index, value);
        });
		logger.info("result = {}", JSON.stringify([...ret]));
		return ret;
	}

	suggestLldpMedPolicy(context) {
		logger.info("suggestLldpMedPolicy context = \n" + context);
		let className = "lldp.LLDPMedNetworkPolicy",
			neId = this.getNeId(context),
			attribute = "id";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"equal": {
					"name": "siteId",
					"value": neId
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}
	suggestPortAccessEgrQOverrideQueueId(context) {
		logger.info("suggestPortAccessEgrQOverrideQueueId context = \n" + context);
		let className = "sasqos.PortAccessEgressQueue",
			neId = this.getNeId(context),
			attribute = "id",
            accessEgressPolicyId = context.getInputValues()["arguments"]["__parent"]["equipment-PhysicalPort"]["accessuplink-AccessUplinkSpecifics"]["accessEgressPolicy"];
		let searchObject ={
			"fullClassName": className,
			"filter": {
				"and": {
					"equal": [{
						"name": "containingPolicyId",
						"value": accessEgressPolicyId
					}, {
						"name": "siteId",
						"value": neId
					}]
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}

	suggestDSCPClassificationPolicy(context) {
		logger.info("suggestPortAccessEgrQOverrideQueueId context = \n" + context);
		let className = "sasqos.DSCPClassification",
			neId = this.getNeId(context),
			attribute = "id";
		let searchObject = {
			"fullClassName": className,
			"filter": {
				"equal": {
					"name": "siteId",
					"value": neId
				}
			},
			"resultFilter": {
				"children": "",
				"attribute": [attribute]
			}
		};
		return this.getData(neId, searchObject, className, attribute);
	}
}
new IntentHandler();
