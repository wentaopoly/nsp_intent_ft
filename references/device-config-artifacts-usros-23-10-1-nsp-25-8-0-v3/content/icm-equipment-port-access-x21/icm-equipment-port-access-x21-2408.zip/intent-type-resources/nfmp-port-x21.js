var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpPort() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    let nfmpFwk = new NfmpFwk();
    var savedObjects;
    var currentObjects;
    var isAudit = false;

    this.synchronize = function(input, result,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {
        // setting up topology
        var savedTopology = input.getCurrentTopology();
        logger.info("Saved Topology = "+savedTopology);
        savedObjects = {};
        currentObjects = {};
        //loading the saved objects from topology
        this.loadSavedObjectsFromTopology(savedTopology);
        var parseTarget = new ParseTarget();
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        logger.info("Target device = " + target);
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());
        logger.info("Target port = " + intentConfig[uniqueIdentifier]);
        intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        logger.info("Configuration to be pushed = "+JSON.stringify(intentConfig));

        if (input.getNetworkState().name() == "delete"){
            return this.syncDelete(target,intentConfig[uniqueIdentifier],result);
        }

        this.createOrModify(target,intentConfig[uniqueIdentifier],intentConfig);
        var currentTopo = this.loadCurrentObjectsToTopology(target);

        return util.setSuccessResult(result,currentTopo);
    }

    this.audit = function(target, config, svcTopo, adminState, auditReport,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {
        var savedTopology = svcTopo;
        currentObjects = {};
        var parseTarget = new ParseTarget();
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        var target = parseTarget.getNeIdFromTarget(target);
        logger.info("Target device = " + target);
        logger.info("Target port = " + intentConfig[uniqueIdentifier]);
        intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        logger.info("auditing configuration = "+JSON.stringify(intentConfig));
        isAudit = true;

        if(intentConfig){
            this.auditAndCompare(target,intentConfig[uniqueIdentifier],intentConfig,auditReport);
        }else{
            throw "configuration not available in the intent";
        }

        return auditReport;
    }

    this.createOrModify = function(target,portId,intentConfig){

        // port level attributes
        var result = this.portLevel(target,portId,intentConfig);

        // removing the delete objects
        this.deleteRemovedObjects(target);

        return result;
    }

    this.auditAndCompare = function(target,portId,intentConfig,auditReport){

        // port level attributes
        var portLevelPayload = this.portLevel(target,portId,intentConfig);
        var result = this.auditRequest(target, portLevelPayload);
        auditReport = util.reportMisaligned(target, result,auditReport);

        return auditReport;
    }

    this.portLevel = function(target,portId,intentConfig){

        var fullClassName = "equipment.PhysicalPort";                    // full class name for port
        var portLevelFdn = util.getBaseFdnForPort(target,portId);        // portlevel attributes fdn
        var objectFullName = portLevelFdn;                               // objectFullName is same as fdn for port level
        var properties = {};

        (intentConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";
        if (intentConfig["description"]){
            properties["description"] = intentConfig["description"];
        }

        if(!isAudit){
            var portLevelPayload = util.editPayload(portLevelFdn,properties,null,fullClassName,objectFullName);
            var result = this.modifyRequest(target, portLevelPayload);
            this.createSerialPortSpecifics(target,intentConfig,portLevelFdn);
            //creating Serial Channel
            if(intentConfig["serialChannel"]){
                this.createSerialChannel(target,intentConfig,portLevelFdn);
            }
        }else{
            var childProperties = [];
            //child: Serial Channel
            if(intentConfig["serialChannel"]){
                var serialChannelPayload = this.createSerialChannel(target,intentConfig,portLevelFdn);
                childProperties.push(serialChannelPayload);
            }
            var portLevelPayload = util.editPayload(portLevelFdn,properties,childProperties,fullClassName,objectFullName);
            return portLevelPayload;
        }
    }

    this.createSerialPortSpecifics = function(target,intentConfig,portLevelFdn){
        var fullClassName = "tdmequipment.SerialPortSpecifics";
        var serialPortSpecificsFdn = portLevelFdn+":serialPort";
        var objectFullName = serialPortSpecificsFdn;
        var properties = {};

        properties["serialType"] = "x21";

        if(!isAudit){
            var serialPortSpecificsPayload = util.editPayload(portLevelFdn,properties,null,fullClassName,objectFullName);
            var result = this.modifyRequest(target, serialPortSpecificsPayload);
        }else{
            return this.createChildObjectPayload(fullClassName,null,properties);
        }
    }

    this.createSerialChannel = function(target,intentConfig,portLevelFdn){
        var fullClassName = "tdmequipment.SerialChannel";
        var serialChannelConfig = intentConfig["serialChannel"];
        var serialChannelFdn = portLevelFdn+":serial-1";
        var objectFullName = serialChannelFdn;
        var properties = {};

        (serialChannelConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";
        if (!isAudit){
            properties["portChannelType"] = "x21";
            properties["displayedLocalChannelId"] = "1";
        }

        if(!isAudit){
            var serialChannelPayload = util.editPayload(portLevelFdn,properties,null,fullClassName,objectFullName);
            var result = this.modifyRequest(target, serialChannelPayload);
            this.createSerialChannelSpecifics(target,intentConfig,serialChannelFdn);
            if(intentConfig["serialChannel"]["ds0Channel-group"]){
                this.createDS0ChannelGroup(target,intentConfig,serialChannelFdn);
            }
        }else{
            var childProperties = [];
            //child-1 : DataChannelSpecifics
            var serialChannelSpecificsPayload = this.createSerialChannelSpecifics(target,intentConfig,serialChannelFdn);
            childProperties.push(serialChannelSpecificsPayload);

            //child-2 : DS0ChannelGroup
            if(intentConfig["serialChannel"]["ds0Channel-group"]){
                var ds0ChannelGroupPayload = this.createDS0ChannelGroup(target,intentConfig,serialChannelFdn);
                childProperties.push(ds0ChannelGroupPayload);
            }

            return this.createChildObjectPayload(fullClassName,childProperties,properties);
        }
    }

    this.createSerialChannelSpecifics = function(target,intentConfig,serialChannelFdn){
        var fullClassName = "tdmequipment.SerialChannelSpecifics";
        var serialChannelSpecificsConfig = intentConfig["serialChannel"];
        var serialChannelSpecificsFdn = serialChannelFdn+":serialSpecs";
        var objectFullName = serialChannelSpecificsFdn;
        var properties = {};

        //Checking Data Channel Specifics exits, it take some time for data Channel To get created & come up.
        if(!isAudit && !util.isObjectExists(target,fullClassName,objectFullName)){
            logger.info("Adding 5 sec delay for Serial Channel Specifics to get created.");
            util.delay(5000);
            if(!util.isObjectExists(target,fullClassName,objectFullName)){
                throw new RuntimeException("Serial Channel Specifics: "+objectFullName+" still does not exist.Try Synchronize after some time.");
            }
        }

        if(serialChannelSpecificsConfig["speed"])
        {
            properties["speed"] = serialChannelSpecificsConfig["speed"];
        }

        if(!isAudit){
            var serialChannelSpecificsPayload = util.editPayload(serialChannelFdn,properties,null,fullClassName,objectFullName);
            var result = this.modifyRequest(target, serialChannelSpecificsPayload);
        }else{
            return this.createChildObjectPayload(fullClassName,null,properties);
        }
    }

    this.createDS0ChannelGroup = function(target,intentConfig,serialChannelFdn){
        var fullClassName = "tdmequipment.DS0ChannelGroup";
        var ds0ChannelGroupConfig = intentConfig["serialChannel"]["ds0Channel-group"];
        var ds0ChannelGroupFdn = serialChannelFdn+":ds0Grp-1";
        var objectFullName = ds0ChannelGroupFdn;
        var properties = {};


        if(ds0ChannelGroupConfig["channel-group-id"] = "1"){
            properties["displayedLocalChannelId"] = "1";
        }
        if(!isAudit){
            properties["portChannelType"] = "pdhDs0Grp";
            properties["mode"] = "access";
        }
        properties["encapType"] = util.convertToNfmpEncapType(ds0ChannelGroupConfig["encapType"]);
        (ds0ChannelGroupConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";
        if(!isAudit){
            //keeping key and value same as object full name of the DS0ChannelGroup
            mapFwk.set(currentObjects,objectFullName,objectFullName);
            var ds0ChannelGroupPayload = util.editPayload(serialChannelFdn,properties,null,fullClassName,objectFullName);
            var result = this.modifyRequest(target, ds0ChannelGroupPayload);
        }else{
            return this.createChildObjectPayload(fullClassName,null,properties);
        }
    }

    this.createChildObjectPayload = function(fullClassName,childProperties,properties){

        var childObjectPayLoad = {};

        childObjectPayLoad['objectClassName'] = fullClassName;
        childObjectPayLoad['containedClassProperties'] = properties;
        if (!util.isEmpty(childProperties)){
            childObjectPayLoad['containmentInfo'] = childProperties;
        }

        return childObjectPayLoad;
    }

    this.auditRequest = function(target,payload){
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }

        return result;
    }

    this.modifyRequest = function(target,payload){
        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }

        return result;
    }

    this.syncDelete = function (target,portId,result) {

        var portLevelFdn = util.getBaseFdnForPort(target,portId);
        var objectFullName = portLevelFdn+":serial-1";
        logger.info("Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success) {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }

        result.setSuccess(true);
    }

    this.xml2object = function(xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('Input JSON: '+ json)
        return JSON.parse(json);
    }

    this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }
            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }
            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }

    this.loadCurrentObjectsToTopology = function(target) {
        var currentTopo = topologyFactory.createServiceTopology();
        if(Object.keys(currentObjects).length){
            for(var key in currentObjects){
                objectId = mapFwk.get(currentObjects,key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key,objectId,"INFRASTRUCTURE",target,""));
            }
        }
        return currentTopo;
    }

    this.loadSavedObjectsFromTopology = function(savedTopology) {
        if(savedTopology){
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0){
                topoObjects.forEach(function(topoObject){
                    mapFwk.set(savedObjects,topoObject.getObjectType(),topoObject.getObjectRelativeObjectID());
                });
            }
        }
    }

    this.deleteRemovedObjects = function(target) {
        if(Object.keys(savedObjects).length > 0){
            for(var key in savedObjects){
                var value = mapFwk.get(currentObjects,key);
                if(value == undefined || value =="undefined" || value == null) {
                    logger.info("To be Deleted " + key);
                    var objectFullName = key;
                    if (target && String(target).indexOf(':') !== -1) {
                       objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
                    }
                    var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

                    if (!deleteResult.success) {
                        throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
                    }
                }
            }
        }
    };
}
