load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});

function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        let objFullName = objectFullName;
        if (intentConfig["prefixListType"] == 'ipv4')
        {
            objFullName = objFullName.replace("type-ipv4", "type-IPv4");
        }
        else if (intentConfig["prefixListType"] == 'ipv6')
        {
            objFullName = objFullName.replace("type-ipv6", "type-IPv6");
        }
        return objFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        let objFullName = objectFullName;
        if (intentConfig["prefixListType"] == 'ipv4')
        {
            objFullName = objFullName.replace("type-ipv4", "type-IPv4");
        }
        else if (intentConfig["prefixListType"] == 'ipv6')
        {
            objFullName = objFullName.replace("type-ipv6", "type-IPv6");
        }
        return objFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        let type = uniqueIdentifierValues[1];
        if (type == "ipv4")
        {
            objectFullName = objectFullName.replace("type-ipv4", "type-IPv4");
        }
        else if (type == "ipv6")
        {
            objectFullName = objectFullName.replace("type-ipv6", "type-IPv6");
        }
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        var ipv6AddressUtil = new IPv6AddressUtil();
        payload = ipv6AddressUtil.expandIPv6(payload);
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey) {
        return targetValue;
    }
}