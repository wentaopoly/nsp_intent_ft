function ModelDeviceMapping() {

    this.getMapping = function(type){
        switch (type) {
            case "ingress.fc":
                return this.getNetQosIngressFcMapping();
            case "ingress.dot1p":
                return this.getNetQosIngressDot1pMapping();
            case "ingress.dscp":
                return this.getNetQosIngressDscpMapping();
            case "ingress.lsp-exp":
                return this.getNetQosIngressLspExpMapping();
            case "ingress.meter":
                return this.getNetQosIngressMeterMapping();
            case "ingress.queue":
                return this.getNetQosIngressQueueMapping();
            case "egress.fc":
                return this.getNetQosEgressFcMapping();
        }
    }

    this.getNetQosIngressMapping = function () {
        var mapping = {};
        mapping["ingress.default-action.fc"] = "defaultFc";
        mapping["ingress.default-action.profile"] = "defaultProfile";
        mapping["ingress.mpls-lsp-exp-profile-map"] = "mplsLspExpMapPointer";
        mapping["ingress.classification-type.dscp-classification"] = "dscpClassificationPointer";
        mapping["ingress.classification-type.dot1p-classification"] = "dot1pClassificationPointer";
        mapping["ingress.classification-type.mpls-lsp-exp-classification"] = "mplsLspExpClassificationPointer";
        return mapping;
    }

    this.getNetQosEgressMapping = function () {
        var mapping = {};
        mapping["egress.remarking"] = "egressRemark";
        mapping["egress.remark"] = "remarkPolicyPointer";
        mapping["egress.remarking-type"] = "egressRemarkType";
        return mapping;
    }

    this.getNetQosIngressFcMapping = function () {
        var mapping = {};
        mapping["fc.fc-name"] = "forwardingClass";
        mapping["fc.multicast-meter"] = "mCastMeter";
        mapping["fc.use-dei"] = "useDei";
        mapping["fc.meter"] = "meter";
        mapping["fc.multicast-queue"] = "multicastQueueId";
        mapping["fc.queue"] = "queueId";
        return mapping;
    }

    this.getNetQosIngressDot1pMapping = function () {
        var mapping = {};
        mapping["dot1p.dot1p-value"] = "dot1p";
        mapping["dot1p.profile"] = "profile";
        mapping["dot1p.fc"] = "forwardingClass";
        return mapping;
    }

    this.getNetQosIngressDscpMapping = function () {
        var mapping = {};
        mapping["dscp.dscp-name"] = "dscp";
        mapping["dscp.fc"] = "forwardingClass";
        mapping["dscp.profile"] = "profile";
        return mapping;
    }
    
    this.getNetQosIngressLspExpMapping = function () {
        var mapping = {};
        mapping["lsp-exp.lsp-exp-value"] = "lspExp";
        mapping["lsp-exp.fc"] = "forwardingClass";
        mapping["lsp-exp.profile"] = "profile";
        return mapping;
    }

    this.getNetQosIngressMeterMapping = function () {
        var mapping = {};
        mapping["meter.meter-id"] = "id";
        mapping["meter.multipoint"] = "mCast";
        mapping["meter.mode"] = "mode";
        mapping["meter.cbs-type"] = "cbsType";
        mapping["meter.mbs-type"] = "mbsType";
        mapping["meter.adaptation-rule.pir"] = "pirAdaptation";
        mapping["meter.adaptation-rule.cir"] = "cirAdaptation";
        mapping["meter.rate.pir"] = "pir";
        mapping["meter.rate.cir"] = "cir";
        return mapping;
    }

    this.getNetQosIngressQueueMapping = function () {
        var mapping = {};
        mapping["queue.queue-id"] = "id";
        mapping["queue.cbs"] = "committedBurstSize";
        mapping["queue.mbs"] = "maximumBurstSize";
        mapping["queue.weight"] = "weight";
        mapping["queue.slope-policy"] = "slopePolicyPointer";
        mapping["queue.priority"] = "priority";
        mapping["queue.rate.pir"] = "pir";
        mapping["queue.rate.cir"] = "cir";
        mapping["queue.adaptation-rule.pir"] = "pirAdaptation";
        mapping["queue.adaptation-rule.cir"] = "cirAdaptation";
        return mapping;
    }

    this.getNetQosEgressFcMapping = function () {
        var mapping = {};
        mapping["fc.fc-name"] = "forwardingClass";
        mapping["fc.dot1p-in-profile"] = "dot1pInProfile";
        mapping["fc.dot1p-out-profile"] = "dot1pOutProfile";
        mapping["fc.dscp-in-profile"] = "dscpInProfile";
        mapping["fc.dscp-out-profile"] = "dscpOutProfile";
        mapping["fc.lsp-exp-in-profile"] = "lspExpInProfile";
        mapping["fc.lsp-exp-out-profile"] = "lspExpOutProfile";
        mapping["fc.de-mark"] = "deMark";
        mapping["fc.de-mark.force"] = "forceDeValue";
        mapping["fc.dot1p"] = "dot1pProfile";
        return mapping;
    }
}
