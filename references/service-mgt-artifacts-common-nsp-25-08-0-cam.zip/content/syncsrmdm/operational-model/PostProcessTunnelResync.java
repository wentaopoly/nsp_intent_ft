package com.nokia.nsp.mdt.intents.ibsf.resync.mdc;

import com.nokia.nsp.md.common.IExecutionContext;
import com.nokia.nsp.md.common.IYangObject;
import com.nokia.nsp.md.common.YangObject;
import com.nokia.nsp.md.db.yang.api.ExecutionContext;
import com.nokia.nsp.md.db.yang.api.QueryParameters;
import com.nokia.nsp.md.ifg.yang.api.Field;
import com.nokia.nsp.md.ifg.yang.api.Fields;
import com.nokia.nsp.md.resync.api.IMdResyncFw;
import com.nokia.nsp.md.resync.api.IResyncClassHandler;
import com.nokia.nsp.md.resync.api.NotificationType;
import com.nokia.nspos.persistence.impl.db.transaction.Transactor;
import com.nokia.nspos.persistence.impl.db.transaction.TxPhase;
import com.nokia.nspos.persistence.yang.api.IYangDB;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PostProcessTunnelResync implements IResyncClassHandler {
    private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(PostProcessTunnelResync.class.getName() + ".postProcessObject");
    IMdResyncFw iMdResyncFw;
    IYangDB yangDB;
    static ThreadLocal<Map<String, List<String>>> neNameDestCache = new ThreadLocal<>();

    @Override
    public void postProcessObject(Map<String, Object> aInData, IYangObject aInIYangObject,
                                  String aInNeId, NotificationType aInNotificationType, IMdResyncFw aInMdResyncFw) {
        if (aInNotificationType.equals(NotificationType.DELETE)) {
            return;
        }

        YangObject lNewYang = new YangObject();
        iMdResyncFw = aInMdResyncFw;
        yangDB = iMdResyncFw.getIYangDB();

        if (aInNotificationType == NotificationType.CREATE) {
            //If tunnel created through datasync default name
            String brownfieldName = "from-" + aInNeId + "-" + aInIYangObject.get("id");
            if (logger.isDebugEnabled()) {
                logger.debug("Setting name from brownfield discovered tunnel to: " + brownfieldName);
            }
            lNewYang.setProperty("name", brownfieldName);

            // add cmodel source
            ArrayList lSources;
            if (aInIYangObject.getExtraData("sources") != null && aInIYangObject.getExtraData("sources") instanceof ArrayList) {
                lSources = (ArrayList) aInIYangObject.getExtraData("sources");
            } else {
                lSources = new ArrayList();
            }
            lSources.add("fdn:app:mdm-ami-cmodel:" + aInNeId + ":service:Service:/service/sdp[sdp-id='" + aInIYangObject.get("id") + "']");
            lNewYang.addExtraData("sources", lSources);
        }


        if (aInData.containsKey("_classId_") && aInData.get("_classId_") != null && aInData.get("_classId_").toString().startsWith("nokia-state")) {
            //run post processing on conf only except set name and fdn on state create notification

            /*need to run postprocessing to resolve tunnel destination-ne-id on state
            if (aInNotificationType == NotificationType.CREATE) {
                updateInDb(lNewYang, aInIYangObject.getIdentifier(), false);
            }
            return;*/
        }

        if (logger.isDebugEnabled()) {
            logger.debug("Starting post-processing tunnel object (" + aInNotificationType + "): " + aInIYangObject.getIdentifier());
        }


        Map<String, List<String>> lNeNameDestCache = neNameDestCache.get();
        if (null == lNeNameDestCache) {
            lNeNameDestCache = new HashMap<>();
            neNameDestCache.set(lNeNameDestCache);
            Transactor.getContext().addEventHandler(TxPhase.FINAL, (p, c) -> {
                neNameDestCache.remove();
            });
        }


        QueryParameters lQueryParameters = new QueryParameters();
        lQueryParameters.setDepth(2);
        ArrayList<Field> lFieldList = new ArrayList<>();
        //lFieldList.add(new Field("component-id"));
        lFieldList.add(new Field("ne-name"));
        Fields lFields = new Fields(lFieldList);
        lQueryParameters.setFields(lFields);
        IYangDB lYangDb = aInMdResyncFw.getIYangDB();


        String lFoundSourceNeName = "";
        String lFoundDestinationNeName = "";
        List<String> lFoundDestinationNeNameDestList = null;
        List<String> lFoundSourceNeNameDest = getNeNameByIdAndDestFromCache(aInNeId, true, lNeNameDestCache, lQueryParameters, lYangDb);
        if (lFoundSourceNeNameDest != null && lFoundSourceNeNameDest.size()>=1) {
            lFoundSourceNeName=lFoundSourceNeNameDest.get(0);
        }
        String lDestIp="";
        if(aInData.containsKey("far-end") && aInData.get("far-end")!=null && ((Map)aInData.get("far-end")).containsKey("ip-address")){
            //full resync
            lDestIp=(String)((Map)aInData.get("far-end")).get("ip-address");
        }
        if(aInData.containsKey("oper-tunnel-far-end-inet-address") && aInData.get("oper-tunnel-far-end-inet-address")!=null){
            //full resync state
            lDestIp=(String)aInData.get("oper-tunnel-far-end-inet-address");
        }
        else if(aInData.containsKey("ip-address")){
            //notification
            lDestIp=(String)aInData.get("ip-address");
        }

        if (lDestIp!=null && !lDestIp.equals("")) {
            lFoundDestinationNeNameDestList = getNeNameByIdAndDestFromCache(lDestIp, false, lNeNameDestCache, lQueryParameters, lYangDb);
            if (lFoundDestinationNeNameDestList != null && lFoundDestinationNeNameDestList.size()>=1) {
                lFoundDestinationNeName=lFoundDestinationNeNameDestList.get(0);
            }
            if (lFoundDestinationNeName.equals(lDestIp)) { //lookup ip from openconfig, Requires openconfig adaptor sros-oc-logical-inventory
                QueryParameters lQpOpenConfigInt = new QueryParameters();
                lQpOpenConfigInt.setDepth(2);
                lQpOpenConfigInt.setFields(Fields.parse("ip"));
                lQpOpenConfigInt.setLimit(2);
                String xpath = "/openconfig-interfaces:interfaces/interface/subinterfaces/subinterface/openconfig-if-ip:ipv4/addresses/address[ip='" + lDestIp + "']" +
                        "|/openconfig-interfaces:interfaces/interface/subinterfaces/subinterface/openconfig-if-ip:ipv6/addresses/address[ip='" + lDestIp + "']";
                List<IYangObject> lIpsFoundList = null;
                lIpsFoundList = lYangDb.getMany(xpath, lQpOpenConfigInt);
                if (lIpsFoundList.size() > 1) {
                    logger.info("found more than one ip in db for " + lDestIp);

                } else if (lIpsFoundList.size() == 1) {
                    //get neId
                    final String lDestNeId = lIpsFoundList.get(0).getNetworkId();
                    if (lDestNeId != null) {
                        lFoundDestinationNeNameDestList = getNeNameByIdAndDestFromCache(lDestNeId, true, lNeNameDestCache, lQueryParameters, lYangDb);
                        lFoundDestinationNeName = lFoundDestinationNeNameDestList.get(0);

                        List<String> neNameAndIpList = new ArrayList<String>();
                        neNameAndIpList.add(lFoundDestinationNeName);
                        neNameAndIpList.add(lDestNeId);

                        lNeNameDestCache.put(lDestIp, neNameAndIpList);
                    }
                }
            }
        }

        lNewYang.setProperty("source-ne-name", lFoundSourceNeName);
        if (lFoundDestinationNeNameDestList != null && lFoundDestinationNeNameDestList.size()>=2) {
            lNewYang.setProperty("destination-ne-name", lFoundDestinationNeName);
            lNewYang.setProperty("destination-ne-id", lFoundDestinationNeNameDestList.get(1));//update destination-ne-id to be correct ip and use for stitch
        }
        else if(lDestIp==null){
            lNewYang.setProperty("destination-ne-name", "");
            lNewYang.setProperty("destination-ne-id", "");//delete destination ne-id
        }

        /*
        if(aInData.containsKey("lsp")){
            // bind to existing lsp in db
            if(logger.isDebugEnabled()) {
                //logger.debug("contains lsp");
            }
        }*/

        if (!lNewYang.getProperties().isEmpty()) {
            updateInDb(lNewYang, aInIYangObject.getIdentifier(), false);
        }
    }

    private String queryNetworkElements(String aInIp, QueryParameters aInQueryParameters, IYangDB aInYangDb) {
        String lportFdn = "/nsp-equipment:network/network-element[ne-id='" + aInIp + "']";
        IYangObject lNeYangObj = aInYangDb.getSingle(lportFdn, aInQueryParameters);
        return (lNeYangObj != null && lNeYangObj.hasProperty("ne-name")) ? (String) lNeYangObj.getProperty("ne-name") : null;
    }

    private List<String> getNeNameByIdAndDestFromCache(String aInIp, boolean aInSetCache, Map<String, List<String>> aInNeNameDestCache, QueryParameters aInQueryParameters, IYangDB aInYangDb) {
        //source will always be neId even if loopback

        List<String> lFoundNeNameDest = aInNeNameDestCache.get(aInIp);
        if (null == lFoundNeNameDest) {
            String lFoundNeName = queryNetworkElements(aInIp, aInQueryParameters, aInYangDb);

            if (lFoundNeName == null) {
                //else set as neId
                lFoundNeName = aInIp;
            }
            lFoundNeNameDest = new ArrayList<String>();
            lFoundNeNameDest.add(lFoundNeName);
            lFoundNeNameDest.add(aInIp);
            if (aInSetCache) {
                aInNeNameDestCache.put(aInIp, lFoundNeNameDest);
            }
        }
        return lFoundNeNameDest;
    }

    private void updateInDb(IYangObject aInYangObject, String aInXPath, boolean aInDelete) {
        final QueryParameters qp = new QueryParameters();
        qp.setSuperUser(true);
        IExecutionContext executionContextSvc = new ExecutionContext(null, null, false, false, false);
        qp.setIExecutionContext(executionContextSvc);

        if (aInDelete) {
            yangDB.delete(aInXPath, qp);
        } else {
            yangDB.update(aInXPath, aInYangObject, qp);
        }

    }
}