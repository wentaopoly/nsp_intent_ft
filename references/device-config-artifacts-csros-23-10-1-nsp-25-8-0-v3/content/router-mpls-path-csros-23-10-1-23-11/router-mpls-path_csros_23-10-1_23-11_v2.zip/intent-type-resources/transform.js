load({ script: resourceProvider.getResource("nfmpSuggest.js"), name: "NfmpSuggest" });
function transformData() {
    const nfmpSuggest = new NfmpSuggest();
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        let tunnelData;
        if(intentConfig.displayedName){
            tunnelData = nfmpSuggest.getTunnelData(neId, intentConfig.displayedName, "pathId", "displayedName");
            if(tunnelData == undefined)
            {
                tunnelData = 0;
            }
            intentConfig.pathId = tunnelData;
            objectFullName = objectFullName.replace(/id-[^:]+/, "id-"+tunnelData);
        }
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        let tunnelPathName = uniqueIdentifierValues[1];
        if(tunnelPathName){
            let tunnelPathData = nfmpSuggest.getTunnelData(neId, tunnelPathName, "pathId", "displayedName");
            objectFullName = objectFullName.replace(/id-[^:]+/, "id-"+tunnelPathData);
        }
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
        if(xpath==="mpls-ProvisionedHop.ipAddress" && targetValue==="N/A") {
            targetValue=null;
        }
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
}