/* eslint-disable no-unused-vars */
/**
 * There are various use-cases where intent-designer would like to modify the payload/intent-config
 * before/after sync/audit/brownfield discovery. This class along with {@link CustomHooks}
 * provides placeholder/function to achieve such functionality
 */
let RuntimeException = Java.type("java.lang.RuntimeException");

export default class IntentDeviceDeviation {

  removeIntentConfig(intentConfig, neId) {
    var deviationData = undefined;
    try {
      deviationData = this.deviationData();
    } catch (err) {
      return intentConfig;
    }
    logger.info("Removing deviations from config: " + intentConfig);
    var neFamily = this.getNeFamilyRelease(neId);
    logger.info("NE family : " + neFamily);
    var neType = this.getNeType(neFamily);
    var chassisType = this.getChassisType(neFamily);
    var neVersion = this.getNeVersion(neFamily);
    logger.info("Intent dev JS: neType: " + neType + ", chassisType: " + chassisType + ", neVersion: " + neVersion);
    var deviationInfoArr = deviationData["devitaionInfo"];
    for (var i = 0; i < deviationInfoArr.length; i++) {
      var deviationObj = deviationInfoArr[i];
      var deviationNetype = deviationObj["neType"];
      var deviationNeVersion = deviationObj["neVersion"];
      var deviationChassisTypes = deviationObj["chassisTypes"];
      var chassisFlag = deviationChassisTypes.length == 0;
      if (!chassisFlag) {
        chassisFlag = deviationChassisTypes.indexOf(chassisType) != -1;
      }
      var result = neType.localeCompare(deviationNetype) == 0 && chassisFlag;
      var neversionResult = deviationNeVersion.length == 0;
      if (!neversionResult) {
        neversionResult = deviationNeVersion.indexOf(neVersion) != -1;
      }
      logger.info("neType : " + neType + ", chassisType : " + chassisType + ",result : " + result + ", neVersionResult : " + neversionResult);
      if (result && neversionResult) {
        var notSupportedAttributes = deviationObj["NotSupportedAttributes"];
        for (var j = 0; j < notSupportedAttributes.length; j++) {
          var segments = notSupportedAttributes[j].split(".");
          var attributeToDelete = segments.pop();
          var dataPath = segments.join(".");
          logger.info("Deleting attribute : " + attributeToDelete + ", from Data Path : " + dataPath);
          this.deleteAttribute(intentConfig, dataPath, attributeToDelete);
        }
      }
    }
    logger.info("intent deviation post process config" + JSON.stringify(intentConfig));
    return intentConfig;
  }

  /**
   *
   * @param {*} intentConfig
   * @param {*} path
   * @param {*} attribute
   * @returns
   */
  deleteAttribute(intentConfig, path, attribute) {
    if (path !== "") {
      var segments = path.split(".");
      for (var segment of segments) {
        if (!intentConfig.hasOwnProperty(segment)) {
          return;
        }
        intentConfig = intentConfig[segment];
        //check for Array or Object
        if (Array.isArray(intentConfig)) {
          for (var i = 0; i < intentConfig.length; i++) {
            if (intentConfig[i].hasOwnProperty(attribute)) {
              delete intentConfig[i][attribute];
            } else {
              segments.splice(0, segments.indexOf(segment) + 1);
              var remSegments = segments.join(".");
              this.deleteAttribute(intentConfig[i], remSegments, attribute);
            }
          }
        } else if (intentConfig.hasOwnProperty(attribute)) {
          delete intentConfig[attribute];
        }
      }
    } else {
      if (intentConfig.hasOwnProperty(attribute)) {
        delete intentConfig[attribute];
      }
    }
  }

  getNeFamilyRelease(target) {
    var neId = target;
    var returnNeType = "";
    try {
      var managerList = [];
      var managers = mds.getAllManagersOfType("REST");
      managers.forEach(function (manager) {
        if (mds.getManagerByName(manager).getConnectivityState().toString() === "CONNECTED") {
          managerList.push(manager);
        }
      });
      var Arrays = Java.type("java.util.Arrays");
      var ArrayList = Java.type("java.util.ArrayList");

      var jsArray = ["NFM-P", "NSP", "MDC"];
      var javaList = new ArrayList(Arrays.asList(jsArray));
      var devices = mds.getAllManagedDevicesFrom(javaList);
      devices.forEach(function (device) {
        var deviceName = device.getName();
        logger.info("device Name : " + deviceName);
        var result = deviceName.localeCompare(neId);
        if (result == 0) {
          logger.info("result: " + result);
          returnNeType = device.getFamilyTypeRelease();
          return returnNeType;
        }
      });
      return returnNeType;
    } catch (e) {
      logger.error("[LOGGER-DEMO] Exception *******************  : " + e);
      return {
        "Device Not Found": "Device Not Found",
      };
    }
  }

  /**
   *
   * @param {*} neFamily
   * @returns
   */
  getNeType(neFamily) {
    var neFamilyArr = neFamily.split(":");
    return neFamilyArr[0];
  }

  getChassisType(neFamily) {
    var neFamilyArr = neFamily.split(":");
    return neFamilyArr[2];
  }

  /**
   *
   * @param {*} neFamily
   * @returns
   */
  function(neFamily) {
    var neFamilyArr = neFamily.split(":");
    return neFamilyArr[2];
  }

  /**
   *
   * @param {*} neFamily
   * @returns
   */
  getNeVersion(neFamily) {
    var neFamilyArr = neFamily.split(":");
    return neFamilyArr[1];
  }

  /**
   *
   * @returns
   */
  deviationData() {
    var deviationObj = resourceProvider.getResource("custom/intent-deviations.json");
    logger.info("Deviation Info Data : " + deviationObj);
    return JSON.parse(deviationObj);
  }
}
