var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});


function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function(target, initialPropertyName) {

        let neId = parseTarget.getNeIdFromTarget(target);
        let portId = parseTarget.getUniqueIdentifier(target);
        let searchPayLoad = this.constructSearchString(neId, portId);
        let searchResponse = nfmpFwk.find(neId, searchPayLoad);
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                throw new RuntimeException("Failed to get Port info from nfm-p for Ne " + neId + " and Port Id: " + portId);
            if(JSON.parse(searchResponse["response"]).length === 0)
                throw new RuntimeException("There is no port with Port Id:"+portId);
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse[0];
    }

    this.constructSearchString = function(neId, portId) {
        let portFullName =  util.getBaseFdnForPort(neId, portId);
        let filterExpression = "siteId='" + neId + "' AND fullName='" + portFullName + "'";
        let jsonPayLoad = {
            "fullClassName": "equipment.Connector",
            "filter": {
                "filterExpression": filterExpression
            }
        };

        return jsonPayLoad;
    }

    this.extractDeviceConfig = function(defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        let portconfig = deviceConfig['properties'];
        if (null !== portconfig) {
            this.extractConnectorPortProperties(parsedDefaultTargetData, portconfig);
        }
        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData))
        return parsedDefaultTargetData;
    }

    this.extractConnectorPortProperties = function (defaultTargetData, portconfig) {
        logger.info("extractConnectorPortProperties...");
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object')
            {
                let mappings = modelDeviceMapping.getMapping("port");
                this.traverseAndUpdatePortConfig(targetKey, targetObj, portconfig,mappings);
            }
        }
        return defaultTargetData;
    }

    this.traverseAndUpdatePortConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (value != null && typeof value === 'object') {
                this.traverseAndUpdatePortConfig(mappedKey, value, parsedDeviceConfig, mappings);
            } else {
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
            }
        }
        return obj;
    }

    this.getAndUpdateFromDeviceConfig = function(mappings, mappedKey, targetKey, targetObj, parsedDeviceConfig) {
        // Get the key from mapping against targetKey
        // If the mapping key is not undefined, Get the value from deviceKey
        // if the value from deviceConfig against that mapping key is not n
        let nfmpKey = mappings[mappedKey];
        let deviceValue = parsedDeviceConfig[nfmpKey];

        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);
    }

    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue !== null)
        {
            switch (mappedKey)
            {
                case "port.admin-state":
                    deviceValue = util.transformToIntentAdminState(deviceValue);
                    break;
                case "port.connector.breakout":
                    deviceValue = util.transformToIntentBreakout(deviceValue);
                    break;
                case "port.connector.rs-fec-mode":
                    deviceValue = util.transformToIntentRsFecMode(deviceValue);
                    break;
            }
            return deviceValue;
        }
    }
}
