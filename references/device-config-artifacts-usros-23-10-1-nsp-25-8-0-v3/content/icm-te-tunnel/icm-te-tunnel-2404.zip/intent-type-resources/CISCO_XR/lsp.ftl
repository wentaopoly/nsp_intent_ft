<#ftl output_format="JSON">
<#setting number_format="computer">
{
    "active": "act",
    "interface-name": "tunnel-te${target?keep_after("_")}",
    "description" : "${config["description"]}",
    <#if config["admin-state"] == "tunnel-admin-state-down">
        "shutdown" : [null],
    </#if>
    "interface-virtual": [null],
    "ipv4-network" : {
        "addresses" :{
            "unnumbered":"Loopback0"
        }
    },
    "tunnel-te-attributes": {
        "signalled-name" : "${target}",
        "destination":"${config["destination"]}",
        <#if extraParams.primary?size != 0>
            <#list extraParams.primary?values as value>
                <#if value["conf"]??>
                    "priority" : {
                        "setup-priority" : ${value["conf"]["setup-priority"]},
                        "hold-priority" : ${value["conf"]["hold-priority"]}
                    },
                </#if>
            </#list>
        </#if>

        <#if extraParams.primary?size != 0>
            <#list extraParams.primary?values as value>
                <#if value["conf"]["use-path-computation"] == true>
                    "pce":{
                        "delegation":{
                            "enable":[null],
                            "reopt":[null]
                        }
                    },
                </#if>
            </#list>
        </#if>

        <#if config["protection"]["enable"] == true>
            "fast-reroute" : {
                "bandwidth-protection":1,
                "node-protection":1
            },
        </#if>

        <#if extraParams.primary?size != 0>
            <#list extraParams.primary?values as value>
                "bandwidth": {
                    "dste-type":"pre-standard-dste",
                    "class-or-pool-type":0,
                    "bandwidth":${value.bandwidth}
                },
            </#list>
        </#if>

        "path-option-protects": {
            "path-option-protect": [
                {
                    "protection": "active"
                    <#if extraParams.primary?has_content || extraParams.secondary?has_content>
                        ,
                        "path-options" : {
                            "path-option" :[
                                <#list extraParams.primary?values as value>
                                    {
                                        "preference-level": ${value["conf"]["preference"]},
                                        "path-type": "explicit-name",
                                        "path-name":"${value.name}"
                                        <#if config["signaling-type"] == "path-setup-sr">,
                                            "segment-routing": "segment-routing"
                                        </#if>
                                    }

                                    <#if value?has_next>,</#if>
                                </#list>

                                <#if extraParams.secondary?has_content && extraParams.primary?has_content>
                                    ,
                                    <#list extraParams.secondary?values as sec>
                                        {
                                            "preference-level": ${sec["conf"]["preference"]},
                                            "path-type": "explicit-name",
                                            "path-name":"${sec.name}"
                                            <#if config["signaling-type"] == "path-setup-sr">,
                                                "segment-routing": "segment-routing"
                                            </#if>
                                        }
                                        <#if sec?has_next>,</#if>
                                    </#list>
                                </#if>

                                <#list extraParams.primary?values as value>
                                    <#if value.excludeAdminGroup? has_content>
                                        ,
                                        <#list value.excludeAdminGroup?values as excludeVal>
                                            {
                                                "preference-level":${(1?number * 4 + excludeVal?index)?number},
                                                "path-type": "dynamic",
                                                "path-option-attribute-set-name" : "${excludeVal}"
                                                <#if config["signaling-type"] == "path-setup-sr">,
                                                    "segment-routing": "segment-routing"
                                                </#if>
                                            }

                                        <#if excludeVal?has_next>,</#if>
                                        </#list>
                                    </#if>
                                    <#if value.includeAdminGroup? has_content>
                                        ,
                                        <#list value.includeAdminGroup?values as includeVal>
                                        {
                                            "preference-level":${(1?number *  6+ includeVal?index)?number},
                                            "path-type": "dynamic",
                                            "path-option-attribute-set-name" : "${includeVal}"
                                            <#if config["signaling-type"] == "path-setup-sr">,
                                                "segment-routing": "segment-routing"
                                            </#if>
                                        }

                                        <#if includeVal?has_next>,</#if>
                                        </#list>
                                    </#if>
                                </#list>
                                <#if extraParams.secondary?has_content && extraParams.primary?has_content && extraParams.hopless?has_content>,</#if>
                                    <#list extraParams.hopless?values as hops>
                                    {
                                        "name":"${hops.name}"
                                    }
                                    </#list>

                            ]
                        }

                    <#else>,
                        "path-options" : {
                            "path-option" :[
                            {
                                "preference-level": 1,
                                "path-type": "dynamic"
                                <#if config["signaling-type"] == "path-setup-sr">,
                                    "segment-routing": "segment-routing"
                                </#if>
                            }
                            ]
                        }

                    </#if>
                }
            ]
        }
    }
}