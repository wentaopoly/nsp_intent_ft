load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
function transformData() {
    const util = new utilities();
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        let portAttrib = this.getPortAttributes(payload["objectFullName"]);
        if(isAudit) {
            if(payload["configInfo"]["equipment.PhysicalPort"]["mode"] == "access"){
                if(payload["configInfo"]["equipment.PhysicalPort"]["collectStats"] !== undefined){
                    delete payload["configInfo"]["equipment.PhysicalPort"]["collectStats"];
                }
            }
            if(payload["configInfo"]["equipment.PhysicalPort"]["mode"] == "network"){
                if(payload["configInfo"]["equipment.PhysicalPort"]["ethAccessCollectStats"] !== undefined){
                    delete payload["configInfo"]["equipment.PhysicalPort"]["ethAccessCollectStats"];
                }
            }
        }
        if (!isAudit) {
            if(!payload["configInfo"]["equipment.PhysicalPort"]["portSchedulerPolicyObjectPointer"]){
                payload["configInfo"]["equipment.PhysicalPort"]["portSchedulerPolicyObjectPointer"] = '';
                payload["configInfo"]["equipment.PhysicalPort"]["monitorPortScheduler"] = "disabled";
            }
            if(!payload["configInfo"]["equipment.PhysicalPort"]["accountingPolicyObjectPointer"]){
                payload["configInfo"]["equipment.PhysicalPort"]["accountingPolicyObjectPointer"] = '';
            }
            if(!payload["configInfo"]["equipment.PhysicalPort"]["ethAccessAccountingPolicyObjectPointer"]){
                payload["configInfo"]["equipment.PhysicalPort"]["ethAccessAccountingPolicyObjectPointer"] = '';
            }
            if(!payload["configInfo"]["equipment.PhysicalPort"]["etherAccountingPolicyObjectPointer"]){
                payload["configInfo"]["equipment.PhysicalPort"]["etherAccountingPolicyObjectPointer"] = '';
            }
            if(!payload["configInfo"]["equipment.PhysicalPort"]["monitorOperGroupPtr"]){
                payload["configInfo"]["equipment.PhysicalPort"]["monitorOperGroupPtr"] = '';
            }
            if(!payload["configInfo"]["equipment.PhysicalPort"]["portQosPolicyPointer"]){
                payload["configInfo"]["equipment.PhysicalPort"]["portQosPolicyPointer"] = 'PortQosPolicy7250SROS:default';
            }
            if(payload["configInfo"]["equipment.PhysicalPort"]["portSchedulerPolicyObjectPointer"] != '' &&
            util.isObjectExists("equipment.PortSchedulerOverride",payload["distinguishedName"]+":port-scheduler-override-"+(payload["configInfo"]["equipment.PhysicalPort"]["portSchedulerPolicyObjectPointer"].replace('Port Scheduler:', '')))) {
                delete payload["configInfo"]["equipment.PhysicalPort"]["portSchedulerPolicyObjectPointer"];
            }
            if(payload["configInfo"]["equipment.PhysicalPort"]["otuEnable"] == "enable" && util.isObjectExists("ethernetequipment.OtuInterface", payload["distinguishedName"]+":otu")) {
                if(portAttrib["otuEnable"] == "enable" && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.OtuInterface"]) {
                    delete payload["configInfo"]["equipment.PhysicalPort"]["otuEnable"];
                }
            }

            if(portAttrib["iomType"] == "card_iom4_e_hs"){
                if(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["slope.QosPool"]){
                    delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["slope.QosPool"];
                }
            }

            if(portAttrib["isPrimaryLagMember"] == "false" && portAttrib["lagMembershipId"] != 0){
                if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["slope.QosPool"]) {
                    for (var index in payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["slope.QosPool"]) {
                        var qosPoolConfig = payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["slope.QosPool"][index];

                        if (qosPoolConfig["slopePolicyPointer"]) {
                            delete qosPoolConfig["slopePolicyPointer"];
                        }
                        if (qosPoolConfig["reservedCbs"]) {
                            delete qosPoolConfig["reservedCbs"];
                        }
                        payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["slope.QosPool"][index] = qosPoolConfig;
                    }
                }
            }

            if(portAttrib["administrativeState"] == "portInService" && (portAttrib["specificCardType"] == "card_imm1_oc768_tun" ||
            portAttrib["specificCardType"] == "card_imm1_40gb_xp_tun" || portAttrib["specificCardType"] == "mda_m1_10gb_dwdm_tun" ||
            portAttrib["specificCardType"] == "mda_m2_10gb_xp_xfp_wt" || portAttrib["specificCardType"] == "mda_imm1_oc768_tun" ||
            portAttrib["specificCardType"] == "mda_imm1_40gb_xp_tun" || portAttrib["specificCardType"] == "mda_imm_p1_100g_tun" ||
            portAttrib["specificCardType"] == "mda_imm_p1_100g_tun_b" || portAttrib["specificCardType"] == "mda_x2_100g_tun" ||
            portAttrib["cardSubType"] == "pss_aluWdm260scx2OTU4Card" || portAttrib["cardSubType"] == "pss_aluWdm130scx10Card")){
                if(portAttrib["otuEnable"] == "enable"){
                    if(portAttrib["dwdmChannel"] == "0"){
                        delete payload["configInfo"]["equipment.PhysicalPort"]["administrativeState"];
                    }
                }
            }

            if(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lag.SharedQueueVlanPolicy"]) {
                for (var index in payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lag.SharedQueueVlanPolicy"]) {
                    var sharedQueueVlanPolicy = payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lag.SharedQueueVlanPolicy"][index];

                    if (sharedQueueVlanPolicy["vlanQosPolicyName"] == "default") {
                        sharedQueueVlanPolicy["vlanQosPolicyPtr"] = "VlanQosPolicy7250SROS:default";
                    }
                    else{
                        sharedQueueVlanPolicy["vlanQosPolicyPtr"] = "network:"+neId+":VlanQosPolicy7250SROS:"+sharedQueueVlanPolicy["vlanQosPolicyName"];
                    }

                    payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lag.SharedQueueVlanPolicy"][index] = sharedQueueVlanPolicy;
                }
            }
        }
        if(payload["configInfo"]["equipment.PhysicalPort"]["ols"] != "enabled"){
            delete payload["configInfo"]["equipment.PhysicalPort"]["olsEgAmpGain"];
        }
        if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]){
            if(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestNonTpmrPortConfiguration"]){
                if(!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestNonTpmrPortConfiguration"]["portCfgTLVsTxEnable"] ||
                payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestNonTpmrPortConfiguration"]["portCfgTLVsTxEnable"].length == 0) {
                    payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestNonTpmrPortConfiguration"]["portCfgTLVsTxEnable"] = {"bit": []};
                    if(isAudit){
                        payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestNonTpmrPortConfiguration"]["portCfgTLVsTxEnable"] = "";
                    }
                }
            }

            if(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestCustomerPortConfiguration"]){
                if(!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestCustomerPortConfiguration"]["portCfgTLVsTxEnable"] ||
                payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestCustomerPortConfiguration"]["portCfgTLVsTxEnable"].length == 0) {
                    payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestCustomerPortConfiguration"]["portCfgTLVsTxEnable"] = {"bit": []};
                    if(isAudit){
                        payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestCustomerPortConfiguration"]["portCfgTLVsTxEnable"] = "";
                    }
                }
            }

            if(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]){
                if(!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["portCfgTLVsTxEnable"] ||
                payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["portCfgTLVsTxEnable"].length == 0) {
                    payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["portCfgTLVsTxEnable"] = {"bit": []};
                    if(isAudit){
                        payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["portCfgTLVsTxEnable"] = "";
                    }
                }
                if(!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["medPortConfigTLVsTxEnable"] ||
                payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["medPortConfigTLVsTxEnable"].length == 0) {
                    payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["medPortConfigTLVsTxEnable"] = {"bit": []};
                    if(isAudit){
                        payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["lldp.LLDPNearestBridgePortConfiguration"]["medPortConfigTLVsTxEnable"] = "";
                    }
                }
            }

            if(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"] ){
                if (!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["reportAlarmBits"] ||
                payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["reportAlarmBits"].length == 0) {
                    payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["reportAlarmBits"] = {"bit": []};
                    if(isAudit){
                        payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["reportAlarmBits"] = "";
                    }
                }
                if(!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["addressedCapability"] ||
                payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["addressedCapability"].length == 0) {
                    payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["addressedCapability"] = {"bit": []};
                    if(isAudit){
                        payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["addressedCapability"] = "";
                    }
                }
            }
            if(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.CoherentOpticalCfg"]){
                if( !payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.CoherentOpticalCfg"]["cohOptPortCfgAlarms"] ||
                payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.CoherentOpticalCfg"]["cohOptPortCfgAlarms"].length == 0) {
                    payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.CoherentOpticalCfg"]["cohOptPortCfgAlarms"] = {"bit": []};
                    if(isAudit){
                        payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.CoherentOpticalCfg"]["cohOptPortCfgAlarms"] = "";
                    }
                }
            }
            if(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.OtuInterface"]){
                if(!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.OtuInterface"]["cfgAlarms"] ||
                payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.OtuInterface"]["cfgAlarms"].length == 0) {
                    payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.OtuInterface"]["cfgAlarms"] = {"bit": []};
                    if(isAudit){
                        payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.OtuInterface"]["cfgAlarms"] = "";
                    }
                }
            }
            if(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortMonitorSpecifics"]){
                if(!payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortMonitorSpecifics"]["reportAlarmBits"] ||
                payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortMonitorSpecifics"]["reportAlarmBits"].length == 0) {
                    payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortMonitorSpecifics"]["reportAlarmBits"] = {"bit": []};
                    if(isAudit){
                        payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortMonitorSpecifics"]["reportAlarmBits"] = "";
                    }
                }
            }
            if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.PortDwdmConfig"] &&
                Object.keys(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.PortDwdmConfig"]).length == 0) {
                delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.PortDwdmConfig"];
            }
        }

        if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.AccessIngrQGroup"]) {
            for (var index in payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.AccessIngrQGroup"]) {
                var accessIngrQGroupConfig = payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.AccessIngrQGroup"][index];

                if (accessIngrQGroupConfig["queueGroupPolicyPointer"]) {
                    accessIngrQGroupConfig["queueGroupName"] = accessIngrQGroupConfig["queueGroupPolicyPointer"].replace('ingressQGroup:', '');
                }
                if (!accessIngrQGroupConfig["schedulerPolicyPointer"]) {
                   accessIngrQGroupConfig["schedulerPolicyPointer"] = '';
                }
                if (!accessIngrQGroupConfig["accountingPolicyPointer"]) {
                   accessIngrQGroupConfig["accountingPolicyPointer"] = '';
                }

               if (accessIngrQGroupConfig["children-Set"] && accessIngrQGroupConfig["children-Set"]["ethernetequipment.AccessIngrQOverride"]){
                   for (var indx in accessIngrQGroupConfig["children-Set"]["ethernetequipment.AccessIngrQOverride"]){
                       var accessIngrQOverrideConfig = accessIngrQGroupConfig["children-Set"]["ethernetequipment.AccessIngrQOverride"][indx];
                       if (!accessIngrQOverrideConfig["queueGroupName"]){
                           accessIngrQOverrideConfig["queueGroupName"] = accessIngrQGroupConfig["queueGroupName"];
                       }
                       accessIngrQGroupConfig["children-Set"]["ethernetequipment.AccessIngrQOverride"][indx] = accessIngrQOverrideConfig;
                   }
               }

               payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.AccessIngrQGroup"][index] = accessIngrQGroupConfig;
            }
        }

        if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.NetworkEgrQGroup"]) {
            for (var index in payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.NetworkEgrQGroup"]) {
                var networkEgrQGroupConfig = payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.NetworkEgrQGroup"][index];

                if (networkEgrQGroupConfig["queueGroupPolicyPointer"]) {
                    networkEgrQGroupConfig["queueGroupName"] = networkEgrQGroupConfig["queueGroupPolicyPointer"].replace('egressQGroup:', '');
                }
                if (!networkEgrQGroupConfig["policerControlPolicyPointer"]) {
                   networkEgrQGroupConfig["policerControlPolicyPointer"] = '';
                }
                if (!networkEgrQGroupConfig["schedulerPolicyPointer"]) {
                   networkEgrQGroupConfig["schedulerPolicyPointer"] = '';
                }
                if (!networkEgrQGroupConfig["accountingPolicyPointer"]) {
                   networkEgrQGroupConfig["accountingPolicyPointer"] = '';
                }

               if (networkEgrQGroupConfig["children-Set"] && networkEgrQGroupConfig["children-Set"]["ethernetequipment.NetworkEgrQOverride"]){
                   for (var indx in networkEgrQGroupConfig["children-Set"]["ethernetequipment.NetworkEgrQOverride"]){
                       var networkEgrQOverrideConfig = networkEgrQGroupConfig["children-Set"]["ethernetequipment.NetworkEgrQOverride"][indx];
                       if (!networkEgrQOverrideConfig["queueGroupName"]){
                           networkEgrQOverrideConfig["queueGroupName"] = networkEgrQGroupConfig["queueGroupName"];
                       }
                       networkEgrQGroupConfig["children-Set"]["ethernetequipment.NetworkEgrQOverride"][indx] = networkEgrQOverrideConfig;
                   }
               }

               payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.NetworkEgrQGroup"][index] = networkEgrQGroupConfig;
            }
        }

        if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.AccessEgrQGroup"]) {
            for (var index in payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.AccessEgrQGroup"]) {
                var accessEgrQGroupConfig = payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.AccessEgrQGroup"][index];

                if (accessEgrQGroupConfig["queueGroupPolicyPointer"]) {
                    accessEgrQGroupConfig["queueGroupName"] = accessEgrQGroupConfig["queueGroupPolicyPointer"].replace('egressQGroup:', '');
                }
                if (!accessEgrQGroupConfig["schedulerPolicyPointer"]) {
                   accessEgrQGroupConfig["schedulerPolicyPointer"] = '';
                }
                if (!accessEgrQGroupConfig["accountingPolicyPointer"]) {
                   accessEgrQGroupConfig["accountingPolicyPointer"] = '';
                }

               if (accessEgrQGroupConfig["children-Set"] && accessEgrQGroupConfig["children-Set"]["ethernetequipment.AccessEgrQOverride"]){
                   for (var indx in accessEgrQGroupConfig["children-Set"]["ethernetequipment.AccessEgrQOverride"]){
                       var accessEgrQOverrideConfig = accessEgrQGroupConfig["children-Set"]["ethernetequipment.AccessEgrQOverride"][indx];
                       if (!accessEgrQOverrideConfig["queueGroupName"]){
                           accessEgrQOverrideConfig["queueGroupName"] = accessEgrQGroupConfig["queueGroupName"];
                       }
                       accessEgrQGroupConfig["children-Set"]["ethernetequipment.AccessEgrQOverride"][indx] = accessEgrQOverrideConfig;
                   }
               }

               payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.AccessEgrQGroup"][index] = accessEgrQGroupConfig;
            }
        }

        if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"] && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["equipment.EgrSchVirtualPort"]) {
            for (var index in payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["equipment.EgrSchVirtualPort"]) {
                var egrSchVirtualPortConfig = payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["equipment.EgrSchVirtualPort"][index];

                if (!egrSchVirtualPortConfig["portSchedulerPolicyPointer"]) {
                   egrSchVirtualPortConfig["portSchedulerPolicyPointer"] = '';
                }
                if (!egrSchVirtualPortConfig["schedulerPolicyPointer"]) {
                   egrSchVirtualPortConfig["schedulerPolicyPointer"] = '';
                }

                payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["equipment.EgrSchVirtualPort"][index] = egrSchVirtualPortConfig;
            }
        }

        if(payload["configInfo"]["equipment.PhysicalPort"]["otuEnable"] == "disable"){
            if(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.OtuInterface"]){
                delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.OtuInterface"];
            }
        }

        if(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.EthernetPortSpecifics"]["networkMode"] != "wan") {
            if(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortSpecifics"]){
                delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortSpecifics"];
            }
            if(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortOverheadSpecifics"]){
                delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortOverheadSpecifics"];
            }
            if(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortMonitorSpecifics"]){
                delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["sonetequipment.SonetPortMonitorSpecifics"];
            }
        }
        if(payload["configInfo"]["equipment.PhysicalPort"]["transceiverDco"] == "disabled" && (portAttrib["specificCardType"] == "mda_me1_100gb_cfp2" ||
        portAttrib["specificCardType"] == "mda_x4_100g_cfp2"   || portAttrib["specificCardType"] == "mda_maxp1_100gb_cfp2" ||
        portAttrib["specificCardType"] == "mda_maxp1_100gb_cfp" || portAttrib["specificCardType"] == "mda_cx2_100g_cfp" ||
        portAttrib["specificCardType"] == "mda_imm_p1_100g_cfp" || portAttrib["specificCardType"] == "mda_m4_10g_sfp_plus_1_100g_cfp2")){
            if(payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]){
                if (portAttrib["specificCardType"] != "mda_m4_10g_sfp_plus_1_100g_cfp2" && payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.PortDwdmConfig"]){
                    delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.PortDwdmConfig"];
                }

                if (payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.CoherentOpticalCfg"]){
                    delete payload["configInfo"]["equipment.PhysicalPort"]["children-Set"]["ethernetequipment.CoherentOpticalCfg"];
                }
            }
        }

        return payload;
    }

    this.getPortAttributes = function (objectFullName){
        var className = "equipment.PhysicalPort";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "iomType",
                    "lagMembershipId",
                    "isPrimaryLagMember",
                    "administrativeState",
                    "specificCardType",
                    "cardSubType",
                    "otuEnable",
                    "dwdmChannel"
                ]
            }
        };

        var nfmpFwk = new NfmpFwk();
        var resultFetch = nfmpFwk.post("/v3/search", searchObject);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));
        var result = {}
        var iomType = "";
        if (finalResponse !== undefined)
        {
            result["iomType"] = finalResponse["iomType"][0];
            result["lagMembershipId"] = finalResponse['lagMembershipId'];
            result["isPrimaryLagMember"] = finalResponse['isPrimaryLagMember'];
            result["administrativeState"] = finalResponse['administrativeState'];
            result["specificCardType"] = finalResponse['specificCardType'][0];
            result["cardSubType"] = finalResponse['cardSubType'];
            result["otuEnable"] = finalResponse['otuEnable'];
            result["dwdmChannel"] = finalResponse['dwdmChannel'];
        }
        logger.info ("result = {}",JSON.stringify(result))

        return result;
    }

    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit, objectFullName) {
        if(xpath == "portSchedulerPolicyObjectPointer" ||
           xpath == "equipment-EgrSchVirtualPort.portSchedulerPolicyPointer")
        {
            targetValue = 'Port Scheduler:'+ targetValue;
        }
        if(xpath == "networkQueueObjectPointer")
        {
            targetValue = 'network:' + neId + ':Network Queue:'+ targetValue;
            if (neId && String(neId).indexOf(':') !== -1) {
                targetValue = util.modifyNeIdForIpV6(targetValue, neId);
            }
        }
        if(xpath == "accountingPolicyObjectPointer" ||
           xpath == "etherAccountingPolicyObjectPointer" ||
           xpath == "ethAccessAccountingPolicyObjectPointer" ||
           xpath == "ethernetequipment-AccessIngrQGroup.accountingPolicyPointer" ||
           xpath == "ethernetequipment-AccessEgrQGroup.accountingPolicyPointer" ||
           xpath == "ethernetequipment-NetworkEgrQGroup.accountingPolicyPointer")
        {
            targetValue = 'Accounting:'+ targetValue;
        }
        if(xpath == "ethernetequipment-AccessEgrQGroup.queueGroupPolicyPointer" ||
           xpath == "ethernetequipment-NetworkEgrQGroup.queueGroupPolicyPointer")
        {
            targetValue = 'egressQGroup:'+ targetValue;
        }
        if(xpath == "ethernetequipment-AccessIngrQGroup.queueGroupPolicyPointer")
        {
            targetValue = 'ingressQGroup:'+ targetValue;
        }
        if(xpath == "ethernetequipment-AccessEgrQGroup.schedulerPolicyPointer" ||
           xpath == "ethernetequipment-AccessIngrQGroup.schedulerPolicyPointer" ||
           xpath == "ethernetequipment-NetworkEgrQGroup.schedulerPolicyPointer" ||
           xpath == "equipment-EgrSchVirtualPort.schedulerPolicyPointer")
        {
            targetValue = 'Scheduler:'+ targetValue;
        }
        if(xpath == "hsPortPoolPointer")
        {
            targetValue = 'hsPortPoolPolicy:'+ targetValue;
        }
        if(xpath == "ethernetequipment-NetworkEgrQGroup.policerControlPolicyPointer")
        {
            targetValue = 'hPolicing:'+ targetValue;
        }
        if(xpath == "radiusServerPolicyAuthPointer" ||
           xpath == "radiusServerPolicyAcctPointer")
        {
            targetValue = 'network:' + neId + ':radiusServerPolicy:'+ targetValue;
            if (neId && String(neId).indexOf(':') !== -1) {
                targetValue = util.modifyNeIdForIpV6(targetValue, neId);
            }
        }
        if(xpath == "slope-QosPool.slopePolicyPointer")
        {
            targetValue = 'Slope:'+ targetValue;
        }
        if(xpath == "monitorOperGroupPtr")
        {
            targetValue = 'network:' + neId + ':svcgr-'+ targetValue;
            if (neId && String(neId).indexOf(':') !== -1) {
                targetValue = util.modifyNeIdForIpV6(targetValue, neId);
            }
        }
        if(xpath == "portQosPolicyPointer")
        {
            targetValue = 'PortQosPolicy7250SROS:'+ targetValue;
        }

        if(xpath == "olsEgAmpGain" ||
           xpath == "ethernetequipment-AccessIngrQGroup.ethernetequipment-AccessIngrQOverride.violationThreshold" ||
           xpath == "ethernetequipment-NetworkEgrQGroup.ethernetequipment-NetworkEgrQOverride.violationThreshold" ||
           xpath == "ethernetequipment-AccessEgrQGroup.ethernetequipment-AccessEgrQOverride.violationThreshold" ||
           xpath == "cohOptPortCfgTxPower" ||
           xpath == "cohOptPortCfgRxLosThresh" )
        {
            if(targetValue && !isNaN(targetValue) && !targetValue.contains("."))
            {
                targetValue = Number(targetValue);
                targetValue = targetValue.toFixed(1);
            }
        }

        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig) {
        if(xpath == "portSchedulerPolicyObjectPointer" ||
           xpath == "equipment-EgrSchVirtualPort.portSchedulerPolicyPointer")
        {
            targetValue = targetValue.replace('Port Scheduler:', '');
        }
        if(xpath == "networkQueueObjectPointer")
        {
            targetValue = targetValue.split(':Network Queue:')[1];
        }
        if(xpath == "accountingPolicyObjectPointer" ||
          xpath == "etherAccountingPolicyObjectPointer" ||
          xpath == "ethAccessAccountingPolicyObjectPointer" ||
          xpath == "ethernetequipment-AccessIngrQGroup.accountingPolicyPointer" ||
          xpath == "ethernetequipment-AccessEgrQGroup.accountingPolicyPointer" ||
          xpath == "ethernetequipment-NetworkEgrQGroup.accountingPolicyPointer")
        {
            targetValue = targetValue.replace('Accounting:', '');
        }
        if(xpath == "ethernetequipment-AccessEgrQGroup.queueGroupPolicyPointer" ||
           xpath == "ethernetequipment-NetworkEgrQGroup.queueGroupPolicyPointer")
        {
            targetValue = targetValue.replace('egressQGroup:', '');
        }
        if(xpath == "ethernetequipment-AccessIngrQGroup.queueGroupPolicyPointer")
        {
            targetValue = targetValue.replace('ingressQGroup:', '');
        }
        if(xpath == "ethernetequipment-AccessEgrQGroup.schedulerPolicyPointer" ||
           xpath == "ethernetequipment-AccessIngrQGroup.schedulerPolicyPointer" ||
           xpath == "ethernetequipment-NetworkEgrQGroup.schedulerPolicyPointer" ||
           xpath == "equipment-EgrSchVirtualPort.schedulerPolicyPointer")
        {
            targetValue = targetValue.replace('Scheduler:', '');
        }
        if(xpath == "hsPortPoolPointer")
        {
            targetValue = targetValue.replace('hsPortPoolPolicy:', '');
        }
        if(xpath == "ethernetequipment-NetworkEgrQGroup.policerControlPolicyPointer")
        {
            targetValue = targetValue.replace('hPolicing:', '');
        }
        if(xpath == "pae802_1x-PaePortAuthenticatorSpecifics.radiusServerPolicyAuthPointer" ||
           xpath == "pae802_1x-PaePortAuthenticatorSpecifics.radiusServerPolicyAcctPointer")
        {
            targetValue = targetValue.split(':radiusServerPolicy:')[1];
        }
        if(xpath == "slope-QosPool.slopePolicyPointer")
        {
            const lastIndex = targetValue.lastIndexOf(':');
            if (lastIndex !== -1) {
                targetValue = targetValue.replace(targetValue.slice(0, lastIndex + 1), '');
            }
        }
        if(xpath == "monitorOperGroupPtr")
        {
            targetValue = targetValue.split(':svcgr-')[1];
        }
        if(xpath == "portQosPolicyPointer")
        {
            targetValue = targetValue.replace('PortQosPolicy7250SROS:', '');
        }
        if(xpath == "olsEgAmpGain" && targetValue == 2500.0 )
        {
            targetValue = targetValue/100;
        }

        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }

    this.transformIntentConfig = function (intentConfig){

        if ( !(intentConfig["specificCardType"] == "mda_me16_25g_sfp28_plus_2_100g_qsfp28" || intentConfig["specificCardType"] == "mda_me12_10gb_1gb_sfp_plus" ||
        intentConfig["specificCardType"] == "mda_me2_100gb_qsfp28_msec" || intentConfig["specificCardType"] == "mda_me8_10gb_25gb_sfp_plus_28" ||
        intentConfig["specificCardType"] == "mda_maxp10_10_1_gb_msec_sfp_plus" || intentConfig["specificCardType"] == "mda_7210_k8sfp_4tx" ||
        intentConfig["specificCardType"] == "mda_7210_k3sfp_8combo" || intentConfig["specificCardType"] == "mda_imm48_sfp_2_100g_qsfp28" ||
        intentConfig["specificCardType"] == "mda_imm36_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m10_10g_sfp_plus" ||
        intentConfig["specificCardType"] == "mda_m6_10g_sfp_plus_1_100g_qsfp28" || intentConfig["specificCardType"] == "mdas_ms16_100g_sfpdd_plus_4_100g_qsfp28" ||
        intentConfig["specificCardType"] == "mda_m14_10g_sfp_plus_plus_4_1g_tx" || intentConfig["specificCardType"] == "mda_m6_10g_sfp_plus_1_100g_qsfp28" ||
        intentConfig["specificCardType"] == "mda_m10_10g_sfp_plus" || intentConfig["specificCardType"] == "mdas_ms8_100gb_sfpdd_plus_2_100g_qsfp28" ||
        intentConfig["specificCardType"] == "mda_m6_10g_sfp_plus_4_25g_sfp28" || intentConfig["specificCardType"] == "mda_m18_25g_sfp28" ||
        intentConfig["specificCardType"] == "mda_m2_cfp2_dco" || intentConfig["specificCardType"] == "mda_7210_m16tx_6sfp_2sfpp" ||
        intentConfig["specificCardType"] == "mda_m1_400g_qsfpdd_plus_1_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m46_10g_sfp_plus" ||
        intentConfig["specificCardType"] == "mda_m4_10g_sfp_plus_1_100g_cfp2" || intentConfig["specificCardType"] == "mda_m20_10g_sfp_plus" ||
        intentConfig["specificCardType"] == "mda_m24_800g_qsfpdd_1" )) {
            if (intentConfig["macsec-MacsecPort"]){
                delete intentConfig["macsec-MacsecPort"];
            }
        }

        if (!(intentConfig["portClass"] == "faste" || intentConfig["portClass"] == "gige" || intentConfig["portClass"] == "xgige" ||
        intentConfig["portClass"] == "variableEthernet" || intentConfig["portClass"] == "cgige" || intentConfig["portClass"] == "cdgige" ||
        intentConfig["portClass"] == "xlgige" || intentConfig["portClass"] == "xlcgige" || intentConfig["portClass"] == "xxvgige" ||
        intentConfig["portClass"] == "terabite" || intentConfig["portClass"] == "lgige" )){
            if (intentConfig["pae802_1x-PaePortSpecifics"]){
                delete intentConfig["pae802_1x-PaePortSpecifics"];
            }
            if (intentConfig["pae802_1x-PaePortAuthenticatorSpecifics"]){
                delete intentConfig["pae802_1x-PaePortAuthenticatorSpecifics"];
            }
        }
        if(!(( intentConfig["specificCardType"] != "mda_a2_10gb_xfp" && intentConfig["specificCardType"] != "mda_a2_10gb_xfp"
        && intentConfig["portCategory"] == "ethernet" ) || intentConfig["portCategory"] == "dslPort" ||
        ( intentConfig["portCategory"] == "wdmPort" && intentConfig["portClass"] == "xgige" ))){
            if (intentConfig["ethernetequipment-Dot3Oam"]){
                delete intentConfig["ethernetequipment-Dot3Oam"];
            }
        }
        if( !(intentConfig["portClass"] == "faste" || intentConfig["portClass"] == "gige" || intentConfig["portClass"] == "xgige" ||
        intentConfig["portClass"] == "variableEthernet" || intentConfig["portClass"] == "cgige" || intentConfig["portClass"] == "cdgige" ||
        intentConfig["portClass"] == "vsme" || intentConfig["portClass"] == "xlgige" || intentConfig["portClass"] == "xlcgige" ||
        intentConfig["portClass"] == "2xgige" || intentConfig["portClass"] == "xxvgige" || intentConfig["portClass"] == "lgige" ||
        intentConfig["portClass"] == "terabite" || intentConfig["portClass"] == "tsp" || intentConfig["portClass"] == "cpri3" ||
        intentConfig["portClass"] == "cpri5" || intentConfig["portClass"] == "cpri6" || intentConfig["portClass"] == "cpri7" ||
        intentConfig["portClass"] == "cpri8" || intentConfig["portClass"] == "cpri10" || intentConfig["portClass"] == "obsai4" ||
        intentConfig["portClass"] == "obsai8" || ( ( intentConfig["specificCardType"] == "mda_a2_10gb_xfp" ||
        intentConfig["specificCardType"] == "mda_p2_10gb_xfp" ) && intentConfig["portClass"] == "virtualPort" )) ){
            if (intentConfig["ethernetequipment-EthernetPortSpecifics"]){
                delete intentConfig["ethernetequipment-EthernetPortSpecifics"];
            }
        }
        if ( !(intentConfig["portClass"] == "faste" || intentConfig["portClass"] == "gige" || intentConfig["portClass"] == "xgige" ||
        intentConfig["portClass"] == "xxvgige" || intentConfig["portClass"] == "variableEthernet" || intentConfig["portClass"] == "cdgige" ||
        intentConfig["portClass"] == "xlgige" || intentConfig["portClass"] == "xlcgige" || intentConfig["portClass"] == "terabite" ||
        intentConfig["portClass"] == "lgige" || intentConfig["portClass"] == "tsp" || intentConfig["portClass"] == "cpri3" ||
        intentConfig["portClass"] == "cpri5" || intentConfig["portClass"] == "cpri6" || intentConfig["portClass"] == "cpri7" ||
        intentConfig["portClass"] == "cpri8" || intentConfig["portClass"] == "cpri10" || intentConfig["portClass"] == "obsai4" ||
        intentConfig["portClass"] == "obsai8" || ( intentConfig["portClass"] == "cgige" &&
        intentConfig["cardSubType"] != "pss_aluWdm260scx2OTU4Card" ) ) ){
            if (intentConfig["lldp-LLDPNearestNonTpmrPortConfiguration"]){
                delete intentConfig["lldp-LLDPNearestNonTpmrPortConfiguration"];
            }
            if (intentConfig["lldp-LLDPNearestCustomerPortConfiguration"]){
                delete intentConfig["lldp-LLDPNearestCustomerPortConfiguration"];
            }
        }
        if( !(intentConfig["portClass"] == "faste" || intentConfig["portClass"] == "gige" || intentConfig["portClass"] == "xgige" ||
        intentConfig["portClass"] == "variableEthernet" || intentConfig["portClass"] == "cgige" || intentConfig["portClass"] == "cdgige" ||
        intentConfig["portClass"] == "xlgige" || intentConfig["portClass"] == "xlcgige" || intentConfig["portClass"] == "xxvgige" ||
        intentConfig["portClass"] == "terabite" || intentConfig["portClass"] == "lgige" || intentConfig["portClass"] == "tsp" ||
        intentConfig["portClass"] == "cpri3" || intentConfig["portClass"] == "cpri5" || intentConfig["portClass"] == "cpri6" ||
        intentConfig["portClass"] == "cpri7" || intentConfig["portClass"] == "cpri8" || intentConfig["portClass"] == "cpri10" ||
        intentConfig["portClass"] == "obsai4" || intentConfig["portClass"] == "obsai8" ) ){
            if (intentConfig["lldp-LLDPNearestBridgePortConfiguration"]){
                delete intentConfig["lldp-LLDPNearestBridgePortConfiguration"];
            }
        }

        if( !(intentConfig["specificCardType"] == "mda_m1_10gb_dwdm_tun" || intentConfig["specificCardType"] == "mda_imm1_oc768_tun" ||
        intentConfig["specificCardType"] == "mda_imm1_40gb_xp_tun" || intentConfig["specificCardType"] == "mda_imm_p1_100g_tun" ||
        intentConfig["specificCardType"] == "mda_imm_p1_100g_tun_b" || intentConfig["specificCardType"] == "mda_me10_10gb_sfp_plus" ||
        intentConfig["specificCardType"] == "mda_me1_100gb_cfp2" || intentConfig["specificCardType"] == "mda_me6_10gb_sfp_plus" ||
        intentConfig["cardSubType"] == "pss_aluWdm260scx2OTU4Card" || intentConfig["cardSubType"] == "pss_aluWdm130scx10Card" ||
        intentConfig["specificCardType"] == "mda_x2_100g_tun" || intentConfig["specificCardType"] == "mda_me1_100gb_cfp2" ||
        intentConfig["specificCardType"] == "mda_x4_100g_cfp2" || intentConfig["specificCardType"] == "mda_me3_200gb_cfp2_dco" ||
        intentConfig["specificCardType"] == "mda_x6_200g_cfp2_dco" || intentConfig["specificCardType"] == "mdas_ms6_200gb_cfp2_dco" ||
        intentConfig["specificCardType"] == "mdas_ms3_200gb_cfp2_dco" || intentConfig["specificCardType"] == "mda_maxp1_100gb_cfp2")){
            if (intentConfig["ethernetequipment-OtuInterface"]){
                delete intentConfig["ethernetequipment-OtuInterface"];
            }
        }

        if(!( intentConfig["specificCardType"] == "mda_m1_10gb_dwdm_tun" || intentConfig["specificCardType"] == "mda_imm1_oc768_tun" ||
        intentConfig["specificCardType"] == "mda_imm12_10gb_sf" || intentConfig["specificCardType"] == "mda_imm_p6_10g_sfp" ||
        intentConfig["specificCardType"] == "mda_imm_p10_10g_sfp" || intentConfig["specificCardType"] == "mda_cx20_10g_sfp" ||
        intentConfig["specificCardType"] == "mda_x40_10g_sfp" || intentConfig["specificCardType"] == "mda_imm40_10gb_sfp" ||
        intentConfig["specificCardType"] == "mda_imm1_40gb_xp_tun" || intentConfig["specificCardType"] == "mda_m2_10gb_xp_xfp_wt" ||
        intentConfig["specificCardType"] == "mda_m4_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_ma4_10gb_sfp_plus" ||
        intentConfig["specificCardType"] == "mda_maxp10_10gb_sfp_plus" || intentConfig["specificCardType"] == "mda_maxp10_10_1_gb_msec_sfp_plus" ||
        intentConfig["specificCardType"] == "mda_maxp1_100gb_cfp" || intentConfig["specificCardType"] == "mda_maxp1_100gb_cfp2" ||
        intentConfig["specificCardType"] == "mda_maxp1_100gb_cfp4" || intentConfig["specificCardType"] == "mda_m2_10gb_xp_xfp" ||
        intentConfig["specificCardType"] == "mda_m1_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_m1_10gb_hs_xfp_b" ||
        intentConfig["specificCardType"] == "mda_m1_10gb_xfp" || intentConfig["specificCardType"] == "mda_m2_10gb_xfp" ||
        intentConfig["specificCardType"] == "mda_m10_1gb_plus_1_10gb" || intentConfig["specificCardType"] == "mda_imm4_10gb_xp_xfp" ||
        intentConfig["specificCardType"] == "mda_imm5_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_imm2_10gb_xp_xfp" ||
        intentConfig["specificCardType"] == "mda_icm2_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_m2_oc192_xp_xfp" ||
        intentConfig["specificCardType"] == "mda_imm_p1_100g_tun" || intentConfig["specificCardType"] == "mda_imm_p1_100g_tun_b" ||
        intentConfig["specificCardType"] == "mda_me10_10gb_sfp_plus" || intentConfig["specificCardType"] == "mda_me6_10gb_sfp_plus" ||
        intentConfig["specificCardType"] == "mda_x2_100g_tun" || intentConfig["specificCardType"] == "mda_me1_100gb_cfp2" ||
        intentConfig["specificCardType"] == "mda_x4_100g_cfp2" || intentConfig["specificCardType"] == "mda_me12_10gb_1gb_sfp_plus" ||
        intentConfig["specificCardType"] == "mda_me8_10gb_25gb_sfp_plus_28" || intentConfig["specificCardType"] == "mda_maxp1_100gb_cfp2" ||
        (( intentConfig["specificCardType"] == "mda_a2_10gb_xfp" || intentConfig["specificCardType"] == "mda_p2_10gb_xfp" ) && intentConfig["portCategory"] == "ethernet") ||
        intentConfig["specificCardType"] == "mda_imm48_sfp_2_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m10_10g_sfp_plus" ||
        intentConfig["specificCardType"] == "mda_m6_10g_sfp_plus_1_100g_cfp4" || intentConfig["specificCardType"] == "mda_m6_10g_sfp_plus_1_100g_qsfp28" ||
        intentConfig["specificCardType"] == "mda_m6_10g_sfp_plus_4_25g_sfp28" || intentConfig["specificCardType"] == "mda_m4_10g_sfp_plus_1_100g_cfp2" ||
        intentConfig["specificCardType"] == "mda_m48_10g_sfp_plus_6_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m24_sfp_plus_8_sfp28_2_qsfp28" ||
        intentConfig["specificCardType"] == "mda_m14_10g_sfp_plus_plus_4_1g_tx" || ( intentConfig["specificCardType"] == "mda_esat" && intentConfig["portClass"] == "xlcgige" ) ||
        ( intentConfig["specificCardType"] == "mda_m4_1g_tx_plus_20_1g_sfp_plus_6_10g_sfp_plus" && intentConfig["portClass"] == "xlcgige" ) ||
        intentConfig["specificCardType"] == "mda_cx2_100g_cfp" || intentConfig["specificCardType"] == "mda_imm_p1_100g_cfp" ||
        intentConfig["specificCardType"] == "mda_m10_1g_sfp_plus_2_10g_sfp_plus" || ( intentConfig["specificCardType"] == "mda_maxp6_10gb_sfp_1_40gb_qsfp" &&
        intentConfig["portClass"] == "xgige" ) || intentConfig["specificCardType"] == "mda_x40_10g_sfp_ptp" || intentConfig["specificCardType"] == "mda_m4_10g_sfp_plus_1_100g_cfp2" )){
            if (intentConfig["ethernetequipment-PortDwdmConfig"]){
                delete intentConfig["ethernetequipment-PortDwdmConfig"];
            }
        }

        if( !(intentConfig["specificCardType"] == "mda_imm_p1_100g_tun" || intentConfig["specificCardType"] == "mda_imm_p1_100g_tun_b" ||
        intentConfig["cardSubType"] == "pss_aluWdm260scx2OTU4Card" || intentConfig["cardSubType"] == "pss_aluWdm130scx10Card" ||
        intentConfig["specificCardType"] == "mda_x2_100g_tun" || intentConfig["specificCardType"] == "mda_me1_100gb_cfp2" ||
        intentConfig["specificCardType"] == "mda_x4_100g_cfp2" || intentConfig["specificCardType"] == "mda_maxp1_100gb_cfp2" ||
        intentConfig["specificCardType"] == "mda_cx2_100g_cfp" || intentConfig["specificCardType"] == "mda_imm_p1_100g_cfp" ||
        intentConfig["specificCardType"] == "mda_m4_10g_sfp_plus_1_100g_cfp2" || intentConfig["specificCardType"] == "mda_maxp1_100gb_cfp")){
            if (intentConfig["ethernetequipment-CoherentOpticalCfg"]){
                delete intentConfig["ethernetequipment-CoherentOpticalCfg"];
            }
        }

        if( !( intentConfig["portClass"] == "sonet" || ( intentConfig["specificCardType"] == "mda_m1_xgige" ||
        intentConfig["specificCardType"] == "mda_m20_xgige_vsr" || intentConfig["specificCardType"] == "mda_m1_10gb_xp_xfp" ||
        intentConfig["specificCardType"] == "mda_m2_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_m4_10gb_xp_xfp" ||
        intentConfig["specificCardType"] == "mda_ma4_10gb_sfp_plus" || intentConfig["specificCardType"] == "mda_maxp10_10gb_sfp_plus" ||
        intentConfig["specificCardType"] == "mda_maxp10_10_1_gb_msec_sfp_plus" || intentConfig["specificCardType"] == "mda_ma2_10gb_sfp_12_1gb_sfp" ||
        intentConfig["specificCardType"] == "mda_imm5_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_imm4_10gb_xp_xfp" ||
        intentConfig["specificCardType"] == "mda_imm2_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_m1_10gb_dwdm_tun" ||
        intentConfig["specificCardType"] == "mda_icm2_10gb_xp_xfp" || intentConfig["specificCardType"] == "mda_imm1_100gb_cfp" ||
        intentConfig["specificCardType"] == "mda_imm12_10gb_sf" || intentConfig["specificCardType"] == "mda_p10_1gb_p1_10gb_xmda_sfp_sar18" ||
        intentConfig["specificCardType"] == "mda_cx20_10g_sfp" || intentConfig["specificCardType"] == "mda_x40_10g_sfp" ||
        intentConfig["specificCardType"] == "mda_imm_p6_10g_sfp" || intentConfig["specificCardType"] == "mda_imm_p10_10g_sfp" ||
        intentConfig["specificCardType"] == "mda_imm_p20_1gb_sfp" || intentConfig["specificCardType"] == "mda_m2_10gb_xp_xfp_wt" ||
        intentConfig["specificCardType"] == "mda_m12_1gb_plus_2_10gb_xp" || intentConfig["specificCardType"] == "mda_imm40_10gb_sfp" ||
        intentConfig["specificCardType"] == "mda_maxp6_10gb_sfp_1_40gb_qsfp" || intentConfig["specificCardType"] == "mda_me10_10gb_sfp_plus" ||
        intentConfig["specificCardType"] == "mda_me6_10gb_sfp_plus" || intentConfig["specificCardType"] == "mda_me12_10gb_1gb_sfp_plus" ||
        intentConfig["specificCardType"] == "mda_me8_10gb_25gb_sfp_plus_28" || intentConfig["specificCardType"] == "mdas_mse_24_200g_sfpdd" ||
        intentConfig["specificCardType"] == "xma_x2_s18_800g_qsfpdd" || intentConfig["specificCardType"] == "mdas_mse6_400g_cfp2_dco" ||
        intentConfig["specificCardType"] == "mdas_mse14_800g_plus_4_400g" || intentConfig["specificCardType"] == "mdas_mse6_800g_qsfpdd"  ||
        (( intentConfig["specificCardType"] == "mda_a2_10gb_xfp" || intentConfig["specificCardType"] == "mda_p2_10gb_xfp" ) &&
        intentConfig["portClass"] != "virtualPort" ) || intentConfig["specificCardType"] == "mda_p10_1gb_p1_10gb_xmda_sfp_sar18_v2" ||
        (( intentConfig["specificCardType"] == "mda_a6_eth_10g" || intentConfig["specificCardType"] == "mda_p4_eth" ||
        intentConfig["specificCardType"] == "mda_i7_mix_eth" || intentConfig["specificCardType"] == "mda_a6_eth_10g_e" ) &&
        intentConfig["portClass"] != "variableEthernet" ) || intentConfig["specificCardType"] == "mda_imm48_sfp_2_100g_qsfp28" ||
        intentConfig["specificCardType"] == "mda_imm36_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m6_10g_sfp_plus_1_100g_qsfp28" ||
        intentConfig["specificCardType"] == "mda_m10_10g_sfp_plus" || intentConfig["specificCardType"] == "mda_m4_10g_sfp_plus_1_100g_cfp2" ||
        intentConfig["specificCardType"] == "mda_m24_sfp_plus_8_sfp28_2_qsfp28" || intentConfig["specificCardType"] == "mda_m14_10g_sfp_plus_plus_4_1g_tx" ||
        intentConfig["specificCardType"] == "mda_m12_sfp28_plus_2_qsfp28" || intentConfig["specificCardType"] == "mda_m2_qsfpdd_plus_2_qsfp28_plus_24_sfp28" ||
        intentConfig["specificCardType"] == "mda_m48_10g_sfp_plus_6_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m32_qsfp28_plus_4_qsfpdd" ||
        intentConfig["specificCardType"] == "mda_m6_qsfpdd_plus_48_sfp56" || intentConfig["specificCardType"] == "mda_m4_1g_tx_plus_20_1g_sfp_plus_6_10g_sfp_plus" ||
        intentConfig["specificCardType"] == "mda_m18_25g_sfp28" || intentConfig["specificCardType"] == "mda_m1_400g_qsfpdd_plus_1_100g_qsfp28" ||
        intentConfig["specificCardType"] == "mda_m5_100g_qsfp28" || intentConfig["specificCardType"] == "mda_m2_cfp2_dco" ||
        intentConfig["specificCardType"] == "mda_m20_10g_sfp_plus" || intentConfig["specificCardType"] == "mda_m10_50g_sfp56" ||
        intentConfig["specificCardType"] == "mda_m46_10g_sfp_plus" || intentConfig["specificCardType"] == "mda_m32_1g_csfp" ||
        intentConfig["specificCardType"] == "mda_m80_1g_csfp" )) ){

            if (!(( intentConfig["specificCardType"] == "card_mpr_9500_p2stm" ||
                        intentConfig["specificCardType"] == "card_mpr_9500_p2stmchan" ) && ( intentConfig["portUsage"] == "sfpe" || intentConfig["portUsage"] == "sfpo" ))){
                if (intentConfig["sonetequipment-SonetPortSpecifics"]){
                    delete intentConfig["sonetequipment-SonetPortSpecifics"];
                }
            }
            if (intentConfig["sonetequipment-SonetPortOverheadSpecifics"]){
                delete intentConfig["sonetequipment-SonetPortOverheadSpecifics"];
            }
            if (intentConfig["sonetequipment-SonetPortMonitorSpecifics"]){
                delete intentConfig["sonetequipment-SonetPortMonitorSpecifics"];
            }
        }
        if (!(intentConfig["portClass"] == "faste" || intentConfig["portClass"] == "gige" || intentConfig["portClass"] == "xgige" ||
        intentConfig["portClass"] == "variableEthernet" || intentConfig["portClass"] == "cgige" || intentConfig["portClass"] == "cdgige" ||
        intentConfig["portClass"] == "vsme" || intentConfig["portClass"] == "xlgige" || intentConfig["portClass"] == "xlcgige" ||
        intentConfig["portClass"] == "2xgige" || intentConfig["portClass"] == "xxvgige" || intentConfig["portClass"] == "lgige" ) ){
            if (intentConfig["ethernetequipment-EthernetStormControl"]) {
                delete intentConfig["ethernetequipment-EthernetStormControl"];
            }
        }
    }
}