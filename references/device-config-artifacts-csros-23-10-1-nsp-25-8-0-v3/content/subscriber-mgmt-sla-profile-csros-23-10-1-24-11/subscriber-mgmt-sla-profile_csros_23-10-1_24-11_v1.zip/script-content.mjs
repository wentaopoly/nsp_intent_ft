/********************************************************************************
 * DEVICE-SPECIFIC INTENT-TYPE USED FOR NSP DEVICE CONFIGURATION (ICM)
 *   Vendor: Nokia
 *   Device families: 7750 SR, 7450 ESS, 7950 XRS, 7705 SAR, 7250 IXR
 *   Device version: 23.10.R1
 *
 * (c) 2025 by Nokia
 ********************************************************************************/

import { IntentHandlerBase }  from 'common/IntentHandlerBase.mjs';
import { NSP }  from 'common/NSP.mjs';

class IntentHandler extends (IntentHandlerBase) {
  constructor() {
    super();
    this.greenFieldObjectFullName = "SLA Profile:$displayedName";
    this.greenFieldFDN = "SLA Profile";
    this.brownFieldObjectFullName = "network:$systemAddress:SLA Profile:$displayedName";
    this.isPolicyIntent = true;
    this.initialPropertyName = "slaprofile-Policy";
    this.uniqueIdentifier = "displayedName";
    NSP.checkRelease(24, 11);
  }

  //overwrite methods
  transformPayloadGreenField(payload, neId, isAudit) {
    if (!isAudit) {
      if (!payload["configInfo"]["slaprofile.Policy"]["creditControlPolicyPointer"]) {
        payload["configInfo"]["slaprofile.Policy"]["creditControlPolicyPointer"] = '';
      }
      if (!payload["configInfo"]["slaprofile.Policy"]["ingressQosPolicyObjectPointer"]) {
        payload["configInfo"]["slaprofile.Policy"]["ingressQosPolicyObjectPointer"] = "Access Ingress:1";
      }
      if (!payload["configInfo"]["slaprofile.Policy"]["egressQosPolicyObjectPointer"]) {
        payload["configInfo"]["slaprofile.Policy"]["egressQosPolicyObjectPointer"] = "Access Egress:1";
      }
      if (!payload["configInfo"]["slaprofile.Policy"]["schedulerPolicyObjectPointer"]) {
        payload["configInfo"]["slaprofile.Policy"]["schedulerPolicyObjectPointer"] = '';
      }
      if (!payload["configInfo"]["slaprofile.Policy"]["ingressIpFilterPointer"]) {
        payload["configInfo"]["slaprofile.Policy"]["ingressIpFilterPointer"] = '';
      }
      if (!payload["configInfo"]["slaprofile.Policy"]["egressIpFilterPointer"]) {
        payload["configInfo"]["slaprofile.Policy"]["egressIpFilterPointer"] = '';
      }
      if (!payload["configInfo"]["slaprofile.Policy"]["oneTimeHttpRedirectFilterPointer"]) {
        payload["configInfo"]["slaprofile.Policy"]["oneTimeHttpRedirectFilterPointer"] = '';
      }
      if (!payload["configInfo"]["slaprofile.Policy"]["ingressIpv6FilterPointer"]) {
        payload["configInfo"]["slaprofile.Policy"]["ingressIpv6FilterPointer"] = '';
      }
      if (!payload["configInfo"]["slaprofile.Policy"]["egressIpv6FilterPointer"]) {
        payload["configInfo"]["slaprofile.Policy"]["egressIpv6FilterPointer"] = '';
      }
      if (!payload["configInfo"]["slaprofile.Policy"]["categoryMapPointer"]) {
        payload["configInfo"]["slaprofile.Policy"]["categoryMapPointer"] = '';
      }
      if (payload["configInfo"]["slaprofile.Policy"]["ingressReportRateType"]!="namedScheduler"){
        payload["configInfo"]["slaprofile.Policy"]["ingressReportRateScheduler"] = '';
      }
      if (payload["configInfo"]["slaprofile.Policy"]["egressReportRateType"]!="namedScheduler"){
        payload["configInfo"]["slaprofile.Policy"]["egressReportRateScheduler"] = '';
      }
      if (payload["configInfo"]["slaprofile.Policy"]["children-Set"] && payload["configInfo"]["slaprofile.Policy"]["children-Set"]["slaprofile.IngressPolicerOverride"]) {
        for (var index in payload["configInfo"]["slaprofile.Policy"]["children-Set"]["slaprofile.IngressPolicerOverride"]) {
          var ingressPolicerOverrideConfig = payload["configInfo"]["slaprofile.Policy"]["children-Set"]["slaprofile.IngressPolicerOverride"][index];

          if (!ingressPolicerOverrideConfig["accessPolicyId"]) {
            ingressPolicerOverrideConfig["accessPolicyId"] = payload["configInfo"]["slaprofile.Policy"]["ingressQosPolicyObjectPointer"].split("Access Ingress:")[1];
          }

          payload["configInfo"]["slaprofile.Policy"]["children-Set"]["slaprofile.IngressPolicerOverride"][index] = ingressPolicerOverrideConfig;
        }
      }
      if (payload["configInfo"]["slaprofile.Policy"]["children-Set"] && payload["configInfo"]["slaprofile.Policy"]["children-Set"]["slaprofile.EgressPolicerOverride"]) {
        for (var index in payload["configInfo"]["slaprofile.Policy"]["children-Set"]["slaprofile.EgressPolicerOverride"]) {
          var egressPolicerOverrideConfig = payload["configInfo"]["slaprofile.Policy"]["children-Set"]["slaprofile.EgressPolicerOverride"][index];

          if (!egressPolicerOverrideConfig["accessPolicyId"]) {
            egressPolicerOverrideConfig["accessPolicyId"] = payload["configInfo"]["slaprofile.Policy"]["egressQosPolicyObjectPointer"].split("Access Egress:")[1];
          }

          payload["configInfo"]["slaprofile.Policy"]["children-Set"]["slaprofile.EgressPolicerOverride"][index] = egressPolicerOverrideConfig;
        }
      }
      if (payload["configInfo"]["slaprofile.Policy"]["children-Set"] && payload["configInfo"]["slaprofile.Policy"]["children-Set"]["slaprofile.EgressAccessPolicyQueueOverride"]) {
        for (var index in payload["configInfo"]["slaprofile.Policy"]["children-Set"]["slaprofile.EgressAccessPolicyQueueOverride"]) {
          var accessEgressQueueConfig = payload["configInfo"]["slaprofile.Policy"]["children-Set"]["slaprofile.EgressAccessPolicyQueueOverride"][index];

          if (!accessEgressQueueConfig["hsSlopePolicyPointer"]) {
            accessEgressQueueConfig["hsSlopePolicyPointer"] = '';
          }
          
          payload["configInfo"]["slaprofile.Policy"]["children-Set"]["slaprofile.EgressAccessPolicyQueueOverride"][index] = accessEgressQueueConfig;
        }
      }
      if ( payload["configInfo"]["slaprofile.Policy"]["schedulerPolicyObjectPointer"] && payload["configInfo"]["slaprofile.Policy"]["children-Set"] &&
           payload["configInfo"]["slaprofile.Policy"]["children-Set"]["slaprofile.EgressSchedulerOverride"]) {
        for (var index in payload["configInfo"]["slaprofile.Policy"]["children-Set"]["slaprofile.EgressSchedulerOverride"]) {
          var egressSchedulerOverrideConfig = payload["configInfo"]["slaprofile.Policy"]["children-Set"]["slaprofile.EgressSchedulerOverride"][index];
          var tierId = this.getSchedulerTier(neId, payload["configInfo"]["slaprofile.Policy"]["schedulerPolicyObjectPointer"].split('Scheduler:')[1],egressSchedulerOverrideConfig["schedulerName"]);
          if (tierId !='' && !egressSchedulerOverrideConfig["schedulerPointer"] ) {
            egressSchedulerOverrideConfig["schedulerPointer"] = 'network:'+neId+':'+payload["configInfo"]["slaprofile.Policy"]["schedulerPolicyObjectPointer"]+':'+tierId+'-virtual-scheduler-'+egressSchedulerOverrideConfig["schedulerName"];
          }

          payload["configInfo"]["slaprofile.Policy"]["children-Set"]["slaprofile.EgressSchedulerOverride"][index] = egressSchedulerOverrideConfig;
        }
     }
      
    }

    return payload;
  }

  getSchedulerTier(neId,schedulerPolicyName,schedulerName) {
    let className = "vs.Entry", attribute = "tier";
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": [
            {
              "name": "containingPolicyDisplayedName",
              "value": schedulerPolicyName
            },
            {
              "name": "siteId",
              "value": neId
            },
            {
             "name": "displayedName",
             "value": schedulerName
            }
          ]
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    let ret=this.getData(neId, searchObject, className, attribute);
    const values = [...ret.values()];
    return values.length > 0 ?'tier-'+(values[0].split('tier')[1]):'';
  }

  transformTargetValueGreenField(xpath, targetValue, targetKey, neId, isAudit) {
    if (xpath == "creditControlPolicyPointer") {
      targetValue = 'creditControl:' + targetValue;
    }
    if (xpath == "ingressQosPolicyObjectPointer") {
      targetValue = 'Access Ingress:' + targetValue;
    }
    if (xpath == "egressQosPolicyObjectPointer") {
      targetValue = 'Access Egress:' + targetValue;
    }
    if (xpath == "schedulerPolicyObjectPointer") {
      targetValue = 'Scheduler:' + targetValue;
    }
    if (xpath == "ingressIpFilterPointer" ||
        xpath == "egressIpFilterPointer" ||
        xpath == "oneTimeHttpRedirectFilterPointer") {
      targetValue = 'IP Filter:' + targetValue;
    }
    if (xpath == "ingressIpv6FilterPointer" ||
        xpath == "egressIpv6FilterPointer") {
      targetValue = 'IPv6 Filter:' + targetValue;
    }
    if (xpath == "categoryMapPointer") {
      targetValue = 'categoryMap:' + targetValue;
    }
    if (xpath == "slaprofile-EgressAccessPolicyQueueOverride.hsSlopePolicyPointer") {
      targetValue = 'Slope:' + targetValue;
    }
  
    return targetValue;
  }

  transformTargetValueBrownField(xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
    if (xpath == "creditControlPolicyPointer") {
      targetValue = targetValue.replace('creditControl:', '');
    }
    if (xpath == "ingressQosPolicyObjectPointer") {
      targetValue = targetValue.replace('Access Ingress:', '');
    }
    if (xpath == "egressQosPolicyObjectPointer") {
      targetValue = targetValue.replace('Access Egress:', '');
    }
    if (xpath == "schedulerPolicyObjectPointer") {
      targetValue = targetValue.replace('Scheduler:', '');
    }
    if (xpath == "ingressIpFilterPointer" ||
        xpath == "egressIpFilterPointer" ||
        xpath == "oneTimeHttpRedirectFilterPointer") {
      targetValue = targetValue.replace('IP Filter:', '');
    }
    if (xpath == "ingressIpv6FilterPointer" ||
        xpath == "egressIpv6FilterPointer") {
      targetValue = targetValue.replace('IPv6 Filter:', '');
    }
    if (xpath == "categoryMapPointer") {
      targetValue = targetValue.replace('categoryMap:', '');
    }
    if (xpath == "slaprofile-EgressAccessPolicyQueueOverride.hsSlopePolicyPointer") {
      targetValue = targetValue.replace('Slope:', '');
    }

    return targetValue;
  }  

  // WebUI suggest/picker callouts:
  suggestSlaProfile(context) {
    logger.info("suggestSlaProfile context = \n" + context);
    let className = "slaprofile.Policy", neId = this.getNeId(context), attribute = "displayedName";
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": {
            "name": "siteId",
            "value": neId
          }
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  }

  suggestCreditControlPolicy(context) {
    logger.info("suggestCreditControlPolicy context = \n" + context);
    let className = "crdtctrl.CrdtCtrlPolicy", neId = this.getNeId(context), attribute = "displayedName";
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": {
            "name": "siteId",
            "value": neId
          }
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  }

  suggestIngressQosPolicy(context) {
    logger.info("suggestIngressQosPolicy context = \n" + context);
    let className = "aingr.Policy", neId = this.getNeId(context), attribute = "id";
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": {
            "name": "siteId",
            "value": neId
          }
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  }

  suggestScheduler(context) {
    logger.info("suggestScheduler context = \n" + context);
    let className = "vs.Entry", neId = this.getNeId(context), attribute = "displayedName";
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": {
            "name": "siteId",
            "value": neId
          }
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  }

  suggestEgressQosPolicy(context) {
    logger.info("suggestEgressQosPolicy context = \n" + context);
    let className = "aengr.Policy", neId = this.getNeId(context), attribute = "id";
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": {
            "name": "siteId",
            "value": neId
          }
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  }

  suggestSchedulerPolicy(context) {
    logger.info("suggestSchedulerPolicy context = \n" + context);
    let className = "vs.Policy", neId = this.getNeId(context), attribute = "displayedName";
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": {
            "name": "siteId",
            "value": neId
          }
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  }

  suggestIpFilter(context) {
    logger.info("suggestIpFilter context = \n" + context);
    let className = "aclfilter.IpFilter", neId = this.getNeId(context), attribute = "id";
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": {
            "name": "siteId",
            "value": neId
          }
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  }

  suggestIpv6Filter(context) {
    logger.info("suggestIpv6Filter context = \n" + context);
    let className = "aclfilter.Ipv6Filter", neId = this.getNeId(context), attribute = "id";
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": {
            "name": "siteId",
            "value": neId
          }
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  }

  suggestCategoryMap(context) {
    logger.info("suggestCategoryMap context = \n" + context);
    let className = "crdtctrl.CtgryMapPolicy", neId = this.getNeId(context), attribute = "displayedName";
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": {
            "name": "siteId",
            "value": neId
          }
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  }

  suggestCategoryName(context) {
    logger.info("suggestCategoryName context = \n" + context);
    let className = "crdtctrl.Category", neId = this.getNeId(context), attribute = "displayedName";
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": {
            "name": "siteId",
            "value": neId
          }
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  }

  suggestAccessIngressQueueId(context) {
    logger.info("suggestAccessIngressQueueId context = \n" + context);
    let className = "aingr.Queue", neId = this.getNeId(context), attribute = "id", 
    accessIngressPolicyId = context.getInputValues()["arguments"]["__parent"]["slaprofile-Policy"]["ingressQosPolicyObjectPointer"];
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": [
            {
              "name": "containingPolicyId",
              "value": accessIngressPolicyId
            },
            {
              "name": "siteId",
              "value": neId
            }
          ]
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  } 

  suggestAccessEgressQueueId(context) {
    logger.info("suggestAccessEgressQueueId context = \n" + context);
    let className = "aengr.Queue", neId = this.getNeId(context), attribute = "id", 
    accessEgressPolicyId = context.getInputValues()["arguments"]["__parent"]["slaprofile-Policy"]["egressQosPolicyObjectPointer"];
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": [
            {
              "name": "containingPolicyId",
              "value": accessEgressPolicyId
            },
            {
              "name": "siteId",
              "value": neId
            }
          ]
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  }

  suggestHsSlopePolicyPointer(context) {
    logger.info("suggestHsSlopePolicyPointer context = \n" + context);
    let className = "slope.Policy", neId = this.getNeId(context), attribute = "displayedName";
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": {
            "name": "siteId",
            "value": neId
          }
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  }

  suggestIngressPolicerId(context) {
    logger.info("suggestIngressPolicerId context = \n" + context);
    let className = "aingr.Policer", neId = this.getNeId(context), attribute = "id", 
    accessIngressPolicyId = context.getInputValues()["arguments"]["__parent"]["slaprofile-Policy"]["ingressQosPolicyObjectPointer"];
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": [
            {
              "name": "containingPolicyId",
              "value": accessIngressPolicyId
            },
            {
              "name": "siteId",
              "value": neId
            }
          ]
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  }

  suggestEgressPolicerId(context) {
    logger.info("suggestEgressPolicerId context = \n" + context);
    let className = "aengr.Policer", neId = this.getNeId(context), attribute = "id", 
    accessEgressPolicyId = context.getInputValues()["arguments"]["__parent"]["slaprofile-Policy"]["egressQosPolicyObjectPointer"];
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": [
            {
              "name": "containingPolicyId",
              "value": accessEgressPolicyId
            },
            {
              "name": "siteId",
              "value": neId
            }
          ]
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  } 

  suggestSchedulerName(context) {
    logger.info("suggestSchedulerName context = \n" + context);
    let className = "vs.Entry", neId = this.getNeId(context), attribute = "displayedName", 
    schedulerPolicyName = context.getInputValues()["arguments"]["__parent"]["slaprofile-Policy"]["schedulerPolicyObjectPointer"];
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": [
            {
              "name": "containingPolicyDisplayedName",
              "value": schedulerPolicyName
            },
            {
              "name": "siteId",
              "value": neId
            }
          ]
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  } 

  suggestHsWrrGrpId(context) {
    logger.info("suggestHsWrrGrpId context = \n" + context);
    let className = "aengr.HsWrrGroup", neId = this.getNeId(context), attribute = "id", 
    accessEgressPolicyId = context.getInputValues()["arguments"]["__parent"]["slaprofile-Policy"]["egressQosPolicyObjectPointer"];
    let searchObject = {
      "fullClassName": className,
      "filter": {
        "and": {
          "equal": [
            {
              "name": "containingPolicyId",
              "value": accessEgressPolicyId
            },
            {
              "name": "siteId",
              "value": neId
            }
          ]
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          attribute
        ]
      }
    };
    return this.getData(neId, searchObject, className, attribute);
  }
}

new IntentHandler();
