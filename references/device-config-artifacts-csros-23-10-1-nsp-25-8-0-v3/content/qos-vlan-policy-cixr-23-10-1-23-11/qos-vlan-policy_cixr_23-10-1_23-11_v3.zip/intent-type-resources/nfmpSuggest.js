function NfmpSuggest() {
   this.getData = function (searchObjectJson, className, type) {
        let nfmpFwk = new NfmpFwk();
        let ret = [];
        let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        let finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    ret.push(value[type]);
                })
            }
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
   }

    this.getQueueMgmtPolicy = function (neId) {
        var searchObjectJson = {
            "fullClassName": "ixrqos.QueueMgmtPolicy",
             "filter": {
                "equal": {
                   "name": "siteId",
                   "value": neId
                }
             },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObjectJson, "ixrqos.QueueMgmtPolicy", "displayedName");
    }

    this.getDisplayedName = function (neId) {
        let className = "ixrqos.VlanQosPolicy";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObject, className, "displayedName")
    }
}