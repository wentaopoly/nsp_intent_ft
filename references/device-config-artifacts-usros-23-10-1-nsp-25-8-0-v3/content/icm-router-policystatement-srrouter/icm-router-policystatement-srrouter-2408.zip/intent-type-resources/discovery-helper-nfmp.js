var RuntimeException = Java.type('java.lang.RuntimeException');

load({
    script: resourceProvider.getResource("nfmp-fwk.js"),
    name: "NfmpFwk"
});
load({
    script: resourceProvider.getResource('parse-target.js'),
    name: 'ParseTarget'
});
load({
    script: resourceProvider.getResource("util-fwk.js"),
    name: "utilities"
});


function NfmpDiscoveryHelper() {

    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();
    this.getDeviceConfiguration = function(target, initialPropertyName) {

        var neId = parseTarget.getNeIdFromTarget(target);
        var policyStatementName = parseTarget.getUniqueIdentifier(target);
        var searchPayLoad = this.constructSearchString(neId, policyStatementName);
        var searchResponse = nfmpFwk.find(neId, searchPayLoad);
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
          if(!(searchResponse.success))
            throw new RuntimeException("Failed to get Policy info from nfm-p for Ne " + neId + " and Policy Name: " + policyStatementName);
          if(JSON.parse(searchResponse["response"]).length === 0)
            throw new RuntimeException("There is no Policy Statement with Name:" + policyStatementName );
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse[0];

    }

    this.extractDeviceConfig = function(defaultTargetData, deviceConfig, initialPropertyName) {
        var parsedDefaultTargetData = JSON.parse(defaultTargetData);
        var policyconfig = deviceConfig['properties'];
        if (null !== policyconfig) {
            var deviceDefaultAction = this.transformDeviceValue("policy-statement.default-action.action-type", policyconfig['action']);
            if(deviceDefaultAction === "none")
            {
                delete parsedDefaultTargetData['policy-statement']['default-action']['action-type'];
                delete parsedDefaultTargetData['policy-statement']['enableDefaultAction'];
            }
            else
            {
                parsedDefaultTargetData['policy-statement']['default-action']['action-type'] = deviceDefaultAction;
                parsedDefaultTargetData['policy-statement']['enableDefaultAction'] = true;
            }
        }
        var childrenConfig = deviceConfig["children"];
        if (childrenConfig && childrenConfig.length !== 0) {

            var statementEntryData = parsedDefaultTargetData['policy-statement']['entry'];
            if (!Array.isArray(statementEntryData)) {
                statementEntryData = [statementEntryData];
            }
            if (statementEntryData !== null && Array.isArray(statementEntryData) && statementEntryData.length !== 0) {
                var statementEntryArray = this.extractEntryData(statementEntryData, childrenConfig);
                parsedDefaultTargetData['policy-statement']['entry'] = statementEntryArray;
            }
        }
        else
        {
            parsedDefaultTargetData['policy-statement']['entry'] = undefined;
        }
        this.clearEmpties(parsedDefaultTargetData);
        return parsedDefaultTargetData;
    }

    this.extractPolicyProperties = function(defaultTargetData, policyConfig) 
    {
        var keys = Object.keys(defaultTargetData);
        for (var i = 0; i < keys.length; i++) {
            var targetKey = keys[i];
            var targetObj = defaultTargetData[targetKey];

            if (targetObj !== null && typeof targetObj === 'object') {
                var mappings = modelDeviceMapping.getMapping("policy");
                this.traverseAndUpdateConfig(targetKey, targetObj, policyConfig, mappings);
            }
        }
        return defaultTargetData;
    }


    this.extractEntryData = function(defaultEntryData, childrenConfig) {

        var statementEntryArray = [];
        var entryDefaults = defaultEntryData[0];
        var mappings = modelDeviceMapping.getMapping("entry");
        for (var i = 0; childrenConfig && i < childrenConfig.length; i++) {
            var childConfig = childrenConfig[i];
            var childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass === 'rp.PolicyStatementEntry') {
                var entryData = JSON.parse(JSON.stringify(entryDefaults));
                this.traverseAndUpdateConfig('policy-statement.entry', entryData, childConfig['properties'], mappings);
                var entryAction = this.transformDeviceValue('policy-statement.entry.action.action-type', childConfig['properties']['action']);
                if(entryAction === "none")
                {
                    delete entryData['action'];
                }
                else
                {
                    entryData['action']['action-type'] = entryAction;
                }
                entryData['action'] = this.extractEntryAction(entryData['action'], childConfig["children"]);
                this.extractFromCriteria(entryData, childConfig["children"]);
                this.extractToCriteria(entryData['to'], childConfig["children"]);

                statementEntryArray.push(entryData);
            }
        }
        return statementEntryArray;

    }

    this.extractFromCriteria = function(defaultEntryData, childrenConfig)
    {
        var foundFrom = false;
        var defaultFromData = defaultEntryData['from'];
        for (var i = 0; childrenConfig && i < childrenConfig.length; i++) {
            var childConfig = childrenConfig[i];
            var childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass === 'rp.FromCriteria') {
                foundFrom = true;
                defaultFromData['protocol']['name'] = this.transformProtocolValue(childConfig['properties']['protocolBits']);
                defaultFromData['family'] = this.transformFamilyValue(childConfig['properties']['family']);
                defaultFromData['community']['name'] = childConfig['properties']['communityName'];
                defaultFromData['community']['community'] = undefined;
                defaultFromData['community']['expression'] = undefined;
                this.extractCommunityExpression(defaultFromData, childConfig['children']);
                this.extractFromCriteriaPrefixList(defaultFromData, childConfig['children']);
            }
        }
        if(foundFrom === false)
        {
            defaultEntryData['from'] = undefined;
        }
    }

    this.extractCommunityExpression = function(defaultFromData, childrenConfig)
    {
        for (var i = 0; childrenConfig && i < childrenConfig.length; i++) {
            var childConfig = childrenConfig[i];
            var childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass === 'rp.CommunityExpression') {
                defaultFromData['community']['expression'] = childConfig['properties']['communityExpr'];
                if(defaultFromData['community']['expression'] !== "")
                {
                    defaultFromData['community']['name'] = undefined;
                }
            }
        }
    }

    this.extractFromCriteriaPrefixList = function(defaultFromData, childrenConfig)
    {
        for (var i = 0; childrenConfig && i < childrenConfig.length; i++) {
            var childConfig = childrenConfig[i];
            var childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass === 'rp.FromCriteriaPrefixListMembers')
            {
                if(childConfig['properties']['addPrefixListMemberName'] === "")
                {
                    defaultFromData['prefix-list'] = [];
                    continue;
                }
                defaultFromData['prefix-list'] = childConfig['properties']['addPrefixListMemberName'].replace(/\"/g, "").split(" ");
            }
        }
    }

    this.extractEntryAddCommunityAction = function(defaultEntryData, childrenConfig)
    {
        for (var i = 0; childrenConfig && i < childrenConfig.length; i++) {
            var childConfig = childrenConfig[i];
            var childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass === 'rp.AddCommunityAction')
            {
                if(childConfig['properties']['addCommunityName'] === "")
                {
                    defaultEntryData['community']['add'] = [];
                    continue;
                }
                defaultEntryData['community']['add'] = childConfig['properties']['addCommunityName'].replace(/\"/g, "").split(" ");
            }
        }
    }

    this.extractToCriteria = function(defaultToData, childrenConfig)
    {
        for (var i = 0; childrenConfig && i < childrenConfig.length; i++) {
            var childConfig = childrenConfig[i];
            var childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass === 'rp.ToCriteria') {
                defaultToData['protocol']['name'] = this.transformProtocolValue(childConfig['properties']['protocolBits']);
            }
        }
    }

    this.extractEntryAction = function(entryActionData, childrenConfig)
    {
        var entryActionDefaults = entryActionData;
        for (var i = 0; childrenConfig && i < childrenConfig.length; i++) {
            var childConfig = childrenConfig[i];
            var childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass === 'rp.Action') {
                var entryActionData = JSON.parse(JSON.stringify(entryActionDefaults));
                entryActionData['local-preference'] = childConfig['properties']["localPreference"];
                if(childConfig['properties']["preference"] && childConfig['properties']["preference"] != "0" )
                {
                    entryActionData['preference'] = childConfig['properties']["preference"];
                }
                else
                {
                    entryActionData['preference'] = undefined;
                }
                entryActionData['admin-tag-policy'] = (childConfig['properties']["adminTagPolicy"]).replace("rtrAdminTagPolicy:rtr-1-ratpol-", "");
                entryActionData['create-mpls-tunnel'] = childConfig['properties']["createMplsTunnel"];
                this.extractEntryAddCommunityAction(entryActionData, childConfig["children"]);
            }
        }
        return entryActionData;
    }
    
    this.traverseAndUpdateConfig = function(objKey, obj, parsedDeviceConfig, mappings) {

        var keys = Object.keys(obj);
        for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            var value = obj[key];

            var mappedKey = objKey + "." + key;

            if (mappedKey !== "policy-statement.entry" &&
                mappedKey !== "policy-statement.entry.from" &&
                mappedKey !== "policy-statement.entry.from.protocol" &&
                mappedKey !== "policy-statement.entry.to" &&
                mappedKey !== "policy-statement.entry.to.protocol" &&
                mappedKey !== "policy-statement.entry.action"&&
                mappedKey !== "policy-statement.entry.action.community") {

                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else
                {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.getAndUpdateFromDeviceConfig = function(mappings, mappedKey, targetKey, targetObj, parsedDeviceConfig) {
        // Get the key from mapping against targetKey
        // If the mapping key is not undefined, Get the value from deviceKey
        // if the value from deviceConfig against that mapping key is not n

        var nfmpKey = mappings[mappedKey];
        var deviceValue = parsedDeviceConfig[nfmpKey];
        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);

    }
    this.constructSearchString = function(neId, name) {
        var filterExpression = "siteId='" + neId + "' AND policyStatementName='" + name + "'";
        var jsonPayLoad = {
            "fullClassName": "rp.PolicyStatement",
            "filter": {
                "filterExpression": filterExpression
            }
        };
        return jsonPayLoad;
    }

    this.transformDeviceValue = function(mappedKey, deviceValue) {
        if (deviceValue !== null) {
            switch (mappedKey) {
                case "policy-statement.entry.entry-id":
                     deviceValue = parseInt(deviceValue);
                     break;
                case "policy-statement.default-action.action-type":
                case "policy-statement.entry.action.action-type":
                    deviceValue = this.transformActionTypeValue(deviceValue);
                    break;
            }
            return deviceValue;
        }
        return deviceValue;
    }

    this.transformActionTypeValue = function(deviceValue){
        if(deviceValue == "accept")
        {
            return "accept";
        }
        else if(deviceValue == "reject")
        {
            return "reject";
        }
        else if(deviceValue == "nextEntry")
        {
            return "next-entry";
        }
        else if(deviceValue == "nextPolicy")
        {
            return "next-policy";
        }
        else
        {
            return "none";
        }
    }

    this.transformProtocolValue = function(deviceValue)
    {
        if(deviceValue)
        {
            var index = deviceValue.indexOf("none");
            if(index > -1)
            {
                deviceValue.splice(index, 1);
            }
            for (var index in deviceValue)
            {
                var protocol =deviceValue[index];
                index = deviceValue.indexOf(protocol);

                if (~index) {
                    deviceValue[index] = util.getIntentProtocolName(protocol);
                }
            }
        }
        return deviceValue;
    }

    this.transformFamilyValue = function(deviceValue)
    {
        if(deviceValue == "")
        {
            deviceValue = undefined;
        }
        if(deviceValue)
        {
            for (var index in deviceValue)
            {
                var protocol =deviceValue[index];
                var index = deviceValue.indexOf(protocol);

                if (~index) {
                    deviceValue[index] = util.getIntentFamilyName(protocol);
                }
            }
        }
        return deviceValue;
    }

    this.clearEmpties = function (o) {
        for (var k in o)
        {
            if (!o[k] || typeof o[k] !== "object")
            {
                continue
            }

            this.clearEmpties(o[k]);
            if (Object.keys(o[k]).length === 0)
            {
                delete o[k];
            }
        }
    }
}
