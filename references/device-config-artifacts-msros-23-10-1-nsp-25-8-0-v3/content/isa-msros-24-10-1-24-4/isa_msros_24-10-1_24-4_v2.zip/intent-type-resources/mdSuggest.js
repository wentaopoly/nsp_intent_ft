function MdSuggest() {
    this.getConfigurePortPolicy = function (neId) {
       const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/port-policy?fields=name`;
       return this.getSuggestData(neId, url, "nokia-conf:port-policy", "name");
    }

    this.getRadiusIsaPolicy = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/aaa/radius/isa-policy?fields=name`;
    return this.getSuggestData(neId, url, "nokia-conf:isa-policy", "name");
   }

    this.getConfigureEsaId = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/esa?fields=esa-id`;
    return this.getSuggestData(neId, url, "nokia-conf:esa", "esa-id");
   }

    this.getEsaVmId = function(neId, esaId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/esa=${esaId}/vm?fields=vm-id`;
    return this.getSuggestData(neId, url, "nokia-conf:vm", "vm-id");
   }

    this.getIsaTunnelMemberPoolName = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/isa/tunnel-member-pool?fields=name`;
    return this.getSuggestData(neId, url, "nokia-conf:tunnel-member-pool", "name");
   }

    this.getServiceOperGroupName = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/service/oper-group?fields=name`;
    return this.getSuggestData(neId, url, "nokia-conf:oper-group", "name");
   }

    this.getConfigureCardSlotNumber = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/card?fields=slot-number`;
    return this.getSuggestData(neId, url, "nokia-conf:card", "slot-number");
   }

    this.getIsaApplicationAssuranceGroupAaGroupId = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/isa/application-assurance-group?fields=aa-group-id`;
    return this.getSuggestData(neId, url, "nokia-conf:application-assurance-group", "aa-group-id");
   }

    this.getLogAccountingPolicyId = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/log/accounting-policy?fields=policy-id`;
    return this.getSuggestData(neId, url, "nokia-conf:accounting-policy", "policy-id");
   }

    this.getQosPortSchedulerPolicyName = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/qos/port-scheduler-policy?fields=name`;
    return this.getSuggestData(neId, url, "nokia-conf:port-scheduler-policy", "name");
   }

    this.getQosNetworkQueueNetworkQueuePolicy = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/nokia-conf:/configure/qos/network-queue?fields=network-queue-policy`;
    return this.getSuggestData(neId, url, "nokia-conf:network-queue", "network-queue-policy");
   }

    this.getQosSlopePolicySlopePolicyName = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/qos/slope-policy?fields=slope-policy-name`;
    return this.getSuggestData(neId, url, "nokia-conf:slope-policy", "slope-policy-name");
   }

   this.getSuggestData = function(neId, url, initialProperty, propertyName) {
      const mdcFwk = new MdcFwk();
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg[initialProperty];
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data[propertyName]).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }
}