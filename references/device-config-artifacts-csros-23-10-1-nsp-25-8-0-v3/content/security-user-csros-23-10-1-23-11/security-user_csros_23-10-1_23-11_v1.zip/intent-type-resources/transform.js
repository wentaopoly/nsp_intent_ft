function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        if(isAudit == true) {
          if(payload["configInfo"]["sitesec.LocalUser"]["ne3sPassword"]) {
            delete payload["configInfo"]["sitesec.LocalUser"]["ne3sPassword"];
          }
          if(payload["configInfo"]["sitesec.LocalUser"]["ne3sPassword2"]) {
            delete payload["configInfo"]["sitesec.LocalUser"]["ne3sPassword2"];
          }
          if(payload["configInfo"]["sitesec.LocalUser"]["nwi3Password"]) {
            delete payload["configInfo"]["sitesec.LocalUser"]["nwi3Password"];
          }
          if(payload["configInfo"]["sitesec.LocalUser"]["nwi3Password2"]) {
            delete payload["configInfo"]["sitesec.LocalUser"]["nwi3Password2"];
          }
          if(payload["configInfo"]["sitesec.LocalUser"]["linuxOldPassword"]) {
            delete payload["configInfo"]["sitesec.LocalUser"]["linuxOldPassword"];
          }
          if(payload["configInfo"]["sitesec.LocalUser"]["linuxPassword"]) {
            delete payload["configInfo"]["sitesec.LocalUser"]["linuxPassword"];
          }
          if(payload["configInfo"]["sitesec.LocalUser"]["linuxPassword2"]) {
            delete payload["configInfo"]["sitesec.LocalUser"]["linuxPassword2"];
          }
          if(payload["configInfo"]["sitesec.LocalUser"]["password"]) {
            delete payload["configInfo"]["sitesec.LocalUser"]["password"];
          }
          if(payload["configInfo"]["sitesec.LocalUser"]["password2"]) {
            delete payload["configInfo"]["sitesec.LocalUser"]["password2"];
          }
          if(payload["configInfo"]["sitesec.LocalUser"]["snmpAuthPassword"]) {
            delete payload["configInfo"]["sitesec.LocalUser"]["snmpAuthPassword"];
          }
          if(payload["configInfo"]["sitesec.LocalUser"]["snmpAuthPassword2"]) {
            delete payload["configInfo"]["sitesec.LocalUser"]["snmpAuthPassword2"];
          }
          if(payload["configInfo"]["sitesec.LocalUser"]["snmpPrivPassword"]) {
            delete payload["configInfo"]["sitesec.LocalUser"]["snmpPrivPassword"];
          }
          if(payload["configInfo"]["sitesec.LocalUser"]["snmpPrivPassword2"]) {
            delete payload["configInfo"]["sitesec.LocalUser"]["snmpPrivPassword2"];
          }
        }
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
}
