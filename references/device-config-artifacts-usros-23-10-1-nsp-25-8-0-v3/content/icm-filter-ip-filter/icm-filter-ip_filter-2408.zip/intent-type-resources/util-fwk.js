load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities()
{
    this.setErrorResult = function (result)
    {
        result.setSuccess(false);
        result.setErrorCode(100);
        result.setErrorDetail("failed To set Topology.");
        return result
    }

    this.setSuccessResult = function (result,savedTopology)
    {
        result.setSuccess(true);
        if (savedTopology !== undefined)
        {
            result.setTopology(savedTopology);
        }
        return result;
    }

    this.xml2object = function (xmlElement)
    {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        return JSON.parse(json);
    }

    this.extractInfo = function (topology, key,i)
    {
        var values;
        if (topology != null && topology.getXtraInfo() != null) {
            topology.getXtraInfo().forEach(function (extraInfo) {
                if (extraInfo.getKey() == key) {
                    var value = extraInfo.getValue();
                    values = value.split(",")

                }
            });
        }

        if (values === undefined)
            return values
        else
            return values[i];
    }

    this.reportMisaligned = function (target, result, auditReport) {
        var report = JSON.parse(result.response);
        if (!report.aligned)
        {
            for (var i = 0; i < report.misalignedAttributes.length; i++)
            {
                var attributeData = report.misalignedAttributes[i];
                if (attributeData.expected == "present")
                {
                    //misaligned object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else if (attributeData.expected == "not present")
                {
                    //undesired object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                    auditReport.addMisAlignedAttribute(misalignedAttribute);
                }

            }
        }
        return auditReport
    }

    /*
   function: getIfObjectExists
   description: returns the object for objectFullName if exists.
   */
    this.getIfObjectExists = function(className, objectFullName){

        let nfmpFwk = new NfmpFwk();
        var expectedJson = {
            "fullClassName": className,
            "filter": {
                "filterExpression": "fullName='"+objectFullName+"'"
            }
        };
        var ret = false;
        var resultFetch = nfmpFwk.post("search", expectedJson);
        var finalResponse = JSON.parse(resultFetch.response);


        if(!Array.isArray(finalResponse))
        {
            finalResponse = null;
        }

        return finalResponse;
    }

    this.editPayload = function(fdn,properties,childProperties,fullClassName,objectFullName){

        var payload  = {};
        var configInfo = {};
        configInfo["containedClassProperties"] = properties;
        configInfo["containmentInfo"] = childProperties;
        configInfo["objectClassName"] = fullClassName;
        //payload["fdn"] = fdn;
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName,
            payload["configInfo"] = configInfo;
        return payload;
    }

    /*
    function: getIpFilterId
    description: Getting the Filter id from target.
    */
    this.getIpFilterId = function(target){
        var filterId = target.split("#")[3];
        return filterId;
    };

    /*
    function: getIpFilterName
    description: Getting the Filter Name from target.
    */
    this.getIpFilterName = function(target){

        //write code here
        var filterName = target.split("#")[2];
        return filterName;

    };

    this.transformNfmpDefaultAction = function(intentDefaultAction){
        var nfmpDefaultAction="";
        switch (intentDefaultAction)
        {
            case "drop":nfmpDefaultAction="drop";
                break;
            case "accept":nfmpDefaultAction="forward";
                break;
            default:nfmpDefaultAction="drop";
        }
        return nfmpDefaultAction;
    }

    this.transformIntentDefaultAction = function(nfmpDefaultAction){
        var intentDefaultAction ="";
        switch (nfmpDefaultAction)
        {
            case "drop":intentDefaultAction="drop";
                break;
            case "forward":intentDefaultAction="accept";
                break;
            default:intentDefaultAction="drop";
        }
        return intentDefaultAction;
    }

    this.transformNfmpProtocol = function(intentProtocolValue){
        var nfmpProtocolValue="";
        switch (intentProtocolValue)
        {
            case "tcp-udp":nfmpProtocolValue="UDPTCP";
                break;
            case "icmp":nfmpProtocolValue="ICMP";
                break;
            case "igmp":nfmpProtocolValue="IGMP";
                break;
            case "ip":nfmpProtocolValue="IP";
                break;
            case "tcp":nfmpProtocolValue="TCP";
                break;
            case "egp":nfmpProtocolValue="EGP";
                break;
            case "igp":nfmpProtocolValue="IGP";
                break;
            case "udp":nfmpProtocolValue="UDP";
                break;
            case "rdp":nfmpProtocolValue="RDP";
                break;
            case "ipv6":nfmpProtocolValue="IPv6";
                break;
            case "ipv6-route":nfmpProtocolValue="IPv6Route";
                break;
            case "ipv6-frag":nfmpProtocolValue="IPv6Frag";
                break;
            case "idrp":nfmpProtocolValue="IDRP";
                break;
            case "rsvp":nfmpProtocolValue="RSVP";
                break;
            case "gre":nfmpProtocolValue="GRE";
                break;
            case "ipv6-icmp":nfmpProtocolValue="IPv6_ICMP";
                break;
            case "ipv6-no-nxt":nfmpProtocolValue="IPv6_NoNxt";
                break;
            case "ipv6-opts":nfmpProtocolValue="IPv6_Opts";
                break;
            case "iso-ip":nfmpProtocolValue="ISO_IP";
                break;
            case "eigrp":nfmpProtocolValue="EIGRP";
                break;
            case "ospf-igp":nfmpProtocolValue="OSPFIGP";
                break;
            case "ether-ip":nfmpProtocolValue="ETHERIP";
                break;
            case "encap":nfmpProtocolValue="ENCAP";
                break;
            case "pnni":nfmpProtocolValue="PNNI";
                break;
            case "pim":nfmpProtocolValue="PIM";
                break;
            case "vrrp":nfmpProtocolValue="VRRP";
                break;
            case "l2tp":nfmpProtocolValue="L2TP";
                break;
            case "stp":nfmpProtocolValue="STP";
                break;
            case "ptp":nfmpProtocolValue="PTP";
                break;
            case "isis":nfmpProtocolValue="ISIS";
                break;
            case "crtp":nfmpProtocolValue="CRTP";
                break;
            case "crudp":nfmpProtocolValue="CRUDP";
                break;
            case "sctp":nfmpProtocolValue="SCTP";
                break;
            default:nfmpProtocolValue=undefined;
        }
        return nfmpProtocolValue;
    }

    this.transformIntentProtocol = function(nfmpProtocolValue){
        var intentProtocolValue="";
        switch (nfmpProtocolValue)
        {
            case "UDPTCP":intentProtocolValue="tcp-udp";
                break;
            case "ICMP":intentProtocolValue="icmp";
                break;
            case "IGMP":intentProtocolValue="igmp";
                break;
            case "IP":intentProtocolValue="ip";
                break;
            case "TCP":intentProtocolValue="tcp";
                break;
            case "EGP":intentProtocolValue="egp";
                break;
            case "IGP":intentProtocolValue="igp";
                break;
            case "UDP":intentProtocolValue="udp";
                break;
            case "RDP":intentProtocolValue="rdp";
                break;
            case "IPv6":intentProtocolValue="ipv6";
                break;
            case "IPv6Route":intentProtocolValue="ipv6-route";
                break;
            case "IPv6Frag":intentProtocolValue="ipv6-frag";
                break;
            case "IDRP":intentProtocolValue="idrp";
                break;
            case "RSVP":intentProtocolValue="rsvp";
                break;
            case "GRE":intentProtocolValue="gre";
                break;
            case "IPv6_ICMP":intentProtocolValue="ipv6-icmp";
                break;
            case "IPv6_NoNxt":intentProtocolValue="ipv6-no-nxt";
                break;
            case "IPv6_Opts":intentProtocolValue="ipv6-opts";
                break;
            case "ISO_IP":intentProtocolValue="iso-ip";
                break;
            case "EIGRP":intentProtocolValue="eigrp";
                break;
            case "OSPFIGP":intentProtocolValue="ospf-igp";
                break;
            case "ETHERIP":intentProtocolValue="ether-ip";
                break;
            case "ENCAP":intentProtocolValue="encap";
                break;
            case "PNNI":intentProtocolValue="pnni";
                break;
            case "PIM":intentProtocolValue="pim";
                break;
            case "VRRP":intentProtocolValue="vrrp";
                break;
            case "L2TP":intentProtocolValue="l2tp";
                break;
            case "STP":intentProtocolValue="stp";
                break;
            case "PTP":intentProtocolValue="ptp";
                break;
            case "ISIS":intentProtocolValue="isis";
                break;
            case "CRTP":intentProtocolValue="crtp";
                break;
            case "CRUDP":intentProtocolValue="crudp";
                break;
            case "SCTP":intentProtocolValue="sctp";
                break;
            default:intentProtocolValue=undefined;
        }
        return intentProtocolValue;
    }

  this.modifyNeIdForIpV6 = function (objectFullName, neId) {
     logger.info("modifying NeId For IpV6");
     objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
     return objectFullName;
  }
}
