function MdSuggest() {
    this.getOspfInstance = function (neId) {
        let url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base/ospf?fields=ospf-instance";
        return this.getSuggestData(neId, url, "nokia-conf:ospf", "ospf-instance");
    }

    this.getTransitArea = function (neId, instanceId, routerId, actionType) {
        let transitAreas;
        let mdcFwk = new MdcFwk();
        if(actionType === "associate"){
        let url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/ospf=${instanceId}/area=0.0.0.0/virtual-link=${routerId},?fields=transit-area`;
          return this.getSuggestData(neId, url, "nokia-conf:virtual-link", "transit-area");
        }else{
        let url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/ospf=${instanceId}/area?fields=area-id`;
        let resultFetch = mdcFwk.fetch(neId, url);
        let finalResponse = resultFetch["msg"]["nokia-conf:area"];
        if (!Array.isArray(finalResponse)) {
          return [];
        }
         transitAreas = finalResponse.filter(function(item) {
            return item["area-id"] !== "0.0.0.0";
        }).map(function(item) {
            return item["area-id"];
        });
      }
      return transitAreas;
    };

    this.getAreaData = function (neId, instance) {
        let url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/ospf=${instance}/area?fields=area-id`;
        let mdcFwk = new MdcFwk();
        let resultFetch = mdcFwk.fetch(neId, url);
        let finalResponse = resultFetch["msg"]["nokia-conf:area"];

        if (!Array.isArray(finalResponse)) {
            return [];
        }

        let Areas = finalResponse.filter(function(item) {
            return item["area-id"] === "0.0.0.0";
        }).map(function(item) {
            return item["area-id"];
        });

        return Areas;
    };

    this.getAuthenticationKeychain = function (neId) {
        let url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/system/security/keychains/keychain?fields=keychain-name";
        return this.getSuggestData(neId, url, "nokia-conf:keychain", "keychain-name");
    }

    this.getSuggestData = function (neId, url, initialProperty, propertyName) {
        let mdcFwk = new MdcFwk();
        logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, propertyName);
        let ret = [];
        let resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info("MDC resultFetch =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        let finalResponse = resultFetch["msg"][initialProperty];
        logger.info("finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse)) {
            for (let index in finalResponse) {
                logger.info("Device " + propertyName + " Data = {}", finalResponse[index][propertyName]);
                ret.push(finalResponse[index][propertyName]);
            }
        }
         ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info("ret = \n" + JSON.stringify(ret));
        return ret;
    }

   this.getRouterId = function (neId, instanceId, actionType) {
      let neIdXPath = `/nsp-equipment:network/network-element`;
      let nspRestConf = new NspRestconfFwk();
      let finalResponse = nspRestConf.findByXpath(neIdXPath, "3", "ne-id");
      if(actionType === "associate"){
        let url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/ospf=${instanceId}/area=0.0.0.0/virtual-link?fields=router-id`;
        return this.getSuggestData(neId, url, "nokia-conf:virtual-link", "router-id");
      }else if(finalResponse) {
        let data = finalResponse.map(element => element["ne-id"]).filter(id => id !== neId);
        return data;
    }
    return [];
  }
}
