function NfmpSuggest() {

    this.getTunnelName = function (neId) {
        let className = "mpls.Tunnel";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "sourceNodeId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObject, className, "displayedName")
    }

    this.getTunnelData = function (neId, tunnelData ,type, name) {
        let nfmpFwk = new NfmpFwk();
        let className = "mpls.Tunnel";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "sourceNodeId",
                            "value": neId
                        },
                        {
                            "name": name,
                            "value": tunnelData
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    type
                ]
            }
        };
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        let finalResponse = JSON.parse(resultFetch.response);
        let data = (finalResponse[className] && finalResponse[className][type]);
        return data;
    }

    this.getData = function (searchObjectJson, className, type) {
        var nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    ret.push(value[type]);
                })
            }
        }

        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

}