function NfmpSuggest() {
   this.getData = function (searchObjectJson, className, type) {
        let nfmpFwk = new NfmpFwk();
        let ret = [];
        let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        let finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    ret.push(value[type]);
                })
            }
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
   }

    this.getWRRPolicy = function (neId) {
        var searchObjectJson = {
            "fullClassName": "portscheduler.HsmdaWrrPolicy",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObjectJson, "portscheduler.HsmdaWrrPolicy", "displayedName");
    }

    this.getHSAttachmentPolicy = function (neId) {
        var searchObjectJson = {
            "fullClassName": "hsqos.HsAttachmentPolicy",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObjectJson, "hsqos.HsAttachmentPolicy", "displayedName");
    }

    this.getHS_WREDSlopePolicy = function (neId) {
        var searchObjectJson = {
            "fullClassName": "slope.Policy",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObjectJson, "slope.Policy", "displayedName");
    }

    this.getSlopePolicy = function (neId) {
        var searchObjectJson = {
            "fullClassName": "slope.HsmdaSlopePolicy",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObjectJson, "slope.HsmdaSlopePolicy", "displayedName");
    }

    this.getPoolName = function (neId) {
        var searchObjectJson = {
            "fullClassName": "slope.NamedPool",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObjectJson, "slope.NamedPool", "displayedName");
    }

    this.getDisplayedName = function (neId) {
        let className = "nqueue.Policy";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObject, className, "displayedName")
    }
}