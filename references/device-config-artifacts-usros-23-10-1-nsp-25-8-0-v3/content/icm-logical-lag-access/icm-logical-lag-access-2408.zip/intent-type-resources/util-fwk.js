load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {

    this.setSuccessResult = function (result, savedTopology) {
        result.setSuccess(true);
        if (savedTopology !== undefined)
        {
            result.setTopology(savedTopology);
        }
        return result;
    }

    this.reportMisaligned = function (target, result, auditReport) {
        var report = JSON.parse(result.response);
        if (!report.aligned)
        {
            for (var i = 0; i < report.misalignedAttributes.length; i++)
            {
                var attributeData = report.misalignedAttributes[i];
                if (attributeData.expected == "present")
                {
                    //misaligned object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else if (attributeData.expected == "not present")
                {
                    //undesired object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                    auditReport.addMisAlignedAttribute(misalignedAttribute);
                }

            }
        }
        return auditReport
    }

    this.editPayload = function (fdn, properties, childProperties, fullClassName, objectFullName) {

        var payload = {};
        var configInfo = {};
        configInfo["containedClassProperties"] = properties;
        configInfo["containmentInfo"] = childProperties;
        configInfo["objectClassName"] = fullClassName;
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName;
        payload["configInfo"] = configInfo;
        return payload;
    }

    /*
        function: isObjectExists
        description: To Check the Object exists or not.
   */
    this.isObjectExists = function (className, objectFullName) {
        let nfmpFwk = new NfmpFwk();
        var ret = false;
        var searchObjectJson = {
            "fullClassName": className,
            "filter": {
                "filterExpression": "fullName='" + objectFullName + "'"
            }
        };
        var resultFetch = nfmpFwk.post("search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse))
        {
            ret = true;
        }
        return ret;
    }

    //convert system-id to NFMP system-id, convert 00:00:00:00:00:00 to 00-00-00-00-00-00.
    this.convertToNfmpsystemId = function (systemId) {
        return systemId.replaceAll(":", "-");
    }

    //convert system-id to Intent system-id, convert  00-00-00-00-00-00 to 00:00:00:00:00:00.
    this.convertToIntentsystemId = function (systemId) {
        return systemId.replaceAll("-", ":");
    }

    //convert admin-sate to NFMP administrate State.
    this.convertToNfmpAdminstarteState = function (adminState) {
        if (adminState == "enable")
        {
            return "portInService";
        }
        else if (adminState == "disable")
        {
            return "portOutOfService";
        }
    }

    //convert administrate State to intent admin-state.
    this.convertToIntentAdminState = function (adminState) {
        if (adminState == "portInService")
        {
            return "enable";
        }
        else if (adminState == "portOutOfService")
        {
            return "disable";
        }
    }

    this.convertAdminStateBrownField=function(adminState) {
        if (adminState == "enabled")
        {
            return "enable";
        }
        else if (adminState == "disabled")
        {
            return "disable";
        }
    }

    this.convertSubGroupGreenField = function (subGroup) {
        if (subGroup == "-2")
        {
            return "auto_iom";
        }
        else if (subGroup == "-1")
        {
            return "auto_mda";
        }
        return subGroup;
    }

    this.convertSubGroupBrownField = function (subGroup) {
        if (subGroup == "auto_iom")
        {
            return "-2";
        }
        else if (subGroup == "auto_mda")
        {
            return "-1";
        }
        return subGroup;
    }

    //convert encapType to NFMP encapType.
    this.convertToNfmpEncapType = function (encapType) {
        if (encapType == null)
        {
            return "nullEncap";
        }
        else if (encapType == "dot1q")
        {
            return "qEncap";
        }
        else if (encapType == "qinq")
        {
            return "qinqEncap";
        }
    }

    //convert encapType to Intent encapType.
    this.convertToIntentEncapType = function (encapType) {
        if (encapType == "nullEncap")
        {
            return "null";
        }
        else if (encapType == "qEncap")
        {
            return "dot1q";
        }
        else if (encapType == "qinqEncap")
        {
            return "qinq";
        }
    }

    //convert port-threshold Action to NFMP portThresholdAction.
    this.convertToNfmpportThresholdAction = function (action) {
        if (action == "dynamic-cost")
        {
            return "dynamicCost";
        }
        else if (action == "static-cost")
        {
            return "staticCost";
        }
        return action;
    }

    //convert port-threshold Action to Intent portThresholdAction.
    this.convertToIntentportThresholdAction = function (action) {
        if (action == "dynamicCost")
        {
            return "dynamic-cost";
        }
        else if (action == "staticCost")
        {
            return "static-cost";
        }
        return action;
    }

    this.getBaseFdnForPort = function (target, portId) {
        if (portId.startsWith("esat"))
        {
            return this.getBaseFdnForSatellitePort(target, portId);
        }
        var portIds = portId.split("/");
        var cardSlot;
        var xiomSlot;
        var mdaSlot;
        var connector;
        var portNumber

        portIds.forEach(function (item, index) {
            // logger.info("*********************item, index = " + item + "-----" + index);
            switch (index)
            {
                case 0:
                    cardSlot = item;
                    break;
                case 1:
                    //xiom
                    if (isNaN(item))
                    {
                        xiomSlot = item;
                    }
                    else
                    {
                        mdaSlot = item;
                    }
                    break;
                case 2:
                    //connector
                    if (isNaN(item))
                    {
                        connector = item;
                    }
                    else if (mdaSlot)
                    {
                        portNumber = item;
                    }
                    else
                    {
                        mdaSlot = item;
                    }
                    break;
                case 3:
                    //connector
                    if (isNaN(item))
                    {
                        connector = item;
                    }
                    else
                    {
                        portNumber = item;
                    }
                    break;
                case 4:
                    portNumber = item;
                    break;


            }
        });

        // logger.info("************ cardSlot =" + cardSlot + ",xiomSlot=" + xiomSlot + ",mdaSlot=" + mdaSlot + ",connector=" + connector + ",portNumber=" + portNumber);
        //"network:92.168.96.22:shelf-1:cardSlot-1:card:xioSlot-1:xiomCard:daughterCardSlot-1:daughterCard:conn-1:port-1"

        var portDn = "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card";
        if (xiomSlot)
        {
            portDn += ":xioSlot-" + xiomSlot.substring(1) + ":xiomCard";
        }
        if (mdaSlot)
        {
            portDn += ":daughterCardSlot-" + mdaSlot + ":daughterCard";
        }
        if (connector)
        {
            portDn += ":conn-" + connector.substring(1);
        }
        if (portNumber)
        {
            portDn += ":port-" + portNumber;
        }
        if (target && String(target).indexOf(':') !== -1) {
          portDn = this.modifyNeIdForIpV6(portDn, target);
        }
        logger.info("*********************portDn = " + portDn);
        return portDn;
        //return "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card:daughterCardSlot-" + mdaSlot + ":daughterCard:port-" + portNumber;
    }

    this.getBaseFdnForSatellitePort = function (target, portId) {

        var portIds = (portId.split("-")[1]).split("/");
        var shelf = "shelf-1-5-";
        shelf += portIds[0];
        var satId = portIds[0];
        var cardSlot = "cardSlot-1:card";
        var mdaSlot = "daughterCardSlot-1:daughterCard";
        var portNumber = portIds[2];
        var snmpPortId = this.getSatellitePortSnmpId(satId, 1, portNumber, false, 5)
        //logger.info("******satellite port = shelf = "+shelf+", portnumber = "+portNumber +"\n portid = "+ portId+"\n portids = "+ portIds);
        var portDn = "network:" + target + ":" + shelf + ":" + cardSlot + ":" + mdaSlot + ":port-" + snmpPortId;
        if (target && String(target).indexOf(':') !== -1) {
            portDn = this.modifyNeIdForIpV6(portDn, target);
        }
        logger.info("SatPortDN = " + portDn);
        return portDn;
    }

    this.getSatellitePortSnmpId = function (aInSatId, aInSlotId, aInPortId, aInUplink, aInPhyShelfClass) {
        var aInSnmpIndex = aInPortId;
        var lUplinkBit = 0;
        if (aInUplink)
        {
            lUplinkBit = 1;
        }
        var lSatId = aInSatId << 16;
        var lSlotId = aInSlotId << 11;
        var lUplink = lUplinkBit << 10;
        var lSat = 136 << 23;
        aInSnmpIndex = lSat | lSatId | lSlotId | lUplink | aInSnmpIndex;
        return aInSnmpIndex;
    }

    this.convertAdminStateGreenField = function (adminState) {
        if (adminState == "enable")
        {
            return "enabled";
        }
        else if (adminState == "disable")
        {
            return "disabled";
        }
    }
    this.expandIPv6Address =  function (address)
    {
        var ipv6AddressUtil = new IPv6AddressUtil();
         return ipv6AddressUtil.expandIPv6AddressForClassic(address);
    }
    this.convertBfValueSupport = function (input) {
        if (input === undefined) {
            return undefined;
        }
        if (input == "-1")
        {
            return "infinite";
        }
        else
        {
            return input;
        }
    }
    this.getIxrType= function (target) {
        var deviceInfos = mds.getAllInfoFromDevices(target);
        if (null == deviceInfos || deviceInfos.size() === 0) {
            throw new RuntimeException("Device not found :" + target);
        }
        var deviceInfo = deviceInfos.get(0);
        var deviceType = deviceInfo.getFamilyTypeRelease();
        if (deviceType == null) {
            throw new RuntimeException("Device Family type and release not found for device: " + target);
        }
        var type= deviceType.split(':');
        log.info(null, "Device type:" + type);
        var deviceType;
        deviceType = {
            type: type[2]
        };
        return deviceType;
    };

  this.modifyNeIdForIpV6 = function (objectFullName, neId) {
     logger.info("modifying NeId For IpV6");
     objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
     return objectFullName;
  }


   this.MdIpv6ValidAddresssMaskSupport = function(input) {
        if (input === undefined) {
            return undefined;
        }
        if (input.endsWith(':') || input.endsWith('::0')) {
            input += ":";
        }
        let hex = removeLeadingTrailingZeros(input)
        if(hex.indexOf('::')!==-1){
            hex=hex.replace(/(::)0+/g, '$1').replace(/:::/g, "::")
            return hex;
        }
        const hextets = hex.split(':').filter(part => part !== ''); // Remove empty parts
        let maxZeroLength = 0;
        let longestZeroIndex = -1;
        let currentZeroLength = 0;
        for (let i = 0; i < hextets.length; i++) {
            if (hextets[i] === '0') {
                currentZeroLength++;
                if (currentZeroLength > maxZeroLength) {
                    maxZeroLength = currentZeroLength;
                    longestZeroIndex = i - maxZeroLength + 1;
                }
            } else {
                currentZeroLength = 0;
            }
        }
        if (maxZeroLength > 1) {
            hextets.splice(longestZeroIndex, maxZeroLength, '::');
        }
        if (maxZeroLength === 1) {
            const zeroIndex = hextets.indexOf('0');
            const zeroCount = hextets.filter(part => part === '0').length;
            if (zeroIndex !== -1 && zeroCount === 1 && hextets.length !== 8) {
                hextets.splice(zeroIndex, 1, '::');
            }
        }

        let result = hextets.join(':').replace(/::+/g, '::');
        return result;
    }

    function removeLeadingTrailingZeros(input) {
        const parts = input.split(':');
        for (let i = 0; i < parts.length; i++) {
            if(parts[i] == ''){
                continue
            }else{
                parts[i] = removeLeadingZeros(parts[i]);
            }

        }
        return parts.join(':');
    }

    function removeLeadingZeros(part) {
        let result = '';
        let nonZeroEncountered = false;
        for (let i = 0; i < part.length; i++) {
            if (part[i] !== '0') {
                nonZeroEncountered = true;
            }
            if (nonZeroEncountered) {
                result += part[i];
            }
        }
        return result || '0';
   }

    function ipv6ToMappedIpv4WithSuffix(address){
        // Preserve CIDR suffix if present
        let cidrSuffix = '';
        if (address.indexOf('/') !== -1) {
            var splitParts = address.split('/');
            address = splitParts[0];
            cidrSuffix = '/' + splitParts[1];
        }
        address = ipv6ToMappedIpv4(address);
        return address+cidrSuffix;
    }

    function ipv6ToMappedIpv4(ipv6)
    {
        // Extract the hex part after "::ffff:"
        let hexPart = ipv6.replace("::ffff:", "");
        hexPart = hexPart.replace("::FFFF:", "");

        // Split the remaining part into two 16-bit sections
        const parts = hexPart.split(":");
        if (parts.length !== 2) {
            return ipv6;
        }

        // Convert each 16-bit hex value into two 8-bit decimal values
        const firstTwoOctets = parseInt(parts[0], 16); // Convert first 16 bits
        const lastTwoOctets = parseInt(parts[1], 16);  // Convert last 16 bits

        // Extract individual octets
        const octet1 = (firstTwoOctets >> 8) & 0xFF;
        const octet2 = firstTwoOctets & 0xFF;
        const octet3 = (lastTwoOctets >> 8) & 0xFF;
        const octet4 = lastTwoOctets & 0xFF;

        // Construct the final "::ffff:<IPv4>" format
        return "::ffff:" + octet1 + "." + octet2 + "." + octet3 + "." + octet4;
    }

    this.expandIPv6ForMd = function(address) {
        var fullAddress = "";
        var validGroupCount = 8;

        var ipv4 = "";
        var extractIpv4 = /([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})/;
        var validateIpv4 = /((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})/;
        // look for embedded ipv4
        if (validateIpv4.test(address)) {
            var groups = address.match(extractIpv4);
            for (var i = 1; i < groups.length; i++) {
                ipv4 += ("0" + (parseInt(groups[i], 10).toString(16))).slice(-2) + (i == 2 ? ":" : "");
            }
            if(!address.startsWith("::ffff") && !address.startsWith("::FFFF"))
			{
				address = address.replace(extractIpv4, ipv4);
			}
        }
        else
        {
            if(address.startsWith("::ffff") || address.startsWith("::FFFF"))
            {
                address = ipv6ToMappedIpv4WithSuffix(address)
            }
        }

        if (address.indexOf("::") == -1) // All eight groups are present.
            fullAddress = address;
        else // Consecutive groups of zeroes have been collapsed with "::".
        {
            var sides = address.split("::");
            var groupsPresent = 0;
            for (var i = 0; i < sides.length; i++) {
                groupsPresent += sides[i].split(":").length;
            }
            fullAddress += (sides[0] ? sides[0] : 0) + ":";
            for (var i = 0; i < validGroupCount - groupsPresent; i++) {
                fullAddress += "0:";
            }
            if (sides[1]) {
                fullAddress += (sides[1].split("/")[0] ? sides[1].split("/")[0] : "0") +
                    (sides[1].split("/")[1] ? "/" + sides[1].split("/")[1] : "");
            } else {
                fullAddress += "0";
            }

        }
        fullAddress = removeLeadingZeros(fullAddress);
        return fullAddress.toLowerCase();
    }
}
