var RuntimeException = Java.type('java.lang.RuntimeException');

load({
    script: resourceProvider.getResource("nfmp-fwk.js"),
    name: "NfmpFwk"
});
load({
    script: resourceProvider.getResource('parse-target.js'),
    name: 'ParseTarget'
});
load({
    script: resourceProvider.getResource("util-fwk.js"),
    name: "utilities"
});

load({
    script: resourceProvider.getResource('nfmpSuggest.js'),
    name: 'NfmpSuggest'
})

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();
    let nfmpSuggest = new NfmpSuggest();

    this.getDeviceConfiguration = function(target, initialPropertyName) {

        let neId = parseTarget.getNeIdFromTarget(target);
        let filterId = util.getIpFilterId(target);
        let filterName = parseTarget.getUniqueIdentifier(target);
        let searchPayLoad = this.constructSearchString(neId, filterId, filterName);
        let resultFetch = nfmpFwk.find(neId, searchPayLoad);
        if (!resultFetch.success) {
            throw new RuntimeException("Failed to find Filter ID: " + filterId + ", filter-Name : " + filterName + " on NE " + neId);
        }
        let finalResponse = JSON.parse(resultFetch.response);
        if (JSON.stringify(finalResponse) === JSON.stringify({})) {
            throw new RuntimeException("search results is empty for IPv6 Filter with policy ID: " + filterId + " finalResponse: " + JSON.stringify(finalResponse));
        }
        else if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse["aclfilter.Ipv6Filter"]];
            logger.info(LOG_PREFIX + "Search results: " + JSON.stringify(finalResponse));
        }
        return finalResponse[0];
    }

    this.extractDeviceConfig = function(defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        if (null !== deviceConfig) {
            this.extractIPv6FilterProperties(parsedDefaultTargetData, deviceConfig);
            let childrenConfig = deviceConfig["children-Set"];
            if (undefined !== childrenConfig && null !== childrenConfig)
            {
                let IPv6FilterEntryDeviceConfig = childrenConfig["aclfilter.Ipv6FilterEntry"];
                if(IPv6FilterEntryDeviceConfig != undefined && !Array.isArray(IPv6FilterEntryDeviceConfig))
                {
                    IPv6FilterEntryDeviceConfig = [IPv6FilterEntryDeviceConfig];
                }
                if(IPv6FilterEntryDeviceConfig != undefined && IPv6FilterEntryDeviceConfig.length != 0)
                {
                    let ipv6FilterEntryData = parsedDefaultTargetData['ipv6-filter']['entry'];
                    if (ipv6FilterEntryData !== null && Array.isArray(ipv6FilterEntryData) && ipv6FilterEntryData.length !== 0)
                    {
                        let ipFilterEntryArray = this.extractIPv6FilterEntryData(ipv6FilterEntryData, IPv6FilterEntryDeviceConfig);
                        parsedDefaultTargetData['ipv6-filter']['entry'] = ipFilterEntryArray;
                    }
                }
                else
                {
                    delete parsedDefaultTargetData['ipv6-filter']['entry'];
                }

                let IPv6FilterEntryEmbededFilterConfig = childrenConfig["aclfilter.Ipv6FilterEmbeddedRefTable"];
                if(IPv6FilterEntryEmbededFilterConfig!= undefined && !Array.isArray(IPv6FilterEntryEmbededFilterConfig))
                {
                    IPv6FilterEntryEmbededFilterConfig = [IPv6FilterEntryEmbededFilterConfig];
                }
                if(IPv6FilterEntryEmbededFilterConfig != undefined && IPv6FilterEntryEmbededFilterConfig.length != 0)
                {
                    if(parsedDefaultTargetData['ipv6-filter']['embed'])
                    {
                        let ipv6FilterEmbedFilterEntryData = parsedDefaultTargetData['ipv6-filter']['embed']["filter"];
                        if (ipv6FilterEmbedFilterEntryData !== null && Array.isArray(ipv6FilterEmbedFilterEntryData) && ipv6FilterEmbedFilterEntryData.length !== 0)
                        {
                            let ipv6FilterEmbedFilterEntryArray = this.extractIPv6FilterEmbedFilterProperties(ipv6FilterEmbedFilterEntryData, IPv6FilterEntryEmbededFilterConfig);
                            parsedDefaultTargetData['ipv6-filter']['embed']['filter'] = ipv6FilterEmbedFilterEntryArray;
                        }
                    }
                }
                else
                {
                    if(parsedDefaultTargetData['ipv6-filter']['embed'] && parsedDefaultTargetData['ipv6-filter']['embed']["filter"])
                    {
                        delete parsedDefaultTargetData['ipv6-filter']['embed']["filter"];
                    }
                }

                let IPv6FilterEntryEmbededFlowSpecConfig = childrenConfig["aclfilter.FlowSpecEmbeddedFilter"];
                if(IPv6FilterEntryEmbededFlowSpecConfig != undefined && !Array.isArray(IPv6FilterEntryEmbededFlowSpecConfig))
                {
                    IPv6FilterEntryEmbededFlowSpecConfig = [IPv6FilterEntryEmbededFlowSpecConfig];
                }
                if(IPv6FilterEntryEmbededFlowSpecConfig != undefined && IPv6FilterEntryEmbededFlowSpecConfig.length != 0)
                {
                    if(parsedDefaultTargetData['ipv6-filter']['embed'])
                    {
                        let ipv6FilterEmbedFlowSpecEntryData = parsedDefaultTargetData['ipv6-filter']['embed']["flowspec"];
                        if (ipv6FilterEmbedFlowSpecEntryData !== null && Array.isArray(ipv6FilterEmbedFlowSpecEntryData) && ipv6FilterEmbedFlowSpecEntryData.length !== 0)
                        {
                            let ipv6FilterEmbedFlowSpecEntryArray = this.extractIPv6FilterEmbedFlowSpecProperties(ipv6FilterEmbedFlowSpecEntryData, IPv6FilterEntryEmbededFlowSpecConfig);
                            parsedDefaultTargetData['ipv6-filter']['embed']['flowspec'] = ipv6FilterEmbedFlowSpecEntryArray;
                        }
                    }
                }
                else
                {
                    if(parsedDefaultTargetData['ipv6-filter']['embed'] && parsedDefaultTargetData['ipv6-filter']['embed']["flowspec"])
                    {
                        delete parsedDefaultTargetData['ipv6-filter']['embed']["flowspec"];
                    }
                }
                if(parsedDefaultTargetData['ipv6-filter']['embed'] && parsedDefaultTargetData['ipv6-filter']['embed']['openflow'])
                {
                    delete parsedDefaultTargetData['ipv6-filter']['embed']["openflow"];
                }
            }
            else
            {
                delete parsedDefaultTargetData['ipv6-filter']['entry'];
                delete parsedDefaultTargetData['ipv6-filter']['embed'];
            }
        }

        this.clearEmptiesAndNull(parsedDefaultTargetData);
        return parsedDefaultTargetData;
    }

    this.extractIPv6FilterEntryData = function(defaultIPFilterEntryData, IPv6FilterEntryDeviceConfig)
    {
        let ipFilterEntryArray = [];
        let ipFilterEntryDefaults = defaultIPFilterEntryData[0];
        for (let i = 0; i < IPv6FilterEntryDeviceConfig.length; i++)
        {
            let ipv6EntryConfig = IPv6FilterEntryDeviceConfig[i];
            let siteId = ipv6EntryConfig["siteId"];
            let ipv6FilterEntryData = JSON.parse(JSON.stringify(ipFilterEntryDefaults));
            ipv6FilterEntryData['entry-id'] = ipv6EntryConfig['id'];
            ipv6FilterEntryData['description'] = ipv6EntryConfig['description'];
            ipv6FilterEntryData['pbr-down-action-override'] =
                util.transformIntentPbrDownAction(ipv6EntryConfig['pbrDownActionOvr']);

            if(ipv6EntryConfig['stickyDestHoldTimeUp'] == -1)
            {
                ipv6FilterEntryData['sticky-dest'] = "no-hold-time-up";
            }
            else
            {
                ipv6FilterEntryData['sticky-dest'] = ipv6EntryConfig['stickyDestHoldTimeUp'];
            }

            if(ipv6EntryConfig["logId"])
            {
                ipv6FilterEntryData["log"] = ipv6EntryConfig["logId"];
            }

            if(ipv6EntryConfig["collectStats"])
            {
                ipv6FilterEntryData["collect-stats"] = ipv6EntryConfig["collectStats"];
            }

            if(ipv6EntryConfig["egrPBR"] == "enable")
            {
                ipv6FilterEntryData["egress-pbr"] = "true";
            }
            else if(ipv6EntryConfig["egrPBR"] == "enableWithL4LB")
            {
                ipv6FilterEntryData["egress-pbr"] = "true-with-l4lb";
            }
            else
            {
                ipv6FilterEntryData["egress-pbr"] = undefined;
            }

            if(ipv6EntryConfig["cflowdSample"] === "true")
            {
                ipv6FilterEntryData["filter-sample"] = true;
            }
            else
            {
                ipv6FilterEntryData["filter-sample"] = false;
            }
            if(ipv6EntryConfig["cflowdIfSample"] === "true")
            {
                ipv6FilterEntryData["interface-sample"] = true;
            }
            else
            {
                ipv6FilterEntryData["interface-sample"] = false;
            }

            if(ipv6EntryConfig["sampleProfile"] && ipv6EntryConfig["sampleProfile"] != "0")
            {
                ipv6FilterEntryData["sample-profile"] = ipv6EntryConfig["sampleProfile"];
            }

            if(ipv6EntryConfig["tcpEstablished"] == "true")
            {
                ipv6FilterEntryData["match"]["tcp-established"] = [null];
                delete ipv6FilterEntryData["match"]["tcp-flags"];
            }
            else
            {
                delete ipv6FilterEntryData["match"]["tcp-established"];
                if(ipv6EntryConfig["tcpAck"] != "off")
                {
                    ipv6FilterEntryData["match"]["tcp-flags"]["ack"] = ipv6EntryConfig["tcpAck"];
                }
                if(ipv6EntryConfig["tcpSyn"] != "off")
                {
                    ipv6FilterEntryData["match"]["tcp-flags"]["syn"] = ipv6EntryConfig["tcpSyn"];
                }
                if(ipv6EntryConfig["tcpFin"] != "off")
                {
                    ipv6FilterEntryData["match"]["tcp-flags"]["fin"] = ipv6EntryConfig["tcpFin"];
                }
                if(ipv6EntryConfig["tcpRst"] != "off")
                {
                    ipv6FilterEntryData["match"]["tcp-flags"]["rst"] = ipv6EntryConfig["tcpRst"];
                }
                if(ipv6EntryConfig["tcpPsh"] != "off")
                {
                    ipv6FilterEntryData["match"]["tcp-flags"]["psh"] = ipv6EntryConfig["tcpPsh"];
                }
                if(ipv6EntryConfig["tcpUrg"] != "off")
                {
                    ipv6FilterEntryData["match"]["tcp-flags"]["urg"] = ipv6EntryConfig["tcpUrg"];
                }
                if(ipv6EntryConfig["tcpEce"] != "off")
                {
                    ipv6FilterEntryData["match"]["tcp-flags"]["ece"] = ipv6EntryConfig["tcpEce"];
                }
                if(ipv6EntryConfig["tcpCwr"] != "off")
                {
                    ipv6FilterEntryData["match"]["tcp-flags"]["cwr"] = ipv6EntryConfig["tcpCwr"];
                }
                if(ipv6EntryConfig["tcpNs"] != "off")
                {
                    ipv6FilterEntryData["match"]["tcp-flags"]["ns"] = ipv6EntryConfig["tcpNs"];
                }

            }
            let filterProtocolList = ipv6EntryConfig['protocolListPointer'];
            if(filterProtocolList !== "")
            {
                ipv6FilterEntryData['match']["next-header-list"] = filterProtocolList.replace("filterProtocolList:", "");
                delete ipv6FilterEntryData["match"]["next-header"];
            }
            else{
                ipv6FilterEntryData["match"]["next-header"] = util.transformIntentProtocol(ipv6EntryConfig['protocol']);
                delete ipv6FilterEntryData["match"]["next-header-list"];
            }

            if (ipv6EntryConfig['ipAddress'] === '0:0:0:0:0:0:0:0' && ipv6EntryConfig['ipAddressMask'] === "0" && ipv6EntryConfig['ipPrefixListPointer'] === ""){
                ipv6FilterEntryData['match']['ip'] = undefined;
            }
            else{
                ipv6FilterEntryData['match']['ip'] = new Object();
                let ipFilterPrefixList = ipv6EntryConfig['ipPrefixListPointer'];
                if(ipFilterPrefixList !== "")
                {
                    ipv6FilterEntryData['match']['ip']['ipv6-prefix-list'] = ipFilterPrefixList.replace("filterPrefixList:", "");
                }
                else
                {
                    ipv6FilterEntryData['match']['ip']['address'] = ipv6EntryConfig['ipAddress'] +"/"+ ipv6EntryConfig['ipAddressMask'];
                    ipv6FilterEntryData['match']['ip']['mask'] = ipv6EntryConfig['ipAddressFullMask']
                }
            }
            if (!this.isObjectExists(ipv6FilterEntryData['match']['ip']))
            {
                if (ipv6EntryConfig['sourceIpAddress'] === '0:0:0:0:0:0:0:0' && ipv6EntryConfig['sourceIpAddressMask'] == "0" && ipv6EntryConfig['srcIpPrefixListPointer'] === ""){
                    ipv6FilterEntryData['match']['src-ip'] = undefined;
                }
                else{
                    ipv6FilterEntryData['match']['src-ip'] = new Object();
                    let srcIpFilterPrefixList = ipv6EntryConfig['srcIpPrefixListPointer'];
                    if(srcIpFilterPrefixList !== "")
                    {
                        ipv6FilterEntryData['match']['src-ip']['ipv6-prefix-list'] = srcIpFilterPrefixList.replace("filterPrefixList:", "").replace("#type-IPv6", "");
                    }
                    else
                    {
                        ipv6FilterEntryData['match']['src-ip']['address'] = ipv6EntryConfig['sourceIpAddress']+"/"+ ipv6EntryConfig['sourceIpAddressMask'];
                        ipv6FilterEntryData['match']['src-ip']['mask'] = ipv6EntryConfig['sourceIpAddressFullMask'];
                    }
                }

                if (ipv6EntryConfig['destinationIpAddress'] === '0:0:0:0:0:0:0:0' && ipv6EntryConfig['destinationIpAddressMask'] == "0" && ipv6EntryConfig['dstIpPrefixListPointer'] === ""){
                    ipv6FilterEntryData['match']['dst-ip'] = undefined;
                }
                else{
                    ipv6FilterEntryData['match']['dst-ip'] = new Object();
                    let dstIpFilterPrefixList = ipv6EntryConfig['dstIpPrefixListPointer'];
                    if(dstIpFilterPrefixList !== "")
                    {
                        ipv6FilterEntryData['match']['dst-ip']['ipv6-prefix-list'] = dstIpFilterPrefixList.replace("filterPrefixList:", "").replace("#type-IPv6", "");
                    }
                    else
                    {
                        ipv6FilterEntryData['match']['dst-ip']['address'] = ipv6EntryConfig['destinationIpAddress']+"/"+ ipv6EntryConfig['destinationIpAddressMask'];
                        ipv6FilterEntryData['match']['dst-ip']['mask'] = ipv6EntryConfig['destinationIpAddressFullMask'];
                    }
                }
            }

            if((ipv6FilterEntryData['match']['next-header'] == "tcp" || ipv6FilterEntryData['match']['next-header'] == "udp" || ipv6FilterEntryData['match']['next-header'] == "tcp-udp" || ipv6FilterEntryData['match']['next-header'] == "sctp" || ipv6FilterEntryData['match']['protocol-list'] != null)
                && ipv6EntryConfig['portSelector'])
            {
                if(ipv6EntryConfig['portSelector'] == "AND_PORT")
                {
                    ipv6FilterEntryData['match']['src-port'] = new Object();
                    if(ipv6EntryConfig['sourcePortListPointer'])
                    {
                        ipv6FilterEntryData['match']['src-port']['port-list'] = ipv6EntryConfig['sourcePortListPointer'].replace("filterPortList:", "")
                    }
                    else if(ipv6EntryConfig['sourceOperator'] == "EQUAL")
                    {
                        ipv6FilterEntryData['match']['src-port']["eq"] = ipv6EntryConfig['sourcePort1'];
                    }
                    else if(ipv6EntryConfig['sourceOperator'] == "LESS_THAN")
                    {
                        ipv6FilterEntryData['match']['src-port']["lt"] = ipv6EntryConfig['sourcePort1'];
                    }
                    else if(ipv6EntryConfig['sourceOperator'] == "GREATER_THAN")
                    {
                        ipv6FilterEntryData['match']['src-port']["gt"] = ipv6EntryConfig['sourcePort1'];
                    }
                    else if(ipv6EntryConfig['sourceOperator'] == "RANGE")
                    {
                        ipv6FilterEntryData['match']['src-port']["range"] = new Object();
                        ipv6FilterEntryData['match']['src-port']["range"]["start"] = ipv6EntryConfig['sourcePort1'];
                        ipv6FilterEntryData['match']['src-port']["range"]["end"] = ipv6EntryConfig['sourcePort2'];
                    }

                    ipv6FilterEntryData['match']['dst-port'] = new Object();
                    if(ipv6EntryConfig['destinationPortListPointer'])
                    {
                        ipv6FilterEntryData['match']['dst-port']['port-list'] = ipv6EntryConfig['destinationPortListPointer'].replace("filterPortList:", "")
                    }
                    else if(ipv6EntryConfig['destinationOperator'] == "EQUAL")
                    {
                        ipv6FilterEntryData['match']['dst-port']["eq"] = ipv6EntryConfig['destinationPort1'];
                    }
                    else if(ipv6EntryConfig['destinationOperator'] == "LESS_THAN")
                    {
                        ipv6FilterEntryData['match']['dst-port']["lt"] = ipv6EntryConfig['destinationPort1'];
                    }
                    else if(ipv6EntryConfig['destinationOperator'] == "GREATER_THAN")
                    {
                        ipv6FilterEntryData['match']['dst-port']["gt"] = ipv6EntryConfig['destinationPort1'];
                    }
                    else if(ipv6EntryConfig['destinationOperator'] == "RANGE")
                    {
                        ipv6FilterEntryData['match']['dst-port']["range"] = new Object();
                        ipv6FilterEntryData['match']['dst-port']["range"]["start"] = ipv6EntryConfig['destinationPort1'];
                        ipv6FilterEntryData['match']['dst-port']["range"]["end"] = ipv6EntryConfig['destinationPort2'];
                    }
                    ipv6FilterEntryData['match']['port'] = undefined;
                }
                else if(ipv6EntryConfig['portSelector'] == "OR_PORT")
                {
                    ipv6FilterEntryData['match']['port'] = new Object();
                    if(ipv6EntryConfig['portListPointer'])
                    {
                        ipv6FilterEntryData['match']['port']['port-list'] = ipv6EntryConfig['portListPointer'].replace("filterPortList:", "")
                    }
                    else if(ipv6EntryConfig['portOperator'] == "EQUAL")
                    {
                        ipv6FilterEntryData['match']['port']["eq"] = ipv6EntryConfig['port1'];
                    }
                    else if(ipv6EntryConfig['portOperator'] == "LESS_THAN")
                    {
                        ipv6FilterEntryData['match']['port']["lt"] = ipv6EntryConfig['port1'];
                    }
                    else if(ipv6EntryConfig['portOperator'] == "GREATER_THAN")
                    {
                        ipv6FilterEntryData['match']['port']["gt"] = ipv6EntryConfig['port1'];
                    }
                    else if(ipv6EntryConfig['portOperator'] == "RANGE")
                    {
                        ipv6FilterEntryData['match']['port']["range"] = new Object();
                        ipv6FilterEntryData['match']['port']["range"]["start"] = ipv6EntryConfig['port1'];
                        ipv6FilterEntryData['match']['port']["range"]["end"] = ipv6EntryConfig['port2'];
                    }
                    ipv6FilterEntryData["match"]["src-port"] = undefined;
                    ipv6FilterEntryData["match"]["dst-port"] = undefined;
                }
                else
                {
                    ipv6FilterEntryData['match']['src-port'] = new Object();
                    if(ipv6EntryConfig['sourceOperator'] === "EQUAL")
                    {
                        ipv6FilterEntryData['match']['src-port']["eq"] = ipv6EntryConfig['sourcePort1'];
                    }
                    else if(ipv6EntryConfig['sourceOperator'] === "LESS_THAN")
                    {
                        ipv6FilterEntryData['match']['src-port']["lt"] = ipv6EntryConfig['sourcePort1'];
                    }
                    else if(ipv6EntryConfig['sourceOperator'] === "GREATER_THAN")
                    {
                        ipv6FilterEntryData['match']['src-port']["gt"] = ipv6EntryConfig['sourcePort1'];
                    }
                    else if(ipv6EntryConfig['sourceOperator'] === "RANGE")
                    {
                        ipv6FilterEntryData['match']['src-port']["range"] = new Object();
                        ipv6FilterEntryData['match']['src-port']["range"]["start"] = ipv6EntryConfig['sourcePort1'];
                        ipv6FilterEntryData['match']['src-port']["range"]["end"] = ipv6EntryConfig['sourcePort2'];
                    }

                    ipv6FilterEntryData['match']['dst-port'] = new Object();
                    if(ipv6EntryConfig['destinationOperator'] === "EQUAL")
                    {
                        ipv6FilterEntryData['match']['dst-port']["eq"] = ipv6EntryConfig['destinationPort1'];
                    }
                    else if(ipv6EntryConfig['destinationOperator'] === "LESS_THAN")
                    {
                        ipv6FilterEntryData['match']['dst-port']["lt"] = ipv6EntryConfig['destinationPort1'];
                    }
                    else if(ipv6EntryConfig['destinationOperator'] === "GREATER_THAN")
                    {
                        ipv6FilterEntryData['match']['dst-port']["gt"] = ipv6EntryConfig['destinationPort1'];
                    }
                    else if(ipv6EntryConfig['destinationOperator'] === "RANGE")
                    {
                        ipv6FilterEntryData['match']['dst-port']["range"] = new Object();
                        ipv6FilterEntryData['match']['dst-port']["range"]["start"] = ipv6EntryConfig['destinationPort1'];
                        ipv6FilterEntryData['match']['dst-port']["range"]["end"] = ipv6EntryConfig['destinationPort2'];
                    }
                    ipv6FilterEntryData['match']['port'] = undefined;
                }
            }
            else
            {
                ipv6FilterEntryData['match']['src-port'] = undefined;
                ipv6FilterEntryData['match']['dst-port'] = undefined;
                ipv6FilterEntryData['match']['port'] = undefined;
            }

            if(ipv6EntryConfig['dscp'] && ipv6EntryConfig['dscp'] != "default")
            {
                ipv6FilterEntryData["match"]["dscp"] = ipv6EntryConfig['dscp'];
            }

            if(ipv6EntryConfig["fragment"])
            {
                if(ipv6EntryConfig["fragment"] == "firstOnly")
                {
                    ipv6FilterEntryData["match"]["fragment"] = "first-only";
                }
                else if(ipv6EntryConfig["fragment"] == "non-first-only")
                {
                    ipv6FilterEntryData["match"]["fragment"] = "non-first-only";
                }
                else if(ipv6EntryConfig["fragment"] == "true" || ipv6EntryConfig["fragment"] == "false")
                {
                    ipv6FilterEntryData["match"]["fragment"] = ipv6EntryConfig["fragment"];
                }
            }

            if(ipv6EntryConfig["destIpv6Class"] && ipv6EntryConfig["destIpv6Class"] != 0)
            {
                ipv6FilterEntryData["match"]["destination-class"] = ipv6EntryConfig["destIpv6Class"];
            }

            if(ipv6EntryConfig["sourceMacAddress"] && ipv6EntryConfig["sourceMacAddress"] != "00-00-00-00-00-00")
            {
                ipv6FilterEntryData["match"]["src-mac"]["address"] = ipv6EntryConfig["sourceMacAddress"];
            }

            if(ipv6EntryConfig["sourceMacAddressMask"] && ipv6EntryConfig["sourceMacAddressMask"] != "00-00-00-00-00-00")
            {
                ipv6FilterEntryData["match"]["src-mac"]["mask"] = ipv6EntryConfig["sourceMacAddressMask"];
            }

            if(ipv6EntryConfig["authHeadExtHeader"])
            {
                if(ipv6EntryConfig["authHeadExtHeader"] && ipv6EntryConfig["authHeadExtHeader"] != "off")
                {
                    ipv6FilterEntryData["match"]["extension-header"]["ah"] = ipv6EntryConfig["authHeadExtHeader"];
                }
                if(ipv6EntryConfig["encSecPayloadExtHeader"] && ipv6EntryConfig["encSecPayloadExtHeader"] != "off")
                {
                    ipv6FilterEntryData["match"]["extension-header"]["esp"] = ipv6EntryConfig["encSecPayloadExtHeader"];
                }
                if(ipv6EntryConfig["hopByHopOpt"] && ipv6EntryConfig["hopByHopOpt"] != "off")
                {
                    ipv6FilterEntryData["match"]["extension-header"]["hop-by-hop"] = ipv6EntryConfig["hopByHopOpt"];
                }
                if(ipv6EntryConfig["routingType0"] && ipv6EntryConfig["routingType0"] != "off")
                {
                    ipv6FilterEntryData["match"]["extension-header"]["routing-type0"] = ipv6EntryConfig["routingType0"];
                }
            }

            if(ipv6EntryConfig["flowLabel"] && ipv6EntryConfig["flowLabel"] != "-1")
            {
                ipv6FilterEntryData["match"]["flow-label"] = new Object();
                ipv6FilterEntryData["match"]["flow-label"]["value"] = ipv6EntryConfig["flowLabel"];
                if(ipv6EntryConfig["flowLabelMask"])
                {
                    ipv6FilterEntryData["match"]["flow-label"]["mask"] = ipv6EntryConfig["flowLabelMask"];
                }
            }

            if(ipv6EntryConfig["icmpType"] && ipv6EntryConfig["icmpType"] != "-1")
            {
                ipv6FilterEntryData["match"]["icmp"]["type"] = ipv6EntryConfig["icmpType"];
            }

            if(ipv6EntryConfig["icmpCode"] && ipv6EntryConfig["icmpCode"] != "-1")
            {
                ipv6FilterEntryData["match"]["icmp"]["code"] = ipv6EntryConfig["icmpCode"];
            }

            if(ipv6EntryConfig["matchPktLenOper"] == "EQUAL")
            {
                ipv6FilterEntryData["match"]["packet-length"]["eq"] = ipv6EntryConfig["matchPktLenVal1"];
            }
            else if(ipv6EntryConfig["matchPktLenOper"] == "LESS_THAN")
            {
                ipv6FilterEntryData["match"]["packet-length"]["lt"] = ipv6EntryConfig["matchPktLenVal1"];
            }
            else if(ipv6EntryConfig["matchPktLenOper"] == "GREATER_THAN")
            {
                ipv6FilterEntryData["match"]["packet-length"]["gt"] = ipv6EntryConfig["matchPktLenVal1"];
            }
            else if(ipv6EntryConfig["matchPktLenOper"] == "RANGE")
            {
                ipv6FilterEntryData["match"]["packet-length"]["range"]["start"] = ipv6EntryConfig["matchPktLenVal1"];
                ipv6FilterEntryData["match"]["packet-length"]["range"]["end"] = ipv6EntryConfig["matchPktLenVal2"];
            }

            if(ipv6EntryConfig["matchHoplimitOper"] == "EQUAL")
            {
                ipv6FilterEntryData["match"]["hop-limit"]["eq"] = ipv6EntryConfig["matchHoplimitVal1"];
            }
            else if(ipv6EntryConfig["matchHoplimitOper"] == "LESS_THAN")
            {
                ipv6FilterEntryData["match"]["hop-limit"]["lt"] = ipv6EntryConfig["matchHoplimitVal1"];
            }
            else if(ipv6EntryConfig["matchHoplimitOper"] == "GREATER_THAN")
            {
                ipv6FilterEntryData["match"]["hop-limit"]["gt"] = ipv6EntryConfig["matchHoplimitVal1"];
            }
            else if(ipv6EntryConfig["matchHoplimitOper"] == "RANGE")
            {
                ipv6FilterEntryData["match"]["hop-limit"]["range"]["start"] = ipv6EntryConfig["matchHoplimitVal1"];
                ipv6FilterEntryData["match"]["hop-limit"]["range"]["end"] = ipv6EntryConfig["matchHoplimitVal2"];
            }

            ipv6FilterEntryData['action'] = new Object();
            if(ipv6EntryConfig['forwardFC'] == "true" && ipv6EntryConfig['forwardFcType'])
            {
                ipv6FilterEntryData['action']['fc'] = ipv6EntryConfig['forwardFcType']
            }
            if(ipv6EntryConfig['action'] == "drop")
            {
                ipv6FilterEntryData['action']['drop'] =  [null]
                ipv6FilterEntryData["action"]["drop-when"] = new Object();
                if(ipv6EntryConfig["hoplimitOper"] != "NONE")
                {
                    ipv6FilterEntryData["action"]["drop-when"]["hop-limit"] = new Object();
                    if(ipv6EntryConfig["hoplimitOper"] == "EQUAL")
                    {
                        ipv6FilterEntryData["action"]["drop-when"]["hop-limit"]["eq"] = ipv6EntryConfig["hoplimitVal1"];
                    }
                    else if(ipv6EntryConfig["hoplimitOper"] == "LESS_THAN")
                    {
                        ipv6FilterEntryData["action"]["drop-when"]["hop-limit"]["lt"] = ipv6EntryConfig["hoplimitVal1"];
                    }
                    else if(ipv6EntryConfig["hoplimitOper"] == "GREATER_THAN")
                    {
                        ipv6FilterEntryData["action"]["drop-when"]["hop-limit"]["gt"] = ipv6EntryConfig["hoplimitVal1"];
                    }
                    else if(ipv6EntryConfig["hoplimitOper"] == "RANGE")
                    {
                        ipv6FilterEntryData["action"]["drop-when"]["hop-limit"]["range"] = new Object();
                        ipv6FilterEntryData["action"]["drop-when"]["hop-limit"]["range"]["start"] = ipv6EntryConfig["hoplimitVal1"];
                        ipv6FilterEntryData["action"]["drop-when"]["hop-limit"]["range"]["end"] = ipv6EntryConfig["hoplimitVal2"];
                    }
                    else
                    {
                        ipv6FilterEntryData["action"]["drop-when"]["hop-limit"] = undefined;
                    }
                }
                if(ipv6EntryConfig["pktLenOper"] != "NONE")
                {
                    ipv6FilterEntryData["action"]["drop-when"]["payload-length"] = new Object();
                    if(ipv6EntryConfig["pktLenOper"] == "EQUAL")
                    {
                        ipv6FilterEntryData["action"]["drop-when"]["payload-length"]["eq"] = ipv6EntryConfig["pktLenVal1"];
                    }
                    else if(ipv6EntryConfig["pktLenOper"] == "LESS_THAN")
                    {
                        ipv6FilterEntryData["action"]["drop-when"]["payload-length"]["lt"] = ipv6EntryConfig["pktLenVal1"];
                    }
                    else if(ipv6EntryConfig["pktLenOper"] == "GREATER_THAN")
                    {
                        ipv6FilterEntryData["action"]["drop-when"]["payload-length"]["gt"] = ipv6EntryConfig["pktLenVal1"];
                    }
                    else if(ipv6EntryConfig["pktLenOper"] == "RANGE")
                    {
                        ipv6FilterEntryData["action"]["drop-when"]["payload-length"]["range"] = new Object();
                        ipv6FilterEntryData["action"]["drop-when"]["payload-length"]["range"]["start"] = ipv6EntryConfig["pktLenVal1"];
                        ipv6FilterEntryData["action"]["drop-when"]["payload-length"]["range"]["end"] = ipv6EntryConfig["pktLenVal2"];
                    }
                    else
                    {
                        ipv6FilterEntryData["action"]["drop-when"]["payload-length"] = undefined;
                    }
                }
                if(ipv6FilterEntryData["action"]["drop-when"]["hop-limit"] === undefined &&
                    ipv6FilterEntryData["action"]["drop-when"]["payload-length"] === undefined)
                {
                    ipv6FilterEntryData["action"]["drop-when"]["pattern"] = new Object();
                    if(ipv6EntryConfig["patternExp"])
                    {
                        ipv6FilterEntryData["action"]["drop-when"]["pattern"]["expression"] = ipv6EntryConfig["patternExp"];
                    }
                    if(ipv6EntryConfig["patternMask"])
                    {
                        ipv6FilterEntryData["action"]["drop-when"]["pattern"]["mask"] = ipv6EntryConfig["patternMask"];
                    }
                    if(ipv6EntryConfig["patternOffsetType"])
                    {
                        ipv6FilterEntryData["action"]["drop-when"]["pattern"]["offset-type"] =
                            util.transformIntentPatternOffSetType(ipv6EntryConfig["patternOffsetType"]);
                    }
                    if(ipv6EntryConfig["patternOffsetValue"] && ipv6EntryConfig["patternOffsetValue"] != "0")
                    {
                        ipv6FilterEntryData["action"]["drop-when"]["pattern"]["offset-value"] = ipv6EntryConfig["patternOffsetValue"];
                    }
                }
            }
            else if(ipv6EntryConfig['action'] == "ignoreMatch")
            {
                ipv6FilterEntryData['action']['ignore-match'] =  [null]
            }
            else if((ipv6EntryConfig['action'] == "forwardBondingConnection") ||
                (ipv6EntryConfig['action'] == "forwardEsi") ||
                (ipv6EntryConfig['action'] == "forwardRouter") ||
                (ipv6EntryConfig['action'] == "forward") ||
                (ipv6EntryConfig['action'] == "forwardNextHopRouter") ||
                (ipv6EntryConfig['action'] == "forwardLsp") ||
                (ipv6EntryConfig['action'] == "forwardSdp") ||
                (ipv6EntryConfig['action'] == "forwardSap") ||
                (ipv6EntryConfig['action'] == "forwardRedirectFilter") ||
                (ipv6EntryConfig['action'] == "forwardVprnTarget") ||
                (ipv6EntryConfig['action'] == "forwardGre") ||
                (ipv6EntryConfig['action'] == "forwardMplsPlcyEndPoint") ||
                (ipv6EntryConfig['action'] == "forwardSrtePlcyColor") ||
                (ipv6EntryConfig['action'] == "forwardSrv6Plcy"))
            {
                ipv6FilterEntryData["action"]["forward"] = new Object();
                if((ipv6EntryConfig['action'] == "forwardBondingConnection"))
                {
                    ipv6FilterEntryData["action"]["forward"]["bonding-connection"] = ipv6FilterEntryData["fwdBondingConnectionId"];
                }
                else if(ipv6EntryConfig['action'] == "forwardEsi")
                {
                    if(ipv6EntryConfig["fwdEsiVplsServicePointer"])
                    {
                        ipv6FilterEntryData["action"]["forward"]["esi-l2"] = new Object();
                        ipv6FilterEntryData["action"]["forward"]["esi-l2"]["esi-value"] = ipv6EntryConfig["fwdEsiValue"]
                        if(ipv6EntryConfig["fwdEsiVplsServicePointer"])
                        {
                            ipv6FilterEntryData["action"]["forward"]["esi-l2"]["vpls"] = nfmpSuggest.getVPLSName(siteId, ipv6EntryConfig["fwdEsiVplsServicePointer"]);
                        }
                    }
                    else
                    {
                        ipv6FilterEntryData["action"]["forward"]["esi-l3"] = new Object();
                        ipv6FilterEntryData["action"]["forward"]["esi-l3"]["sf-ip"] = ipv6EntryConfig["fwdEsiSfIpV6"]
                        ipv6FilterEntryData["action"]["forward"]["esi-l3"]["esi-value"] = ipv6EntryConfig["fwdEsiValue"]
                        ipv6FilterEntryData["action"]["forward"]["esi-l3"]["vas-interface"] = ipv6EntryConfig["fwdesiVasInterfaceName"]
                        if(ipv6EntryConfig["fwdEsiVprnServicePointer"])
                        {
                            ipv6FilterEntryData["action"]["forward"]["esi-l3"]["vprn"] = nfmpSuggest.getVPRNServiceName(siteId, ipv6EntryConfig["fwdEsiVprnServicePointer"]);
                        }
                    }
                }
                else if(ipv6EntryConfig['action'] == "forwardRouter")
                {
                    if(ipv6EntryConfig["routerType"] == "base")
                    {
                        ipv6FilterEntryData["action"]["forward"]["router-instance"] = "Base";
                    }
                    else
                    {
                        if(ipv6EntryConfig["fwdVprnPointer"])
                        {
                            ipv6FilterEntryData["action"]["forward"]["router-instance"] = nfmpSuggest.getVPRNServiceName(siteId, ipv6EntryConfig["fwdVprnPointer"]);
                        }
                    }
                }
                else if(ipv6EntryConfig['action'] == "forward")
                {
                    if((ipv6EntryConfig["nextHopIndirectlyReachable"] && ipv6EntryConfig["nextHopIndirectlyReachable"] !== "false") || (ipv6EntryConfig["nextHop"] && ipv6EntryConfig["nextHop"] !== "0:0:0:0:0:0:0:0"))
                    {
                        ipv6FilterEntryData["action"]["forward"]["next-hop"] = new Object();
                        ipv6FilterEntryData["action"]["forward"]["next-hop"]["nh-ip"] = new Object();
                        ipv6FilterEntryData["action"]["forward"]["next-hop"]["nh-ip"]["indirect"] = ipv6EntryConfig["nextHopIndirectlyReachable"];
                        ipv6FilterEntryData["action"]["forward"]["next-hop"]["nh-ip"]["address"] = ipv6EntryConfig["nextHop"];
                    }
                    else
                    {
                        ipv6FilterEntryData["action"]["accept"] = [null];
                        ipv6FilterEntryData["action"]["forward"] = undefined;
                    }
                }
                else if(ipv6EntryConfig['action'] == "forwardNextHopRouter")
                {
                    if((ipv6EntryConfig["nextHopIndirectlyReachable"] && ipv6EntryConfig["nextHopIndirectlyReachable"] !== "false") || (ipv6EntryConfig["nextHop"] && ipv6EntryConfig["nextHop"] !== "0:0:0:0:0:0:0:0"))
                    {
                        ipv6FilterEntryData["action"]["forward"]["next-hop"] = new Object();
                        ipv6FilterEntryData["action"]["forward"]["next-hop"]["nh-ip-vrf"] = new Object();
                        ipv6FilterEntryData["action"]["forward"]["next-hop"]["nh-ip-vrf"]["indirect"] = ipv6EntryConfig["nextHopIndirectlyReachable"];
                        ipv6FilterEntryData["action"]["forward"]["next-hop"]["nh-ip-vrf"]["address"] = ipv6EntryConfig["nextHop"];
                        if(ipv6EntryConfig["routerType"] == "base")
                        {
                            ipv6FilterEntryData["action"]["forward"]["next-hop"]["nh-ip-vrf"]["router-instance"] = "Base";
                        }
                        else
                        {
                            if(ipv6EntryConfig["fwdVprnPointer"])
                            {
                                ipv6FilterEntryData["action"]["forward"]["next-hop"]["nh-ip-vrf"]["router-instance"] = nfmpSuggest.getVPRNServiceName(siteId, ipv6EntryConfig["fwdVprnPointer"]);
                            }
                        }
                    }
                }
                else if(ipv6EntryConfig['action'] == "forwardLsp")
                {
                    if(ipv6EntryConfig["fwdLspPointer"])
                    {
                        ipv6FilterEntryData["action"]["forward"]["lsp"] = nfmpSuggest.getLSPName(siteId, ipv6EntryConfig["fwdLspPointer"]);
                    }
                }
                else if(ipv6EntryConfig['action'] == "forwardSdp")
                {
                    ipv6FilterEntryData["action"]["forward"]["sdp"] = new Object();
                    ipv6FilterEntryData["action"]["forward"]["sdp"]["sdp-bind-id"] = ipv6EntryConfig["fwdSdpBindPathId"] + ":" + ipv6EntryConfig["fwdSdpBindVcId"];
                }
                else if(ipv6EntryConfig['action'] == "forwardSap")
                {
                    ipv6FilterEntryData["action"]["forward"]["sap"] = new Object();
                    let sapId = "";
                    sapId = ipv6EntryConfig["fwdSapPortName"];
                    if(ipv6EntryConfig["fwdSapOuterEncapValue"])
                    {
                        if(ipv6EntryConfig["fwdSapOuterEncapValue"] == "4095")
                        {
                            sapId = sapId + ":*";
                        }
                        else
                        {
                            sapId = sapId + ":" + ipv6EntryConfig["fwdSapOuterEncapValue"];
                        }
                    }
                    if(ipv6EntryConfig["fwdSapInnerEncapValue"])
                    {
                        if(ipv6EntryConfig["fwdSapInnerEncapValue"] == "4095")
                        {
                            sapId = sapId + ".*";
                        }
                        else
                        {
                            sapId = sapId + "." + ipv6EntryConfig["fwdSapInnerEncapValue"];
                        }
                    }
                    ipv6FilterEntryData["action"]["forward"]["sap"]["sap-id"] = sapId;
                }
                else if(ipv6EntryConfig['action'] == "forwardRedirectFilter")
                {
                    ipv6FilterEntryData["action"]["forward"]["redirect-policy"] = (ipv6EntryConfig["fwdRedPlcyPointer"]).replace("filterRedirect:", "");
                }
                else if(ipv6EntryConfig['action'] == "forwardVprnTarget")
                {
                    ipv6FilterEntryData["action"]["forward"]["vprn-target"] = new Object();
                    ipv6FilterEntryData["action"]["forward"]["vprn-target"]["bgp-nh"] = ipv6EntryConfig["fwdVprnTgtBgpNHAddr"];
                    if(ipv6EntryConfig["fwdVprnRouterPointer"])
                    {
                        ipv6FilterEntryData["action"]["forward"]["vprn-target"]["vprn"] = nfmpSuggest.getVPRNServiceName(siteId, ipv6EntryConfig["fwdVprnRouterPointer"]);
                    }
                    if(ipv6EntryConfig["fwdVprnTgtLspPointer"])
                    {
                        ipv6FilterEntryData["action"]["forward"]["vprn-target"]["lsp"] = nfmpSuggest.getLSPName(siteId, ipv6EntryConfig["fwdVprnTgtLspPointer"]);
                    }
                    ipv6FilterEntryData["action"]["forward"]["vprn-target"]["adv-prefix"] =
                        ipv6EntryConfig["fwdVprnTgtAdvPrefix"] + "/" + ipv6EntryConfig["fwdVprnTgtAdvPrefixLength"];
                }
                else if(ipv6EntryConfig['action'] == "forwardGre")
                {
                    ipv6FilterEntryData["action"]["forward"]["gre-tunnel"] = (ipv6EntryConfig["fwdGreTunnelPointer"]).replace("GreTunnelTemplate:","");
                }
                else if(ipv6EntryConfig['action'] == "forwardMplsPlcyEndPoint")
                {
                    ipv6FilterEntryData["action"]["forward"]["mpls-policy"] = new Object();
                    ipv6FilterEntryData["action"]["forward"]["mpls-policy"]["endpoint"] = ipv6EntryConfig["fwdMPLSPolicyEndPointAddress"];
                }
                else if(ipv6EntryConfig['action'] == "forwardSrtePlcyColor")
                {
                    ipv6FilterEntryData["action"]["forward"]["srte-policy"] = new Object();
                    ipv6FilterEntryData["action"]["forward"]["srte-policy"]["endpoint"] = ipv6EntryConfig["fwdSrtePlcyEndPointAddress"];
                    ipv6FilterEntryData["action"]["forward"]["srte-policy"]["color"] = ipv6EntryConfig["fwdSRTEPolicyColor"];
                }
                else if(ipv6EntryConfig['action'] == "forwardSrv6Plcy")
                {
                    ipv6FilterEntryData["action"]["forward"]["srv6-policy"] = new Object();
                    ipv6FilterEntryData["action"]["forward"]["srv6-policy"]["endpoint"] = ipv6EntryConfig["fwdSrv6PlcyEndptAddr"];
                    ipv6FilterEntryData["action"]["forward"]["srv6-policy"]["color"] = ipv6EntryConfig["fwdSrv6PlcyColor"];
                    ipv6FilterEntryData["action"]["forward"]["srv6-policy"]["service-sid"] = ipv6EntryConfig["fwdSrv6PlcySvcSid"];
                }

                else
                {
                    //Do Nothing
                }
            }
            else if(ipv6EntryConfig['action'] == "httpredirect")
            {
                ipv6FilterEntryData["action"]["http-redirect"] = new Object();
                if(ipv6EntryConfig["redirectURL"] && ipv6EntryConfig["redirectURL"] != "")
                {
                    ipv6FilterEntryData["action"]["http-redirect"]["url"] = ipv6EntryConfig["redirectURL"];
                }
                if(ipv6EntryConfig["allowRadiusOverride"])
                {
                    ipv6FilterEntryData["action"]["http-redirect"]["allow-override"] = ipv6EntryConfig["allowRadiusOverride"];
                }
            }
            else if(ipv6EntryConfig['action'] == "NAT")
            {
                ipv6FilterEntryData["action"]["nat"] = new Object();
                if(ipv6EntryConfig["natPolicyPointer"] && ipv6EntryConfig["natPolicyPointer"] != "")
                {
                    ipv6FilterEntryData["action"]["nat"]["nat-policy"] = (ipv6EntryConfig["natPolicyPointer"]).replace("natPolicy:nat-", "");
                }
                if(ipv6EntryConfig["natType"])
                {
                    if (ipv6EntryConfig["natType"] == "dsLite")
                    {
                        ipv6FilterEntryData["action"]["nat"]["nat-type"] = "dslite"
                    }
                    else if (ipv6EntryConfig["natType"] == "nat64Lsn")
                    {
                        ipv6FilterEntryData["action"]["nat"]["nat-type"] = "nat64";
                    }
                }
            }
            else if(ipv6EntryConfig['action'] == "tcpMssAdjust")
            {
                ipv6EntryConfig["action"]["tcp-mss-adjust"] = [null];
            }
            else if(ipv6EntryConfig['action'] == "ratelimit")
            {
                ipv6FilterEntryData["action"]["rate-limit"] = new Object();
                if(ipv6EntryConfig["rateLimitMbs"] != "") {
                  if(ipv6EntryConfig["rateLimitMbs"] == "-1") {
                    ipv6FilterEntryData["action"]["rate-limit"]["mbs"] = "auto";
                  }
                  else {
                    ipv6FilterEntryData["action"]["rate-limit"]["mbs"] = ipv6EntryConfig["rateLimitMbs"];
                  }
                }
                if(ipv6EntryConfig["rateLimitUnit"] == "kbps" && ipv6EntryConfig["rateLimit"] != "") {

                  if(ipv6EntryConfig["rateLimit"] == "-1") {
                    ipv6FilterEntryData["action"]["rate-limit"]["pir"] = "max";
                  }
                  else {
                    ipv6FilterEntryData["action"]["rate-limit"]["pir"] = ipv6EntryConfig["rateLimit"];
                  }
                }
                if(ipv6EntryConfig["rateLimitUnit"] == "pps" && ipv6EntryConfig["rateLimitPps"] != "-2") {

                  if(ipv6EntryConfig["rateLimitPps"] == "-1") {
                    ipv6FilterEntryData["action"]["rate-limit"]["pps-pir"] = "max";
                  }
                  else {
                    ipv6FilterEntryData["action"]["rate-limit"]["pps-pir"] = ipv6EntryConfig["rateLimitPps"];
                  }
                  delete ipv6FilterEntryData["action"]["rate-limit"]["mbs"];
                }
                if(ipv6EntryConfig["hoplimitOper"] != "NONE")
                {
                    ipv6FilterEntryData["action"]["rate-limit"]["hop-limit"] = new Object();
                    if(ipv6EntryConfig["hoplimitOper"] == "EQUAL")
                    {
                        ipv6FilterEntryData["action"]["rate-limit"]["hop-limit"]["eq"] = ipv6EntryConfig["hoplimitVal1"];
                    }
                    else if(ipv6EntryConfig["hoplimitOper"] == "LESS_THAN")
                    {
                        ipv6FilterEntryData["action"]["rate-limit"]["hop-limit"]["lt"] = ipv6EntryConfig["hoplimitVal1"];
                    }
                    else if(ipv6EntryConfig["hoplimitOper"] == "GREATER_THAN")
                    {
                        ipv6FilterEntryData["action"]["rate-limit"]["hop-limit"]["gt"] = ipv6EntryConfig["hoplimitVal1"];
                    }
                    else if(ipv6EntryConfig["hoplimitOper"] == "RANGE")
                    {
                        ipv6FilterEntryData["action"]["rate-limit"]["hop-limit"]["range"] = new Object();
                        ipv6FilterEntryData["action"]["rate-limit"]["hop-limit"]["range"]["start"] = ipv6EntryConfig["hoplimitVal1"];
                        ipv6FilterEntryData["action"]["rate-limit"]["hop-limit"]["range"]["end"] = ipv6EntryConfig["hoplimitVal2"];
                    }
                    else
                    {
                        ipv6FilterEntryData["action"]["rate-limit"]["hop-limit"] = undefined;
                    }
                }

                if(ipv6EntryConfig["pktLenOper"] != "NONE")
                {
                    ipv6FilterEntryData["action"]["rate-limit"]["payload-length"] = new Object();
                    if(ipv6EntryConfig["pktLenOper"] == "EQUAL")
                    {
                        ipv6FilterEntryData["action"]["rate-limit"]["payload-length"]["eq"] = ipv6EntryConfig["pktLenVal1"];
                    }
                    else if(ipv6EntryConfig["pktLenOper"] == "LESS_THAN")
                    {
                        ipv6FilterEntryData["action"]["rate-limit"]["payload-length"]["lt"] = ipv6EntryConfig["pktLenVal1"];
                    }
                    else if(ipv6EntryConfig["pktLenOper"] == "GREATER_THAN")
                    {
                        ipv6FilterEntryData["action"]["rate-limit"]["payload-length"]["gt"] = ipv6EntryConfig["pktLenVal1"];
                    }
                    else if(ipv6EntryConfig["pktLenOper"] == "RANGE")
                    {
                        ipv6FilterEntryData["action"]["rate-limit"]["payload-length"]["range"] = new Object();
                        ipv6FilterEntryData["action"]["rate-limit"]["payload-length"]["range"]["start"] = ipv6EntryConfig["pktLenVal1"];
                        ipv6FilterEntryData["action"]["rate-limit"]["payload-length"]["range"]["end"] = ipv6EntryConfig["pktLenVal2"];
                    }
                    else
                    {
                        ipv6FilterEntryData["action"]["rate-limit"]["payload-length"] = undefined;
                    }
                }

                if(ipv6FilterEntryData["action"]["rate-limit"]["hop-limit"] === undefined &&
                    ipv6FilterEntryData["action"]["rate-limit"]["payload-length"] === undefined)
                {
                    ipv6FilterEntryData["action"]["rate-limit"]["pattern"] = new Object();
                    if(ipv6EntryConfig["patternExp"])
                    {
                        ipv6FilterEntryData["action"]["rate-limit"]["pattern"]["expression"] = ipv6EntryConfig["patternExp"];
                    }
                    if(ipv6EntryConfig["patternMask"])
                    {
                        ipv6FilterEntryData["action"]["rate-limit"]["pattern"]["mask"] = ipv6EntryConfig["patternMask"];
                    }
                    ipv6FilterEntryData["action"]["rate-limit"]["pattern"]["offset-type"] =
                        util.transformIntentPatternOffSetType(ipv6EntryConfig["patternOffsetType"]);
                    ipv6FilterEntryData["action"]["rate-limit"]["pattern"]["offset-value"] = ipv6EntryConfig["patternOffsetValue"];
                }
                if(ipv6FilterEntryData["rateLimitExtractedTraffic"])
                {
                    ipv6FilterEntryData["action"]["rate-limit"]["pattern"] = undefined;
                    ipv6FilterEntryData["action"]["rate-limit"]["extracted-traffic-case"] = [null];
                }
            }
            else if(ipv6EntryConfig['action'] == "forwardWhen")
            {
                ipv6FilterEntryData["action"]["accept-when"] = new Object();
                ipv6FilterEntryData["action"]["accept-when"]["pattern"] = new Object();
                if(ipv6EntryConfig["patternExp"])
                {
                    ipv6FilterEntryData["action"]["accept-when"]["pattern"]["expression"] = ipv6EntryConfig["patternExp"];
                }
                if(ipv6EntryConfig["patternMask"])
                {
                    ipv6FilterEntryData["action"]["accept-when"]["pattern"]["mask"] = ipv6EntryConfig["patternMask"];
                }
                ipv6FilterEntryData["action"]["accept-when"]["pattern"]["offset-type"] =
                    util.transformNfmpPatternOffSetType(ipv6EntryConfig["patternOffsetType"]);
                ipv6FilterEntryData["action"]["accept-when"]["pattern"]["offset-value"] = ipv6EntryConfig["patternOffsetValue"];
            }
            else
            {
                //Do Nothing
            }
            if(ipv6EntryConfig["extendedAction"] == "remarkDscp" && ipv6EntryConfig["actionRemarkDscp"])
            {
                ipv6FilterEntryData['action']["remark"] = new Object();
                ipv6FilterEntryData['action']["remark"]["dscp"] = ipv6EntryConfig["actionRemarkDscp"];
            }

            if(ipv6EntryConfig["secondaryAction"] || ipv6EntryConfig["secondaryExtendedAction"] == "remarkDscp")
            {
                ipv6FilterEntryData['action']["secondary"] = new Object();
                if(ipv6EntryConfig["secondaryAction"] == "forwardNextHopRouter" ||
                    ipv6EntryConfig["secondaryAction"] == "forwardSdp" ||
                    ipv6EntryConfig["secondaryAction"] == "forwardSap" ||
                    ipv6EntryConfig["secondaryAction"] == "forwardVprnTarget")
                {
                    ipv6FilterEntryData['action']["secondary"]["forward"] = new Object();
                    if(ipv6EntryConfig["secondaryAction"] == "forwardNextHopRouter")
                    {
                        ipv6FilterEntryData['action']["secondary"]["forward"]["next-hop"] = new Object();
                        ipv6FilterEntryData['action']["secondary"]["forward"]["next-hop"]["nh-ip-vrf"] = new Object();
                        ipv6FilterEntryData['action']["secondary"]["forward"]["next-hop"]["nh-ip-vrf"]["address"] = ipv6EntryConfig["secondaryNextHop"];
                        ipv6FilterEntryData['action']["secondary"]["forward"]["next-hop"]["nh-ip-vrf"]["indirect"] = ipv6EntryConfig["secondaryNextHopIndirect"];
                        if(ipv6EntryConfig["secondaryRouterType"] == "base")
                        {
                            ipv6FilterEntryData['action']["secondary"]["forward"]["next-hop"]["nh-ip-vrf"]["router-instance"] = "Base";
                        }
                        else
                        {
                            if(ipv6EntryConfig["secondaryRouterType"])
                            {
                                ipv6FilterEntryData['action']["secondary"]["forward"]["next-hop"]["nh-ip-vrf"]["router-instance"] =
                                                                nfmpSuggest.getVPRNServiceName(siteId, ipv6EntryConfig["secondaryFwdVprnPointer"]);
                            }
                        }
                    }
                    if(ipv6EntryConfig["secondaryAction"] == "forwardSdp")
                    {
                        ipv6FilterEntryData['action']["secondary"]["forward"]["sdp"] = new Object();
                        ipv6FilterEntryData['action']["secondary"]["forward"]["sdp"]["sdp-bind-id"] =
                            ipv6EntryConfig["secondaryFwdSdpBindPathId"]+":"+ipv6EntryConfig["secondaryFwdSdpBindVcId"];
                    }
                    if(ipv6EntryConfig["secondaryAction"] == "forwardSap")
                    {
                        ipv6FilterEntryData['action']["secondary"]["forward"]["sap"] = new Object();
                        let sapId = "";
                        sapId = ipv6EntryConfig["secondaryFwdSapPortName"];
                        if(ipv6EntryConfig["secondaryFwdSapOuterEncapValue"])
                        {
                            if(ipv6EntryConfig["secondaryFwdSapOuterEncapValue"] == "4095")
                            {
                                sapId = sapId + ":*";
                            }
                            else
                            {
                                sapId = sapId + ":" + ipv6EntryConfig["secondaryFwdSapOuterEncapValue"];
                            }
                        }
                        if(ipv6EntryConfig["secondaryFwdSapInnerEncapValue"])
                        {
                            if(ipv6EntryConfig["secondaryFwdSapInnerEncapValue"] == "4095")
                            {
                                sapId = sapId + ".*";
                            }
                            else
                            {
                                sapId = sapId + "." + ipv6EntryConfig["secondaryFwdSapInnerEncapValue"];
                            }
                        }
                        ipv6FilterEntryData['action']["secondary"]["forward"]["sap"]["sap-id"] = sapId;
                    }
                    if(ipv6EntryConfig["secondaryAction"] == "forwardVprnTarget")
                    {
                        ipv6FilterEntryData['action']["secondary"]["forward"]["vprn-target"] = new Object();
                        ipv6FilterEntryData["action"]["secondary"]["forward"]["vprn-target"]["bgp-nh"] = ipv6EntryConfig["secondaryFwdVprnTgtBgpNHAddr"];
                        if(ipv6EntryConfig["secondaryFwdVprnRouterPointer"])
                        {
                            ipv6FilterEntryData["action"]["secondary"]["forward"]["vprn-target"]["vprn"] = nfmpSuggest.getVPRNServiceName(siteId, ipv6EntryConfig["secondaryFwdVprnRouterPointer"]);
                        }
                        if(ipv6EntryConfig["secondaryVprnTgtLspPointer"])
                        {
                            ipv6FilterEntryData["action"]["secondary"]["forward"]["vprn-target"]["lsp"] = nfmpSuggest.getLSPName(siteId, ipv6EntryConfig["secondaryVprnTgtLspPointer"]);
                        }
                        ipv6FilterEntryData["action"]["secondary"]["forward"]["vprn-target"]["adv-prefix"] =
                            ipv6EntryConfig["secondaryVprnTgtAdvPrefix"] + "/" + ipv6EntryConfig["secondaryVprnTgtAdvPrefixLength"];
                    }

                }
                if(ipv6EntryConfig["secondaryExtendedAction"] == "remarkDscp")
                {
                    ipv6FilterEntryData['action']["secondary"]["remark"] = new Object();
                    ipv6FilterEntryData['action']["secondary"]["remark"]["dscp"] = ipv6EntryConfig["secondaryActionRemarkDscp"];
                }
            }
            this.clearEmptiesAndNull(ipv6FilterEntryData);
            ipFilterEntryArray.push(ipv6FilterEntryData);
        }
        return ipFilterEntryArray;
    }

    this.extractIPv6FilterProperties = function(defaultTargetData, ipFilterConfig)
    {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++) {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object') {
                let mappings = modelDeviceMapping.getMapping("IPv6filter");
                this.traverseAndUpdateConfig(targetKey, targetObj, ipFilterConfig, mappings);
            }
        }
    }

    this.extractIPv6FilterEmbedFilterProperties = function(ipv6FilterEmbedFilterEntryData, ipv6FilterEmbedFilterConfig)
    {
        let ipv6FilterEmbedFilterEntryArray = [];
        let ipv6FilterEntryEmbedFilterDefaults = ipv6FilterEmbedFilterEntryData[0];
        for (let i = 0; i < ipv6FilterEmbedFilterConfig.length; i++)
        {
            let ipv6EntryEmbedFilterConfig = ipv6FilterEmbedFilterConfig[i];
            let ipv6FilterEntryEmbedFilterData = JSON.parse(JSON.stringify(ipv6FilterEntryEmbedFilterDefaults));
            if(ipv6EntryEmbedFilterConfig["offset"])
            {
                ipv6FilterEntryEmbedFilterData["offset"] = ipv6EntryEmbedFilterConfig["offset"];
            }
            if(ipv6EntryEmbedFilterConfig["adminState"] === "active")
            {
                ipv6FilterEntryEmbedFilterData["admin-state"] = "enable";
            }
            else
            {
                ipv6FilterEntryEmbedFilterData["admin-state"] = "disable";
            }

            if(ipv6EntryEmbedFilterConfig["embeddedFilterId"] && ipv6EntryEmbedFilterConfig["embeddedFilterId"] != 0)
            {
                let filterName = nfmpSuggest.getFilterName(ipv6EntryEmbedFilterConfig["siteId"], ipv6EntryEmbedFilterConfig["embeddedFilterId"]);
                ipv6FilterEntryEmbedFilterData["name"] = filterName;
            }
            ipv6FilterEmbedFilterEntryArray.push(ipv6FilterEntryEmbedFilterData);
        }
        return ipv6FilterEmbedFilterEntryArray;
    }

    this.extractIPv6FilterEmbedFlowSpecProperties = function(defaultTargetData, ipv6FilterEmbedFlowSpecConfig)
    {
        let ipv6FilterEmbedFlowSpecEntryArray = [];
        let ipv6FilterEntryEmbedFlowSpecDefaults = defaultTargetData[0];
        for (let i = 0; i < ipv6FilterEmbedFlowSpecConfig.length; i++)
        {
            let ipv6EntryEmbedFlowSpecConfig = ipv6FilterEmbedFlowSpecConfig[i];
            let siteId = ipv6EntryEmbedFlowSpecConfig["siteId"];
            let ipv6FilterEntryEmbedFlowSpecData = JSON.parse(JSON.stringify(ipv6FilterEntryEmbedFlowSpecDefaults));
            if(ipv6EntryEmbedFlowSpecConfig["offset"])
            {
                ipv6FilterEntryEmbedFlowSpecData["offset"] = ipv6EntryEmbedFlowSpecConfig["offset"];
            }
            if(ipv6EntryEmbedFlowSpecConfig["adminState"] === "active")
            {
                ipv6FilterEntryEmbedFlowSpecData["admin-state"] = "enable";
            }
            else
            {
                ipv6FilterEntryEmbedFlowSpecData["admin-state"] = "disable";
            }
            if(ipv6EntryEmbedFlowSpecConfig["groupId"] && ipv6EntryEmbedFlowSpecConfig["groupId"] != 65535)
            {
                ipv6FilterEntryEmbedFlowSpecData["group"] = ipv6EntryEmbedFlowSpecConfig["groupId"];
            }
            if(ipv6EntryEmbedFlowSpecConfig["routerType"] == "base")
            {
                ipv6FilterEntryEmbedFlowSpecData["router-instance"] = "Base";
            }
            else
            {
                if(ipv6EntryEmbedFlowSpecConfig["vprnPointer"])
                {
                    ipv6FilterEntryEmbedFlowSpecData["router-instance"] = nfmpSuggest.getVPRNServiceName(siteId, ipv6EntryEmbedFlowSpecConfig["vprnPointer"]);
                }
            }
            ipv6FilterEmbedFlowSpecEntryArray.push(ipv6FilterEntryEmbedFlowSpecData);
        }
        return ipv6FilterEmbedFlowSpecEntryArray;
    }

    this.traverseAndUpdateConfig = function(objKey, obj, parsedDeviceConfig, mappings)
    {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];

            let mappedKey = objKey + "." + key;
            if (mappedKey !== "ipv6-filter.entry")
            {
                if (value != null && typeof value === 'object')
                {
                    this.traverseAndUpdateConfig(mappedKey, value, parsedDeviceConfig, mappings);
                }
                else
                {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }


    this.getAndUpdateFromDeviceConfig = function(mappings, mappedKey, targetKey, targetObj, parsedDeviceConfig) {
        // Get the key from mapping against targetKey
        // If the mapping key is not undefined, Get the value from deviceKey
        // if the value from deviceConfig against that mapping key is not n
        let nfmpKey = mappings[mappedKey];
        let deviceValue = parsedDeviceConfig[nfmpKey];

        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue, parsedDeviceConfig);

    }

    this.transformDeviceValue = function(mappedKey, deviceValue, parsedDeviceConfig) {
        if (deviceValue !== null) {
            switch (mappedKey)
            {
                case "ipv6-filter.default-action":
                    deviceValue = util.transformIntentDefaultAction(deviceValue);
                    break;
                case "ipv6-filter.type":
                    deviceValue = util.transformIntentFilterType(deviceValue);
                    break;
                default:
            }
            return deviceValue;
        }
    }

    this.constructSearchString = function (neId, filterId, filterName) {
        let searchJson = {
            "fullClassName": "aclfilter.Ipv6Filter",
            "filter":{
                "and":{
                    "equal":[{
                        "name":"siteId",
                        "value": neId
                    },
                    {
                        "name":"id",
                        "value": filterId
                    },
                    {
                        "name":"filterName",
                        "value": filterName
                    }]
                }
            }
        };
        return searchJson;
    }

    this.clearEmptiesAndNull = function (o)
    {
        for (let k in o)
        {
            if(!Array.isArray(o) && o[k] === null)
            {
                delete o[k];
            }
            if (!o[k] || typeof o[k] !== "object")
            {
                continue
            }

            this.clearEmptiesAndNull(o[k]);
            if (Object.keys(o[k]).length === 0)
            {
                delete o[k];
            }
        }
    }

    this.isObjectExists = function (obj) {
        return obj !== undefined && obj !== null;
    }
}
