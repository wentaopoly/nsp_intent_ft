{
  "ietf-yang-patch:yang-patch": {
    "patch-id": "generic-patch-${timestamp}",
    "edit": [
      {
        "operation": "replace",
        "edit-id": "edit-${timestamp}",
        "target": "${target}",
        "value": {"${intentContainerWithModule}":${configData}
      }
      }
    ]
  }
}