var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk'});
load({script: resourceProvider.getResource('traverse-fwk.js'), name: 'TraverseFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities" });
function MdcIntentFwk() {
    var intentDeviationObj = new IntentDeviceDeviation();
     var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,5}(:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){6}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(\/(0|[1-9][0-9]?|1[0-1][0-9]?|12[0-8]))?$/;
     var util = new utilities();
    this.restResponseHandler = function (exception, httpStatus, response) {
        logger.info("[IntentMgr] REST response : " + response);
        logger.info("[IntentMgr] REST httpStatus : " + httpStatus);
        if (exception) {
            throw new RuntimeException("Couldn't connect to device proxy for ; Response: " + response);
        }
        if (httpStatus !== 200 && httpStatus !== 201) {
            throw new RuntimeException("Failed to access device  using MDC; Response: " + response);
        }
        restResponse = JSON.parse(response);
    };

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, cpmTopologyObj) {

        var traverseFwk = new TraverseFwk();
        var parseTarget = new ParseTarget();
        var target = parseTarget.getNeIdFromTarget(input.getTarget());

        // saved topology
        var savedTopology = input.getCurrentTopology();

        if (savedTopology == null) {
            savedTopology = topologyFactory.createServiceTopology();
        }

        if (input.getNetworkState().name() == "delete") {
            logger.info(JSON.stringify(savedTopology));
            traverseFwk.resetTheVariables();
            var requests = [];

            var deleteCpmIPfilterObj = {};
            deleteCpmIPfilterObj["operation"] = "delete";
            deleteCpmIPfilterObj["edit-id"] = "edit-" + new Date().getTime();
            deleteCpmIPfilterObj["target"] = "nokia-conf:/" + parentXpath + "/" + 'cpm-filter/ip-filter';
            requests.push(deleteCpmIPfilterObj)
            result = traverseFwk.syncRequest(target, requests, result, cpmTopologyObj.getSavedTopologyCpmFilter());

            var deleteCpmIPv6filterObj = {};
            deleteCpmIPv6filterObj["operation"] = "delete";
            deleteCpmIPv6filterObj["edit-id"] = "edit-" + new Date().getTime();
            deleteCpmIPv6filterObj["target"] = "nokia-conf:/" + parentXpath + "/" + 'cpm-filter/ipv6-filter';
            requests.push(deleteCpmIPv6filterObj)
            result = traverseFwk.syncRequest(target, requests, result, cpmTopologyObj.getSavedTopologyCpmFilter());

            var deleteCpmQueueObj = {};
            deleteCpmQueueObj["operation"] = "delete";
            deleteCpmQueueObj["edit-id"] = "edit-" + new Date().getTime();
            deleteCpmQueueObj["target"] = "nokia-conf:/" + parentXpath + "/" + 'cpm-queue'
            requests.push(deleteCpmQueueObj)
            result = traverseFwk.syncRequest(target, requests, result, cpmTopologyObj.getSavedTopologyCpmQueue());

            result.setTopology(null);
            return result;
        }

        var cpmObjs = ['cpm-queue', 'cpm-filter'];
        for (var i = 0; i < cpmObjs.length; i++) {
            var cpmObj = cpmObjs[i];
            if (cpmObj === 'cpm-queue') {
                if (target !== "0.0.0.0") {
                    var intentConfig;
                    intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][cpmObj];
                    if (intentConfig != undefined && intentConfig !== "") {

                        var savedTopology = cpmTopologyObj.getSavedTopologyCpmQueue();
                        savedTopology = traverseFwk.traverse(target, intentConfig, savedTopology, null, parentXpath, cpmObj);
                        cpmTopologyObj.setSavedTopologyCpmQueue(savedTopology);

                        //sorting delete array
                        var deleteRequests = traverseFwk.getDeleteRequests();
                        deleteRequests.sort(function (a, b) {
                            return b["target"].length - a["target"].length;
                        });

                        // concating createrequests and deleterequests
                        var createRequests = traverseFwk.getCreateRequests();
                        var requests;
                        if (deleteRequests && createRequests) {
                            requests = createRequests.concat(deleteRequests);
                        }
                        if (requests) {
                            result = traverseFwk.syncRequest(target, requests, result, savedTopology);
                        }

                        if (!result['success']) {
                            traverseFwk.resetTheVariables();
                            return result;
                        }

                    }
                }
            }

            if (cpmObj === 'cpm-filter') {
                if (target !== "0.0.0.0") {
                    var intentConfig;
                    intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][cpmObj];
                    if (intentConfig) {
                        intentConfig = intentDeviationObj.removeIntentConfig(intentConfig, target);
                        var savedTopology = cpmTopologyObj.getSavedTopologyCpmFilter();
                        savedTopology = traverseFwk.traverse(target, intentConfig, savedTopology, null, parentXpath, cpmObj);
                        cpmTopologyObj.setSavedTopologyCpmFilter(savedTopology);

                        //sorting delete array
                        var deleteRequests = traverseFwk.getDeleteRequests();
                        deleteRequests.sort(function (a, b) {
                            return b["target"].length - a["target"].length;
                        });

                        // concating createrequests and deleterequests
                        var createRequests = traverseFwk.getCreateRequests();
                        var requests;
                        if (deleteRequests && createRequests) {
                            requests = createRequests.concat(deleteRequests);
                        }
                        if (requests) {
                            result = traverseFwk.syncRequest(target, requests, result, savedTopology);
                        }
                        traverseFwk.resetTheVariables();
                    }
                }
            }
        }

        return result;
    }

    this.audit = function (target, config, svcTopo, adminState, report, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, cpmTopologyObj) {
        var parseTarget = new ParseTarget();

        var cpmObjs = ['cpm-filter', 'cpm-queue'];
        for (var i = 0; i < cpmObjs.length; i++) {
            var cpmObj = cpmObjs[i];
            var currentConfig;
            var traverseFwk = new TraverseFwk();

            currentConfig = this.xml2object(config)['configuration'][intentTypeName][cpmObj];
            currentConfig = this.expandIPv6(currentConfig);
            var targetNeId = parseTarget.getNeIdFromTarget(target);
            if (targetNeId !== "0.0.0.0") {

                if (cpmObj === 'cpm-filter') {
                    currentConfig = intentDeviationObj.removeIntentConfig(currentConfig, targetNeId);
                    svcTopo = cpmTopologyObj.getSavedTopologyCpmFilter();
                }

                if (cpmObj === 'cpm-queue') {
                    svcTopo = cpmTopologyObj.getSavedTopologyCpmQueue();
                }

                svcTopo = traverseFwk.traverse(targetNeId, currentConfig, svcTopo, report, parentXpath, cpmObj);
                // reseting the variables
                traverseFwk.resetTheVariables();
            }
        }

        return report;

    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }

    this.expandIPv6 = function (obj) {
        for (var key in obj) {
            if (typeof obj[key] === 'object' && obj[key] !== null) {
                this.expandIPv6(obj[key]);
            } else if (typeof obj[key] === 'string' && this.matchExact(ipv6Regex, obj[key])) {
                obj[key] = this.expandIPv6AddressForMd(obj[key]);
            }
        }
      return obj
    }

    this.matchExact = function(r, str) {
        var match = str.match(r);
        return match && str === match[0];
    }

    this.expandIPv6AddressForMd = function (input) {
        var expanded = util.expandIPv6ForMd(input);
        expanded = util.MdIpv6ValidAddresssMaskSupport(expanded).toLowerCase();
        return expanded;
    };
}
