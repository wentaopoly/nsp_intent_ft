<#ftl output_format="JSON">
<#setting number_format="computer">
{
    "path-name": "${extraParams.name}",
    <#if extraParams.name != "hopless" && extraParams["explicit-route-objects-always"]["route-object-include-exclude"].length != 0 >
    "hop": [
    <#list extraParams["explicit-route-objects-always"]["route-object-include-exclude"]?values as value>
        {
            "hop-index": ${value.index},
            "ip-address": "${value.numbered\-node\-hop.node\-id}",
            "type": "${value.numbered\-node\-hop.hop\-type}"
        }<#if value?has_next>,</#if>
    </#list>
    ],
    </#if>
    "admin-state": "enable"
}
