load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {
  this.setErrorResult = function (result) {
    result.setSuccess(false);
    result.setErrorCode(100);
    result.setErrorDetail("failed To set Topology.");
    return result
  }

  this.setSuccessResult = function (result,savedTopology) {
    result.setSuccess(true);
    if (savedTopology !== undefined){
      result.setTopology(savedTopology);
    }
    return result;
  }

  this.xml2object = function(xmlElement) {
    var lXml = Java.type("org.json.XML");
    var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
    var serializer = lsImpl.createLSSerializer();
    serializer.getDomConfig().setParameter("xml-declaration", false);
    var  str = serializer.writeToString(xmlElement);
    var  json = lXml.toJSONObject(str).toString();
    logger.info('inp json: '+ json)
    return JSON.parse(json);
  }

  this.extractInfo = function (topology, key,i) {
    var values;
    if (topology != null && topology.getXtraInfo() != null) {
      topology.getXtraInfo().forEach(function (extraInfo) {
        if (extraInfo.getKey() == key) {
          var value = extraInfo.getValue();
          values = value.split(",")

        }
      });
    }

    if (values === undefined)
      return values
    else
      return values[i];
  }

  this.reportMisaligned = function (target, result, auditReport) {
    var report = JSON.parse(result.response);
    if (!report.aligned) {
      for (var i = 0; i < report.misalignedAttributes.length; i++) {
        var attributeData = report.misalignedAttributes[i];
        if (attributeData.expected == "present") {
          //misaligned object
          var objectDn = attributeData.name;
          var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
          auditReport.addMisAlignedObject(misalignedObject);
        }
        else if (attributeData.expected == "not present") {
          //undesired object
          var objectDn = attributeData.name;
          var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
          auditReport.addMisAlignedObject(misalignedObject);
        }
        else {
          var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
          auditReport.addMisAlignedAttribute(misalignedAttribute);
        }
      }
    }
    return auditReport
  }

  this.editPayload = function(fdn, properties, childProperties, fullClassName, objectFullName){
    var payload  = {};
    var configInfo = {};
    configInfo[fullClassName] = properties;
    if(childProperties != null)
    {
      configInfo[fullClassName]["children-Set"] = childProperties;
    }
    //payload["fdn"] = fdn;
    payload["distinguishedName"] = fdn;
    payload["objectFullName"] = objectFullName;
    payload["clearOnDeployFailure"] = true;
    payload["configInfo"] = configInfo;
    logger.info(LOG_PREFIX + "All final payload : " + JSON.stringify(payload));
    return payload;
  }

  /*
   function: getServiceCustomerId
   description: Getting the Customer id from target.
   */
  this.getServiceCustomerId = function (target) {
    var customerId = target.split("#")[3];
    return customerId;
  }

  /*
   function: getServiceCustomerName
   description: Getting the Customer Name from target.
   */
  this.getServiceCustomerName = function (target) {
    var customerName = target.split("#")[2];
    return customerName;
  }

  /*
   function: getIfSubscriberObjectExists
   description: returns the Subscriber Object for objectFullName if exists.
   */
  this.getIfSubscriberObjectExists = function(className, objectFullName) {

    let nfmpFwk = new NfmpFwk();
    var expectedJson = {
      "fullClassName": className,
      "filter":{
        "equal":{
          "name":"objectFullName",
          "value": objectFullName
        }
      },
      "resultFilter": {

      }
    };
    var ret = false;
    var resultFetch = nfmpFwk.post("/v3/search", expectedJson);
    logger.info(LOG_PREFIX + "Subscriber search results : " + JSON.stringify(resultFetch));
    var finalResponse = JSON.parse(resultFetch.response);
    logger.info(LOG_PREFIX + "********Extracted Search results : " + JSON.stringify(finalResponse));
    if (JSON.stringify(finalResponse) === JSON.stringify({})) {
      logger.info(LOG_PREFIX + "Search results is empty: " + JSON.stringify(finalResponse));
      finalResponse = null;
    }
    else if (!Array.isArray(finalResponse)) {
      finalResponse = [finalResponse];
      logger.info(LOG_PREFIX + "Search results: " + JSON.stringify(finalResponse));
    }
    return finalResponse;
  }

  /*
   function: getIfSubscriberSiteObjectExists
   description: returns the Subscriber Site Object for objectFullName if exists.
   */
  this.getIfSubscriberSiteObjectExists = function(className, objectFullName) {

    let nfmpFwk = new NfmpFwk();
    var expectedJson = {
      "fullClassName": className,
      "filter":{
        "equal":{
          "name":"objectFullName",
          "value": objectFullName
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          "subscriberSiteId",
        ]
      }
    };
    var ret = false;
    var resultFetch = nfmpFwk.post("/v3/search", expectedJson);
    logger.info(LOG_PREFIX + "Subscriber search results : " + JSON.stringify(resultFetch));
    var finalResponse = JSON.parse(resultFetch.response);
    logger.info(LOG_PREFIX + "********Extracted Search results : " + JSON.stringify(finalResponse));
    if (JSON.stringify(finalResponse) === JSON.stringify({})) {
      logger.info(LOG_PREFIX + "Search results is empty: " + JSON.stringify(finalResponse));
      finalResponse = null;
    }
    else if (!Array.isArray(finalResponse)) {
      finalResponse = [finalResponse];
      logger.info(LOG_PREFIX + "Search results: " + JSON.stringify(finalResponse));
    }
    return finalResponse;
  }

  /*
   function: getSubscriberSiteList
   description: returns the Subscriber Site List under the Subscriber Object.
   */
  this.getSubscriberSiteList = function(className, objectFullName){

    let nfmpFwk = new NfmpFwk();
    var expectedJson = {
      "fullClassName": className,
      "filter":{
        "equal":{
          "name":"objectFullName",
          "value": objectFullName
        }
      },
      "resultFilter": {
        "attribute": [
          "children-Set"
        ]
      }
    };
    var ret = false;
    var resultFetch = nfmpFwk.post("/v3/search", expectedJson);
    logger.info(LOG_PREFIX + "Subscriber Site Search results : " + JSON.stringify(resultFetch));
    var finalResponse = JSON.parse(resultFetch.response)["subscr.Subscriber"]["children-Set"]["subscr.Site"];
    logger.info(LOG_PREFIX + "********Extracted Search results : " + JSON.stringify(finalResponse));
    if (JSON.stringify(finalResponse) === JSON.stringify({})) {
      logger.info(LOG_PREFIX + "Search results is empty: " + JSON.stringify(finalResponse));
      finalResponse = null;
    }
    else if (!Array.isArray(finalResponse)) {
      finalResponse = [finalResponse];
      logger.info(LOG_PREFIX + "Search results: " + JSON.stringify(finalResponse));
    }
    return finalResponse;
  }

}
