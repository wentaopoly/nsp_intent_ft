function IntentConfigValueReplacer() {

    this.replaceConfigValue = function (intentConfig) {

        var interntValueReplaceDataObj = undefined;
        try {
            interntValueReplaceDataObj = this.getIntentValueReplaceData();
        } catch (err) {
            return intentConfig;
        }
        logger.info("Intent Config Value Replace")
        var intentConfigValueReplaceAttributes = interntValueReplaceDataObj['intentConfigValueReplaceAttributes'];
        for (var i = 0; i < intentConfigValueReplaceAttributes.length; i++) {
            var obj = intentConfigValueReplaceAttributes[i];
            logger.info("attributeName : " + obj['attributeName'] + ", configValue : " + obj['configValue'] + ", replaceValue : " + obj['replaceValue'])
            replaceValue(intentConfig, obj['attributeName'], obj['configValue'], obj['replaceValue'], obj['dataType'], obj['parent'], true);
        }

        logger.info(JSON.stringify(intentConfig));
        return intentConfig;
    }

    this.replaceBrownFieldDiscoveryConfigValue = function (intentConfig) {

        var interntValueReplaceDataObj = undefined;
        try {
            interntValueReplaceDataObj = this.getIntentValueReplaceData();
        } catch (err) {
            return intentConfig;
        }
        logger.info("Intent Config Value Replace")
        var intentConfigValueReplaceAttributes = interntValueReplaceDataObj['intentConfigValueReplaceAttributes'];
        for (var i = 0; i < intentConfigValueReplaceAttributes.length; i++) {
            var obj = intentConfigValueReplaceAttributes[i];
            logger.info("attributeName : " + obj['attributeName'] + ", configValue : " + obj['configValue'] + ", replaceValue : " + obj['replaceValue'])
            replaceValue(intentConfig, obj['attributeName'], obj['replaceValue'], obj['configValue'], obj['dataType'], obj['parent'], true);
        }

        logger.info(JSON.stringify(intentConfig));
        return intentConfig;
    }

    function replaceValue(intenetConfig, attributeName, configValue, replaceConfigValue, dataType, parent, replaceFalg) {

        for (var prop in intenetConfig) {
            var attrComp = prop.localeCompare(attributeName) == 0;
            logger.info(prop + "--->" + replaceFalg + "--->" + attrComp)
            if (attrComp && replaceFalg) {
                var intentAttrValue = intenetConfig[prop];
                var configValueCmp = false;
                if (typeof (configValue) == 'string' && typeof (intentAttrValue) == 'string') {
                    configValueCmp = (intentAttrValue.localeCompare(configValue) == 0);
                } else {
                    if (intentAttrValue == configValue) {
                        configValueCmp = true;
                    }
                }

                logger.info("configValueCmp : " + configValueCmp);
                if (configValueCmp) {
                    intenetConfig[prop] = replaceConfigValue;
                    logger.info("intenetConfig[prop] : " + intenetConfig[prop]);
                }

                var dataTypeFlag = dataType.localeCompare('leaf-list') == 0;
                if (dataTypeFlag && !Array.isArray(intentAttrValue)) {
                    intenetConfig[prop] = [intentAttrValue]
                }

            } else if (typeof intenetConfig[prop] === 'object') {
                replaceFalg = (prop.localeCompare(parent) == 0) || (parent.localeCompare('-') == 0);
                logger.info(JSON.stringify(intenetConfig[prop]));
                replaceValue(intenetConfig[prop], attributeName, configValue, replaceConfigValue, dataType, parent, replaceFalg);
            }
        }
    }

    this.getIntentValueReplaceData = function () {
        var interntValueReplaceDataObj = resourceProvider.getResource("intentConfigValueReplaceData.json");
        logger.info("Intent Value Replace Info Data : " + interntValueReplaceDataObj);
        return JSON.parse(interntValueReplaceDataObj);
    }
}
