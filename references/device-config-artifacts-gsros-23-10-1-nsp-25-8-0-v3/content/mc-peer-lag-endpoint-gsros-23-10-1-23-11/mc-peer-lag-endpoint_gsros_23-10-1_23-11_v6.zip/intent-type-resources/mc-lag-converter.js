load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});

function McLagConverter() {

    var intentDeviationObj = new IntentDeviceDeviation();
    var util = new utilities();
    this.convertIntentConfigToDeviceSpecific = function (target, intentConfig, isAudit) {

        var targetAttrs = target.split('#');
        var endPointA = targetAttrs[2];
        var endPointB = targetAttrs[4];
        var endPointAPeer = targetAttrs[3];
        var endPointBPeer = targetAttrs[5];

        var endPointADevice = {
            "ip-address": endPointBPeer,
            "admin-state": intentConfig['endPointADetails']['admin-state'],
            "description": intentConfig['endPointADetails']['description'],
            "peer-name": intentConfig['endPointADetails']['peer-name'],
            "source-address": endPointAPeer,
            "mc-lag": {
                "keep-alive-interval": intentConfig['mc-lag']['endPointADetails']['keep-alive-interval'],
                "admin-state": intentConfig['mc-lag']['endPointADetails']['admin-state'],
                "hold-on-neighbor-failure": intentConfig['mc-lag']['endPointADetails']['hold-on-neighbor-failure']
            },
            "mc-ring": {
                "ring": []
            }
        };

        if (intentConfig['sync']['endPointADetails']) {
            endPointADevice["sync"] = {
                "admin-state": intentConfig['sync']['endPointADetails']['admin-state'],
                "igmp": intentConfig['sync']['endPointADetails']['igmp'],
                "igmp-snooping": intentConfig['sync']['endPointADetails']['igmp-snooping'],
                "ipsec": intentConfig['sync']['endPointADetails']['ipsec'],
                "l2tp": intentConfig['sync']['endPointADetails']['l2tp'],
                "local-dhcp-server": intentConfig['sync']['endPointADetails']['local-dhcp-server'],
                "mc-ring": intentConfig['sync']['endPointADetails']['mc-ring'],
                "mld": intentConfig['sync']['endPointADetails']['mld'],
                "mld-snooping": intentConfig['sync']['endPointADetails']['mld-snooping'],
                "python": intentConfig['sync']['endPointADetails']['python'],
                "srrp": intentConfig['sync']['endPointADetails']['srrp'],
                "sub-host-trk": intentConfig['sync']['endPointADetails']['sub-host-trk'],
                "nat": intentConfig['sync']['endPointADetails']['nat'],
                "pim-snooping": intentConfig['sync']['endPointADetails']['pim-snooping'],
                "sub-mgmt": intentConfig['sync']['endPointADetails']['sub-mgmt'],
                "transport-encryption": intentConfig['sync']['endPointADetails']['transport-encryption'],
                "tags": intentConfig['sync']['endPointADetails']['tags'],
                "tunnel-group": intentConfig['sync']['endPointADetails']['tunnel-group'],
                "track-srrp": intentConfig['sync']['endPointADetails']['track-srrp'],
                "diameter-node": intentConfig['sync']['endPointADetails']['diameter-node']
            };
        }
        let endPointAMcEndpoint = {};
        if(intentConfig['enable-mc-endpoint'])
        {
            endPointAMcEndpoint['admin-state'] = intentConfig['mc-endpoint']['endPointADetails']['admin-state'];
            endPointAMcEndpoint['system-priority'] = intentConfig['mc-endpoint']['endPointADetails']['system-priority'];
            endPointAMcEndpoint['keep-alive-interval'] = intentConfig['mc-endpoint']['endPointADetails']['keep-alive-interval'];
            endPointAMcEndpoint['hold-on-neighbor-failure'] = intentConfig['mc-endpoint']['endPointADetails']['hold-on-neighbor-failure'];
            endPointAMcEndpoint['passive-mode'] = intentConfig['mc-endpoint']['endPointADetails']['passive-mode'];
            endPointAMcEndpoint['boot-timer'] = intentConfig['mc-endpoint']['endPointADetails']['boot-timer'];
            endPointAMcEndpoint['bfd'] = intentConfig['mc-endpoint']['endPointADetails']['bfd'];
            endPointADevice['mc-endpoint'] = endPointAMcEndpoint;
        }
        else
        {
            endPointADevice['mc-endpoint'] = endPointAMcEndpoint;
        }
        let endPointAMcIpsec = {};
        if(intentConfig['enable-mc-ipsec'])
        {   var endPointADetails = intentConfig['mc-ipsec'] && intentConfig['mc-ipsec']['endPointADetails'];
            var tunnelDetails = intentConfig['mc-ipsec'] && intentConfig['mc-ipsec'];
            if(endPointADetails){
                endPointAMcIpsec['bfd-liveness'] = endPointADetails['bfd-liveness'];
                endPointAMcIpsec['keep-alive-interval'] = endPointADetails['keep-alive-interval'];
                endPointAMcIpsec['hold-on-neighbor-failure'] = endPointADetails['hold-on-neighbor-failure'];
                var discoveryIntervalDataA = endPointADetails['discovery-interval'];
                if(discoveryIntervalDataA){
                    endPointAMcIpsec['discovery-interval'] = {}
                    if(discoveryIntervalDataA['interval-secs']){
                        endPointAMcIpsec['discovery-interval']['interval-secs'] = discoveryIntervalDataA['interval-secs'];
                    }
                    if(discoveryIntervalDataA['boot']){
                        endPointAMcIpsec['discovery-interval']['boot'] = discoveryIntervalDataA['boot'];
                    }
                }
                if (endPointADetails['domain']) {
                     var domainADetails = [];
                     if (!Array.isArray(endPointADetails['domain'])) {
                         endPointADetails['domain'] = [endPointADetails['domain']];
                     }
                     for (var index in endPointADetails["domain"]) {
                        var domainListDataA = endPointADetails["domain"][index];
                        var item = {};
                        if (domainListDataA["id"]) {
                            item["id"] = domainListDataA["id"];
                        }
                        if (domainListDataA["admin-state"]) {
                            item["admin-state"] = domainListDataA["admin-state"];
                        }
                        domainADetails.push(item);
                     }
                    endPointAMcIpsec['domain'] = domainADetails;
                }
                if (tunnelDetails['tunnelGroup']) {
                    var tunnelGroupConfigA = [];
                     if (!Array.isArray(tunnelDetails['tunnelGroup'])) {
                         tunnelDetails['tunnelGroup'] = [tunnelDetails['tunnelGroup']];
                     }
                    for (var index in tunnelDetails["tunnelGroup"]) {
                        let tunnelGroupDataA = tunnelDetails["tunnelGroup"][index];
                        var item = {};
                        if (tunnelGroupDataA["firstTunnelGroupId"]) {
                            item["tunnel-group-id"] = tunnelGroupDataA["firstTunnelGroupId"];
                        }
                        if (tunnelGroupDataA["firstSiteAdministrativeState"]) {
                            item["admin-state"] =  util.convertToIntentAdminstarteState(tunnelGroupDataA["firstSiteAdministrativeState"]);
                        }
                        if (tunnelGroupDataA["firstSitePeerGroup"]) {
                            item["peer-group"] = tunnelGroupDataA["firstSitePeerGroup"];
                        }
                        if (tunnelGroupDataA["firstSitePriority"]) {
                            item["priority"] = tunnelGroupDataA["firstSitePriority"];
                        }
                        tunnelGroupConfigA.push(item);
                    }
                    endPointAMcIpsec['tunnel-group'] = tunnelGroupConfigA;
                }
                endPointADevice['mc-ipsec'] = endPointAMcIpsec;
            }
        }
        else
        {
                endPointADevice['mc-ipsec'] = endPointAMcIpsec;
        }
        var lags = this.convertEndpointBLag(intentConfig['mc-lag']['lag'], endPointB);

        if (intentConfig['mc-lag']['lag']) {
            var endPointAlags = [];
            var intentLags = intentConfig['mc-lag']['lag']
            var neFamily = intentDeviationObj.getNeFamilyRelease(endPointA);
            var neVersion = intentDeviationObj.getNeVersion(neFamily);
            if (intentLags && intentLags.length) {
                for (var i = 0; i < intentLags.length; i++) {
                    var lagObj = intentLags[i];
                    if (neVersion.startsWith("19.") || neVersion.startsWith("20.")) {
                        lagObj["lag-index"] = parseInt(lagObj['lag-name']);
                        delete lagObj["lag-name"]
                    }
                    if (lagObj["system-id"]) {
                        lagObj["system-id"] = lagObj["system-id"].replaceAll("-", ":");
                    }
                    endPointAlags.push(lagObj);
                }
            } else {
                var lagObj = intentLags;
                if (neVersion.startsWith("19.") || neVersion.startsWith("20.")) {
                    lagObj["lag-index"] = parseInt(lagObj['lag-name']);
                    delete lagObj["lag-name"];
                }
                if (lagObj["system-id"]) {
                    lagObj["system-id"] = lagObj["system-id"].replaceAll("-", ":");
                }
                endPointAlags.push(lagObj);
            }
            endPointADevice['mc-lag']['lag'] = endPointAlags;

        }
        else
        {
            endPointADevice['mc-lag']['lag'] = []
        }

        if (intentConfig['mc-ring']['ringGroup'])
        {
            if (!Array.isArray(intentConfig["mc-ring"]["ringGroup"]))
            {
                intentConfig["mc-ring"]["ringGroup"] = [intentConfig["mc-ring"]["ringGroup"]];
            }
            var endPointARings = [];
            var intentRings = intentConfig['mc-ring']['ringGroup'];
            if (intentRings && intentRings.length) {
                for (var i = 0; i < intentRings.length; i++) {
                    var ringObj = {};
                    ringObj['sync-tag'] = intentRings[i]['ringName'];
                    var ringIntentConfig = intentRings[i]['endPointADetails']['ring'];
                    ringObj['admin-state'] = ringIntentConfig['admin-state'];
                    ringObj['type'] = ringIntentConfig['type'];
                    if (ringIntentConfig['in-band-control-path']) {
                        ringObj['in-band-control-path'] = ringIntentConfig['in-band-control-path'];
                        delete ringObj['in-band-control-path']['admin-state'];
                    }
                    if(ringIntentConfig['path-b']) {
                        if (!(ringIntentConfig['type'] == "layer-3" && ringIntentConfig['path-b']["wildcard-saps"] == false && Object.keys(ringIntentConfig['path-b']).length == 1))
                            ringObj['path-b'] = ringIntentConfig['path-b'];
                    }

                    if(ringIntentConfig['path-excl']) {
                        if (!(ringIntentConfig['type'] == "layer-3" && ringIntentConfig['path-excl']["wildcard-saps"] == false && Object.keys(ringIntentConfig['path-excl']).length == 1))
                            ringObj['path-excl'] = ringIntentConfig['path-excl'];
                    }
                    if(ringIntentConfig['srrp-instance']) ringObj['srrp-instance'] = ringIntentConfig['srrp-instance'];
                    if (ringIntentConfig['ring-node']) {
                        ringObj['ring-node'] = ringIntentConfig['ring-node'];
                        if (!Array.isArray(ringObj['ring-node']))
                        {
                            ringObj['ring-node'] = [ringObj['ring-node']];
                        }
                        if(ringObj['ring-node'] && ringObj['ring-node'].length){
                            for(var idx in ringObj['ring-node']) {
                                var ringNodeConfig = ringObj['ring-node'][idx];
                                //remove Nfmp Only Properties
                                delete ringNodeConfig['rncvServiceId'];
                                delete ringNodeConfig['rncvOuterEncapValue'];
                                delete ringNodeConfig['rncvInnerEncapValue'];
                            }
                        }
                    }

                    endPointARings.push(ringObj);
                }
            }
            endPointADevice['mc-ring']['ring'] = endPointARings;
        }
        else
        {
            intentConfig['mc-ring']['ring'] = [];
        }

        if (!isAudit) {
            endPointADevice['authentication-key'] = intentConfig['endPointADetails']['authentication-key'];
        }
        logger.info("endPointADevice = {}", JSON.stringify(endPointADevice));

        var endPointBDevice = {
            "ip-address": endPointAPeer,
            "admin-state": intentConfig['endPointBDetails']['admin-state'],
            "description": intentConfig['endPointBDetails']['description'],
            "peer-name": intentConfig['endPointBDetails']['peer-name'],
            "source-address": endPointBPeer,
            "mc-lag": {
                "keep-alive-interval": intentConfig['mc-lag']['endPointBDetails']['keep-alive-interval'],
                "admin-state": intentConfig['mc-lag']['endPointBDetails']['admin-state'],
                "hold-on-neighbor-failure": intentConfig['mc-lag']['endPointBDetails']['hold-on-neighbor-failure'],
                "lag": lags
            },
            "mc-ring": {
                "ring": []
            }
        };

        if (intentConfig['sync']['endPointBDetails']) {
            endPointBDevice["sync"] = {
                "admin-state": intentConfig['sync']['endPointBDetails']['admin-state'],
                "igmp": intentConfig['sync']['endPointBDetails']['igmp'],
                "igmp-snooping": intentConfig['sync']['endPointBDetails']['igmp-snooping'],
                "ipsec": intentConfig['sync']['endPointBDetails']['ipsec'],
                "l2tp": intentConfig['sync']['endPointBDetails']['l2tp'],
                "local-dhcp-server": intentConfig['sync']['endPointBDetails']['local-dhcp-server'],
                "mc-ring": intentConfig['sync']['endPointBDetails']['mc-ring'],
                "mld": intentConfig['sync']['endPointBDetails']['mld'],
                "mld-snooping": intentConfig['sync']['endPointBDetails']['mld-snooping'],
                "python": intentConfig['sync']['endPointBDetails']['python'],
                "srrp": intentConfig['sync']['endPointBDetails']['srrp'],
                "sub-host-trk": intentConfig['sync']['endPointBDetails']['sub-host-trk'],
                "nat": intentConfig['sync']['endPointBDetails']['nat'],
                "pim-snooping": intentConfig['sync']['endPointBDetails']['pim-snooping'],
                "sub-mgmt": intentConfig['sync']['endPointBDetails']['sub-mgmt'],
                "transport-encryption": intentConfig['sync']['endPointBDetails']['transport-encryption'],
                "tags": intentConfig['sync']['endPointBDetails']['tags'],
                "tunnel-group": intentConfig['sync']['endPointBDetails']['tunnel-group'],
                "track-srrp": intentConfig['sync']['endPointBDetails']['track-srrp'],
                "diameter-node": intentConfig['sync']['endPointBDetails']['diameter-node']
            };
        }
        let endPointBMcEndpoint = {};
        if(intentConfig['enable-mc-endpoint'])
        {
            endPointBMcEndpoint['admin-state'] = intentConfig['mc-endpoint']['endPointADetails']['admin-state'];
            endPointBMcEndpoint['system-priority'] = intentConfig['mc-endpoint']['endPointADetails']['system-priority'];
            endPointBMcEndpoint['keep-alive-interval'] = intentConfig['mc-endpoint']['endPointADetails']['keep-alive-interval'];
            endPointBMcEndpoint['hold-on-neighbor-failure'] = intentConfig['mc-endpoint']['endPointADetails']['hold-on-neighbor-failure'];
            endPointBMcEndpoint['passive-mode'] = intentConfig['mc-endpoint']['endPointADetails']['passive-mode'];
            endPointBMcEndpoint['boot-timer'] = intentConfig['mc-endpoint']['endPointADetails']['boot-timer'];
            endPointBMcEndpoint['bfd'] = intentConfig['mc-endpoint']['endPointADetails']['bfd'];
            endPointBDevice['mc-endpoint'] = endPointBMcEndpoint;
        }
        else
        {
            endPointBDevice['mc-endpoint'] = endPointBMcEndpoint;
        }
        let endPointBMcIpsec = {};
        if(intentConfig['enable-mc-ipsec'])
        {   var endPointBDetails = intentConfig['mc-ipsec'] && intentConfig['mc-ipsec']['endPointBDetails'];
            if(endPointBDetails){
                endPointBMcIpsec['bfd-liveness'] = endPointBDetails['bfd-liveness'];
                endPointBMcIpsec['keep-alive-interval'] = endPointBDetails['keep-alive-interval'];
                endPointBMcIpsec['hold-on-neighbor-failure'] = endPointBDetails['hold-on-neighbor-failure'];
                var discoveryIntervalDataB = endPointBDetails['discovery-interval'];
                if(discoveryIntervalDataB){
                    endPointBMcIpsec['discovery-interval'] = {}
                    if(discoveryIntervalDataB['interval-secs']){
                        endPointBMcIpsec['discovery-interval']['interval-secs'] = discoveryIntervalDataB['interval-secs'];
                    }
                    if(discoveryIntervalDataB['boot']){
                        endPointBMcIpsec['discovery-interval']['boot'] = discoveryIntervalDataB['boot'];
                    }
                }
                if (endPointBDetails['domain']) {
                    var domainBDetails = [];
                     if (!Array.isArray(endPointBDetails['domain'])) {
                         endPointBDetails['domain'] = [endPointBDetails['domain']];
                     }
                    for (var index in endPointBDetails["domain"]) {
                        let domainListDataB = endPointBDetails["domain"][index];
                        var item = {};
                        if (domainListDataB["id"]) {
                            item["id"] = domainListDataB["id"];
                        }
                        if (domainListDataB["admin-state"]) {
                            item["admin-state"] = domainListDataB["admin-state"];
                        }
                        domainBDetails.push(item);
                    }
                    endPointBMcIpsec['domain'] = domainBDetails;
                }
                if (tunnelDetails['tunnelGroup']) {
                    var tunnelGroupConfigB = [];
                     if (!Array.isArray(tunnelDetails['tunnelGroup'])) {
                         tunnelDetails['tunnelGroup'] = [tunnelDetails['tunnelGroup']];
                     }
                    for (var index in tunnelDetails["tunnelGroup"]) {
                        var tunnelGroupDataB = tunnelDetails["tunnelGroup"][index];
                        var item = {};
                        if (tunnelGroupDataB["secondTunnelGroupId"]) {
                            item["tunnel-group-id"] = tunnelGroupDataB["secondTunnelGroupId"];
                        }
                        if (tunnelGroupDataB["secondSiteAdministrativeState"]) {
                            item["admin-state"] = util.convertToIntentAdminstarteState(tunnelGroupDataB["secondSiteAdministrativeState"]);
                        }
                        if (tunnelGroupDataB["secondSitePeerGroup"]) {
                            item["peer-group"] = tunnelGroupDataB["secondSitePeerGroup"];
                        }
                        if (tunnelGroupDataB["secondSitePriority"]) {
                            item["priority"] = tunnelGroupDataB["secondSitePriority"];
                        }
                        tunnelGroupConfigB.push(item);
                    }
                    endPointBMcIpsec['tunnel-group'] = tunnelGroupConfigB;
                }
                endPointBDevice['mc-ipsec'] = endPointBMcIpsec;
            }
        }
        else
        {
                endPointBDevice['mc-ipsec'] = endPointBMcIpsec;
        }
        if (!isAudit) {
            endPointBDevice['authentication-key'] = intentConfig['endPointBDetails']['authentication-key'];
        }
        if (intentConfig['mc-ring']['ringGroup'])
        {
            if (!Array.isArray(intentConfig["mc-ring"]["ringGroup"]))
            {
                intentConfig["mc-ring"]["ringGroup"] = [intentConfig["mc-ring"]["ringGroup"]];
            }
            var endPointBRings = [];
            var intentRings = intentConfig['mc-ring']['ringGroup'];
            if (intentRings && intentRings.length) {
                for (var i = 0; i < intentRings.length; i++) {
                    var ringObj = {};
                    ringObj['sync-tag'] = intentRings[i]['ringName'];
                    var ringIntentConfig = intentRings[i]['endPointBDetails']['ring'];
                    ringObj['admin-state'] = ringIntentConfig['admin-state'];
                    ringObj['type'] = ringIntentConfig['type'];
                    if (ringIntentConfig['in-band-control-path']) {
                        ringObj['in-band-control-path'] = ringIntentConfig['in-band-control-path'];
                        //remove Nfmp Only Properties
                        delete ringObj['in-band-control-path']['admin-state'];
                    }
                    if(ringIntentConfig['path-b']) {
                        if (!(ringIntentConfig['type'] == "layer-3" && ringIntentConfig['path-b']["wildcard-saps"] == false && Object.keys(ringIntentConfig['path-b']).length == 1))
                            ringObj['path-b'] = ringIntentConfig['path-b'];
                    }

                    if(ringIntentConfig['path-excl']) {
                        if (!(ringIntentConfig['type'] == "layer-3" && ringIntentConfig['path-excl']["wildcard-saps"] == false && Object.keys(ringIntentConfig['path-excl']).length == 1))
                            ringObj['path-excl'] = ringIntentConfig['path-excl'];
                    }

                    if(ringIntentConfig['srrp-instance']) ringObj['srrp-instance'] = ringIntentConfig['srrp-instance'];
                    if (ringIntentConfig['ring-node']) {
                        ringObj['ring-node'] = ringIntentConfig['ring-node'];
                        if (!Array.isArray(ringObj['ring-node']))
                        {
                            ringObj['ring-node'] = [ringObj['ring-node']];
                        }
                        if(ringObj['ring-node'] && ringObj['ring-node'].length){
                            for(var idx in ringObj['ring-node']) {
                                var ringNodeConfig = ringObj['ring-node'][idx];
                                //remove Nfmp Only Properties
                                delete ringNodeConfig['rncvServiceId'];
                                delete ringNodeConfig['rncvOuterEncapValue'];
                                delete ringNodeConfig['rncvInnerEncapValue'];
                            }
                        }
                    }

                    endPointBRings.push(ringObj);
                }
            }
            endPointBDevice['mc-ring']['ring'] = endPointBRings;
        }
        else
        {
            intentConfig['mc-ring']['ring'] = [];
        }

        logger.info("endPointBDevice = {}", JSON.stringify(endPointBDevice));
        var deviceConfig = {
            "endpointA": endPointADevice,
            "endpointB": endPointBDevice
        };

        logger.info(JSON.stringify(deviceConfig));

        return deviceConfig;
    }

    this.convertEndpointBLag = function (lags, neId) {
        if(lags && !Array.isArray(lags))
        {
            lags = [lags];
        }
        logger.info("Convert Endpoint B lags " + JSON.stringify(lags));
        var convertedLags = [];

        var neFamily = intentDeviationObj.getNeFamilyRelease(neId);
        var neVersion = intentDeviationObj.getNeVersion(neFamily);

        if (lags && lags.length) {
            for (var i = 0; i < lags.length; i++) {
                var lagObj = lags[i];
                if (lagObj['remote-lag'])
                {
                    var lag = {
                        "remote-lag": lagObj['lag-name'],
                        "lacp-key": lagObj['lacp-key'],
                        "system-priority": lagObj['system-priority'],
                        "source-bmac-lsb": lagObj['source-bmac-lsb']
                    }
                    if (neVersion.startsWith("19.") || neVersion.startsWith("20.")) {
                        lag["lag-id"] = parseInt(lagObj['remote-lag']);
                    } else {
                        lag["lag-name"] = lagObj['remote-lag'];
                    }
                    if (lagObj["system-id"]) {
                        lag["system-id"] = lagObj["system-id"].replaceAll("-", ":");
                    }
                    convertedLags.push(lag);
                }
            }
        }
       /* else {
            if (lags) {
                var lag = {
                    "remote-lag": lags['lag-name'],
                    "lacp-key": lags['lacp-key'],
                    "system-priority": lags['system-priority']
                }
                if (neVersion.startsWith("19.") || neVersion.startsWith("20.")) {
                    lag["lag-index"] = parseInt(lags['remote-lag']);
                } else {
                    lag["lag-name"] = lags['remote-lag'];
                }
                if (lags["system-id"]) {
                    lag["system-id"] = lags["system-id"].replaceAll("-", ":");
                }
                convertedLags.push(lag);
            }
        }*/

        return convertedLags;
    }
}