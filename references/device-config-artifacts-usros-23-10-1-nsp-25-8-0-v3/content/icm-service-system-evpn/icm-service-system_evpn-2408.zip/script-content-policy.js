var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
  "ibn" : "http://www.nokia.com/management-solutions/ibn",
  "nc" : "urn:ietf:params:xml:ns:netconf:base:1.0",
  "device-manager" : "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
  "http://www.nokia.com/management-solutions/anv-device-holders" : "anv-device-holders"
};


MdcFwk = load({
    script: resourceProvider.getResource('mdc-fwk.js'),
    name: 'mdc-fwk'
});
mdcFwk = new MdcFwk();

TraverseFwk = load({
    script: resourceProvider.getResource('traverse-fwk.js'),
    name: 'Traverse'
});
traverseFwk = new TraverseFwk();
var intentTypeName = 'day-config-1';

restResponseHandler = function (exception, httpStatus, response) {
    logger.info("[IntentMgr] REST response : " + response);
    logger.info("[IntentMgr] REST httpStatus : " + httpStatus);
    if (exception) {
        throw new RuntimeException("Couldn't connect to device proxy for ; Response: "+response);
    };
    if (httpStatus !== 200 && httpStatus !== 201) {
        throw new RuntimeException("Failed to access device  using MDC; Response: "+response);
    };
    restResponse = JSON.parse(response);
};

function synchronize(input) {
  var result = synchronizeResultFactory.createSynchronizeResult();
  var target = input.getTarget();
  
  // saved topology
  savedTopology = input.getCurrentTopology();

  if(savedTopology == null){
        savedTopology = topologyFactory.createServiceTopology();
  }
  
  if (input.getNetworkState().name() == "delete"){
      logger.info(JSON.stringify(savedTopology));
      result = traverseFwk.deleteAllFromTopology(savedTopology,target,result);
      return result;
    
  }
  
   var intentConfig;
 
  if(target !== "0.0.0.0"){
        var intentConfig;
        distributionMode = xml2object(input.getIntentConfiguration())['configuration'][intentTypeName]['distribution-mode'];
        if (distributionMode === "globalsync"){
             intentConfig = getGlobalConfig();
        }else{
             intentConfig  = xml2object(input.getIntentConfiguration())['configuration'][intentTypeName]["configure"];
        }

        if (intentConfig){
            savedTopology = traverseFwk.traverse(target,intentConfig,savedTopology,null,"","configure");
          
          //sorting delete array
            deleteRequests = traverseFwk.getDeleteRequests();
            deleteRequests.sort(function(a, b){
                            return b["target"].length - a["target"].length;
            });

          // concating createrequests and deleterequests
            createRequests = traverseFwk.getCreateRequests();
            var requests;
            if(deleteRequests && createRequests){
                requests = createRequests.concat(deleteRequests);
            }
            if ( requests ){
                result = traverseFwk.syncRequest(target,requests,result,savedTopology);
            }
      
        }else{  
                result = traverseFwk.deleteAllFromTopology(savedTopology,target,result); 
        }
    
   }

  return result;
}

function onAudit(target, config, svcTopo, adminState) {
 
  var report = auditFactory.createAuditReport(null, null);
  var currentConfig;
  
  if(target !== "0.0.0.0"){
    
     distributionMode = xml2object(config)['configuration'][intentTypeName]['distribution-mode'];
     if (distributionMode === "globalsync"){
         currentConfig = getGlobalConfig();
     }else{
         currentConfig  = xml2object(config)['configuration'][intentTypeName]["configure"];
     }
     svcTopo = traverseFwk.traverse(target,currentConfig,svcTopo,report,"","configure");
     // reseting the variables
     traverseFwk.resetTheVariables();
  }
  
  return report;
  
}

function getNodes(context) {
  var returnVal = []
  var url = "/restconf/meta/api/v1/nes"
  try {
    var managerList = []
    var managers = mds.getAllManagersOfType("REST");
    managers.forEach(function (manager) {
      if (mds.getManagerByName(manager).getConnectivityState().toString() === 'CONNECTED') {
        managerList.push(manager)
      }
    })

    var devices = mds.getAllManagedDevicesFrom(managerList);
    
    devices.forEach(function (device) {
      returnVal.push(device.getName());
    });
    
    return returnVal;
  } catch (e) {
    logger.info("Exception *******************  : " + e);
    return {
      "Device Not Found": "Device Not Found"
    }
  }
}

function xml2object(xmlElement) {
    var lXml = Java.type("org.json.XML");
    var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
    var serializer = lsImpl.createLSSerializer();
    serializer.getDomConfig().setParameter("xml-declaration", false);
    var str = serializer.writeToString(xmlElement);
    var json = lXml.toJSONObject(str).toString();
    return JSON.parse(json);
}

function getGlobalConfig(){
      
       globalConfig =  ibnService.getIntent(intentTypeName,"0.0.0.0")["intentConfig"];
       xmlSubtree = utilityService.extractSubtree(globalConfig, {}, "//*[local-name()='intent']/*[1]");
       globalJson = xml2object(xmlSubtree)["intent-specific-data"][intentTypeName]["configure"];
       
       return globalJson;
}
  
