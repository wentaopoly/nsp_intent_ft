function MdSuggest() {
    this.getPolicyName = function (neId, policyId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-state:/state/qos/sap-ingress?fields=oper-policy-id";
        return this.getData(neId, url, "sap-ingress-policy-name", policyId);
    }
    this.getPolicyId = function (neId, policyName) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-state:/state/qos/sap-ingress?fields=oper-policy-id";
        if (policyName) {
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-state:/state/qos/sap-ingress=" + policyName + "?fields=oper-policy-id";
        }
        return this.getData(neId, url, "oper-policy-id");
    }

    this.getIpCriteriaPrefixList = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/match-list/ip-prefix-list";
        return this.getSuggestData(neId, url, "nokia-conf:ip-prefix-list", "prefix-list-name");
    }

    this.getIpv6CriteriaPrefixList = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/match-list/ipv6-prefix-list";
        return this.getSuggestData(neId, url, "nokia-conf:ipv6-prefix-list", "prefix-list-name");
    }

    this.getAdvConfigPolicy = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/adv-config-policy";
        return this.getSuggestData(neId, url, "nokia-conf:adv-config-policy", "adv-config-policy-name");
    }

    this.getQueueGroupNames = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/queue-group-templates/ingress/queue-group";
        return this.getSuggestData(neId, url, "nokia-conf:queue-group","ingress-queue-group-name");
    }

    this.getQueueGroupQueues = function (neId, queueGroup) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/queue-group-templates/ingress/queue-group=" + queueGroup + "/queue";
        return this.getSuggestData(neId, url, "nokia-conf:queue","queue-id");
    }

    this.getData = function (neId, url, type, policyId) {
        var mdcFwk = new MdcFwk();
        logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info("MDC resultFetch =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"]["nokia-state:sap-ingress"];
        logger.info("finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                if (policyId) {
                    logger.info("PolicyId Selected = {}", policyId);
                    logger.info("Device policy ID = {}", finalResponse[index]["oper-policy-id"]);
                    if (finalResponse[index]["oper-policy-id"] == policyId) {
                        ret.push(finalResponse[index][type]);
                        break;
                    }
                } else {
                    ret.push(finalResponse[index][type]);
                }
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info("ret = \n" + JSON.stringify(ret));
        return ret;
    }

    this.getSuggestData = function (neId, url, initialProperty, propertyName) {
        var mdcFwk = new MdcFwk();
        logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, propertyName);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info("MDC resultFetch =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"][initialProperty];
        logger.info("finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                logger.info("Device " + propertyName + " Data = {}", finalResponse[index][propertyName]);
                ret.push(finalResponse[index][propertyName]);
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info("ret = \n" + JSON.stringify(ret));
        return ret;
    }
}

