var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpNetworkQueue() {

    var util = new utilities();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var savedTopology;
    var isAudit = false;
    var isEdit = false;
    var nfmpFwkPostRequest = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true"
    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        if (input.getNetworkState().name() == "delete")
        {
            logger.info("Calling syncDelete");
            return this.syncDelete(input, result);
        }
        savedTopology = input.getCurrentTopology();
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        var intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        //set the policy name from target
        intentConfig["network-queue-policy-name"] = input.getTarget().split("#")[2];
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        this.createOrModify(neId, intentConfig);
        return util.setSuccessResult(result, savedTopology);
    }
    this.syncDelete = function (input, result) {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyName = input.getTarget().split("#")[2];
        var objectFullName = "network:" + neId + ":sasNetworkQueue:" + policyName;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        logger.info("Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }
    this.createOrModify = function (neId, intentConfig) {
        var networkQueuePayload = this.createPolicyLevelPayLoad(neId, intentConfig);
        var result = this.modifyRequest(neId, networkQueuePayload);
        // distribute the policy to the local
        // Distribute Global Policy to Ne in Target
        if (!isEdit)
        {
            logger.info("Distributing the policy to local");
            var objectFullName = "sasNetworkQueue:" + intentConfig["network-queue-policy-name"];
            var fullClassName = "sasqos.NQueue";
            var localPolicyFullName = "network:" + neId + ":" + objectFullName;
            localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
            var distributePayload = util.distribute(neId, objectFullName, false);
            var distributeResult = nfmpFwk.post(nfmpFwkPostRequest, distributePayload);
            if (!distributeResult.success)
            {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }
            util.delay(2000);
            // Changing SyncWithGlobal To Local Edit Only
            distributePayload = util.distribute(neId, objectFullName, true);
            distributeResult = nfmpFwk.post(nfmpFwkPostRequest, distributePayload);
            if (!distributeResult.success)
            {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }
            util.delay(2000);
            if (!util.isObjectExists(fullClassName, localPolicyFullName))
            {
                throw new RuntimeException("Unable to Distribute existing Global Policy: " + objectFullName + " to local policy: " + localPolicyFullName + " , Kindly check the Global Policy configuration");
            }
        }
        return result;
    }
    this.createPolicyLevelPayLoad = function (neId, intentConfig) {
        var fullClassName = "sasqos.NQueue";
        var policyFdn = "sasNetworkQueue";
        var objectFullName = "sasNetworkQueue:" + intentConfig["network-queue-policy-name"];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        if (util.isObjectExists(fullClassName, localPolicyFullName) || isAudit)
        {
            objectFullName = localPolicyFullName;
            if (!isAudit)
            {
                isEdit = true;
            }
        }
        var properties = {};
        properties["displayedName"] = intentConfig["network-queue-policy-name"];
        properties["description"] = intentConfig["description"];
        var childProperties = {};
        if (intentConfig["queue"])
        {
            if (!Array.isArray(intentConfig["queue"]))
            {
                intentConfig["queue"] = [intentConfig["queue"]];
            }
            var queues = [];
            for (var index in intentConfig["queue"])
            {
                var intentQueueConfig = intentConfig["queue"][index];
                var queueProperties = {};
                queueProperties["id"] = intentQueueConfig["queue-id"];
                queueProperties["isQueueDeployable"] = true;
                queueProperties["displayedName"] = intentQueueConfig["displayed-name"];
                queueProperties["description"] = intentQueueConfig["description"];
                queueProperties["pirAdaptation"] = intentQueueConfig["adaptation-rule"]["pir"];
                queueProperties["cirAdaptation"] = intentQueueConfig["adaptation-rule"]["cir"];
                queueProperties["pir"] = intentQueueConfig["rate"]["pir"];
                queueProperties["cir"] = intentQueueConfig["rate"]["cir"];
                queueProperties["committedBurstSize"] = intentQueueConfig["burst-size"]["committed-burst-size"];
                queueProperties["maximumBurstSize"] = intentQueueConfig["burst-size"]["maximum-burst-size"];
                queueProperties["mode"] = intentQueueConfig["mode"];
                queueProperties["weight"] = intentQueueConfig["weight"];
                queueProperties["priority"] = intentQueueConfig["priority"];
                if (intentQueueConfig["queue-management-policy"])
                {
                    queueProperties["queuemgmtPolicyPointer"] = util.convertQueueMgmtPolicyGreenField(intentQueueConfig["queue-management-policy"])
                }
                else
                {
                    queueProperties["queuemgmtPolicyPointer"] = "sasQueueMgmtPolicy:default";
                }
                if (intentQueueConfig["slope-policy"])
                {
                    queueProperties["slopePolicyPointer"] = util.convertSlopePolicyGreenField(intentQueueConfig["slope-policy"]);
                }
                else
                {
                    queueProperties["slopePolicyPointer"] = "sasSlope:default";
                }
                queues.push(queueProperties);
            }
            childProperties["sasqos.NQueueEntry"] = queues;
        }
        else
        {
            childProperties["sasqos.NQueueEntry"] = [];
        }
        // logger.info("NQueueEntry = {}",JSON.stringify(queues));
        if (intentConfig["fc"])
        {
            if (!Array.isArray(intentConfig["fc"]))
            {
                intentConfig["fc"] = [intentConfig["fc"]];
            }
            var fcs = [];
            for (var index in intentConfig["fc"])
            {
                var fcProperties = {};
                var intentFcConfig = intentConfig["fc"][index];
                fcProperties["forwardingClass"] = intentFcConfig["forwarding-class"];
                fcProperties["queueId"] = intentFcConfig["queue-id"];
                fcs.push(fcProperties);
            }
            childProperties["sasqos.NQueueForwardingClass"] = fcs;
        }
        else
        {
            childProperties["sasqos.NQueueForwardingClass"] = [];
        }
        // logger.info("NQueueForwardingClass = {}",JSON.stringify(fcs));
        // logger.info("childProperties = {}",JSON.stringify(childProperties));
        var policyLevelPayload = util.editPayload(policyFdn, properties, childProperties, fullClassName, objectFullName);
        return policyLevelPayload;
    }
    this.modifyRequest = function (neId, payload) {
        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
           logger.error("Error result = {}",JSON.stringify(result));
           let errorMsg = result.msg;
           if(errorMsg.indexOf("object already exists") !== -1)
           {
               logger.info("Global policy Object already exists, Re-checking the Policy existence ");
               //util.delay(2000);
               let configInfo = payload.configInfo;
               let fullClassName;
               for (let key in configInfo) {
                 if (configInfo.hasOwnProperty(key)) {
                   fullClassName = key;
                   break;
                 }
               }
               let objectFullName = payload.objectFullName;
               objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
               logger.info("fullClassName = {}",fullClassName);
               logger.info("objectFullName = {}",objectFullName);
               if (!util.isObjectExists(fullClassName, objectFullName))
               {
                   throw new RuntimeException("Global Policy Object Not Found!!!");
               }
           }
           else
           {
               throw new RuntimeException(result.msg);
           }
        }
        return result;
    }
    this.audit = function (input, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        isAudit = true;
        var lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        var intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        intentConfig["network-queue-policy-name"] = input.getTarget().split("#")[2];
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        if (intentConfig)
        {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }
        return auditReport
    }
    this.auditAndCompare = function (neId, intentConfig, auditReport) {
        var networkQueuePayload = this.createPolicyLevelPayLoad(neId, intentConfig);
        logger.info("Audit payload = {}", JSON.stringify(networkQueuePayload));
        var result = this.auditRequest(neId, networkQueuePayload);
        auditReport = util.reportMisaligned(neId, result, auditReport);
        return auditReport;
    }
    this.auditRequest = function (neId, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }
}
