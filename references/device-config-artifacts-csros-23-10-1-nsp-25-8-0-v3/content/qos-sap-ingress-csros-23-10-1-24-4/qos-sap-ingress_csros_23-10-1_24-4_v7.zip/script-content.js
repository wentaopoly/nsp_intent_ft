var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
const icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
const gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('parse-target.js'), name: 'parse-target'});
var parseTargetObj = new ParseTarget();

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})
var nfmpSuggest = new NfmpSuggest();

let intentTypeName = "qos-sap-ingress_csros_23-10-1_24-4";

// example port, sap-ingress etc..
let initialPropertyName = "aingr-Policy";

var LOG_PREFIX = "[QOS Sap Ingress]: "
// unique identifier
let uniqueIdentifier = "id,policyName";

/**
 *
 * @param {*} input
 */
function validatePolicy(input) {
    logger.info("--------------Intent validate --------------");
    let target = input.getTarget();
    logger.info("validate target " + target);
    let neId = parseTargetObj.getNeIdFromTarget(target);
    let policyId = parseTargetObj.getUniqueIdentifier(target)[0];
    let lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
    let intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];
    logger.info("validate ne policy name " + intentConfig['policyName']);
    let serachString = constructSearchString(neId, policyId,intentConfig['policyName'])
    var result = nfmpSuggest.getData(serachString, "aingr.Policy", "id");
    if(result.length != 0)
    {
        throw new RuntimeException("There exists a SAP ingress policy "+policyId+ " with same name " + intentConfig['policyName']+" on"+ neId);
    }
}

/**
 * This function is starting point by IM for sync operation
 * @param input
 * @returns {*}
 */
function synchronize(input) {
    logger.info("-------------------- script-content.js -> synchronize() --------------------");
    logger.info("Intent Synchronisation started - input = {}", input)
    validatePolicy(input);
    return NspIntentHelper.synchronize(input, intentTypeName, initialPropertyName, uniqueIdentifier);
}

/**
 * The function is starting point for audit operation in IM
 * @param input
 * @returns {*}
 */
function audit(input) {
    logger.info("-------------------- script-content.js -> audit() --------------------");
    logger.info("Intent Audit started - input = {}", input)
    return NspIntentHelper.audit(input, intentTypeName, initialPropertyName, uniqueIdentifier)
}

/**
 * This function returns NE-ID
 *
 * @param context
 * @returns {string}
 */
function getNeId(context) {
    logger.info("-------------------- script-content.js -> getNeId() --------------------");
    let neId;
    let target = context.getInputValues()["target"]["objectidentifier"];
    logger.info("target = {}", target)
    if (target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    logger.info("NeId : " + neId);
    return neId;
}

/**
 * The function is used in Brownfield discovery by ICM Framework
 * It discover's the configuration from the target device
 * and manipulate as per Template's default-target-data
 *
 * @see ICMFwk for more details
 * @param {*} input - the config data of a deployment
 * @returns result - the result of the operation
 */
function getTargetData(input) {
    logger.info("-------------------- script-content.js -> getTargetData() --------------------");
    logger.info("getTargetData input for brownfield = \n" + input);
    let target = input.target;
    let config = null;
    logger.info("target=" + target);
    let deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info("deviceConfig = {} ", JSON.stringify(deviceConfig));
    let data = gtdFwk.gtdSend(deviceConfig);
    logger.info("data = {}", JSON.stringify(data));
    logger.info("returning result = {}", JSON.stringify(data.msg.result));
    return data.msg.result;
}

function suggestAdvancedConfigPolicyName(context) {
    logger.info(LOG_PREFIX + "suggestAdvancedConfigPolicyName context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getAdvancedConfigPolicyName(neId);
}

function suggestIpPrefixListName(context) {
    logger.info(LOG_PREFIX + "suggestIpPrefixListName context = \n" + context);
    return nfmpSuggest.getIpPrefixListName();
}

function suggestIpv6PrefixListName(context) {
    logger.info(LOG_PREFIX + "suggestIpv6PrefixListName context = \n" + context);
    return nfmpSuggest.getIpv6PrefixListName();
}

function suggestSlopePolicyName(context) {
    logger.info(LOG_PREFIX + "suggestSlopePolicyName context = \n" + context);
    return nfmpSuggest.getSlopePolicyName();
}

function suggestPolicerId(context) {
    logger.info(LOG_PREFIX + "suggestPolicerId context = \n" + context);
    return nfmpSuggest.getSlopePolicerId();
}

function suggestParentArbiterName(context) {
    logger.info(LOG_PREFIX + "suggestParentArbiterName context = \n" + context);
    return nfmpSuggest.getParentArbiterName();
}

function suggestSchedulerName(context) {
    logger.info(LOG_PREFIX + "suggestSchedulerName context = \n" + context);
    return nfmpSuggest.getSchedulerName();
}

function suggestQueueId(context) {
    logger.info("suggestQueueId context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getQueueId(neId);
}

function suggestPolicerId(context) {
    logger.info("suggestPolicerId context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getPolicerId(neId);
}
function suggestPolicyId(context) {
    logger.info("suggestPolicyId context = \n" + context);
    var neId = getNeId(context);
    let policyName = undefined;
        var templateName = context.getInputValues()["target"]["templatename"];
        if(context.getInputValues()["target"]["target"])
        {
            policyName = context.getInputValues()["target"]["target"][templateName]["target_policyName"]
        }
        else
        {
            policyName = context.getInputValues()["target"]["policyName"]
        }
    return nfmpSuggest.getPolicyId(neId, policyName);
}
function suggestPolicyName(context) {
    logger.info("suggestPolicyName context = \n" + context);
    var neId = getNeId(context);
    let policyId = undefined;
    var templateName = context.getInputValues()["target"]["templatename"];
    if(context.getInputValues()["target"]["target"])
    {
        policyId = context.getInputValues()["target"]["target"][templateName]["target_id"]
    }
    else
    {
        policyId = context.getInputValues()["target"]["id"]
    }
    return nfmpSuggest.getPolicyName(neId,policyId);
}

function suggestQueueData(context) {
    var queue_id=[];
    logger.info(LOG_PREFIX + "suggestQueueId context = \n" + context);
    var queues = context['inputValues']['arguments']['__root']['aingr-Policy']['aingr-Queue'];
    queues.forEach(function(queueObject) {
        logger.info("Queue Id in Input : " + queueObject['id']);
        queue_id.push(queueObject['id']);
    });
    return queue_id;
}

function constructSearchString(neId, policyId, policyName) {
    var searchJson = {
        "fullClassName": "aingr.Policy",
        "filter":{
            "and":{
                "equal":[{
                    "name":"siteId",
                    "value": neId
                },
                {
                    "name":"policyName",
                    "value": policyName
                }],
                "not":{
                    "equal":[{
                        "name":"id",
                        "value": policyId
                    }]
                }
            }
        }
    };
    return searchJson;
}

