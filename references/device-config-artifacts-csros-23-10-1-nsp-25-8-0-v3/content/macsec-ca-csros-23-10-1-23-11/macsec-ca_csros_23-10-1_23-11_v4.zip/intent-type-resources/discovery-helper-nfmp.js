var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource("model-device-mapping.js"), name: "model-device-mapping"});

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();
    let modelDeviceMapping = new ModelDeviceMapping();
    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let caName = target.split("#")[2];
        let searchPayLoad = this.constructSearchString(neId, caName);
        let searchResponse = nfmpFwk.post("/v3/search", searchPayLoad);
        logger.info("searchResponse == {} ", JSON.stringify(searchResponse))
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find CA Name  : " + caName);
        }
        searchResponse = JSON.parse(searchResponse.response);
        logger.info("searchResponse = {}", JSON.stringify(searchResponse));
        return searchResponse;
    }
    this.constructSearchString = function (neId, caName) {
        let jsonPayLoad = {
            "fullClassName": "macsec.ConnectivityAssociation",
            "filter": {
                "equal": {
                    "name": "caName",
                    "value": caName
                }
            }
        }
        return jsonPayLoad;
    }
    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        let macsecCaConfig = deviceConfig["macsec.ConnectivityAssociation"];
        let preSharedKeys = {};
        let sites = {};
        if (deviceConfig["macsec.ConnectivityAssociation"]["children-Set"])
        {
            if (deviceConfig["macsec.ConnectivityAssociation"]["children-Set"]["macsec.StaticCAK"])
            {
                if (deviceConfig["macsec.ConnectivityAssociation"]["children-Set"]["macsec.StaticCAK"]["children-Set"])
                {
                    if (deviceConfig["macsec.ConnectivityAssociation"]["children-Set"]["macsec.StaticCAK"]["children-Set"]["macsec.PreSharedKey"])
                    {
                        preSharedKeys = deviceConfig["macsec.ConnectivityAssociation"]["children-Set"]["macsec.StaticCAK"]["children-Set"]["macsec.PreSharedKey"];
                    }
                }
            }
            if (deviceConfig["macsec.ConnectivityAssociation"]["children-Set"]["macsec.CASite"])
            {
                sites = deviceConfig["macsec.ConnectivityAssociation"]["children-Set"]["macsec.CASite"]
            }
        }
        deviceConfig = {
            "macsecCaConfig": macsecCaConfig,
            "preSharedKeys": preSharedKeys,
            "sites": sites
        }
        logger.info("***********************************deviceConfig***********************************************");
        logger.info(JSON.stringify(deviceConfig));
        logger.info("************************************parsedDefaultTargetData***********************************");
        logger.info(JSON.stringify(parsedDefaultTargetData));
        logger.info("**************************************************END******************************************");
        if (null !== deviceConfig)
        {
            extractMacSecCAProperties(parsedDefaultTargetData, deviceConfig["macsecCaConfig"]);
            let staticCakPreSharedKeys = extractPreSharedKeyProperties(parsedDefaultTargetData["connectivity-association"]["static-cak"]["pre-shared-key"], deviceConfig["preSharedKeys"]);
            parsedDefaultTargetData["connectivity-association"]["static-cak"]["pre-shared-key"] = staticCakPreSharedKeys;
            let sitesConfigArray = extractSitesProperties(parsedDefaultTargetData["connectivity-association"]["sites"], deviceConfig["sites"]);
            parsedDefaultTargetData["connectivity-association"]["sites"] = sitesConfigArray;

        }
        clearEmpties(parsedDefaultTargetData);
        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData));
        return parsedDefaultTargetData;
    }

    function extractMacSecCAProperties(defaultTargetData, deviceConfig) {
        let keys = Object.keys(defaultTargetData);
        //logger.info("keys = " + keys)
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj))
            if (targetObj !== null && typeof targetObj === 'object')
            {
                traverseAndUpdateMacSecCaConfig(targetKey, targetObj, deviceConfig);
            }
        }
        return defaultTargetData;
    }

    function extractPreSharedKeyProperties(preSharedKeyTargetData, deviceConfig) {
        let preSharedKeyArray = [];
        let preSharedKeyData = preSharedKeyTargetData[0];
        let mappings = modelDeviceMapping.getPreSharedKeyMapping();
        for (let i = 0; i < deviceConfig.length; i++)
        {
            let devicePreSharedKeyConfig = deviceConfig[i];
            let keys = Object.keys(preSharedKeyData);
            logger.info("keys = " + keys);
            for (let j = 0; j < keys.length; j++)
            {
                let targetKey = keys[j];
                let targetObj = preSharedKeyData[targetKey];
                let mappedKey = "pre-shared-key." + targetKey;
                //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj) + "\nmappedKey = " + mappedKey);
                getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, preSharedKeyData, devicePreSharedKeyConfig);
            }
            preSharedKeyArray.push(JSON.parse(JSON.stringify(preSharedKeyData)));
        }
        return preSharedKeyArray;
    }

    function extractSitesProperties(siteTargetData, deviceConfig) {
        let siteArray = [];
        let siteData = siteTargetData[0];
        if (Object.keys(deviceConfig).length > 0 && !Array.isArray(deviceConfig))
        {
            deviceConfig = [deviceConfig];
        }
        let mappings = modelDeviceMapping.getSiteMapping();
        for (let i = 0; i < deviceConfig.length; i++)
        {
            let deviceSiteConfig = deviceConfig[i];
            let keys = Object.keys(siteData);
            logger.info("keys = " + keys);
            for (let j = 0; j < keys.length; j++)
            {
                let targetKey = keys[j];
                let targetObj = siteData[targetKey];
                let mappedKey = "sites." + targetKey;
                //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj) + "\nmappedKey = " + mappedKey);
                if (targetObj != null && typeof targetObj === 'object')
                {
                    traverseAndUpdateSiteConfig(targetKey, targetObj, deviceSiteConfig);
                }
                else
                {
                    getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, siteData, deviceSiteConfig);
                }
            }
            siteArray.push(JSON.parse(JSON.stringify(siteData)));
        }
        return siteArray;
    }

    function traverseAndUpdateMacSecCaConfig(objKey, obj, deviceConfig) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            let mappings = modelDeviceMapping.getMacSecCaMapping();
            if (value != null && typeof value === 'object')
            {
                if (key === "keying-parameters" || key === "static-cak")
                {
                    let newDeviceConf = deviceConfig;
                    if (key === "static-cak")
                    {
                        if (deviceConfig["children-Set"])
                        {
                            if (deviceConfig["children-Set"]["macsec.StaticCAK"])
                            {
                                newDeviceConf = deviceConfig["children-Set"]["macsec.StaticCAK"]
                            }
                        }
                    }
                    traverseAndUpdateMacSecCaConfig(key, value, newDeviceConf);
                }
                else
                {
                    continue;
                }
            }
            else
            {
                getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, deviceConfig);
            }
        }
        return obj;
    }

    function traverseAndUpdateSiteConfig(objKey, obj, deviceConfig) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let newDeviceConfig = deviceConfig;
            let key = keys[i];
            if (key === "mka-hello-interval" ||
                key === "edit-mka-hello-interval" ||
                key === "mka-key-server-priority" ||
                key === "edit-mka-key-server-priority")
            {
                if (deviceConfig["children-Set"])
                {
                    if (deviceConfig["children-Set"]["macsec.StaticCAK"])
                    {
                        newDeviceConfig = deviceConfig["children-Set"]["macsec.StaticCAK"]
                    }
                }
            }
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            let mappings = modelDeviceMapping.getSiteMapping();
            if (value != null && typeof value === 'object')
            {
                continue;
            }
            else
            {
                if (key === "edit-admin-state" ||
                    key === "edit-description" ||
                    key === "edit-replay-window-size" ||
                    key === "edit-replay-protection" ||
                    key === "edit-mka-hello-interval" ||
                    key === "edit-mka-key-server-priority")
                {
                    let inheritanceMask = newDeviceConfig["inheritanceMask"];
                    obj[key] = false;
                    if (Array.isArray(inheritanceMask))
                    {
                        for (let j = 0; j < inheritanceMask.length; j++)
                        {
                            if (mappings[key] === inheritanceMask[j])
                            {
                                obj[key] = true;
                                break;
                            }
                        }
                    }
                }
                else
                {
                    getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, newDeviceConfig);
                }
            }
        }
        return obj;
    }

    function getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, targetObj, deviceConfigData) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = deviceConfigData[nfmpKey];
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[targetKey] = (deviceValue) ? transformDeviceValue(mappedKey, deviceValue) : deviceValue;
    }

    function transformDeviceValue(mappedKey, deviceValue) {
        if (deviceValue !== null)
        {
            switch (mappedKey)
            {
                case "connectivity-association.admin-state":
                case "inherit-global-parameters.admin-state":
                    deviceValue = util.convertAdminStateBrownField(deviceValue);
                    break;
                case "static-cak.mka-hello-interval":
                case "inherit-global-parameters.mka-hello-interval":
                    deviceValue = util.convertHelloIntervalBrownField(deviceValue);
                    break;
                case "keying-parameters.hsm-id":
                    deviceValue = deviceValue ? deviceValue.split("hsmMgr:hsm-")[1] : deviceValue;
                    break;
            }
            return deviceValue;
        }
    }

    function clearEmpties(o) {
        for (let k in o)
        {
            if (!o[k] || typeof o[k] !== "object")
            {
                continue
            }
            clearEmpties(o[k]);
            if (Object.keys(o[k]).length === 0)
            {
                delete o[k];
            }
        }
    }
}