load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {

    this.setSuccessResult = function (result, savedTopology) {
        result.setSuccess(true);
        if (savedTopology !== undefined)
        {
            result.setTopology(savedTopology);
        }
        return result;
    }

    this.reportMisaligned = function (target, result, auditReport) {
        var report = result;
        if (!report.aligned)
        {
            for (var i = 0; i < report.misalignedAttributes.length; i++)
            {
                var attributeData = report.misalignedAttributes[i];
                if((attributeData.name).indexOf("mcPimSnooping") > -1)
                {
                    if(this.arraysAreEqual(attributeData.expected, attributeData.actual))
                    {
                      continue;
                    }
                }
                if (attributeData.expected == "present")
                {
                    //misaligned object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else if (attributeData.expected == "not present")
                {
                    //undesired object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                    auditReport.addMisAlignedAttribute(misalignedAttribute);
                }

            }
        }
        return auditReport
    }

    this.editPayload = function (fdn, properties, childProperties, fullClassName, objectFullName) {

        var payload = {};
        var configInfo = {};
        configInfo[fullClassName] = properties;
        configInfo[fullClassName]["children-Set"] = childProperties;
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName;
        payload["clearOnDeployFailure"] = true;
        payload["configInfo"] = configInfo;
        return payload;
    }

    /*
        function: isObjectExists
        description: To Check the Object exists or not.
   */
    this.isObjectExists = function (className, objectFullName) {
            let nfmpFwk = new NfmpFwk();
            var ret = false;
            var searchObjectJson = {
                "fullClassName": className,
                "filter": {
                    "equal": {
                        "name": "objectFullName",
                        "value": objectFullName
                    }
                }
            };
            var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);

            logger.info("isObjectExists data = {}", JSON.stringify(resultFetch));

            var finalResponse = JSON.parse(resultFetch.response);
            logger.info("Final response of search = {}", JSON.stringify(finalResponse));
            if (Object.keys(finalResponse).length !== 0 && finalResponse.constructor === Object)
            {
                ret = true;
            }
            logger.info("isObjectExists = {} ", ret);
            return ret;
        }

    //convert system-id to NFMP system-id, convert 00:00:00:00:00:00 to 00-00-00-00-00-00.
    this.convertToNfmpsystemId = function (systemId) {
        return systemId.replaceAll(":", "-");
    }
    this.convertToIntentsystemId = function (systemId) {
        return systemId.replaceAll("-", ":");
    }

    //convert admin-sate to NFMP administrate State.
    this.convertToNfmpAdminstarteState = function (adminState) {
        if (adminState == "enable")
        {
            return "tmnxInService";
        }
        else if (adminState == "disable")
        {
            return "tmnxOutOfService";
        }
    }
    this.convertToIntentAdminstarteState = function (adminState) {
        if (adminState == "tmnxInService")
        {
            return "enable";
        }
        else if (adminState == "tmnxOutOfService")
        {
            return "disable";
        }
    }

    //Compare IP address.
    this.compareIpAddress = function (endpointAInterfaceIP, endpointBInterfaceIP) {
        var interfaceA = endpointAInterfaceIP.split(".");
        var interfaceB = endpointBInterfaceIP.split(".");

        var interfaceAValue = this.ipToBits(interfaceA);
        var interfaceBValue = this.ipToBits(interfaceB);

        return (interfaceAValue - interfaceBValue);

    }

    this.ipToBits = function (ip) {
        var lTotal;
        var lThisPart;
        var lShiftedPart;
        BIT_MASK_SHIFTS = [24, 16, 8, 0];
        for (var i = 0; i < 4; i++)
        {
            var lThisPart = ip[i];
            var lShiftedPart = lThisPart << BIT_MASK_SHIFTS[i];

            lTotal = (lTotal | lShiftedPart) >>> 0; // >>> 0 to convert the result to unsigned int
        }
        return lTotal;
    }

    this.arraysAreEqual = function(arr1, arr2) {
        if(!Array.isArray(arr1))
        {
          arr1 = [arr1];
        }
        if(!Array.isArray(arr2))
        {
          arr2 = [arr2];
        }
        // Check if the arrays have the same length
        if (arr1.length !== arr2.length) {
          return false;
        }

        // Sort the arrays
        var sortedArr1 = arr1.slice().sort();
        var sortedArr2 = arr2.slice().sort();

        // Compare the sorted arrays
        for (var i = 0; i < sortedArr1.length; i++) {
          if (sortedArr1[i] !== sortedArr2[i]) {
            return false; // Elements are different, arrays are not equal
          }
        }

        return true; // Arrays are equal
   }

    this.modifyNeIdForIpV6 = function (objectFullName, address1, address2) {
      if (!(address2)){
         objectFullName = objectFullName.replace(address1, address1.replaceAll(":","_"));
        return objectFullName;
      }
        objectFullName = objectFullName.replaceAll(address1, address1.replaceAll(":", "_")).replaceAll(address2, address2.replaceAll(":", "_"));
        return objectFullName;
    }

    this.getIxrType= function (target) {
        var deviceInfos = mds.getAllInfoFromDevices(target);
        if (null == deviceInfos || deviceInfos.size() === 0) {
            throw new RuntimeException("Device not found :" + target);
        }
        var deviceInfo = deviceInfos.get(0);
        var deviceType = deviceInfo.getFamilyTypeRelease();
        if (deviceType == null) {
            throw new RuntimeException("Device Family type and release not found for device: " + target);
        }
        var type= deviceType.split(':');
        log.info(null, "Device type:" + type);
        var deviceType;
        deviceType = {
            type: type[2]
        };
        return deviceType;
    };

    /*
    function: getBaseFdnForPort
    description: Construct the Fdn for Port and return it.
    */
    this.getBaseFdnForPort = function (target, portId) {
        if(portId.startsWith("esat"))
        {
            return this.getBaseFdnForSatelliteConnectorPort(target,portId);
        }
        var portIds = portId.split("/");
        var cardSlot;
        var xiomSlot;
        var mdaSlot;
        var connector;
        var portNumber

        portIds.forEach(function (item, index) {
            // logger.info("*********************item, index = " + item + "-----" + index);
            switch (index)
            {
                case 0:
                    cardSlot = item;
                    break;
                case 1:
                    //xiom
                    if (isNaN(item))
                    {
                        xiomSlot = item;
                    }
                    else
                    {
                        mdaSlot = item;
                    }
                    break;
                case 2:
                    //connector
                    if (isNaN(item))
                    {
                        connector = item;
                    }
                    else if(mdaSlot)
                    {
                        portNumber = item;
                    }
                    else
                    {
                        mdaSlot = item;
                    }
                    break;
                case 3:
                    //connector
                    if (isNaN(item))
                    {
                        connector = item;
                    }
                    else
                    {
                        portNumber = item;
                    }
                    break;
                case 4:
                    portNumber = item;
                    break;


            }
        });

        // logger.info("************ cardSlot =" + cardSlot + ",xiomSlot=" + xiomSlot + ",mdaSlot=" + mdaSlot + ",connector=" + connector + ",portNumber=" + portNumber);
        //"network:92.168.96.22:shelf-1:cardSlot-1:card:xioSlot-1:xiomCard:daughterCardSlot-1:daughterCard:conn-1:port-1"

        var portDn = "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card";
        if (xiomSlot)
        {
            portDn += ":xioSlot-" + xiomSlot.substring(1) + ":xiomCard";
        }
        if (mdaSlot)
        {
            portDn += ":daughterCardSlot-" + mdaSlot + ":daughterCard";
        }
        if (connector)
        {
            portDn += ":conn-" + connector.substring(1);
        }
        if (portNumber)
        {
            portDn += ":port-" + portNumber;
        }
        if (target && String(target).indexOf(':') !== -1) {
            portDn = this.modifyNeIdForIpV6(portDn, target);
        }
        logger.info("*********************portDn = " + portDn);
        return portDn;
        //return "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card:daughterCardSlot-" + mdaSlot + ":daughterCard:port-" + portNumber;
    }

    this.getBaseFdnForSatelliteConnectorPort = function (target, portId) {

        var portIds = (portId.split("-")[1]).split("/");
        var shelf = "shelf-1-5-";
        shelf += portIds[0];
        var satId =portIds[0];
        var cardSlot = "cardSlot-1:card" ;
        var mdaSlot = "daughterCardSlot-1:daughterCard";
        var portNumber = portIds[2];
        var connPortNumber = portNumber.substring(1);
        //logger.info("******satellite port = shelf = "+shelf+", portnumber = "+portNumber +"\n portid = "+ portId+"\n portids = "+ portIds);
        var portDn = "network:" + target + ":"+shelf+":" + cardSlot +":" +mdaSlot+":conn-"+connPortNumber ;
        if (target && String(target).indexOf(':') !== -1) {
            portDn = this.modifyNeIdForIpV6(portDn, target);
        }
        logger.info("SatConnPortDN = "+portDn);
        return portDn;
    }

    this.getLagId = function (lagName,neId){
        var className = "lag.Interface";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                         {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "lagNameId",
                            "value": lagName
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "lagId"
                ]
            }
        };
        var nfmpFwk = new NfmpFwk();
        var resultFetch = nfmpFwk.post("/v3/search", searchObject);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));
        var result = {}
        if (finalResponse !== undefined)
        {
            result["lagId"] = finalResponse['lagId'];
        }
        logger.info ("result = {}",JSON.stringify(result))

        return result["lagId"];

    }

    this.getPortLagEncapType = function (objectFullName){
        var className = (objectFullName.indexOf("lag:interface") > -1)?"lag.Interface":"equipment.PhysicalPort";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "encapType"
                ]
            }
        };

        var nfmpFwk = new NfmpFwk();
        var resultFetch = nfmpFwk.post("/v3/search", searchObject);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));
        var result = {}
        if (finalResponse !== undefined)
        {
            result["encapType"] = finalResponse['encapType'];
        }
        logger.info ("result = {}",JSON.stringify(result))

        return result;
    }
}
