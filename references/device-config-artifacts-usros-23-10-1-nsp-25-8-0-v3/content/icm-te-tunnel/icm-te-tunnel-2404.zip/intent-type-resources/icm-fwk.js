load({
    script: resourceProvider.getResource('mediator-fwk.js'),
    name: 'mediator-fwk'
});
nfmpFwk = new MediatorFramework("NFMP");

load({
    script: resourceProvider.getResource('nsp-restconf-fwk.js'),
    name: 'nsp-restconf-fwk'
});
nspRestconfFwk = new NspRestconfFwk();

load({
    script: resourceProvider.getResource("discovery-helper-nfmp.js"),
    name: "discovery-helper-nfmp"
});
load({
    script: resourceProvider.getResource("discovery-helper-mdc.js"),
    name: "discovery-helper-mdc"
});
load({
    script: resourceProvider.getResource('mdt-fwk.js'),
    name: 'MdtFwk'
});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
ICMFwk.prototype.mdcDiscovery = new MdcDiscoveryHelper();

//discoveryHelper = new NfmpDiscoveryHelper();

    var mdtFwk = new MdtFwk();
    var parseTarget = new ParseTarget();
    var mdcDiscoveryHelper = null;
    var extensionConfig = null;
    var ietfUtils = new IetfUtilities();

    var ThreadLocal = Java.type('java.lang.ThreadLocal');
    var HashMap = Java.type('java.util.HashMap');
    var requestScope = new ThreadLocal();

function ICMFwk() {

    this.setExtensionConfig = function (inputConfig) {
        this.extensionConfig = inputConfig;
    };

    // get the device configuration
    this.getDeviceConfiguration = function (targetWithTemplate, requestContext) {
        logger.info('icm-fwk.getDeviceConfiguration: targetWithTemplate = ' + JSON.stringify(targetWithTemplate));
        logger.info('icm-fwk.getDeviceConfiguration: requestContext = ' + requestContext);
        var targetData = this.getTargetData(targetWithTemplate, requestContext);
        logger.info('icm-fwk.getDeviceConfiguration: targetData = ' + JSON.stringify(targetData));
        return targetData;
    }

    this.getTemplate = function (templateName) {
        return nspRestconfFwk.getByXpath("/nsp-icm:icm/templates/template=" + templateName);
    }

    this.getDefaultTargetData = function (templateName) {
        var templateObj = nspRestconfFwk.getByXpath("/nsp-icm:icm/templates/template=" + templateName);
        logger.info('getDefaultTargetData: templateObj = ' + templateObj + ", templateObj = " + JSON.stringify(templateObj));
        //var defaultTargetData = templateObj['nsp-icm:template'][0]['default-target-data'];
        var defaultTargetData = templateObj['nsp-icm:template'][0]['target-data-struct'];
        return defaultTargetData;
    }

    this.getModifiedDeviceConfig = function (templateName, discoveryHelper, deviceConfig, requestContext, neId) {
        // if it is MDCDiscoveryHelper, modify the deviceConfig else dont do anything
        var targetData = deviceConfig;
        if (discoveryHelper instanceof MdcDiscoveryHelper)
        {
            var templateMetaInfo = this.mdcDiscovery.getDeviceTemplate(neId, requestContext);
            if(templateMetaInfo["type"] === "Cisco" || (templateMetaInfo["type"] === "CiscoR-IOSXRV9000-CC") || templateMetaInfo["type"] === "Juniper" || templateMetaInfo["type"] === "ATN 950D" || templateMetaInfo["type"] === "ATN 910C-G" || templateMetaInfo["type"] === "NetEngine 8000"){
            targetData = deviceConfig;
            }else{
                targetData["lsp"] = deviceConfig;
            }
            // delete target-identifiers from deviceConfig
            var targetIdentifiers = this.getTemplate(templateName)['nsp-icm:template'][0]['target-identifiers'];
            logger.info("getModifiedDeviceConfig: targetIdentifiers = {}", JSON.stringify(targetIdentifiers));
            for (var i = 0; i < targetIdentifiers.length; i++)
            {
                var name = targetIdentifiers[i].name;
                if(templateMetaInfo["type"] === "Cisco" || (templateMetaInfo["type"] === "CiscoR-IOSXRV9000-CC") || templateMetaInfo["type"] === "Juniper" || templateMetaInfo["type"] === "ATN 950D" || templateMetaInfo["type"] === "ATN 910C-G" || templateMetaInfo["type"] ==="NetEngine 8000"){ 
                    delete targetData[name];
                    }else{
                    delete targetData["lsp"][name];
                    }
            }
        }
        logger.debug("getModifiedDeviceConfig: returning targetData as = {}", JSON.stringify(targetData));
        return targetData;
    }

    this.getTargetData = function (targetWithTemplate, requestContext) {
        var targetAr = targetWithTemplate.split("#");
        var templateName = targetAr[0];
        logger.info('getTargetData: targetAr = ' + targetAr + ", targetAr = " + JSON.stringify(targetAr));
        var neId = parseTarget.getNeIdFromTarget(targetWithTemplate);
        logger.info('getTargetData: neId = ' + neId + ", neId = " + JSON.stringify(neId));
        // SBM: Set source
        var intentConfigJson = requestContext.get("intentConfigJson");
        if (!intentConfigJson["source"]) {
            logger.info('getTargetData: setting source: ' + neId + ' into intentConfigJson');
            intentConfigJson["source"] = neId;
        }

        var defaultTargetData = this.getDefaultTargetData(templateName);

        logger.info('getTargetData: defaultTargetData = ' + defaultTargetData + ", defaultTargetData = " + JSON.stringify(defaultTargetData));
        var deviceConfig = this.getConfigurations(targetWithTemplate, requestContext);
        if (typeof deviceConfig === 'string' && deviceConfig.indexOf('Failed to fetch service') > -1)
        {
            logger.error("getTargetData: deviceConfig = {}, deviceConfig = {}", deviceConfig, JSON.stringify(deviceConfig));
            return deviceConfig;
        }

        logger.info("getTargetData: value of deviceConfig = {}", JSON.stringify(deviceConfig));
        return this.extractDeviceConfig(templateName, neId, defaultTargetData, deviceConfig, requestContext);
    }


    this.getConfigurations = function (targetWithTemplate, requestContext) {
        var neId = parseTarget.getNeIdFromTarget(targetWithTemplate);
        logger.info('getConfigurations: neId = ' + neId + ", neId = " + JSON.stringify(neId));
        var discoveryHelper = this.getDiscoveryHelper(neId);
        logger.info('getConfigurations: discoveryHelper = ' + discoveryHelper + ", discoveryHelper = " + JSON.stringify(discoveryHelper));

        if (discoveryHelper instanceof NfmpDiscoveryHelper) {
            // Step 1: Determine Devices to be configured by this intent
            var deviceInfos = this.extensionConfig.getDevicesInvolved();
            // Step 2 : update NSP Source
            var nfmpTunnelIds = new NSPInstance(this.imLogger).preDeploy(deviceInfos, requestContext, this.navigateInstance);
            logger.info('icm-fwk: getConfigurations: nfmpTunnelIds = ' + nfmpTunnelIds + ", nfmpTunnelIds = " + JSON.stringify(nfmpTunnelIds));
            requestContext.put("nfmpTunnelIds", nfmpTunnelIds);
        } else if(discoveryHelper instanceof MdcDiscoveryHelper) {
            //adding sourceNodeId to requestContext
            requestContext.put("neId",parseTarget.getNeIdFromTarget(targetWithTemplate));
        }

        return discoveryHelper.getDeviceConfiguration(targetWithTemplate, requestContext, neId);
    }

    this.getDiscoveryHelper = function (neId) {

        var managerName = mdtFwk.getManagerName(neId);
        logger.info('Device: ' + neId + ' is managed by: ' + managerName);

        switch (managerName)
        {
            case 'NFM-P':
                logger.info('Device is managed by NFMP')
                return this.createNfmpDiscoveryHelper()
                break;
            case 'MDC':
                logger.info('Device is managed by MDM')
                return this.createMdcDiscoveryHelper()
                break;
            default:
                logger.info('Device is not managed')
                throw new RuntimeException('Device is not Managed')
        }

        return ''
    }

    this.createNfmpDiscoveryHelper = function () {
        return new NfmpDiscoveryHelper();
    }

    this.createMdcDiscoveryHelper = function () {
        if (mdcDiscoveryHelper == null)
        {
            mdcDiscoveryHelper = new MdcDiscoveryHelper();
        }
        return mdcDiscoveryHelper;
    }

    this.extractDeviceConfig = function (templateName, neId, defaultTargetData, deviceConfig, requestContext) {
        var discoveryHelper = this.getDiscoveryHelper(neId);
        deviceConfig = this.getModifiedDeviceConfig(templateName, discoveryHelper, deviceConfig, requestContext, neId);
        if (discoveryHelper instanceof MdcDiscoveryHelper){
             templateMetaInfo = this.mdcDiscovery.getDeviceTemplate(neId, requestContext);
            if(templateMetaInfo["type"] === "Juniper" || templateMetaInfo["type"] === "ATN 950D" || templateMetaInfo["type"] === "ATN 910C-G" || templateMetaInfo["type"] === "NetEngine 8000"){
            var deviceConfigJson = JSON.parse(deviceConfig)
            return discoveryHelper.extractDeviceConfig(defaultTargetData, deviceConfigJson, requestContext, neId);
            }else{
                return discoveryHelper.extractDeviceConfig(defaultTargetData, deviceConfig, requestContext, neId);  
            }
        }else{
        return discoveryHelper.extractDeviceConfig(defaultTargetData, deviceConfig, requestContext, neId);
        }
    }

    this.navigateInstance = function (deviceId, requestContext) {
        logger.info("[icm-fwk][navigateInstance] invoked, deviceId = " + deviceId + ", requestContext = " + requestContext);
        var managerName = ietfUtils.getManagerName(deviceId);
        var lInstance = "";

        var lSourceNodeId = {};
        if (requestContext.get("sourceNodeId")) lSourceNodeId = requestContext.get("sourceNodeId");
        lSourceNodeId[deviceId] = deviceId;

        //Openconfig loopback handling
        if (!managerName) {
            logger.info('[icm-fwk][navigateInstance] Lookup Openconfig Loopback Address {}', deviceId);
            var nspMediator = new MediatorFramework("NSP");
            var payload = {
                "input": {
                    "xpath-filter": "/openconfig-interfaces:interfaces/interface/subinterfaces/subinterface[boolean(config[nsp-openconfig-interfaces-augments:loopback='true'])]/openconfig-if-ip:ipv4/addresses/address[ip='" + deviceId + "']",
                    "depth": "2"
                }
            };
            var openIntRes = nspMediator.post("https://restconf-gateway:443/restconf/operations/nsp-inventory:find", payload);
            if (openIntRes && openIntRes.success) {
                if (openIntRes.response["nsp-inventory:output"] && openIntRes.response["nsp-inventory:output"]["data"] && openIntRes.response["nsp-inventory:output"]["data"].length === 1) {
                    lSourceNodeId[deviceId] = openIntRes.response["nsp-inventory:output"]["data"][0]["@"]["nsp-model:network-id"];
                    managerName = ietfUtils.getManagerName(lSourceNodeId[deviceId]);
                    if (!managerName)
                        throw new RuntimeException('Device is not Managed');
                } else if (openIntRes.response["nsp-inventory:output"] && openIntRes.response["nsp-inventory:output"]["data"] && openIntRes.response["nsp-inventory:output"]["data"].length > 1) {
                    throw new RuntimeException('Found more than one Loopback in system');
                } else {
                    throw new RuntimeException('Device is not Managed');
                }
            }
        }
        requestContext.put("sourceNodeId", lSourceNodeId);

        logger.info('[icm-fwk][navigateInstance] Device: {} is managed by: {}', deviceId, managerName);

        if (!managerName) {
            throw new RuntimeException('Device is not Managed');
        }

        if (managerName.indexOf("MDC") !== -1)
        {
            lInstance = new MDMInstance();
            lInstance.setImLogger(this.imLogger);
        }
        else if (managerName.indexOf("NFM-P") !== -1)
        {
            lInstance = new NFMPInstance(lSourceNodeId[deviceId]);
            lInstance.setImLogger(this.imLogger);
        }
        else
            throw new RuntimeException('Device is not Managed')

        /*switch (managerName) {
            case 'NFM-P':
                lInstance = new NFMPInstance();
                lInstance.setImLogger(this.imLogger);
                break;
            case 'MDC':
                lInstance = new MDMInstance();
                lInstance.setImLogger(this.imLogger);
                break;
            default:
                throw new RuntimeException('Device is not Managed')
        }*/
        return lInstance;
    };

    this.setRequestContext = function (input) {
        var requestContext = new HashMap();
        requestScope.set(requestContext);

        requestContext.put("sync-input", input);
        requestContext.put("target", input.getTarget().split("#")[2]);
        logger.info("[icm-fwk][setRequestContext] target {} ", JSON.stringify(input.getTarget().split("#")[2]));
        requestContext.put("originalTarget", input.getTarget().split("#")[2]);
        logger.info("[icm-fwk][setRequestContext] originalTarget {} ", JSON.stringify(input.getTarget().split("#")[2]));
        var lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        logger.info("[icm-fwk][setRequestContext] lConfig {} ", JSON.stringify(lConfig));
        var lJson = lConfig[Object.keys(lConfig)[0]];
        lJson["hold-priority"] = 0;
        logger.info("[icm-fwk][setRequestContext] getJsonIntentConfiguration {} ", JSON.stringify(lJson));
        requestContext.put("intentConfigJson", lJson);
        requestContext.put("isBF", false);

        //BrownField
        var lTarget = input.getTarget().split("_");
        logger.info("[icm-fwk][setRequestContext] lTarget {} ", JSON.stringify(lTarget));
        if (lTarget && lTarget.length > 1) {
            if (lTarget[0] && lTarget[0] === lJson["source"]) {
                var modifiedTarget = lTarget.splice(1, lTarget.length - 1).join("_");
                logger.warn("[icm-fwk]BrownField Tunnel {} using {}", input.getTarget(), modifiedTarget);
                requestContext.put("target", modifiedTarget);
                requestContext.put("isBF", true);
            }
        }
        this.extensionConfig.setIntentTypeNameAndVersion();

        //this.setImLogger(new IntentLogger(requestContext.get("intentType"), requestContext.get("intentTypeVersion"), requestContext.get("target")));
        //requestContext.put("imLogger", logger);

        var topo = input.getCurrentTopology();
        logger.info("[icm-fwk][setRequestContext] input.getCurrentTopology {} ", JSON.stringify(topo));
        requestContext.put("createTopo", false);
        if (topo === null) {
            logger.info("[icm-fwk] Creating topology");
            topo = topologyFactory.createServiceTopology();
            requestContext.put("createTopo", true);
        }
        logger.info("[icm-fwk][setRequestContext] now currentTopology {} ", JSON.stringify(topo));
        requestContext.put("currentTopology", topo);
        requestContext.put("networkState", input.getNetworkState().name());
        requestContext.put("lspPathMap", {});

        logger.info("[icm-fwk][setRequestContext] requestContext {} ", JSON.stringify(requestContext));
        return requestContext;
    };

}
