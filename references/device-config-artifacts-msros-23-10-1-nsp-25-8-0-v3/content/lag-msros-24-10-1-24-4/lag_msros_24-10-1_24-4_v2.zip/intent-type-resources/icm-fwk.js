load({
  script: resourceProvider.getResource("mediator-fwk.js"),
  name: "mediator-fwk",
});
var nfmpFwk = new MediatorFramework("NFMP");

load({
  script: resourceProvider.getResource("nsp-restconf-fwk.js"),
  name: "nsp-restconf-fwk",
});
var nspRestconfFwk = new NspRestconfFwk();

load({
  script: resourceProvider.getResource("discovery-helper-nfmp.js"),
  name: "discovery-helper-nfmp",
});
load({
  script: resourceProvider.getResource("discovery-helper-mdc.js"),
  name: "discovery-helper-mdc",
});
load({
  script: resourceProvider.getResource("mdt-fwk.js"),
  name: "MdtFwk",
});
load({
  script: resourceProvider.getResource("parse-target.js"),
  name: "ParseTarget",
});


function ICMFwk() {
  let mdtFwk = new MdtFwk();
  let parseTarget = new ParseTarget();
  let mdcDiscoveryHelper = null;

  /**
   * get the device configuration
   * @param {*} targetWithTemplate
   * @param {*} deviceYangModuleName
   * @param {*} parentXpath
   * @param {*} intentContainer
   * @returns
   */
  this.getDeviceConfiguration = function (
    targetWithTemplate,
    deviceYangModuleName,
    parentXpath,
    intentContainer
  ) {
    logger.info("ICMFwk::getDeviceConfiguration");
    let targetAr = targetWithTemplate.split("#");
    let templateName = targetAr[0];
    let neId = parseTarget.getNeIdFromTarget(targetWithTemplate);
    let discoveryHelper = this.getDiscoveryHelper(neId);
    let targetDataStruct = this.getTargetDataStruct(templateName);
    let deviceConfig = discoveryHelper.getDeviceConfiguration(
      targetWithTemplate,
      deviceYangModuleName,
      parentXpath,
      intentContainer
    );
    if (
      typeof deviceConfig === "string" &&
      deviceConfig.indexOf("Failed to fetch service") > -1
    ) {
      logger.error(deviceConfig);
      return deviceConfig;
    }
    let postDiscObj = {
    deviceConfig: deviceConfig,
    intentContainer: intentContainer,
    neId: neId,
    targetDataStruct: targetDataStruct,
    templateName: templateName,
    deviceYangModuleName: deviceYangModuleName
  }
    customHooks.postDiscovery(postDiscObj);
    deviceConfig = postDiscObj.deviceConfig;
    intentContainer= postDiscObj.intentContainer;
    neId= postDiscObj.neId;
    targetDataStruct= postDiscObj.targetDataStruct;
    templateName= postDiscObj.templateName;
    deviceYangModuleName= postDiscObj.deviceYangModuleName;
    return discoveryHelper.extractDeviceConfig(
      targetDataStruct,
      deviceConfig,
      intentContainer,
      neId
    );
  };

  /**
   *
   * Get the template object from ICM
   *
   * @param {*} templateName
   * @returns
   */
  this.getTemplate = function (templateName) {
    logger.info("ICMFwk::getTemplate::templateName = " + templateName);
    return nspRestconfFwk.getByXpath(
      "/nsp-icm:icm/templates/template=" + templateName
    );
  };

  /**
   * Get the getTargetDataStructructure of a Template
   * @param {*} templateName
   * @returns
   */
  this.getTargetDataStruct = function (templateName) {
    let templateObj = nspRestconfFwk.getByXpath(
      "/nsp-icm:icm/templates/template=" + templateName
    );
    let targetDataStruct =
      templateObj["nsp-icm:template"][0]["target-data-struct"];
    logger.info("\nICMFwk::getTargetDataStruct\n" + targetDataStruct);
    return targetDataStruct;
  };

  /**
   *
   * @param {*} neId
   * @returns
   */
  this.getDiscoveryHelper = function (neId) {
    let managerName = mdtFwk.getManagerName(neId);
    logger.info("Device: " + neId + " is managed by: " + managerName);

    switch (managerName) {
      case "NFM-P":
        logger.info("Device is managed by NFMP");
        return this.createNfmpDiscoveryHelper();
        break;
      case "MDC":
        logger.info("Device is managed by MDM");
        return this.createMdcDiscoveryHelper();
        break;
      default:
        logger.info("Device is not managed");
        throw new RuntimeException("Device is not Managed");
    }
    return "";
  };

  /**
   *
   * @returns
   */
  this.createNfmpDiscoveryHelper = function () {
    return new NfmpDiscoveryHelper();
  };

  /**
   *
   * @returns
   */
  this.createMdcDiscoveryHelper = function () {
    if (mdcDiscoveryHelper == null) {
      mdcDiscoveryHelper = new MdcDiscoveryHelper();
    }
    return mdcDiscoveryHelper;
  };
}
