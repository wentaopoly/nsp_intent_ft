function ModelDeviceMapping() {
    this.getMacFilterMapping = function () {
        var mapping = {};
        mapping['mac-filter.description'] = 'description';
        mapping['mac-filter.default-action'] = 'defaultAction';
        mapping['mac-filter.type'] = 'macFilterType';
        mapping['mac-filter.scope'] = 'scope';
        return mapping;
    }
}
