var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
const icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
const gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})

let intentTypeName = "router-ospf-area_csros_23-10-1_24-4";

// example port, sap-ingress etc..
let initialPropertyName = "ospf-AreaSite";


// unique identifier
let uniqueIdentifier = "instanceIndex,areaId";


/**
 * This function is starting point by IM for sync operation
 * @param input
 * @returns {*}
 */
function synchronize(input) {
    logger.info("-------------------- script-content.js -> synchronize() --------------------");
    logger.info("Intent Synchronisation started - input = {}", input)
    return NspIntentHelper.synchronize(input, intentTypeName, initialPropertyName, uniqueIdentifier);
}

/**
 * The function is starting point for audit operation in IM
 * @param input
 * @returns {*}
 */
function audit(input) {
    logger.info("-------------------- script-content.js -> audit() --------------------");
    logger.info("Intent Audit started - input = {}", input)
    return NspIntentHelper.audit(input, intentTypeName, initialPropertyName, uniqueIdentifier)
}

/**
 * This function returns NE-ID
 *
 * @param context
 * @returns {string}
 */
function getNeId(context) {
    logger.info("-------------------- script-content.js -> getNeId() --------------------");
    let neId;
    let target = context.getInputValues()["target"]["objectidentifier"];
    logger.info("target = {}", target)
    if (target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    logger.info("NeId : " + neId);
    return neId;
}

/**
 * The function is used in Brownfield discovery by ICM Framework
 * It discover's the configuration from the target device
 * and manipulate as per Template's default-target-data
 *
 * @see ICMFwk for more details
 * @param {*} input - the config data of a deployment
 * @returns result - the result of the operation
 */
function getTargetData(input) {
    logger.info("-------------------- script-content.js -> getTargetData() --------------------");
    logger.info("getTargetData input for brownfield = \n" + input);
    let target = input.target;
    let config = null;
    logger.info("target=" + target);
    let deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info("deviceConfig = {} ", JSON.stringify(deviceConfig));
    let data = gtdFwk.gtdSend(deviceConfig);
    logger.info("data = {}", JSON.stringify(data));
    logger.info("returning result = {}", JSON.stringify(data.msg.result));
    return data.msg.result;
}

function suggestAreaId(context) {
    let neId = getNeId(context);
    let instanceId = "";
    let InpVal = context.getInputValues();
    InpVal = JSON.parse(InpVal);
    InpVal = InpVal["target"]["target"];
    if(context.getInputValues()["action"]) {
      let templateName = Object.keys(InpVal);
      instanceId = InpVal[templateName]["target_instanceIndex"];
    }
    else {
      instanceId = context.getInputValues()["target"]["instanceIndex"];
    }
    return new NfmpSuggest().getAreaSite(getNeId(context),instanceId);
}

function suggestInstanceIndex(context) {
    let neId = getNeId(context);
    return new NfmpSuggest().getInstanceIndex(getNeId(context));
}

function suggestBIER(context) {
    let neId = getNeId(context);
    return new NfmpSuggest().getBIER(getNeId(context));
}

function suggestPolicy1(context) {
    let neId = getNeId(context);
    return new NfmpSuggest().getPolicy1(getNeId(context));
}
