load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})
function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        let objFullName = objectFullName;
        if (intentConfig["prefixListType"] == 'ipv4')
        {
            objFullName = objFullName.split("#")[0]
        }
        objFullName = objFullName.replace("type-ipv6", "type-IPv6");
        return objFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName.replace("type-ipv6", "type-IPv6");
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        let type = uniqueIdentifierValues[1];
        if (type == "ipv6")
        {
            return objectFullName.replace("type-ipv6", "type-IPv6");
        }
        else
        {
            return objectFullName.split("#")[0];
        }
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        var ipv6AddressUtil = new IPv6AddressUtil();
        payload = ipv6AddressUtil.expandIPv6(payload);
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        let nfmpSuggest = new NfmpSuggest();
        if(xpath == "filterprefixlist-PrefixListApplyPathMember.virtualRouterPointer")
        {
            targetValue = nfmpSuggest.getRoutingInstancePointer(neId, targetValue)
        }
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, neId) {
        let nfmpSuggest = new NfmpSuggest();
        if(xpath == "filterprefixlist-PrefixListApplyPathMember.virtualRouterPointer")
        {
            targetValue = targetValue+":"+neId.replaceAll(":", "_");
            targetValue = nfmpSuggest.getRoutingInstances(neId, targetValue);
        }
        return targetValue;
    }
}