var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk" });
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities" });
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk' });
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget' });

function NfmpPolicyStatement() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var savedObjects;
    var currentObjects;
    var isAudit = false;
    var isLocalExists = false;
    var isGlobalExists = false;
    this.synchronize = function (input, result, intentTypeName, xpath, initialPropertyName, uniqueIdentifier) {

        if (input.getNetworkState().name() == "delete") {
            return this.syncDelete(input, result);
        }

        var savedTopology = input.getCurrentTopology();
        logger.info(savedTopology);
        savedObjects = {};
        currentObjects = {};
        //loading the saved objects from topology
        this.loadSavedObjectsFromTopology(savedTopology);
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        //intentConfig = this.removeEmptyContainers("", intentConfig, "", target);

        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));

        logger.info("Target device = " + target);
        logger.info("Target policy-statement = " + intentConfig[uniqueIdentifier]);
        //throw new RuntimeException("config"+ JSON.stringify(intentConfig));

        this.createOrModify(target, uniqueIdentifier, intentConfig);
        var currentTopo = this.loadCurrentObjectsToTopology(target);

        return util.setSuccessResult(result, currentTopo);
        return result;
    }

    this.audit = function (target, config, svcTopo, adminState, auditReport, intentTypeName, xpath, initialPropertyName, uniqueIdentifier) {

        var savedTopology = svcTopo;
        savedObjects = {};
        currentObjects = {};
        isAudit = true;
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        //intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
        // Prefix List ame is part of the target-component
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        var target = parseTarget.getNeIdFromTarget(target);
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target policy-statement = " + intentConfig[uniqueIdentifier]);

        if (intentConfig) {
            this.auditAndCompare(target, uniqueIdentifier, intentConfig, auditReport);
        } else {
            throw "configuration not available in the intent";
        }

        return auditReport
    }

    this.createOrModify = function (target, uniqueIdentifier, intentConfig) {

        // full class name for port and ethernet are same
        var fullClassName = "rp.PolicyStatement";
        // portlevel and ethernet level attributes have the same fdn
        var policyFdn = "rpStatement";
        // objectFullName is same as fdn for port level
        var objectFullName = "rpStatement:policy-stmt-" + intentConfig[uniqueIdentifier];
        var localPolicyFullName = "network:" + target + ":rpStatement:policy-stmt-" + intentConfig[uniqueIdentifier];
        if (target && String(target).indexOf(':') !== -1) {
            localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, target);
        }
        var localPolicy = util.getIfObjectExists("rp.PolicyStatement", localPolicyFullName);
        if (localPolicy != null) {
            isLocalExists = true;
            isGlobalExists = true;
        }
        else {
            if (util.isObjectExists(fullClassName, objectFullName)) {
                isGlobalExists = true;
            }
            else {
                var statementEntryPayload = this.createPolicyLevelPayLoad(target, uniqueIdentifier, intentConfig, false, true);

                var result = this.modifyRequest(target, statementEntryPayload);
            }
            // distribute the policy to the local
            // Distribute Global Policy to Ne in Target
            let distributeResult = this.distributePolicy(target, uniqueIdentifier, intentConfig, false);

            if (!distributeResult.success) {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }

            // Changing SyncWithGlobal To Local Edit Only
            distributeResult = this.distributePolicy(target, uniqueIdentifier, intentConfig, true);

            if (!distributeResult.success) {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }

            return result;
        }

        var statementEntryPayload = this.createPolicyLevelPayLoad(target, uniqueIdentifier, intentConfig, true, false);

        // removing the delete objects
        this.deleteRemovedObjects(target);

        var result = this.modifyRequest(target, statementEntryPayload);

        return result;

    }

    this.auditAndCompare = function (target, uniqueIdentifier, intentConfig, auditReport) {

        var statementEntryPayload = this.createPolicyLevelPayLoad(target, uniqueIdentifier, intentConfig);
        var result = this.auditRequest(target, statementEntryPayload);
        auditReport = util.reportMisaligned(target, result, auditReport);
        return auditReport;

    }

    this.createPolicyLevelPayLoad = function (target, uniqueIdentifier, intentConfig, isLocalExists, isCreate) {

        // full class name for port and ethernet are same
        var fullClassName = "rp.PolicyStatement";
        // portlevel and ethernet level attributes have the same fdn
        var policyFdn = "rpStatement";
        // objectFullName is same as fdn for port level
        var objectFullName = "rpStatement:policy-stmt-" + intentConfig[uniqueIdentifier];
        var localPolicyFullName = "network:" + target + ":rpStatement:policy-stmt-" + intentConfig[uniqueIdentifier];
        if (target && String(target).indexOf(':') !== -1) {
            localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, target);
        }
        if (isAudit == true || isLocalExists) {
            objectFullName = localPolicyFullName;
        }
        var properties = {};

        properties["policyStatementName"] = intentConfig[uniqueIdentifier];
        if(intentConfig["enableDefaultAction"] == true && intentConfig["default-action"])
        {
            var action = intentConfig["default-action"]["action-type"];
            if(action == "accept")
            {
                properties["action"] = "accept";
            }
            else if(action == "reject")
            {
                properties["action"] = "reject";
            }
            else if(action == "next-entry")
            {
                properties["action"] = "nextEntry"
            }
            else if(action == "next-policy")
            {
                properties["action"] = "nextPolicy"
            }
            else
            {
                properties["action"] = "none"
            }
        }
        var childProperties = [];
        if (intentConfig["entry"]) {
            if (!Array.isArray(intentConfig["entry"])) {
                intentConfig["entry"] = [intentConfig["entry"]];
            }
            for (var index in intentConfig["entry"]) {
                var intentStatementEntryConfig = intentConfig["entry"][index];
                var statementEntryPayload = this.createPolicyStatementEntryPayLoad(target, intentStatementEntryConfig, intentConfig,objectFullName);
                childProperties.push(statementEntryPayload);
            }
        }

        var policyLevelPayload = util.editPayload(policyFdn, properties, childProperties, fullClassName, objectFullName);
        return policyLevelPayload;
    }

    this.createPolicyStatementEntryPayLoad = function (target, intentSatememntEntryConfig, intentConfig, parentFullName) {

        var fullClassName = "rp.PolicyStatementEntry";
        var objectFullName = parentFullName+":stmt-entry-"+intentSatememntEntryConfig["entry-id"];
        var properties = {};

        properties["entryId"] = intentSatememntEntryConfig["entry-id"];
        properties["description"] = intentSatememntEntryConfig["description"];

        if(intentSatememntEntryConfig["action"])
        {
            var action = intentSatememntEntryConfig["action"]["action-type"];
            if(action == "accept")
            {
                properties["action"] = "accept";
            }
            else if(action == "reject")
            {
                properties["action"] = "reject";
            }
            else if(action == "next-entry")
            {
                properties["action"] = "nextEntry"
            }
            else if(action == "next-policy")
            {
                properties["action"] = "nextPolicy"
            }
            else
            {
                properties["action"] = "none"
            }
        }
        var childProperties = [];
        if (intentSatememntEntryConfig["from"]) {

            var intentFromCriteriaConfig = intentSatememntEntryConfig["from"];
            var fromCriteria = JSON.parse(JSON.stringify(intentFromCriteriaConfig));
            fromCriteria = this.removeEmptyContainers("",fromCriteria, "", "");
            if(!(fromCriteria == undefined && isAudit == true))
            {
                var statementEntryFromCriteriaPayload = this.createStatementEntryFromCriteriaPayLoad(target, intentFromCriteriaConfig, intentConfig, objectFullName);
                childProperties.push(statementEntryFromCriteriaPayload);
            }
        }
        if (intentSatememntEntryConfig["to"]) {

            var intentToCriteriaConfig = intentSatememntEntryConfig["to"];
            var toCriteria = JSON.parse(JSON.stringify(intentToCriteriaConfig));
            toCriteria = this.removeEmptyContainers("",toCriteria, "", "")
            if(!(toCriteria == undefined && isAudit == true))
            {
                var statementEntryToCriteriaPayload = this.createStatementEntryToCriteriaPayLoad(target, intentToCriteriaConfig, intentConfig);
                childProperties.push(statementEntryToCriteriaPayload);
            }
        }
        if (intentSatememntEntryConfig["action"]) {

            var intentEntryActionConfig = intentSatememntEntryConfig["action"];
            var actionConfig = JSON.parse(JSON.stringify(intentEntryActionConfig));
            actionConfig = this.removeEmptyContainers("",actionConfig, "", "");
            if(!(actionConfig == undefined && isAudit == true))
            {
                var statementEntryActionPayload = this.createStatementEntryActionPayLoad(target, intentEntryActionConfig, intentConfig,objectFullName);
                childProperties.push(statementEntryActionPayload);
            }
        }

        var statementEntryPayload = util.editChildPayload(properties, childProperties, fullClassName, objectFullName);

        return statementEntryPayload;
    }

    this.createStatementEntryFromCriteriaPayLoad = function (target, intentFromCriteriaConfig, intentConfig, parentFullName) {

        var fullClassName = "rp.FromCriteria";
        var properties = {};
        var objectFullName = parentFullName+":from-criteria";

        if( intentFromCriteriaConfig["community"])
        {
            if(intentFromCriteriaConfig["community"]["name"])
            {
                properties["communityName"] = intentFromCriteriaConfig["community"]["name"];
            }
            else
            {
                properties["communityName"] = "";
            }
        }
        else
        {
            properties["communityName"] = "";
        }

        if(intentFromCriteriaConfig["protocol"])
        {
            if (!Array.isArray(intentFromCriteriaConfig["protocol"]["name"])) {
                intentFromCriteriaConfig["protocol"]["name"] = [intentFromCriteriaConfig["protocol"]["name"]];
            }

            for (var index in intentFromCriteriaConfig["protocol"]["name"]) {
                var protocol =intentFromCriteriaConfig["protocol"]["name"][index];
                var index = intentFromCriteriaConfig["protocol"]["name"].indexOf(protocol);

                if (~index) {
                    intentFromCriteriaConfig["protocol"]["name"][index] = util.getNfmpProtocolName(protocol);
                }
            }
            properties["protocolBits"] = intentFromCriteriaConfig["protocol"]["name"];
        }

        if(intentFromCriteriaConfig["family"])
        {
            if (!Array.isArray(intentFromCriteriaConfig["family"])) {
                intentFromCriteriaConfig["family"] = [intentFromCriteriaConfig["family"]];
            }
            for (var index in intentFromCriteriaConfig["family"]) {
                var family =intentFromCriteriaConfig["family"][index];
                var index =intentFromCriteriaConfig["family"].indexOf(family);

                if (~index) {
                    intentFromCriteriaConfig["family"][index] = util.getNfmpFamilyName(family);
                }
            }

            properties["family"] = intentFromCriteriaConfig["family"];
        }

        var childProperties = [];
        if(intentFromCriteriaConfig["community"] != undefined)
        {
            if(intentFromCriteriaConfig["community"]["expression"] === undefined || intentFromCriteriaConfig["community"]["expression"] == "")
            {
                if(isAudit === false)
                {
                    logger.info("Deleting " + objectFullName+":CommuExp");
                    var deleteResult = nfmpFwk.deployDelete(objectFullName+":CommuExp", "application/json");

                    if (!deleteResult.success) {
                        throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
                    }
                }
            }
            else
            {
                var intentEntryFromCriteriaCommunityConfig = intentFromCriteriaConfig["community"];
                var statementEntryFromCriteriaCommunityPayload = this.createStatementEntryFromCriteriaCommunityExpressionPayLoad(target, intentEntryFromCriteriaCommunityConfig, intentConfig);
                childProperties.push(statementEntryFromCriteriaCommunityPayload);
            }
        }

        var statementEntryFromCriteriaPrefixListPayload = this.createStatementEntryFromCriteriaPrefixListPayLoad(target, intentFromCriteriaConfig, intentConfig);
        if(statementEntryFromCriteriaPrefixListPayload != undefined)
        {
            childProperties.push(statementEntryFromCriteriaPrefixListPayload);
        }

        var statementEntryFromCriteriaPayload = util.editChildPayload(properties, childProperties, fullClassName, objectFullName);

        return statementEntryFromCriteriaPayload;

    }
    this.createStatementEntryToCriteriaPayLoad = function (target, intentToCriteriaConfig, intentConfig) {

        var fullClassName = "rp.ToCriteria";
        var properties = {};

        if(intentToCriteriaConfig["protocol"])
        {
            if (!Array.isArray(intentToCriteriaConfig["protocol"]["name"])) {
                intentToCriteriaConfig["protocol"]["name"] = [intentToCriteriaConfig["protocol"]["name"]];
            }
            for (var index in intentToCriteriaConfig["protocol"]["name"]) {
                var protocol =intentToCriteriaConfig["protocol"]["name"][index];
                var index = intentToCriteriaConfig["protocol"]["name"].indexOf(protocol);

                if (~index) {
                    intentToCriteriaConfig["protocol"]["name"][index] = util.getNfmpProtocolName(protocol);
                }
            }
            properties["protocolBits"] = intentToCriteriaConfig["protocol"]["name"];
        }

        return this.createChildObjectPayload(fullClassName, properties);
    }
    this.createStatementEntryActionPayLoad = function (target, intentEntryActionConfig, intentConfig, parentFullName) {

        var fullClassName = "rp.Action";
        var objectFullName = parentFullName+":action";
        var properties = {};

        properties["preference"] = intentEntryActionConfig["preference"];
        if(isAudit == false)
        {
            properties["localPreferenceSet"] = "true";
        }
        properties["localPreference"] = intentEntryActionConfig["local-preference"];
        var childProperties = [];
        if(intentEntryActionConfig["community"] != undefined)
        {
            var intentEntryAddCommunityActionConfig = intentEntryActionConfig["community"];
            var statementEntryAddCommunityActionPayload = this.createStatementEntryAddCommunityActionPayLoad(target, intentEntryAddCommunityActionConfig, intentConfig);
            if(statementEntryAddCommunityActionPayload != undefined)
            {
                childProperties.push(statementEntryAddCommunityActionPayload);
            }
        }
        if(intentEntryActionConfig['admin-tag-policy'])
        {
            properties["adminTagPolicy"] = "rtrAdminTagPolicy:rtr-1-ratpol-" + intentEntryActionConfig["admin-tag-policy"];
        }
        else
        {
            properties["adminTagPolicy"] = "";
        }
        if(intentEntryActionConfig['create-mpls-tunnel'])
        {
            properties["createMplsTunnel"] = true;
        }
        else
        {
            properties["createMplsTunnel"] = false;
        }

        var statementEntryActionPayload = util.editChildPayload(properties, childProperties, fullClassName, objectFullName);

        return statementEntryActionPayload;

    }

    this.createStatementEntryAddCommunityActionPayLoad = function (target, intentEntryAddCommunityActionConfig, intentConfig) {

        var fullClassName = "rp.AddCommunityAction";
        var properties = {};

        if(intentEntryAddCommunityActionConfig["add"])
        {
            if (Array.isArray(intentEntryAddCommunityActionConfig["add"]))
            {
                properties["addCommunityName"] = "";
                for (var i =  0; i < intentEntryAddCommunityActionConfig["add"].length; i++)
                {
                    properties["addCommunityName"] = properties["addCommunityName"] + "\"" + intentEntryAddCommunityActionConfig['add'][i] + "\"";
                    if(i+1 < intentEntryAddCommunityActionConfig["add"].length)
                    {
                        properties["addCommunityName"] = properties["addCommunityName"]+" ";
                    }
                }
            }
            else
            {
                properties["addCommunityName"] = "\"" + intentEntryAddCommunityActionConfig['add'] + "\"";
            }

            if(isAudit == false)
            {
                properties["addCommunityName"] = "\" " + properties["addCommunityName"] + " \"";
            }
        }
        else
        {
            if(isAudit === false)
            {
                properties["addCommunityName"] = "";
            }
            else
            {
                return undefined;
            }
        }

        return this.createChildObjectPayload(fullClassName, properties);

    }

    this.createStatementEntryFromCriteriaCommunityExpressionPayLoad = function (target, intentEntryFromCriteriaCommunityMemberConfig, intentConfig) {

        var fullClassName = "rp.CommunityExpression";
        var properties = {};

        if(intentEntryFromCriteriaCommunityMemberConfig["expression"] === undefined || intentEntryFromCriteriaCommunityMemberConfig["expression"] == "")
        {
            properties["communityExpr"] = "";
        }
        else
        {
            properties["communityExpr"] = intentEntryFromCriteriaCommunityMemberConfig["expression"];
        }

        return this.createChildObjectPayload(fullClassName, properties);

    }

    this.createStatementEntryFromCriteriaPrefixListPayLoad = function (target, intentEntryFromCriteriaConfig, intentConfig) {

        var fullClassName = "rp.FromCriteriaPrefixListMembers";
        var properties = {};

        if(intentEntryFromCriteriaConfig["prefix-list"])
        {
            if (Array.isArray(intentEntryFromCriteriaConfig["prefix-list"]))
            {
                properties["addPrefixListMemberName"] = "";
                for (var i = 0; i < intentEntryFromCriteriaConfig["prefix-list"].length; i++)
                {
                    properties["addPrefixListMemberName"] = properties["addPrefixListMemberName"] + "\"" + intentEntryFromCriteriaConfig['prefix-list'][i] + "\"";
                    if(i+1 < intentEntryFromCriteriaConfig["prefix-list"].length)
                    {
                        properties["addPrefixListMemberName"] = properties["addPrefixListMemberName"]+" ";
                    }
                }
            }
            else
            {
                properties["addPrefixListMemberName"] = "\"" + intentEntryFromCriteriaConfig['prefix-list'] + "\"";
            }
            if(isAudit == false)
            {
                properties["addPrefixListMemberName"] = "\" " + properties["addPrefixListMemberName"] + " \"";
            }
        }
        else
        {
            if(isAudit === false)
            {
                properties["addPrefixListMemberName"] = "";
            }
            else
            {
                return undefined;
            }
        }

        return this.createChildObjectPayload(fullClassName, properties);
    }

    this.syncDelete = function (input, result) {

        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var statementEntry = parseTarget.getUniqueIdentifier(input.getTarget());
        var objectFullName = "network:" + neId + ":rpStatement:policy-stmt-" + statementEntry;
        if (neId && String(neId).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        }
        logger.info("Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success) {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }

    this.modifyRequest = function (target, payload) {

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            logger.error("Error while deploying the request {}", JSON.stringify(result.msg));
		    let objFullName = payload["objectFullName"];
            if (target && String(target).indexOf(':') !== -1) {
                objFullName = util.modifyNeIdForIpV6(objFullName, target);
            }
		    if(!(objFullName.indexOf("network") !== -1))
		    {
                logger.info("Redeploying the request ...  ");
                result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
                if (!result.success)
                {
                    throw new RuntimeException(result.msg)
                }
		    }
		    else
		    {
                throw new RuntimeException(result.msg)
		    }
        }
        return result;

    }

    this.createChildObjectPayload = function (fullClassName, properties) {

        var childObjectPayLoad = {};
        childObjectPayLoad['objectClassName'] = fullClassName;
        childObjectPayLoad['containedClassProperties'] = properties;
        return childObjectPayLoad;

    }

    this.auditRequest = function (target, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;

    }

    this.distributePolicy = function (nodeIp, uniqueIdentifier, intentConfig, localEdit) {

        logger.info(" localEdit: " + localEdit);
        var objectFullName = "rpStatement:policy-stmt-" + intentConfig[uniqueIdentifier];
        var xmlReq = utilityService.processTemplate(resourceProvider.getResource(localEdit ? "distribute_local_edit.ftl" : "distribute.xml"), { nodeIp: nodeIp, objectFullName: objectFullName });
        logger.info(xmlReq);
        return nfmpFwk.passThroughRequest('/', xmlReq);

    }

    this.loadCurrentObjectsToTopology = function (target) {

        var currentTopo = topologyFactory.createServiceTopology();
        if (Object.keys(currentObjects).length) {
            for (var key in currentObjects) {
                objectId = mapFwk.get(currentObjects, key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key, objectId, "INFRASTRUCTURE", target, ""));
            }
        }
        return currentTopo;

    }

    this.loadSavedObjectsFromTopology = function (savedTopology) {

        if (savedTopology) {
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0) {
                topoObjects.forEach(function (topoObject) {
                    mapFwk.set(savedObjects, topoObject.getObjectType(), topoObject.getObjectRelativeObjectID());
                });
            }
        }

    }

    this.deleteRemovedObjects = function (target) {

        if (Object.keys(savedObjects).length > 0) {
            for (var key in savedObjects) {

                var value = mapFwk.get(currentObjects, key);
                if (value == undefined || value == "undefined" || value == null) {
                    logger.info("To be Deleted " + key);
                    var objectFullName = key;
                    if (target && String(target).indexOf(':') !== -1) {
                        objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
                    }
                    var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

                    if (!deleteResult.success) {
                        throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
                    }
                }

            }
        }

    }

    this.removeEmptyContainers = function (prop, intentJson, path, target) {

        if (Array.isArray(intentJson)) {
            var object = [];
            for (var prop in intentJson) {
                var value = this.removeEmptyContainers(prop, intentJson[prop], path, target);
                if (value) {
                    object.push(value);
                }

            }
            if (Object.keys(object).length !== 0) {
                return object;
            }
        } else if (typeof intentJson == 'object') {
            var object = {};
            for (var prop in intentJson) {
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop, intentJson[prop], pPath, target);
                if ((value && value !== null) || value == 0) {
                    object[prop] = value;
                }

            }
            if (Object.keys(object).length !== 0) {
                return object;
            }
        } else {
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if (intentJson !== undefined && intentJson !== "") {
                return intentJson;
            }

            return null;
        }
    }
}
