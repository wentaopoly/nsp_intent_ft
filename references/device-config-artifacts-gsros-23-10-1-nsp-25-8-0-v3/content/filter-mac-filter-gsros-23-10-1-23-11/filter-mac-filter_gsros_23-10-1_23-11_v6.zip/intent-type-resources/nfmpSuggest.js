load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {
    this.getMacFilterName = function (neId, filterId) {
        var className = "aclfilter.MacFilter";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "filterName",
                    "id"
                ]
            }
        };
        if (filterId) {
            var policyFilter = {};
            policyFilter["name"] = "id";
            policyFilter["value"] = filterId;
            searchObject["filter"]["and"]["equal"].push(policyFilter);
        }
        logger.info(LOG_PREFIX + "final search object = {}", searchObject);
        return this.getData(neId, searchObject, "filterName", filterId);
    }

    this.getMacFilterId= function (neId, filterName) {
        var className = "aclfilter.MacFilter";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "filterName",
                    "id"
                ]
            }
        };
        if (filterName) {
            var policyFilter = {};
            policyFilter["name"] = "filterName";
            policyFilter["value"] = filterName;
            searchObject["filter"]["and"]["equal"].push(policyFilter);
        }
        return this.getData(neId, searchObject, "id", filterName);
    }

    this.getData = function (target, searchObjectJson, type, filterPolicyAttribute) {
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.find(target, searchObjectJson);
        logger.info(LOG_PREFIX + resultFetch.response);
        var finalResponse = JSON.parse(resultFetch.response)["aclfilter.MacFilter"];
        logger.info(LOG_PREFIX + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                if (filterPolicyAttribute) {
                    logger.info(LOG_PREFIX + "Filter Selected = {}", filterPolicyAttribute);
                    logger.info(LOG_PREFIX + "Device policy = {}", finalResponse[index][type]);
                    ret.push(finalResponse[index][type]);
                    break;
                }
                else {
                    ret.push(finalResponse[index][type]);
                }
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "result = \n" + JSON.stringify(ret));
        return ret;
    }
    this.getFilterLog = function (neId) {
        var searchObjectJson = {
            "fullClassName": "nodelog.FilterLog",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        finalResponse = finalResponse["nodelog.FilterLog"];
        logger.info(JSON.stringify(finalResponse));

        if (Object.keys(finalResponse).length !== 0)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            finalResponse.forEach(function (value, index, array) {
                ret.push(value["id"]);
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }
}
