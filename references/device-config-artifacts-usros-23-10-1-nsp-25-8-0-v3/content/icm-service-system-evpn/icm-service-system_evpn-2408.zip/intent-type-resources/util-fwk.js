function utilities() {

  this.setSuccessResult = function (result, savedTopology) {
    result.setSuccess(true);
    if (savedTopology !== undefined) {
      result.setTopology(savedTopology);
    }
    return result;
  }

  this.reportMisaligned = function (target, result, auditReport) {
    var report = JSON.parse(result.response);
    if (!report.aligned) {
      for (var i = 0; i < report.misalignedAttributes.length; i++) {
        var attributeData = report.misalignedAttributes[i];
        var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
        auditReport.addMisAlignedAttribute(misalignedAttribute);
      }
    }
    return auditReport
  }
  this.editPayload = function (fdn, properties, fullClassName, objectFullName)
  {
    var payload = {};
    var configInfo = {};
    configInfo["containedClassProperties"] = properties;
    configInfo["objectClassName"] = fullClassName;
    payload["objectFullName"] = objectFullName;
    payload["distinguishedName"] = fdn;
    payload["configInfo"] = configInfo;
    return payload;
  }
  this.getBaseFdnForPort = function (target, portId) {
    if (portId.startsWith("esat"))
    {
      return this.getBaseFdnForSatellitePort(target, portId);
    }
    var portIds = portId.split("/");
    var cardSlot;
    var xiomSlot;
    var mdaSlot;
    var connector;
    var portNumber

    portIds.forEach(function (item, index) {
      // logger.info("*********************item, index = " + item + "-----" + index);
      switch (index)
      {
        case 0:
          cardSlot = item;
          break;
        case 1:
          //xiom
          if (isNaN(item))
          {
            xiomSlot = item;
          }
          else
          {
            mdaSlot = item;
          }
          break;
        case 2:
          //connector
          if (isNaN(item))
          {
            connector = item;
          }
          else if (mdaSlot)
          {
            portNumber = item;
          }
          else
          {
            mdaSlot = item;
          }
          break;
        case 3:
          //connector
          if (isNaN(item))
          {
            connector = item;
          }
          else
          {
            portNumber = item;
          }
          break;
        case 4:
          portNumber = item;
          break;


      }
    });

    // logger.info("************ cardSlot =" + cardSlot + ",xiomSlot=" + xiomSlot + ",mdaSlot=" + mdaSlot + ",connector=" + connector + ",portNumber=" + portNumber);
    //"network:92.168.96.22:shelf-1:cardSlot-1:card:xioSlot-1:xiomCard:daughterCardSlot-1:daughterCard:conn-1:port-1"

    var portDn = "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card";
    if (xiomSlot)
    {
      portDn += ":xioSlot-" + xiomSlot.substring(1) + ":xiomCard";
    }
    if (mdaSlot)
    {
      portDn += ":daughterCardSlot-" + mdaSlot + ":daughterCard";
    }
    if (connector)
    {
      portDn += ":conn-" + connector.substring(1);
    }
    if (portNumber)
    {
      portDn += ":port-" + portNumber;
    }
    if (target && String(target).indexOf(':') !== -1) {
        portDn = this.modifyNeIdForIpV6(portDn, target);
    }
    logger.info("*********************portDn = " + portDn);
    return portDn;
    //return "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card:daughterCardSlot-" + mdaSlot + ":daughterCard:port-" + portNumber;
  }

  this.getBaseFdnForSatellitePort = function (target, portId) {

    var portIds = (portId.split("-")[1]).split("/");
    var shelf = "shelf-1-5-";
    shelf += portIds[0];
    var satId = portIds[0];
    var cardSlot = "cardSlot-1:card";
    var mdaSlot = "daughterCardSlot-1:daughterCard";
    var portNumber = portIds[2];
    var snmpPortId = this.getSatellitePortSnmpId(satId, 1, portNumber, false, 5)
    //logger.info("******satellite port = shelf = "+shelf+", portnumber = "+portNumber +"\n portid = "+ portId+"\n portids = "+ portIds);
    var portDn = "network:" + target + ":" + shelf + ":" + cardSlot + ":" + mdaSlot + ":port-" + snmpPortId;
    if (target && String(target).indexOf(':') !== -1) {
        portDn = this.modifyNeIdForIpV6(portDn, target);
    }
    logger.info("SatPortDN = " + portDn);
    return portDn;
  }

  this.getSatellitePortSnmpId = function (aInSatId, aInSlotId, aInPortId, aInUplink, aInPhyShelfClass) {
    var aInSnmpIndex = aInPortId;
    var lUplinkBit = 0;
    if (aInUplink)
    {
      lUplinkBit = 1;
    }
    var lSatId = aInSatId << 16;
    var lSlotId = aInSlotId << 11;
    var lUplink = lUplinkBit << 10;
    var lSat = 136 << 23;
    aInSnmpIndex = lSat | lSatId | lSlotId | lUplink | aInSnmpIndex;
    return aInSnmpIndex;
  }

  this.getBaseFdnForLag = function (target, lagId)
  {
      var lagPointer = "network:" + target + ":lag:interface-" + lagId;
      if (target && String(target).indexOf(':') !== -1) {
         lagPointer = this.modifyNeIdForIpV6(lagPointer, target);
      }
      return lagPointer;
  }

  this.modifyNeIdForIpV6 = function (objectFullName, neId) {
     logger.info("modifying NeId For IpV6");
     objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
     return objectFullName;
  }
}
