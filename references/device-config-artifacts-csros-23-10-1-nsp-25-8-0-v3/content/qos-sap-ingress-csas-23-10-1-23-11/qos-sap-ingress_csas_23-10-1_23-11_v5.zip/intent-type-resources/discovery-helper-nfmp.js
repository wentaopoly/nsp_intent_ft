var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        logger.info("TARGET IS : " + target);
        let neId = parseTarget.getNeIdFromTarget(target);
        let sasPolicyName = target.split("#")[2];
        logger.info("sasPolicyName : " + JSON.stringify(sasPolicyName));
        let searchPayLoad = this.constructSearchString(neId, sasPolicyName);
        let searchResponse = nfmpFwk.post("/v3/search", searchPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find sas Policy  : " + sasPolicyName + " on NE " + neId);
        }
        searchResponse = JSON.parse(searchResponse.response);
        logger.info("searchResponse = {}", JSON.stringify(searchResponse));
        return searchResponse;
    }

    this.constructSearchString = function (neId, sasPolicyName) {
        logger.info("sasPolicyName : " + JSON.stringify(sasPolicyName));
        let objectFullName = "network:" + neId + ":sasAccessIngress:" + sasPolicyName;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        let fullClassName = "sasqos.AccessIngress";
        let jsonPayLoad = {
            "fullClassName": fullClassName,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        return jsonPayLoad;
    }

    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
//deviceConfig = deviceConfig["sasqos.AccessIngress"];
        logger.info("***********************************deviceConfig***********************************************");
        logger.info(JSON.stringify(deviceConfig));
        logger.info("************************************parsedDefaultTargetData***********************************");
        logger.info(JSON.stringify(parsedDefaultTargetData));
        logger.info("**************************************************END******************************************");


        let sasIngressConfig = deviceConfig['sasqos.AccessIngress'];
        if (null !== sasIngressConfig && sasIngressConfig !== undefined) {
            parsedDefaultTargetData = this.extractPolicyLevelProperties(parsedDefaultTargetData, sasIngressConfig);
        }
        let childrenConfig = sasIngressConfig['children-Set'];
        if (undefined !== childrenConfig && null !== childrenConfig && childrenConfig.length !== 0) {

            let macCriteriaEntryData = parsedDefaultTargetData['sap-ingress']['mac-criteria']['entry'];
            if (macCriteriaEntryData !== null && macCriteriaEntryData.length !== 0) {
                let childMacCriteriaConfig = childrenConfig["sasqos.MacMatch"];
                if (childMacCriteriaConfig !== undefined && childMacCriteriaConfig.length != 0) {
                    let macCriteriaEntryArray = this.extractData(macCriteriaEntryData, childMacCriteriaConfig, 'sap-ingress.mac-criteria.entry');
                    parsedDefaultTargetData['sap-ingress']['mac-criteria']['entry'] = macCriteriaEntryArray;

                }
                else {
                    delete parsedDefaultTargetData['sap-ingress']['mac-criteria']['entry'];
                }
            }

            let ipCriteriaEntryData = parsedDefaultTargetData['sap-ingress']['ip-criteria']['entry'];
            if (ipCriteriaEntryData !== null && ipCriteriaEntryData.length !== 0) {
                let childIpCriteriaConfig = childrenConfig["sasqos.IpMatch"];
                if (childIpCriteriaConfig !== undefined && childIpCriteriaConfig.length != 0) {
                    let ipCriteriaEntryArray = this.extractData(ipCriteriaEntryData, childIpCriteriaConfig, 'sap-ingress.ip-criteria.entry');
                    parsedDefaultTargetData['sap-ingress']['ip-criteria']['entry'] = ipCriteriaEntryArray;
                }
                else {
                    delete parsedDefaultTargetData['sap-ingress']['ip-criteria']['entry'];
                }
            }

            let ipv6CriteriaEntryData = parsedDefaultTargetData['sap-ingress']['ipv6-criteria']['entry'];
            if (ipv6CriteriaEntryData !== null && ipv6CriteriaEntryData.length !== 0) {
                let childIpv6CriteriaConfig = childrenConfig["sasqos.Ipv6Match"];
                if (childIpv6CriteriaConfig !== undefined && childIpv6CriteriaConfig.length != 0) {
                    let ipv6CriteriaEntryArray = this.extractData(ipv6CriteriaEntryData, childIpv6CriteriaConfig, 'sap-ingress.ipv6-criteria.entry');
                    parsedDefaultTargetData['sap-ingress']['ipv6-criteria']['entry'] = ipv6CriteriaEntryArray;
                }
                else {
                    delete parsedDefaultTargetData['sap-ingress']['ipv6-criteria']['entry'];
                }
            }

            let fcData = parsedDefaultTargetData['sap-ingress']['fc']["fc"];
            if (fcData !== null && Array.isArray(fcData) && fcData.length !== 0) {
                let childFcConfig = childrenConfig["sasqos.AccessIngressForwardingClass"];
                if (childFcConfig !== undefined && childFcConfig.length != 0) {
                    let fcArray = this.extractData(fcData, childFcConfig, 'sap-ingress.fc.fc');
                    parsedDefaultTargetData['sap-ingress']['fc']["fc"] = fcArray;
                }
                else {
                    delete parsedDefaultTargetData['sap-ingress']['fc']["fc"];
                }
            }

            let meterData = parsedDefaultTargetData['sap-ingress']['meter']['meter'];
            if (meterData !== null && Array.isArray(meterData) && meterData.length !== 0) {
                let childMeterConfig = childrenConfig["sasqos.Meter"];
                if (childMeterConfig !== undefined && childMeterConfig.length != 0) {
                    let meterDataArray = this.extractData(meterData, childMeterConfig, 'sap-ingress.meter.meter');
                    parsedDefaultTargetData['sap-ingress']['meter']['meter'] = meterDataArray;
                }
                else {
                    delete parsedDefaultTargetData['sap-ingress']['meter']['meter'];
                }
            }

            let queueData = parsedDefaultTargetData['sap-ingress']['queue']["queue"];
            if (queueData !== null && Array.isArray(queueData) && queueData.length !== 0) {
                let childQueueConfig = childrenConfig["sasqos.AccessIngressQueue"];
                if (childQueueConfig !== undefined && childQueueConfig.length != 0) {
                    let queueArray = this.extractData(queueData, childQueueConfig, 'sap-ingress.queue.queue');
                    parsedDefaultTargetData['sap-ingress']['queue']["queue"] = queueArray;
                }
                else {
                    delete parsedDefaultTargetData['sap-ingress']['queue']["queue"];
                }
            }

        }
        return parsedDefaultTargetData;

    }

    this.extractPolicyLevelProperties = function (defaultTargetData, sasIngressConfig) {


        if(sasIngressConfig["description"]) {
            defaultTargetData["sap-ingress"]["description"] = sasIngressConfig["description"];
        }
        if(sasIngressConfig["defaultFc"]) {
            defaultTargetData["sap-ingress"]["default-fc"] = sasIngressConfig["defaultFc"];
        }
        if(sasIngressConfig["numQosClassifiers"]) {
            defaultTargetData["sap-ingress"]["num-qos-classifiers"] = sasIngressConfig["numQosClassifiers"];
        }
        if(sasIngressConfig["scope"]) {
            defaultTargetData["sap-ingress"]["scope"] = sasIngressConfig["scope"];
        }

        if(sasIngressConfig["tableClassificationCriteria"]) {
            defaultTargetData["sap-ingress"]["table-classification-criteria"] = this.transformTableClassificationCriteria(sasIngressConfig["tableClassificationCriteria"]);
        }
        else{
            defaultTargetData["sap-ingress"]["table-classification-criteria"] = "none";
        }


        if(sasIngressConfig["defaultFcProfile"]) {
            defaultTargetData["sap-ingress"]["profile"] = sasIngressConfig["defaultFcProfile"];
        }
        else {
            defaultTargetData["sap-ingress"]["profile"] = "None";
        }


        if(sasIngressConfig["macMatchCriteriaType"]) {
            defaultTargetData["sap-ingress"]["mac-match-criteria-type"] = sasIngressConfig["macMatchCriteriaType"];
        }
        else {
            defaultTargetData["sap-ingress"]["mac-match-criteria-type"] = "false";
        }

        if(sasIngressConfig["ipMatchCriteriaType"]) {
            defaultTargetData["sap-ingress"]["ip-match-criteria-type"] = sasIngressConfig["ipMatchCriteriaType"];
        }
        if(sasIngressConfig["enableIpv6Classification"] == "true") {
            defaultTargetData["sap-ingress"]["allow-any-ipv6-match"] = "true";
            defaultTargetData["sap-ingress"]["ipv6-match-criteria-type"] = sasIngressConfig["ipv6MatchCriteriaType"];
        }
        else{
            defaultTargetData["sap-ingress"]["ipv6-match-criteria-type"] = sasIngressConfig["ipv6MatchCriteriaType"];
            defaultTargetData["sap-ingress"]["allow-any-ipv6-match"] = "false";
        }

        if(sasIngressConfig["enableInnerDot1pMatch"] == "true") {
            defaultTargetData["sap-ingress"]["enable-inner-dot1p-match-criteria"] = "true";
        }
        else{
            defaultTargetData["sap-ingress"]["enable-inner-dot1p-match-criteria"] = "false";
        }

        if(sasIngressConfig["ipMacMatchClassificationType"]) {
            defaultTargetData["sap-ingress"]["ip-mac-match"] = this.transformIpMacMatchClassificationType(sasIngressConfig["ipMacMatchClassificationType"]);
        }
        if(sasIngressConfig["dscpClassificationPointer"] ) {
            defaultTargetData["sap-ingress"]["dscp-classification"] = this.transformDscpClassification(sasIngressConfig["dscpClassificationPointer"]);
        }
        else {
            delete defaultTargetData["sap-ingress"]["dscp-classification"];
        }
        if(sasIngressConfig["dot1pClassificationPointer"] != "") {
            defaultTargetData["sap-ingress"]["dot1p-classification"] = this.transformDot1pClassification(sasIngressConfig["dot1pClassificationPointer"]);
        }
        else {
            delete defaultTargetData["sap-ingress"]["dot1p-classification"];
        }
        return defaultTargetData;
    }




    this.extractMacData = function(defaultEntry, childrenConfiguration, path) {

        let objArray = [];
        let Defaults = defaultEntry[0];
        let mappings = modelDeviceMapping.getMapping(path);

        if(Array.isArray(childrenConfiguration)) {
            for (let i =0; i < childrenConfiguration.length; i++) {
                let Data = JSON.parse(JSON.stringify(Defaults));
                let objEntry = this.traverseAndUpdateDataConfig(path, Data, childrenConfiguration[i], mappings, Defaults);
                objArray.push(Data);
            }
        }
        else {
            let Data = JSON.parse(JSON.stringify(Defaults));
            this.traverseAndUpdateDataConfig(path, Data, childrenConfiguration, mappings, Defaults);
            //objArray.push(Defaults);
            objArray.push(Data);
        }
        return objArray;
    }


    this.extractData = function(defaultEntry, childrenConfiguration, path) {
        let EntryDefaults = defaultEntry[0];
        let EntryArray = [];
        let EntryData = "";
        if (childrenConfiguration !== undefined && childrenConfiguration !== null) {
            if (Array.isArray(childrenConfiguration)) {
                for (let i = 0; i < childrenConfiguration.length; i++) {
                    let childConfig = childrenConfiguration[i];
                    if(path == 'sap-ingress.mac-criteria.entry') {
                        EntryData = this.macEntryData(EntryDefaults, childConfig);
                    }
                    else if(path == "sap-ingress.ip-criteria.entry") {
                        EntryData = this.ipEntryData(EntryDefaults, childConfig);
                    }
                    else if(path == "sap-ingress.ipv6-criteria.entry") {
                        EntryData = this.ipv6EntryData(EntryDefaults, childConfig);
                    }
                    else if(path == "sap-ingress.fc.fc") {
                        EntryData = this.fcEntryData(EntryDefaults, childConfig);
                    }
                    else if(path == "sap-ingress.meter.meter") {
                        EntryData = this.meterEntryData(EntryDefaults, childConfig);
                    }
                    else if(path == "sap-ingress.queue.queue") {
                        EntryData = this.queueEntryData(EntryDefaults, childConfig);
                    }
                    EntryArray.push(EntryData);
                }
            } else {
                let childConfig = childrenConfiguration;
                if(path == 'sap-ingress.mac-criteria.entry') {
                    EntryData = this.macEntryData(EntryDefaults, childConfig);
                }
                else if(path == "sap-ingress.ip-criteria.entry") {
                    EntryData = this.ipEntryData(EntryDefaults, childConfig);
                }
                else if(path == "sap-ingress.ipv6-criteria.entry") {
                    EntryData = this.ipv6EntryData(EntryDefaults, childConfig);
                }
                else if(path == "sap-ingress.fc.fc") {
                    EntryData = this.fcEntryData(EntryDefaults, childConfig);
                }
                else if(path == "sap-ingress.meter.meter") {
                    EntryData = this.meterEntryData(EntryDefaults, childConfig);
                }
                else if(path == "sap-ingress.queue.queue") {
                    EntryData = this.queueEntryData(EntryDefaults, childConfig);
                }
                EntryArray.push(EntryData);
            }
        }
        return EntryArray;
    }

    this.queueEntryData = function(queueEntryDefaults, childConfig) {
        let queueData = JSON.parse(JSON.stringify(queueEntryDefaults));

        if(childConfig["id"]) {
            queueData["queue-id"] = childConfig["id"];
        }
        if(childConfig["displayedName"]) {
            queueData["name"] = childConfig["displayedName"];
        }
        if(childConfig["description"]) {
            queueData["description"] = childConfig["description"];
        }
        if(childConfig["weight"]) {
            queueData["weight"] = childConfig["weight"];
        }
        if(childConfig["priority"]) {
            queueData["priority"] = childConfig["priority"];
        }
        if(childConfig["queuemgmtPolicyPointer"]) {
            queueData["queue-management-policy"] = this.transformSasQueueMgmtPolicy(childConfig["queuemgmtPolicyPointer"]);
        }
        if(childConfig["slopePolicyPointer"]) {
            queueData["slope-policy"] = this.transformSasSlope(childConfig["slopePolicyPointer"]);
        }
        if(childConfig["portParent"]) {
            queueData["port-parent"]["port-parent"] = childConfig["portParent"];
        }
        if(childConfig["portParentWeight"]) {
            queueData["port-parent"]["weight"] = this.transformWeight(childConfig["portParentWeight"]);
        }
        if(childConfig["portParentCirLevel"]) {
            queueData["port-parent"]["Cir-level"] = this.transformLevel(childConfig["portParentCirLevel"]);
        }
        if(childConfig["cir"] || childConfig["cir"] == 0) {
            queueData["rate"]["Cir"] = childConfig["cir"];
            if(childConfig["cir"] == "-1") {
                queueData["rate"]["cir-max"] = "true";
            }
            else {
                queueData["rate"]["cir-max"] = "false";
            }
        }
        if(childConfig["pir"] || childConfig["pir"] == 0) {
            queueData["rate"]["Pir"] = childConfig["pir"];
            if(childConfig["pir"] == "-1") {
                queueData["rate"]["pir-max"] = "true";
            }
            else {
                queueData["rate"]["pir-max"] = "false";
            }
        }
        if(childConfig["cirAdaptation"]) {
            queueData["adaptation-rule"]["cir"] = childConfig["cirAdaptation"];
        }
        if(childConfig["pirAdaptation"]) {
            queueData["adaptation-rule"]["pir"] = childConfig["pirAdaptation"];
        }
        if(childConfig["committedBurstSize"]) {
            if(queueData["Burst-Size"]["admin-CBS"] != "-1") {
                queueData["Burst-Size"]["admin-CBS"] = childConfig["committedBurstSize"];
                queueData["Burst-Size"]["default-cbs"] = "false";
            }
            else {
                queueData["Burst-Size"]["admin-CBS"] = "-1";//childConfig["committedBurstSize"];
                queueData["Burst-Size"]["default-cbs"] = "true";
            }
        }
        if(childConfig["maximumBurstSize"]) {
            queueData["Burst-Size"]["admin-MBS"] = childConfig["maximumBurstSize"];
            if(queueData["Burst-Size"]["admin-MBS"] != "-1") {
                queueData["Burst-Size"]["default-mbs"] = "false";
            }
            else {
                queueData["Burst-Size"]["default-mbs"] = "true";
            }
        }


        this.clearEmptiesAndNull(queueData);
        return queueData;

    }


    this.meterEntryData = function(meterEntryDefaults, childConfig) {

        let meterData = JSON.parse(JSON.stringify(meterEntryDefaults));
        if(childConfig["id"]) {
            meterData["meter-id"] = childConfig["id"];
        }
        if(childConfig["rateMode"]) {
            meterData["rate-mode"] = util.transformRateMode(childConfig["rateMode"]);
        }
        if(childConfig["colorMode"]) {
            meterData["color-mode"] = util.transformColorMode(childConfig["colorMode"]);
        }
        if(childConfig["cir"] || childConfig["cir"] == 0) {
            meterData["rate"]["Cir"] = childConfig["cir"];
            if(childConfig["cir"] == "-1") {
                meterData["rate"]["cir-max"] = "true";
            }
            else {
                meterData["rate"]["cir-max"] = "false";
            }
        }
        if(childConfig["pir"] || childConfig["pir"] == 0) {
            meterData["rate"]["Pir"] = childConfig["pir"];
            if(childConfig["pir"] == "-1") {
                meterData["rate"]["pir-max"] = "true";
            }
            else {
                meterData["rate"]["pir-max"] = "false";
            }
        }
        if(childConfig["cirAdaptation"]) {
            meterData["adaptation-rule"]["cir"] = childConfig["cirAdaptation"];
        }
        if(childConfig["pirAdaptation"]) {
            meterData["adaptation-rule"]["pir"] = childConfig["pirAdaptation"];
        }
        if(childConfig["cbsType"]) {
            meterData["Burst-Size"]["CBS-type"] = this.transformCBSType(childConfig["cbsType"]);

            if(childConfig["cbsType"] === "bytes" && childConfig["cbsBytes"]) {
                if(childConfig["cbsBytes"] != "-1") {
                    meterData["Burst-Size"]["default-cbs"] = "false";
                    meterData["Burst-Size"]["admin-CBS-bytes"] = childConfig["cbsBytes"];
                    meterData["Burst-Size"]["admin-CBS-kilobytes"] = -1;
                    meterData["Burst-Size"]["admin-CBS-kilobits"] = -1;
                }
                else {
                    meterData["Burst-Size"]["default-cbs"] = "true";
                    meterData["Burst-Size"]["admin-CBS-bytes"] = -1;
                    meterData["Burst-Size"]["admin-CBS-kilobytes"] = -1;
                    meterData["Burst-Size"]["admin-CBS-kilobits"] = -1;
                }
            }
            else if(childConfig["cbsType"] === "kbytes" && childConfig["cbsKiloBytes"]) {
                if(childConfig["cbsKiloBytes"] != "-1") {
                    meterData["Burst-Size"]["admin-CBS-kilobytes"] = childConfig["cbsKiloBytes"];
                    meterData["Burst-Size"]["admin-CBS-kilobits"] = -1;
                    meterData["Burst-Size"]["admin-CBS-bytes"] = -1;
                    meterData["Burst-Size"]["default-cbs"] = "false";
                }
                else {
                    meterData["Burst-Size"]["default-cbs"] = "true";
                    meterData["Burst-Size"]["admin-CBS-bytes"] = -1;
                    meterData["Burst-Size"]["admin-CBS-kilobytes"] = -1;
                    meterData["Burst-Size"]["admin-CBS-kilobits"] = -1;
                }
            }
            else if(childConfig["cbsType"] === "kbits" && childConfig["cbs"]) {
                if(childConfig["cbs"] != "-1") {
                    meterData["Burst-Size"]["admin-CBS-kilobits"] = childConfig["cbs"];
                    meterData["Burst-Size"]["admin-CBS-bytes"] = -1;
                    meterData["Burst-Size"]["admin-CBS-kilobytes"] = -1;
                    meterData["Burst-Size"]["default-cbs"] = "false";
                }
                else {
                    meterData["Burst-Size"]["default-cbs"] = "true";
                    meterData["Burst-Size"]["admin-CBS-bytes"] = -1;
                    meterData["Burst-Size"]["admin-CBS-kilobytes"] = -1;
                    meterData["Burst-Size"]["admin-CBS-kilobits"] = -1;
                }
            }
            else {
                meterData["Burst-Size"]["default-cbs"] = "true";
                meterData["Burst-Size"]["admin-CBS-bytes"] = -1;
                meterData["Burst-Size"]["admin-CBS-kilobytes"] = -1;
                meterData["Burst-Size"]["admin-CBS-kilobits"] = -1;
            }
        }
        if(childConfig["mbsType"]) {
            meterData["Burst-Size"]["MBS-type"] = this.transformMBSType(childConfig["mbsType"]);

            if(childConfig["mbsType"] === "bytes" && childConfig["mbsBytes"]) {
                if(childConfig["mbsBytes"] != "-1") {
                    meterData["Burst-Size"]["admin-MBS-bytes"] = childConfig["mbsBytes"];
                    meterData["Burst-Size"]["admin-MBS-kilobytes"] = -1;
                    meterData["Burst-Size"]["admin-MBS-kilobits"] = -1;
                    meterData["Burst-Size"]["default-mbs"] = "false";
                }
                else {
                    meterData["Burst-Size"]["default-mbs"] = "true";
                    meterData["Burst-Size"]["admin-MBS-bytes"] = -1;
                    meterData["Burst-Size"]["admin-MBS-kilobytes"] = -1;
                    meterData["Burst-Size"]["admin-MBS-kilobits"] = -1;
                }
            }
            else if(childConfig["mbsType"] === "kbytes" && childConfig["mbsKiloBytes"]) {
                if(childConfig["mbsKiloBytes"] != "-1") {
                    meterData["Burst-Size"]["admin-MBS-kilobytes"] = childConfig["mbsKiloBytes"];
                    meterData["Burst-Size"]["admin-MBS-kilobits"] = -1;
                    meterData["Burst-Size"]["admin-MBS-bytes"] = -1;
                    meterData["Burst-Size"]["default-mbs"] = "false";
                }
                else {
                    meterData["Burst-Size"]["default-mbs"] = "true";
                    meterData["Burst-Size"]["admin-MBS-bytes"] = -1;
                    meterData["Burst-Size"]["admin-MBS-kilobytes"] = -1;
                    meterData["Burst-Size"]["admin-MBS-kilobits"] = -1;
                }
            }
            else if(childConfig["mbsType"] === "kbits" && childConfig["mbs"]) {
                if(childConfig["mbs"] != "-1") {
                    meterData["Burst-Size"]["admin-MBS-kilobits"] = childConfig["mbs"];
                    meterData["Burst-Size"]["admin-MBS-bytes"] = -1;
                    meterData["Burst-Size"]["admin-MBS-kilobytes"] = -1;
                    meterData["Burst-Size"]["default-mbs"] = "false";
                }
                else {
                    meterData["Burst-Size"]["default-mbs"] = "true";
                    meterData["Burst-Size"]["admin-MBS-bytes"] = -1;
                    meterData["Burst-Size"]["admin-MBS-kilobytes"] = -1;
                    meterData["Burst-Size"]["admin-MBS-kilobits"] = -1;
                }
            }
            else {
                meterData["Burst-Size"]["default-mbs"] = "true";
                meterData["Burst-Size"]["admin-MBS-bytes"] = -1;
                meterData["Burst-Size"]["admin-MBS-kilobytes"] = -1;
                meterData["Burst-Size"]["admin-MBS-kilobits"] = -1;
            }
        }

        this.clearEmptiesAndNull(meterData);
        return meterData;
    }


    this.fcEntryData = function(fcEntryDefaults, childConfig) {

        let fcData = JSON.parse(JSON.stringify(fcEntryDefaults));
        if(childConfig["forwardingClass"]) {
            fcData["fc-name"] = childConfig["forwardingClass"];
        }
        if(childConfig["meterId"] || childConfig["meterId"] == "0") {
            fcData["meter-id"] = childConfig["meterId"];
        }
        if(childConfig["multicastQueueId"] || childConfig["multicastQueueId"] == "0") {
            fcData["multicast-queue-id"] = childConfig["multicastQueueId"];
        }
        if(childConfig["broadcastMeterId"] || childConfig["broadcastMeterId"] == "0") {
            fcData["broadcast-id"] = childConfig["broadcastMeterId"];
        }
        if(childConfig["unknownMeterId"] || childConfig["unknownMeterId"] == "0") {
            fcData["unknown-meter-id"] = childConfig["unknownMeterId"];
        }
        if(childConfig["multicastMeterId"] || childConfig["multicastMeterId"] == "0") {
            fcData["multicast-id"] = childConfig["multicastMeterId"];
        }
        if(childConfig["queueId"] || childConfig["queueId"] == "0") {
            fcData["queue-id"] = childConfig["queueId"];
        }
        if(childConfig["useDei"]) {
            fcData["use-Dei"] = childConfig["useDei"];
        }
        else {
            fcData["use-Dei"] = "false";
        }


        this.clearEmptiesAndNull(fcData);
        return fcData;
    }


    this.ipEntryData = function(ipEntryDefaults, childConfig) {

        let ipData = JSON.parse(JSON.stringify(ipEntryDefaults));
        if (childConfig['id']) {
            ipData['entry-id'] = childConfig['id'];
        }
        if (childConfig['description']) {
            ipData['description'] = childConfig['description'];
        }
        if (childConfig['protocol'] != "ALL") {
            ipData["match"]['protocol'] = childConfig['protocol'];
        }
        else {
            ipData["match"]["protocol"] = "NONE";
        }
        if (childConfig['sourceIpAddress']) {
            ipData["match"]["src-ip"]['address'] = childConfig['sourceIpAddress'];
            if(childConfig["sourceIpAddress"] != "0.0.0.0") {
                ipData["match"]["src-ip"]['src'] = "true";
            }
            else {
                ipData["match"]["src-ip"]['src'] = "false";
            }
        }
        if (childConfig['sourceIpAddressMask']) {
            ipData["match"]["src-ip"]['mask'] = this.transformIpMask(childConfig['sourceIpAddressMask']);
            if(ipData["match"]["src-ip"]['mask'] != "0") {
                ipData["match"]["src-ip"]['src'] = "true";
            }
            else {
                ipData["match"]["src-ip"]['src'] = "false";
            }
        }
        if (childConfig['destinationIpAddress']) {
            ipData["match"]["dst-ip"]['address'] = childConfig['destinationIpAddress'];
            if(childConfig["destinationIpAddress"] != "0.0.0.0") {
                ipData["match"]["dst-ip"]['dst'] = "true";
            }
            else {
                ipData["match"]["dst-ip"]['dst'] = "false";
            }
        }
        if (childConfig['destinationIpAddressMask']) {
            ipData["match"]["dst-ip"]['mask'] = this.transformIpMask(childConfig['destinationIpAddressMask']);
            if(ipData["match"]["dst-ip"]['mask'] != "0") {
                ipData["match"]["dst-ip"]['dst'] = "true";
            }
            else {
                ipData["match"]["dst-ip"]['dst'] = "false";
            }
        }
        if (childConfig['sourceOperator']) {
            ipData["match"]["src-port"]['src-prt'] = childConfig['sourceOperator'];
            if(childConfig["sourceOperator"] != "NONE") {
                ipData["match"]["src-port"]['src-port'] = "true";
            }
            else {
                ipData["match"]["src-port"]['src-port'] = "false";
            }
        }
        if (childConfig['sourcePort1']) {
            ipData["match"]["src-port"]['port-src'] = childConfig['sourcePort1'];
            if(childConfig["sourcePort1"] != "0") {
                ipData["match"]["src-port"]['src-port'] = "true";
            }
            else {
                ipData["match"]["src-port"]['src-port'] = "false";
            }
        }
        if (childConfig['destinationOperator']) {
            ipData["match"]["dst-port"]['dst-prt'] = childConfig['destinationOperator'];
            if(childConfig["destinationOperator"] != "NONE") {
                ipData["match"]["dst-port"]['dst-port'] = "true";
            }
            else {
                ipData["match"]["dst-port"]['dst-port'] = "false";
            }
        }
        if (childConfig['destinationPort1']) {
            ipData["match"]["dst-port"]['port-dst'] = childConfig['destinationPort1'];
            if(childConfig["destinationPort1"] != "0") {
                ipData["match"]["dst-port"]['dst-port'] = "true";
            }
            else {
                ipData["match"]["dst-port"]['dst-port'] = "false";
            }
        }
        if (childConfig['dscp']) {
            ipData["match"]["dscp"]['dscp-type'] = childConfig['dscp'];
            if(childConfig["dscp"] != "default") {
                ipData["match"]["dscp"]['dscp'] = "true";
            }
        }
        if (childConfig['dscpValue']) {
            ipData["match"]["dscp"]['dscp-value'] = childConfig['dscpValue'];
            if(childConfig["dscpValue"] != "-1") {
                ipData["match"]["dscp"]['dscp'] = "true";
            }
        }
        if (childConfig['dscpMask']) {
            ipData["match"]["dscp"]['dscp-mask'] = childConfig['dscpMask'];
            if(childConfig["dscpMask"] != "0") {
                ipData["match"]["dscp"]['dscp'] = "true";
            }
        }
        if(childConfig["dscp"] == "default" && childConfig["dscpValue"] == "-1" && childConfig["dscpMask"] == "0") {
            ipData["match"]["dscp"]['dscp'] = "false";
        }
        if (childConfig['ipPrecedence']) {
            ipData["match"]["ip-precedence"]['ip-precedence-value'] = this.transformIpPrecedence(childConfig['ipPrecedence']);
            if(childConfig["ipPrecedence"] != "default") {
                ipData["match"]["ip-precedence"]['ip-precedence'] = "true";
            }
        }
        if (childConfig['ipPrecedenceMask']) {
            ipData["match"]["ip-precedence"]['precedence-mask'] = this.transformIpPrecedence(childConfig['ipPrecedenceMask']);
            if(ipData["match"]["ip-precedence"]['precedence-mask'] != "0") {
                ipData["match"]["ip-precedence"]['ip-precedence'] = "true";
            }
        }
        if(childConfig["ipPrecedence"] == "default" && ipData["match"]["ip-precedence"]['precedence-mask'] == "0") {
            ipData["match"]["ip-precedence"]['ip-precedence'] = "false";
        }
        if (childConfig['forwardingClass'] != "") {
            ipData["action"]["fc"] = childConfig['forwardingClass'];
        }
        else {
            ipData["action"]["fc"] = "default";
        }
        this.clearEmptiesAndNull(ipData);
        return ipData;
    }

    this.ipv6EntryData = function(ipv6EntryDefaults, childConfig) {

        let ipData = JSON.parse(JSON.stringify(ipv6EntryDefaults));
        if (childConfig['id']) {
            ipData['entry-id'] = childConfig['id'];
        }
        if (childConfig['description']) {
            ipData['description'] = childConfig['description'];
        }
        if (childConfig['protocol'] != "ALL") {
            ipData["match"]['protocol'] = childConfig['protocol'];
        }
        else {
            ipData["match"]["protocol"] = "NONE";
        }
        if (childConfig['sourceIpAddress']) {
            ipData["match"]["src-ip"]['address'] = childConfig['sourceIpAddress'];
            if(childConfig["sourceIpAddress"] != "0:0:0:0:0:0:0:0") {
                ipData["match"]["src-ip"]['src'] = "true";
            }
            else {
                ipData["match"]["src-ip"]['src'] = "false";
            }
        }
        if (childConfig['sourceIpAddressMask']) {
            ipData["match"]["src-ip"]['mask'] = childConfig['sourceIpAddressMask'];
            if(childConfig["sourceIpAddressMask"] != "0") {
                ipData["match"]["src-ip"]['src'] = "true";
            }
            else {
                ipData["match"]["src-ip"]['src'] = "false";
            }
        }
        if (childConfig['destinationIpAddress']) {
            ipData["match"]["dst-ip"]['address'] = childConfig['destinationIpAddress'];
            if(childConfig["destinationIpAddress"] != "0:0:0:0:0:0:0:0") {
                ipData["match"]["dst-ip"]['dst'] = "true";
            }
            else {
                ipData["match"]["dst-ip"]['dst'] = "false";
            }
        }
        if (childConfig['destinationIpAddressMask']) {
            ipData["match"]["dst-ip"]['mask'] = childConfig['destinationIpAddressMask'];
            if(childConfig["destinationIpAddressMask"] != "0") {
                ipData["match"]["dst-ip"]['dst'] = "true";
            }
            else {
                ipData["match"]["dst-ip"]['dst'] = "false";
            }
        }
        if (childConfig['sourceOperator']) {
            ipData["match"]["src-port"]['src-prt'] = childConfig['sourceOperator'];
            if(childConfig["sourceOperator"] != "NONE") {
                ipData["match"]["src-port"]['src-port'] = "true";
            }
            else {
                ipData["match"]["src-port"]['src-port'] = "false";
            }
        }
        if (childConfig['sourcePort1']) {
            ipData["match"]["src-port"]['port-src'] = childConfig['sourcePort1'];
            if(childConfig["sourcePort1"] != "0") {
                ipData["match"]["src-port"]['src-port'] = "true";
            }
            else {
                ipData["match"]["src-port"]['src-port'] = "false";
            }
        }
        if (childConfig['destinationOperator']) {
            ipData["match"]["dst-port"]['dst-prt'] = childConfig['destinationOperator'];
            if(childConfig["destinationOperator"] != "NONE") {
                ipData["match"]["dst-port"]['dst-port'] = "true";
            }
            else {
                ipData["match"]["dst-port"]['dst-port'] = "false";
            }
        }
        if (childConfig['destinationPort1']) {
            ipData["match"]["dst-port"]['port-dst'] = childConfig['destinationPort1'];
            if(childConfig["destinationPort1"] != "0") {
                ipData["match"]["dst-port"]['dst-port'] = "true";
            }
            else {
                ipData["match"]["dst-port"]['dst-port'] = "false";
            }
        }
        if (childConfig['dscp']) {
            ipData["match"]["dscp"]['dscp-type'] = childConfig['dscp'];
            if(childConfig["dscp"] != "default") {
                ipData["match"]["dscp"]['dscp'] = "true";
            }
            else {
                ipData["match"]["dscp"]['dscp'] = "false";
            }
        }
        if (childConfig['dscpValue']) {
            ipData["match"]["dscp"]['dscp-value'] = childConfig['dscpValue'];
            if(childConfig["dscpValue"] != "-1") {
                ipData["match"]["dscp"]['dscp'] = "true";
            }
            else {
                ipData["match"]["dscp"]['dscp'] = "false";
            }
        }
        if (childConfig['dscpMask']) {
            ipData["match"]["dscp"]['dscp-mask'] = childConfig['dscpMask'];
            if(childConfig["dscpMask"] != "0") {
                ipData["match"]["dscp"]['dscp'] = "true";
            }
            else {
                ipData["match"]["dscp"]['dscp'] = "false";
            }
        }
        if (childConfig['ipPrecedence']) {
            ipData["match"]["ip-precedence"]['ip-precedence-value'] = this.transformIpPrecedence(childConfig['ipPrecedence']);
            if(childConfig["ipPrecedence"] != "default") {
                ipData["match"]["ip-precedence"]['ip-precedence'] = "true";
            }
            else {
                ipData["match"]["ip-precedence"]['ip-precedence'] = "false";
            }
        }
        if (childConfig['ipPrecedenceMask']) {
            ipData["match"]["ip-precedence"]['precedence-mask'] = this.transformIpPrecedence(childConfig['ipPrecedenceMask']);
            if(ipData["match"]["ip-precedence"]['precedence-mask'] != "0") {
                ipData["match"]["ip-precedence"]['ip-precedence'] = "true";
            }
            else {
                ipData["match"]["ip-precedence"]['ip-precedence'] = "false";
            }
        }
        if (childConfig['forwardingClass'] != "") {
            ipData["action"]["fc"] = childConfig['forwardingClass'];
        }
        else {
            ipData["action"]["fc"] = "Default";
        }
        this.clearEmptiesAndNull(ipData);
        return ipData;
    }

    this.macEntryData = function(macEntryDefaults, childConfig) {

        let ForwardingClassData = JSON.parse(JSON.stringify(macEntryDefaults));
        if (childConfig['id']) {
            ForwardingClassData['entry-id'] = childConfig['id'];
        }
        if (childConfig['description']) {
            ForwardingClassData["description"] = childConfig['description'];
        }
        ForwardingClassData["mac-criteria"] = "any";
        if (childConfig['macMatchCriteriaType']) {
            ForwardingClassData["mac-criteria"] = childConfig['macMatchCriteriaType'];
        }
        if (childConfig['dot1pValue']) {
            ForwardingClassData['match']['dot1p-value'] = this.transformDot1pValue(childConfig['dot1pValue']);
            if(childConfig["dot1pValue"] != "default") {
                ForwardingClassData['match']['dot1p'] = "true";
            }
            else {
                ForwardingClassData['match']['dot1p'] = "false";
            }
        }
        if (childConfig['dot1pMask']) {
            ForwardingClassData['match']['dot1p-mask'] = this.transformDot1pValue(childConfig['dot1pMask']);
            if(childConfig["dot1pMask"] != "priority_0") {
                ForwardingClassData['match']['dot1p'] = "true";
            }
            else {
                ForwardingClassData['match']['dot1p'] = "false";
            }
        }
        if (childConfig['innerDot1pValue']) {
            ForwardingClassData['match']['inner-dot1p-value'] = this.transformDot1pValue(childConfig['innerDot1pValue']);
            if(childConfig["innerDot1pValue"] != "default") {
                ForwardingClassData['match']['inner-dot1p'] = "true";
            }
            else {
                ForwardingClassData['match']['inner-dot1p'] = "false";
            }
        }
        if (childConfig['innerDot1pMask']) {
            ForwardingClassData['match']['inner-dot1p-mask'] = this.transformDot1pValue(childConfig['innerDot1pMask']);
            if(childConfig["innerDot1pMask"] != "priority_0") {
                ForwardingClassData['match']['inner-dot1p'] = "true";
            }
            else {
                ForwardingClassData['match']['inner-dot1p'] = "false";
            }
        }
        if (childConfig['outerDot1pValue']) {
            ForwardingClassData['match']['outer-dot1p-value'] = this.transformDot1pValue(childConfig['outerDot1pValue']);
            if(childConfig["outerDot1pValue"] != "default") {
                ForwardingClassData['match']['outer-dot1p'] = "true";
            }
            else {
                ForwardingClassData['match']['outer-dot1p'] = "false";
            }
        }
        if (childConfig['outerDot1pMask']) {
            ForwardingClassData['match']['outer-dot1p-mask'] = this.transformDot1pValue(childConfig['outerDot1pMask']);
            if(childConfig["outerDot1pMask"] != "priority_0") {
                ForwardingClassData['match']['outer-dot1p'] = "true";
            }
            else {
                ForwardingClassData['match']['outer-dot1p'] = "false";
            }
        }
        if (childConfig['ethernetType']) {
            ForwardingClassData['match']['e-type-value'] = childConfig['ethernetType'];
            if(childConfig["ethernetType"] != "-1") {
                ForwardingClassData['match']['e-type'] = "true";
            }
            else {
                ForwardingClassData['match']['e-type'] = "false";
            }
        }
        if (childConfig['sourceMacAddress']) {
            ForwardingClassData['match']['src-mac'] = childConfig['sourceMacAddress'];
            if(childConfig["sourceMacAddress"] != "00-00-00-00-00-00") {
                ForwardingClassData["match"]["src"] = "true";
            }
            else {
                ForwardingClassData['match']['src'] = "false";
            }
        }
        if (childConfig['sourceMacAddressMask']) {
            ForwardingClassData['match']['src-mask'] = childConfig['sourceMacAddressMask'];
            if(childConfig["sourceMacAddressMask"] != "00-00-00-00-00-00") {
                ForwardingClassData["match"]["src"] = "true";
            }
            else {
                ForwardingClassData['match']['src'] = "false";
            }
        }
        if (childConfig['destinationMacAddress']) {
            ForwardingClassData['match']['dst-mac'] = childConfig['destinationMacAddress'];
            if(childConfig["destinationMacAddress"] != "00-00-00-00-00-00") {
                ForwardingClassData["match"]["dst"] = "true";
            }
            else {
                ForwardingClassData['match']['dst'] = "false";
            }
        }
        if (childConfig['destinationMacAddressMask']) {
            ForwardingClassData['match']['dst-mask'] = childConfig['destinationMacAddressMask'];
            if(childConfig["destinationMacAddressMask"] != "00-00-00-00-00-00") {
                ForwardingClassData["match"]["dst"] = "true";
            }
            else {
                ForwardingClassData['match']['dst'] = "false";
            }
        }
        if (childConfig['innerTagValue']) {
            ForwardingClassData['match']['inner-tag-value'] = childConfig['innerTagValue'];
            if(childConfig["innerTagValue"] != "-1") {
                ForwardingClassData['match']['inner-tag'] = "true";
            }
            else {
                ForwardingClassData['match']['inner-tag'] = "false";
            }
        }
        if (childConfig['innerTagMask']) {
            ForwardingClassData['match']['inner-tag-vid-mask'] = childConfig['innerTagMask'];
            if(childConfig["innerTagMask"] != "4095") {
                ForwardingClassData['match']['inner-tag'] = "true";
            }
            else {
                ForwardingClassData['match']['inner-tag'] = "false";
            }
        }
        if (childConfig['outerTagValue']) {
            ForwardingClassData['match']['outer-tag-value'] = childConfig['outerTagValue'];
            if(childConfig["outerTagValue"] != "-1") {
                ForwardingClassData['match']['outer-tag'] = "true";
            }
            else {
                ForwardingClassData['match']['outer-tag'] = "false";
            }
        }
        if (childConfig['outerTagMask']) {
            ForwardingClassData['match']['outer-tag-vid-mask'] = childConfig['outerTagMask'];
            if(childConfig["outerTagMask"] != "4095") {
                ForwardingClassData['match']['outer-tag'] = "true";
            }
            else {
                ForwardingClassData['match']['outer-tag'] = "false";
            }
        }
        if (childConfig['forwardingClass'] != "") {
            ForwardingClassData['action']['fc'] = childConfig['forwardingClass'];
        }
        else{
            ForwardingClassData['action']['fc'] = "default";
        }
        if (childConfig['defaultFcProfile'] != "none") {
            if(childConfig['defaultFcProfile'] != "dei") {
                ForwardingClassData['action']['profile'] = childConfig['defaultFcProfile'];
            }
            else {
                ForwardingClassData['action']['profile'] = "DEI";
            }
        }
        else {
            ForwardingClassData['action']['profile'] = "none";
        }



        this.clearEmptiesAndNull(ForwardingClassData);
        return ForwardingClassData;

    }


    this.traverseAndUpdateDataConfig = function(objKey, obj, parsedDeviceConfig, mappings, Defaults) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;

            if (value != null && typeof value === 'object') {
                this.traverseAndUpdateDataConfig(mappedKey, value, parsedDeviceConfig, mappings, Defaults);
            } else {
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig, Defaults);
            }
        }
        //return Defaults;
        return obj;
    }




    this.traverseAndUpdateConfig = function (objKey, obj, parsedDeviceConfig, mappings, Defaults) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;

            if(mappedKey !== "sap-ingress.mac-criteria" &&  mappedKey !=="sap-ingress.ip-criteria" &&  mappedKey !=="sap-ingress.ipv6-criteria" && mappedKey !== "sap-ingress.meter" && mappedKey !=="sap-ingress.fc" && mappedKey !=="sap-ingress.queue") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateConfig(mappedKey, value, parsedDeviceConfig, mappings, Defaults);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig, Defaults);
                }
            }
        }
        //return Defaults;
        return obj;
    }


    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, deviceConfigData, Defaults) {
        let nfmpKey = mappings[mappedKey];

        let deviceValue = deviceConfigData[nfmpKey];
        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);
    }

    this.transformDeviceValue = function (mappedKey, deviceValue) {

        switch (mappedKey)
        {
            case "sap-ingress.meter.meter.rate-mode":
                deviceValue = util.transformRateMode(deviceValue);
                break;
            case "sap-ingress.meter.meter.color-mode":
                deviceValue = util.transformColorMode(deviceValue);
                break;
            case "sap-ingress.meter.meter.Burst-Size.CBS-type":
                deviceValue = this.transformCBSType(deviceValue);
                break;
            case "sap-ingress.meter.meter.Burst-Size.MBS-type":
                deviceValue = this.transformMBSType(deviceValue);
                break;
            case "sap-ingress.queue.queue.queue-management-policy":
                deviceValue = this.transformSasQueueMgmtPolicy(deviceValue);
                break;
            case "sap-ingress.queue.queue.slope-policy":
                deviceValue = this.transformSasSlope(deviceValue);
                break;
            case "sap-ingress.queue.queue.port-parent.weight":
                deviceValue = this.transformWeight(deviceValue);
                break;
            case "sap-ingress.queue.queue.port-parent.Cir-level":
                deviceValue = this.transformLevel(deviceValue);
                break;
            case "sap-ingress.mac-criteria.entry.match.dot1p-mask":
                deviceValue = this.transformDot1pMask(deviceValue);
                break;
            case "sap-ingress.mac-criteria.entry.match.inner-dot1p-mask":
                deviceValue = this.transformDot1pMask(deviceValue);
                break;
            case "sap-ingress.mac-criteria.entry.match.outer-dot1p-mask":
                deviceValue = this.transformDot1pMask(deviceValue);
                break;
            case "sap-ingress.mac-criteria.entry.match.dot1p-value":
                deviceValue = this.transformDot1pValue(deviceValue);
                break;
            case "sap-ingress.mac-criteria.entry.match.inner-dot1p-value":
                deviceValue = this.transformDot1pValue(deviceValue);
                break;
            case "sap-ingress.mac-criteria.entry.match.outer-dot1p-value":
                deviceValue = this.transformDot1pValue(deviceValue);
                break;
            case "sap-ingress.mac-criteria.entry.action.fc":
                deviceValue = this.transformFc(deviceValue);
                break;
            case "sap-ingress.dscp-classification":
                deviceValue = this.transformDscpClassificationPointer(deviceValue);
                break;
            case "sap-ingress.dot1p-classification":
                deviceValue = this.transformDot1pClassificationPointer(deviceValue);
                break;
            case "sap-ingress.ip-mac-match":
                deviceValue = this.transformIpMacMatchClassificationType(deviceValue);
                break;
            case "sap-ingress.table-classification-criteria":
                deviceValue = this.transformTableClassificationCriteria(deviceValue);
                break;
            case "sap-ingress.ip-criteria.entry.match.src-ip.mask":
                deviceValue = this.transformIpMask(deviceValue);
                break;
            case "sap-ingress.ip-criteria.entry.match.dst-ip.mask":
                deviceValue = this.transformIpMask(deviceValue);
                break;
            case "sap-ingress.ip-criteria.entry.match.ip-precedence.precedence-mask":
                deviceValue = this.transformIpPrecedence(deviceValue);
                break;
            case "sap-ingress.ipv6-criteria.entry.match.ip-precedence.precedence-mask":
                deviceValue = this.transformIpPrecedence(deviceValue);
                break;
            default:
                deviceValue = deviceValue;
                break;

        }
        return deviceValue;
    }

    this.transformLevel = function(value) {
        let arr = value.split("l");
        return arr[2];
    }

    this.transformFc = function(value) {
        if(value != "") {
            return "default";
        }
        return value;
    }

    this.transformIpPrecedence = function(value) {
        if(value == "default") {
            return value;
        }
        else {
            let arr = value.split("_");
            return arr[1];
        }

    }

    this.transformIpMask = function(value) {
        let arr = value.split("k");
        return arr[1];
    }

    this.transformWeight = function(value) {
        let arr = value.split("t");
        return arr[1];
    }

    this.transformSasQueueMgmtPolicy = function(value) {
        let arr = value.split(":");
        return arr[1];
    }

    this.transformSasSlope = function(value) {
        let arr = value.split(":");
        return arr[1];
    }

    this.transformDscpClassificationPointer = function(value) {
        let arr = value.split("-");
        return arr[1];
    }

    this.transformDot1pClassificationPointer = function(value) {
        let arr = value.split("-");
        return arr[1];
    }

    this.transformIpMacMatchClassificationType = function(value) {
        if(value == 'ip_first') {
            return 'ip-first';
        }
        else if(value == 'mac_first') {
            return 'mac-first';
        }
    }

    this.transformTableClassificationCriteria = function(value) {
        if(value == 'dscp') {
            return 'use-dscp';
        }
        else if(value == 'dotip') {
            return 'use-dot1p';
        }
        else if(value == 'both') {
            return 'both-dscp-dotip';
        }
        else {
            return 'none';
        }
    }

    this.transformColorMode = function(value) {
        if(value == 'colorAware') {
            return 'color-aware';
        }
        else {
            return 'color-blind';
        }
    }

    this.transformCBSType = function(value) {
        if(value == 'kbits') {
            return 'Kilobits';
        }
        else if(value == 'kbytes') {
            return 'Kilobytes';
        }
        else {
            return 'Bytes';
        }
    }

    this.transformMBSType = function(value) {
        if(value == 'kbits') {
            return 'Kilobits';
        }
        else if(value == 'kbytes') {
            return 'Kilobytes';
        }
        else {
            return 'Bytes';
        }
    }

    this.transformDot1pMask = function(value) {
        let arr = value.split("_");
        return arr[1];
    }

    this.transformDot1pClassification = function(value) {
        let arr = value.split("-");
        return arr[1];
    }


    this.transformDscpClassification = function(value) {
        let arr = value.split("-");
        return arr[1];
    }

    this.transformDot1pValue = function(value) {
        if(value == "default") {
            return "Not Set (-1)";
        }
        else {
            let arr = value.split("_");
            return arr[1];
        }
    }

    this.transformRateMode = function(value) {
        if(value == 'trtcm1') {
            return 'trTCM(RFC-2698)';
        }
        else if(value == 'trtcm2') {
            return 'trTCM(RFC-4115)';
        }
        else {
            return 'srTCM';
        }
    }

    this.clearEmptiesAndNull = function (o) {
        for (let k in o)
        {
            if (!o[k] || typeof o[k] !== "object")
            {
                continue
            }
            this.clearEmptiesAndNull(o[k]);
            if (Object.keys(o[k]).length === 0)
            {
                delete o[k];
            }
        }
    }
}
