<#ftl output_format="JSON">
<#setting number_format="computer">
{
    "distinguishedName":"lsp",
    "childConfigInfo": {
        <#if config["signaling-type"] == "path-setup-sr">
        "mpls.SegmentRoutingTeLsp": {
        <#else>
        "mpls.DynamicLsp": {
        </#if>
            "destinationNodeId": "${destinationNeId}",
            "children-Set": {
                <#if config["path-profile"]?has_content>
                    "mpls.PathProfile":{
                    <#if config["path-group"]?has_content>
                        "groupId": "${config["path-group"]?long?c}",
                    </#if>
                        "profileId": "${config["path-profile"]?long?c}"
                    },
                </#if>
                <#if config["color"]?has_content>
                    "mpls.LspAdminTag":{
                       "tagName": "${config["color"]}",
                       "tagPointer": "rtrAdminTag:rtr-1-tag-${config["color"]}"
                    },
                </#if>

                "mpls.LspPath": [
                <#list extraParams?values as value>
                {
                    "resourceId": ${value.id},
                    "bandwidth": ${value.bandwidth},
                    <#assign Inheritance = []>
                    <#if value.hop != 0>
                        <#assign Inheritance = Inheritance + [ "hopLimit" ] />
                        "hopLimit" : ${value.hop},
                    </#if>
                    <#if value.includeAdminGroup != 0>
                        <#assign Inheritance = Inheritance + [ "adminGroupInclude" ] />
                        "adminGroupInclude" : ${value.includeAdminGroup},
                    </#if>
                    <#if value.excludeAdminGroup != 0>
                        <#assign Inheritance = Inheritance + [ "adminGroupExclude" ] />
                        "adminGroupExclude" : ${value.excludeAdminGroup},
                    </#if>
                    <#if value.isAudit && value.isAudit == true>
                        <#if Inheritance?size !=0>
                            "propertyInheritance": [
                            <#list Inheritance as inharitVal>
                                "${inharitVal}"<#if inharitVal?has_next>,</#if>
                            </#list>
                            ],
                        <#else>
                            "propertyInheritance": "",
                        </#if>
                    <#else>
                        "propertyInheritance": {"bit":[
                        <#list Inheritance as inharitVal>
                            "${inharitVal}"<#if inharitVal?has_next>,</#if>
                        </#list>
                        ]},
                    </#if>
                    "record": true,
                    "holdPriority" : ${value.holdPriority},
                    "setupPriority" : ${value.setupPriority},
                    "type": "${value.type}",
                    "enableSrlg" : "${value.isSrlg?c}"
                }<#if value?has_next>,</#if>
                </#list>
                ],
                "mpls.LspExtension": {
                    <#if config["primary-paths"]?is_hash_ex && (config["primary-paths"]["primary-path"])?? && config["primary-paths"]["primary-path"]?size != 0>
                        <#list config["primary-paths"]["primary-path"]?values as value>
                            <#if value["use-path-computation"] == true>
                                "pathComputationMethod": "pce",
                                "pceReport" : "enable",
                                "pceControl" : "true",
                            <#else>
                                "pathComputationMethod": "localCspf",
                                "pceReport" : "inherit",
                                "pceControl" : "false",
                            </#if>
                        </#list>
                    </#if>
                    "adaptive": true,
                    "cspfEnabled": true,
                    <#if config["signaling-type"] == "path-setup-rsvp">
                        <#if config["protection"]["enable"] == true>
                            "fastRerouteEnabled": true,
                            <#if config["protection"]["protection-type"] == "lsp-protection-1-for-1">
                                "fastRerouteBackupType" : "oneToOne"
                            <#elseif config["protection"]["protection-type"] == "lsp-protection-1-for-n">
                                "fastRerouteBackupType" : "manyToOne"
                            </#if>
                        <#else>
                            "fastRerouteEnabled": false
                        </#if>
                    <#else>
                        "fastRerouteEnabled": false
                    </#if>
                }
            },
            "displayedName": "${target}",
            "sourceNodeId": "${sourceNeId}",
            "sourceIpAddress": "${device}",
            "pathId": ${config["nfmpTunnelId"]?long?c},
            "tunnelDestinationMatching": "none",
            "destinationIpAddress": "${destination}",
            <#if config["admin-state"] == "tunnel-admin-state-down">
                "administrativeState" : "lspDown",
            <#else>
                "administrativeState" : "lspUp",
            </#if>
            "description": "${config.description}"
        }
    }
}
