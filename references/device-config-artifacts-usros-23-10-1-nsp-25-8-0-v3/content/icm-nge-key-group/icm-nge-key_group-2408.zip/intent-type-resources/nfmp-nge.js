var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpNGE() {
    var util = new utilities();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var savedTopology;
    var isAudit = false;
    var nfmpFwkPostRequest = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true"
    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        if (input.getNetworkState().name() == "delete")
        {
            logger.info("Calling syncDelete");
            return this.syncDelete(input, result);
        }
        savedTopology = input.getCurrentTopology();
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        logger.info("lConfig = {}", JSON.stringify(lConfig));
        var intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        intentConfig["key-group-id"] = input.getTarget().split("#")[2];
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        this.createOrModify(neId, intentConfig);
        return util.setSuccessResult(result, savedTopology);
    }
    this.syncDelete = function (input, result) {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        logger.info("lConfig = {}", JSON.stringify(lConfig));
        var intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        var keyGroupId = input.getTarget().split("#")[2];
        var objectFullName = "ngeMgr:kg-0.0.0.0/" + keyGroupId;
        logger.info("Deleting " + objectFullName);

        //decrypt sdp
        if (intentConfig["sdp"])
        {
            var sdpConfig = intentConfig["sdp"];
            if (!Array.isArray(sdpConfig))
            {
                sdpConfig = [sdpConfig];
            }
            var instanceFullName = "ngeMgr:kg-0.0.0.0/" + keyGroupId;
            var sdpDecryptArray = [];
            var sdpSiteArray = [];
            for (var index in sdpConfig)
            {
                var includeConfig = sdpConfig[index];
                var sdp = includeConfig["name"];
                var siteId = includeConfig["source-id"]
                sdp = instanceFullName + ":kgsdpb" + sdp.split("from")[1];
                var siteFdn = "ngeMgr:kg-" + siteId + "/" + keyGroupId;
                sdpDecryptArray.push(sdp);
                sdpSiteArray.push(siteFdn);
            }
            if (sdpDecryptArray.length > 0)
            {
                logger.info("Decryprt existing SDPs");
                this.decryptSdp(instanceFullName, sdpDecryptArray);
            }
            if (sdpSiteArray.length > 0)
            {
                logger.info("Removing Sites");
                this.removeSites(instanceFullName, sdpSiteArray);
            }
        }
        var deleteKeyGroup = {
            "generic.GenericObject.deleteInstance": {
                "deployer": "immediate",
                "synchronousDeploy": false,
                "distinguishedName": objectFullName
            }
        }
        var deleteResult = nfmpFwk.post(nfmpFwkPostRequest, deleteKeyGroup);
        //var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }
    this.createOrModify = function (neId, intentConfig) {
        var keyGroupPayload = this.createKeyGroupPayLoad(neId, intentConfig);
        this.modifyRequest(neId, keyGroupPayload);
        if (intentConfig["sdp"])
        {
            var sdpConfig = intentConfig["sdp"];
            if (!Array.isArray(sdpConfig))
            {
                sdpConfig = [sdpConfig];
            }
            var instanceFullName = "ngeMgr:kg-0.0.0.0/" + intentConfig["key-group-id"];
            var sdpEncryptArray = [];
            var sdpDecryptArray = [];
            for (var index in sdpConfig)
            {
                var includeConfig = sdpConfig[index];
                var sdp = includeConfig["name"];
                sdp = instanceFullName + ":kgsdpb" + sdp.split("from")[1];
                if (includeConfig["encrypt"] === true)
                {
                    sdpEncryptArray.push(sdp);
                }
                else
                {
                    sdpDecryptArray.push(sdp);
                }
            }

            if (sdpEncryptArray.length > 0)
            {
                this.encryptSdp(instanceFullName, sdpEncryptArray);
            }
            if (sdpDecryptArray.length > 0)
            {
                this.decryptSdp(instanceFullName, sdpDecryptArray);
            }
        }
    }
    this.createKeyGroupPayLoad = function (neId, intentConfig) {
        var fullClassName = "nge.KeyGroup";
        var fdn = "ngeMgr";
        var objectFullName = "ngeMgr:kg-0.0.0.0/" + intentConfig["key-group-id"];

        var properties = {};
        properties["id"] = intentConfig["key-group-id"];
        properties["keyGroupName"] = intentConfig["key-group"]["key-group-name"];
        properties["description"] = intentConfig["key-group"]["description"];
        properties["progressiveRekey"] = "false"
        properties["forceRekey"] = "false"
        if (intentConfig["key-group"]["re-key"] === 'Progressive Rekey')
        {
            properties["progressiveRekey"] = "true"
            properties["forceRekey"] = "false"
        }
        else if (intentConfig["key-group"]["re-key"] === 'Force Rekey')
        {
            properties["progressiveRekey"] = "false"
            properties["forceRekey"] = "true"
        }
        properties["encrypAlgorithm"] = intentConfig["key-group"]["encryption-algorithm"];
        properties["authAlgorithm"] = intentConfig["key-group"]["authentication-algorithm"];
        var childProperties = {};
        if (intentConfig["sdp"])
        {
            var sdpConfig = intentConfig["sdp"];
            if (!Array.isArray(sdpConfig))
            {
                sdpConfig = [sdpConfig];
            }
            var sdpConfigArray = [];
            for (var index in sdpConfig)
            {
                var includeConfig = sdpConfig[index];
                var sdpProperties = {};
                sdpProperties["sdpFdn"] = includeConfig["name"];
                sdpProperties["sourceNodeId"] = includeConfig["source-id"];
                sdpProperties["destinationNodeId"] = includeConfig["destination-id"];
                sdpProperties["pathId"] = includeConfig["path-id"];
                if (isAudit)
                {
                    sdpProperties["adminEncryptionStatus"] = util.convertEncryptionGreenField(includeConfig["encrypt"])
                }
                sdpConfigArray.push(sdpProperties);
            }
            childProperties["nge.KeyGroupSdpBinding"] = sdpConfigArray;

        }
        else
        {
            childProperties["nge.KeyGroupSdpBinding"] = [];
        }
        var keyGroupPayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
        return keyGroupPayload;
    }
    this.modifyRequest = function (neId, payload) {
        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }
    this.encryptSdp = function (instanceFullName, sdpEncryptArray) {
        var payload = {
            "nge.KeyGroup.enableSdpEncryption": {
                "deployer": "immediate",
                "instanceFullName": instanceFullName,
                "keyGroupSdpBindingFullNames": {
                    "string": sdpEncryptArray
                }
            }
        }
        logger.info("Encrypt payload = {}", JSON.stringify(payload));
        var result = nfmpFwk.post("/rest/api/v3/request", payload);
        logger.info(JSON.stringify(result));
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
    }
    this.decryptSdp = function (instanceFullName, sdpDecryptArray) {
        var payload = {
            "nge.KeyGroup.disableSdpEncryption": {
                "deployer": "immediate",
                "instanceFullName": instanceFullName,
                "keyGroupSdpBindingFullNames": {
                    "string": sdpDecryptArray
                }
            }
        }
        logger.info("decrypt payload = {}", JSON.stringify(payload));
        var result = nfmpFwk.post("/rest/api/v3/request", payload);
        logger.info(JSON.stringify(result));
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        var failureReason = (JSON.parse(result.response))["nge.KeyGroup.disableSdpEncryptionException"];
        if (failureReason)
        {
            logger.error(JSON.stringify(failureReason) + ", retrying after 5 seconds");
            util.delay(5000);
            this.decryptSdp(instanceFullName, sdpDecryptArray);
        }
    }
    this.removeSites = function (instanceFullName, sdpSiteArray) {
        var payload = {
            "nge.KeyGroup.removeLocalKeyGroups": {
                "deployer": "immediate",
                "instanceFullName": instanceFullName,
                "localKeyGroupFullNames": {
                    "string": sdpSiteArray
                }
            }
        }
        logger.info("remove site payload = {}", JSON.stringify(payload));
        var result = nfmpFwk.post(nfmpFwkPostRequest, payload);
        logger.info(JSON.stringify(result));
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        var failureReason = (JSON.parse(result.response))["nge.KeyGroup.removeLocalKeyGroupsException"];
        if (failureReason)
        {
            logger.error(JSON.stringify(failureReason) + ", retrying after 5 seconds");
            util.delay(5000);
            this.removeSites(instanceFullName, sdpSiteArray);
        }
    }
    this.audit = function (input, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        isAudit = true;
        var lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        var intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        intentConfig["key-group-id"] = input.getTarget().split("#")[2];
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        if (intentConfig)
        {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }
        return auditReport
    }
    this.auditAndCompare = function (neId, intentConfig, auditReport) {
        var keyGroupPayload = this.createKeyGroupPayLoad(neId, intentConfig);
        var result = this.auditRequest(neId, keyGroupPayload);
        auditReport = util.reportMisaligned(neId, result, auditReport);
        return auditReport;
    }
    this.auditRequest = function (neId, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }
}
