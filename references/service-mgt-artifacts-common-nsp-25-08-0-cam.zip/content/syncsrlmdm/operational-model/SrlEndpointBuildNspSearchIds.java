package com.nokia.nsp.mdt.intents.ibsf.resync.mdc;


import com.nokia.nsp.md.db.yang.api.QueryParameters;
import com.nokia.nsp.md.resync.plugin.common.DeviceResyncClass;
import com.nokia.nsp.md.resync.plugin.common.IBuildNspSearchIds;
import com.nokia.nsp.md.resync.plugin.common.IFullResyncContext;
import com.nokia.nsp.md.resync.plugin.common.ResyncClass;


import java.util.ArrayList;
import java.util.List;

public class SrlEndpointBuildNspSearchIds implements IBuildNspSearchIds {

    @Override
    public List<String> buildNspFullResyncSearchIds(DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, IFullResyncContext aInIFullResyncContext, QueryParameters aOutQueryParameters) {
        List<String> lXPaths = new ArrayList<>(11);
        String lNeId = aInIFullResyncContext.getNeId();
        String lEndpointXPath = aInIFullResyncContext.getIYangPath().asString() + "[site-id='" + lNeId+ "']";
        lXPaths.add(lEndpointXPath);

        return lXPaths;
    }

}