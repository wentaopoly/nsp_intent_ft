
var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn" : "http://www.nokia.com/management-solutions/ibn",
    "nc" : "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager" : "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders" : "anv-device-holders"
};

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var nspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();


var intentTypeName = 'port-connector_gsros_23-10-1_23-11';
var initialPropertyName = "port";
var uniqueIdentifier = "portName";
var parentXpath = "configure";

function synchronize(input) {
    logger.info('Intent Synchronisation started')

    return nspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started')

    return nspIntentHelper.audit(target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function validate(syncInput) {
    var contextualErrorJsonObj = {};
    var intentConfig = syncInput.getJsonIntentConfiguration();

    // Code to validation here. Add errors to contextualErrorJsonObj.
    // contextualErrorJsonObj["attribute"] = "Attribute must be set";

    if (Object.keys(contextualErrorJsonObj).length !== 0) {
        utilityService.throwContextErrorException(contextualErrorJsonObj);
    }
}

function getTargetData(input) {
    logger.info("getTargetData input for brownfield = \n" + input);
    var target = input.target;
    var config = null;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info(JSON.stringify(deviceConfig));
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}
