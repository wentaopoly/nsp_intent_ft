function IcmServiceFwk() {
    GTD_HOST = "nsp-infra-config-server-app-service";
    GTD_PORT = "8888";

    this.configRestClient = function (url, httpMethod) {
        log.info(
            null,
            "[IcmServiceFwk] called with " +
            GTD_HOST +
            ":" +
            GTD_PORT +
            " and url " +
            url +
            " as HTTP " +
            httpMethod
        );
        restClient.setIp(GTD_HOST);
        restClient.setPort(GTD_PORT);
        restClient.setProtocol("http");
    };

    /**
     * Get target-data
     * @param {} data
     * @returns
     */
    this.gtdSend = function (data) {
        var result = {};
        this.configRestClient("action-result", "POST");
        logger.info(JSON.stringify(data));
        restClient.post(
            "action-result",
            "application/json",
            JSON.stringify(data),
            "application/json",
            function (exception, httpStatus, response) {
                if (exception) {
                    result = {
                        success: false,
                        httpStatus: httpStatus,
                        msg: "Couldn't connect got response " + response,
                    };
                }
                if (httpStatus !== 200 && httpStatus !== 201) {
                    result = {
                        success: false,
                        httpStatus: httpStatus,
                        msg: "Failed to fetch service got response " + response,
                    };
                } else {
                    logger.info(JSON.stringify(response));
                    result = {
                        success: true,
                        httpStatus: httpStatus,
                        msg: JSON.parse(response),
                    };
                }
            }
        );
        return result;
    };
}
