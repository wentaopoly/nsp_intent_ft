var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();
    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let distCpuPolicyName = parseTarget.getUniqueIdentifier(target);
        logger.info("neID = {}, Dist-CPU-PolicyName = {}", neId, distCpuPolicyName);
        let searchPayLoad = this.constructSearchString(neId, distCpuPolicyName);
        let searchResponse = nfmpFwk.post("search", searchPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find Dist CPU Policy  : " + distCpuPolicyName + " on NE " + neId);
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse[0];
    }
    this.constructSearchString = function (neId, distCpuPolicyName) {
        let fullName = "fullName = 'network:" + neId + ":DCpuProtection:" + distCpuPolicyName + "'"
        if (neId && String(neId).indexOf(':') !== -1) {
            fullName = util.modifyNeIdForIpV6(fullName, neId);
        }
        let jsonPayLoad = {
            "filter": {
                "filterExpression": fullName
            },
            "fullClassName": "sitesec.DCpuProtection"
        };
        return jsonPayLoad;
    }
    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        logger.info("***********************************deviceConfigSTART******************************************");
        logger.info(JSON.stringify(deviceConfig));
        logger.info("**********************************************************************************************");
        logger.info(JSON.stringify(parsedDefaultTargetData));
        logger.info("***********************************deviceConfigEND******************************************");
        let dCpuPolicyConfig = deviceConfig["properties"];
        let staticPolicierConfig = [];
        let localMonitorPolicierConfig = [];
        let protocolConfig = [];
        let dCpuChildrenConfig = deviceConfig['children'];
        if (dCpuChildrenConfig)
        {
            dCpuChildrenConfig.forEach(function (element) {
                if (element.fullClassName === 'sitesec.DCpuProtectionStaticPlcrEntry')
                {
                    staticPolicierConfig.push(element['properties']);
                }
                if (element.fullClassName === 'sitesec.DCpuProtectionLocMonPlcrEntry')
                {
                    localMonitorPolicierConfig.push(element['properties']);
                }
                if (element.fullClassName === 'sitesec.DCpuProtectionProtocolEntry')
                {
                    protocolConfig.push(element['properties']);
                }
            });
        }
        let dCpuPolicydeviceConfig = {
            "dCpuPolicyConfig": dCpuPolicyConfig,
            "staticPolicierConfig": staticPolicierConfig,
            "localMonitorPolicierConfig": localMonitorPolicierConfig,
            "protocolConfig": protocolConfig
        };

        logger.info("***********************************dCpuPolicydeviceConfigSTART******************************************");
        logger.info(JSON.stringify(dCpuPolicydeviceConfig));
        logger.info("***********************************dCpuPolicydeviceConfigEND******************************************");

        if (null !== dCpuPolicyConfig)
        {
            this.extractDcpuPolicyProperties(parsedDefaultTargetData, dCpuPolicydeviceConfig);
        }
        logger.info("Intent data after extractDcpuPolicyProperties :\n" + JSON.stringify(parsedDefaultTargetData));
        let staticPolicierData = parsedDefaultTargetData['policy']['static-policer'];
        if (staticPolicierData !== null && Array.isArray(staticPolicierData) && staticPolicierData.length !== 0)
        {
            let staticPolicierArray = this.extractDcpuChildrenProperties(parsedDefaultTargetData['policy']['static-policer'], dCpuPolicydeviceConfig.staticPolicierConfig, "static-policer");
            parsedDefaultTargetData['policy']['static-policer'] = staticPolicierArray;
        }
        logger.info("Intent data after staticPolicierArray :\n" + JSON.stringify(parsedDefaultTargetData));
        let localMonitorPolicierData = parsedDefaultTargetData['policy']['local-monitoring-policer'];
        if (localMonitorPolicierData !== null && Array.isArray(localMonitorPolicierData) && localMonitorPolicierData.length !== 0)
        {
            let localMonitorPolicierArray = this.extractDcpuChildrenProperties(parsedDefaultTargetData['policy']['local-monitoring-policer'], dCpuPolicydeviceConfig.localMonitorPolicierConfig, "local-monitoring-policer");
            parsedDefaultTargetData['policy']['local-monitoring-policer'] = localMonitorPolicierArray;
        }
        logger.info("Intent data after localMonitorPolicierArray :\n" + JSON.stringify(parsedDefaultTargetData));
        let protocolData = parsedDefaultTargetData['policy']['protocol'];
        if (protocolData !== null && Array.isArray(protocolData) && protocolData.length !== 0)
        {
            let protocolArray = this.extractDcpuChildrenProperties(parsedDefaultTargetData['policy']['protocol'], dCpuPolicydeviceConfig.protocolConfig, "protocol");
            parsedDefaultTargetData['policy']['protocol'] = protocolArray;
        }
        logger.info("Intent data after protocolArray :\n" + JSON.stringify(parsedDefaultTargetData));
        this.clearEmpties(parsedDefaultTargetData);
        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData));
        return parsedDefaultTargetData;
    }
    this.extractDcpuPolicyProperties = function (defaultTargetData, deviceConfig) {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj))
            if (targetObj !== null && typeof targetObj === 'object')
            {
                let mappings = modelDeviceMapping.getDcpuPolicyMapping();
                this.traverseAndUpdateConfig(targetKey, targetObj, mappings, deviceConfig);
            }
        }
        return defaultTargetData;
    }
    this.extractDcpuChildrenProperties = function (dcpuChildTargetData, deviceConfig, mappingType) {
        let dcpuChildArray = [];
        let mappings = modelDeviceMapping.getDcpuChildMapping();
        for (let i = 0; i < deviceConfig.length; i++)
        {
            let deviceChildConfig = deviceConfig[i];
            let dcpuChildData = JSON.parse(JSON.stringify(dcpuChildTargetData[0]));
            let keys = Object.keys(dcpuChildData);
            logger.info("keys = " + keys);
            for (let j = 0; j < keys.length; j++)
            {
                let targetKey = keys[j];
                let targetObj = dcpuChildData[targetKey];
                let mappedKey = "policy." + mappingType + "." + targetKey;
                logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj) + "\nmappedKey = " + mappedKey);
                if (targetObj !== null && typeof targetObj === 'object')
                {
                    this.traverseAndUpdateDcpuChildConfig(mappedKey, targetObj, mappings, deviceChildConfig)
                }
                else
                {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, dcpuChildData, deviceChildConfig);
                }
            }
            dcpuChildArray.push(JSON.parse(JSON.stringify(dcpuChildData)));
        }
        return dcpuChildArray;
    }
    this.traverseAndUpdateConfig = function (objKey, obj, mappings, deviceConfig) {
        logger.info("traverseAndUpdateConfig,objKey = {}, \nobj={}, \nmappings={}, \ndeviceConfig={}", objKey, JSON.stringify(obj), mappings, JSON.stringify(deviceConfig))
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            logger.info("key = {}", key);
            logger.info("value = {}", JSON.stringify(value));
            logger.info("**********mappedKey = " + mappedKey);
            if (value != null && typeof value === 'object')
            {
                continue;
            }
            else
            {
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, deviceConfig);
            }

        }
        return obj;
    }
    this.traverseAndUpdateDcpuChildConfig = function (objKey, obj, mappings, deviceConfig) {
        logger.info("traverseAndUpdateDcpuChildConfig,objKey = {}, \nobj={}, \nmappings={}, \ndeviceConfig={}", objKey, JSON.stringify(obj), JSON.stringify(mappings), JSON.stringify(deviceConfig))
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            logger.info("key = {}", key);
            logger.info("value = {}", JSON.stringify(value));
            logger.info("**********mappedKey = " + mappedKey);
            if (value != null && typeof value === 'object')
            {
                this.traverseAndUpdateDcpuChildConfig(mappedKey, value, mappings, deviceConfig);
            }
            else
            {
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, deviceConfig);
            }

        }
        return obj;
    }
    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, deviceConfigData) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = "";
        if (mappedKey.startsWith("policy.static-policer.") || mappedKey.startsWith("policy.local-monitoring-policer.") || mappedKey.startsWith("policy.protocol."))
        {
            deviceValue = deviceConfigData[nfmpKey];
            if (deviceConfigData["rateType"] === "packets")
            {
                if (mappedKey.endsWith("rate.kbps.limit") ||
                    mappedKey.endsWith("rate.kbps.mbs"))
                {
                    deviceValue = undefined;
                }
            }
            if (deviceConfigData["rateType"] === "kbps")
            {
                if (mappedKey.endsWith("rate.packets.limit") ||
                    mappedKey.endsWith("rate.packets.within") ||
                    mappedKey.endsWith("rate.packets.initial-delay"))
                {
                    deviceValue = undefined;
                }
            }
            if (mappedKey.startsWith("policy.protocol.enforcement."))
            {
                if (deviceConfigData["enforceType"] === "static")
                {
                    if (mappedKey.endsWith("dynamic.mon-policer-name") ||
                        mappedKey.endsWith("dynamic-local-mon-bypass") ||
                        mappedKey.endsWith("shared.shared-policer-name"))
                    {
                        deviceValue = undefined;
                    }
                }
                if (deviceConfigData["enforceType"] === "dynamic")
                {
                    if (deviceConfigData["enforcementPolicerName"] === "local-mon-bypass")
                    {
                    if (mappedKey.endsWith("static.policer-name") ||
                            mappedKey.endsWith("dynamic.mon-policer-name") ||
                            mappedKey.endsWith("shared.shared-policer-name"))
                        {
                            deviceValue = undefined;
                        }
                    }
                    else if (mappedKey.endsWith("static.policer-name") ||
                        mappedKey.endsWith("dynamic-local-mon-bypass") ||
                        mappedKey.endsWith("shared.shared-policer-name"))
                    {
                        deviceValue = undefined;
                    }
                }
                if (deviceConfigData["enforceType"] === "shared")
                {
                    if (mappedKey.endsWith("dynamic.mon-policer-name") ||
                        mappedKey.endsWith("dynamic-local-mon-bypass") ||
                        mappedKey.endsWith("static.policer-name"))
                    {
                        deviceValue = undefined;
                    }
                }
            }
        }
        else
        {
            deviceValue = deviceConfigData.dCpuPolicyConfig[nfmpKey];
        }
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);
    }
    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue !== null)
        {
            switch (mappedKey)
            {
                case "policy.type":
                    deviceValue = util.convertPolicyTypeBrownField(deviceValue);
                    break;
                case "policy.static-policer.log-events":
                case "policy.local-monitoring-policer.log-events":
                case "policy.protocol.dynamic-parameters.log-events":
                    deviceValue = util.convertLogEventsTypeBrownField(deviceValue);
                    break;
                case "policy.static-policer.exceed-action.action":
                case "policy.local-monitoring-policer.exceed-action":
                case "policy.protocol.dynamic-parameters.exceed-action.action":
                    deviceValue = util.convertExceedActionBrownField(deviceValue);
                    break;
                case "policy.static-policer.exceed-action.hold-down":
                case "policy.protocol.dynamic-parameters.exceed-action.hold-down":
                    deviceValue = util.convertHoldDownDurationBrownField(deviceValue);
                    break;
                case "policy.static-policer.rate.kbps.limit":
                case "policy.static-policer.rate.packets.limit":
                case "policy.local-monitoring-policer.rate.kbps.limit":
                case "policy.local-monitoring-policer.rate.packets.limit":
                case "policy.protocol.dynamic-parameters.rate.kbps.limit":
                case "policy.protocol.dynamic-parameters.rate.packets.limit":
                    deviceValue = util.convertRateBrownField(deviceValue);
                    break;
                case "policy.protocol.protocol-name":
                    deviceValue = util.convertProtocolTypeBrownField(deviceValue);
                    break;
                case "policy.protocol.enforcement.dynamic-local-mon-bypass":
                    if (deviceValue)
                    {
                        deviceValue = [null];
                    }
                    break;
                case "policy.static-policer.rate.type":
                case "policy.local-monitoring-policer.rate.type":
                case "policy.protocol.dynamic-parameters.rate.type":
                case "policy.protocol.enforcement.type":
                    deviceValue = undefined;
                    break;
            }
            return deviceValue;
        }
    }
    this.clearEmpties = function (o) {
        for (let k in o)
        {
            if (!o[k] || typeof o[k] !== "object")
            {
                continue
            }

            this.clearEmpties(o[k]);
            if (Object.keys(o[k]).length === 0)
            {
                delete o[k];
            }
        }
    }
}
