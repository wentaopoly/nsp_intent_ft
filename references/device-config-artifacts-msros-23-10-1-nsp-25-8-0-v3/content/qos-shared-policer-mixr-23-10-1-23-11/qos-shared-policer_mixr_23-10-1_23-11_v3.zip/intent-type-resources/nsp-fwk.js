function nspFwk() {
  NSP_MED_HOST = "nsp-mdt-nsp-mediator-svc";
  NSP_MED_PORT = "80";

  this.configRestClient = function (url, method) {
    logger.info(
      "[nspFwk][" +
        method +
        "]: Calling NSP Mediator " +
        NSP_MED_HOST +
        ":" +
        NSP_MED_PORT +
        " with URL: " +
        url
    );
    restClient.setIp(NSP_MED_HOST);
    restClient.setPort(NSP_MED_PORT);
    restClient.setProtocol("http");
  };

  this.send = function (url, method, body, contentType, acceptType) {
    this.configRestClient(url, method);
    var result = {};
    var contentTypeHeader = "application/json";
    var acceptTypeHeader = "application/json";
    var bodyPayload = {};
    var PATCH_PREFIX = "patch/";

    if (contentType) {
      contentTypeHeader = contentType;
    }

    if (acceptType) {
      acceptTypeHeader = acceptType;
    }

    if (body === null || body === "") {
      bodyPayload = null;
    } else {
      bodyPayload = body;
    }

    if (method === "POST") {
      restClient.post(
        url,
        contentTypeHeader,
        JSON.stringify(bodyPayload),
        acceptTypeHeader,
        function (exception, httpStatus, response) {
          logger.info("[nspFwk][POST] url: " + url);
          logger.info(
            "[nspFwk][POST] bodyPayload: " + JSON.stringify(bodyPayload)
          );
          logger.info("[nspFwk][POST] status: " + httpStatus);
          logger.info("[nspFwk][POST] response: " + response);
          if (exception) {
            logger.info("[nspFwk][POST] Call had an exception: " + exception);
          }
          result = {
            status: httpStatus,
            response: response,
          };
        }
      );
    } else if (method === "PATCH") {
      logger.info("patchUrl: " + url);

      restClient.post(
        PATCH_PREFIX + url,
        contentTypeHeader,
        JSON.stringify(bodyPayload),
        acceptTypeHeader,
        function (exception, httpStatus, response) {
          logger.info("[nspFwk][PATCH] url: " + url);
          logger.info(
            "[nspFwk][PATCH] bodyPayload: " + JSON.stringify(bodyPayload)
          );
          logger.info("[nspFwk][PATCH] status: " + httpStatus);
          logger.info("[nspFwk][PATCH] response: " + response);
          if (exception) {
            logger.info("[nspFwk][PATCH] Call had an exception: " + exception);
          }
          result = {
            status: httpStatus,
            response: response,
          };
        }
      );
    } else if (method === "DELETE") {
      restClient.delete(
        url,
        contentTypeHeader,
        function (exception, httpStatus, response) {
          logger.info("[nspFwk][DELETE] status: " + httpStatus);
          logger.info("[nspFwk][DELETE] response: " + response);
          if (exception) {
            logger.info("[nspFwk][DELETE] Call had an exception: " + exception);
          }
          result = {
            status: httpStatus,
            response: response,
          };
        }
      );
    } else if (method === "PUT") {
      restClient.put(
        url,
        contentTypeHeader,
        JSON.stringify(bodyPayload),
        acceptTypeHeader,
        function (exception, httpStatus, response) {
          logger.info("[nspFwk][PUT] url: " + url);
          logger.info(
            "[nspFwk][PUT] bodyPayload: " + JSON.stringify(bodyPayload)
          );
          logger.info("[nspFwk][PUT] status: " + httpStatus);
          logger.info("[nspFwk][PUT] response: " + response);
          if (exception) {
            logger.info("[nspFwk][PUT] Call had an exception: " + exception);
          }
          result = {
            status: httpStatus,
            response: response,
          };
        }
      );
    } else {
      //Default to GET
      restClient.get(
        url,
        contentTypeHeader,
        function (exception, httpStatus, response) {
          logger.info("[nspFwk][GET] status: " + httpStatus);
          logger.info("[nspFwk][GET] response: " + response);
          if (exception) {
            logger.info("[nspFwk][GET] Call had an exception: " + exception);
          }
          result = {
            status: httpStatus,
            response: JSON.parse(response),
          };
        }
      );
    }
    return result;
  };
}
