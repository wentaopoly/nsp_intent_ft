var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk'});
load({script: resourceProvider.getResource('traverse-fwk.js'), name: 'TraverseFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
load({script: resourceProvider.getResource('intentConfigValueReplacer.js'), name: 'IntentConfigValueReplacer'});

function MdcIntentFwk() {

    var intentDeviationObj = new IntentDeviceDeviation();
    var intentConfigValueReplacerObj = new IntentConfigValueReplacer();

    this.restResponseHandler = function (exception, httpStatus, response) {
        logger.info("[IntentMgr] REST response : " + response);
        logger.info("[IntentMgr] REST httpStatus : " + httpStatus);
        if (exception) {
            throw new RuntimeException("Couldn't connect to device proxy for ; Response: " + response);
        }

        if (httpStatus !== 200 && httpStatus !== 201) {
            throw new RuntimeException("Failed to access device  using MDC; Response: " + response);
        }

        restResponse = JSON.parse(response);
    };

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {

        var traverseFwk = new TraverseFwk();
        var parseTarget = new ParseTarget();
        var target = parseTarget.getNeIdFromTarget(input.getTarget());

        var neFamily = intentDeviationObj.getNeFamilyRelease(target);
        var neVersion = intentDeviationObj.getNeVersion(neFamily);

        // saved topology
        var savedTopology = input.getCurrentTopology();

        if (savedTopology == null) {
            savedTopology = topologyFactory.createServiceTopology();
        }

        if (input.getNetworkState().name() == "delete") {
            logger.info(JSON.stringify(savedTopology));
            traverseFwk.resetTheVariables();
            var requests = [];
            var deleteObj = {};
            deleteObj["operation"] = "delete";
            deleteObj["edit-id"] = "edit-" + new Date().getTime();
            deleteObj["target"] = "nokia-conf:/configure/service/system/bgp/evpn/ethernet-segment=" + parseTarget.getUniqueIdentifier(input.getTarget());
            requests.push(deleteObj)
            result = traverseFwk.syncRequest(target, requests, result, savedTopology);
            result.setTopology(null);
            return result;
        }

        if (target !== "0.0.0.0") {
            var intentConfig;
            intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
            if(!intentConfig)
            {
                intentConfig = Object.create({});
            }
            intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());

            if (neVersion.compareTo("21.") < 0) {
                if(intentConfig['association'] && intentConfig['association']['lag'] && intentConfig['association']['lag']['lag-name']) {
                    var destination = {};
                    destination['lag-id'] = intentConfig['association']['lag']['lag-name'];
                    intentConfig['association']['lag']['lag-id'] = destination['lag-id'];
                    delete intentConfig['association']['lag']['lag-name'];
                }
            }
            //Removing deviations info
            intentConfig = intentDeviationObj.removeIntentConfig(intentConfig, target);
            //Replace Values
            intentConfig = intentConfigValueReplacerObj.replaceConfigValue(intentConfig);
            if (intentConfig) {
                savedTopology = traverseFwk.traverse(target, intentConfig, savedTopology, null, parentXpath, initialPropertyName);

                //sorting delete array
                var deleteRequests = traverseFwk.getDeleteRequests();
                deleteRequests.sort(function (a, b) {
                    return b["target"].length - a["target"].length;
                });

                // concating createrequests and deleterequests
                var createRequests = traverseFwk.getCreateRequests();
                var requests;
                if (deleteRequests && createRequests) {
                    requests = deleteRequests.concat(createRequests);
                }
                if (requests) {
                    result = traverseFwk.syncRequest(target, requests, result, savedTopology);
                }

            } else {

                result = traverseFwk.deleteAllFromTopology(savedTopology, target, result);
            }

        }
        traverseFwk.resetTheVariables();
        return result;
    }

    this.audit = function (target, config, svcTopo, adminState, report, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        var currentConfig;
        var traverseFwk = new TraverseFwk();
        var parseTarget = new ParseTarget();
        currentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        if(!currentConfig )
        {
            currentConfig  = Object.create({});
        }
        currentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        var targetNeId = parseTarget.getNeIdFromTarget(target);

        var neFamily = intentDeviationObj.getNeFamilyRelease(targetNeId);
        var neVersion = intentDeviationObj.getNeVersion(neFamily);

        if (neVersion.compareTo("21.") < 0) {
            if(currentConfig['association'] && currentConfig['association']['lag'] && currentConfig['association']['lag']['lag-name']) {
                var destination = {};
                destination['lag-id'] = currentConfig['association']['lag']['lag-name'];
                currentConfig['association']['lag'] = destination;
                delete currentConfig['association']['lag']['lag-name'];
            }
        }
        var targetNeId = parseTarget.getNeIdFromTarget(target);
        //Ignoring deviations compare
        currentConfig = intentDeviationObj.removeIntentConfig(currentConfig, targetNeId);
        //Replace Values
        currentConfig = intentConfigValueReplacerObj.replaceConfigValue(currentConfig);

        if (currentConfig['esi']) {

            if (currentConfig['esi'].indexOf(":") !== -1) {
                currentConfig['esi'] = '0x' + currentConfig['esi'].replaceAll(':', '').toLowerCase();
            }

            if (currentConfig['esi'].indexOf("-") !== -1) {
                currentConfig['esi'] = '0x' + currentConfig['esi'].replaceAll('-', '').toLowerCase();
            }

        }

        if (targetNeId !== "0.0.0.0") {

            svcTopo = traverseFwk.traverse(targetNeId, currentConfig, svcTopo, report, parentXpath, initialPropertyName);
            // reseting the variables
            traverseFwk.resetTheVariables();
        }

        return report;

    }

    this.getNodes = function (context) {
        var returnVal = []
        var url = "/restconf/meta/api/v1/nes"
        try {
            var managerList = []
            var managers = mds.getAllManagersOfType("REST");
            managers.forEach(function (manager) {
                if (mds.getManagerByName(manager).getConnectivityState().toString() === 'CONNECTED') {
                    managerList.push(manager)
                }
            })

            var devices = mds.getAllManagedDevicesFrom(managerList);

            devices.forEach(function (device) {
                returnVal.push(device.getName());
            });

            return returnVal;
        } catch (e) {
            logger.info("Exception *******************  : " + e);
            return {
                "Device Not Found": "Device Not Found"
            }
        }
    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }
}
