function MdSuggest() {
    this.suggestFwdPathExtFpeId = function (neId) {
       const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/fwd-path-ext/fpe?fields=fpe-id`;
       return this.getSuggestData(neId, url, "nokia-conf:fpe", "fpe-id");
    }

    this.suggestMplsLabelsReservedLabelBlockLabelBlockName = function (neId) {
       const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/mpls-labels/reserved-label-block?fields=label-block-name`;
       return this.getSuggestData(neId, url, "nokia-conf:reserved-label-block", "label-block-name");
    }

    this.suggestMicroSegmentBlockName = function (neId) {
       const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/segment-routing/segment-routing-v6/micro-segment/block?fields=block-name`;
       return this.getSuggestData(neId, url, "nokia-conf:block", "block-name");
    }

    this.suggestSegmentRoutingV6LocatorName = function (neId) {
       const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/segment-routing/segment-routing-v6/locator?fields=locator-name`;
       return this.getSuggestData(neId, url, "nokia-conf:locator", "locator-name");
    }

    this.suggestRouterInterfaceName = function (neId) {
       const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/interface?fields=interface-name`;
       return this.getSuggestData(neId, url, "nokia-conf:interface", "interface-name");
    }

    this.suggestSegmentRoutingV6MicroSegmentLocatorName = function (neId) {
       const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/segment-routing/segment-routing-v6/micro-segment-locator?fields=locator-name`;
       return this.getSuggestData(neId, url, "nokia-conf:micro-segment-locator", "locator-name");
    }

   this.getSuggestData = function(neId, url, initialProperty, propertyName) {
      const mdcFwk = new MdcFwk();
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg[initialProperty];
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data[propertyName]).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }
}
