var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpSystemSecurityCpm() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    let nfmpFwk = new NfmpFwk();
    var parseTarget =  new ParseTarget();
    var savedObjects;
    var currentObjects;
    var isAudit = false;

    this.synchronize = function(input, result,intentTypeName,initialPropertyName,uniqueIdentifier)
    {
        var target = parseTarget.getNeIdFromTarget(input.getTarget());

        var searchResponse = nfmpFwk.find(target);
        logger.info(JSON.stringify(searchResponse));
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                throw new RuntimeException("Failed to get cpm filter info from nfm-p for Ne " + target);
            if(JSON.parse(searchResponse["response"]).length === 0)
                throw new RuntimeException("There is no CPM filter discovered on NFMP for NE:" + target );
        }
        var finalResponse = JSON.parse(searchResponse['response']);
        var objectFullName = finalResponse[0]['properties']['objectFullName'];
        if (target && String(target).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
        }
        // code to handle delete
        if (input.getNetworkState().name() == "delete")
        {
            return this.syncDelete(target, objectFullName, result)
        }

        var savedTopology = input.getCurrentTopology();
        logger.info(savedTopology);
        savedObjects = {};
        currentObjects = {};
        isAudit = false;
        //loading the saved objects from topology
        this.loadSavedObjectsFromTopology(savedTopology);

        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName];
        //intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        if(!intentConfig)
        {
            intentConfig = Object.create({});
        }
        logger.info("Configuration to be pushed = "+JSON.stringify(intentConfig));
        logger.info("Target device = " + target);

        this.createOrModify(target,intentConfig, objectFullName);

        var currentTopo = this.loadCurrentObjectsToTopology(target);

        result = util.setSuccessResult(result,currentTopo);
        return result;
    }

    this.createOrModify= function(target,intentConfig, objectFullName)
    {
        var result;
        var cpmFilterPayload = this.createCpmFilterPayLoad(target, intentConfig, objectFullName);
        //MDT sends parent config first and then child configs. So, for the default action to be drop, ip filter admin status as enable,
        //one IP filter entry should be existing.
        //SO, send the default action as forward (intent model value is accept) and ip-filter admin status as disable and then update their values to actuals in another request
        if(intentConfig["cpm-filter"] && (intentConfig["cpm-filter"]["default-action"] === "drop"))
        {
            cpmFilterPayload["configInfo"]["containedClassProperties"]["defaultAction"] = "forward";
            cpmFilterPayload["configInfo"]["containedClassProperties"]["adminstrativeStatus"] = "tmnxOutOfService";
        }
        result = this.modifyRequest(target, cpmFilterPayload);

        //again deploy the actual default-action and ip-filter administrative status
        if(intentConfig["cpm-filter"] && (intentConfig["cpm-filter"]["default-action"] === "drop"))
        {
            cpmFilterPayload["configInfo"]["containedClassProperties"]["defaultAction"] = "drop";
            cpmFilterPayload["configInfo"]["containedClassProperties"]["adminstrativeStatus"] = "tmnxInService";
        }
        result = this.modifyRequest(target, cpmFilterPayload);
        return result;
    }

    this.modifyRequest = function(target,payload){

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;

    }

    this.syncDelete = function (target, objectFullName,  result)
    {
        /*
         * NFMP doesn't provide delete functionality for cpm-filter. we have to create empty global policy and distribute that
         * to the node to clear the config. and that empty global policy can be updated at anytime.
         * So, we are not sure, which global policy is empty, otherwise we end up creating empty global policy again and again.
         * solution could be deleting the filters and queues individually. and this too will have to trigger many delete requests if there are many filters/queues.
         * Below is the simplified solution which would make less calls to MDT.
         * updating the cpm-filter policy with default config and one dummy child of each children type
         * then delete the dummy children we have created as we know the full name. this way it would clear the entire cpm-filter config
         */
        if (target && String(target).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
        }
        logger.info("Deleting " + objectFullName);
        var deletePayload = JSON.parse("{\"distinguishedName\":\"CPM IP Filter\",\"objectFullName\":\""+objectFullName+"\",\"configInfo\":{\"containedClassProperties\":{\"defaultAction\":\"forward\",\"adminstrativeStatus\":\"tmnxOutOfService\",\"ipv6AdminstrativeStatus\":\"tmnxOutOfService\"},\"containmentInfo\":[{\"objectClassName\":\"sitesec.CpmFilterQueue\",\"containedClassProperties\":{\"id\":33}},{\"objectClassName\":\"sitesec.CpmIpFilterEntry\",\"containedClassProperties\":{\"id\":1}},{\"objectClassName\":\"sitesec.CpmIPv6FilterEntry\",\"containedClassProperties\":{\"id\":2}}],\"objectClassName\":\"sitesec.CpmIpFilter\"}}");

        this.modifyRequest(target, deletePayload);

        var deleteResult = nfmpFwk.deployDelete(objectFullName+":cpm-ipf-1", "application/json");

        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }

        deleteResult = nfmpFwk.deployDelete(objectFullName+":cpm-ipv6f-2", "application/json");

        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }

        deleteResult = nfmpFwk.deployDelete(objectFullName+":cpmf-queue-33", "application/json");

        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }

    this.createCpmFilterPayLoad = function (target, intentConfig, objectFullName)
    {
        var fullClassName = "sitesec.CpmIpFilter";
        var policyFdn = "CPM IP Filter";

        var properties = {};
        var childProperties = [];

        if(intentConfig["cpm-queue"])
        {
            var queuesConfig = intentConfig["cpm-queue"];
            if (queuesConfig["queue"])
            {
                if(!Array.isArray(queuesConfig["queue"]))
                {
                    queuesConfig["queue"] = [queuesConfig["queue"]];
                }
            }
            for(var index in queuesConfig["queue"])
            {
                var intentQueueConfig = queuesConfig["queue"][index];
                var queuePayload = this.createQueuePayLoad(target,intentQueueConfig);
                childProperties.push(queuePayload);
            }
        }

        if(intentConfig["cpm-filter"])
        {
            var filterConfig = intentConfig["cpm-filter"];
            if(filterConfig['default-action'] === "drop")
            {
                if(((filterConfig["ip-filter"] === undefined) || (filterConfig["ip-filter"]["admin-state"] !== "enable")))
                {
                    throw new RuntimeException("Default Action and IP Filter Administrative status cannot be set to drop and down respectively ");
                }
                if(filterConfig["ip-filter"]["entry"] === undefined)
                {
                    throw new RuntimeException("One or more CPM IP Filter IPv4 Entries must exist, in order to have Default Action set to drop and IPv4 Administrative status set to Up");
                }
            }

            if(filterConfig["default-action"])
            {
                if(filterConfig["default-action"] == "accept")
                {
                    properties["defaultAction"] = "forward";
                }
                else
                {
                    properties["defaultAction"] = filterConfig["default-action"];
                }
            }
            else
            {
                properties["defaultAction"] = "forward";
            }
            if (filterConfig["ip-filter"])
            {
                if(filterConfig["ip-filter"]["admin-state"] == "enable")
                {
                    properties["adminstrativeStatus"] = "tmnxInService";
                }
                else
                {
                    properties["adminstrativeStatus"] = "tmnxOutOfService";
                }
                if(!Array.isArray(filterConfig["ip-filter"]["entry"]))
                {
                    filterConfig["ip-filter"]["entry"] = [filterConfig["ip-filter"]["entry"]];
                }
                for(var index in filterConfig["ip-filter"]["entry"])
                {
                    var intentIPFilterEntryConfig = filterConfig["ip-filter"]["entry"][index];
                    if(intentIPFilterEntryConfig)
                    {
                        var IPFilterEntryPayload = this.createIpFilterEntryPayLoad(target,intentIPFilterEntryConfig);
                        childProperties.push(IPFilterEntryPayload);
                    }
                }
            }
            if (filterConfig["ipv6-filter"])
            {
                if(filterConfig["ipv6-filter"]["admin-state"] == "enable")
                {
                    properties["ipv6AdminstrativeStatus"] = "tmnxInService";
                }
                else
                {
                    properties["ipv6AdminstrativeStatus"] = "tmnxOutOfService";
                }
                if(!Array.isArray(filterConfig["ipv6-filter"]["entry"]))
                {
                    filterConfig["ipv6-filter"]["entry"] = [filterConfig["ipv6-filter"]["entry"]];
                }
                for(var index in filterConfig["ipv6-filter"]["entry"])
                {
                    var intentIPv6FilterEntryConfig = filterConfig["ipv6-filter"]["entry"][index];
                    if(intentIPv6FilterEntryConfig)
                    {
                        var IPv6FilterEntryPayload = this.createIpv6FilterEntryPayLoad(target,intentIPv6FilterEntryConfig);
                        childProperties.push(IPv6FilterEntryPayload);
                    }
                }
            }
        }

        var cpmFilterPayload = util.editPayload(policyFdn,properties,childProperties,fullClassName,objectFullName);
        return cpmFilterPayload;
    }

    this.createIpFilterEntryPayLoad = function(target,intentIPFilterEntryConfig)
    {

        var fullClassName = "sitesec.CpmIpFilterEntry";
        var properties = {};

        if(isAudit != true)
        {
            properties["ipOptionValue"] = 0;
        }
        properties["ipOptionMask"] = 0;
        properties["id"] = intentIPFilterEntryConfig["entry-id"];
        properties["description"] = intentIPFilterEntryConfig['description'];

        if(intentIPFilterEntryConfig["action"])
        {
            if(intentIPFilterEntryConfig["action"]["accept"] != undefined)
            {
                properties["action"] = "forward";
            }
            else if(intentIPFilterEntryConfig["action"]["default"] != undefined)
            {
                properties["action"] = "default";
            }
            else if(intentIPFilterEntryConfig["action"]["queue"] != undefined)
            {
                properties["action"] = "queue";
                properties["queueId"] = intentIPFilterEntryConfig["action"]["queue"];
            }
            else
            {
                properties["action"] = "drop";
            }
        }

        if(intentIPFilterEntryConfig["match"])
        {
            if(intentIPFilterEntryConfig["match"]["ip-option"])
            {
                if(isAudit != true)
                {
                    properties["ipOptionValue"] = intentIPFilterEntryConfig["match"]["ip-option"]['type'];
                }
                properties["ipOptionMask"] = intentIPFilterEntryConfig["match"]["ip-option"]['mask'];
            }
            if(intentIPFilterEntryConfig['match']['protocol'])
            {
                properties["protocol"] = this.transformProtocol(intentIPFilterEntryConfig['match']['protocol']);
            }
            if(intentIPFilterEntryConfig['match']['fragment'] != undefined)
            {
                properties["fragment"] = intentIPFilterEntryConfig["match"]["fragment"].toString()
            }
            else
            {
                properties["fragment"] = "off";
            }

            if(intentIPFilterEntryConfig["match"]["icmp"])
            {
                properties["icmpCode"] = intentIPFilterEntryConfig["match"]["icmp"]["code"];
                properties["icmpType"] = intentIPFilterEntryConfig["match"]["icmp"]["type"];
            }
            else
            {
                properties["icmpCode"] = -1;
                properties["icmpType"] = -1;
            }

            if(intentIPFilterEntryConfig["match"]["src-ip"])
            {
                if(intentIPFilterEntryConfig["match"]["src-ip"]["address"])
                {
                    properties["sourceIpAddress"] = intentIPFilterEntryConfig["match"]["src-ip"]["address"].split("/")[0];
                    properties["sourceIpAddressMask"] = 'ipAddrMask' + intentIPFilterEntryConfig["match"]["src-ip"]["address"].split("/")[1];
                    properties["srcIpPrefixListPointer"] = "";
                }
                if(intentIPFilterEntryConfig["match"]["src-ip"]["ip-prefix-list"])
                {
                    properties["sourceIpAddress"] = "0.0.0.0";
                    properties["sourceIpAddressMask"] = 'ipAddrMask0';
                    properties["srcIpPrefixListPointer"] = 'filterPrefixList:' + intentIPFilterEntryConfig["match"]["src-ip"]["ip-prefix-list"];
                }
            }

            if(intentIPFilterEntryConfig["match"]["dst-ip"])
            {
                if(intentIPFilterEntryConfig["match"]["dst-ip"]["address"])
                {
                    properties["destinationIpAddress"] = intentIPFilterEntryConfig["match"]["dst-ip"]["address"].split("/")[0];
                    properties["destinationIpAddressMask"] = 'ipAddrMask' + intentIPFilterEntryConfig["match"]["dst-ip"]["address"].split("/")[1];
                    properties["dstIpPrefixListPointer"] = "";
                }
                if(intentIPFilterEntryConfig["match"]["dst-ip"]["ip-prefix-list"])
                {
                    properties["destinationIpAddress"] = "0.0.0.0";
                    properties["destinationIpAddressMask"] = 'ipAddrMask0';
                    properties["dstIpPrefixListPointer"] = 'filterPrefixList:' + intentIPFilterEntryConfig["match"]["dst-ip"]["ip-prefix-list"];
                }
            }

            if(intentIPFilterEntryConfig["match"]["port"])
            {
                properties["portSelector"] = "OR_PORT";
                if(intentIPFilterEntryConfig["match"]["port"]["port"])
                {
                    if(intentIPFilterEntryConfig["match"]["port"]["port"] == "eq")
                    {
                        properties["portOperator"] = "mask";
                        properties["port"] =  intentIPFilterEntryConfig["match"]["port"]["eq"];
                        properties["portMask"] =  intentIPFilterEntryConfig["match"]["port"]["mask"];
                    }
                    else if(intentIPFilterEntryConfig["match"]["port"]["port"] == "range")
                    {
                        properties["portOperator"] = "range";
                        if(isAudit === false)
                        {
                            properties["sourcePortOperator"] = "range";
                            properties["destinationPortOperator"] = "range";
                        }
                        if(intentIPFilterEntryConfig["match"]["port"]["range"])
                        {
                            properties["port"] =  intentIPFilterEntryConfig["match"]["port"]["range"]["start"];
                            properties["portHigh"] =  intentIPFilterEntryConfig["match"]["port"]["range"]["end"];
                            if(isAudit === false)
                            {
                                properties["sourcePort"] =  intentIPFilterEntryConfig["match"]["port"]["range"]["start"];
                                properties["sourcePortHigh"] =  intentIPFilterEntryConfig["match"]["port"]["range"]["end"];
                                properties["destinationPort"] =  intentIPFilterEntryConfig["match"]["port"]["range"]["start"];
                                properties["destinationPortHigh"] =  intentIPFilterEntryConfig["match"]["port"]["range"]["end"];
                            }
                        }
                    }
                    else if(intentIPFilterEntryConfig["match"]["port"]["port"] == "port-list")
                    {
                        properties["portListPointer"] = 'filterPortList:' + intentIPFilterEntryConfig["match"]["port"]["port-list"];
                    }
                }
            }
            if(intentIPFilterEntryConfig["match"]["src-port"])
            {
                properties["portSelector"] = "AND_PORT";
                if(intentIPFilterEntryConfig["match"]["src-port"]["port"])
                {
                    if(intentIPFilterEntryConfig["match"]["src-port"]["port"] == "eq")
                    {
                        properties["sourcePortOperator"] = "mask";
                        properties["sourcePort"] =  intentIPFilterEntryConfig["match"]["src-port"]["eq"];
                        properties["sourcePortMask"] =  intentIPFilterEntryConfig["match"]["src-port"]["mask"];
                    }
                    else if(intentIPFilterEntryConfig["match"]["src-port"]["port"] == "range")
                    {
                        properties["sourcePortOperator"] = "range";
                        if(intentIPFilterEntryConfig["match"]["src-port"]["range"])
                        {
                            properties["sourcePort"] =  intentIPFilterEntryConfig["match"]["src-port"]["range"]["start"];
                            properties["sourcePortHigh"] =  intentIPFilterEntryConfig["match"]["src-port"]["range"]["end"];
                        }
                    }
                    else if(intentIPFilterEntryConfig["match"]["src-port"]["port"] == "port-list")
                    {
                        properties["sourcePortListPointer"] = 'filterPortList:' + intentIPFilterEntryConfig["match"]["src-port"]["port-list"];
                    }
                }
            }
            if(intentIPFilterEntryConfig["match"]["dst-port"])
            {
                properties["portSelector"] = "AND_PORT";
                if(intentIPFilterEntryConfig["match"]["dst-port"]["port"])
                {
                    if(intentIPFilterEntryConfig["match"]["dst-port"]["port"] == "eq")
                    {
                        properties["destinationPortOperator"] = "mask";
                        properties["destinationPort"] =  intentIPFilterEntryConfig["match"]["dst-port"]["eq"];
                        properties["destinationPortMask"] =  intentIPFilterEntryConfig["match"]["dst-port"]["mask"];
                    }
                    else if(intentIPFilterEntryConfig["match"]["dst-port"]["port"] == "range")
                    {
                        properties["destinationPortOperator"] = "range";
                        if(intentIPFilterEntryConfig["match"]["dst-port"]["range"])
                        {
                            properties["destinationPort"] =  intentIPFilterEntryConfig["match"]["dst-port"]["range"]["start"];
                            properties["destinationPortHigh"] =  intentIPFilterEntryConfig["match"]["dst-port"]["range"]["end"];
                        }
                    }
                    else if(intentIPFilterEntryConfig["match"]["dst-port"]["port"] == "port-list")
                    {
                        properties["destinationPortListPointer"] = 'filterPortList:' + intentIPFilterEntryConfig["match"]["dst-port"]["port-list"];
                    }
                }
            }
        }
        return this.createChildObjectPayload(fullClassName,properties);
    }

    this.createIpv6FilterEntryPayLoad = function(target,intentIPv6FilterEntryConfig)
    {

        var fullClassName = "sitesec.CpmIPv6FilterEntry";
        var properties = {};

        properties["id"] = intentIPv6FilterEntryConfig["entry-id"];
        properties["description"] = intentIPv6FilterEntryConfig['description'];
        if(intentIPv6FilterEntryConfig["action"])
        {
            if(intentIPv6FilterEntryConfig["action"]["accept"] != undefined)
            {
                properties["action"] = "forward";
            }
            else if(intentIPv6FilterEntryConfig["action"]["default"] != undefined)
            {
                properties["action"] = "default";
            }
            else if(intentIPv6FilterEntryConfig["action"]["queue"] != undefined)
            {
                properties["action"] = "queue";
                properties["queueId"] = intentIPv6FilterEntryConfig["action"]["queue"];
            }
            else
            {
                properties["action"] = "drop";
            }
        }
        if(intentIPv6FilterEntryConfig['match'])
        {
            if(intentIPv6FilterEntryConfig['match']['next-header'])
            {
                properties["protocol"] = this.transformProtocol(intentIPv6FilterEntryConfig['match']['next-header']);
            }
            if(intentIPv6FilterEntryConfig['match']['fragment'] != undefined)
            {
                properties["fragment"] = intentIPv6FilterEntryConfig['match']['fragment'].toString();
            }
            else
            {
                properties["fragment"] = "off";
            }

            if(intentIPv6FilterEntryConfig["match"]["icmp"])
            {
                properties["icmpCode"] = intentIPv6FilterEntryConfig["match"]["icmp"]["code"];
                properties["icmpType"] = intentIPv6FilterEntryConfig["match"]["icmp"]["type"];
            }
            else
            {
                properties["icmpCode"] = -1;
                properties["icmpType"] = -1;
            }
            if(intentIPv6FilterEntryConfig["match"]["src-ip"])
            {
                if(intentIPv6FilterEntryConfig["match"]["src-ip"]["address"])
                {
                    properties["sourceIpAddress"] = util.expandIPv6Address(intentIPv6FilterEntryConfig["match"]["src-ip"]["address"].split("/")[0]);
                    properties["sourceIpAddressMask"] = intentIPv6FilterEntryConfig["match"]["src-ip"]["address"].split("/")[1];
                    properties["srcIpPrefixListPointer"] = "";
                }
                if(intentIPv6FilterEntryConfig["match"]["src-ip"]["ipv6-prefix-list"])
                {
                    properties["sourceIpAddress"] = "0:0:0:0:0:0:0:0";
                    properties["sourceIpAddressMask"] = "0";
                    properties["srcIpPrefixListPointer"] = 'filterPrefixList:' + intentIPv6FilterEntryConfig["match"]["src-ip"]["ipv6-prefix-list"]+'#type-IPv6';
                }
            }

            if(intentIPv6FilterEntryConfig["match"]["dst-ip"])
            {
                if(intentIPv6FilterEntryConfig["match"]["dst-ip"]["address"])
                {
                    properties["destinationIpAddress"] = util.expandIPv6Address(intentIPv6FilterEntryConfig["match"]["dst-ip"]["address"].split("/")[0]);
                    properties["destinationIpAddressMask"] = intentIPv6FilterEntryConfig["match"]["dst-ip"]["address"].split("/")[1];
                    properties["dstIpPrefixListPointer"] = "";
                }
                if(intentIPv6FilterEntryConfig["match"]["dst-ip"]["ipv6-prefix-list"])
                {
                    properties["destinationIpAddress"] = "0:0:0:0:0:0:0:0";
                    properties["destinationIpAddressMask"] = "0";
                    properties["dstIpPrefixListPointer"] = 'filterPrefixList:' + intentIPv6FilterEntryConfig["match"]["dst-ip"]["ipv6-prefix-list"]+"#type-IPv6";
                }
            }

            if(intentIPv6FilterEntryConfig["match"]["port"])
            {
                properties["portSelector"] = "OR_PORT";
                if(intentIPv6FilterEntryConfig["match"]["port"]["port"])
                {
                    if(intentIPv6FilterEntryConfig["match"]["port"]["port"] == "eq")
                    {
                        properties["portOperator"] = "mask";
                        properties["port"] =  intentIPv6FilterEntryConfig["match"]["port"]["eq"];
                        properties["portMask"] =  intentIPv6FilterEntryConfig["match"]["port"]["mask"];
                    }
                    else if(intentIPv6FilterEntryConfig["match"]["port"]["port"] == "range")
                    {
                        properties["portOperator"] = "range";
                        if(isAudit === false)
                        {
                            properties["sourcePortOperator"] = "range";
                            properties["destinationPortOperator"] = "range";
                        }
                        if(intentIPv6FilterEntryConfig["match"]["port"]["range"])
                        {
                            properties["port"] =  intentIPv6FilterEntryConfig["match"]["port"]["range"]["start"];
                            properties["portHigh"] =  intentIPv6FilterEntryConfig["match"]["port"]["range"]["end"];
                            if(isAudit === false)
                            {
                                properties["sourcePort"] =  intentIPv6FilterEntryConfig["match"]["port"]["range"]["start"];
                                properties["sourcePortHigh"] =  intentIPv6FilterEntryConfig["match"]["port"]["range"]["end"];
                                properties["destinationPort"] =  intentIPv6FilterEntryConfig["match"]["port"]["range"]["start"];
                                properties["destinationPortHigh"] =  intentIPv6FilterEntryConfig["match"]["port"]["range"]["end"];
                            }
                        }
                    }
                    else if(intentIPv6FilterEntryConfig["match"]["port"]["port"] == "port-list")
                    {
                        properties["portListPointer"] = 'filterPortList:' + intentIPv6FilterEntryConfig["match"]["port"]["port-list"];
                    }
                }
            }
            if(intentIPv6FilterEntryConfig["match"]["src-port"])
            {
                properties["portSelector"] = "AND_PORT";
                if(intentIPv6FilterEntryConfig["match"]["src-port"]["port"])
                {
                    if(intentIPv6FilterEntryConfig["match"]["src-port"]["port"] == "eq")
                    {
                        properties["sourcePortOperator"] = "mask";
                        properties["sourcePort"] =  intentIPv6FilterEntryConfig["match"]["src-port"]["eq"];
                        properties["sourcePortMask"] =  intentIPv6FilterEntryConfig["match"]["src-port"]["mask"];
                    }
                    else if(intentIPv6FilterEntryConfig["match"]["src-port"]["port"] == "range")
                    {
                        properties["sourcePortOperator"] = "range";
                        if(intentIPv6FilterEntryConfig["match"]["src-port"]["range"])
                        {
                            properties["sourcePort"] =  intentIPv6FilterEntryConfig["match"]["src-port"]["range"]["start"];
                            properties["sourcePortHigh"] =  intentIPv6FilterEntryConfig["match"]["src-port"]["range"]["end"];
                        }
                    }
                    else if(intentIPv6FilterEntryConfig["match"]["src-port"]["port"] == "port-list")
                    {
                        properties["sourcePortListPointer"] = 'filterPortList:' + intentIPv6FilterEntryConfig["match"]["src-port"]["port-list"];
                    }
                }
            }
            if(intentIPv6FilterEntryConfig["match"]["dst-port"])
            {
                properties["portSelector"] = "AND_PORT";
                if(intentIPv6FilterEntryConfig["match"]["dst-port"]["port"])
                {
                    if(intentIPv6FilterEntryConfig["match"]["dst-port"]["port"] == "eq")
                    {
                        properties["destinationPortOperator"] = "mask";
                        properties["destinationPort"] =  intentIPv6FilterEntryConfig["match"]["dst-port"]["eq"];
                        properties["destinationPortMask"] =  intentIPv6FilterEntryConfig["match"]["dst-port"]["mask"];
                    }
                    else if(intentIPv6FilterEntryConfig["match"]["dst-port"]["port"] == "range")
                    {
                        properties["destinationPortOperator"] = "range";
                        if(intentIPv6FilterEntryConfig["match"]["dst-port"]["range"])
                        {
                            properties["destinationPort"] =  intentIPv6FilterEntryConfig["match"]["dst-port"]["range"]["start"];
                            properties["destinationPortHigh"] =  intentIPv6FilterEntryConfig["match"]["dst-port"]["range"]["end"];
                        }
                    }
                    else if(intentIPv6FilterEntryConfig["match"]["dst-port"]["port"] == "port-list")
                    {
                        properties["destinationPortListPointer"] = 'filterPortList:' + intentIPv6FilterEntryConfig["match"]["dst-port"]["port-list"];
                    }
                }
            }
        }

        return this.createChildObjectPayload(fullClassName,properties);
    }

    this.createQueuePayLoad = function(target,queueConfig)
    {

        var fullClassName = "sitesec.CpmFilterQueue";
        var properties = {};

        properties["id"] = queueConfig["queue-id"];
        properties["committedBurstSize"] = queueConfig['cbs'];
        properties["maximumBurstSize"] = queueConfig['mbs'];
        if(queueConfig['rate'])
        {
            if(queueConfig['rate']['pir'] == 'max')
            {
                properties["pir"] = -1;
            }
            else
            {
                properties["pir"] = queueConfig['rate']['pir'];
            }
            if(queueConfig['rate']['cir'] == 'max')
            {
                properties["cir"] = -1;
            }
            else
            {
                properties["cir"] = queueConfig['rate']['cir'];
            }
        }
        return this.createChildObjectPayload(fullClassName,properties);
    }

    this.createChildObjectPayload = function(fullClassName,properties){

        var childObjectPayLoad = {};
        childObjectPayLoad['objectClassName'] = fullClassName;
        childObjectPayLoad['containedClassProperties'] = properties;
        return childObjectPayLoad;
    }

    this.xml2object = function(xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: '+ json)
        return JSON.parse(json);
    }

    this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }

    this.loadSavedObjectsFromTopology = function(savedTopology) {

        if(savedTopology){
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0){
                topoObjects.forEach(function(topoObject){
                    mapFwk.set(savedObjects,topoObject.getObjectType(),topoObject.getObjectRelativeObjectID());
                });
            }
        }

    }

    this.loadCurrentObjectsToTopology = function(target) {

        var currentTopo = topologyFactory.createServiceTopology();
        if(Object.keys(currentObjects).length){
            for(var key in currentObjects){
                objectId = mapFwk.get(currentObjects,key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key,objectId,"INFRASTRUCTURE",target,""));
            }
        }
        return currentTopo;

    }

    this.audit = function(target, config, svcTopo, adminState, auditReport,intentTypeName,initialPropertyName,uniqueIdentifier)
    {
        // code to handle audit
        var savedTopology = svcTopo;
        savedObjects = {};
        currentObjects = {};
        isAudit = true;

        var intentConfig = this.xml2object(config)['configuration'][intentTypeName];
        // intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
        var target = parseTarget.getNeIdFromTarget(target);
        var searchResponse = nfmpFwk.find(target);
        logger.info(JSON.stringify(searchResponse));
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                throw new RuntimeException("Failed to get cpm filter info from nfm-p for Ne " + target);
            if(JSON.parse(searchResponse["response"]).length === 0)
                throw new RuntimeException("There is no CPM filter discovered on NFMP for NE:" + target );
        }
        var finalResponse = JSON.parse(searchResponse['response']);
        var objectFullName = finalResponse[0]['properties']['objectFullName'];
        if (target && String(target).indexOf(':') !== -1) {
             objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
        }
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);

        if (intentConfig) {
            this.auditAndCompare(target, objectFullName, intentConfig, auditReport);
        } else {
            throw "configuration not available in the intent";
        }

        return auditReport
    }

    this.auditAndCompare = function (target, objectFullName, intentConfig, auditReport)
    {
        var cpmFilterPayload = this.createCpmFilterPayLoad(target, intentConfig, objectFullName);
        var result = this.auditRequest(target, cpmFilterPayload);
        auditReport = util.reportMisaligned(target, result, auditReport);
        return auditReport;
    }

    this.auditRequest = function(target,payload){
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;

    }

    this.transformProtocol = function (protocol)
    {
        if(protocol == "tcp-udp")
        {
            return "UDPTCP";
        }
        else if(protocol == "icmp")
        {
            return "ICMP";
        }
        else if(protocol == "igmp")
        {
            return "IGMP";
        }
        else if(protocol == "ip")
        {
            return "IP";
        }
        else if(protocol == "tcp")
        {
            return "TCP";
        }
        else if(protocol == "egp")
        {
            return "EGP";
        }
        else if(protocol == "igp")
        {
            return "IGP";
        }
        else if(protocol == "udp")
        {
            return "UDP";
        }
        else if(protocol == "rdp")
        {
            return "RDP";
        }
        else if(protocol == "ipv6")
        {
            return "IPv6";
        }
        else if(protocol == "ipv6-route")
        {
            return "IPv6Route";
        }
        else if(protocol == "ipv6-frag")
        {
            return "IPv6Frag";
        }
        else if(protocol == "idrp")
        {
            return "IDRP";
        }
        else if(protocol == "rsvp")
        {
            return "RSVP";
        }
        else if(protocol == "gre")
        {
            return "GRE";
        }
        else if(protocol == "ipv6-icmp")
        {
            return "IPv6_ICMP";
        }
        else if(protocol == "ipv6-no-nxt")
        {
            return "IPv6_NoNxt";
        }
        else if(protocol == "ipv6-opts")
        {
            return "IPv6_Opts";
        }
        else if(protocol == "iso-ip")
        {
            return "ISO_IP";
        }
        else if(protocol == "eigrp")
        {
            return "EIGRP";
        }
        else if(protocol == "ospf-igp")
        {
            return "OSPFIGP";
        }
        else if(protocol == "ether-ip")
        {
            return "ETHERIP";
        }
        else if(protocol == "encap")
        {
            return "ENCAP";
        }
        else if(protocol == "pnni")
        {
            return "PNNI";
        }
        else if(protocol == "pim")
        {
            return "PIM";
        }
        else if(protocol == "vrrp")
        {
            return "VRRP";
        }
        else if(protocol == "l2tp")
        {
            return "L2TP";
        }
        else if(protocol == "stp")
        {
            return "STP";
        }
        else if(protocol == "ptp")
        {
            return "PTP";
        }
        else if(protocol == "isis")
        {
            return "ISIS";
        }
        else if(protocol == "crtp")
        {
            return "CRTP";
        }
        else if(protocol == "crudp")
        {
            return "CRUDP";
        }
        else if(protocol == "sctp")
        {
            return "SCTP";
        }
        else
        {
            return undefined;
        }

    }

}
