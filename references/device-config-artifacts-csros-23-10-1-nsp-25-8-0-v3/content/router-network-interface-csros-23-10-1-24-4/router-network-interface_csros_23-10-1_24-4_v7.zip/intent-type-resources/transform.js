load({ script: resourceProvider.getResource("nfmpSuggest.js"), name: "NfmpSuggest" });
load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
function transformData() {
    let ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(\/(0|[1-9][0-9]?|1[0-1][0-9]?|12[0-8]))?$/;
    let jsonFile = resourceProvider.getResource("meta-data/property-meta-data.json");
    jsonFile = JSON.parse(jsonFile);
    const nfmpSuggest = new NfmpSuggest();
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        let interfaceData;
        if(intentConfig.id){
            interfaceData = nfmpSuggest.getInterfaceData(neId, intentConfig.id, "id", "displayedName");
            if(interfaceData == undefined)
            {
                interfaceData = 0;
            }
            objectFullName = objectFullName.replace(/interface-[^:]+/, "interface-"+interfaceData);
        }
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        let interfaceData;
        let interfaceName = uniqueIdentifierValues[0];
        if(interfaceName){
            interfaceData = nfmpSuggest.getInterfaceData(neId, interfaceName, "id", "displayedName");
            objectFullName = objectFullName.replace(/interface-[^:]+/, "interface-"+interfaceData);
        }
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        if (payload.configInfo)
        {
            if (payload.configInfo["rtr.NetworkInterface"])
            {
                let networkInterface = payload.configInfo["rtr.NetworkInterface"];
                networkInterface.displayedName = networkInterface.id;
                if (networkInterface.id)
                {
                    let interfaceData = nfmpSuggest.getInterfaceData(neId, networkInterface.id, "id", "displayedName");
                    networkInterface.id = interfaceData;
                }
                if(networkInterface.id == undefined)
                {
                    networkInterface.id = 0;
                }
                if (networkInterface.dCpuProtectionPolicyPointer) {
                   if (!networkInterface.dCpuProtectionPolicyPointer.toString().startsWith("DCpuProtection:")) {
                      let nfmpNameExtension = "DCpuProtection:"
                      let dCpuProtectionPolicyData  = nfmpNameExtension + networkInterface.dCpuProtectionPolicyPointer;
                      networkInterface.dCpuProtectionPolicyPointer = dCpuProtectionPolicyData;
                   }
                }
                if (networkInterface.dosProtection) {
                   if (!networkInterface.dosProtection.toString().startsWith("NE DoS Protection:")) {
                      let nfmpNameExtension = "NE DoS Protection:"
                      let dosProtectionData  = nfmpNameExtension + networkInterface.dosProtection;
                      networkInterface.dosProtection = dosProtectionData;
                   }
                }
                if (networkInterface.networkPolicyObjectPointer) {
                   if (!networkInterface.networkPolicyObjectPointer.toString().startsWith("Network:")) {
                      let nfmpNameExtension = "Network:"
                      let networkPolicyData  = nfmpNameExtension + networkInterface.networkPolicyObjectPointer;
                      networkInterface.networkPolicyObjectPointer = networkPolicyData;
                   }
                }
                if (networkInterface.qosIngFpRedirectQGrpPointer) {
                  if (!networkInterface.qosIngFpRedirectQGrpPointer.toString().startsWith("ingressQGroup:")) {
                     let nfmpNameExtension = "ingressQGroup:"
                     let qosIngFpRedirectQGrpData  = nfmpNameExtension + networkInterface.qosIngFpRedirectQGrpPointer;
                     networkInterface.qosIngFpRedirectQGrpPointer = qosIngFpRedirectQGrpData;
                  }
                }
                if (networkInterface.redirectQueueGroupPointer) {
                  if (!networkInterface.redirectQueueGroupPointer.toString().startsWith("egressQGroup:")) {
                     let nfmpNameExtension = "egressQGroup:"
                     let redirectQueueGroupData  = nfmpNameExtension + networkInterface.redirectQueueGroupPointer;
                     networkInterface.redirectQueueGroupPointer = redirectQueueGroupData;
                  }
                }
                if (networkInterface.policyAccountingTemplatePointer) {
                  if (!networkInterface.policyAccountingTemplatePointer.toString().startsWith("rpAccountingTemp:pactmp-")) {
                     let nfmpNameExtension = "rpAccountingTemp:pactmp-"
                     let policyAccountingTempData  = nfmpNameExtension + networkInterface.policyAccountingTemplatePointer;
                     networkInterface.policyAccountingTemplatePointer = policyAccountingTempData;
                  }
                }
                if((isAudit && networkInterface["children-Set"] && this.isJsonCompletelyEmpty(networkInterface["children-Set"]["rtr.RouterAdvertisement"])) || (networkInterface['displayedName'] == 'system'))
                {
                    delete networkInterface["children-Set"]["rtr.RouterAdvertisement"];
                }
                if(networkInterface.ipv6Allowed != true && networkInterface["children-Set"])
                {
                    delete networkInterface["children-Set"]["rtr.SecureNeighborDiscovery"];
                    delete networkInterface["children-Set"]["rtr.ProxyNeighborDiscovery"];
                }
                if(!networkInterface.adminGroupInclude) {
                    networkInterface.adminGroupInclude = "0";
                }
            }
        }
        return payload;
    }
    this.isJsonCompletelyEmpty = function(obj) {
      // Check if the object itself is empty
      if (Object.keys(obj).length === 0) {
        return true;
      }

      // Check each property
      for (let key in obj) {
        if (obj.hasOwnProperty(key)) {
          // If the property is an object, check it recursively
          if (typeof obj[key] === 'object' && obj[key] !== null) {
            if (!this.isJsonCompletelyEmpty(obj[key])) {
              return false;
            }
          } else {
            // If the property is not an object (or it's a non-null primitive value), it's not empty
            return false;
          }
        }
      }
      // If all properties are empty objects or there are no properties, the object is empty
      return true;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        let ipv6AddrUtil = new IPv6AddressUtil();
        if(isAudit)
        {
            if(xpath == "egressPirPercent" || xpath == "egressCirPercent")
            {
                if(targetValue && !isNaN(targetValue) && !targetValue.contains("."))
                {
                    targetValue = Number(targetValue);
                    targetValue = targetValue.toFixed(1);
                }
            }
            if(xpath == "rtr-RouterAdvertisement.rtr-RouterAdvertisementPrefix.prefix"||
               xpath == "sas-DelayMetricConfiguration.ipv6SourAddress" ||
               xpath == "sas-DelayMetricConfiguration.ipv6DestAddress" ||
               xpath == "rtr-RouterAdvertisement.rtr-InterfaceDNSOptions.server1"||
               xpath == "rtr-RouterAdvertisement.rtr-InterfaceDNSOptions.server2"||
               xpath == "rtr-RouterAdvertisement.rtr-InterfaceDNSOptions.server3"||
               xpath == "rtr-RouterAdvertisement.rtr-InterfaceDNSOptions.server4"||
               xpath == "rtr-NeighborDiscovery.ipAddress")
            {
                targetValue = ipv6AddrUtil.expandIPv6AddressForClassic(targetValue);
            }
            if(xpath == "rtr-VirtualRouterIpAddress.ipAddress" ||
               xpath == "adminLinkLocalAddrWithZoneIndex" ||
               xpath == "adminLinkLocalAddr"||
               xpath == "ipHelperAddress")
            {
                if(ipv6AddrUtil.matchExact(ipv6Regex, targetValue))
                {
                    targetValue = ipv6AddrUtil.expandIPv6AddressForClassic(targetValue);
                }
            }
            if(xpath == "vrrp-Instance.vrrp-AuthenticationKey.key")
            {
                targetValue = undefined;
            }
        }
        if(xpath === "vrrp-Instance.vrrpPolicyPointer" || xpath === "vrrp-InstanceV6.vrrpPolicyPointer")
        {
            targetValue = this.convertVrrpPolicyPointerGreenField(targetValue, neId);
        }
        if(xpath === "portPointer")
        {
            targetValue = this.convertPortToPortPointer(targetValue, neId);
        }
        if(xpath == "rtr-DhcpRelayConfiguration.pythonPolicyPointer")
        {
             if (!targetValue.startsWith("pythonPolicy:")) {
                 let nfmpNameExtension = "pythonPolicy:"
                 let pythonPolicy  = nfmpNameExtension + targetValue;
                 targetValue = pythonPolicy;
              }
        }
        if(xpath == "sas-DelayMetricConfiguration.linkMeasTemplatePointer")
        {
            if (!targetValue.startsWith("linkMeasurementTemplate:")) {
                 let nfmpNameExtension = "linkMeasurementTemplate:"
                 let linkMeasurementTemplate  = nfmpNameExtension + targetValue;
                 targetValue = linkMeasurementTemplate;
              }
        }
        if(xpath == "rtr-RouterAdvertisement.rtr-InterfaceDNSOptions.server1" ||
            xpath == "rtr-RouterAdvertisement.rtr-InterfaceDNSOptions.server2" ||
             xpath == "rtr-RouterAdvertisement.rtr-InterfaceDNSOptions.server3" ||
             xpath == "rtr-RouterAdvertisement.rtr-InterfaceDNSOptions.server4")
        {
            if(isAudit && targetValue == "0:0:0:0:0:0:0:0")
            {
                targetValue = undefined;
            }
        }
        if(xpath == "rtr-DhcpRelayConfiguration.server1" ||
            xpath == "rtr-DhcpRelayConfiguration.server2" ||
             xpath == "rtr-DhcpRelayConfiguration.server3" ||
             xpath == "rtr-DhcpRelayConfiguration.server4" ||
             xpath == "rtr-DhcpRelayConfiguration.server5" ||
             xpath == "rtr-DhcpRelayConfiguration.server6" ||
             xpath == "rtr-DhcpRelayConfiguration.server7" ||
             xpath == "rtr-DhcpRelayConfiguration.server8")
        {
            if(isAudit && targetValue == "0.0.0.0")
            {
                targetValue = undefined;
            }
        }
        if(xpath === "sharedRiskLinkGroupPointers")
         {
             let newtarget = []
             logger.info("targetValue ======= {} ",JSON.stringify(targetValue));
             targetValue.forEach(function(item) {
             for (var key in item) {
                if (item.hasOwnProperty(key)) {
                  let dat = {};
                  dat[key] = "rtrSrlgGroup:srlg-"+item[key];
                  newtarget.push(dat);
                }
             }
           });
           targetValue = newtarget;
         }
         if(targetValue && targetValue != "N/A")
         {
             if(xpath === "ingressFilterPointer" ||
                xpath === "egressFilterPointer")
             {
                 targetValue = "IP Filter:"+targetValue;
             }
             if(xpath === "ingressIpv6FilterPointer" ||
                xpath === "egressIpv6FilterPointer")
             {
                 targetValue = "IPv6 Filter:"+targetValue;
             }
             if(xpath === "localDhcpServerPointer")
             {
                 targetValue = "network:"+neId+":router-1:localDhcpServer-"+targetValue;
             }
         }

        return targetValue;
    }
    this.convertPortToPortPointer = function(portName, neId)
    {
        return nfmpSuggest.getPortObjectFullName(neId,portName);
    }
    this.convertVrrpPolicyPointerGreenField = function(vrrpDisplayName, neId)
    {
       return "network:"+neId+":VRRP:"+nfmpSuggest.getVrrpPolicyPointerFdn(neId,vrrpDisplayName);
        //return nfmpSuggest.getVrrpPolicyPointerFdn(neId,vrrpDisplayName);
    }
     this.convertVrrpPolicyPointerBrownField = function(vrrpPolicyPointer)
    {
        return nfmpSuggest.getVrrpPolicyPointerdisplayedName(vrrpPolicyPointer);
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig,targetWithTemplate) {
        if(xpath === "sharedRiskLinkGroupPointers")
        {
          let newtarget = []
          logger.info("targetValue ======= {} ",JSON.stringify(targetValue));
          targetValue.forEach(function(pointer) {
             let keyType = jsonFile[targetKey]["dataTypeInfo"]["typeListProperties"]["type"];
             keyType = keyType.toLowerCase();
             logger.info("pointer ===== {}" , pointer[keyType]);
             let dat = {};
             dat[keyType] = pointer[keyType].split("-")[1];
             newtarget.push(dat);
          });
          targetValue = newtarget;
        }
        if(xpath === "vrrp-Instance.vrrpPolicyPointer" || xpath === "vrrp-InstanceV6.vrrpPolicyPointer")
        {
            targetValue = this.convertVrrpPolicyPointerBrownField(targetValue);
        }
        if(xpath === "portPointer")
        {
            targetValue = this.convertPortPointerToPort(targetValue);
        }
        if(xpath === "adminGroupInclude")
        {
            logger.info("=======================================")
            logger.info("xpath = {}, targetKey={}, targetValue={}",xpath,targetKey,targetValue)
            let neId = parseTarget.getNeIdFromTarget(targetWithTemplate);
            let result = [];
            for (let i = 0; i < 255; i++) {
                if ((targetValue & (1 << i)) !== 0) {
                    result.push(i.toString());
                }
            }
            targetValue = nfmpSuggest.getFormattedAdminGroupData(result,neId);
        }
        if (xpath === "dCpuProtectionPolicyPointer") {
             targetValue = brownFieldNfmpNameSupport(targetValue, "DCpuProtection:");
        }
        else if(xpath === "dosProtection"){
             targetValue = brownFieldNfmpNameSupport(targetValue, "NE DoS Protection:");
        }
        else if(xpath === "networkPolicyObjectPointer"){
             targetValue = brownFieldNfmpNameSupport(targetValue, "Network:");
        }
        else if(xpath === "qosIngFpRedirectQGrpPointer"){
             targetValue = brownFieldNfmpNameSupport(targetValue, "ingressQGroup:");
        }
        else if(xpath === "redirectQueueGroupPointer"){
             targetValue = brownFieldNfmpNameSupport(targetValue, "egressQGroup:");
        }
        else if(xpath === "rtr-DhcpRelayConfiguration.pythonPolicyPointer"){
             targetValue = brownFieldNfmpNameSupport(targetValue, "pythonPolicy:");
        }
        else if(xpath === "sas-DelayMetricConfiguration.linkMeasTemplatePointer"){
             targetValue = targetValue.split(':').pop();
        }
        else if(xpath === "policyAccountingTemplatePointer"){
             targetValue = brownFieldNfmpNameSupport(targetValue, "rpAccountingTemp:pactmp-");
        }
        else if(xpath === "ingressFilterPointer" ||
                xpath === "egressFilterPointer")
        {
             targetValue = brownFieldNfmpNameSupport(targetValue, "IP Filter:");
        }
        else if(xpath === "ingressIpv6FilterPointer" ||
                xpath === "egressIpv6FilterPointer")
        {
              targetValue = brownFieldNfmpNameSupport(targetValue, "IPv6 Filter:");
        }
        else if(xpath === "localDhcpServerPointer")
        {
              const match = targetValue.match(/localDhcpServer-([\w\d]+)$/);
              targetValue = match ? match[1] : null;
        }
       function brownFieldNfmpNameSupport(input, nameExtension) {
         if (input !== undefined && input.startsWith(nameExtension)) {
            var input1 = input.replace(nameExtension, "");
            return input1;
         }
         return input;
        }
        return targetValue;
    }
    this.convertPortPointerToPort = function(portPointer)
    {
        return nfmpSuggest.getPortName(portPointer);
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }

    this.transformIntentConfig = function (intentConfig) {
        function handleAdminGroupValue(value) {
            let binary = 0;
            value.forEach(item => {
                const match = item.match(/\((\d+)\)/);
                if (match) {
                    const bitPosition = Number(match[1]);
                    binary |= (1 << bitPosition);
                }
            });
            return binary.toString();
        };
        if(intentConfig["adminGroupInclude"]) {
            intentConfig["adminGroupInclude"] = handleAdminGroupValue(intentConfig["adminGroupInclude"]);
        }
    }
}