function MdSuggest() {
    this.getServerProfileName = function (neId) {
       const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/system/security/tls/server-tls-profile?fields=server-profile-name`;
       return this.getSuggestData(neId, url, "nokia-conf:server-tls-profile", "server-profile-name");
    }

    this.getCertProfile = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/system/security/tls/cert-profile?fields=cert-profile-name`;
    return this.getSuggestData(neId, url, "nokia-conf:cert-profile", "cert-profile-name");
   }

    this.getServerCipherList = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/system/security/tls/server-cipher-list?fields=server-cipher-list-name`;
    return this.getSuggestData(neId, url, "nokia-conf:server-cipher-list", "server-cipher-list-name");
   }

    this.getServerGroupList = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/system/security/tls/server-group-list?fields=server-group-list-name`;
    return this.getSuggestData(neId, url, "nokia-conf:server-group-list", "server-group-list-name");
   }

    this.getServerSignatureList = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/system/security/tls/server-signature-list?fields=server-signature-list-name`;
    return this.getSuggestData(neId, url, "nokia-conf:server-signature-list", "server-signature-list-name");
   }

    this.getCommonNameList = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/system/security/pki/common-name-list?fields=cn-list-name`;
    return this.getSuggestData(neId, url, "nokia-conf:common-name-list", "cn-list-name");
   }

    this.getTrustAnchorProfile = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/system/security/tls/trust-anchor-profile?fields=trust-anchor-profile-name`;
    return this.getSuggestData(neId, url, "nokia-conf:trust-anchor-profile", "trust-anchor-profile-name");
   }

   this.getSuggestData = function(neId, url, initialProperty, propertyName) {
      const mdcFwk = new MdcFwk();
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg[initialProperty];
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data[propertyName]).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }
}
