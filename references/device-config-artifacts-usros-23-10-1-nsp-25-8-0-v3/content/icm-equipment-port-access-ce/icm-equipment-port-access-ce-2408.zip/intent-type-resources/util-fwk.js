load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {

    this.setErrorResult = function (result) {
        result.setSuccess(false);
        result.setErrorCode(100);
        result.setErrorDetail("failed To set Topology.");

        return result
    }

    this.setSuccessResult = function (result,savedTopology) {
        result.setSuccess(true);
        if (savedTopology !== undefined){
            result.setTopology(savedTopology);
        }

        return result;
    }

    this.reportMisaligned = function (target, result, auditReport) {
        var report = JSON.parse(result.response);
        if (!report.aligned)
        {
            for (var i = 0; i < report.misalignedAttributes.length; i++)
            {
                var attributeData = report.misalignedAttributes[i];
                if (attributeData.expected == "present")
                {
                    //misaligned object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else if (attributeData.expected == "not present")
                {
                    //undesired object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                    auditReport.addMisAlignedAttribute(misalignedAttribute);
                }

            }
        }
        return auditReport
    }

    /*
    function: getBaseFdnForPort
    description: Construct the Fdn for Port and return it.
    */
    this.getBaseFdnForPort = function(target,portId){
        var portIds = portId.split("/");
        var cardSlot = portIds[0];
        var mdaSlot = portIds[1];
        var portNumber = portIds[2];
        let portDn = "network:"+target+":shelf-1:cardSlot-"+cardSlot+":card:daughterCardSlot-"+mdaSlot+":daughterCard:port-"+portNumber;
        if (target && String(target).indexOf(':') !== -1) {
            portDn = this.modifyNeIdForIpV6(portDn, target);
        }
       return portDn;
    }

    /*
    function: isObjectExists
    description: To check if the object exists or not.
    */
    this.isObjectExists = function(target,className, objectFullName)
    {
        let nfmpFwk = new NfmpFwk();
        var filterExpression = "siteId='" + target + "' AND fullName='" + objectFullName + "'";
        var searchPayLoad = {
            "fullClassName": className,
            "filter": {
                "filterExpression": filterExpression
            }
        };
        logger.info("[UTIL-FWK.JS] isObjectExists(): Search Payload = "+JSON.stringify(searchPayLoad));
        var ret = false;
        var searchResponse = nfmpFwk.find(target, searchPayLoad);
        var finalResponse = JSON.parse(searchResponse.response);

        logger.info("[UTIL-FWK.JS] isObjectExists(): Search Response = "+JSON.stringify(finalResponse));

        if(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0)
        {
            ret = true;
        }

        return ret;
    }

    /*
     function: getIfObjectExists
     description: returns the object for objectFullName if exists.
    */
    this.getIfObjectExists = function(className, objectFullName)
    {
        let nfmpFwk = new NfmpFwk();
        var expectedJson = {
            "fullClassName": className,
            "filter": {
                "filterExpression": "fullName='"+objectFullName+"'"
            }
        };
        var ret = false;
        var resultFetch = nfmpFwk.post("search", expectedJson);
        var finalResponse = JSON.parse(resultFetch.response);

        if(!Array.isArray(finalResponse))
        {
            finalResponse = null;
        }
        logger.info("[UTIL-FWK.JS] getIfObjectExists(): finalResponse ="+JSON.stringify(finalResponse));
        return finalResponse;
    }


    /*
    function: editPayLoad
    description: Construct the payload to deploy on nfm-p.
    */
    this.editPayload = function(fdn,properties,childProperties,fullClassName,objectFullName){

        var payload  = {};
        var configInfo = {};

        configInfo["containedClassProperties"] = properties;
        if (childProperties != null){
            configInfo["containmentInfo"] = childProperties;
        }
        configInfo["objectClassName"] = fullClassName;
        //payload["fdn"] = fdn;
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName,
            payload["configInfo"] = configInfo;

        return payload;
    }

    /*
    function: isEmpty
    description: To check the passed parameter is Empty or not.
    */
    this.isEmpty = function(obj) {
        if(obj == null){
            return true;
        }
        return Object.keys(obj).length === 0;
    }

    /*
    function: delay
    description: Sometimes the object creation takes time, we can use delay for child-level operation.
    */
    this.delay = function (milliseconds){
        var date = new Date();
        date.setMilliseconds(date.getMilliseconds() + milliseconds);
        while(new Date() < date){
        }
    }

    /*
    function: getNfmpTimeSlotBits
    description: get the Timeslots Bits from the selected timeSlotRange.
    */
    this.getNfmpTimeSlotBits = function(timeSlots){
        logger.info("[UTIL-FWK.JS] getTimeSlotBits(): Selected Timeslots ="+timeSlots);
        var timeSlotBits = [];
        if(timeSlots != null)
        {
            timeSlotBits = timeSlots.split(" ");
        }
        logger.info("[UTIL-FWK.JS] getTimeSlotBits(): Converted Timeslots to Nfmp timeSlotBits ="+timeSlotBits);

        return timeSlotBits;
    }

    /*
    function: compareTimeSlots
    description: compare the Timeslots of intent with the Nfmp timeSlotBits.
    */
    this.compareTimeSlots = function(intentTimeSlot,timeSlotBits){
        var result = false;
        if(intentTimeSlot.length === 0 && timeSlotBits.length === 0){
            return true;
        }
        if (intentTimeSlot.length === timeSlotBits.length) {
            for (var index in intentTimeSlot) {
                result = timeSlotBits.indexOf(intentTimeSlot[index]) !== -1;
                if (result === false) {
                    break;
                }
            }
        }
        return result;
    }

    /*
    function: isContiansInResponse
    description: For auditTimeslots, check if the misaligned object is already there in response or not
    */
    this.isContiansInResponse = function(response,obj){
        return response.some(function (res) {
            return res.name === obj.name;
        });
    }

    this.modifyNeIdForIpV6 = function (objectFullName, neId) {
        logger.info("modifying NeId For IpV6");
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }
}
