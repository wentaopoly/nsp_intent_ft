load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
load({script: resourceProvider.getResource('nfmp-port-policy-fwk.js'), name: 'NfmpPortIngressPolicyFwk'})
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'})

function NspIntentHelper() {

    var mdtFwk = new MdtFwk();

    this.synchronize = function (input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        logger.info("Nsp Intent Helper -> Synchronise--> input,intentTypeName,parentXpath,initialPropertyName =" + input + "," + intentTypeName + "," + parentXpath + "," + initialPropertyName);
        try {
            var result = synchronizeResultFactory.createSynchronizeResult();
            var instanceFwk = this.navigateInstance(input.getTarget());
            instanceFwk.synchronize(input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
            return result
        } catch (e) {
            logger.info('Error Occured while Synchronising with error: ' + e)
            throw new RuntimeException('Error Executing Intent: ' + e)
        }
    }

    this.audit = function (input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        try {
            var instanceFwk = this.navigateInstance(input.getTarget());
            logger.info('instanceFwk ' + instanceFwk)
            var report = auditFactory.createAuditReport(null, null);
            //Calling the audit of respective fwk
            instanceFwk.audit(input, report, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier)
            return report
        } catch (e) {
            logger.info('Error Occured while Auditing with error: ' + e)
            throw new RuntimeException('Error Executing Intent: ' + e)
        }
    }

    this.navigateInstance = function (target) {
        //THIS INTENT IS ONLY FOR NFMP AND NOT FOR NE'S IN NFMP, HENCE REMOVING THE NODE CHECK
        return this.createNfmpInstance();
        /*var managerName = mdtFwk.getManagerName(new ParseTarget().getNeIdFromTarget(target));
        logger.info('Device: ' + target + ' is managed by: ' + managerName);
        switch (managerName)
        {
            case 'NFM-P':
                logger.info('Device is managed by NFMP')
                return this.createNfmpInstance()
                break;
            default:
                logger.info('Device is not managed')
                throw new RuntimeException('Device is not Managed')
        }

        return ''*/
    }
    this.createNfmpInstance = function () {
        return new NfmpPortIngressPolicyFwk()
    }
}
