var RuntimeException = Java.type('java.lang.RuntimeException');

load({
    script: resourceProvider.getResource('mdc-fwk.js'),
    name: 'MdcFwk'
});
load({
    script: resourceProvider.getResource('parse-target.js'),
    name: 'ParseTarget'
});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});



function MdcDiscoveryHelper() {
    let mdcFwk = new MdcFwk();
    let parseTarget = new ParseTarget();

    let intentDeviationObj = new IntentDeviceDeviation();

    this.getDeviceConfiguration = function (targetWithTemplate, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(targetWithTemplate);
        let url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/routing-options/" + initialPropertyName
        let getResult = mdcFwk.fetch(neId, url);
        let configFromDevice = getResult.msg["nokia-conf:" + initialPropertyName];
        if (configFromDevice == undefined)
        {
            throw new RuntimeException("cannot get configuration from device");
        }
        logger.info("configFromDevice == {}",JSON.stringify(configFromDevice))
        return configFromDevice;
    }

    this.extractDeviceConfig = function (targetData, deviceConfig, initialPropertyName) {
        let parsedTargetData = JSON.parse(targetData);
        let config = parsedTargetData[initialPropertyName];
        let mergedTargetData = this.traverse(config, deviceConfig);
        parsedTargetData[initialPropertyName] = mergedTargetData;
        return parsedTargetData;
    }

    this.traverse = function (targetData, deviceConfig) {
        if (targetData !== null && targetData !== undefined)
        {
            let keys = Object.keys(targetData);
            for (let i = 0; i < keys.length; i++)
            {
                let propertyName = keys[i];
                let deviceValue = deviceConfig[propertyName];

                if (deviceValue != undefined && Array.isArray(deviceValue))
                {
                    targetData[propertyName] = this.ArrayTraverse(targetData[propertyName], deviceValue, []);
                }
                else if (deviceValue != undefined && typeof deviceValue === 'object')
                {
                    targetData[propertyName] = this.containerTraverse(targetData[propertyName], deviceValue, {});
                }
                else
                {
                    targetData[propertyName] = deviceValue
                }
            }

        }
        return targetData;
    }

    this.ArrayTraverse = function (arrayTargetData, arrayDeviceConfigData, arrayData) {
        for (let i = 0; i < arrayDeviceConfigData.length; i++)
        {
            let arrayObject = {};
            let keys = Object.keys(arrayTargetData[0]);
            for (let j = 0; j < keys.length; j++)
            {
                let propertyName = keys[j];
                let deviceValue = arrayDeviceConfigData[i][propertyName];
                if (deviceValue != null && deviceValue != undefined && Array.isArray(deviceValue))
                {
                    arrayObject[propertyName] = this.ArrayTraverse(arrayTargetData[0][propertyName], deviceValue, []);
                }
                else if (deviceValue != null && deviceValue != undefined && typeof deviceValue === 'object')
                {
                    arrayObject[propertyName] = this.containerTraverse(arrayTargetData[0][propertyName], deviceValue, {});

                }
                else
                {
                    arrayObject[propertyName] = deviceValue
                }
            }
            arrayData.push(arrayObject);
        }
        return arrayData;
    }

    this.containerTraverse = function (containerTargetData, containerDeviceConfigData, targetContainer) {
        let keys = Object.keys(containerTargetData);
        for (let i = 0; i < keys.length; i++)
        {
            let propertyName = keys[i];
            let deviceValue = containerDeviceConfigData[propertyName];
            if (deviceValue != null && deviceValue != undefined && Array.isArray(deviceValue))
            {
                if (this.isAtrributeLeafList(deviceValue))
                {
                    targetContainer[propertyName] = deviceValue;
                }
                else
                {
                    targetContainer[propertyName] = this.ArrayTraverse(containerTargetData[propertyName], deviceValue, []);
                }

            }
            else if (deviceValue != null && deviceValue != undefined && typeof deviceValue === 'object')
            {
                targetContainer[propertyName] = this.containerTraverse(containerTargetData[propertyName], deviceValue, {});
            }
            else
            {
                targetContainer[propertyName] = deviceValue
            }
        }
        return targetContainer;
    }

    this.isAtrributeLeafList = function (leaflistData) {
        let isLeaflist = true;
        for (let i = 0; i < leaflistData.length; i++)
        {

            if (leaflistData[i] != null && typeof leaflistData[i] == 'object')
            {
                isLeaflist = false;
                break;
            }
        }
        return isLeaflist;
    }

    this.cipherSpecialCharacterInKey = function (key) {
        return key.replaceAll("/", "%2F").replaceAll(":", "%3A");
    }
}