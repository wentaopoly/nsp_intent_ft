load({script: resourceProvider.getResource('intent-logger.js'), name: 'intent-logger.js'});
load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'mediator-fwk.js'});

IntentValidator.prototype.nspMediator = new MediatorFramework("NSP");
IntentValidator.prototype.imLogger = null;

/*
 * Constructor Function. We'll attach more property and methods by updating "prototype" object.
 */
function IntentValidator(imLogger) {
    this.imLogger = imLogger || new IntentLogger();
}

IntentValidator.prototype.validateNe = function (requestContext, navigateInstance, deviceList) {
    for (var j = 0; j < deviceList.length; j++) {
        navigateInstance(deviceList[j], requestContext);
    }
};


IntentValidator.prototype.validateOnModify = function (requestContext, intentConfigJson, contextualErrorJsonObj) {
    var ietfGet = this.nspMediator.fetch("https://restconf-gateway:443/restconf/data/ietf-te:te/tunnels/tunnel=" + requestContext.get("originalTarget"));
    if (ietfGet.response && ietfGet.response["ietf-te:tunnel"] && ietfGet.response["ietf-te:tunnel"][0]) {
        ietfGet = ietfGet.response["ietf-te:tunnel"][0];
        this.imLogger.info("tunnel ietfGet: {}", ietfGet);
        if (intentConfigJson["source"] !== ietfGet["source"])
            contextualErrorJsonObj["source"] = "cannot modify source ip address";
        if (intentConfigJson["destination"] !== ietfGet["destination"])
            contextualErrorJsonObj["destination"] = "cannot modify destination ip address";
        if (intentConfigJson["bidirectional"] !== ietfGet["bidirectional"])
            contextualErrorJsonObj["bidirectional"] = "cannot modify bidirectional flag";
        if (!ietfGet["primary-paths"] || !ietfGet["primary-paths"]["primary-path"] ||
            (ietfGet["primary-paths"] && ietfGet["primary-paths"]["primary-path"] && ietfGet["primary-paths"]["primary-path"].length === 0)) {
            if (intentConfigJson["primary-paths"] && intentConfigJson["primary-paths"]["primary-path"] && intentConfigJson["primary-paths"]["primary-path"].length !== 0)
                contextualErrorJsonObj["primary-paths"] = "cannot change hopless path to explicit path, please recreate tunnel";
        }
    }
};

IntentValidator.prototype.validateSignalingTypes = function (intentConfigJson, contextualErrorJsonObj) {
    var tunnelSignalingType = intentConfigJson["signaling-type"];
    this.imLogger.debug("tunnel signaling-type: " + tunnelSignalingType);
    var pathsToIterate = ["primary", "secondary"]; // will be appended with "-path(s)" for iteration
    var error = false; // flag to break out of signaling-type validation loop
    for (var i = 0; i < pathsToIterate.length; i++) {
        if (error) break;
        var currPathPrefix = pathsToIterate[i];
        // Get the paths
        var paths = intentConfigJson[currPathPrefix + "-paths"][currPathPrefix + "-path"] || [];
        // If it's a single path (object), then transform to array for iteration
        if (paths instanceof Object && !Array.isArray(paths)) {
            paths = [paths];
        }
        this.imLogger.debug("paths: " + paths);
        // Go through and verify signaling types match
        for (var j = 0; j < paths.length; j++) {
            var signalingType = paths[j]["signaling-type"];
            this.imLogger.debug(currPathPrefix + "[" + j + "]" + " signaling-type: " + signalingType);
            if (signalingType !== tunnelSignalingType) {
                // found a mismatch, no need to continue checking
                contextualErrorJsonObj[currPathPrefix + "-path[" + j + "]"] = "signaling type must match root signaling-type of " + tunnelSignalingType;
                error = true;
                break;
            }
        }
    }
};

IntentValidator.prototype.validateRouteObjects = function (intentConfigJson, contextualErrorJsonObj) {
    var pathsToIterate = ["primary", "secondary"]; // will be appended with "-path(s)" for iteration
    var excludeAlwayses = []; // will hold "route-object-exclude-always" objects
    for (var i = 0; i < pathsToIterate.length; i++) {
        var currPathPrefix = pathsToIterate[i];
        // Get the paths
        var paths = intentConfigJson[currPathPrefix + "-paths"][currPathPrefix + "-path"] || [];
        // If it's a single path (object), then transform to array for iteration
        if (paths instanceof Object && !Array.isArray(paths)) {
            paths = [paths];
        }
        // Go through the paths route objects
        for (var j = 0; j < paths.length; j++) {
            var routeObject = paths[j]["explicit-route-objects-always"];
            if (routeObject) {
                var obj = routeObject["route-object-exclude-always"];
                if (obj) {
                    // Sort exclude-always by index
                    obj.sort(function (a, b) {
                        return a.index - b.index
                    });
                    // Store the sorted & stringified exclude-always object
                    excludeAlwayses.push(JSON.stringify(obj));
                }
            }
        }
    }
    // Verify every exclude-always stored are equal
    var excludeAlwaysMatch = excludeAlwayses.every(function (value, index, arr) {
        return value === arr[0];
    });
    if (!excludeAlwaysMatch) contextualErrorJsonObj["route-object-exclude-always"] = "route-object-exclude-always in primary and secondary paths must match";
};
