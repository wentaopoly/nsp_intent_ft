function ModelDeviceMapping() {
    this.getCardMapping = function () {
        var mapping = {};
        mapping['card.admin-state'] = 'administrativeState';
        mapping['card.card-type'] = 'specificType';
        return mapping;
    }
    this.getXiomMapping = function () {
        var mapping = {};
        mapping['card.xiom.xiom-slot'] = 'xiomCardSlotId';
        mapping['card.xiom.admin-state'] = 'administrativeState';
        mapping['card.xiom.xiom-type'] = 'specificType';
        return mapping;
    }
    this.getMdaMapping = function () {
        var mapping = {};
        mapping['card.mda.mda-slot'] = 'daughterCardSlotId';
        mapping['card.mda.admin-state'] = 'administrativeState';
        mapping['card.mda.mda-type'] = 'specificType';
        mapping['card.mda.sync-e'] = 'syncE';
        mapping['card.xiom.mda.mda-slot'] = 'daughterCardSlotId';
        mapping['card.xiom.mda.admin-state'] = 'administrativeState';
        mapping['card.xiom.mda.mda-type'] = 'specificType';
        mapping['card.xiom.mda.sync-e'] = 'syncE';
        return mapping;
    }
}
