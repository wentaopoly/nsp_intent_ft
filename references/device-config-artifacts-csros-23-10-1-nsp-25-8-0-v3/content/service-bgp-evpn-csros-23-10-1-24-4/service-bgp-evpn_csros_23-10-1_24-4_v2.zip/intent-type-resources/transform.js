load({ script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil' });
load({ script: resourceProvider.getResource("nfmpSuggest.js"), name: "NfmpSuggest" });
function transformData() {
    const nfmpSuggest = new NfmpSuggest();
    const ipv6AddressUtil = new IPv6AddressUtil();
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit, supportDelReq) {
       payload = ipv6AddressUtil.expandIPv6(payload);
       if (payload.configInfo["netw.NetworkElement"].hasOwnProperty("children-Set")) {
          let childrenSet = payload.configInfo["netw.NetworkElement"]["children-Set"];
          if(supportDelReq){
             if (childrenSet.hasOwnProperty("svr.BgpEvpnEthernetSegment")) {
                 childrenSet["svr.BgpEvpnEthernetSegment"].forEach(bgpEvpnEthernetSegment => {
                 if (!bgpEvpnEthernetSegment.ethSegPortIdPointer && !bgpEvpnEthernetSegment.ethSegLagIdPointer  && (!bgpEvpnEthernetSegment.ethSegPwPortId || (bgpEvpnEthernetSegment.ethSegPwPortId && bgpEvpnEthernetSegment.ethSegPwPortId==0))) {
                    bgpEvpnEthernetSegment["children-Set"] = bgpEvpnEthernetSegment["children-Set"] || {};
                    bgpEvpnEthernetSegment["children-Set"]["svr.BgpEvpnEthernetSegmentSTagCTagRange"] = [];
                    bgpEvpnEthernetSegment["children-Set"]["svr.BgpEvpnEthernetSegmentSTagRange"] = [];
                    bgpEvpnEthernetSegment["children-Set"]["svr.BgpEvpnEthernetSegmentQTagRange"] = [];
                }
             });
            }
          }
          if (childrenSet.hasOwnProperty("svr.BgpEvpnEthernetSegment")) {
             childrenSet["svr.BgpEvpnEthernetSegment"].forEach(bgpEvpnEthernetSegment => {
             if (bgpEvpnEthernetSegment.ethSegPortIdPointer) {
               let portIdPointer = nfmpSuggest.getPortData(neId, bgpEvpnEthernetSegment.ethSegPortIdPointer, "objectFullName");
               bgpEvpnEthernetSegment.ethSegPortIdPointer = portIdPointer;
                }else {
                   bgpEvpnEthernetSegment.ethSegPortIdPointer = '';
                }
             });
          }
          if (childrenSet["svr.SystemBgpEvpn"] && childrenSet["svr.SystemBgpEvpn"]["srlbReservedLabelBlock"]) {
             let labelBlockName = childrenSet["svr.SystemBgpEvpn"]["srlbReservedLabelBlock"]
             let rslbdata = nfmpSuggest.getRslbBlockData(neId, labelBlockName, "objectFullName");
              childrenSet["svr.SystemBgpEvpn"]["srlbReservedLabelBlock"] = rslbdata;
          }else{
              childrenSet["svr.SystemBgpEvpn"]["srlbReservedLabelBlock"] = '';
          }
          if (childrenSet.hasOwnProperty("svr.BgpEvpnEthernetSegment")) {
             childrenSet["svr.BgpEvpnEthernetSegment"].forEach(bgpEvpnEthernetSegment => {
                if (bgpEvpnEthernetSegment.ethSegLagIdPointer) {
                   let lagIdPointer = nfmpSuggest.getData(neId, bgpEvpnEthernetSegment.ethSegLagIdPointer, "lag.Interface","lagId","siteId");
                   bgpEvpnEthernetSegment.ethSegLagIdPointer = lagIdPointer;
                }
                else{
                   bgpEvpnEthernetSegment.ethSegLagIdPointer = '';
                }
             });
          }
          if (childrenSet.hasOwnProperty("svr.BgpEvpnEthernetSegment")) {
             childrenSet["svr.BgpEvpnEthernetSegment"].forEach(bgpEvpnEthernetSegment => {
                if (bgpEvpnEthernetSegment.ethSegSdpIdPointer) {
                   let sdpIdPointer = nfmpSuggest.getData(neId, bgpEvpnEthernetSegment.ethSegSdpIdPointer, "svt.Tunnel","pathId","fromNodeId");
                   bgpEvpnEthernetSegment.ethSegSdpIdPointer = sdpIdPointer;
                }
                else{
                   bgpEvpnEthernetSegment.ethSegSdpIdPointer = '';
                   if(supportDelReq){
                        bgpEvpnEthernetSegment["children-Set"] = bgpEvpnEthernetSegment["children-Set"] || {};
                        bgpEvpnEthernetSegment["children-Set"]["svr.BgpEvpnEthernetSegmentVcIdRange"] = [];
                   }

                }
             });
          }
          if (childrenSet.hasOwnProperty("svr.BgpEvpnEthernetSegment")) {
              childrenSet["svr.BgpEvpnEthernetSegment"].forEach(bgpEvpnEthernetSegment => {
                if (!bgpEvpnEthernetSegment.memberOperGroupName) {
                   bgpEvpnEthernetSegment.memberOperGroupName = '';
                }
              });
          }
          if (childrenSet.hasOwnProperty("svr.BgpEvpnEthernetSegment")) {
              childrenSet["svr.BgpEvpnEthernetSegment"].forEach(bgpEvpnEthernetSegment => {
                if (!bgpEvpnEthernetSegment.ethSegPwPortId) {
                   bgpEvpnEthernetSegment.ethSegPwPortId = 0;
                }
              });
          }
          if (childrenSet.hasOwnProperty("svr.BgpEvpnEthernetSegment")) {
              childrenSet["svr.BgpEvpnEthernetSegment"].forEach(bgpEvpnEthernetSegment => {
                if (!bgpEvpnEthernetSegment.vprnNextHopAddr) {
                   bgpEvpnEthernetSegment.vprnNextHopAddr = "0.0.0.0";
                    if(supportDelReq){
                        bgpEvpnEthernetSegment["children-Set"] = bgpEvpnEthernetSegment["children-Set"] || {};
                        bgpEvpnEthernetSegment["children-Set"]["svr.BgpEvpnEthernetSegmentL3NextHopEviRange"]=[];
                        bgpEvpnEthernetSegment["children-Set"]["svr.BgpEvpnEthernetSegmentL3NextHopEviRange"] = [];
                   }
                }
              });
          }
          if (childrenSet.hasOwnProperty("svr.BgpEvpnEthernetSegment")) {
              childrenSet["svr.BgpEvpnEthernetSegment"].forEach(bgpEvpnEthernetSegment => {
                if (!bgpEvpnEthernetSegment.ethSegVxlanInstanceId) {
                    bgpEvpnEthernetSegment.ethSegVxlanInstanceId = 0;
                    if(supportDelReq){
                        bgpEvpnEthernetSegment["children-Set"] = bgpEvpnEthernetSegment["children-Set"] || {};
                        bgpEvpnEthernetSegment["children-Set"]["svr.BgpEvpnEthernetSegmentServiceRange"] = [];
                   }
                }
              });
          }
          if (childrenSet.hasOwnProperty("svr.BgpEvpnEthernetSegment")) {
             childrenSet["svr.BgpEvpnEthernetSegment"].forEach(bgpEvpnEthernetSegment => {
                if (bgpEvpnEthernetSegment.ethSegSrcBMacLeastSignificantBit) {
                   let bmacLsfData = convertToNfmpFormat(bgpEvpnEthernetSegment.ethSegSrcBMacLeastSignificantBit)
                   bgpEvpnEthernetSegment.ethSegSrcBMacLeastSignificantBit = bmacLsfData;
                }
             });
          }
          if (childrenSet.hasOwnProperty("svr.BgpEvpnEthernetSegment")) {
             childrenSet["svr.BgpEvpnEthernetSegment"].forEach(bgpEvpnEthernetSegment => {
                if (bgpEvpnEthernetSegment.ethSegEsiValue) {
                   let ethSegEsidata = bgpEvpnEthernetSegment["ethSegEsiValue"].toLowerCase();
                   if (ethSegEsidata.indexOf('-') !== -1) {
                      ethSegEsidata = ethSegEsidata.replace('-', ':');
                   }
                   bgpEvpnEthernetSegment.ethSegEsiValue = ethSegEsidata;
                }
             });
          }
       }
       return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
       let neId= fullDeviceConfig["siteId"];
       if (xpath == "svr-BgpEvpnEthernetSegment.ethSegPortIdPointer") {
          let portName = nfmpSuggest.getPortDataForBF(neId, targetValue);
          if (portName) {
             targetValue = portName;
          }
       }else if(xpath == "svr-BgpEvpnEthernetSegment.ethSegLagIdPointer") {
         let lagData = nfmpSuggest.getDataForBF(neId, targetValue, "lag.Interface","lagId", "siteId");
          if (lagData) {
             targetValue = lagData;
          }
        }else if(xpath == "svr-BgpEvpnEthernetSegment.ethSegSdpIdPointer") {
          let sdpData = nfmpSuggest.getDataForBF(neId, targetValue, "svt.Tunnel", "pathId", "fromNodeId");
           if (sdpData) {
              targetValue = sdpData;
           }
        }else if(xpath == "svr-SystemBgpEvpn.srlbReservedLabelBlock") {
          let labelBlockData = nfmpSuggest.getDataForBF(neId, targetValue, "mpls.ReservedLabelBlock", "labelBlockName", "siteId");
           if (labelBlockData) {
              targetValue = labelBlockData;
           }
        }
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }

    function convertToNfmpFormat(bmacLsbValue) {
        if (typeof bmacLsbValue === 'string') {
            if (bmacLsbValue.indexOf(':') !== -1) return bmacLsbValue.replace(':', '-');
            if (bmacLsbValue.indexOf('-') !== -1) return bmacLsbValue;
       }
       if (!isNaN(bmacLsbValue) && bmacLsbValue!='0') {
           let hex = Number(bmacLsbValue).toString(16);
           hex = hex.length < 4 ? '0'.repeat(4 - hex.length) + hex : hex;
           return `${hex.slice(0, 2)}-${hex.slice(2)}`;
       }
       return bmacLsbValue;
   }
}