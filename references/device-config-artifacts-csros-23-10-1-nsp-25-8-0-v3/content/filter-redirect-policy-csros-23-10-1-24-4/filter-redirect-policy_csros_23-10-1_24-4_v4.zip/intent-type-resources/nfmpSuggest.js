function NfmpSuggest() {
    this.getDisplayedName = function (neId) {
        let className = "redirectfilter.RedirectPolicy";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObject, className, "displayedName")
    }
    this.getData = function (searchObjectJson, className, type) {
        let nfmpFwk = new NfmpFwk();
        let ret = [];
        let resultFetch = nfmpFwk.post("v3/search", searchObjectJson);
        logger.info(resultFetch.response);
        let finalResponse = JSON.parse(resultFetch.response);
        finalResponse = finalResponse[className];
        logger.info(JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse))
        {
            finalResponse = [finalResponse];
        }
        if (Object.keys(finalResponse).length !== 0)
        {
            finalResponse.forEach(function (value, index, array) {
                ret.push(value[type]);
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }
    this.getVprn = function(neId){
            let className = "vprn.Site";
            let searchObject = {
                "fullClassName": className,
                "filter": {
                    "equal": {
                        "name": "siteId",
                        "value": neId
                    }
                },
                "resultFilter": {
                    "children": "",
                    "attribute": [
                        "svcComponentId",
                        "serviceId",
                        "serviceName"
                    ]
                }
            };
            let nfmpFwk = new NfmpFwk();
            let result = {};
            let resultFetch = nfmpFwk.post("/v3/search", searchObject);
            let finalResponse = JSON.parse(resultFetch.response);
            finalResponse = finalResponse[className];
            if(!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            logger.info(JSON.stringify(finalResponse));
            let data = finalResponse.map(function (vprn) {
            var obj = {};
            obj["service-name"] = vprn["serviceName"];
            obj["service-id"] = vprn["serviceId"];
            obj["service-component-id"] = vprn["svcComponentId"];
            return obj;
        });
        result["data"] = JSON.stringify(data);
        return result;
    }
}