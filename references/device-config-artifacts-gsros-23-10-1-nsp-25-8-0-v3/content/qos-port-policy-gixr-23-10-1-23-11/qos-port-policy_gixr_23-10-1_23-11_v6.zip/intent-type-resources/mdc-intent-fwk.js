var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk'});
load({script: resourceProvider.getResource('traverse-fwk.js'), name: 'TraverseFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});

function MdcIntentFwk() {
  var intentDeviationObj = new IntentDeviceDeviation();

  this.restResponseHandler = function(exception, httpStatus, response) {
    logger.info(LOG_PREFIX + "[IntentMgr] REST response : " + response);
    logger.info(LOG_PREFIX + "[IntentMgr] REST httpStatus : " + httpStatus);
    if (exception) {
      throw new RuntimeException("Couldn't connect to device proxy for ; Response: "+response);
    }
    if (httpStatus !== 200 && httpStatus !== 201) {
      throw new RuntimeException("Failed to access device  using MDC; Response: "+response);
    }
    restResponse = JSON.parse(response);
  };

  this.cipherSpecialCharacterInKey = function (key) {
    return key.replaceAll("/", "%2F").replaceAll(":", "%3A");
  };

  this.synchronize = function(input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
    var traverseFwk = new TraverseFwk();
    var parseTarget = new ParseTarget();
    var target = parseTarget.getNeIdFromTarget(input.getTarget());

    // saved topology
    var savedTopology = input.getCurrentTopology();

    if(savedTopology == null) {
      savedTopology = topologyFactory.createServiceTopology();
    }
    if (input.getNetworkState().name() == "delete") {
      logger.info(JSON.stringify(savedTopology));
      traverseFwk.resetTheVariables();

      result = traverseFwk.deleteAllFromTopology(savedTopology,target,result);

      return result;
    }

    if(target !== "0.0.0.0") {
      var intentConfig;
      intentConfig  = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
      //workaround for decimal64 DataType
      intentConfig  = this.transformIntentConfig(intentConfig);
      var policyName = input.getTarget().split("#")[2];
      intentConfig['port-qos-policy-name'] = policyName;
     
      if (intentConfig) {

        intentConfig = intentDeviationObj.removeIntentConfig(intentConfig, target);

        savedTopology = traverseFwk.traverse(target,intentConfig,savedTopology,null,parentXpath,initialPropertyName);
        //sorting delete array
        var deleteRequests = traverseFwk.getDeleteRequests();
        deleteRequests.sort(function(a, b){
          return b["target"].length - a["target"].length;
        });

        //concating createrequests and deleterequests
        var createRequests = traverseFwk.getCreateRequests();
        var requests;
        if(deleteRequests && createRequests){
          requests = deleteRequests.concat(createRequests);
        }
        if ( requests ) {
          result = traverseFwk.syncRequest(target,requests,result,savedTopology);
        }
      }
      else{
        result = traverseFwk.deleteAllFromTopology(savedTopology,target,result);
      }
    }
    traverseFwk.resetTheVariables();
    return result;
  }

  this.audit = function(target, config, svcTopo, adminState, report, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
    var currentConfig;
    var traverseFwk = new TraverseFwk();
    var parseTarget = new ParseTarget();
    var targetNeId = parseTarget.getNeIdFromTarget(target);

    if(target !== "0.0.0.0") {

      currentConfig  = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
      //workaround for decimal64 DataType
      currentConfig  = this.transformIntentConfig(currentConfig);
      var policyName = target.split("#")[2];
      currentConfig['port-qos-policy-name'] = policyName;


      currentConfig = intentDeviationObj.removeIntentConfig(currentConfig, target);

      svcTopo = traverseFwk.traverse(targetNeId,currentConfig,svcTopo,report,parentXpath,initialPropertyName);
      // reseting the variables
      traverseFwk.resetTheVariables();
    }
    return report;
  }

  this.getNodes = function(context) {
    var returnVal = []
    var url = "/restconf/meta/api/v1/nes"
    try {
      var managerList = []
      var managers = mds.getAllManagersOfType("REST");
      managers.forEach(function (manager) {
        if (mds.getManagerByName(manager).getConnectivityState().toString() === 'CONNECTED') {
          managerList.push(manager)
        }
      })

      var devices = mds.getAllManagedDevicesFrom(managerList);

      devices.forEach(function (device) {
        returnVal.push(device.getName());
      });

      return returnVal;
    } catch (e) {
      logger.info("Exception *******************  : " + e);
      return {
        "Device Not Found": "Device Not Found"
      }
    }
  }

  this.xml2object = function(xmlElement) {
    var lXml = Java.type("org.json.XML");
    var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
    var serializer = lsImpl.createLSSerializer();
    serializer.getDomConfig().setParameter("xml-declaration", false);
    var str = serializer.writeToString(xmlElement);
    var json = lXml.toJSONObject(str).toString();
    logger.info(LOG_PREFIX + 'inp json: '+ json)
    return JSON.parse(json);
  }

  this.transformIntentConfig = function (intentConfig) {
    if(intentConfig["queue"] !== undefined && intentConfig["queue"] !== null) {
      if (!Array.isArray(intentConfig["queue"])) {
        intentConfig["queue"] = [intentConfig["queue"]];
      }
      var queues = [];
      for (var idx in intentConfig["queue"]) {
        var queueConfig = intentConfig["queue"][idx];
        if (queueConfig["queue-id"] != 7 || queueConfig["queue-id"] != 8) {
          if (queueConfig["low-latency"] !== undefined && queueConfig["low-latency"] !== null) {
            delete queueConfig["low-latency"];
          }
        }
        if (queueConfig["scheduler-mode"] !== undefined && queueConfig["scheduler-mode"] !== null) {
          if (queueConfig["scheduler-mode"]["wfq"] !== undefined && queueConfig["scheduler-mode"]["wfq"] !== null) {
            if (queueConfig["scheduler-mode"]["wfq"]["percent-rate"] !== undefined && queueConfig["scheduler-mode"]["wfq"]["percent-rate"] !== null) {
              if (queueConfig["scheduler-mode"]["wfq"]["percent-rate"]["pir"] !== undefined && queueConfig["scheduler-mode"]["wfq"]["percent-rate"]["pir"] !== null && queueConfig["scheduler-mode"]["wfq"]["percent-rate"]["pir"] !== "") {
                queueConfig["scheduler-mode"]["wfq"]["percent-rate"]["pir"] = parseFloat(queueConfig["scheduler-mode"]["wfq"]["percent-rate"]["pir"]);
              }
              if (queueConfig["scheduler-mode"]["wfq"]["percent-rate"]["cir"] !== undefined && queueConfig["scheduler-mode"]["wfq"]["percent-rate"]["cir"] !== null && queueConfig["scheduler-mode"]["wfq"]["percent-rate"]["cir"] !== "") {
                queueConfig["scheduler-mode"]["wfq"]["percent-rate"]["cir"] = parseFloat(queueConfig["scheduler-mode"]["wfq"]["percent-rate"]["cir"]);
              }
            }
          }
        }
        queues.push(queueConfig);
      }
      intentConfig["queue"] = queues;
    }
    return intentConfig;
  }
}
