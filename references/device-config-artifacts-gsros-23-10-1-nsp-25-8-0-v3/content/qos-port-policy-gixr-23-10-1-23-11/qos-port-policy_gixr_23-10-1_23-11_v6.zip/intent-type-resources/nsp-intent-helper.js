load({ script: resourceProvider.getResource("mdt-fwk.js"), name: "MdtFwk" });
load({ script: resourceProvider.getResource('mdc-intent-fwk.js'), name: 'MdcIntentFwk'})
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'})
load({ script: resourceProvider.getResource("nfmp-port-policy-fwk.js"), name: "NfmpPortPolicyFwk"})

function NspIntentHelper() {
  
  var mdtFwk = new MdtFwk();

  this.synchronize = function(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {

    logger.info(LOG_PREFIX + 'Nsp Intent Helper -> Synchronise');
    try {

      var result = synchronizeResultFactory.createSynchronizeResult();

      var instanceFwk = this.navigateInstance(input.getTarget());

      instanceFwk.synchronize(input, result,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier);

      return result
    }
    catch (e) {
      logger.info(LOG_PREFIX + 'Error Occured while Synchronising with error: ' + e)
      throw new RuntimeException('Error Executing Intent: ' + e)
    }
  }

  this.audit = function(target,
                        config,
                        svcTopo,
                        adminState,
                        intentTypeName,
                        parentXpath,
                        initialPropertyName,
                        uniqueIdentifier) {

    try {
      var instanceFwk = this.navigateInstance(target);
      logger.info(LOG_PREFIX + 'instanceFwk ' + instanceFwk);

      var report = auditFactory.createAuditReport(null, null);

      //Calling the audit of respective fwk
      instanceFwk.audit(target, config, svcTopo, adminState, report, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
      return report
    }
    catch (e) {
      logger.info(LOG_PREFIX + 'Error Occured while Auditing with error: ' + e)
      throw new RuntimeException('Error Executing Intent: ' + e)
    }
  }

  this.navigateInstance = function(target) {

    var managerName = mdtFwk.getManagerName(new ParseTarget().getNeIdFromTarget(target));
    logger.info(LOG_PREFIX + 'Device: ' + target + ' is managed by: ' + managerName);

    switch(managerName) {
      case 'NFM-P':
        logger.info(LOG_PREFIX + 'Device is managed by NFMP')
        return this.createNfmpInstance()
      case 'MDC':
        logger.info(LOG_PREFIX + 'Device is managed by MDM')
        return this.createMdcInstance()
      default:
        logger.info(LOG_PREFIX + 'Device is not managed')
        throw new RuntimeException('Device is not Managed')
    }
  }

  /**
   * Create NFMP Manager
   * @returns instance of NfmpExample
   */
  this.createNfmpInstance = function () {
    return new NfmpPortPolicyFwk();
  };

  /**
   * Create MDC Manager
   * @returns intance of MdcIntentFwk
   */
  this.createMdcInstance = function () {
    return new MdcIntentFwk();
  };
}
