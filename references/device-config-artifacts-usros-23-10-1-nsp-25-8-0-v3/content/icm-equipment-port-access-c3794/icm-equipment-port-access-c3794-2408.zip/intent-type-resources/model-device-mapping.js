function ModelDeviceMapping() {


    this.getMapping = function(type){
        switch(type){
            case "port":
                return this.getPortMapping();
            case "dataChannel":
                return this.getDataChannelMapping();
            case "dataChannelSpecifics":
                return this.getDataChannelSpecificsMapping();
            case "ds0Channel-group":
                return this.getDs0ChannelGroupMapping();
            case "ds0ChannelGroupSpecifics":
                return this.getDs0ChannelGroupSpecificsMapping();
            default:
                return this.getPortMapping();
        }
    }

    this.getPortMapping = function() {
        var mapping = {};
        mapping['port.admin-state'] = 'administrativeState';
        mapping['port.description'] = 'description';

        return mapping;
    }

    this.getDataChannelMapping = function() {
        var mapping = {};
        mapping['port.dataChannel.admin-state'] = 'administrativeState';

        return mapping;
    }

    this.getDataChannelSpecificsMapping = function() {
        var mapping = {};
        mapping['port.dataChannel.framing'] = 'dataFraming';

        return mapping;
    }

    this.getDs0ChannelGroupMapping = function() {
        var mapping = {};
        mapping['port.dataChannel.ds0Channel-group.channel-group-id'] = 'displayedLocalChannelId';
        mapping['port.dataChannel.ds0Channel-group.admin-state'] = 'administrativeState';

        return mapping;
    }

    this.getDs0ChannelGroupSpecificsMapping = function() {
        var mapping = {};
        mapping['port.dataChannel.ds0Channel-group.timeslots'] = 'timeSlotBits';

        return mapping;
    }
}
