var RuntimeException = Java.type('java.lang.RuntimeException');

load({
    script: resourceProvider.getResource('mdc-fwk.js'),
    name: 'MdcFwk'
});
load({
    script: resourceProvider.getResource('parse-target.js'),
    name: 'ParseTarget'
});
load({
    script: resourceProvider.getResource("util-fwk.js"),
    name: "utilities"
});

function MdcDiscoveryHelper() {
    let mdcFwk = new MdcFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function (targetWithTemplate, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(targetWithTemplate);
        let filterName = util.getIpFilterName(targetWithTemplate);
        let filterId = util.getIpFilterId(targetWithTemplate);
        let url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/filter/" + initialPropertyName + "=" + filterName;
        let getResult = mdcFwk.fetch(neId, url);
        let configFromDevice = getResult.msg["nokia-conf:" + initialPropertyName];
        if (configFromDevice == undefined) {
            throw new RuntimeException("cannot get configuration from device");
        }
        if (Array.isArray(configFromDevice)) {
            let lFilterId = configFromDevice[0]['filter-id'];
            if (lFilterId) {
                if (parseInt(lFilterId) !== parseInt(filterId)) throw "There is no ip-filter with Name:" + filterName + " and Id:" + filterId;
                return configFromDevice[0];
            } else throw "There is no ip-filter with Name:" + filterName + " and Id:" + filterId;

        } else {
            throw "cannot get configuration from device"
        }
    }

    this.extractDeviceConfig = function (targetData, deviceConfig, initialPropertyName) {
        let parsedTargetData = JSON.parse(targetData);
        let config = parsedTargetData[initialPropertyName];
        let mergedTargetData = this.traverse(config, deviceConfig);

        parsedTargetData[initialPropertyName] = mergedTargetData;

        if (parsedTargetData["ip-filter"]) {
            let ipFilterEntries = parsedTargetData["ip-filter"]["entry"];
            if (ipFilterEntries) {
                let ipFilterentyObjects = []
                for (let i = 0; i < ipFilterEntries.length; i++) {
                    let entryObj = ipFilterEntries[i];
                    if (entryObj["match"]) {

                        if (entryObj["match"]["ip"]) {
                            if (entryObj["match"]["ip"]["address"] || entryObj["match"]["ip"]["mask"]){
                                entryObj["match"]["ip"]["match-address-choice"] = "address-and-prefix-or-mask";
                            } else if (entryObj["match"]["ip"]["ip-prefix-list"]){
                                entryObj["match"]["ip"]["match-address-choice"] = "ip-prefix-list";
                            }
                        } else {
                            if (entryObj["match"]["src-ip"]) {
                                if (entryObj["match"]["src-ip"]["address"] || entryObj["match"]["src-ip"]["mask"]){
                                    entryObj["match"]["src-ip"]["match-address-choice"] = "address-and-prefix-or-mask";
                                } else if (entryObj["match"]["src-ip"]["ip-prefix-list"]){
                                    entryObj["match"]["src-ip"]["match-address-choice"] = "ip-prefix-list";
                                }
                            }
                            if (entryObj["match"]["dst-ip"]) {
                                if (entryObj["match"]["dst-ip"]["address"] || entryObj["match"]["dst-ip"]["mask"]){
                                    entryObj["match"]["dst-ip"]["match-address-choice"] = "address-and-prefix-or-mask";
                                } else if (entryObj["match"]["dst-ip"]["ip-prefix-list"]){
                                    entryObj["match"]["dst-ip"]["match-address-choice"] = "ip-prefix-list";
                                }
                            }
                        }

                        if (entryObj["match"]["port"]) {
                            if (entryObj["match"]["port"]["range"]) {
                                entryObj["match"]["port"]["port"] = "range";
                            } else if (entryObj["match"]["port"]["port-list"]) {
                                entryObj["match"]["port"]["port"] = "port-list";
                            } else if (entryObj["match"]["port"]["gt"]) {
                                entryObj["match"]["port"]["port"] = "gt";
                            }else if (entryObj["match"]["port"]["lt"]) {
                                entryObj["match"]["port"]["port"] = "lt";
                            }else {
                                entryObj["match"]["port"]["port"] = "eq";
                            }
                        } else {
                            if (entryObj["match"]["src-port"]) {
                                if (entryObj["match"]["src-port"]["range"]) {
                                    entryObj["match"]["src-port"]["port"] = "range";
                                } else if (entryObj["match"]["src-port"]["port-list"]) {
                                    entryObj["match"]["src-port"]["port"] = "port-list";
                                } else if (entryObj["match"]["src-port"]["gt"]) {
                                    entryObj["match"]["src-port"]["port"] = "gt";
                                }else if (entryObj["match"]["src-port"]["lt"]) {
                                    entryObj["match"]["src-port"]["port"] = "lt";
                                }else {
                                    entryObj["match"]["src-port"]["port"] = "eq";
                                }
                            }
                            if (entryObj["match"]["dst-port"]) {
                                if (entryObj["match"]["dst-port"]["range"]) {
                                    entryObj["match"]["dst-port"]["port"] = "range";
                                } else if (entryObj["match"]["dst-port"]["port-list"]) {
                                    entryObj["match"]["dst-port"]["port"] = "port-list";
                                } else if (entryObj["match"]["dst-port"]["gt"]) {
                                    entryObj["match"]["dst-port"]["port"] = "gt";
                                }else if (entryObj["match"]["dst-port"]["lt"]) {
                                    entryObj["match"]["dst-port"]["port"] = "lt";
                                }else {
                                    entryObj["match"]["dst-port"]["port"] = "eq";
                                }
                            }
                        }
                    }
                    ipFilterentyObjects.push(entryObj);
                }
                parsedTargetData["ip-filter"]["entry"] = ipFilterentyObjects;
            }
        }
        return parsedTargetData;
    }


    this.traverse = function (targetData, deviceConfig) {
        if (targetData !== null && targetData !== undefined) {
            let keys = Object.keys(targetData);
            for (let i = 0; i < keys.length; i++) {
                let propertyName = keys[i];
                let deviceValue = deviceConfig[propertyName];

                if (deviceValue != undefined && Array.isArray(deviceValue)) {
                    targetData[propertyName] = this.ArrayTraverse(targetData[propertyName], deviceValue, []);
                } else if (deviceValue != undefined && typeof deviceValue === 'object') {
                    targetData[propertyName] = this.containerTraverse(targetData[propertyName], deviceValue, {});
                } else {
                    targetData[propertyName] = deviceValue
                }
            }

        }
        return targetData;
    }

    this.ArrayTraverse = function (arrayTargetData, arrayDeviceConfigData, arrayData) {
        for (let i = 0; i < arrayDeviceConfigData.length; i++) {
            let arrayObject = {};
            let keys = Object.keys(arrayTargetData[0]);
            for (let j = 0; j < keys.length; j++) {
                let propertyName = keys[j];
                let deviceValue = arrayDeviceConfigData[i][propertyName];
                if (deviceValue != null && deviceValue != undefined && Array.isArray(deviceValue)) {
                    arrayObject[propertyName] = this.ArrayTraverse(arrayTargetData[0][propertyName], deviceValue, []);
                } else if (deviceValue != null && deviceValue != undefined && typeof deviceValue === 'object') {
                    arrayObject[propertyName] = this.containerTraverse(arrayTargetData[0][propertyName], deviceValue, {});

                } else {
                    arrayObject[propertyName] = deviceValue
                }
            }
            arrayData.push(arrayObject);
        }

        return arrayData;
    }

    this.containerTraverse = function (containerTargetData, containerDeviceConfigData, targetContainer) {
        let keys = Object.keys(containerTargetData);
        for (let i = 0; i < keys.length; i++) {
            let propertyName = keys[i];
            let deviceValue = containerDeviceConfigData[propertyName];
            if (deviceValue != null && deviceValue != undefined && Array.isArray(deviceValue)) {
                if (this.isAtrributeLeafList(deviceValue)) {
                    targetContainer[propertyName] = deviceValue;
                } else {
                    targetContainer[propertyName] = this.ArrayTraverse(containerTargetData[propertyName], deviceValue, []);
                }

            } else if (deviceValue != null && deviceValue != undefined && typeof deviceValue === 'object') {
                targetContainer[propertyName] = this.containerTraverse(containerTargetData[propertyName], deviceValue, {});
            } else {
                targetContainer[propertyName] = deviceValue
            }
        }
        return targetContainer;
    }

    this.isAtrributeLeafList = function (leaflistData) {
        let isLeaflist = true;
        for (let i = 0; i < leaflistData.length; i++) {

            if (leaflistData[i] != null && typeof leaflistData[i] == 'object') {
                isLeaflist = false;
                break;
            }
        }
        return isLeaflist;
    }

    this.cipherSpecialCharacterInKey = function (key) {
        return key.replaceAll("/", "%2F").replaceAll(":", "%3A");
    }
}
