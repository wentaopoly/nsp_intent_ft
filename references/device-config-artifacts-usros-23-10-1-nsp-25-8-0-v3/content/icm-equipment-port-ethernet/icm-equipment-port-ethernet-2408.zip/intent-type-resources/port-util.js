function PortUtil(){


    this.isEsatPort = function(portNumber){
        var isEsatPortfalg =  portNumber.startsWith('esat');
        return isEsatPortfalg;
    }

    this.isXiomPort = function(portNumber){

        var portInfo = portNumber.split('/');

        if(portInfo.length == 3 || this.isEsatPort(portNumber)){
            return false;
        }

        logger.info("Port Info : " + portInfo)
        var isContainsX = portInfo[1].startsWith('x');
        var isContainsC = portInfo[3].startsWith('c');

        if(portInfo.length == 5 && isContainsX && isContainsC){
            logger.info("Port is XIOM Port : " + portNumber)
            return true;
        }

        return false;
    }

    this.isXiomConnector = function(portNumber){

        var portInfo = portNumber.split('/');

        if(portInfo.length == 3 || this.isEsatPort(portNumber)){
            return false;
        }

        logger.info("Port Info : " + portInfo)
        var isContainsX = portInfo[1].startsWith('x');
        var isContainsC = portInfo[3].startsWith('c');

        if(portInfo.length == 4 && isContainsX && isContainsC){
            logger.info("Port is XIOM Connector : " + portNumber)
            return true;
        }

        return false;
    }

    this.isBreakoutPort = function(portNumber){

        var portInfo = portNumber.split('/');

        if(portInfo.length == 3 || this.isEsatPort(portNumber)){
            return false;
        }

        logger.info("Port Info : " + portInfo)
        var isContainsC = portInfo[2].startsWith('c');

        if(portInfo.length == 4 &&  isContainsC){
            logger.info("Port is Breakout Port : " + portNumber)
            return true;
        }

        return false;
    }

    this.isConnector = function(portNumber){

        var portInfo = portNumber.split('/');

        if(portInfo.length == 3 || this.isEsatPort(portNumber)){
            return false;
        }

        logger.info("Port Info : " + portInfo)
        var isContainsC = portInfo[2].startsWith('c');

        if(portInfo.length == 3 &&  isContainsC){
            logger.info("Port is Connector : " + portNumber)
            return true;
        }

        return false;
    }
}
