load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        if (!isAudit){
            if( payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.DynamicPolicer"]){
                payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.DynamicPolicer"]["policyId"] = payload["configInfo"]["aengr.Policy"]["id"];
            }
            if(!payload["configInfo"]["aengr.Policy"]["postPolicerMappingPolicy"]){
                payload["configInfo"]["aengr.Policy"]["postPolicerMappingPolicy"] = '';
            }
            if(!payload["configInfo"]["aengr.Policy"]["hsAttachmentPolicy"]){
                payload["configInfo"]["aengr.Policy"]["hsAttachmentPolicy"] = "HsAttachmentPolicy:hsAtt-default";
            }
            if(payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.DynamicPolicer"] && !payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.DynamicPolicer"]["parentArbiterName"]){
                payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.DynamicPolicer"]["parentArbiterName"] = '';
            }
            if (payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.Policer"]) {
                for (var index in payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.Policer"]) {
                    var policerConfig = payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.Policer"][index];


                    if (!policerConfig["parentArbiterName"]) {
                        policerConfig["parentArbiterName"] = '';
                    }
                    if (!policerConfig["scheduler"]) {
                        policerConfig["scheduler"] = '';
                    }
                    if (!policerConfig["advancedConfigPolicyPointer"]) {
                        policerConfig["advancedConfigPolicyPointer"] = '';
                    }

                    payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.Policer"][index] = policerConfig;
                }
            }
            if (payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.Queue"]) {
                for (var index in payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.Queue"]) {
                    var queueConfig = payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.Queue"][index];

                    if (!queueConfig["advancedConfigPolicyPointer"]) {
                        queueConfig["advancedConfigPolicyPointer"] = '';
                    }
                    if (!queueConfig["hsWredQueueSlopePlcyPointer"]) {
                        queueConfig["hsWredQueueSlopePlcyPointer"] = 'Slope:_tmnx_hs_default';
                    }

                    payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.Queue"][index] = queueConfig;
                }
            }
            if (payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.IpMatch"]) {

                for (var index in payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.IpMatch"]) {

                    var ipMatchConfig = payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.IpMatch"][index];

                    if (ipMatchConfig["sourceIpAddressMask"] && ipMatchConfig["sourceIpAddressFullMask"]) {
                        delete ipMatchConfig["sourceIpAddressFullMask"];
                    }
                    if (ipMatchConfig["destinationIpAddressMask"] && ipMatchConfig["destinationIpAddressFullMask"]) {
                        delete ipMatchConfig["destinationIpAddressFullMask"];
                    }
                    payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.IpMatch"][index] = ipMatchConfig;

                }

            }

            if (payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.ForwardingClass"]) {

                for (var index in payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.ForwardingClass"]) {

                    var fcConfig = payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.ForwardingClass"][index];
                    if (fcConfig["queueGroup"] == 'N/A') { delete fcConfig["queueGroup"]; }
                    payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.ForwardingClass"][index] = fcConfig;

                }
            }

            if (payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.Ipv6Match"]) {
                for (var index in payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.Ipv6Match"]) {
                    var ipv6MatchConfig = payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.Ipv6Match"][index];

                    if (!ipv6MatchConfig["dstIpPrefixListPointer"]) {
                        ipv6MatchConfig["dstIpPrefixListPointer"] = '';
                    }
                    if (!ipv6MatchConfig["srcIpPrefixListPointer"]) {
                        ipv6MatchConfig["srcIpPrefixListPointer"] = '';
                    }

                    payload["configInfo"]["aengr.Policy"]["children-Set"]["aengr.Ipv6Match"][index] = ipv6MatchConfig;
                }
            }

        }

        var ipv6AddressUtil = new IPv6AddressUtil();
        payload = ipv6AddressUtil.expandIPv6(payload);
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        if(xpath == "aengr-Dot1p.forwardingClass" && targetValue == "default")
        {
            targetValue = "";
        }
        if(xpath == "postPolicerMappingPolicy")
        {
            targetValue = 'postPolicerMapping:'+ targetValue;
        }
        if(xpath == "hsAttachmentPolicy")
        {
            targetValue = 'HsAttachmentPolicy:hsAtt-'+ targetValue;
        }
        if(xpath == "egrHsmdaWrrPlcy")
        {
            targetValue = 'HsmdaWrrPolicy:'+ targetValue;
        }
        if(xpath == "aengr-IpMatch.dstIpPrefixListPointer")
        {
            targetValue = 'qosPrefixList:' + targetValue + '#type-IPv4';
        }
        if(xpath == "aengr-IpMatch.srcIpPrefixListPointer")
        {
            targetValue = 'qosPrefixList:' + targetValue + '#type-IPv4';
        }
        if(xpath == "aengr-Ipv6Match.dstIpPrefixListPointer")
        {
            targetValue = 'qosPrefixList:' + targetValue + '#type-IPv6';
        }
        if(xpath == "aengr-Ipv6Match.srcIpPrefixListPointer")
        {
            targetValue = 'qosPrefixList:' + targetValue + '#type-IPv6';
        }
        if(xpath == "aengr-HsmdaQueue.slopePolicyPointer")
        {
            targetValue = 'HSMDA Slope:'+ targetValue;
        }
        if(xpath == "aengr-Queue.slopePolicyPointer")
        {
            targetValue = 'Slope:'+ targetValue;
        }
        if(xpath == "aengr-Queue.hsWredQueueSlopePlcyPointer")
        {
            targetValue = 'Slope:'+ targetValue;
        }
        if(xpath == "aengr-Queue.wredQueueSlopePolicyPointer")
        {
            targetValue = 'Slope:'+ targetValue;
        }
        if(xpath == "aengr-Policer.advancedConfigPolicyPointer")
        {
            targetValue = 'advancedConfigPolicy:'+ targetValue;
        }
        if(xpath == "aengr-Queue.advancedConfigPolicyPointer")
        {
            targetValue = 'advancedConfigPolicy:'+ targetValue;
        }
        if(xpath == "aengr-Queue.cirPercent" ||
            xpath == "aengr-Queue.pirPercent" ||
            xpath == "aengr-Queue.portAvgOverhead" ||
            xpath == "aengr-HsWrrGroup.pirPercentRate" ||
            xpath == "aengr-Policer.cirPercent" ||
            xpath == "aengr-Policer.pirPercent")
        {
            if(targetValue && !isNaN(targetValue) && !targetValue.contains("."))
            {
                targetValue = Number(targetValue);
                targetValue = targetValue.toFixed(1);
            }
        }

        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey) {
        if(xpath == "aengr-Dot1p.forwardingClass" && targetValue == "")
        {
            targetValue = "default";
        }
        if(xpath == "postPolicerMappingPolicy")
        {
            targetValue = targetValue.replace('postPolicerMapping:', '');
        }
        if(xpath == "hsAttachmentPolicy")
        {
            targetValue = targetValue.replace('HsAttachmentPolicy:hsAtt-', '');
        }
        if(xpath == "egrHsmdaWrrPlcy")
        {
            targetValue = targetValue.replace('HsmdaWrrPolicy:', '');
        }
        if(xpath == "aengr-IpMatch.dstIpPrefixListPointer")
        {
            targetValue = (targetValue.replace('qosPrefixList:', '')).replace("#type-IPv4", "");
        }
        if(xpath == "aengr-IpMatch.srcIpPrefixListPointer")
        {
            targetValue = (targetValue.replace('qosPrefixList:', '')).replace("#type-IPv4", "");
        }
        if(xpath == "aengr-Ipv6Match.dstIpPrefixListPointer")
        {
            targetValue = (targetValue.replace('qosPrefixList:', '')).replace("#type-IPv6", "");
        }
        if(xpath == "aengr-Ipv6Match.srcIpPrefixListPointer")
        {
            targetValue = (targetValue.replace('qosPrefixList:', '')).replace("#type-IPv6", "");
        }
        if(xpath == "aengr-HsmdaQueue.slopePolicyPointer")
        {
            targetValue = targetValue.replace('HSMDA Slope:', '');
        }
        if(xpath == "aengr-Queue.slopePolicyPointer")
        {
            targetValue = targetValue.replace('Slope:', '');
        }
        if(xpath == "aengr-Queue.hsWredQueueSlopePlcyPointer")
        {
            targetValue = targetValue.replace('Slope:', '');
        }
        if(xpath == "aengr-Queue.wredQueueSlopePolicyPointer")
        {
            targetValue = targetValue.replace('Slope:', '');
        }
        if(xpath == "aengr-Policer.advancedConfigPolicyPointer")
        {
            targetValue = targetValue.replace('advancedConfigPolicy:', '');
        }
        if(xpath == "aengr-Queue.advancedConfigPolicyPointer")
        {
            targetValue = targetValue.replace('advancedConfigPolicy:', '');
        }

        return targetValue;
    }

    this.transformLocalObjectFullNameDistribute = function(localObjectFullName,
        intentConfig,
        payload,
        neId) {
        return localObjectFullName;
    }
}