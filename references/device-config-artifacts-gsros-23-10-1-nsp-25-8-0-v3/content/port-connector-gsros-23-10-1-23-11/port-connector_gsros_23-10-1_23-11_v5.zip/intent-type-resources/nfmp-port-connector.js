var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpPort() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    let nfmpFwk = new NfmpFwk();
    var isAudit = false;

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        // setting up topology
        var savedTopology = input.getCurrentTopology();
        var parseTarget = new ParseTarget();
        isAudit = false;
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target port = " + intentConfig[uniqueIdentifier]);
        if (input.getNetworkState().name() == "delete")
        {
            return this.syncDelete(target,intentConfig[uniqueIdentifier],result);
        }
        this.createOrModify(target, intentConfig[uniqueIdentifier], intentConfig);
        return util.setSuccessResult(result, savedTopology);
    }


    this.audit = function (target, config, svcTopo, adminState, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        var savedTopology = svcTopo;
        var parseTarget = new ParseTarget();
        isAudit = true;
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        var target = parseTarget.getNeIdFromTarget(target);
        intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target port = " + intentConfig[uniqueIdentifier]);
        if (intentConfig)
        {
            this.auditAndCompare(target, intentConfig[uniqueIdentifier], intentConfig, auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }

    }


    this.createOrModify = function (target, portId, intentConfig) {

        // connector port level attributes
        var connectorPortLevelPayload = this.connectorPortLevel(target, portId, intentConfig);

        var result = this.modifyRequest(target, connectorPortLevelPayload);

        return result;

    }

    this.auditAndCompare = function (target, portId, intentConfig, auditReport) {

        // connector port level attributes
        var connectorPortLevelPayload = this.connectorPortLevel(target, portId, intentConfig);

        var result = this.auditRequest(target, connectorPortLevelPayload);
        // adding miss aligned attributes
        var auditReport = util.reportMisaligned(target, result, auditReport);

        return auditReport;
    }

    this.connectorPortLevel = function (target, portId, intentConfig) {

        var properties = {};

        // full class name for connector port
        var fullClassName = "equipment.Connector";
        var connectorPortLevelFdn = util.getBaseFdnForPort(target, portId);
        // objectFullName is same as fdn for connector port level
        var objectFullName = connectorPortLevelFdn;
        var intentBreakoutType = util.transformNfmpBreakoutType(intentConfig["connector"]["breakout"]);
        var intentRsFecMode = util.transformNfmpRsFecMode(intentConfig["connector"]["rs-fec-mode"]);

        // adminstate
        (intentConfig["admin-state"] == "enable") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";

        if (isAudit == false){
            var searchPayLoad = this.constructSearchString(target, portId);
            var searchResponse = nfmpFwk.find(target, searchPayLoad);
            if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
            {
                if(!(searchResponse.success))
                    throw new RuntimeException("Failed to get Port info from nfm-p for Ne " + target + " and Port Id: " + portId);
                if(JSON.parse(searchResponse["response"]).length === 0)
                    throw new RuntimeException("There is no port with Port Id:"+portId);
            }
            searchResponse = JSON.parse(searchResponse["response"]);

            var nfmpAdminState = searchResponse[0]["properties"]["administrativeState"]
            if( nfmpAdminState == "portOutOfService" && intentConfig["admin-state"] == "enable"){
                var adminStateEnablePaylod = util.editPayload(connectorPortLevelFdn,properties,fullClassName,objectFullName);
                var result = this.modifyRequest(target, adminStateEnablePaylod);
                properties = {};
            }
            var nfmpBreakoutType = searchResponse[0]["properties"]["portConnectorBreakoutType"]

            if( nfmpBreakoutType != "none" && nfmpBreakoutType != intentBreakoutType ){
                var property = {};
                property["portConnectorBreakoutType"] = "none";
                var connBreakoutNonePayload = util.editPayload(connectorPortLevelFdn,property,fullClassName,objectFullName);
                var result = this.modifyRequest(target, connBreakoutNonePayload);
            }
        }
        properties["portConnectorBreakoutType"] = intentBreakoutType;
        properties["portConnectorRsFecMode"] = intentRsFecMode;

        var connectorPortLevelPayload = util.editPayload(connectorPortLevelFdn, properties, fullClassName, objectFullName);
        return connectorPortLevelPayload;
    }

    this.constructSearchString = function(neId, portId) {
        var connPortFullName =  util.getBaseFdnForPort(neId, portId);
        var filterExpression = "siteId='" + neId + "' AND fullName='" + connPortFullName + "'";
        var jsonPayLoad = {
            "fullClassName": "equipment.Connector",
            "filter": {
                "filterExpression": filterExpression
            }
        };

        return jsonPayLoad;
    }

    this.auditRequest = function (target, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;

    }

    this.modifyRequest = function (target, payload) {
        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;

    }

    this.syncDelete = function (target,portId, result) {
        //Setting Connector Breakout Type to "None" when removing the connector intent
        var fullClassName = "equipment.Connector";
        var connectorPortLevelFdn = util.getBaseFdnForPort(target, portId);
        var objectFullName = connectorPortLevelFdn;

        var property = {};
        property["portConnectorBreakoutType"] = "none";
        var connBreakoutNonePayload = util.editPayload(connectorPortLevelFdn,property,fullClassName,objectFullName);
        this.modifyRequest(target, connBreakoutNonePayload);

        return result.setSuccess(true);
    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }

    this.removeEmptyContainers = function (prop, intentJson, path, target) {

        if (Array.isArray(intentJson))
        {
            var object = [];
            for (var prop in intentJson)
            {
                var value = this.removeEmptyContainers(prop, intentJson[prop], path, target);
                if (value)
                {
                    object.push(value);
                }

            }
            if (Object.keys(object).length !== 0)
            {
                return object;
            }
        }
        else if (typeof intentJson == 'object')
        {
            var object = {};
            for (var prop in intentJson)
            {
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop, intentJson[prop], pPath, target);
                if ((value && value !== null) || value == 0)
                {
                    object[prop] = value;
                }

            }
            if (Object.keys(object).length !== 0)
            {
                return object;
            }
        }
        else
        {
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if (intentJson !== undefined && intentJson !== "")
            {
                return intentJson;
            }

            return null;
        }
    }
}
