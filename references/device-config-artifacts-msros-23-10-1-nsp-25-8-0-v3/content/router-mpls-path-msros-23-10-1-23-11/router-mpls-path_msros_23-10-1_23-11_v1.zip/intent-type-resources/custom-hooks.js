load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
load({script: resourceProvider.getResource("parse-target.js"), name: "ParseTarget"});
function CustomHooks() {
var ipv6AddressUtil = new IPv6AddressUtil();
var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,5}(:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){6}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(\/(0|[1-9][0-9]?|1[0-1][0-9]?|12[0-8]))?$/;


    /**
   * PreAudit Hook
   */
  const preAudit = (inputObj) => {
     /**
     * Write your custom preAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer, 
     *          uniqueIdentifier, deviceYangModuleName
     *           
     */
    logger.info("[CUSTOM-HOOKS] preAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
    var target = inputObj["target"];
    var intentConfig = inputObj["intentConfig"];
    var neId = parseTarget.getNeIdFromTarget(target);
    intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
    logger.info("preAudit intent config after removing deviation attributes: " + JSON.stringify(intentConfig));
    inputObj["intentConfig"] = intentConfig;

    if(inputObj["intentConfig"] && inputObj["intentConfig"]["hop"]) {
                for(let i=0;i< inputObj["intentConfig"]["hop"].length; i++) {
                    if(inputObj["intentConfig"]["hop"][i] && inputObj["intentConfig"]["hop"][i]["ip-address"]) {
                        let ip = inputObj["intentConfig"]["hop"][i]["ip-address"];
                        if (ip && String(ip).indexOf(':') !== -1) {
                            inputObj["intentConfig"]["hop"][i]["ip-address"] = ipv6AddressUtil.expandIPv6Address(inputObj["intentConfig"]["hop"][i]["ip-address"]);
                            inputObj["intentConfig"]["hop"][i]["ip-address"] = ipv6AddressUtil.MdIpv6ValidAddresssMaskSupport(inputObj["intentConfig"]["hop"][i]["ip-address"]);
                        }
                    }
                }
    }
   return inputObj;
  };

  /**
   * PostAudit Hook
   */
  const postAudit = (inputObj) => {
    /**
     * Write your custom postAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer, 
     *          uniqueIdentifier, deviceYangModuleName, auditReport
     *           
     */

    logger.info("[CUSTOM-HOOKS] postAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

    
  };

  /**
   * PreSync Hook
   */
   const preSync = (inputObj) => {
        /**
         * Write your custom preSync logic here
         * inputObj by default contains the following keys:
         *          target, config, intentTypeName, rootXPath,
         *          intentContainer, uniqueIdentifier, deviceYangModuleName
         *          topology, state, syncResult
         */
        logger.info("[CUSTOM-HOOKS] preSync call");
        var config = JSON.parse(inputObj["config"]);
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
        var target = inputObj["target"];
        config = this.removeEmptyContainers("", config, "", target);
        config = this.expandIPv6(config);
        inputObj["config"] = JSON.stringify(config);
        return inputObj;
   };

  /**
   * PostSync Hook
   */
  const postSync = (inputObj) => {
    /**
     * Write your custom postSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] postSync call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
    
  };

  /**
   * 
   * PostDiscovery Hook
   */
  const postDiscovery = (inputObj) => {
    /**
     * Write your custom postDiscovery logic here
     * inputObj by default contains the following keys:
     *        deviceConfig, intentContainer, neId,
     *        targetDataStruct, templateName, deviceYangModuleName
     */

    logger.info("[CUSTOM-HOOKS] postDiscovery call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

  }

  this.removeEmptyContainers= function(prop,intentJson,path,target){

          if(Array.isArray(intentJson)){
              var object = [];
              for(var prop in intentJson){
                  var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                  if(value){
                      object.push(value);
                  }

              }
              if(Object.keys(object).length !== 0){
                  return object;
              }
          }else if( typeof intentJson == 'object' ){
              var object = {};
              for(var prop in intentJson){
                  var pPath = path + "/" + prop;
                  var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                  if((value && value!==null) || value == 0 ){
                      object[prop] = value;
                  }

              }
              if(Object.keys(object).length !== 0){
                  return object;
              }
          }else{
              if(intentJson!==undefined && intentJson!==""){
                  return intentJson;
              }

              return null;
          }
  }

    this.expandIPv6 = function (obj) {
          for (var key in obj) {
              if (typeof obj[key] === 'object' && obj[key] !== null) {
                  this.expandIPv6(obj[key]);
              } else if (typeof obj[key] === 'string' && this.matchExact(ipv6Regex, obj[key])) {
                  obj[key] = this.expandIPv6AddressForMd(obj[key]);
          }
        }
        return obj
      }
      this.matchExact = function(r, str) {
         var match = str.match(r);
         return match && str === match[0];
      }

      this.expandIPv6AddressForMd = function (input) {
         var expanded = ipv6AddressUtil.expandIPv6Address(input);
         expanded = ipv6AddressUtil.MdIpv6ValidAddresssMaskSupport(expanded);
         return expanded;
      };

  this.preAudit = preAudit;
  this.postAudit = postAudit;
  this.preSync = preSync;
  this.postSync = postSync;
  this.postDiscovery = postDiscovery;

}