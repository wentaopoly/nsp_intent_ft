var RuntimeException = Java.type('java.lang.RuntimeException');

load({
    script: resourceProvider.getResource('mdc-fwk.js'),
    name: 'MdcFwk'
});
load({
    script: resourceProvider.getResource('parse-target.js'),
    name: 'ParseTarget'
});


function MdcDiscoveryHelper() {
    let mdcFwk = new MdcFwk();
    let parseTarget = new ParseTarget();
    let neId = undefined;
    let groupName = undefined;

    this.getDeviceConfiguration = function (targetWithTemplate, initialPropertyName) {

        neId = parseTarget.getNeIdFromTarget(targetWithTemplate);
        groupName = parseTarget.getUniqueIdentifier(targetWithTemplate);
        let url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base/bgp/" + initialPropertyName +"="+groupName;
        let getResult = mdcFwk.fetch(neId, url);
        let configFromDevice = getResult.msg["nokia-conf:" + initialPropertyName];
        if (configFromDevice == undefined) {
            throw new RuntimeException("cannot get configuration from device");
        }

        return configFromDevice;
    }

    this.extractDeviceConfig = function (targetData, deviceConfig, initialPropertyName) {

        let url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:configure/router=Base/bgp";
        let getResult = mdcFwk.fetch(neId, url);

        let configFromDevice = getResult.msg["nokia-conf:bgp"];

        if (configFromDevice == undefined ||
            ( configFromDevice['group'] == undefined && configFromDevice['neighbor'] == undefined)) {
            throw new RuntimeException("cannot get configuration from device");
        }

        let bgpConfig = {};

        bgpConfig['group'] = {};
        if (!Array.isArray(configFromDevice['group']))
        {
            configFromDevice['group'] = [configFromDevice['group']];
        }
        for (let index in configFromDevice['group'])
        {
            if(configFromDevice['group'][index]["group-name"] == groupName)
            {
                bgpConfig['group'] = configFromDevice['group'][index];
                break;
            }
        }

        bgpConfig['neighbor'] = [];
        if(configFromDevice['neighbor'] != undefined)
        {
            if (!Array.isArray(configFromDevice['neighbor']))
            {
                configFromDevice['neighbor'] = [configFromDevice['neighbor']];
            }
            for (let index in configFromDevice['neighbor'])
            {
                if(configFromDevice['neighbor'][index]["group"] == groupName)
                {
                    bgpConfig['neighbor'].push(configFromDevice['neighbor'][index]);
                }
            }
        }

        let parsedTargetData = JSON.parse(targetData);

        let mergedTargetData = this.traverse(parsedTargetData, bgpConfig);
        parsedTargetData = mergedTargetData;

        if(bgpConfig['neighbor'].length == 0)
        {
            delete parsedTargetData['neighbor'];
        }

        if(configFromDevice['group'] == undefined)
        {
            delete parsedTargetData['group'];
        }
        return parsedTargetData;
    }


    this.traverse = function (targetData, deviceConfig) {
        if (targetData !== null && targetData !== undefined) {
            let keys = Object.keys(targetData);
            for (let i = 0; i < keys.length; i++) {
                let propertyName = keys[i];
                let deviceValue = deviceConfig[propertyName];

                if (deviceValue != undefined && Array.isArray(deviceValue)) {
                    targetData[propertyName] = this.ArrayTraverse(targetData[propertyName], deviceValue, []);
                } else if (deviceValue != undefined && typeof deviceValue === 'object') {
                    targetData[propertyName] = this.containerTraverse(targetData[propertyName], deviceValue, {});
                } else {
                    targetData[propertyName] = deviceValue
                }
            }

        }
        return targetData;
    }

    this.ArrayTraverse = function (arrayTargetData, arrayDeviceConfigData, arrayData) {
        for (let i = 0; i < arrayDeviceConfigData.length; i++) {
            let arrayObject = {};
            let keys = Object.keys(arrayTargetData[0]);
            for (let j = 0; j < keys.length; j++) {
                let propertyName = keys[j];
                let deviceValue = arrayDeviceConfigData[i][propertyName];

                if (deviceValue != null && deviceValue != undefined && Array.isArray(deviceValue)) {
                    arrayObject[propertyName] = this.ArrayTraverse(arrayTargetData[0][propertyName], deviceValue, []);
                } else if (deviceValue != null && deviceValue != undefined && typeof deviceValue === 'object') {
                    arrayObject[propertyName] = this.containerTraverse(arrayTargetData[0][propertyName], deviceValue, {});

                } else {
                    arrayObject[propertyName] = deviceValue
                }
            }
            arrayData.push(arrayObject);
        }

        return arrayData;
    }

    this.containerTraverse = function (containerTargetData, containerDeviceConfigData, targetContainer) {
        let keys = Object.keys(containerTargetData);
        for (let i = 0; i < keys.length; i++) {
            let propertyName = keys[i];
            let deviceValue = containerDeviceConfigData[propertyName];

            if (deviceValue != null && deviceValue != undefined && Array.isArray(deviceValue)) {
                if (this.isAtrributeLeafList(deviceValue)) {
                    targetContainer[propertyName] = deviceValue;
                } else {
                    targetContainer[propertyName] = this.ArrayTraverse(containerTargetData[propertyName], deviceValue, []);
                }

            } else if (deviceValue != null && deviceValue != undefined && typeof deviceValue === 'object') {
                targetContainer[propertyName] = this.containerTraverse(containerTargetData[propertyName], deviceValue, {});
            } else {
                targetContainer[propertyName] = deviceValue
            }
        }
        return targetContainer;
    }

    this.isAtrributeLeafList = function (leaflistData) {
        let isLeaflist = true;
        for (let i = 0; i < leaflistData.length; i++) {

            if (leaflistData[i] != null && typeof leaflistData[i] == 'object') {
                isLeaflist = false;
                break;
            }
        }
        return isLeaflist;
    }

    this.cipherSpecialCharacterInKey = function (key) {
        return key.replaceAll("/", "%2F").replaceAll(":", "%3A");
    }
}
