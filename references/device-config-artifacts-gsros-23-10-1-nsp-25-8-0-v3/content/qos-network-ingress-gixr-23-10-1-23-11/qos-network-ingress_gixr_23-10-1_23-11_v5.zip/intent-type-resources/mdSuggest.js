function MdSuggest() {
    this.getPolicyName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/network-ingress";
        return this.getData(neId, url, "network-ingress-policy-name", "network-ingress");
    }
    
    this.getIngressClassificationPolicy = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/ingress-classification-policy";
        return this.getData(neId, url, "ingress-classification-policy-name", "ingress-classification-policy");
    }
    
    this.getData = function (neId, url, type, configName) {
        var mdcFwk = new MdcFwk();
        logger.info(LOG_PREFIX + "MdSuggest QOS network --getData---neId={}, url={}, type={}, configName{}", neId, url, type, configName);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info(LOG_PREFIX + "MDC resultFetch QOS network =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"]["nokia-conf:" + configName];
        logger.info(LOG_PREFIX + "finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                ret.push(finalResponse[index][type]);
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "ret = \n" + JSON.stringify(ret));
        return ret;
    }
}