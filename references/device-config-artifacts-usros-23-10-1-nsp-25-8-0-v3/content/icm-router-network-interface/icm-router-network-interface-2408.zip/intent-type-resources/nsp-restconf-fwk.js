load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'MediatorFramework'});

function NspRestconfFwk() {
    this.mediatorFwk = new MediatorFramework("NSP");
}

NspRestconfFwk.prototype.RESTCONF_HOST = "restconf-gateway";
NspRestconfFwk.prototype.RESTCONF_PORT = "443";
NspRestconfFwk.prototype.mediatorFwk = null;
NspRestconfFwk.prototype.NSP_RESTCONF_INVENTORY_FIND_URL = "/restconf/operations/nsp-inventory:find";

NspRestconfFwk.prototype.constructURL = function (path, method) {
    var url = "https://" + this.RESTCONF_HOST + ":" + this.RESTCONF_PORT + path;
    logger.info("[RestconfFwk] {}Calling restconf via NSP Mediator: {}", method, url);
    return url;
};

NspRestconfFwk.prototype.findByXpathPaginated = function (xPath, depth, fields, offset) {
    if (!depth) depth = 3;
    if (!offset) offset = 0;
    var limit = 300;
    var url = this.constructURL(this.NSP_RESTCONF_INVENTORY_FIND_URL, "POST");
    var input = {};
    var ret = [];
    input["xpath-filter"] = xPath;
    input["depth"] = depth;
    if (fields !== undefined)
        input["fields"] = fields;
    input["offset"] = offset;
    input["limit"] = limit;
    var requestBody = {};
    requestBody["input"] = input;

    var response = this.mediatorFwk.post(url, requestBody);
    logger.info("[RestconfFwk][findByXpathPaginated] response = {}", JSON.stringify(response));

    if (response.httpStatus === 200 && response) {
        var lRes = JSON.parse(response["response"]);
        if (lRes && lRes["nsp-inventory:output"]) {
            var data = lRes["nsp-inventory:output"]["data"];
            if (data.length !== 0) {
                ret = ret.concat(data);
            }
            if ((lRes["nsp-inventory:output"]["end-index"] + 1) !== lRes["nsp-inventory:output"]["total-count"]) {
                ret = ret.concat(this.findByXpathPaginated(xPath, depth, fields, lRes["nsp-inventory:output"]["end-index"] + 1));
            }
        }
    }
    return ret;
};

NspRestconfFwk.prototype.findByXpath = function (xPath, depth, fields) {
    if (!depth) {
        depth = 3;
    }
    var url = this.constructURL(this.NSP_RESTCONF_INVENTORY_FIND_URL, "POST");
    var input = {};
    var ret = null;
    input["xpath-filter"] = xPath;
    input["depth"] = depth;
    if (fields !== undefined)
        input["fields"] = fields;
    var requestBody = {};
    requestBody["input"] = input;

    var response = this.mediatorFwk.post(url, requestBody);
    logger.info("[RestconfFwk][findByXpath] response = {}", JSON.stringify(response));

    if (response.httpStatus === 200 && response) {
        var lRes = JSON.parse(response["response"]);
        if (lRes && lRes["nsp-inventory:output"]) {
            var data = JSON.parse(response["response"])["nsp-inventory:output"]["data"];
            if (data.length !== 0)
                ret = data;
        }
    }
    return ret;
};


NspRestconfFwk.prototype.getPorts = function (neId) {
    if (!neId) {
        return [];
    } else {

        var data = [];
        var lagUrl = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/lag[lag-mode!='access']";
        var response = this.findByXpath(lagUrl, 3, "lag-id;lag-mode;encap-type;description");
        if (response) {
            for (var lagCount = 0; lagCount < response.length; lagCount++) {
                var lagObj = {};
                lagObj["port-id"] = response[lagCount]["lag-id"];
                lagObj["description"] = response[lagCount]["description"];
                lagObj["encapType"] = response[lagCount]["encap-type"];
                lagObj["mode"] = response[lagCount]["lag-mode"];
                data.push(lagObj);
            }
        }

        var portXPath = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/hardware-component/port[boolean(port-details[port-mode !='access' and port-type!='connector-port'])]";
        var ret = this.findByXpath(portXPath, 3, "name;description;port-details");
        var result = {};
        if (ret) {
            var portData = ret.map(function (port) {
                var obj = {};
                obj["port-id"] = (port["name"].replace("Port", "")).trim();
                obj["description"] = port["description"];
                if (port["port-details"]) {
                    obj["encapType"] = port["port-details"][0]["encap-type"]
                    obj["mode"] = port["port-details"][0]["port-mode"]
                }
                if (port["encap-type"]) {
                    obj["encapType"] = port["encap-type"];
                }
                if (port["mode"]) {
                    obj["mode"] = port["port-mode"];
                }
                data.push(obj);
                return obj;
            });

        }
        var result = {};
        result["data"] = JSON.stringify(data);

        return result
    }
};

NspRestconfFwk.prototype.getISISInstances = function (neid) {
    var xPath;
    var result = [];
    if (neid) {
        xPath = "/nsp-network:network/node[node-id='" + neid + "']/node-root/openconfig-network-instance:network-instances/network-instance[name='default']/protocols/protocol[identifier='openconfig-policy-types:ISIS']";
    }

    var data = this.findByXpathPaginated(xPath, 3, 'name');
    if (data) {
        var ret = data.map(function (ne) {
            result.push(ne["name"]);
        });
    }
    return result;
};

NspRestconfFwk.prototype.getOSPFInstances = function (neid, ospfversion) {
    var xPath;
    if (neid) {
        if (ospfversion == 3) {
            xPath = "/nsp-network:network/node[node-id='" + neid + "']/node-root/openconfig-network-instance:network-instances/network-instance[name='default']/protocols/protocol[identifier='openconfig-policy-types:OSPF3']";
        } else {
            xPath = "/nsp-network:network/node[node-id='" + neid + "']/node-root/openconfig-network-instance:network-instances/network-instance[name='default']/protocols/protocol[identifier='openconfig-policy-types:OSPF']";
        }

    }
    var result = [];
    var data = this.findByXpathPaginated(xPath, 3, 'name');
    if (data) {
        var ret = data.map(function (ne) {
            result.push(ne["name"]);

        });

    }
    return result;
};

NspRestconfFwk.prototype.getOSPFAreaInstances = function (neid, ospfversion, ospfInstance) {
    var xPath;
    if (neid) {
        if (ospfversion === 3) {
            xPath = "/nsp-network:network/node[node-id='" + neid + "']/node-root/openconfig-network-instance:network-instances/network-instance[name='default']/protocols/protocol[identifier='openconfig-policy-types:OSPF3'][name='" + ospfInstance + "']";
        } else {
            xPath = "/nsp-network:network/node[node-id='" + neid + "']/node-root/openconfig-network-instance:network-instances/network-instance[name='default']/protocols/protocol[identifier='openconfig-policy-types:OSPF'][name='" + ospfInstance + "']";
        }

    }

    var result = [];
    var data = this.findByXpathPaginated(xPath, 5, undefined);
    var areas = undefined;
    if (ospfversion === 3) {
        areas = data[0]["nsp-openconfig-ospfv3-augments:ospfv3"]["areas"]["area"];
    } else {
        areas = data[0]["ospfv2"]["areas"]["area"];
    }

    for (var areaId = 0; areaId < areas.length; areaId++) {
        var area = areas[areaId];
        result.push(area["identifier"]);
    }

    return result;
};


NspRestconfFwk.prototype.getByXpath = function (xPath) {
    var url = this.constructURL("/restconf/data" + xPath, "GET");
    var response = this.mediatorFwk.fetch(url);
    logger.debug("[RestconfFwk][getByXpath] response = {}", JSON.stringify(response));
    if (response.httpStatus === 200) {
        return response["response"];
    } else {
        return null;
    }
};
