var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpSasEgress() {
    var util = new utilities();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var savedObjects;
    var currentObjects;
    var isAudit = false;
    var isLocalExists = false;
    var isGlobalExists = false;
    var distribute_url = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true";

    this.synchronize = function (input, result, intentTypeName, xpath, initialPropertyName, uniqueIdentifier) {
        if (input.getNetworkState().name() == "delete") {
            return this.syncDelete(input, result);
        }
        var savedTopology = input.getCurrentTopology();
        logger.info(savedTopology);
        savedObjects = {};
        currentObjects = {};
        this.loadSavedObjectsFromTopology(savedTopology);
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyId = input.getTarget().split("#")[2];
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
        if (!intentConfig) {
            intentConfig = Object.create({});
        }
        intentConfig["policy-name"] = input.getTarget().split("#")[3];
        intentConfig["policy-id"] = parseInt(policyId);
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target Access-Egress = " + policyId);

        this.createOrModify(target, intentConfig, intentConfig["policy-name"]);
        var currentTopo = this.loadCurrentObjectsToTopology(target);

        result = util.setSuccessResult(result, currentTopo);
        return result;
    }

    this.syncDelete = function (input, result) {
        var className = "sasqos.PortAccessEgress";
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyId = input.getTarget().split("#")[2];
        var objectFullName = "network:" + neId + ":sasPortAccessEgress:" + policyId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        var searchPayLoad = this.constructSearchString(className, objectFullName);
        var searchResponse = nfmpFwk.find(neId, searchPayLoad);
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0)) {
            if (!(searchResponse.success))
                logger.info("[NFMP-ACCESS-EGRESS-FWK] syncDelete(): Unable to get Policy info from nfm-p for policy Id:" + policyId + " on " + neId);
            if (JSON.parse(searchResponse["response"]).length === 0)
                logger.info("[NFMP-ACCESS-EGRESS-FWK] syncDelete(): There is no access-egress policy Id:" + policyId + " on " + neId);
            result.setSuccess(false);
            return;
        }
        logger.info("[NFMP-ACCESS-EGRESS-FWK] syncDelete(): Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success) {
            logger.info("[NFMP-ACCESS-EGRESS-FWK] syncDelete(): Unable to Delete: " + deleteResult.msg);
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }

    this.createOrModify= function(neId, intentConfig,uniqueIdentifier) {
        var fullClassName = "sasqos.PortAccessEgress";
        var objectFullName = "sasPortAccessEgress:" + intentConfig["policy-id"];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        var localPolicy = util.getIfObjectExists(fullClassName, localPolicyFullName);
        var result;
        var portEgressPayload;
        var distributePayload;
        var distributeResult;
        if (localPolicy != null) {
            isLocalExists = true;
            isGlobalExists = true;
            portEgressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, isLocalExists, localPolicy);
            result = this.modifyRequest(neId, portEgressPayload);
            if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                throw new RuntimeException('Unable to Create/Distribute Policy: ' + intentConfig["policy-id"] +
                    " , Kindly check the intent configuration");
            }
        }
        else {
            logger.info(LOG_PREFIX + "Unable to find the local policy, Trying to fetch global policy if available ");
            var searchPayload = this.constructSearchString(fullClassName, objectFullName);
            var searchResponse = nfmpFwk.find(neId, searchPayload);
            if (!(searchResponse.success && JSON.stringify(searchResponse.response) === "")) {
                if (!searchResponse.success) {
                    logger.info(LOG_PREFIX + "createOrModify(): Unable to get Policy info from nfm-p for Ne " +
                        neId + " and Policy name: " + uniqueIdentifier);
                }
                if (searchResponse.response === "") {
                    logger.info(LOG_PREFIX + "createOrModify(): There is no port-egress policy with ID:" +
                        uniqueIdentifier + " on " + neId);
                }
            }
            else {
                throw new RuntimeException("createOrModify(): There exists a port-egress policy " + uniqueIdentifier + " on " +
                    neId + " with ID " +intentConfig["policy-id"]);
            }

            var globalPolicy = util.getIfObjectExists(fullClassName, objectFullName);
            if (globalPolicy != null) {
                isGlobalExists = true;
                /*   if (globalPolicy[0]["Id"] !== uniqueIdentifier) {
                       logger.info(LOG_PREFIX + "createOrModify(): There exists a port-egress global policy in NFMP with policy Id " + intentConfig["policy-id"] + " on " + neId);
                        this.updateAccessEgressPolicyI(neId, objectFullName, uniqueIdentifier);
                   }*/

                distributePayload = util.distribute(neId, objectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(neId, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                logger.info(LOG_PREFIX + "checking distribution of existing global policy was successful");
                if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                    throw new RuntimeException("Unable to Distribute existing Global Policy: " + uniqueIdentifier +
                        " , Kindly check the Global Policy configuration");
                }
                logger.info(LOG_PREFIX + "distribution of existing global policy was successful, updating with intent configuration ");
                portEgressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, true, globalPolicy);
                result = this.modifyRequest(neId, portEgressPayload);
                if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                    throw new RuntimeException('Unable to Create/Distribute Policy: ' + uniqueIdentifier +
                        " , Kindly check the intent configuration");
                }
            }
            else {
                //distributing empty policy
                logger.info(LOG_PREFIX + " Unable to find the Global Policy, distributing empty policy and updating");
                portEgressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, false, null);
                result = this.modifyRequest(neId, portEgressPayload);
                distributePayload = util.distribute(neId, objectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(neId, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                //updating the local policy with intent configuration
                portEgressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, true, null);
                result = this.modifyRequest(neId, portEgressPayload);
            }
        }
        return result;
    }


    this.createPolicyLevelPayLoad = function (neId, intentConfig) {
        var fullClassName = "sasqos.PortAccessEgress";
        var policyFdn = "sasPortAccessEgress";
        var objectFullName = "sasPortAccessEgress:" + intentConfig["policy-id"];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        if (util.isObjectExists(fullClassName, localPolicyFullName) || isAudit)
        {
            objectFullName = localPolicyFullName;
            if (!isAudit)
            {
                isEdit = true;
            }
        }

        var properties = {};
        var childProperties = {};
        if(intentConfig["policy-id"]) {
            properties["id"] = intentConfig["policy-id"];
        }
        if(intentConfig["policy-name"]) {
            properties["displayedName"] = intentConfig["policy-name"];
        }
        if(intentConfig["description"]) {
            properties["description"] = intentConfig["description"];
        }
        if(intentConfig["scope"]) {
            properties["scope"] = intentConfig["scope"];
        }
        if(intentConfig["egress-remark"]) {
            properties["egressRemark"] = intentConfig["egress-remark"];
        }else{
            properties["egressRemark"] = false;
        }

        if(intentConfig["egress-remark"] == true && intentConfig["remarking-type"]) {
            properties["remarkingType"] = intentConfig["remarking-type"];
        }
        if(intentConfig["remarking-policy"]) {
            properties["remarkPolicyPointer"] = "sasRemarkingPolicy:" + intentConfig["remarking-policy"];
        }

        if (intentConfig["queue"]["queue"]) {
            if (!Array.isArray(intentConfig["queue"]["queue"])) {
                intentConfig["queue"]["queue"] = [intentConfig["queue"]["queue"]];
            }
            var queueLevelDataPayload = [];
            for (var index in intentConfig["queue"]["queue"]) {
                var intentQueueDataConfig = intentConfig["queue"]["queue"][index];
                var queueLevelPayload = this.createQueuePayload(intentQueueDataConfig);
                queueLevelDataPayload.push(queueLevelPayload);
            }
            childProperties["sasqos.PortAccessEgressQueue"] = queueLevelDataPayload;
        }

        if (intentConfig["forwardingClass"]) {
            if(intentConfig["forwardingClass"]["forwardingClass"]){
                if (!Array.isArray(intentConfig["forwardingClass"]["forwardingClass"])) {
                    intentConfig["forwardingClass"]["forwardingClass"] = [intentConfig["forwardingClass"]["forwardingClass"]];
                }
                var forwardingClassPayload = [];
                for (var index in intentConfig["forwardingClass"]["forwardingClass"]) {
                    var intentForwardingClassConfig = intentConfig["forwardingClass"]["forwardingClass"][index];
                    var forwardClassPayload = this.createForwardingClassPayLoad(intentForwardingClassConfig);
                    forwardingClassPayload.push(forwardClassPayload);
                }
                childProperties["sasqos.PortAccessEgressForwardingClass"] = forwardingClassPayload;
            }
        }else{
            childProperties["sasqos.PortAccessEgressForwardingClass"]=[];
        }

        var policyLevelPayload = util.editPayload(policyFdn, properties, childProperties, fullClassName, objectFullName);
        return policyLevelPayload;
    }

    this.createQueuePayload = function (intentQueueDataConfig) {
        var properties = {};

        properties["id"] = intentQueueDataConfig["queue-id"];

        if (intentQueueDataConfig["mode"]) {
            properties["mode"] = intentQueueDataConfig["mode"];
        }
        if (intentQueueDataConfig["queue-management-policy"]) {
            properties["queuemgmtPolicyPointer"] = "sasQueueMgmtPolicy:" + intentQueueDataConfig["queue-management-policy"];
        }
        else {
            properties["queuemgmtPolicyPointer"] = "sasQueueMgmtPolicy:default";
        }
        if (intentQueueDataConfig["weight"]) {
            properties["weight"] = intentQueueDataConfig["weight"];
        }
        if(intentQueueDataConfig["rate"]) {
            if(intentQueueDataConfig["rate"]["rate-type"]) {
                properties["rateType"] = intentQueueDataConfig["rate"]["rate-type"];
            }
            if (intentQueueDataConfig["rate"]["cir"] == "max") {
                properties["cir"] = -1;
            }
            else {
                properties["cir"] = intentQueueDataConfig["rate"]["cir"];
            }

            properties["cirPercentInDecimals"] = intentQueueDataConfig["rate"]["cir-percent"];

            if((isAudit) && (intentQueueDataConfig["rate"]["cir-percent"] % 1 === 0)) {
                properties["cirPercentInDecimals"] = parseInt(intentQueueDataConfig["rate"]["cir-percent"]) + ".0";
            }

            if (intentQueueDataConfig["rate"]["pir"] == "max") {
                properties["pir"] = -1;
            }
            else {
                properties["pir"] = intentQueueDataConfig["rate"]["pir"];
            }
            properties["pirPercentInDecimals"] = intentQueueDataConfig["rate"]["pir-percent"];

            if((isAudit) && (intentQueueDataConfig["rate"]["pir-percent"] % 1 === 0)) {
                properties["pirPercentInDecimals"] = parseInt(intentQueueDataConfig["rate"]["pir-percent"]) + ".0";
            }
        }
        if(intentQueueDataConfig["adaptation-rule"]) {
            if (intentQueueDataConfig["adaptation-rule"]["cir-adaptation"]) {
                properties["cirAdaptation"] = intentQueueDataConfig["adaptation-rule"]["cir-adaptation"];
            }
            if (intentQueueDataConfig["adaptation-rule"]["pir-adaptation"]) {
                properties["pirAdaptation"] = intentQueueDataConfig["adaptation-rule"]["pir-adaptation"];
            }
        }
        return properties;
    }

    this.createForwardingClassPayLoad = function (intentFcConfig) {
        var properties = {};

        if (intentFcConfig["forwarding-class"]) {
            properties["forwardingClass"] = intentFcConfig["forwarding-class"];
        }

        if(intentFcConfig["dot1p"] && (intentFcConfig["dot1p"]["dot1p"] || intentFcConfig["dot1p"]["dot1p"] == "0")) {
            properties["dot1pProfile"] = util.gfNfmpDot1pAttribute(intentFcConfig["dot1p"]["dot1p"]);
        }

        if(intentFcConfig["dot1p"] && (intentFcConfig["dot1p"]["dot1p_in_profile"] || intentFcConfig["dot1p"]["dot1p_in_profile"] == "0")) {
            properties["inDot1p"] = util.gfNfmpDot1pAttribute(intentFcConfig["dot1p"]["dot1p_in_profile"]);
        }

        if(intentFcConfig["dot1p"] && (intentFcConfig["dot1p"]["dot1p_out_profile"] || intentFcConfig["dot1p"]["dot1p_out_profile"] == "0")) {
            properties["outDot1p"] = util.gfNfmpDot1pAttribute(intentFcConfig["dot1p"]["dot1p_out_profile"]);
        }

        if(intentFcConfig["dscp"] && intentFcConfig["dscp"]["dscp_in_profile"]) {
            properties["dscpInProfile"] = intentFcConfig["dscp"]["dscp_in_profile"];
        } else {
            properties["dscpInProfile"] = "default";
        }
        if(intentFcConfig["dscp"] && intentFcConfig["dscp"]["dscp_out_profile"]) {
            properties["dscpOutProfile"] = intentFcConfig["dscp"]["dscp_out_profile"];
        } else {
            properties["dscpOutProfile"] = "default";
        }


        if(intentFcConfig["de"] && intentFcConfig["de"]["mark-de-bit"]) {
            properties["deMark"] = intentFcConfig["de"]["mark-de-bit"];
        }else{
            properties["deMark"] = false;
        }

        if((intentFcConfig["de"] && intentFcConfig["de"]["mark-de-bit"] == true) && ((intentFcConfig["de"]["force-de-value"] == 0) || (intentFcConfig["de"]["force-de-value"]))) {
            properties["forceDeValue"] = intentFcConfig["de"]["force-de-value"];
        }else{
            properties["forceDeValue"] = "default";
        }

        return properties;
    }

    this.modifyRequest = function (target, payload) {

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
           logger.error("Error result = {}",JSON.stringify(result));
           let errorMsg = result.msg;
           if(errorMsg.indexOf("object already exists") !== -1)
           {
               logger.info("Global policy Object already exists, Re-checking the Policy existence ");
               //util.delay(2000);
               let configInfo = payload.configInfo;
               let fullClassName;
               for (let key in configInfo) {
                 if (configInfo.hasOwnProperty(key)) {
                   fullClassName = key;
                   break;
                 }
               }
               let objectFullName = payload.objectFullName;
               objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
               logger.info("fullClassName = {}",fullClassName);
               logger.info("objectFullName = {}",objectFullName);
               if (!util.isObjectExists(fullClassName, objectFullName))
               {
                   throw new RuntimeException("Global Policy Object Not Found!!!");
               }
           }
           else
           {
               throw new RuntimeException(result.msg);
           }
        }
        return result;

    }

    this.audit = function (input, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        isAudit = true;
        var lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        var intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        intentConfig["policy-id"] = input.getTarget().split("#")[2];
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        if (intentConfig) {
            this.auditAndCompare(neId, intentConfig, auditReport);
        } else {
            throw "configuration not available in the intent";
        }
        return auditReport
    }

    this.auditAndCompare = function (neId, intentConfig, auditReport) {
        var PortEgressPayload = this.createPolicyLevelPayLoad(neId, intentConfig);
        var result = this.auditRequest(neId, PortEgressPayload);
        auditReport = util.reportMisaligned(neId, result, auditReport);
        return auditReport;
    }

    this.auditRequest = function (neId, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.updateAuditResult = function (aInAuditResult) {
        var resultResp = JSON.parse(aInAuditResult.response);
        var misalignedAttributes = resultResp.misalignedAttributes;
        if (Object.keys(auditResult).length === 0) {
            auditResult = resultResp;
        } else {
            if (misalignedAttributes.length > 0) {
                auditResult.misalignedAttributes = auditResult.misalignedAttributes.concat(misalignedAttributes);
                auditResult.aligned = false;
            }
        }
    }

    this.constructSearchString = function(className, objectFullName) {
        logger.info(LOG_PREFIX + "Creating search payload for :"+ objectFullName );

        var expectedJson = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        return expectedJson;

    }

    this.loadSavedObjectsFromTopology = function (savedTopology) {
        if (savedTopology) {
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0) {
                topoObjects.forEach(function (topoObject) {
                    mapFwk.set(savedObjects, topoObject.getObjectType(), topoObject.getObjectRelativeObjectID());
                });
            }
        }

    }
    this.loadCurrentObjectsToTopology = function (target) {

        var currentTopo = topologyFactory.createServiceTopology();
        if (Object.keys(currentObjects).length) {
            for (var key in currentObjects) {
                objectId = mapFwk.get(currentObjects, key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key, objectId, "INFRASTRUCTURE", target, ""));
            }
        }
        return currentTopo;

    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        return JSON.parse(json);
    }

    this.removeEmptyContainers = function (prop, intentJson, path, target) {

        if (Array.isArray(intentJson)) {
            var object = [];
            for (var prop in intentJson) {
                var value = this.removeEmptyContainers(prop, intentJson[prop], path, target);
                if (value) {
                    object.push(value);
                }

            }
            if (Object.keys(object).length !== 0) {
                return object;
            }
        } else if (typeof intentJson == 'object') {
            var object = {};
            for (var prop in intentJson) {
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop, intentJson[prop], pPath, target);
                if ((value && value !== null) || value == 0) {
                    object[prop] = value;
                }

            }
            if (Object.keys(object).length !== 0) {
                return object;
            }
        } else {
            if (intentJson !== undefined && intentJson !== "") {
                return intentJson;
            }

            return null;
        }
    }
}
