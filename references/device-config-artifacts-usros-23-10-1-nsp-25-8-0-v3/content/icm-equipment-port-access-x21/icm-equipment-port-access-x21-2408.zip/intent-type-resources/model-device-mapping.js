function ModelDeviceMapping() {


    this.getMapping = function(type){
        switch(type){
            case "port":
                return this.getPortMapping();
            case "serialChannel":
                return this.getSerialChannelMapping();
            case "serialChannelSpecifics":
                return this.getSerialChannelSpecificsMapping();
            case "ds0Channel-group":
                return this.getDs0ChannelGroupMapping();
            default:
                return this.getPortMapping();
        }
    }

    this.getPortMapping = function() {
        var mapping = {};
        mapping['port.admin-state'] = 'administrativeState';
        mapping['port.description'] = 'description';

        return mapping;
    }

    this.getSerialChannelMapping = function() {
        var mapping = {};
        mapping['port.serialChannel.admin-state'] = 'administrativeState';

        return mapping;
    }

    this.getSerialChannelSpecificsMapping = function() {
        var mapping = {};
        mapping['port.serialChannel.speed'] = 'speed';

        return mapping;
    }

    this.getDs0ChannelGroupMapping = function() {
        var mapping = {};
        mapping['port.serialChannel.ds0Channel-group.channel-group-id'] = 'displayedLocalChannelId';
        mapping['port.serialChannel.ds0Channel-group.admin-state'] = 'administrativeState';
        mapping['port.serialChannel.ds0Channel-group.encapType'] = 'encapType';

        return mapping;
    }

}
