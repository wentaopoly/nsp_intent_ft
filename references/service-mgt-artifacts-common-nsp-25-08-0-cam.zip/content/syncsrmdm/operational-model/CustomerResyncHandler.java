package com.nokia.nsp.mdt.intents.ibsf.resync.mdc;

import com.alu.nms.common.util.model.ModelFdn;
import com.nokia.nsp.md.common.IExecutionContext;
import com.nokia.nsp.md.common.IYangObject;
import com.nokia.nsp.md.common.YangObject;
import com.nokia.nsp.md.db.yang.api.ExecutionContext;
import com.nokia.nsp.md.db.yang.api.QueryParameters;
import com.nokia.nsp.md.db.yang.api.meta.IYangPath;
import com.nokia.nsp.md.ifg.yang.api.Fields;
import com.nokia.nsp.md.resync.api.IMdResyncFw;
import com.nokia.nsp.md.resync.api.INspObjectDeleteFilter;
import com.nokia.nsp.md.resync.api.IReadObjects;
import com.nokia.nsp.md.resync.plugin.common.DeviceInfo;
import com.nokia.nsp.md.resync.plugin.common.DeviceResyncClass;
import com.nokia.nsp.md.resync.plugin.common.IMDMPluginMdResyncProvider;
import com.nokia.nsp.md.resync.plugin.common.INspResyncDeviceClassHandler;
import com.nokia.nsp.md.resync.plugin.common.IPartialResyncContext;
import com.nokia.nsp.md.resync.plugin.common.ISaveTaskInfo;
import com.nokia.nsp.md.resync.plugin.common.ResyncClass;
import com.nokia.nsp.md.resync.plugin.common.Utils;
import com.nokia.nspos.persistence.yang.api.IYangDB;
import com.nokia.nspos.persistence.impl.db.transaction.Transactor;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;

public class CustomerResyncHandler implements INspResyncDeviceClassHandler, INspObjectDeleteFilter {
    private static final Logger logger = LoggerFactory.getLogger(CustomerResyncHandler.class.getName() + ".convertToNspObject");
    private static final String DEFAULT_CUST = "Default customer";
    private static final String DEFAULT_CUST_NODE_NAME = "1";

    @Override
    public boolean canDeleteNspObject(IYangObject aInIYangObject, String aInSbiClassId, IMdResyncFw aInIMdResyncFw) {
        Boolean delete = true;
        if (aInIYangObject.hasProperty("name") && aInIYangObject.get("name").toString().equals(DEFAULT_CUST_NODE_NAME)) {
            delete = false;//customer 1 only on state not conf don't delete on conf resync
        }
        return delete;
    }

    @Override
    public boolean isHandleRootDevice(DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, ISaveTaskInfo aInISaveTaskInfo, DeviceInfo aInDeviceInfo) {
        return true;
    }

    private void handleCustomerSite(String custName, String neId, Map deviceObj, String customerSiteClass, IYangDB yangDb,
                                    IMDMPluginMdResyncProvider aInMDMPluginMdResyncProvider, ResyncClass aInNspClass, DeviceInfo aInDeviceInfo, IPartialResyncContext aInPartialContext) {
        String customerXpathQuery = customerSiteClass + "[name='" + custName + "' and site-id='" + neId + "']";
        QueryParameters lQpCust = new QueryParameters();
        IExecutionContext lExecutionContext = new ExecutionContext(null, null, false, false, false);
        lQpCust.setIExecutionContext(lExecutionContext);
        //lQpCust.setFields(Fields.parse("name"));
        lQpCust.setDepth(2);
        lQpCust.setLimit(2);
        List<IYangObject> customerSiteList = yangDb.getMany(customerXpathQuery, lQpCust);
        if (customerSiteList.size() > 0) {
            if (customerSiteList.size() > 1) {
                logger.warn("More than one customer site found for customer {} site-id {}", custName, neId);
            }
            //update existing customer
            IYangObject nspSiteObject = convertDeviceCustomerToNsp(custName, neId, deviceObj);
            //run update
            final QueryParameters qp = new QueryParameters();
            IExecutionContext executionContextSvc = new ExecutionContext(null, null, false, false, false);
            qp.setIExecutionContext(executionContextSvc);

            yangDb.update(customerSiteList.get(0).getIdentifier(), nspSiteObject, qp);
        } else {
            //create global cust if required and site
            String lPath = "/nsp-customer:customers/customer/sites";
            createGlobalCustomerIfRequiredAndChild(custName, neId, deviceObj, lPath, yangDb, aInMDMPluginMdResyncProvider, aInNspClass, aInDeviceInfo, aInPartialContext);
        }
    }

    private void createGlobalCustomerIfRequiredAndChild(String custName, String neId, Map deviceObj, String customerSiteClass, IYangDB yangDb,
                                                        IMDMPluginMdResyncProvider aInMDMPluginMdResyncProvider, ResyncClass aInNspClass, DeviceInfo aInDeviceInfo, IPartialResyncContext aInPartialContext) {
        //query global customer by name
        String customerId = null;
        if (deviceObj.containsKey("customer-id") && deviceObj.get("customer-id")!=null) {
            customerId = deviceObj.get("customer-id").toString();//conf
        } else if (deviceObj.containsKey("oper-customer-id") && deviceObj.get("oper-customer-id")!=null) {
            customerId = (String)deviceObj.get("oper-customer-id").toString();//state
        }

        if (customerId == null && aInMDMPluginMdResyncProvider != null) {

            Set<ResyncClass> lResyncClasses = new HashSet<>(1);
            lResyncClasses.add(aInNspClass);

            Map<String, String> lMap = new HashMap<>();
            String lDeviceXPath = "/configure/service/customer[customer-name='" + custName +"']";
            lMap.put(lDeviceXPath,lDeviceXPath);

            aInMDMPluginMdResyncProvider.submitPartialResyncTask("nokia-conf:/configure/service/customer",
                    lResyncClasses,lMap, neId, aInDeviceInfo.getNodeType(), aInDeviceInfo.getNodeVersion(), aInDeviceInfo.getAmiName(),
                    aInDeviceInfo.getAmiVersion(), aInPartialContext);
            return;
        }

        String globalCustomerIdentifer = customerSiteClass.replace("/sites", "[id='" + customerId + "']");

        QueryParameters lQpCust = new QueryParameters();
        IExecutionContext lExecutionContext = new ExecutionContext(null, null, false, false, false);
        lQpCust.setIExecutionContext(lExecutionContext);
        lQpCust.setFields(Fields.parse("id"));
        lQpCust.setDepth(2);
        lQpCust.setLimit(2);

        final QueryParameters qp = new QueryParameters();
        IExecutionContext executionContextSvc = new ExecutionContext(null, null, false, false, false);
        qp.setIExecutionContext(executionContextSvc);

        List<IYangObject> customerGlobalList = yangDb.getMany(globalCustomerIdentifer, lQpCust);

        if (customerGlobalList.size() > 1) {
            logger.warn("More than one global customer found for customer id {}", customerId);
        }
        if (customerGlobalList.size() == 0) {
            IYangObject nspGlobalObject = convertDeviceCustomerToNsp(custName, null, deviceObj);
            try {
                IYangObject globalCust = yangDb.createChild("/nsp-customer:customers", "customer", nspGlobalObject, qp);
                //update with actual xpath
                globalCustomerIdentifer = globalCust.getIdentifier();
            } catch (Exception e) {
                if (e.toString().contains("duplicate key")) {
                    logger.warn("multiple sites trying to create global customer: {}", custName);
                } else {
                    throw (e);
                }
            }
        } else {
            globalCustomerIdentifer = customerGlobalList.get(0).getIdentifier();
        }

        //create customer site as child
        IYangObject nspSiteObject = convertDeviceCustomerToNsp(custName, neId, deviceObj);

        yangDb.createChild(globalCustomerIdentifer, "sites", nspSiteObject, qp);
    }

    private IYangObject convertDeviceCustomerToNsp(String custName, String neId, Map deviceObj) {
        Map nspCust = new HashMap();
        nspCust.put("name", custName);

        if (deviceObj.containsKey("description")) {
            nspCust.put("description", (String)deviceObj.get("description"));
        } else if (custName.equals(DEFAULT_CUST_NODE_NAME)) {
            //For default customer use same description as NFMP
            nspCust.put("description", DEFAULT_CUST);
        }
        if (deviceObj.containsKey("phone")) {
            nspCust.put("phone-number", (String)deviceObj.get("phone"));
        }
        if (deviceObj.containsKey("contact")) {
            nspCust.put("contact", (String)deviceObj.get("contact"));
        }

        if (neId != null) {//site object
            nspCust.put("site-id", neId);

            Map<String, Object> aInSourceFdn = (Map<String, Object>) (deviceObj).get("_fdn_");
            String lSourceFdnConf = "fdn:" + aInSourceFdn.get("scheme") + ":" + aInSourceFdn.get("namespace") + ":" + neId + ":" +
                    aInSourceFdn.get("fdn").toString().replace("/configure", "/state");
            String lSourceFdnState = "fdn:" + aInSourceFdn.get("scheme") + ":" + aInSourceFdn.get("namespace") + ":" + neId + ":" +
                    aInSourceFdn.get("fdn").toString().replace("/state", "/configure");
            Map<String, Object> lMetaData = new HashMap<>();
            nspCust.put("@", lMetaData);
            List<String> lSources = new ArrayList<>();
            lMetaData.put("nsp-model:sources", lSources);
            //Add state and conf fdns so updates can find object
            lSources.add(lSourceFdnConf);
            lSources.add(lSourceFdnState);
        } else {
            //For default customer use same name as NFMP
            nspCust.put("name", custName.equals(DEFAULT_CUST_NODE_NAME) ? DEFAULT_CUST : custName);

            if (deviceObj.containsKey("customer-id") && deviceObj.get("customer-id")!=null) {
                nspCust.put("id", Integer.parseInt(deviceObj.get("customer-id").toString()));
            } else if (deviceObj.containsKey("oper-customer-id") && deviceObj.get("oper-customer-id")!=null) {
                nspCust.put("id", Integer.parseInt(deviceObj.get("oper-customer-id").toString()));
            }
        }
        return new YangObject(nspCust);
    }


    //full resync
    @Override
    public void handleRootDevice(IYangPath aInIYangPath, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass,
                                 Object aInDeviceObject, ISaveTaskInfo aInISaveTaskInfo, DeviceInfo aInDeviceInfo, IReadObjects aInIReadObjects, List<IYangObject> aOutProcessedObjects) {
        logger.debug("In customer handleRootDevice");
        String neId = aInISaveTaskInfo.getNeId();

        Map deviceObj = (Map) aInDeviceObject;

        Map lDevFdn = (Map<String, Object>) (deviceObj).get("_fdn_");

        String lCustomerSiteSource = Utils.buildSourceFdn((Map) lDevFdn, neId, true);
        IYangObject lReadCustSiteYo = aInIReadObjects.removeBasedOnSource(lCustomerSiteSource);
        String custName = (String)deviceObj.get("customer-name");

        final QueryParameters qp = new QueryParameters();
        IExecutionContext executionContextSvc = new ExecutionContext(null, null, false, false, false);
        qp.setIExecutionContext(executionContextSvc);

        IYangDB yangDb = aInISaveTaskInfo.getIMDMPluginMdResyncProvider().getiMdResyncFw().getIYangDB();
        if (lReadCustSiteYo == null) {
            createGlobalCustomerIfRequiredAndChild(custName, neId, deviceObj, aInIYangPath.toString(), yangDb, null, null, null, null);
        } else {//Found site from source. Update
            IYangObject nspSiteObject = convertDeviceCustomerToNsp(custName, neId, deviceObj);
            //run update
            yangDb.update(lReadCustSiteYo.getIdentifier(), nspSiteObject, qp);
            //Think this is needed to prevent delete
            aOutProcessedObjects.add(lReadCustSiteYo);
        }
    }

    @Override
    public void handlePartialDeviceResyncClass(ISaveTaskInfo aInSaveTaskInfo, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, Map<String, Object> aInDeviceObject, String aInNeId, IMDMPluginMdResyncProvider aInMDMPluginMdResyncProvider, DeviceInfo aInDeviceInfo, IPartialResyncContext aInPartialContext) {
        //only specific object resync.
        logger.info("handlePartialDeviceResyncClass");
        //TODO: verify (what if global does not exist)
        String custName = null;

        if (aInDeviceObject.get("customer-name") != null) {
            custName = (String)aInDeviceObject.get("customer-name");
        } else {
            custName = getCustomerNameFromDeviceObjectInfo(aInDeviceObject);
        }

        IYangDB yangDb = aInMDMPluginMdResyncProvider.getiMdResyncFw().getIYangDB();
        String customerSiteClass = "/nsp-customer:customers/customer/sites";
        handleCustomerSite(custName, aInNeId, aInDeviceObject, customerSiteClass, yangDb, aInMDMPluginMdResyncProvider, aInNspClass, aInDeviceInfo, null);
    }

    @Override
    public void handleUpdate(ISaveTaskInfo aInTaskInfo, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, Map<String, Object> aInDeviceObject, String neId,
                             IMDMPluginMdResyncProvider aInMDMPluginMdResyncProvider, DeviceInfo aInDeviceInfo) {
        logger.debug("handleUpdate");

        String custName = null;

        if (aInDeviceObject.get("customer-name") != null) {
            custName = (String)aInDeviceObject.get("customer-name");
        } else {
            custName = getCustomerNameFromDeviceObjectInfo(aInDeviceObject);
        }

        IYangDB yangDb = aInMDMPluginMdResyncProvider.getiMdResyncFw().getIYangDB();
        String customerSiteClass = "/nsp-customer:customers/customer/sites";
        handleCustomerSite(custName, neId, aInDeviceObject, customerSiteClass, yangDb, aInMDMPluginMdResyncProvider, aInNspClass, aInDeviceInfo, null);

    }

    @Override
    public void handleDelete(ISaveTaskInfo aInTaskInfo, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, Map<String, Object> aInDeviceObject, String neId,
                             IMDMPluginMdResyncProvider aInMDMPluginMdResyncProvider, DeviceInfo aInDeviceInfo) {
        //mdm-notification
        logger.debug("handleDelete");

        String custName = null;

        if (aInDeviceObject.get("customer-name") != null) {
            custName = (String)aInDeviceObject.get("customer-name");
        } else {
            custName = getCustomerNameFromDeviceObjectInfo(aInDeviceObject);
        }

        IYangDB yangDb = aInMDMPluginMdResyncProvider.getiMdResyncFw().getIYangDB();
        String customerSiteClass = "/nsp-customer:customers/customer/sites";

        String customerXpathQuery = customerSiteClass + "[name='" + custName + "' and site-id='" + neId + "']";
        QueryParameters lQpCust = new QueryParameters();
        IExecutionContext lExecutionContext = new ExecutionContext(null, null, false, false, false);
        lQpCust.setIExecutionContext(lExecutionContext);
        lQpCust.setFields(Fields.parse("name"));
        lQpCust.setDepth(2);
        lQpCust.setLimit(2);
        List<IYangObject> customerSiteList = yangDb.getMany(customerXpathQuery, lQpCust);

        if (customerSiteList.size() > 0) {
            yangDb.delete(customerSiteList.get(0).getIdentifier());
        }
        if (customerSiteList.size() > 1) {
            logger.warn("More than one customer site found for customer {} site-id {}", custName, neId);
        }
    }

    @Override
    public void handleDelete(ISaveTaskInfo aInTaskInfo, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, ModelFdn aInDeviceObject, String aInNeId, IMDMPluginMdResyncProvider aInMDMPluginMdResyncProvider, DeviceInfo aInDeviceInfo) {
        //called from data-deployer
        //Don't do anything.
    }

    private String getCustomerNameFromDeviceObjectInfo(Map<String, Object> aInDeviceObject) {
        String  lIFObjFdn = getDevObjFdn(aInDeviceObject);
        String custName = lIFObjFdn.substring(lIFObjFdn.indexOf("customer[customer-name='")+24, lIFObjFdn.lastIndexOf("']"));
        return custName;
    }

    private String getDevObjFdn(Map<String, Object> aInDeviceObject) {
        Object lDevObjFdn = aInDeviceObject.get("_fdn_");
        Map<String, Object> lDevObjFdnMap = new HashMap<>();
        lDevObjFdnMap.putAll((Map) lDevObjFdn);
        String lDevObjFdnStr = (String) lDevObjFdnMap.get("fdn");

        return lDevObjFdnStr;
    }
}
