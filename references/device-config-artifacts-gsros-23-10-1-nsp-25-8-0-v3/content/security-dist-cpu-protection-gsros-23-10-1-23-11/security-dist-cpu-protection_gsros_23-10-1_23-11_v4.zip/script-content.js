var RuntimeException = Java.type('java.lang.RuntimeException');
var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};
var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};
load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();
load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

var intentTypeName = 'security-dist-cpu-protection_gsros_23-10-1_23-11';

// example port, sap-ingress etc..
var initialPropertyName = 'policy';

// unique identifier
var uniqueIdentifier = 'displayedName';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/system/security/dist-cpu-protection';

function synchronize(input) {
    logger.info('Intent Synchronisation started')
    return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started')
    return NspIntentHelper.audit(target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function suggestStaticPolicerName(context) {
    logger.info("suggestStaticPolicerName--context = \n{}", context);
    var staticPolicerNames = [];
    try
    {
        var staticPolicies = context['inputValues']['arguments']['__parent']['policy']['static-policer'];
        staticPolicies.forEach(function (staticPolicyObject) {
            logger.info("static-policer-name : " + staticPolicyObject['policer-name']);
            staticPolicerNames.push(staticPolicyObject['policer-name']);
        });
    } catch (e)
    {
        logger.error("Unable to get Static Policer Names for context =\n{}\nerror = {}", context, e);
    }
    return staticPolicerNames;
}

function suggestDynamicMonitoringPolicerName(context) {
    logger.info("suggestDynamicMonitoringPolicerName--context = \n{}", context);
    var dynamicMonitoringPolicerNames = [];
    try
    {
        var dynamicMonitoringPolicies = context['inputValues']['arguments']['__parent']['policy']['local-monitoring-policer'];
        dynamicMonitoringPolicies.forEach(function (dynamicMonitoringPolicyObject) {
            logger.info("dynamic-monitoring-policer-name : " + dynamicMonitoringPolicyObject['policer-name']);
            dynamicMonitoringPolicerNames.push(dynamicMonitoringPolicyObject['policer-name']);
        });
    } catch (e)
    {
        logger.error("Unable to get Dynamic Monitoring Policer Names for context =\n{}\nerror = {}", context, e);
    }
    return dynamicMonitoringPolicerNames;
}

function getTargetData(input) {
    logger.info("getTargetData input for brownfield = \n" + input);
    var target = input.target;
    var config = null;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info(JSON.stringify(deviceConfig));
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}