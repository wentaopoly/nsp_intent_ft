var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource("transform.js"), name: "transformData"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpConfig() {
    let previousChildrenSet = {};
    let currentChildrenSet = {};
    const util = new utilities();
    const transform = new transformData();
    const parseTarget = new ParseTarget();
    let savedTopology;
    let uniqueIdentifierValue;
    let isAudit = false;
    let isEdit = false;
    let jsonFile = resourceProvider.getResource("meta-data/property-meta-data.json");
    jsonFile = JSON.parse(jsonFile);
    let objectFullNameJsonFile = resourceProvider.getResource("objectFullName.json");
    objectFullNameJsonFile = JSON.parse(objectFullNameJsonFile);
    let isPolicyIntent = objectFullNameJsonFile["isPolicyIntent"];

    this.synchronize = function (input, result, intentTypeName, initialPropertyName, uniqueIdentifier) {
        logger.info("-------------------- nfmp-config.js -> synchronize() --------------------");
        logger.info("result = {},\nintentTypeName = {},\ninitialPropertyName = {},\nuniqueIdentifier = {}", result, intentTypeName, initialPropertyName, uniqueIdentifier);
        savedTopology = input.getCurrentTopology();
        let neId = parseTarget.getNeIdFromTarget(input.getTarget());
        let lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        let intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];
        if (input.getNetworkState().name() == "delete")
        {
            logger.info("Calling syncDelete");
            return this.syncDelete(input, result, intentConfig);
        }
        uniqueIdentifierValue = parseTarget.getUniqueIdentifier(input.getTarget());
        let uids = uniqueIdentifier.split(",");
        uids.forEach((value, index) => {
            intentConfig[value] = uniqueIdentifierValue[index];
        });
        util.removeNullAndEmptyKeys(intentConfig);
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        logger.info("removing unsupported attributes")
        util.removeUnsupportedAttributes(intentConfig, neId)
        logger.info("intentConfig after removing unsupported attributes = {} ", JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        if (savedTopology != null)
        {
            for (let index in savedTopology.getXtraInfo())
            {
                let xtraInfo = savedTopology.getXtraInfo()[index].getKey();
                if (xtraInfo === "childrenSet")
                {
                    previousChildrenSet = JSON.parse(savedTopology.getXtraInfo()[index].getValue());
                }
            }
            logger.info("previousChildrenSet = {}", JSON.stringify(previousChildrenSet))
        }
        this.createOrModify(neId, intentConfig, initialPropertyName);
        result.setTopology(savedTopology);
        result.getTopology().setXtraInfo(savedTopology.getXtraInfo());
        return util.setSuccessResult(result, savedTopology);
    }
    this.syncDelete = function (input, result, intentConfig) {
        logger.info("-------------------- nfmp-config.js -> syncDelete() --------------------");
        logger.info("result = {}", result);
        let nfmpFwk = new NfmpFwk();
        let neId = parseTarget.getNeIdFromTarget(input.getTarget());
        let objectFullName;
        for (let index in savedTopology.getXtraInfo())
        {
            let xtraInfo = savedTopology.getXtraInfo()[index].getKey();
            if (xtraInfo === "objectFullName")
            {
                objectFullName = savedTopology.getXtraInfo()[index].getValue();
            }
            else if (xtraInfo === "localObjectFullName")
            {
                objectFullName = savedTopology.getXtraInfo()[index].getValue();
                break;
            }
        }
        //'#' must be encoded
        objectFullName = objectFullName.replaceAll("#","%23")
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        objectFullName = transform.transformObjectFullNameGreenField(objectFullName, intentConfig, neId, isAudit,true);
        logger.info("Deleting " + objectFullName);
        let deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }
    this.createOrModify = function (neId, intentConfig, initialPropertyName) {
        logger.info("-------------------- nfmp-config.js -> createOrModify() --------------------");
        logger.info("neId = {},\nintentConfig = {},\ninitialPropertyName = {}", neId, intentConfig, initialPropertyName);

        let payload = this.createConfigPayLoad(neId, intentConfig, initialPropertyName);
        this.modifyRequest(neId, payload);
        if (isPolicyIntent)
        {
            // distribute the policy to the local
            // Distribute Global Policy to Ne in Target
            if (!isEdit)
            {
                let nfmpFwk = new NfmpFwk();
                let distribute_url = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true";
                logger.info("Distributing the policy to local");
                let fullClassName = initialPropertyName.replace("-", ".");
                let objectFullName;
                let localObjectFullName;
                for (let index in savedTopology.getXtraInfo())
                {
                    let xtraInfo = savedTopology.getXtraInfo()[index].getKey();
                    if (xtraInfo === "objectFullName")
                    {
                        objectFullName = savedTopology.getXtraInfo()[index].getValue();
                    }
                    if (xtraInfo === "localObjectFullName")
                    {
                        localObjectFullName = savedTopology.getXtraInfo()[index].getValue();
                    }
                }
                objectFullName = transform.transformObjectFullNameDistribute(objectFullName, intentConfig, payload, neId);
                objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
                localObjectFullName = transform.transformLocalObjectFullNameDistribute(localObjectFullName, intentConfig, payload, neId);
                localObjectFullName = util.modifyNeIdForIpV6(localObjectFullName, neId);
                logger.info("Distribute objectFullName = {}", objectFullName);
                let distributePayload = util.distribute(neId, objectFullName, false);
                let distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success)
                {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(neId, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success)
                {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }

                //check if local policy got created, if not throw error, because clearOnDeploy will not give any error if distribute fails.
                logger.info("Checking if local policy object")
                util.delay(2000);
                let localPolicyExists = util.isObjectExists(fullClassName, localObjectFullName);
                if(!localPolicyExists)
                {
                    throw new RuntimeException("Unable to find local Policy : '"+ localObjectFullName + "', for the Class Name: '" + fullClassName + "'. Please check NFMP for any deployment errors.")
                }
                //resend the payload to local to make sure the correct data is updated
                //becuase during multiple/simultaneous distribute, where one node supports a property and nother node doesnt
                //support a property, then by the time the distrubute to node with supported property hits
                //the global might have been got modified
                this.resendPayloadToLocal(neId, payload,localObjectFullName);
            }
        }
    }
    this.resendPayloadToLocal = function (neId, payload,localObjectFullName) {
        payload["objectFullName"] = localObjectFullName;
        transform.transformPayloadGreenField(payload, neId, isAudit)
        logger.info("Modified payload for resending to local = " + JSON.stringify(payload));
        this.modifyRequest(neId, payload);
    }
    this.createConfigPayLoad = function (neId, intentConfig, initialPropertyName) {
        logger.info("-------------------- nfmp-config.js -> createConfigPayLoad() --------------------");
        logger.info("neId = {},\nintentConfig = {},\ninitialPropertyName = {}", neId, JSON.stringify(intentConfig), initialPropertyName);

        if (savedTopology == null)
        {
            logger.info("Creating save topology");
            savedTopology = topologyFactory.createServiceTopology();
        }
        let fullClassName = initialPropertyName.replace("-", ".");
        //let fdn = "***FDN***";
        //let objectFullName = "***OBJECTFULLNAME***";

        let fdn = objectFullNameJsonFile["greenFieldFDN"];
        let objectFullName = objectFullNameJsonFile["greenFieldObjectFullName"];
        objectFullName = this.getObjectFullName(objectFullName, intentConfig, neId);
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        //transform objectFullName if needed
        objectFullName = transform.transformObjectFullNameGreenField(objectFullName, intentConfig, neId, isAudit);
        fdn = this.getObjectFullName(fdn, intentConfig, neId);
        fdn = util.modifyNeIdForIpV6(fdn, neId);
        fdn = transform.transformFdnGreenField(fdn, intentConfig, neId, isAudit);
        logger.info("objectFullName = {}", objectFullName);
        logger.info("fdn = {}", fdn);
        let localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        localPolicyFullName = transform.transformLocalPolicyObjectFullNameGreenField(localPolicyFullName, objectFullName, neId, isAudit);
        let objectFullNameToBeDeployed = objectFullName;
        if (isPolicyIntent)
        {
            if (util.isObjectExists(fullClassName, localPolicyFullName) || isAudit)
            {
                objectFullNameToBeDeployed = localPolicyFullName;
                if (!isAudit)
                {
                    isEdit = true;
                }
            }
            logger.info("localPolicyFullName = {}", localPolicyFullName);
        }
        let addLocalObjectFullName = true;
        let addObjectFullName = true;
        for (let index in savedTopology.getXtraInfo())
        {
            let xtraInfo = savedTopology.getXtraInfo()[index].getKey();
            if (xtraInfo === "objectFullName")
            {
                addObjectFullName = false;
            }
            if (isPolicyIntent)
            {
                if (xtraInfo === "localObjectFullName")
                {
                    addObjectFullName = false;
                }
            }
        }
        if (addObjectFullName)
        {
            logger.info("Adding objectFullName to save topology");
            let entry = topologyFactory.createTopologyXtraInfoFrom("objectFullName", objectFullName);
            savedTopology.addXtraInfo(entry);
        }
        if (isPolicyIntent)
        {
            if (addLocalObjectFullName)
            {
                logger.info("Adding addLocalObjectFullName to save topology");
                let entry = topologyFactory.createTopologyXtraInfoFrom("localObjectFullName", localPolicyFullName);
                savedTopology.addXtraInfo(entry);
            }
        }

        let modifiedIntentConfig = {};
        this.generateJson(neId, modifiedIntentConfig, intentConfig)
        logger.info(JSON.stringify(modifiedIntentConfig))
        let payload = util.editPayload(fdn, fullClassName, objectFullNameToBeDeployed, modifiedIntentConfig);
        currentChildrenSet = JSON.parse(JSON.stringify(payload));

        let childrenSetEntry = topologyFactory.createTopologyXtraInfoFrom("childrenSet", JSON.stringify(currentChildrenSet));
        savedTopology.addXtraInfo(childrenSetEntry);

        logger.info("Previous Children set = {}", JSON.stringify(previousChildrenSet));
        logger.info("Current Children set = {}", JSON.stringify(currentChildrenSet));
        compare(previousChildrenSet, currentChildrenSet);
        util.removeKeysId(currentChildrenSet);
        transform.transformPayloadGreenField(currentChildrenSet, neId, isAudit)
        logger.info("payload = {}", JSON.stringify(currentChildrenSet));
        return currentChildrenSet;
    }
    this.getObjectFullName = function (objectFullName, intentConfig, neId) {
        logger.info("-------------------- nfmp-config.js -> getObjectFullName() --------------------");

        objectFullName = objectFullName.replace("*", "");
        let result = objectFullName;
        let inputString = objectFullName;
        // Find the index of the first '$'
        let dollarIndex = inputString.indexOf('$');
        while (dollarIndex !== -1)
        {
            let nextHyphenIndex = inputString.indexOf('-', dollarIndex);
            let nextColonIndex = inputString.indexOf(':', dollarIndex);
            let nextHashIndex = inputString.indexOf('#', dollarIndex);
            // Find the minimum index among hyphen, colon, and end of string
            let endIndex = inputString.length;
            if (nextHyphenIndex !== -1)
            {
                endIndex = Math.min(endIndex, nextHyphenIndex);
            }
            if (nextColonIndex !== -1)
            {
                endIndex = Math.min(endIndex, nextColonIndex);
            }
            if (nextHashIndex !== -1)
            {
                endIndex = Math.min(endIndex, nextHashIndex);
            }
            // Extract the substring between '$' and the determined end index
            let substring = inputString.substring(dollarIndex + 1, endIndex);
            let replaceSubstring = inputString.substring(dollarIndex, endIndex);
            let value = intentConfig[substring];
            if (substring === "systemAddress")
            {
                value = neId;
            }
            //for non satellite shelf the default shelfId = 1
            if (inputString.indexOf(":shelf-$id:") !== -1 && substring === "id")
            {
                value = 1;
            }
            result = result.replace(replaceSubstring, value)
            // Move the search index to the character after the last '-'
            dollarIndex = inputString.indexOf('$', dollarIndex + 1);
        }
        return result
    }
    this.generateJson = function (neId, modifiedIntentConfig, intentConfig, parentXpath) {
        logger.info("-------------------- nfmp-config.js -> generateJson() --------------------");

        let keys = Object.keys(intentConfig);
        let modifiedArrarIntentConfig = {};
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetValue = intentConfig[targetKey];
            //logger.info("targetKey = " + targetKey + "\targetValue = " + JSON.stringify(targetValue))
            if (targetValue !== null && typeof targetValue === 'object')
            {
                if (Array.isArray(modifiedIntentConfig))
                {
                    this.updateChildrenSet(neId, modifiedArrarIntentConfig, targetKey, targetValue, parentXpath);
                }
                else
                {
                    this.updateChildrenSet(neId, modifiedIntentConfig, targetKey, targetValue, parentXpath);
                }
            }
            else
            {
                let xpath;
                if (parentXpath)
                {
                    xpath = parentXpath + "." + targetKey;
                }
                else
                {
                    xpath = targetKey;
                }
                targetValue = transform.transformTargetValueGreenField(xpath, targetValue, targetKey, neId, isAudit);
                if (Array.isArray(modifiedIntentConfig))
                {
                    if (targetKey !== "key-id" && jsonFile[targetKey]["dataTypeInfo"])
                    {
                        let dataType = jsonFile[targetKey]["dataTypeInfo"]["type"];
                        if (dataType === "bitmask")
                        {
                            let bit = [];
                            let value = targetValue.split(" ");
                            for (let index in value)
                            {
                                bit.push(value[index])
                            }
                            if (isAudit)
                            {
                                modifiedArrarIntentConfig[targetKey] = bit;
                            }
                            else
                            {
                                if (bit.length > 1)
                                {
                                    modifiedArrarIntentConfig[targetKey] = {
                                        "bit": bit
                                    }
                                }
                                else
                                {
                                    modifiedArrarIntentConfig[targetKey] = bit;
                                }
                            }
                        }
                        else
                        {
                            modifiedArrarIntentConfig[targetKey] = targetValue;
                        }
                    }
                    else
                    {
                        modifiedArrarIntentConfig[targetKey] = targetValue;
                    }
                }
                else
                {
                    if (targetKey !== "key-id" && jsonFile[targetKey]["dataTypeInfo"])
                    {
                        let dataType = jsonFile[targetKey]["dataTypeInfo"]["type"];
                        if (dataType === "bitmask")
                        {
                            let bit = [];
                            let value = targetValue.split(" ");
                            for (let index in value)
                            {
                                bit.push(value[index])
                            }
                            if (isAudit)
                            {
                                modifiedIntentConfig[targetKey] = bit;
                            }
                            else
                            {
                                if (bit.length > 1)
                                {
                                    modifiedIntentConfig[targetKey] = {
                                        "bit": bit
                                    }
                                }
                                else
                                {
                                    modifiedIntentConfig[targetKey] = bit;
                                }
                            }
                        }
                                else
                                {
                            modifiedIntentConfig[targetKey] = targetValue;
                        }
                    }
                    else
                    {
                        modifiedIntentConfig[targetKey] = targetValue;
                    }
                }
            }
        }
        if (Array.isArray(modifiedIntentConfig))
        {
            modifiedIntentConfig.push(modifiedArrarIntentConfig);
        }
    }
    this.updateChildrenSet = function (neId, modifiedIntentConfig, targetKey, targetValue, xpath) {
        logger.info("-------------------- nfmp-config.js -> updateChildrenSet() --------------------");
        if (modifiedIntentConfig["children-Set"])
        {
            let parentXpath;
            if (xpath)
            {
                parentXpath = xpath + "." + targetKey;
            }
            else
            {
                parentXpath = targetKey;
            }

            let className = targetKey.replace("-", ".");
            if (Array.isArray(targetValue))
            {
                modifiedIntentConfig["children-Set"][className] = []
                for (let index in targetValue)
                {
                    this.generateJson(neId, modifiedIntentConfig["children-Set"][className], targetValue[index], parentXpath)
                }
            }
            else
            {
                modifiedIntentConfig["children-Set"][className] = {}
                this.generateJson(neId, modifiedIntentConfig["children-Set"][className], targetValue, parentXpath)
            }
        }
        else
        {
            modifiedIntentConfig["children-Set"] = {};
            this.updateChildrenSet(neId, modifiedIntentConfig, targetKey, targetValue, xpath)
        }

    }
    this.modifyRequest = function (neId, payload) {
        logger.info("-------------------- nfmp-config.js -> modifyRequest() --------------------");
        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        let nfmpFwk = new NfmpFwk();
        let result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            logger.error("Error result = {}",JSON.stringify(result));
            let errorMsg = result.msg;
            if(isPolicyIntent && (errorMsg.indexOf("object already exists") !== -1))
            {
                logger.info("Global policy Object already exists, Re-checking the Policy existence ");
                //util.delay(2000);
                let configInfo = payload.configInfo;
                let fullClassName;
                for (let key in configInfo) {
                  if (configInfo.hasOwnProperty(key)) {
                    fullClassName = key;
                    break;
                  }
                }
                let objectFullName = payload.objectFullName;
                logger.info("fullClassName = {}",fullClassName);
                logger.info("objectFullName = {}",objectFullName);
                if (!util.isObjectExists(fullClassName, objectFullName))
                {
                    throw new RuntimeException("Global Policy Object Not Found!!!");
                }
            }
            else
            {
                throw new RuntimeException(result.msg);
            }
        }
        return result;
    }
    this.audit = function (input, auditReport, intentTypeName, initialPropertyName, uniqueIdentifier) {
        logger.info("-------------------- nfmp-config.js -> audit() --------------------");
        logger.info("auditReport = {},\nintentTypeName = {},\ninitialPropertyName = {},\nuniqueIdentifier = {}", auditReport, intentTypeName, initialPropertyName, uniqueIdentifier);
        isAudit = true;
        let lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        let intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];
        let neId = parseTarget.getNeIdFromTarget(input.getTarget());
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        uniqueIdentifierValue = parseTarget.getUniqueIdentifier(input.getTarget());
        let uids = uniqueIdentifier.split(",");
        uids.forEach((value, index) => {
            intentConfig[value] = uniqueIdentifierValue[index];
        });
        util.removeNullAndEmptyKeys(intentConfig);
        logger.info("removing unsupported attributes")
        util.removeUnsupportedAttributes(intentConfig, neId)
        logger.info("intentConfig after removing unsupported attributes = {} ", JSON.stringify(intentConfig));
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        if (intentConfig)
        {
            this.auditAndCompare(neId, intentConfig, auditReport, initialPropertyName);
        }
        else
        {
            throw "configuration not available in the intent";
        }
        return auditReport
    }
    this.auditAndCompare = function (neId, intentConfig, auditReport, initialPropertyName) {
        logger.info("-------------------- nfmp-config.js -> auditAndCompare() --------------------");

        let payload = this.createConfigPayLoad(neId, intentConfig, initialPropertyName);
        let result = this.auditRequest(neId, payload);
        auditReport = util.reportMisaligned(neId, result, auditReport);
        return auditReport;
    }
    this.auditRequest = function (neId, payload) {
        logger.info("-------------------- nfmp-config.js -> auditRequest() --------------------");

        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        let nfmpFwk = new NfmpFwk();
        let result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }
    function compare(previousData, currentData) {
        for (const previousDataKey in previousData)
        {
            if (typeof previousData[previousDataKey] === 'object')
            {
                let previousChildKey = previousDataKey;
                let previousChild = previousData[previousDataKey];
                let currentChild = currentData[previousDataKey]
                if (Array.isArray(previousChild) && Array.isArray(currentChild))
                {
                    iterateArrayObject(previousChild, currentChild);
                    continue;
                }
                if (!currentChild)
                {
                    removeChildrenFromCurrent(previousChild, currentData, previousChildKey);
                }
                else
                {
                    compare(previousChild, currentChild);
                }
            }
        }
    }
    function removeChildrenFromCurrent(previousChild, currentData, key) {
        if (key === "children-Set")
        {
            if (!currentData.hasOwnProperty('children-Set'))
            {
                currentData['children-Set'] = {};
            }
            for (const previousChildKey in previousChild)
            {
                let previousChildObj = previousChild[previousChildKey];
                if (typeof previousChildObj === 'object' && Array.isArray(previousChildObj))
                {
                    currentData['children-Set'][previousChildKey] = [];
                }
            }
        }
        else
        {
            currentData[key] = [];
                }
            }

    function iterateArrayObject(previousChild, currentChild) {
        for (const previousChildElement of previousChild)
        {
            let previousChildObj = previousChildElement;
            let currentChildObj;
            for (const currentChildElement of currentChild)
            {
                let ChildObj = currentChildElement;
                if (ChildObj["key-id"] === previousChildObj["key-id"])
                {
                    currentChildObj = ChildObj;
                    break;
                }
            }
            if (currentChildObj)
            {
                compare(previousChildObj, currentChildObj)
            }
        }

    }
}
