function MdSuggest() {
    this.getGroupName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base/bgp/group";
        return this.getData(neId, url);
    }

    this.getData = function (neId, url) {
        var mdcFwk = new MdcFwk();
        logger.info(LOG_PREFIX + "MdSuggest BGP Group --getData---neId={}, url={}, type={}", neId, url);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info(LOG_PREFIX + "MDC resultFetch BGP Group =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"]["nokia-conf:group"];
        logger.info(LOG_PREFIX + "finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                   ret.push(finalResponse[index]["group-name"]);
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "ret = \n" + JSON.stringify(ret));
        return ret;
    }

    this.getPolicyStatement = function (neId) {
        var url =  "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/policy-options/policy-statement";
        return this.getPolicyStatementData(neId, url, "name");
    }

    this.getPolicyStatementData = function (neId, url, property) {
        var mdcFwk = new MdcFwk();
        logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, property);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info("MDC resultFetch =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"]["nokia-conf:policy-statement"];
        logger.info("finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse))
        {
            for (var index in finalResponse)
            {
                logger.info("Device Policy Statement Data = {}", finalResponse[index][property]);
                ret.push(finalResponse[index][property]);
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info("ret = \n" + JSON.stringify(ret));
        return ret;
    }
}