function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        if (!isAudit) {
            if (payload["configInfo"]["sitesec.TlsCertificateProfile"]["children-Set"] && payload["configInfo"]["sitesec.TlsCertificateProfile"]["children-Set"]["sitesec.TlsCertificateProfileEntry"]) {
                for (var index in payload["configInfo"]["sitesec.TlsCertificateProfile"]["children-Set"]["sitesec.TlsCertificateProfileEntry"]) {
                    var tlsCertificateProfileConfig = payload["configInfo"]["sitesec.TlsCertificateProfile"]["children-Set"]["sitesec.TlsCertificateProfileEntry"][index];

                    if(!tlsCertificateProfileConfig["certificateFile"]){
                        tlsCertificateProfileConfig["certificateFile"] = "N/A"
                    }
                    if(!tlsCertificateProfileConfig["keyFile"]){
                        tlsCertificateProfileConfig["keyFile"] = "N/A"
                    }

                    if(tlsCertificateProfileConfig["children-Set"] && tlsCertificateProfileConfig["children-Set"]["sitesec.TlsCertChainCAProfileEntry"]){
                        for (var indx in tlsCertificateProfileConfig["children-Set"]["sitesec.TlsCertChainCAProfileEntry"]) {
                            var tlsCertChainCAProfileConfig = tlsCertificateProfileConfig["children-Set"]["sitesec.TlsCertChainCAProfileEntry"][indx];

                            if(!tlsCertChainCAProfileConfig["caProfileName"]){
                                tlsCertChainCAProfileConfig["caProfileName"] = '';
                            }

                            tlsCertificateProfileConfig["children-Set"]["sitesec.TlsCertChainCAProfileEntry"][indx] = tlsCertChainCAProfileConfig;
                        }
                    }

                    payload["configInfo"]["sitesec.TlsCertificateProfile"]["children-Set"]["sitesec.TlsCertificateProfileEntry"][index] = tlsCertificateProfileConfig;
                }
            }
        }
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
}