load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'mediator-fwk.js'});
NSPInstance.prototype.imLogger = null;
NSPInstance.prototype.nspMediator = new MediatorFramework("NSP");
NSPInstance.prototype.ietfUtil = new IetfUtilities();
NSPInstance.prototype.nfmpStartTunneldRsvp = 40000;
NSPInstance.prototype.nfmpEndTunneldRsvp = 65533;
NSPInstance.prototype.nfmpStartTunneldSrte = 66000;
NSPInstance.prototype.nfmpEndTunneldSrte = 81000;
// NSPInstance.prototype.nfmpTunnelId = {};

function NSPInstance(imLogger) {
    if (imLogger) this.imLogger = imLogger;
    else this.imLogger = new IntentLogger();
}

NSPInstance.prototype.setImLogger = function (logger) {
    this.imLogger = logger;
    this.ietfUtil.setImLogger(logger);
    this.nspMediator.setImLogger(logger);
};

NSPInstance.prototype.preDeploy = function (deviceInfos, requestContext, navigateInstance) {
    this.imLogger.info('[preDeploy] deviceInfos: {}', JSON.stringify(deviceInfos));
    var nfmpTunnelId = {};
    var sources = [];
    for (var i = 0; i < deviceInfos.length; i++) {
        var deviceId = deviceInfos[i];
        var instanceFwk = navigateInstance(deviceId, requestContext);
        var sourceNodeId = requestContext.get("sourceNodeId")[deviceId];
        this.imLogger.info('[preDeploy] lInstance: {} deviceId: {}', instanceFwk.constructor.name, deviceId);
        if (instanceFwk instanceof MDMInstance && requestContext.get("networkState") !== "delete") {
            sources = sources.concat(this.mdmAddSource(requestContext, deviceId));
        } else if (instanceFwk instanceof NFMPInstance) {
            var lspTopoFdn = this.ietfUtil.getExtraInfo("lsp_" + deviceId, requestContext.get("currentTopology"));

            //destination source node id
            var intentConfigJson = requestContext.get("intentConfigJson");
            var destinationNodeId = intentConfigJson["destination"];
            this.imLogger.info('[preDeploy] intentConfigJson : {}', JSON.stringify(intentConfigJson));
            try {
                if (destinationNodeId)
                    navigateInstance(destinationNodeId, requestContext);
            }catch (e) {
                this.imLogger.info("[preDeploy] device {} is not manged", destinationNodeId);
            }
            if (!lspTopoFdn) {
                var nfmpPayload = {
                    "fullClassName": "mpls.Lsp",
                    "filter": {
                        "and": {
                            "equal": [
                                {
                                    "name": "displayedName",
                                    "value": requestContext.get("target")
                                },
                                {
                                    "name": "sourceNodeId",
                                    "value": sourceNodeId
                                }
                            ]
                        }
                    }
                };
                //var nfmpFwk = new MediatorFramework("NFMP");
                var nfmpFwk = ietfUtils.getNfmpMediator(requestContext.get("sourceNodeId")[deviceId]);
                nfmpFwk.imLogger = this.imLogger;
                var serviceFetch = nfmpFwk.post("/v3/search", nfmpPayload);
                this.imLogger.info("[preDeploy] serviceFetch {}", JSON.stringify(serviceFetch.response));


                if (serviceFetch.success && serviceFetch.response &&
                    (serviceFetch.response["mpls.DynamicLsp"] || serviceFetch.response["mpls.SegmentRoutingTeLsp"])) {
                    var lspData = serviceFetch.response["mpls.DynamicLsp"] ? serviceFetch.response["mpls.DynamicLsp"] :
                        serviceFetch.response["mpls.SegmentRoutingTeLsp"];

                    //BF-destination source node id
                    var destinationNodeId = lspData["destinationIpAddress"];
                    try {
                        if (destinationNodeId)
                            navigateInstance(destinationNodeId, requestContext);
                    }catch (e) {
                        this.imLogger.info("[preDeploy] device {} is not manged", destinationNodeId);
                    }

                    //BF - LSP
                    requestContext.get("currentTopology").addXtraInfo(topologyFactory.createTopologyXtraInfoFrom("lsp_" + deviceId, lspData["objectFullName"]));
                    nfmpTunnelId[deviceId] = parseInt(lspData["pathId"]);

                    //BF - PATH
                    var pathObj = {"primary": {}, "secondary": {}, "hopless": {}};
                    if (lspData["children-Set"] && lspData["children-Set"]["mpls.LspPath"]) {
                        if (!Array.isArray(lspData["children-Set"]["mpls.LspPath"])) {
                            lspData["children-Set"]["mpls.LspPath"] = [lspData["children-Set"]["mpls.LspPath"]]
                        }
                        var lspPathMap = requestContext.get("lspPathMap");

                        lspData["children-Set"]["mpls.LspPath"].forEach(function (lspObj) {
                            // Add the mapping of pathName to path-resourceName
                            lspPathMap[lspObj["name"]] = lspObj["resourceName"];
                          
                            if (lspObj["type"] === "primary" && lspObj["resourceName"] === "hopless") {
                                pathObj["hopless"][lspObj["resourceName"]] = {
                                    "tunnelDn": "mplsTunnel:from-" + deviceId + "-id-" + lspObj["resourceId"],
                                    "pathDn": "N/A"
                                }
                            } else {
                                var lType = "secondary";
                                if (lspObj["type"] === "primary") lType = "primary";
                                pathObj[lType][lspObj["resourceName"]] = {"pathDn": "N/A"};
                                var payload = {
                                    "fullClassName": "mpls.ProvisionedPath",
                                    "filter": {
                                        "and": {
                                            "equal": [{
                                                "name": "fromNodeId",
                                                "value": sourceNodeId
                                            },
                                                {
                                                    "name": "displayedName",
                                                    "value": lspObj["resourceName"]
                                                }]
                                        }
                                    },
                                    "resultFilter": {
                                        "attribute": [
                                            "objectFullName"
                                        ],
                                        "children": {}
                                    }
                                };
                                var lProvisionedPath = nfmpFwk.post("/v3/search", payload);
                                if (lProvisionedPath.success && lProvisionedPath["response"] && lProvisionedPath["response"]["mpls.ProvisionedPath"]) {
                                    pathObj[lType][lspObj["resourceName"]]["pathDn"] = lProvisionedPath["response"]["mpls.ProvisionedPath"]["objectFullName"];
                                }
                                payload["fullClassName"] = "mpls.Tunnel";
                                var lProvisionedPath = nfmpFwk.post("/v3/search", payload);
                                if (lProvisionedPath.success && lProvisionedPath["response"] && lProvisionedPath["response"]["mpls.Tunnel"]) {
                                    pathObj[lType][lspObj["resourceName"]]["tunnelDn"] = lProvisionedPath["response"]["mpls.Tunnel"]["objectFullName"];
                                } else {
                                    throw new RuntimeException ("Found BrownField Tunnel but failed to resolve NFMP objectFullName");
                                }
                            }
                        })
                        requestContext.put("lspPathMap", lspPathMap);
                    }
                    requestContext.get("currentTopology").addXtraInfo(topologyFactory.createTopologyXtraInfoFrom("nfmpFdn_" + deviceId, JSON.stringify(pathObj)));
                    if (Object.keys(pathObj.hopless) !== 0) delete pathObj.hopless;
                    if (Object.keys(pathObj.primary) !== 0) delete pathObj.primary;
                    if (Object.keys(pathObj.secondary) !== 0) delete pathObj.secondary;
                    this.imLogger.info('[preDeploy] topo xtrainfo: {}', requestContext.get("currentTopology").getXtraInfo());

                } else {
                    //GF - new tunnel deployment
                    if (requestContext.get("networkState") !== "delete") {
                        sources.push(this.nfmpAddSource(deviceId, requestContext, nfmpTunnelId));
                    }
                }
            }
        }
    }

    this.imLogger.info("[preDeploy] sources {}", JSON.stringify(sources));

    if (requestContext.get("networkState") !== "delete" && sources && sources.length > 0) {
        var payload = {
            "tunnel": {
                "@": {
                    "nsp-model:sources": sources
                }
            }
        };
       /* var patchRequest = this.nspMediator.patch("https://restconf-gateway:443/restconf/data/ietf-te:te/tunnels/tunnel=" + requestContext.get("originalTarget") + "?nsp-persist-only", payload);
        if (!patchRequest.success) {
            throw new RuntimeException('Patch request to add source failed' + JSON.stringify(patchRequest.response));
        }*/
    }
    return nfmpTunnelId;
};

NSPInstance.prototype.nfmpAddSource = function (deviceId, requestContext, nfmpTunnelId) {
    var type = this.nfmpCreateGlobalPool(deviceId, requestContext);
    nfmpTunnelId[deviceId] = this.getNextTunnelId(deviceId, type, requestContext);
    var sources = null;
    this.imLogger.info("[preDeploy] Found NFMP instance  nfmpTunnelId {}", nfmpTunnelId);
    if (nfmpTunnelId[deviceId]) {
        sources = "fdn:realm:sam:lsp:from-" + deviceId + "-id-" + nfmpTunnelId[deviceId];
    } else {
        throw new RuntimeException('NSP NFMP Source not found for ' + deviceId);
    }
    return sources;
};

NSPInstance.prototype.mdmAddSource = function (requestContext, deviceId) {
    this.imLogger.info("[preDeploy] Found MDM instance");
    var templateMappings = new MDMInstance().getDeviceTemplate(deviceId, requestContext);
    var sources = null;
    this.imLogger.info("[mdmAddSource] templateMappings {}", JSON.stringify(templateMappings));
    if (templateMappings["tunnelSource"]) {
        sources = templateMappings["tunnelSource"];
    } else {
        throw new RuntimeException('NSP MDM Source not found for ' + deviceId);
    }
    return sources;
};

NSPInstance.prototype.nfmpCreateGlobalPool = function (deviceId, requestContext) {
    var start = this.nfmpStartTunneldRsvp;
    var end = this.nfmpEndTunneldRsvp;
    var type = "rsvp";
    if (requestContext.get("intentConfigJson")["signaling-type"] === "path-setup-sr") {
        type = "srte";
        start = this.nfmpStartTunneldSrte;
        end = this.nfmpEndTunneldSrte;
    }
    var fetchPool = this.nspMediator.fetch("https://restconf-gateway:443/restconf/data/nsp-resource-pool:resource-pools/numeric-resource-pools=ietf-tunnel-global-id-pool,ietf_" + deviceId + "_" + type + "?depth=2");
    if (!fetchPool.success) {
        var payload = {
            "nsp-resource-pool:numeric-resource-pools": [
                {
                    "name": "ietf-tunnel-global-id-pool",
                    "scope": "ietf_" + deviceId + "_" + type,
                    "type": "nsp-resource-pool-utils:numerical",
                    "numeric-spec": {
                        "min-value": start,
                        "max-value": end
                    }
                }
            ]
        };
        var rmRequest = this.nspMediator.post("https://restconf-gateway:443/restconf/data/nsp-resource-pool:resource-pools", payload);
        if (!rmRequest.success) {
            throw new RuntimeException('Resource manager pool creation failed ' + JSON.stringify(rmRequest.response));
        }
    }
    return type;
};

NSPInstance.prototype.getNextTunnelId = function (deviceId, type, requestContext) {
    var tunnelId = null;
    var count = 0;
    while (!tunnelId) {
        var response = this.nspMediator.post("https://restconf-gateway:443/restconf/data/nsp-resource-pool:resource-pools/numeric-resource-pools=ietf-tunnel-global-id-pool,ietf_" + deviceId + "_" + type + "/obtain-value-from-pool", {
            "nsp-resource-pool:input": {
                "total-number-of-resources": 1,
                "all-or-nothing": true,
                "owner": "tunnelietfid",
                "confirmed": true
            }
        });
        if (!response.success || count === 5) {
            this.imLogger.error("[RestconfFwk][createService] Failed to get tunnelId : {}", JSON.stringify(response));
            throw new RuntimeException("Failed to populate svcMgrId");
        } else {
            this.imLogger.debug("[RestconfFwk][createService] Successfully got tunnelId");
        }
        if (response["response"]) {
            tunnelId = response["response"]["nsp-resource-pool:output"]["num-consumed-resources"][0]["value"];
            var nfmpPayload = {
                "fullClassName": "mpls.Lsp",
                "filter": {
                    "equal": {
                        "name": "objectFullName",
                        "value": "lsp:from-" + requestContext.get("sourceNodeId")[deviceId] + "-id-" + tunnelId
                    }
                },
                "resultFilter": {
                    "attribute": [
                        "objectFullName"
                    ],
                    "children": {}
                }
            };
            //var nfmpFwk = new MediatorFramework("NFMP");
            var nfmpFwk = ietfUtils.getNfmpMediator(requestContext.get("sourceNodeId")[deviceId]);
            var serviceFetch = nfmpFwk.post("/v3/search", nfmpPayload);
            this.imLogger.info("*****************serviceFetch == {}",JSON.stringify(serviceFetch));
            if (serviceFetch.success && serviceFetch.response && !(JSON.stringify(serviceFetch.response) === "{}" || JSON.stringify(serviceFetch.response).indexOf("does not exist") !== -1)) {
                this.imLogger.error("[RestconfFwk][createService] tunnelId : lsp:from-{}-id-{} is already in use. Fetching next number", deviceId, tunnelId);
                tunnelId = null;
                count++;
            }
        }
    }

    return tunnelId;

};
