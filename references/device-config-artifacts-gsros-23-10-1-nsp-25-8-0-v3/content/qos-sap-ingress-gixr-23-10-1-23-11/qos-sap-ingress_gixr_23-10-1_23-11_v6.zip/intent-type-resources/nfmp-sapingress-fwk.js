var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});


function NfmpSapIngress() {
    var util = new utilities();
    var mapFwk = new MapFwk();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var savedObjects;
    var currentObjects;
    var isAudit = false;
    var isLocalExists = false;
    var isGlobalExists = false;
    var distribute_url = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true"

    this.synchronize = function (input, result, intentTypeName, xpath, initialPropertyName, uniqueIdentifier) {

        if (input.getNetworkState().name() == "delete") {
            return this.syncDelete(input, result);
        }

        var savedTopology = input.getCurrentTopology();
        logger.info(savedTopology);
        savedObjects = {};
        currentObjects = {};
        //loading the saved objects from topology
        this.loadSavedObjectsFromTopology(savedTopology);
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyId = this.getSapIngressPolicyId(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
        if (!intentConfig) {
            intentConfig = Object.create({});
        }
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());
        intentConfig["policy-id"] = parseInt(policyId);
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target sap-ingress = " + intentConfig[uniqueIdentifier]);

        this.createOrModify(target, intentConfig, intentConfig[uniqueIdentifier]);
        var currentTopo = this.loadCurrentObjectsToTopology(target);

        result = util.setSuccessResult(result, currentTopo);
        return result;
    }

    this.syncDelete = function (input, result) {
        var className = "aingr.Policy";
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyId = this.getSapIngressPolicyId(input.getTarget());
        var policyName = this.getSapIngressPolicyName(input.getTarget());
        var objectFullName = "network:" + neId + ":Access Ingress:" + policyId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        var searchPayLoad = this.constructSearchString(className, objectFullName);
        var searchResponse = nfmpFwk.find(neId, searchPayLoad);
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0)) {
            if (!(searchResponse.success))
                logger.info("[NFMP-SAPINGRESS-FWK] syncDelete(): Unable to get Policy info from nfm-p for policy with Name:" + policyName + " and Id:" + policyId + " on " + neId);
            if (JSON.parse(searchResponse["response"]).length === 0)
                logger.info("[NFMP-SAPINGRESS-FWK] syncDelete(): There is no sap-ingress policy with Name:" + policyName + " and Id:" + policyId + " on " + neId);
            result.setSuccess(false);
            return;
        }
        logger.info("[NFMP-SAPINGRESS-FWK] syncDelete(): Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success) {
            logger.info("[NFMP-SAPINGRESS-FWK] syncDelete(): Unable to Delete: " + deleteResult.msg);
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }

    // code to handle sync

    this.audit = function (target, config, svcTopo, adminState, auditReport, intentTypeName, xpath, initialPropertyName, uniqueIdentifier) {

        var savedTopology = svcTopo;
        savedObjects = {};
        currentObjects = {};
        isAudit = true;
        var policyId = this.getSapIngressPolicyId(target);
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
        if (!intentConfig) {
            intentConfig = Object.create({});
        }
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        intentConfig["policy-id"] = parseInt(policyId);
        var target = parseTarget.getNeIdFromTarget(target);
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target sap-ingress = " + intentConfig[uniqueIdentifier]);

        if (intentConfig) {
            this.auditAndCompare(target, intentConfig, auditReport);
        } else {
            throw "configuration not available in the intent";
        }

        return auditReport
    }

    this.auditAndCompare = function (target, intentConfig, auditReport) {

        var sapIngressPayload = this.createPolicyLevelPayLoad(target, intentConfig, true, null,true);
        var result = this.auditRequest(target, sapIngressPayload);
        auditReport = util.reportMisaligned(target, result, auditReport);
        return auditReport;

    }

    this.auditRequest = function (target, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;

    }


    this.createOrModify= function(neId, intentConfig,uniqueIdentifier) {
        var fullClassName = "aingr.Policy";
        var objectFullName = "Access Ingress:" + intentConfig["policy-id"];
        var localPolicyFullName = "network:"+neId+":Access Ingress:" + intentConfig["policy-id"];
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        var localPolicy = util.getIfObjectExists(fullClassName, localPolicyFullName);
        var result;
        var sapIngressPayload;
        var distributePayload;
        var distributeResult;
        if (localPolicy != null) {
            isLocalExists = true;
            isGlobalExists = true;
            if (localPolicy[0]["policyName"] !== uniqueIdentifier) {
                throw new RuntimeException("Already there exists a policy on " + neId +
                    " with policy name " + localPolicy[0]["policyName"] + " with policy ID " + intentConfig["policy-id"]);
            }
            sapIngressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, isLocalExists, localPolicy);
            result = this.modifyRequest(neId, sapIngressPayload);
            if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                throw new RuntimeException('Unable to Create/Distribute Policy: ' + intentConfig["policy-id"] +
                    " , Kindly check the intent configuration");
            }
        }
        else {
            logger.info(LOG_PREFIX + "####### Unable to find the local policy, Trying to fetch global policy if available ######");
            var searchPayload = this.constructSearchString(fullClassName, objectFullName);
            var searchResponse = nfmpFwk.find(neId, searchPayload);
            if (!(searchResponse.success && JSON.stringify(searchResponse.response) === "")) {
                if (!searchResponse.success) {
                    logger.info(LOG_PREFIX + "createOrModify(): Unable to get Policy info from nfm-p for Ne " +
                        neId + " and Policy name: " + uniqueIdentifier);
                }
                if (searchResponse.response === "") {
                    logger.info(LOG_PREFIX + "createOrModify(): There is no sap-ingress policy with Name:" +
                        uniqueIdentifier + " on " + neId);
                }
            }
            else {
                throw new RuntimeException("createOrModify(): There exists a sap-ingress policy " + uniqueIdentifier + " on " +
                    neId + " with ID " +intentConfig["policy-id"]);
            }

            var globalPolicy = util.getIfObjectExists(fullClassName, objectFullName);
            if (globalPolicy != null) {
                isGlobalExists = true;
                if (globalPolicy[0]["policyName"] !== uniqueIdentifier) {
                    logger.info(LOG_PREFIX + "createOrModify(): There exists a sap-ingress global policy in NFMP with policy name " +
                        globalPolicy[0]["policyName"] + " with same policy ID " + intentConfig["policy-id"] + " on " + neId);
                    logger.info(LOG_PREFIX + "createOrModify(): Updating sap-ingress global policy name to " +
                        uniqueIdentifier + "on " + neId + " for policy " + intentConfig["policy-id"]);
                    this.updateSapIngressPolicyName(neId, objectFullName, uniqueIdentifier);
                }

                distributePayload = util.distribute(neId, objectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(neId, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                logger.info(LOG_PREFIX + "checking distribution of existing global policy was successful#######");
                if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                    throw new RuntimeException("Unable to Distribute existing Global Policy: " + uniqueIdentifier +
                        " , Kindly check the Global Policy configuration");
                }
                logger.info(LOG_PREFIX + "distribution of existing global policy was successful, updating with intent configuration ######");
                sapIngressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, true, globalPolicy);
                result = this.modifyRequest(neId, sapIngressPayload);
                if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                    throw new RuntimeException('Unable to Create/Distribute Policy: ' + uniqueIdentifier +
                        " , Kindly check the intent configuration");
                }
            }
            else {
                //distributing empty policy
                logger.info(LOG_PREFIX + "##### Unable to find the Global Policy, distributing empty policy and updating ######");
                sapIngressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, false, null);
                result = this.modifyRequest(neId, sapIngressPayload);
                distributePayload = util.distribute(neId, objectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(neId, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                //updating the local policy with intent configuration
                sapIngressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, true, null);
                result = this.modifyRequest(neId, sapIngressPayload);
            }
        }
        return result;
    }



    this.updateSapIngressPolicyName = function (target, objectFullName, policyName) {
        var fullClassName = "aingr.Policy";
        var policyFdn = "Access Ingress";
        var properties = {};

        properties["policyName"] = policyName;

        var payload = {};
        var configInfo = {};
        configInfo["containedClassProperties"] = properties;
        configInfo["objectClassName"] = fullClassName;
        payload["distinguishedName"] = policyFdn;
        payload["objectFullName"] = objectFullName,
            payload["configInfo"] = configInfo;
        var result = this.modifyRequest(target, payload);
        return result;
    }

    this.constructSearchString = function (className, objectFullName) {
        var expectedJson = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "policyName",
                    "id"
                ]
            }
        };
        return expectedJson;
    }

    this.createPolicyLevelPayLoad = function (target, intentConfig, isLocalExists, policyObject,isAudit) {

        // full class name for port and ethernet are same
        var fullClassName = "aingr.Policy";
        // portlevel and ethernet level attributes have the same fdn
        var policyFdn = "Access Ingress";
        // objectFullName is same as fdn for port level
        var objectFullName = "Access Ingress:" + intentConfig["policy-id"];
        var localPolicyFullName = "network:" + target + ":Access Ingress:" + intentConfig["policy-id"];
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, target);
        var deviceType = util.getIxrType(target);

        if (isLocalExists) {
            objectFullName = localPolicyFullName;
        }
        var properties = {};
        properties["id"] = intentConfig["policy-id"];
        properties["policyName"] = intentConfig["sap-ingress-policy-name"];
        properties["description"] = intentConfig["description"];
        properties["scope"] = intentConfig["scope"];
        properties["ingClassificationPolicy"] = intentConfig["ingress-classification-policy"];
        properties["policerAllocation"]=util.nfmpPolicerAllocation(intentConfig["policer-allocation"]);
        var macFilterEntryPayload = [];
        var childProperties = {};
        if (isLocalExists) {
            if (intentConfig["mac-criteria"]) {
              properties["macCritType"]= util.transformGFCriteriaType(intentConfig["mac-criteria"]["type"]);
              if(intentConfig["mac-criteria"]["entry"]){
                if (!Array.isArray(intentConfig["mac-criteria"]["entry"])) {
                    intentConfig["mac-criteria"]["entry"] = [intentConfig["mac-criteria"]["entry"]];
                }
                for (var index in intentConfig["mac-criteria"]["entry"]) {
                    var intentMacFilterEntryConfig = intentConfig["mac-criteria"]["entry"][index];
                    var entryObjectFullName = objectFullName + ":" + "entry-" + intentMacFilterEntryConfig["entry-id"];
                    mapFwk.set(currentObjects, entryObjectFullName, entryObjectFullName);
                    var entryPayload = this.createMacCriteriaEntryPayLoad(target, intentMacFilterEntryConfig);
                    macFilterEntryPayload.push(entryPayload);
                }
                childProperties["aingr.MacMatch"] = macFilterEntryPayload;
                }else{
                   childProperties["aingr.MacMatch"] = [];
                }
            }
            if (intentConfig["ip-criteria"]){
              if(!deviceType["type"].startsWith("7250 IXR-6") || !deviceType["type"].startsWith("7250 IXR-10") || !deviceType["type"].startsWith("7250 IXR-R6") || !deviceType["type"].startsWith("7250 IXR-R4") || !deviceType["type"].startsWith("7250 IXR-s") || !deviceType["type"].startsWith("7250 IXR-ec") || !deviceType["type"].startsWith("7250 IXR-e")){
                 properties["ipCritType"]= util.transformGFCriteriaType(intentConfig["ip-criteria"]["type"]);
              }
              if(intentConfig["ip-criteria"]["entry"]){
                if(!Array.isArray(intentConfig["ip-criteria"]["entry"])){
                    intentConfig["ip-criteria"]["entry"] = [intentConfig["ip-criteria"]["entry"]];
                }
                var IpCriteriaEntryPayload = [];
                for(var index in intentConfig["ip-criteria"]["entry"]){
                    var intentIpCriteriaEntryConfig = intentConfig["ip-criteria"]["entry"][index];
                    var entryObjectFullName = objectFullName+":"+"entry-"+intentIpCriteriaEntryConfig["entry-id"];
                    //keeping key and value same as object full name of the queue
                    mapFwk.set(currentObjects,entryObjectFullName,entryObjectFullName);
                    var entryPayload = this.createIPCriteriaEntryPayLoad(target,intentIpCriteriaEntryConfig,isAudit);
                    IpCriteriaEntryPayload.push(entryPayload);
                }
                childProperties["aingr.IpMatch"] = IpCriteriaEntryPayload;
               }else{
                  childProperties["aingr.IpMatch"] = [];
               }
            }
            if (intentConfig["ipv6-criteria"]){
              if(!deviceType["type"].startsWith("7250 IXR-6") || !deviceType["type"].startsWith("7250 IXR-10") || !deviceType["type"].startsWith("7250 IXR-R6") || !deviceType["type"].startsWith("7250 IXR-R4") || !deviceType["type"].startsWith("7250 IXR-s") || !deviceType["type"].startsWith("7250 IXR-ec") || !deviceType["type"].startsWith("7250 IXR-e")){
                     properties["ipv6CritType"]= util.transformGFCriteriaType(intentConfig["ipv6-criteria"]["type"]);
              }
              if(intentConfig["ipv6-criteria"]["entry"]){
                if(!Array.isArray(intentConfig["ipv6-criteria"]["entry"])){
                    intentConfig["ipv6-criteria"]["entry"] = [intentConfig["ipv6-criteria"]["entry"]];
                }
                var Ipv6CriteriaEntryPayload = [];
                for(var index in intentConfig["ipv6-criteria"]["entry"]){
                    var intentIpv6CriteriaEntryConfig = intentConfig["ipv6-criteria"]["entry"][index];
                    var entryObjectFullName = objectFullName+":"+"entry-"+intentIpv6CriteriaEntryConfig["entry-id"];
                    //keeping key and value same as object full name of the queue
                    mapFwk.set(currentObjects,entryObjectFullName,entryObjectFullName);
                    var entryPayload = this.createIpv6CriteriaEntryPayLoad(target,intentIpv6CriteriaEntryConfig);
                    Ipv6CriteriaEntryPayload.push(entryPayload);
                }
                childProperties["aingr.Ipv6Match"] = Ipv6CriteriaEntryPayload;
               }else{
                  childProperties["aingr.Ipv6Match"] = [];
               }
            }
            if (!deviceType["type"].startsWith("7250 IXR-x") && !deviceType["type"].startsWith("7250 IXR-x3") && !deviceType["type"].startsWith("7250 IXR-x1") && !deviceType["type"].startsWith("7250 IXR-R6d") && !deviceType["type"].startsWith("7250 IXR-R6dl") && !deviceType["type"].startsWith("7250 IXR-e2")) {
                if (intentConfig["fc"]) {
                    if (!Array.isArray(intentConfig["fc"])) {
                        intentConfig["fc"] = [intentConfig["fc"]];
                    }
                    var forwardingClassPayload = [];
                    for (var index in intentConfig["fc"]) {
                        var intentForwardingClassConfig = intentConfig["fc"][index];
                        var forwardClassPayload = this.createForwardingClassPayLoad(target, intentForwardingClassConfig, intentConfig);
                        forwardingClassPayload.push(forwardClassPayload);
                    }
                    childProperties["aingr.ForwardingClass"] = forwardingClassPayload;
                }
            }
            if(((intentConfig["policer-allocation"]!=="none" && intentConfig["policer-allocation"]!==undefined) && (deviceType["type"].startsWith("7250 IXR-x") || deviceType["type"].startsWith("7250 IXR-x3") || deviceType["type"].startsWith("7250 IXR-x1") || deviceType["type"].startsWith("7250 IXR-R6d") || deviceType["type"].startsWith("7250 IXR-R6dl") || deviceType["type"].startsWith("7250 IXR-e2"))) || !(deviceType["type"].startsWith("7250 IXR-x") || deviceType["type"].startsWith("7250 IXR-x3") || deviceType["type"].startsWith("7250 IXR-x1") || deviceType["type"].startsWith("7250 IXR-R6d") || deviceType["type"].startsWith("7250 IXR-R6dl") || deviceType["type"].startsWith("7250 IXR-e2"))){
                if (intentConfig["policer"]) {
                    if (!Array.isArray(intentConfig["policer"])) {
                        intentConfig["policer"] = [intentConfig["policer"]];
                    }
                    var policerPayload = [];
                    for (var index in intentConfig["policer"]) {
                        var intentPolicerConfigerations = intentConfig["policer"][index];
                        var entryPayload = this.createPolicerPayload(target, intentPolicerConfigerations);
                        policerPayload.push(entryPayload);
                    }
                    childProperties["aingr.Policer"] = policerPayload;
                } else {
                    childProperties["aingr.Policer"] = [];
                }
           }
        }
        var EntryLevelPayload = util.editPayload(policyFdn, properties, childProperties, fullClassName, objectFullName);
        return EntryLevelPayload;
    }

    this.createMacCriteriaEntryPayLoad = function (target, intentMacCriteriaEntryConfig) {
        var fullClassName = "aingr.MacMatch";
        var properties = {};
        if (intentMacCriteriaEntryConfig) {
            properties["id"] = intentMacCriteriaEntryConfig["entry-id"];
            properties["description"] = intentMacCriteriaEntryConfig["description"];
            if (intentMacCriteriaEntryConfig["match"]) {
                properties["frameType"] = util.transformNfmpProtocol(intentMacCriteriaEntryConfig["match"]["frame-type"]);
                if (intentMacCriteriaEntryConfig["match"]["src-mac"] !== undefined || intentMacCriteriaEntryConfig["match"]["src-mac"] === undefined) {
                    if (intentMacCriteriaEntryConfig["match"]["src-mac"] !== undefined) {
                        properties["sourceMacAddress"] = util.nfmpValidMacAddress(intentMacCriteriaEntryConfig["match"]["src-mac"]["address"]);
                        properties["sourceMacAddressMask"] = util.nfmpValidMacAddress(intentMacCriteriaEntryConfig["match"]["src-mac"]["mask"]);
                    } else {
                        var srcMacDefaultValue = "00-00-00-00-00-00";
                        properties["sourceMacAddress"] = srcMacDefaultValue;
                        properties["sourceMacAddressMask"] = srcMacDefaultValue;

                    }
                }
                if (intentMacCriteriaEntryConfig["match"]["dst-mac"] !== undefined || intentMacCriteriaEntryConfig["match"]["dst-mac"] === undefined) {
                    if (intentMacCriteriaEntryConfig["match"]["dst-mac"] !== undefined) {
                        properties["destinationMacAddress"] = util.nfmpValidMacAddress(intentMacCriteriaEntryConfig["match"]["dst-mac"]["address"]);
                        properties["destinationMacAddressMask"] = util.nfmpValidMacAddress(intentMacCriteriaEntryConfig["match"]["dst-mac"]["mask"]);
                    } else {
                        var dstMacDefaultValue = "00-00-00-00-00-00";
                        properties["destinationMacAddress"] = dstMacDefaultValue;
                        properties["destinationMacAddressMask"] = dstMacDefaultValue;
                    }

                }
                if (intentMacCriteriaEntryConfig["match"]["etype"] !== undefined) {
                    properties["ethernetType"] = parseInt(intentMacCriteriaEntryConfig["match"]["etype"]);
                } else {
                    properties["ethernetType"] = -1;
                }
                if (intentMacCriteriaEntryConfig["match"]["dot1p"] !== undefined || intentMacCriteriaEntryConfig["match"]["dot1p"] === undefined) {
                    if (intentMacCriteriaEntryConfig["match"]["dot1p"] !== undefined) {
                        properties["dot1pValue"] = util.nfmpDot1p(intentMacCriteriaEntryConfig["match"]["dot1p"]["priority"]);
                        properties["dot1pMask"] = util.nfmpDot1p(intentMacCriteriaEntryConfig["match"]["dot1p"]["mask"]);
                    } else {
                        properties["dot1pValue"] = "default";
                        properties["dot1pMask"] = "priority_0";
                    }
                }
            }
            if (intentMacCriteriaEntryConfig["action"]) {
                if (intentMacCriteriaEntryConfig["action"]["fc"]) {
                    properties["forwardingClass"] = intentMacCriteriaEntryConfig["action"]["fc"];
                }
            }
        }
        return properties;
    }

    this.createIPCriteriaEntryPayLoad = function(target,intentIpCriteriaEntryConfig,isAudit){

        var fullClassName = "aingr.IpMatch";
        var properties = {};
        var deviceType = util.getIxrType(target);
        properties["id"] = intentIpCriteriaEntryConfig["entry-id"];
        properties["description"] = intentIpCriteriaEntryConfig["description"];
        if(intentIpCriteriaEntryConfig["match"])
        {
            if(intentIpCriteriaEntryConfig["match"]["dscp"])
            {
                properties["dscp"] = intentIpCriteriaEntryConfig["match"]["dscp"];
            }
            if(intentIpCriteriaEntryConfig["match"]["src-ip"]) {
                if (intentIpCriteriaEntryConfig["match"]["src-ip"]["address"]) {
                    properties["sourceIpAddress"] = (intentIpCriteriaEntryConfig["match"]["src-ip"]["address"]).split("/")[0];
                }
                if (intentIpCriteriaEntryConfig["match"]["src-ip"]["address"] && (intentIpCriteriaEntryConfig["match"]["src-ip"]["address"]).split("/")[1] !== undefined) {
                    if(!isAudit || intentIpCriteriaEntryConfig["match"]["src-ip"]["mask"]===undefined){
                        properties["sourceIpAddressMask"] = util.gfNfmpIpAddressMask((intentIpCriteriaEntryConfig["match"]["src-ip"]["address"]).split("/")[1]);
                    }
                } else if ((!deviceType["type"].startsWith("7250 IXR-x") && !deviceType["type"].startsWith("7250 IXR-x3") && !deviceType["type"].startsWith("7250 IXR-x1") && !deviceType["type"].startsWith("7250 IXR-R6d") && !deviceType["type"].startsWith("7250 IXR-R6dl") && !deviceType["type"].startsWith("7250 IXR-e2")) &&  (intentIpCriteriaEntryConfig["match"]["src-ip"]["address"]).split("/")[0]!==undefined && (intentIpCriteriaEntryConfig["match"]["src-ip"]["address"]).split("/")[1]===undefined && intentIpCriteriaEntryConfig["match"]["src-ip"]["mask"]===undefined) {
                    properties["sourceIpAddressMask"] = "ipAddrMask32"
                }
                if (intentIpCriteriaEntryConfig["match"]["src-ip"]["mask"]) {
                    properties["sourceIpAddressFullMask"] = intentIpCriteriaEntryConfig["match"]["src-ip"]["mask"];
                    if(!isAudit){
                        properties["sourceIpAddressMask"] = "ipAddrMask0";
                    }
                }else if(!isAudit){
                    properties["sourceIpAddressFullMask"] ="0.0.0.0";
                }
            }
            if(intentIpCriteriaEntryConfig["match"]["dst-ip"]) {
                if (intentIpCriteriaEntryConfig["match"]["dst-ip"]["address"]) {
                    properties["destinationIpAddress"] = intentIpCriteriaEntryConfig["match"]["dst-ip"]["address"].split("/")[0];
                }
                if (intentIpCriteriaEntryConfig["match"]["dst-ip"]["address"] && (intentIpCriteriaEntryConfig["match"]["dst-ip"]["address"]).split("/")[1] !== undefined) {
                    if(!isAudit || intentIpCriteriaEntryConfig["match"]["dst-ip"]["mask"]===undefined){
                        properties["destinationIpAddressMask"] = util.gfNfmpIpAddressMask((intentIpCriteriaEntryConfig["match"]["dst-ip"]["address"]).split("/")[1]);
                    }
                }else if ((!deviceType["type"].startsWith("7250 IXR-x") && !deviceType["type"].startsWith("7250 IXR-x3") && !deviceType["type"].startsWith("7250 IXR-x1") && !deviceType["type"].startsWith("7250 IXR-R6d") && !deviceType["type"].startsWith("7250 IXR-R6dl") && !deviceType["type"].startsWith("7250 IXR-e2")) &&  (intentIpCriteriaEntryConfig["match"]["dst-ip"]["address"]).split("/")[0]!==undefined && (intentIpCriteriaEntryConfig["match"]["dst-ip"]["address"]).split("/")[1]===undefined && intentIpCriteriaEntryConfig["match"]["dst-ip"]["mask"]===undefined) {
                    properties["destinationIpAddressMask"] = "ipAddrMask32";
                }
                if (intentIpCriteriaEntryConfig["match"]["dst-ip"]["mask"]) {
                    properties["destinationIpAddressFullMask"] = intentIpCriteriaEntryConfig["match"]["dst-ip"]["mask"];
                    if(!isAudit){
                        properties["destinationIpAddressMask"] = "ipAddrMask0";
                    }
                }else if(!isAudit){
                    properties["destinationIpAddressFullMask"]="0.0.0.0";
                }
            }
            if (intentIpCriteriaEntryConfig["match"]["src-port"]) {
                if (intentIpCriteriaEntryConfig["match"]["src-port"]["eq"]) {
                    properties["sourceOperator"] = "EQUAL";
                    properties["sourcePort1"] =  intentIpCriteriaEntryConfig["match"]["src-port"]["eq"];
                }
            }

            if (intentIpCriteriaEntryConfig["match"]["dst-port"]) {
                if (intentIpCriteriaEntryConfig["match"]["dst-port"]["eq"]) {
                    properties["destinationOperator"] = "EQUAL";
                    properties["destinationPort1"] =  intentIpCriteriaEntryConfig["match"]["dst-port"]["eq"];
                }
            }
        }
        if (intentIpCriteriaEntryConfig["action"]) {
            if (intentIpCriteriaEntryConfig["action"]["fc"]) {
                properties["forwardingClass"] =intentIpCriteriaEntryConfig["action"]["fc"];
            }
        }
        return properties;
    }

    this.createIpv6CriteriaEntryPayLoad = function(target, intentIPv6CriteriaEntryConfig){
        var properties = {};
        var fullClassName = "aingr.Ipv6Match";
        var deviceType = util.getIxrType(target);
        properties["id"] = intentIPv6CriteriaEntryConfig["entry-id"];
        properties["description"] = intentIPv6CriteriaEntryConfig["description"];
        if (intentIPv6CriteriaEntryConfig["match"]) {
            if (intentIPv6CriteriaEntryConfig["match"]["src-ip"]) {
                if (intentIPv6CriteriaEntryConfig["match"]["src-ip"]["address"]) {
                    properties["sourceIpAddress"] = util.expandIPv6Address((intentIPv6CriteriaEntryConfig["match"]["src-ip"]["address"]).split("/")[0]);
                }
                if (intentIPv6CriteriaEntryConfig["match"]["src-ip"]["address"] && intentIPv6CriteriaEntryConfig["match"]["src-ip"]["address"].split("/")[1] !== undefined) {
                    properties["sourceIpAddressMask"] = (intentIPv6CriteriaEntryConfig["match"]["src-ip"]["address"]).split("/")[1];
                } else if (!deviceType["type"].startsWith("7250 IXR-x") && !deviceType["type"].startsWith("7250 IXR-x3") && !deviceType["type"].startsWith("7250 IXR-x1") && !deviceType["type"].startsWith("7250 IXR-R6d") && !deviceType["type"].startsWith("7250 IXR-R6dl") && !deviceType["type"].startsWith("7250 IXR-e2")) {
                    properties["sourceIpAddressMask"] = "0";
                }
                if (intentIPv6CriteriaEntryConfig["match"]["src-ip"]["mask"]) {
                    properties["sourceIpAddressFullMask"] = util.expandIPv6Address(intentIPv6CriteriaEntryConfig["match"]["src-ip"]["mask"]);
                }
            }
            if (intentIPv6CriteriaEntryConfig["match"]["dst-ip"]) {
                if (intentIPv6CriteriaEntryConfig["match"]["dst-ip"]["address"]) {
                    properties["destinationIpAddress"] = util.expandIPv6Address((intentIPv6CriteriaEntryConfig["match"]["dst-ip"]["address"]).split("/")[0]);
                }
                if (intentIPv6CriteriaEntryConfig["match"]["dst-ip"]["address"] && (intentIPv6CriteriaEntryConfig["match"]["dst-ip"]["address"]).split("/")[1] !== undefined) {
                    properties["destinationIpAddressMask"] = (intentIPv6CriteriaEntryConfig["match"]["dst-ip"]["address"]).split("/")[1];
                } else if (!deviceType["type"].startsWith("7250 IXR-x") && !deviceType["type"].startsWith("7250 IXR-x3") && !deviceType["type"].startsWith("7250 IXR-x1") && !deviceType["type"].startsWith("7250 IXR-R6d") && !deviceType["type"].startsWith("7250 IXR-R6dl") && !deviceType["type"].startsWith("7250 IXR-e2")) {
                    properties["destinationIpAddressMask"] = "0";
                }
                if (intentIPv6CriteriaEntryConfig["match"]["dst-ip"]["mask"]) {
                    properties["destinationIpAddressFullMask"] = util.expandIPv6Address(intentIPv6CriteriaEntryConfig["match"]["dst-ip"]["mask"]);
                }
            }
        }

        if (intentIPv6CriteriaEntryConfig["action"]) {
            if (intentIPv6CriteriaEntryConfig["action"]["fc"] !== undefined) {
                properties["forwardingClass"] = intentIPv6CriteriaEntryConfig["action"]["fc"];
            }
        }
        return properties;
    }

    this.createPolicerPayload = function (target, intentPolicerPayloadConfig) {
        var fullClassName = "aingr.Policer";
        var properties = {};
        properties["id"] = intentPolicerPayloadConfig["policer-id"];
        properties["description"] = intentPolicerPayloadConfig["description"];
        if (intentPolicerPayloadConfig["stat-mode"]) {
            if (intentPolicerPayloadConfig["stat-mode"] == "no-stats") {
                properties["statsMode"] = "noStats";
            } else if (intentPolicerPayloadConfig["stat-mode"] == "offered-profile-with-discards") {
                properties["statsMode"] = "offeredProfileWithDiscards";
            }
        }
        if (intentPolicerPayloadConfig["mbs"] === "auto") {
            properties["mbs"] = -1;
        } else {
            properties["mbs"] = intentPolicerPayloadConfig["mbs"];
        }
        if (intentPolicerPayloadConfig["cbs"] === "auto") {
            properties["cbs"] = -1;
        } else {
            properties["cbs"] = intentPolicerPayloadConfig["cbs"];
        }
        if (intentPolicerPayloadConfig["rate"] !== undefined) {
            if (intentPolicerPayloadConfig["rate"]["pir"] === "max") {
                properties["adminPir"] = -1;
            } else if (intentPolicerPayloadConfig["rate"]["pir"] !== undefined) {
                properties["adminPir"] = intentPolicerPayloadConfig["rate"]["pir"];
            }
            if (intentPolicerPayloadConfig["rate"]["cir"] === "max") {
                properties["adminCir"] = -1;
            } else if (intentPolicerPayloadConfig["rate"]["cir"] !== undefined) {
                properties["adminCir"] = intentPolicerPayloadConfig["rate"]["cir"];
            }
        }
        if (intentPolicerPayloadConfig["adaptation-rule"]) {
            if (intentPolicerPayloadConfig["adaptation-rule"]["pir"]) {
                properties["pirAdaptation"] = intentPolicerPayloadConfig["adaptation-rule"]["pir"];
            }
            if (intentPolicerPayloadConfig["adaptation-rule"]["cir"]) {
                properties["cirAdaptation"] = intentPolicerPayloadConfig["adaptation-rule"]["cir"];
            }
        }
        return properties;
    }

    this.createForwardingClassPayLoad = function (target, forwardingClassConfig, intentConfig) {

        var fullClassName = "aingr.ForwardingClass";
        var properties = {};

        if (forwardingClassConfig["fc-name"]) {
            properties["forwardingClass"] = forwardingClassConfig["fc-name"];
        }
        if(forwardingClassConfig["unknown-policer"]){
            properties["unknownPolicerId"]=forwardingClassConfig["unknown-policer"];
        }
        if(forwardingClassConfig["multicast-policer"]){
            properties["multicastPolicerId"]=forwardingClassConfig["multicast-policer"];
        }
        if(forwardingClassConfig["broadcast-policer"]){
            properties["broadcastPolicerId"]=forwardingClassConfig["broadcast-policer"];
        }
        return properties;
    }

    /*
      function: getSapIngressPolicyName
      description: Getting the Policy Name from target.
      */
    this.getSapIngressPolicyName = function(target){

        //write code here
        var policyName = target.split("#")[2];
        return policyName;

    };

    /*
    function: getSapIngressPolicyId
    description: Getting the Policy id from target.
    */
    this.getSapIngressPolicyId = function(target){

        //write code here
        var policyId = target.split("#")[3];
        return policyId;

    };

    this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }

    this.loadSavedObjectsFromTopology = function (savedTopology) {
        if (savedTopology) {
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0) {
                topoObjects.forEach(function (topoObject) {
                    mapFwk.set(savedObjects, topoObject.getObjectType(), topoObject.getObjectRelativeObjectID());
                });
            }
        }

    }

    this.loadCurrentObjectsToTopology = function (target) {

        var currentTopo = topologyFactory.createServiceTopology();
        if (Object.keys(currentObjects).length) {
            for (var key in currentObjects) {
                objectId = mapFwk.get(currentObjects, key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key, objectId, "INFRASTRUCTURE", target, ""));
            }
        }
        return currentTopo;

    }

    this.modifyRequest = function (target, payload) {

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
               logger.error("Error result = {}",JSON.stringify(result));
               let errorMsg = result.msg;
               if(errorMsg.indexOf("object already exists") !== -1)
               {
                   logger.info("Global policy Object already exists, Re-checking the Policy existence ");
                   //util.delay(2000);
                   let configInfo = payload.configInfo;
                   let fullClassName;
                   for (let key in configInfo) {
                     if (configInfo.hasOwnProperty(key)) {
                       fullClassName = key;
                       break;
                     }
                   }
                   let objectFullName = payload.objectFullName;
                   objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
                   logger.info("fullClassName = {}",fullClassName);
                   logger.info("objectFullName = {}",objectFullName);
                   if (!util.isObjectExists(fullClassName, objectFullName))
                   {
                       throw new RuntimeException("Global Policy Object Not Found!!!");
                   }
               }
               else
               {
                   throw new RuntimeException(result.msg);
               }
        }
        return result;

    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }
}

