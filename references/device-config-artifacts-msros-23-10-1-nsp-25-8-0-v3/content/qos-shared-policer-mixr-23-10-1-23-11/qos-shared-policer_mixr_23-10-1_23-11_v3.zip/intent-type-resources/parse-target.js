function ParseTarget() {
  this.getNeIdFromTarget = function (target) {
    if (String(target).indexOf("ne-id") !== -1) {
      var nedId = target.split("#")[1];
      var result = nedId
        .match("ne-id='(\\d|\\.|\\w|\\:)+'")[0]
        .replace(/'/g, "")
        .split("=")[1];
      logger.info("NeId = " + result);
      return result;
    } else {
      var neid = target.split("#")[1];
      logger.info("NeId = " + neid);
      return neid;
    }
  };

  /**
   * Get the identifiers value from the target
   * @param {} target 
   * @returns array of identifiers
   */
  this.getUniqueIdentifier = function (target) {
    //the target is - temlateName#NE#identifier1#identifier2....#identifier-n
    var splittedTarget = target.split("#");
    logger.info("splittedTarget " + splittedTarget);
    let identifiersArray = [];
    for (let i = 2; i < splittedTarget.length; i++) {
      identifiersArray.push(splittedTarget[i]);
    }
    logger.info(identifiersArray)
    return identifiersArray;
  };
}
