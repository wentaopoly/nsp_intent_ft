var RuntimeException = Java.type("java.lang.RuntimeException");

var prefixToNsMap = {
    ibn: "http://www.nokia.com/management-solutions/ibn",
    nc: "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders":
        "anv-device-holders",
};

load({ script: resourceProvider.getResource("mdc-fwk.js"), name: "MdcFwk" });
const mdcFwk = new MdcFwk();

load({ script: resourceProvider.getResource("mdt-fwk.js"), name: "MdtFwk" });
var mdtFwk = new MdtFwk();

load({
    script: resourceProvider.getResource("parse-target.js"),
    name: "ParseTarget",
});
var parsedTarget = new ParseTarget();

/**
 * Load lodash and create object as underscore(_)
 */
load({
    script: resourceProvider.getResource("lodash.js"),
    name: "Lodash",
});
const _ = new Lodash();

/**
 * Load Deep-diff and create object as DeepDiff
 */
load({
    script: resourceProvider.getResource("deep-diff.js"),
    name: "DeepDiff",
});
const deepDiff = new DeepDiff();

/**
 *
 * Load and instantiate UtilFwk
 * @see UtilFwk
 */
load({
    script: resourceProvider.getResource("util-fwk.js"),
    name: "UtilFwk",
});
const utilFwk = new UtilFwk();

/**
 *
 * Load and instantiate ICMFwk
 * It contain ICM framework specific functions
 *
 * @see ICMFwk
 */
load({ script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk" });
const icmFwk = new ICMFwk();

/**
 * Load and instance IcmServiceFwk
 *
 * @see GtdFWk
 */
load({
    script: resourceProvider.getResource("icm-service-fwk.js"),
    name: "icm-service-fwk",
});
const icmServiceFwk = new IcmServiceFwk();

/**
 *
 */
load({
    script: resourceProvider.getResource('mdSuggest.js'),
    name: "MdSuggest"
});
var mdSuggest = new MdSuggest();

/**
 *
 */
load({
    script: resourceProvider.getResource("parse-target.js"),
    name: "ParseTarget",
});
var parsedTarget = new ParseTarget();

load({
    script: resourceProvider.getResource("common-utils.js"),
    name: "CommonUtil",
});

load({
    script: resourceProvider.getResource("custom-hooks.js"),
    name: "CustomHooks",
});

const customHooks = new CustomHooks();
var commonUtil = new CommonUtil();

const metadata = JSON.parse(resourceProvider.getResource("meta-data.json"));

var intentTypeName = 'port-eth_mixr_23-10-1_24-4';

/**
 * The node which you would like to configure.
 * example port, sap-ingress etc.
 * In the intent-yang, you will see this as a container
 * which encapsulates all the different type of nodes
 */
var intentContainer = 'port';

var deviceYangModuleName = 'nokia-conf';

// unique identifier
var uniqueIdentifier = 'port-id';

// example "configure" , "configure/qos" etc..
var rootXPath = 'configure';
var LOG_PREFIX_PORT = "[PORT]: "

/**
 *
 * @param {*} input
 */
function validate(input) {
    logger.info("--------------Intent validate --------------");
    var config = formatConfig(input.getJsonIntentConfiguration());
    logger.info("config " + config);
}

/**
 *
 * This function is starting point by IM for sync operation
 *
 * @param {*} input
 * @returns
 */
function synchronize(input) {
    /**
     * Deployment of intents to the network, called for synchronize operations.
     * Used to apply create, update, delete and reconcile to managed devices.
     *
     * All created objects are remembered/restored as part of topology/extra-data
     * to apply house-keeping operations.
     *
     **/
    logger.info("--------------Intent Synchronisation started--------------");
    logger.info("input " + input);
    logger.info("intentTypeName " + intentTypeName);
    logger.info("rootXPath " + rootXPath);
    logger.info("intentContainer " + intentContainer);
    logger.info("uniqueIdentifier " + uniqueIdentifier);
    logger.info("deviceYangModuleName " + deviceYangModuleName);

    // TODO, so far the code is handling single intentContainer
    // but there can be multuple top level containers like the case of cpm-filter having ip-filter, ipv6-filter and mac-filter
    // format the config as per your use-case
    var config = formatConfig(input.getJsonIntentConfiguration());
    logger.info("config " + config);

    var target = input.getTarget();
    var state = input.getNetworkState().name();
    logger.info("state " + state);
    var startTime = new Date().getTime();
    var syncResult = synchronizeResultFactory.createSynchronizeResult();
    logger.info(
        intentTypeName + ":synchronize(" + target + ") in state " + state
    );
    // current topology
    var topology = input.getCurrentTopology();
    if (topology == null) {
        topology = topologyFactory.createServiceTopology();
    }
    logger.info("topology " + JSON.stringify(topology));
    var resp = utilFwk.synchronize(
        target,
        config,
        intentTypeName,
        rootXPath,
        intentContainer,
        uniqueIdentifier,
        deviceYangModuleName,
        topology,
        state,
        syncResult
    );
    var endTime = Date.now();
    var timeTaken = (endTime - startTime) / 1000; // seconds
    logger.info(
        "Time taken to synchronize " + timeTaken + " seconds for intent " + target
    );
    var endTime = Date.now();
    var timeTaken = (endTime - startTime) / 1000; // seconds
    logger.info("Time taken to synchronize " + timeTaken);
    logger.info("--------------Intent Synchronisation done--------------");
    return resp;
}

/**
 *
 * The function is starting point for audit operation in IM
 *
 * @param {*} input
 * @returns auditReport
 */
function audit(input) {
    logger.info("-------------- Intent Audit --------------");
    var startTime = new Date().getTime();
    var target = input.getTarget();
    var key = intentTypeName + ":" + intentTypeName;
    var intentConfig = JSON.parse(input.getJsonIntentConfiguration())[0][key][
        intentContainer
        ];
    var state = input.getNetworkState().name();
    var topology = input.getCurrentTopology();

    logger.info("target " + target);
    logger.info("topology " + topology);
    logger.info("state " + state);
    logger.info("intentConfig " + JSON.stringify(intentConfig));
    let auditReport = utilFwk.audit(
        target,
        intentConfig,
        topology,
        state,
        intentTypeName,
        rootXPath,
        intentContainer,
        uniqueIdentifier,
        deviceYangModuleName
    );
    var endTime = Date.now();
    var timeTaken = (endTime - startTime) / 1000; // seconds
    logger.info(
        "Time taken to audit " + timeTaken + " seconds for intent " + target
    );
    return auditReport;
}

/**
 *
 * The function is used in Brownfield disscovery by ICM FW
 * It discover the configuration from the target device
 * and manipulate as per Template's default-target-data
 *
 *
 * @see ICMFwk for more details
 * @param {*} input - the config data of a deployment
 * @returns result - the result of the operation
 */
function getTargetData(input) {
    logger.info("-------- Intent getTargetData started ------");
    logger.info(JSON.stringify(input));
    var target = input.target;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(
        target,
        deviceYangModuleName,
        rootXPath,
        intentContainer
    );
    logger.info(JSON.stringify(deviceConfig));
    var data = icmServiceFwk.gtdSend(deviceConfig);
    logger.info(JSON.stringify(data));
    logger.info(JSON.stringify(data.msg.result));
    return data.msg.result;
}

/**
 *
 * If there are multiple containers at in intent-yang for intentContainer name,
 * the config returned by the scriptEnginer is array
 *
 * @param {*} config
 * @returns
 */
const formatConfig = (config) => {
    if (Array.isArray(config)) {
        return config[0];
    } else {
        return config;
    }
};

function suggestSlopePolicyName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest SlopePolicyName Context = \n" + context);
    var neId = getNeId(context);
    var slopPolices = mdSuggest.getSlopePolicyName(neId);
    slopPolices.push("_tmnx_hs_default");
    slopPolices.push("default");
    return slopPolices;
}

function suggestAccountingPolicyId(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest AccountingPolicyId Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getAccountingPolicyId(neId);
}

function suggestEgressQueueGroupName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest EgressQueueGroupName Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getEgressQueueGroupName(neId);
}

function suggestSchedulerPolicyName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest SchedulerPolicyName Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getSchedulerPolicyName(neId);
}

function suggestHwAggShaperSchedulerPolicyName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest HwAggShaperSchedulerPolicyName Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getHwAggShaperSchedulerPolicyName(neId);
}

function suggestPortSchedulerPolicyName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest PortSchedulerPolicyName Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getPortSchedulerPolicyName(neId);
}

function suggestRadiusServerPolicyName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest RadiusServerPolicyName Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getRadiusServerPolicyName(neId);
}

function suggestNetworkQueuePolicy(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest NetworkQueuePolicy Context = \n" + context);
    var neId = getNeId(context);
    var networkQueuePolicies = mdSuggest.getNetworkQueuePolicy(neId);
    networkQueuePolicies.push("default");
    return networkQueuePolicies;
}

function suggestOperGroupName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest OperGroupName Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getOperGroupName(neId);
}

function suggestDistCpuProtectionPolicyName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest DistCpuProtectionPolicyName Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getDistCpuProtectionPolicyName(neId);
}

function suggestIngressQueueGroupName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest IngressQueueGroupName Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getIngressQueueGroupName(neId);
}

function suggestMacPolicyId(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest MacPolicyId Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getMacPolicyId(neId);
}

function suggestCaName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest CaName Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getCaName(neId);
}

function suggestRadiusPolicyName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest RadiusPolicyName Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getRadiusPolicyName(neId);
}

function suggestPortQosPolicyName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest PortQosPolicyName Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getPortQosPolicyName(neId);
}

function suggestHsPortPoolPolicyName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest HsPortPoolPolicyName Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getHsPortPoolPolicyName(neId);
}

function suggestHsSchedulerPolicyName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest HsSchedulerPolicyName Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getHsSchedulerPolicyName(neId);
}

function suggestMdAdminName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest MdAdminName Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getMdAdminName(neId);
}

function suggestPolicerControlPolicyName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest PolicerControlPolicyName Context = \n" + context);
    var neId = getNeId(context);
    return mdSuggest.getPolicerControlPolicyName(neId);
}

function suggestVlanQosPolicyName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest VlanQosPolicyName Context = \n" + context);
    var neId = getNeId(context);
    var vlanQosPolicies = mdSuggest.getVlanQosPolicyName(neId);
    vlanQosPolicies.push("default");
    return vlanQosPolicies;
}

function suggestAccessEgressQueueGroupQueueId(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest AccessEgressQueueGroupQueueId Context = \n" + context);
    var neId = getNeId(context);
    var accessEgressQueueGroupName = context.getInputValues()["arguments"]["__parent"]["queue-group-name"];
    return mdSuggest.getEgressQueueGroupQueueId(neId, accessEgressQueueGroupName);
}

function suggestAccessEgressSchedulerName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest AccessEgressSchedulerName Context = \n" + context);
    var neId = getNeId(context);
    var schedulerPolicyName = context.getInputValues()["arguments"]["__parent"]["scheduler-policy"]["policy-name"];
    return mdSuggest.getSchedulerName(neId, schedulerPolicyName);
}

function suggestAccessIngressQueueGroupQueueId(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest AccessIngressQueueGroupQueueId Context = \n" + context);
    var neId = getNeId(context);
    var accessIngressQueueGroupName = context.getInputValues()["arguments"]["__parent"]["port"]["queue-group-name"];
    return mdSuggest.getIngressQueueGroupQueueId(neId, accessIngressQueueGroupName);
}

function suggestAccessIngressSchedulerName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest AccessIngressSchedulerName Context = \n" + context);
    var neId = getNeId(context);
    var schedulerPolicyName = context.getInputValues()["arguments"]["__parent"]["scheduler-policy"]["policy-name"];
    return mdSuggest.getSchedulerName(neId, schedulerPolicyName);
}

function suggestMaAdminName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest MaAdminName Context = \n" + context);
    var neId = getNeId(context);
    var mdAdminName = context.getInputValues()["arguments"]["md-admin-name"];
    return mdSuggest.getMaAdminName(neId, mdAdminName);
}

function suggestNetworkEgressQueueGroupQueueId(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest NetworkEgressQueueGroupQueueId Context = \n" + context);
    var neId = getNeId(context);
    var networkEgressQueueGroupName = context.getInputValues()["arguments"]["__parent"]["queue-group-name"];
    return mdSuggest.getEgressQueueGroupQueueId(neId, networkEgressQueueGroupName);
}

function suggestPoolName(context) {
    logger.info(LOG_PREFIX_PORT + "Suggest PoolName Context = \n" + context);
    return ["default"];
}

function getNeId(context) {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    logger.info(target)
    if (target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    else
    {
        var arguments = JSON.parse(context.getInputValues());
        neId = neIdIterator(arguments["arguments"]);
    }
    logger.info(LOG_PREFIX_PORT + "NeId : " + neId);
    return neId;
}

function neIdIterator(context) {
    var parent = context["__parent"];
    if (parent)
    {
        var neId = parent["target_objectidentifier"];
        if (!neId)
        {
            neId = neIdIterator(parent)
        }
        return neId;
    }
}
