var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let endpointASiteId = target.split("#")[2];
        let endpointAInterfaceAddress = target.split("#")[3];
        let endpointBSiteId = target.split("#")[4];
        let endpointBInterfaceAddress = target.split("#")[5];

        let mcPeerConfig = this.getMcPeerConfiguration(endpointAInterfaceAddress, endpointBInterfaceAddress);
        let mcLagPeerSpecificsConfig = this.getMcLagPeerSpecificsConfig(endpointASiteId, endpointAInterfaceAddress, endpointBSiteId, endpointBInterfaceAddress);
        let mcLagConfig = this.getMcLagConfig(endpointASiteId, endpointAInterfaceAddress, endpointBSiteId, endpointBInterfaceAddress);
        let mcEndpointConfig = this.getMcEndpointConfig(endpointASiteId, endpointAInterfaceAddress, endpointBSiteId, endpointBInterfaceAddress);
        let mcPeerIpsecConfig = this.getMcPeerIpsecPayLoad(endpointASiteId, endpointAInterfaceAddress, endpointBSiteId, endpointBInterfaceAddress);
        let mcIpsecGrpConfig = this.getMcIpsecGrpPayLoad(endpointASiteId, endpointAInterfaceAddress, endpointBSiteId, endpointBInterfaceAddress);
        let mcSyncGrpConfig = this.getMcSyncGrpConfig(endpointASiteId, endpointAInterfaceAddress, endpointBSiteId, endpointBInterfaceAddress);
        let mcRingGrpConfig = this.getMcRingGrpConfig(endpointASiteId, endpointAInterfaceAddress, endpointBSiteId, endpointBInterfaceAddress);
        let deviceConfig = {
            "mcPeerConfig": mcPeerConfig,
            "mcLagPeerSpecificsConfig": mcLagPeerSpecificsConfig,
            "mcLagConfig": mcLagConfig,
            "mcEndpoint": mcEndpointConfig,
            "mcPeerIpsecConfig": mcPeerIpsecConfig,
            "mcIpsecGrpConfig": mcIpsecGrpConfig,
            "mcSyncGrpConfig": mcSyncGrpConfig,
            "mcRingGrpConfig": mcRingGrpConfig
        };
        logger.info("*********************************deviceConfigSTART*************************************");
        logger.info(JSON.stringify(deviceConfig));
        logger.info("*********************************deviceConfigEND*************************************");
        return deviceConfig;
    }

    this.getMcPeerConfiguration = function (endpointAInterfaceAddress, endpointBInterfaceAddress) {
        let fullClassName = "multichassis.MultiChassisPeer";
        let objectFullName = "sam-mc-peer-manager:mc-peer-" + endpointAInterfaceAddress + "-" + endpointBInterfaceAddress;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, endpointAInterfaceAddress, endpointBInterfaceAddress);
        let jsonPayLoad = {
            "fullClassName": fullClassName,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };

        let searchResponse = nfmpFwk.post("/v3/search", jsonPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find MC-Peer with End Point A Interface Id: " + endpointAInterfaceAddress + ", End Point B Interface Id: " + endpointBInterfaceAddress);
        }
        searchResponse = JSON.parse(searchResponse.response);
        logger.info("searchResponse = {}", JSON.stringify(searchResponse));
        return searchResponse;
    }

    this.getMcLagPeerSpecificsConfig = function (endpointASiteId, endpointAInterfaceAddress, endpointBSiteId, endpointBInterfaceAddress) {
        let endPointAMcLagPeerSpecificsFilter = "network:" + endpointASiteId + ":mc-peer-manager:peer-" + endpointBInterfaceAddress + ":mc-lag-spec";
        endPointAMcLagPeerSpecificsFilter = util.modifyNeIdForIpV6(endPointAMcLagPeerSpecificsFilter, endpointASiteId, endpointBInterfaceAddress);
        let fullClassName = "multichassis.MultiChassisLagPeerSpecifics";
        let jsonPayLoad = {
            "fullClassName": fullClassName,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": endPointAMcLagPeerSpecificsFilter
                }
            }
        };
        let endpointAsearchResponse = nfmpFwk.post("/v3/search", jsonPayLoad);
        if (!endpointAsearchResponse.success)
        {
            throw new RuntimeException("Failed to find MC-Lag-Peer-Specifics with ne-Id : " + endpointASiteId + ", End Point A Interface ID : " + endpointAInterfaceAddress + ", End Point B Interface ID : " + endpointBInterfaceAddress);
        }
        let endPointBMcLagPeerSpecificsFilter = "network:" + endpointBSiteId + ":mc-peer-manager:peer-" + endpointAInterfaceAddress + ":mc-lag-spec";
        endPointBMcLagPeerSpecificsFilter = util.modifyNeIdForIpV6(endPointBMcLagPeerSpecificsFilter, endpointBSiteId, endpointAInterfaceAddress);
        jsonPayLoad = {
            "fullClassName": fullClassName,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": endPointBMcLagPeerSpecificsFilter
                }
            }
        };
        let endpointBsearchResponse = nfmpFwk.post("/v3/search", jsonPayLoad);
        if (!endpointBsearchResponse.success)
        {
            throw new RuntimeException("Failed to find MC-Lag-Peer-Specifics with ne-Id : " + endpointBSiteId + ", End Point A Interface ID : " + endpointAInterfaceAddress + ", End Point B Interface ID : " + endpointBInterfaceAddress);
        }
        let mcLagPeerSpecificsConfig = {};
        mcLagPeerSpecificsConfig = {
            "endPointAMcLagPeerSpecificsConfig": JSON.parse(endpointAsearchResponse.response),
            "endPointBMcLagPeerSpecificsConfig": JSON.parse(endpointBsearchResponse.response)
        }
        return mcLagPeerSpecificsConfig;
    }

    this.getMcLagConfig = function (endpointASiteId, endpointAInterfaceAddress, endpointBSiteId, endpointBInterfaceAddress) {
        let endPointAPeerPointerFilter = "network:" + endpointASiteId + ":mc-peer-manager:peer-" + endpointBInterfaceAddress;
        endPointAPeerPointerFilter = util.modifyNeIdForIpV6(endPointAPeerPointerFilter, endpointASiteId, endpointBInterfaceAddress);
        let endPointBPeerPointerFilter = "network:" + endpointBSiteId + ":mc-peer-manager:peer-" + endpointAInterfaceAddress;
        endPointBPeerPointerFilter = util.modifyNeIdForIpV6(endPointBPeerPointerFilter, endpointBSiteId, endpointAInterfaceAddress);
        let fullClassName = "multichassis.MultiChassisLag";
        let jsonPayLoad =
        {
          "fullClassName": fullClassName,
          "filter": {
              "and": {
                  "equal": [
                      {
                          "name": "firstPeerPointer",
                          "value": endPointAPeerPointerFilter
                      },
                      {
                          "name": "secondPeerPointer",
                          "value": endPointBPeerPointerFilter
                      }
                  ]
              }
          }
        };

        let searchResponse = nfmpFwk.post("/v3/search", jsonPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find MC-LAGs with End Point A Interface Id: " + endpointAInterfaceAddress + ", End Point B Interface Id: " + endpointBInterfaceAddress);
        }
        if(searchResponse.response.length == 2)
        {
            searchResponse = [];
        }
        else
        {
         searchResponse = JSON.parse(searchResponse.response);
        }
        logger.info("searchResponse = {}", JSON.stringify(searchResponse));
        return searchResponse;
    }

    this.getMcIpsecGrpPayLoad = function (endpointASiteId, endpointAInterfaceAddress, endpointBSiteId, endpointBInterfaceAddress) {
        let fullClassName = "multichassis.MultiChassisIPSecGroup";
        let jsonPayLoad =
        {
          "fullClassName": fullClassName,
          "filter": {
              "and": {
                  "equal": [
                      {
                          "name": "firstSiteId",
                          "value": endpointASiteId
                      },
                      {
                          "name": "secondSiteId",
                          "value": endpointBSiteId
                      }
                  ]
              }
          }
        };

        let searchResponse = nfmpFwk.post("/v3/search", jsonPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find MC IPSec Group");
        }
        if(searchResponse.response.length == 2)
        {
            searchResponse = [];
        }
        else
        {
         searchResponse = JSON.parse(searchResponse.response);
        }
        logger.info("searchResponse = {}", JSON.stringify(searchResponse));
        return searchResponse;
    }

    this.getMcSyncGrpConfig = function (endpointASiteId, endpointAInterfaceAddress, endpointBSiteId, endpointBInterfaceAddress) {
        let fullClassName = "multichassis.MultiChassisSync";
        let jsonPayLoad =
        {
          "fullClassName": fullClassName,
          "filter": {
              "and": {
                  "equal": [
                      {
                          "name": "firstSiteId",
                          "value": endpointASiteId
                      },
                      {
                          "name": "firstIpAddress",
                          "value": endpointAInterfaceAddress
                      },
                      {
                          "name": "secondSiteId",
                          "value": endpointBSiteId
                      },
                      {
                          "name": "secondIpAddress",
                          "value": endpointBInterfaceAddress
                      },
                  ]
              }
          }
        };

        let searchResponse = nfmpFwk.post("/v3/search", jsonPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find MC Sync Group");
        }
        if(searchResponse.response.length == 2)
        {
            searchResponse = [];
        }
        else
        {
         searchResponse = JSON.parse(searchResponse.response);
        }
        logger.info("searchResponse = {}", JSON.stringify(searchResponse));
        return searchResponse;
    }

    this.getSyncPortConfig = function (objectFullName) {
        let fullClassName = "multichassis.PeerSynchronizationPort";
        let jsonPayLoad =
        {
          "fullClassName": fullClassName,
          "filter": {
              "and": {
                  "equal": [
                      {
                          "name": "objectFullName",
                          "value": objectFullName
                      }
                  ]
              }
          }
        };

        let searchResponse = nfmpFwk.post("/v3/search", jsonPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find Peer Synchronization Port :"+objectFullName);
        }
        if(searchResponse.response.length == 2)
        {
            searchResponse = [];
        }
        else
        {
         searchResponse = JSON.parse(searchResponse.response);
        }
        logger.info("searchResponse = {}", JSON.stringify(searchResponse));
        return searchResponse;
    }

    this.getMcRingGrpConfig = function (endpointASiteId, endpointAInterfaceAddress, endpointBSiteId, endpointBInterfaceAddress) {
        let fullClassName = "multichassis.MultiChassisRingGroup";
        let jsonPayLoad =
        {
          "fullClassName": fullClassName,
          "filter": {
              "and": {
                  "equal": [
                      {
                          "name": "firstSiteId",
                          "value": endpointASiteId
                      },
                      {
                          "name": "firstSitePeerIpAddress",
                          "value": endpointBInterfaceAddress
                      },
                      {
                          "name": "secondSiteId",
                          "value": endpointBSiteId
                      },
                      {
                          "name": "secondSitePeerIpAddress",
                          "value": endpointAInterfaceAddress
                      }
                  ]
              }
          }
        };

        let searchResponse = nfmpFwk.post("/v3/search", jsonPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find MC Ring Group");
        }
        if(searchResponse.response.length == 2)
        {
            searchResponse = [];
        }
        else
        {
         searchResponse = JSON.parse(searchResponse.response);
        }
        logger.info("searchResponse = {}", JSON.stringify(searchResponse));
        return searchResponse;
    }

    this.getMcEndpointConfig = function (endpointASiteId, endpointAInterfaceAddress, endpointBSiteId, endpointBInterfaceAddress) {
            let endPointAPeerPointerFilter = "network:" + endpointASiteId + ":mc-peer-manager:peer-" + endpointBInterfaceAddress;
            endPointAPeerPointerFilter = util.modifyNeIdForIpV6(endPointAPeerPointerFilter, endpointASiteId, endpointBInterfaceAddress);
            let endPointBPeerPointerFilter = "network:" + endpointBSiteId + ":mc-peer-manager:peer-" + endpointAInterfaceAddress;
            endPointBPeerPointerFilter = util.modifyNeIdForIpV6(endPointBPeerPointerFilter, endpointBSiteId, endpointAInterfaceAddress);
            let fullClassName = "multichassis.McEndpointGroup";
           let jsonPayLoad =
           {
             "fullClassName": fullClassName,
             "filter": {
                 "and": {
                     "equal": [
                         {
                             "name": "firstPeerPointer",
                             "value": endPointAPeerPointerFilter
                         },
                         {
                             "name": "secondPeerPointer",
                             "value": endPointBPeerPointerFilter
                         }
                     ]
                 }
             }
           };

           let searchResponse = nfmpFwk.post("/v3/search", jsonPayLoad);
           if (!searchResponse.success)
           {
               throw new RuntimeException("Failed to find MC-ENDPOINT with End Point A Interface Id: " + endpointAInterfaceAddress + ", End Point B Interface Id: " + endpointBInterfaceAddress);
           }
           if(searchResponse.response.length == 2)
           {
                searchResponse = [];
           }
           else
           {
            searchResponse = JSON.parse(searchResponse.response);
           }
           logger.info("searchResponse = {}", JSON.stringify(searchResponse));
           return searchResponse;
    }

    this.getMcPeerIpsecPayLoad = function (endpointASiteId, endpointAInterfaceAddress, endpointBSiteId, endpointBInterfaceAddress) {
        let endPointAMcPeerIPSecPointer = "network:" + endpointASiteId + ":mc-peer-manager:peer-" + endpointBInterfaceAddress + ":mcIPsec";
        endPointAMcPeerIPSecPointer = util.modifyNeIdForIpV6(endPointAMcPeerIPSecPointer, endpointASiteId, endpointBInterfaceAddress);
        let endPointBMcPeerIPSecPointer = "network:" + endpointBSiteId + ":mc-peer-manager:peer-" + endpointAInterfaceAddress + ":mcIPsec";
        endPointBMcPeerIPSecPointerFilter = util.modifyNeIdForIpV6(endPointBMcPeerIPSecPointer, endpointBSiteId, endpointAInterfaceAddress);
        let fullClassName = "multichassis.McPeerIPSec";
        let jsonPayLoad = {
            "fullClassName": fullClassName,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": endPointAMcPeerIPSecPointer
                }
            }
        };
        let endpointAMcPeerIPSecSearchResponse = nfmpFwk.post("/v3/search", jsonPayLoad);
        if (!endpointAMcPeerIPSecSearchResponse.success)
        {
            throw new RuntimeException("Failed to find MC-Lag-Peer-Specifics with ne-Id : " + endpointASiteId + ", End Point A Interface ID : " + endpointAInterfaceAddress + ", End Point B Interface ID : " + endpointBInterfaceAddress);
        }
        jsonPayLoad = {
            "fullClassName": fullClassName,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": endPointBMcPeerIPSecPointer
                }
            }
        };
        let endpointBMcPeerIPSecSearchResponse = nfmpFwk.post("/v3/search", jsonPayLoad);
        if (!endpointBMcPeerIPSecSearchResponse.success)
        {
            throw new RuntimeException("Failed to find MC-Lag-Peer-Specifics with ne-Id : " + endpointBSiteId + ", End Point A Interface ID : " + endpointAInterfaceAddress + ", End Point B Interface ID : " + endpointBInterfaceAddress);
        }
        let mcPeerIpsecConfig = {};
        mcPeerIpsecConfig = {
            "endpointAMcPeerIPSecConfig": JSON.parse(endpointAMcPeerIPSecSearchResponse.response),
            "endpointBMcPeerIPSecConfig": JSON.parse(endpointBMcPeerIPSecSearchResponse.response)
        }
        return mcPeerIpsecConfig;
    }

    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        logger.info("*********************************parsedDefaultTargetDataSTART*************************************");
        logger.info(JSON.stringify(parsedDefaultTargetData));
        logger.info("*********************************parsedDefaultTargetDataEND*************************************");

            if (null !== deviceConfig)
            {
                this.extractMcPeerProperties(parsedDefaultTargetData, deviceConfig);
                logger.info("extracting mc-lag");
                let mcLagArray = this.extractMcLagProperties(parsedDefaultTargetData['peer']['mc-lag']['lag'], deviceConfig['mcLagConfig']);
                parsedDefaultTargetData['peer']['mc-lag']['lag'] = mcLagArray;

                if (deviceConfig['mcPeerIpsecConfig'] &&
                    deviceConfig['mcPeerIpsecConfig']['endpointAMcPeerIPSecConfig'] &&
                    deviceConfig['mcPeerIpsecConfig']['endpointAMcPeerIPSecConfig']['multichassis.McPeerIPSec'] &&
                    deviceConfig['mcPeerIpsecConfig']['endpointAMcPeerIPSecConfig']['multichassis.McPeerIPSec']['children-Set']) {
                        let domainArrayA = this.extractMcIpsecProperties(parsedDefaultTargetData['peer']['mc-ipsec']['endPointADetails']['domain'],
                                deviceConfig['mcPeerIpsecConfig']['endpointAMcPeerIPSecConfig']['multichassis.McPeerIPSec']['children-Set'],"endPointADetails.domain.","multichassis.McPeerIPSecDomain");
                        parsedDefaultTargetData['peer']['mc-ipsec']['endPointADetails']['domain'] = domainArrayA;
                }

                if (deviceConfig['mcIpsecGrpConfig'] && deviceConfig['mcIpsecGrpConfig']["multichassis.MultiChassisIPSecGroup"]){
                    let tunnelGroupArray = this.extractMcIpsecProperties(parsedDefaultTargetData['peer']['mc-ipsec']['tunnelGroup'],deviceConfig['mcIpsecGrpConfig'],"tunnelGroup.","multichassis.MultiChassisIPSecGroup");
                    parsedDefaultTargetData['peer']['mc-ipsec']['tunnelGroup'] = tunnelGroupArray;
                }

                if (deviceConfig['mcPeerIpsecConfig'] &&
                    deviceConfig['mcPeerIpsecConfig']['endpointBMcPeerIPSecConfig'] &&
                    deviceConfig['mcPeerIpsecConfig']['endpointBMcPeerIPSecConfig']['multichassis.McPeerIPSec'] &&
                    deviceConfig['mcPeerIpsecConfig']['endpointBMcPeerIPSecConfig']['multichassis.McPeerIPSec']['children-Set']) {
                        let domainArrayB = this.extractMcIpsecProperties( parsedDefaultTargetData['peer']['mc-ipsec']['endPointBDetails']['domain'], deviceConfig['mcPeerIpsecConfig']['endpointBMcPeerIPSecConfig']['multichassis.McPeerIPSec']['children-Set'],
                        "endPointBDetails.domain.","multichassis.McPeerIPSecDomain");
                    parsedDefaultTargetData['peer']['mc-ipsec']['endPointBDetails']['domain'] = domainArrayB;
                }

                logger.info("extracting mc-sync group")
                let mcSyncGroupArray = this.extractMcSyncGroupProperties(parsedDefaultTargetData['peer']['sync']['syncGroup'], deviceConfig['mcSyncGrpConfig']);
                parsedDefaultTargetData['peer']['sync']['syncGroup'] = mcSyncGroupArray;

                logger.info("extracting mc-ring group")
                let mcRingArray = this.extractMcRingGroupProperties(parsedDefaultTargetData['peer']['mc-ring']['ringGroup'], deviceConfig['mcRingGrpConfig']);
                parsedDefaultTargetData['peer']['mc-ring']['ringGroup'] = mcRingArray;
        }
        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData));
        removeNullAndEmptyKeys(parsedDefaultTargetData);
        logger.info("Intent data after updating from NFMP after removing empty and null :\n" + JSON.stringify(parsedDefaultTargetData));
        return parsedDefaultTargetData;
    }

    this.extractMcPeerProperties = function (defaultTargetData, deviceConfig) {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            //logger.info("************************ targetKey = {},\ntargetObj = {}",targetKey,JSON.stringify(targetObj));
            if (targetObj !== null && typeof targetObj === 'object')
            {
                this.traverseAndUpdateConfig(targetKey, targetObj, deviceConfig);
            }
        }
        return defaultTargetData;
    }

    this.extractMcLagProperties = function (defaultTargetData, deviceConfig) {
        let mcLagArray = [];
        let mcLagData = defaultTargetData[0];
        let mappings = modelDeviceMapping.getMcLagMapping();
        if(Array.isArray(deviceConfig) && deviceConfig.length === 0)
        {
            return;
        }
        deviceConfig = deviceConfig["multichassis.MultiChassisLag"]
        if (!Array.isArray(deviceConfig))
        {
            deviceConfig = [deviceConfig];
        }
        for (let i = 0; i < deviceConfig.length; i++)
        {
            let deviceMcLagConfig = deviceConfig[i];
            let keys = Object.keys(mcLagData);
            logger.info("keys = " + keys);
            for (let j = 0; j < keys.length; j++)
            {
                let targetKey = keys[j];
                let targetObj = mcLagData[targetKey];
                let mappedKey = "peer.mc-lag.lag." + targetKey;
                //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj) + "\nmappedKey = " + mappedKey);
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, mcLagData, deviceMcLagConfig);
            }
            mcLagArray.push(JSON.parse(JSON.stringify(mcLagData)));
        }
        return mcLagArray;
    }

    this.extractMcIpsecProperties = function (defaultTargetData, deviceConfig, mapConfig, fullClassName) {
        let mcIpsecArrayConfigs = [];

        // Defensive check: make sure defaultTargetData has at least one item
        if (!Array.isArray(defaultTargetData) || defaultTargetData.length === 0) {
            return;
        }
        let mcIpsecData = defaultTargetData[0];

        // Defensive check: make sure deviceConfig is valid
        if (!deviceConfig || (Array.isArray(deviceConfig) && deviceConfig.length === 0)) {
            return;
        }

        // Get correct mappings based on mapConfig
        let mappings;
        if (mapConfig === "endPointADetails.domain.") {
            mappings = modelDeviceMapping.getMcIpsecDomainAMapping();
        } else if (mapConfig === "tunnelGroup.") {
            mappings = modelDeviceMapping.getMcIpsecTunnelGroupMapping();
        } else if (mapConfig === "endPointBDetails.domain.") {
            mappings = modelDeviceMapping.getMcIpsecDomainBMapping();
        } else {
            // If mapConfig is unexpected
            return;
        }
        // Check if fullClassName exists inside deviceConfig
        if (!deviceConfig.hasOwnProperty(fullClassName) || deviceConfig[fullClassName] == null) {
            return;
        }
        deviceConfig = deviceConfig[fullClassName];

        logger.info("deviceConfig after fullClassName extraction:\n" + JSON.stringify(deviceConfig));

        // Make sure deviceConfig is always an array
        if (!Array.isArray(deviceConfig)) {
            deviceConfig = [deviceConfig];
        }

        // Process each device config
        for (let i = 0; i < deviceConfig.length; i++) {
            let deviceMcLagConfig = deviceConfig[i];
            let keys = Object.keys(mcIpsecData);

            logger.info("keys = " + keys);

            for (let j = 0; j < keys.length; j++) {
                let targetKey = keys[j];
                var mappedKey = "peer.mc-ipsec." + mapConfig + targetKey;
                logger.info("mappedKey:\n" + mappedKey);
                logger.info("mappings:\n" + JSON.stringify(mappings));
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, mcIpsecData, deviceMcLagConfig);
            }

            // Deep clone mcIpsecData and push into array
            mcIpsecArrayConfigs.push(JSON.parse(JSON.stringify(mcIpsecData)));
        }

        return mcIpsecArrayConfigs;
    };

    this.extractMcSyncGroupProperties = function (defaultTargetData, deviceConfig) {
        let mcSyncGroupArray = [];
        let mcSyncGroupData = defaultTargetData[0];
        if(Array.isArray(deviceConfig) && deviceConfig.length === 0)
        {
            return;
        }
        deviceConfig = deviceConfig["multichassis.MultiChassisSync"]
        if (!Array.isArray(deviceConfig))
        {
            deviceConfig = [deviceConfig];
        }
        for (let i = 0; i < deviceConfig.length; i++)
        {
            let deviceMcSyncGroupConfig = deviceConfig[i];
            let mcSyncGroupData = {};

            mcSyncGroupData["tag"] = deviceMcSyncGroupConfig["tag"];
            mcSyncGroupData["description"] = deviceMcSyncGroupConfig["description"];
            mcSyncGroupData["firstSiteSyncTagConfigLevel"] = deviceMcSyncGroupConfig["firstSiteSyncTagConfigLevel"];
            mcSyncGroupData["firstSitePortName"] = deviceMcSyncGroupConfig["firstSitePortName"];
            mcSyncGroupData["firstSiteSdpId"] = deviceMcSyncGroupConfig["firstSiteSdpId"];
            mcSyncGroupData["secondSitePortName"] = deviceMcSyncGroupConfig["secondSitePortName"];
            mcSyncGroupData["secondSiteSdpId"] = deviceMcSyncGroupConfig["secondSiteSdpId"];

            if(deviceMcSyncGroupConfig["firstSiteSyncTagConfigLevel"] == "vlanLevel"){
                let encapRanges = [];
                let syncPortConfig = this.getSyncPortConfig(deviceMcSyncGroupConfig["firstSitePeerSyncPortPointer"]);
                let encapRangesConfig = null;
                if(syncPortConfig["multichassis.PeerSynchronizationPort"] && syncPortConfig["multichassis.PeerSynchronizationPort"]["children-Set"] &&
                syncPortConfig["multichassis.PeerSynchronizationPort"]["children-Set"]["multichassis.PeerSynchronizationPortEncapRange"])
                {
                    encapRangesConfig = syncPortConfig["multichassis.PeerSynchronizationPort"]["children-Set"]["multichassis.PeerSynchronizationPortEncapRange"];
                    if (!Array.isArray(encapRangesConfig))
                    {
                        encapRangesConfig = [encapRangesConfig];
                    }
                    for (let j = 0; j < encapRangesConfig.length; j++)
                    {
                        let encapRangeConfig = encapRangesConfig[j];
                        let encapRange = {
                            minOuterEncapValue: encapRangeConfig["minOuterEncapValue"],
                            maxOuterEncapValue: encapRangeConfig["maxOuterEncapValue"]
                        };
                        encapRanges.push(encapRange);
                    }
                    mcSyncGroupData["vlanEntries"] = encapRanges;
                }
            }

            mcSyncGroupArray.push(JSON.parse(JSON.stringify(mcSyncGroupData)));
        }
        return mcSyncGroupArray;
    }

    this.extractMcRingGroupProperties = function (defaultTargetData, deviceConfig) {
        let mcRingGroupArray = [];
        let mcRingGroupData = defaultTargetData[0];
        if(Array.isArray(deviceConfig) && deviceConfig.length === 0)
        {
            return;
        }
        deviceConfig = deviceConfig["multichassis.MultiChassisRingGroup"]
        if (!Array.isArray(deviceConfig))
        {
            deviceConfig = [deviceConfig];
        }
        for (let i = 0; i < deviceConfig.length; i++)
        {
            let deviceMcRingGroupConfig = deviceConfig[i];
            let mcRingGroupData = {};

            mcRingGroupData["ringName"] = deviceMcRingGroupConfig["ringName"];

            //get Ring endpointA Config
            let deviceConfigMcRingEndPointA = this.getMcRingEndpointConfig(deviceMcRingGroupConfig["firstMcRingPointer"]);
            deviceConfigMcRingEndPointA = deviceConfigMcRingEndPointA["multichassis.MultiChassisRing"];
            mcRingGroupData["endPointADetails"] = {};
            mcRingGroupData["endPointADetails"]["ring"] = {};
            mcRingGroupData["endPointADetails"]["ring"]["admin-state"] = util.convertToIntentAdminstarteState(deviceConfigMcRingEndPointA["administrativeState"]);
            mcRingGroupData["endPointADetails"]["ring"]["type"] = null;

            mcRingGroupData["endPointADetails"]["ring"]["in-band-control-path"] = {};
            mcRingGroupData["endPointADetails"]["ring"]["in-band-control-path"]["max-debounce-time"] = deviceConfigMcRingEndPointA["ibrccDebounceMaxTime"];
            mcRingGroupData["endPointADetails"]["ring"]["in-band-control-path"]["admin-state"] = util.convertToIntentAdminstarteState(deviceConfigMcRingEndPointA["ibrccAdministrativeState"]);
            mcRingGroupData["endPointADetails"]["ring"]["in-band-control-path"]["dst-ip"] = deviceConfigMcRingEndPointA["ibrccDestinationIpAddr"];
            //mcRingGroupData["endPointADetails"]["ring"]["in-band-control-path"]["service-name"] = deviceConfigMcRingEndPointA["ibrccServiceName"];
            mcRingGroupData["endPointADetails"]["ring"]["in-band-control-path"]["interface"] = deviceConfigMcRingEndPointA["ibrccInterfaceName"];

            mcRingGroupData["endPointADetails"]["ring"]["path-b"] = {};
            mcRingGroupData["endPointADetails"]["ring"]["path-b"]["range"] = [];
            if(deviceConfigMcRingEndPointA["children-Set"] && deviceConfigMcRingEndPointA["children-Set"]["multichassis.PathBVlanRange"]){
                let pathBsVlanConfig = deviceConfigMcRingEndPointA["children-Set"]["multichassis.PathBVlanRange"];
                if (!Array.isArray(pathBsVlanConfig))
                {
                    pathBsVlanConfig = [pathBsVlanConfig];
                }
                for (let j = 0; j < pathBsVlanConfig.length; j++) {
                    let pathBVlanConfig = pathBsVlanConfig[j];
                    let pathBConfig = {};
                    pathBConfig["start"] = pathBVlanConfig["startVlan"];
                    pathBConfig["end"] = pathBVlanConfig["endVlan"];
                    mcRingGroupData["endPointADetails"]["ring"]["path-b"]["range"].push(pathBConfig);
                }
            }

            mcRingGroupData["endPointADetails"]["ring"]["path-excl"] = {};
            mcRingGroupData["endPointADetails"]["ring"]["path-excl"]["range"] = [];
            if(deviceConfigMcRingEndPointA["children-Set"] && deviceConfigMcRingEndPointA["children-Set"]["multichassis.ExcludeVlanRange"]){
                let excludesVlanConfig = deviceConfigMcRingEndPointA["children-Set"]["multichassis.ExcludeVlanRange"];
                if (!Array.isArray(excludesVlanConfig))
                {
                    excludesVlanConfig = [excludesVlanConfig];
                }
                for (let j = 0; j < excludesVlanConfig.length; j++) {
                    let excludeVlanConfig = excludesVlanConfig[j];
                    let pathExclConfig = {};
                    pathExclConfig["start"] = excludeVlanConfig["startVlan"];
                    pathExclConfig["end"] = excludeVlanConfig["endVlan"];
                    mcRingGroupData["endPointADetails"]["ring"]["path-excl"]["range"].push(pathExclConfig);
                }
            }

            mcRingGroupData["endPointADetails"]["ring"]["ring-node"] = [];
            if(deviceConfigMcRingEndPointA["children-Set"] && deviceConfigMcRingEndPointA["children-Set"]["multichassis.MultiChassisRingNode"]){
                let mcRingNodesConfig = deviceConfigMcRingEndPointA["children-Set"]["multichassis.MultiChassisRingNode"];
                if (!Array.isArray(mcRingNodesConfig))
                {
                    mcRingNodesConfig = [mcRingNodesConfig];
                }
                for (let j = 0; j < mcRingNodesConfig.length; j++) {
                    let mcRingNodeConfig = mcRingNodesConfig[j];
                    let ringNodeConfig = {};
                    ringNodeConfig["name"] = mcRingNodeConfig["ringNodeName"];
                    ringNodeConfig["admin-state"] = util.convertToIntentAdminstarteState(mcRingNodeConfig["administrativeState"]);
                    ringNodeConfig["interval"] = mcRingNodeConfig["rncvInterval"];
                    ringNodeConfig["rncvServiceId"] = mcRingNodeConfig["rncvServiceId"];
                    ringNodeConfig["rncvInnerEncapValue"] = mcRingNodeConfig["rncvInnerEncapValue"];
                    ringNodeConfig["rncvOuterEncapValue"] = mcRingNodeConfig["rncvOuterEncapValue"];
                    ringNodeConfig["src-ip"] = mcRingNodeConfig["rncvSourceIpAddr"];
                    ringNodeConfig["dst-ip"] = mcRingNodeConfig["rncvDestinationIpAddr"];
                    ringNodeConfig["src-mac"] = mcRingNodeConfig["rncvSourceMacAddr"];
                    mcRingGroupData["endPointADetails"]["ring"]["ring-node"].push(ringNodeConfig);
                }
            }

            //get Ring endpointB Config
            let deviceConfigMcRingEndPointB = this.getMcRingEndpointConfig(deviceMcRingGroupConfig["secondMcRingPointer"]);
            deviceConfigMcRingEndPointB = deviceConfigMcRingEndPointB["multichassis.MultiChassisRing"];
            mcRingGroupData["endPointBDetails"] = {};
            mcRingGroupData["endPointBDetails"]["ring"] = {};
            mcRingGroupData["endPointBDetails"]["ring"]["admin-state"] = util.convertToIntentAdminstarteState(deviceConfigMcRingEndPointB["administrativeState"]);
            mcRingGroupData["endPointBDetails"]["ring"]["type"] = null;

            mcRingGroupData["endPointBDetails"]["ring"]["in-band-control-path"] = {};
            mcRingGroupData["endPointBDetails"]["ring"]["in-band-control-path"]["max-debounce-time"] = deviceConfigMcRingEndPointB["ibrccDebounceMaxTime"];
            mcRingGroupData["endPointBDetails"]["ring"]["in-band-control-path"]["admin-state"] = util.convertToIntentAdminstarteState(deviceConfigMcRingEndPointB["ibrccAdministrativeState"]);
            mcRingGroupData["endPointBDetails"]["ring"]["in-band-control-path"]["dst-ip"] = deviceConfigMcRingEndPointB["ibrccDestinationIpAddr"];
            //mcRingGroupData["endPointBDetails"]["ring"]["in-band-control-path"]["service-name"] = deviceConfigMcRingEndPointB["ibrccServiceName"];
            mcRingGroupData["endPointBDetails"]["ring"]["in-band-control-path"]["interface"] = deviceConfigMcRingEndPointB["ibrccInterfaceName"];

            mcRingGroupData["endPointBDetails"]["ring"]["path-b"] = {};
            mcRingGroupData["endPointBDetails"]["ring"]["path-b"]["range"] = [];
            if(deviceConfigMcRingEndPointB["children-Set"] && deviceConfigMcRingEndPointB["children-Set"]["multichassis.PathBVlanRange"]){
                let pathBsVlanConfig = deviceConfigMcRingEndPointB["children-Set"]["multichassis.PathBVlanRange"];
                if (!Array.isArray(pathBsVlanConfig))
                {
                    pathBsVlanConfig = [pathBsVlanConfig];
                }
                for (let j = 0; j < pathBsVlanConfig.length; j++) {
                    let pathBVlanConfig = pathBsVlanConfig[j];
                    let pathBConfig = {};
                    pathBConfig["start"] = pathBVlanConfig["startVlan"];
                    pathBConfig["end"] = pathBVlanConfig["endVlan"];
                    mcRingGroupData["endPointBDetails"]["ring"]["path-b"]["range"].push(pathBConfig);
                }
            }

            mcRingGroupData["endPointBDetails"]["ring"]["path-excl"] = {};
            mcRingGroupData["endPointBDetails"]["ring"]["path-excl"]["range"] = [];
            if(deviceConfigMcRingEndPointB["children-Set"] && deviceConfigMcRingEndPointB["children-Set"]["multichassis.ExcludeVlanRange"]){
                let excludesVlanConfig = deviceConfigMcRingEndPointB["children-Set"]["multichassis.ExcludeVlanRange"];
                if (!Array.isArray(excludesVlanConfig))
                {
                    excludesVlanConfig = [excludesVlanConfig];
                }
                for (let j = 0; j < excludesVlanConfig.length; j++) {
                    let excludeVlanConfig = excludesVlanConfig[j];
                    let pathExclConfig = {};
                    pathExclConfig["start"] = excludeVlanConfig["startVlan"];
                    pathExclConfig["end"] = excludeVlanConfig["endVlan"];
                    mcRingGroupData["endPointBDetails"]["ring"]["path-excl"]["range"].push(pathExclConfig);
                }
            }

            mcRingGroupData["endPointBDetails"]["ring"]["ring-node"] = [];
            if(deviceConfigMcRingEndPointB["children-Set"] && deviceConfigMcRingEndPointB["children-Set"]["multichassis.MultiChassisRingNode"]){
                let mcRingNodesConfig = deviceConfigMcRingEndPointB["children-Set"]["multichassis.MultiChassisRingNode"];
                if (!Array.isArray(mcRingNodesConfig))
                {
                    mcRingNodesConfig = [mcRingNodesConfig];
                }
                for (let j = 0; j < mcRingNodesConfig.length; j++) {
                    let mcRingNodeConfig = mcRingNodesConfig[j];
                    let ringNodeConfig = {};
                    ringNodeConfig["name"] = mcRingNodeConfig["ringNodeName"];
                    ringNodeConfig["admin-state"] = util.convertToIntentAdminstarteState(mcRingNodeConfig["administrativeState"]);
                    ringNodeConfig["interval"] = mcRingNodeConfig["rncvInterval"];
                    ringNodeConfig["rncvServiceId"] = mcRingNodeConfig["rncvServiceId"];
                    ringNodeConfig["rncvInnerEncapValue"] = mcRingNodeConfig["rncvInnerEncapValue"];
                    ringNodeConfig["rncvOuterEncapValue"] = mcRingNodeConfig["rncvOuterEncapValue"];
                    ringNodeConfig["src-ip"] = mcRingNodeConfig["rncvSourceIpAddr"];
                    ringNodeConfig["dst-ip"] = mcRingNodeConfig["rncvDestinationIpAddr"];
                    ringNodeConfig["src-mac"] = mcRingNodeConfig["rncvSourceMacAddr"];
                    mcRingGroupData["endPointBDetails"]["ring"]["ring-node"].push(ringNodeConfig);
                }
            }

            mcRingGroupArray.push(JSON.parse(JSON.stringify(mcRingGroupData)));
        }
        return mcRingGroupArray;
    }

    this.getMcRingEndpointConfig = function (objectFullName) {
        let fullClassName = "multichassis.MultiChassisRing";
        let jsonPayLoad = {
            "fullClassName": fullClassName,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        let endpointMcRingSearchResponse = nfmpFwk.post("/v3/search", jsonPayLoad);
        if (!endpointMcRingSearchResponse.success)
        {
            throw new RuntimeException("Failed to find the MultiChassisRing with objectFullName : " + objectFullName );
        }
        return JSON.parse(endpointMcRingSearchResponse.response);
    }

    this.traverseAndUpdateConfig = function (objKey, obj, deviceConfig) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            let deviceConfigData;
            let mappings;
            if (mappedKey.startsWith("peer.endPointADetails") || mappedKey.startsWith("peer.endPointBDetails") ||
                 mappedKey.startsWith("peer.sync") || mappedKey.startsWith("peer.enable-mc-ipsec"))
            {
                mappings = modelDeviceMapping.getMcPeerMapping();
                deviceConfigData = deviceConfig['mcPeerConfig']['multichassis.MultiChassisPeer']
            }
            if (mappedKey.startsWith("peer.mc-lag.endPointADetails"))
            {
                mappings = modelDeviceMapping.getMcLagPeerSpecificsMapping();
                deviceConfigData = deviceConfig['mcLagPeerSpecificsConfig']['endPointAMcLagPeerSpecificsConfig']['multichassis.MultiChassisLagPeerSpecifics']
            }
            if (mappedKey.startsWith("peer.mc-lag.endPointBDetails"))
            {
                mappings = modelDeviceMapping.getMcLagPeerSpecificsMapping();
                deviceConfigData = deviceConfig['mcLagPeerSpecificsConfig']['endPointBMcLagPeerSpecificsConfig']['multichassis.MultiChassisLagPeerSpecifics']
            }
            if (mappedKey.startsWith("peer.mc-endpoint"))
            {
                mappings = modelDeviceMapping.getMcEndpointMapping();
                deviceConfigData = (Array.isArray(deviceConfig['mcEndpoint']) && deviceConfig['mcEndpoint'].length === 0) ? undefined : deviceConfig['mcEndpoint']['multichassis.McEndpointGroup']
            }
            if (mappedKey.startsWith("peer.mc-ipsec.endPointADetails"))
            {
                mappings = modelDeviceMapping.getMcIpsecMapping();
                deviceConfigData = deviceConfig['mcPeerIpsecConfig']['endpointAMcPeerIPSecConfig']['multichassis.McPeerIPSec'];
            }
            if (mappedKey.startsWith("peer.mc-ipsec.endPointBDetails"))
            {
                mappings = modelDeviceMapping.getMcIpsecMapping();
                deviceConfigData = deviceConfig['mcPeerIpsecConfig']['endpointBMcPeerIPSecConfig']['multichassis.McPeerIPSec'];
            }
            if(mappedKey.startsWith("peer.enable-mc-endpoint"))
            {
                if(Array.isArray(deviceConfig['mcEndpoint']) && deviceConfig['mcEndpoint'].length === 0)
                {
                    obj[key] = false;
                }
                else
                {
                    obj[key] = true;
                }
            }
            if(mappedKey.startsWith("peer.enable-mc-ipsec"))
            {
                if(Array.isArray(deviceConfig['mcPeerIpsecConfig']) && deviceConfig['mcPeerIpsecConfig'].length === 0)
                {
                    obj[key] = false;
                }
                else
                {
                    obj[key] = true;
                }
            }
            if (value != null && typeof value === 'object')
            {
                this.traverseAndUpdateConfig(mappedKey, value, deviceConfig);
            }
            else
            {
                if (mappings && deviceConfigData)
                {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, deviceConfigData);
                }
            }
        }
        return obj;
    }

    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, deviceConfig) {
    //logger.info("***********getAndUpdateFromDeviceConfig ======\n mappings = {}\n, mappedKey = {}\n, targetKey = {}\n, targetObj = {}\n, deviceConfig = {}\n",JSON.stringify(mappings), JSON.stringify(mappedKey), JSON.stringify(targetKey), JSON.stringify(targetObj), JSON.stringify(deviceConfig));
        let nfmpKey = mappings[mappedKey];
        let deviceValue = deviceConfig[nfmpKey];
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        if(mappedKey == "peer.mc-lag.lag.source-bmac-lsb")
        {
            if(deviceConfig["srcBMacLsbUseLacpKey"] === 'true')
            {
                targetObj[targetKey] = "use-lacp-key"
            }
            else
            {
                targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);
            }
        }
        else
        {
            targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);
        }
    }

    this.transformDeviceValue = function (mappedKey, deviceValue) {
    //logger.info("**************** transformDeviceValue ============= mappedKey = {}\n , deviceValue = {}\n",JSON.stringify(mappedKey), JSON.stringify(deviceValue));
        if (deviceValue !== null)
        {
            switch (mappedKey)
            {
                case "peer.endPointADetails.admin-state":
                case "peer.endPointBDetails.admin-state":
                case "peer.mc-lag.endPointADetails.admin-state":
                case "peer.mc-lag.endPointBDetails.admin-state":
                case "peer.mc-endpoint.endPointADetails.admin-state":
                case "peer.mc-endpoint.endPointBDetails.admin-state":
                case "peer.mc-ipsec.endPointADetails.domain.admin-state":
                case "peer.mc-ipsec.endPointBDetails.domain.admin-state":
                case "peer.sync.admin-state":
                case "peer.sync.endPointADetails.admin-state":
                case "peer.sync.endPointBDetails.admin-state":
                    deviceValue = util.convertToIntentAdminstarteState(deviceValue);
                    break;
                case "peer.mc-lag.lag.system-id":
                    deviceValue = util.convertToIntentsystemId(deviceValue);
                    break;
                case "peer.sync.mcPimSnooping":
                    deviceValue = Array.isArray(deviceValue) ? deviceValue.join(" "): deviceValue;
                    break;
                case "peer.sync.mcKeyChainName":
                    deviceValue = (deviceValue) ? deviceValue.replace('KeyChain:', ''): deviceValue;
                    break;
            }
            return deviceValue;
        }
    }
    function removeNullAndEmptyKeys(obj) {
        for (let key in obj) {
            const value = obj[key];
            if (value === null || value === undefined || value === "") {
                delete obj[key];
            }
            else if (Array.isArray(value))
            {
                value.forEach(item => {
                if (typeof item === 'object' && item !== null) {
                        removeNullAndEmptyKeys(item);
                }
            });

            // Remove array if it's empty or contains only empty objects
            if (value.length === 0 || value.every(item => typeof item === 'object' && item !== null && Object.keys(item).length === 0)) {
                delete obj[key];
            }
            } else if (typeof value === 'object') {
            removeNullAndEmptyKeys(value);
            if (Object.keys(value).length === 0) {
                delete obj[key];
            }
        }
    }
  }
}