<#ftl output_format="JSON">
<#setting number_format="computer">
{
    "mpls.Tunnel.configureTunnelAndPath": {
        "clearOnDeployFailure": true,
        "pathConfigInfo": {
            "mpls.ProvisionedPath": {
                "destinationNodeId": "${destination}",
                "children-Set": {
                    "mpls.ProvisionedHop": [
                    <#if extraParams.name != "hopless" && (extraParams["explicit-route-objects-always"]["route-object-include-exclude"])?? && extraParams["explicit-route-objects-always"]["route-object-include-exclude"].length != 0 >
                    <#list extraParams["explicit-route-objects-always"]["route-object-include-exclude"]?values as value>
                    {
                        "prefixLength": 32,
                        "displayedName": "hop-${value.index}",
                        "ipAddress": "${value.numbered\-node\-hop.node\-id}",
                        "hopId": ${value.index},
                        "type": "${value.numbered\-node\-hop.hop\-type}",
                        "actionMask": {
                            "bit": ["create", "modify"]
                        }
                    }<#if value?has_next>,</#if>
                    </#list>
                    </#if>
                    ]
                },
                "displayedName": "${extraParams.name}",
                "sourceNodeId": "${sourceNeId}",
                "pathMtu": 0,
                "pathId": 0,
                "actionMask": {
                    "bit": ["create", "modify"]
                }
            }
        },
        "deployer": "immediate",
        "synchronousDeploy": true,
        "tunnelConfigInfo": {
            "mpls.Tunnel": {
                "ingressLabelSwitchRouterId": 1,
<#--                "destinationNodeId": "${destination}",-->
                "administrativeState": "tunnelUp",
                "forwardingClasses": "",
                "displayedName": "${extraParams.name}",
                "sourceNodeId": "${sourceNeId}",
                "tunnelInstance": 1,
                "pathId": 0,
                "priority": 0,
                "actionMask": {
                    "bit": "create"
                }
            }
        }
    }
}
