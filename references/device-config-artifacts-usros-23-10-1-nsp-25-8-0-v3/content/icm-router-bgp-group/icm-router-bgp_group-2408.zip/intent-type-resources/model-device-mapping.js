function ModelDeviceMapping() {


  this.getMapping = function(type){
    switch(type){
      case "group":
        return this.getBGPGroupMapping();
      case "neighbor":
        return this.getBGPNeighbourMapping();
      case "neighbor.prefix-limit":
        return this.getBGPNeighbourPrefixListMapping();
      default:
        return this.getBGPGroupMapping();
        //return this.get
    }
  }

  this.getBGPGroupMapping = function() {
    var mapping = {};
    mapping['group.admin-state'] = 'administrativeState';
    mapping['group.connect-retry'] = 'connectRetryTime';
    mapping['group.keepalive'] = 'keepAlive';
    mapping['group.damping'] = 'damping';
    mapping['group.local-preference'] = 'localPreference';
    mapping['group.min-route-advertisement'] = 'minRouteAdvertisement';
    mapping['group.loop-detect'] = 'loopDetect';
    mapping['group.aggregator-id-zero'] = 'aggregatorIdZero';
    mapping['group.preference'] = 'preference';
    mapping['group.multihop'] = 'multiHop';
    mapping['group.client-reflect'] = 'disableClientReflect';
    mapping['group.vpn-apply-export'] = 'vpnApplyExport';
    mapping['group.vpn-apply-import'] = 'vpnApplyImport';
    mapping['group.asn-4-byte'] = 'disable4ByteASN';
    mapping['group.path-mtu-discovery'] = 'pathMtuDiscovery';
    mapping['group.hold-time.seconds'] = 'holdTime';
    mapping['group.hold-time.minimum-hold-time'] = 'minHoldTime';
    //mapping['group.family'] = 'family';
    mapping['group.remove-private.limited'] = 'removePrivateASLmtd';
    mapping['group.remove-private.skip-peer-as'] = 'removePrivateSkipPeerAs';
    mapping['group.cluster.cluster-id'] = 'clusterId';
    mapping['group.local-as.as-number'] = 'localAS';
    mapping['group.local-as.private'] = 'localASPrivate';
    mapping['group.graceful-restart.restart-time'] = 'grRestartTime';
    mapping['group.graceful-restart.stale-routes-time'] = 'staleRoutesTime';
    mapping['group.outbound-route-filtering.extended-community.accept-orf'] = 'acceptOrf';
    mapping['group.outbound-route-filtering.extended-community.send-orf'] = 'sendOrf';


    return mapping;
  }

  this.getBGPNeighbourMapping = function() {
    var mapping = {};
    mapping['neighbor.ip-address'] = 'peerAddressComponent';
    mapping['neighbor.admin-state'] = 'administrativeState';
    mapping['neighbor.connect-retry'] = 'connectRetryTime';
    mapping['neighbor.keepalive'] = 'keepAlive';
    mapping['neighbor.damping'] = 'damping';
    mapping['neighbor.local-preference'] = 'localPreference';
    mapping['neighbor.min-route-advertisement'] = 'minRouteAdvertisement';
    mapping['neighbor.loop-detect'] = 'loopDetect';
    mapping['neighbor.aggregator-id-zero'] = 'aggregatorIdZero';
    mapping['neighbor.preference'] = 'preference';
    mapping['neighbor.multihop'] = 'multiHop';
    mapping['neighbor.client-reflect'] = 'disableClientReflect';
    mapping['neighbor.vpn-apply-export'] = 'vpnApplyExport';
    mapping['neighbor.vpn-apply-import'] = 'vpnApplyImport';
    mapping['neighbor.asn-4-byte'] = 'disable4ByteASN';
    mapping['neighbor.local-address'] = 'localAddress';
    mapping['neighbor.l2vpn-cisco-interop'] = 'l2vpnCiscoInterop';
    mapping['neighbor.next-hop-self'] = 'nextHopSelf';
    mapping['neighbor.passive'] = 'passive';
    mapping['neighbor.peer-as'] = 'peerAS';
    mapping['neighbor.capability-negotiation'] = 'disableCapabilityNegotiation';
    mapping['neighbor.hold-time.seconds'] = 'holdTime';
    mapping['neighbor.hold-time.minimum-hold-time'] = 'minHoldTime';
    //mapping['neighbor.family'] = 'family';
    mapping['neighbor.remove-private.limited'] = 'removePrivateASLmtd';
    mapping['neighbor.remove-private.skip-peer-as'] = 'removePrivateSkipPeerAs';
    mapping['neighbor.cluster.cluster-id'] = 'clusterId';
    mapping['neighbor.local-as.as-number'] = 'localAS';
    mapping['neighbor.local-as.private'] = 'localASPrivate';
    mapping['neighbor.graceful-restart.restart-time'] = 'grRestartTime';
    mapping['neighbor.graceful-restart.stale-routes-time'] = 'staleRoutesTime';
    mapping['neighbor.outbound-route-filtering.extended-community.accept-orf'] = 'acceptOrf';
    mapping['neighbor.outbound-route-filtering.extended-community.send-orf'] = 'sendOrf';

    return mapping;
  }

  this.getBGPNeighbourPrefixListMapping = function() {
    var mapping = {};
    mapping['neighbor.prefix-limit.family'] = 'family';
    mapping['neighbor.prefix-limit.maximum'] = 'prefixLimit';
    mapping['neighbor.prefix-limit.log-only'] = 'prefixLogOnly';
    mapping['neighbor.prefix-limit.threshold'] = 'prefixThreshold';
    mapping['neighbor.prefix-limit.idle-timeout'] = 'prefixIdleTimeOut';
    mapping['neighbor.prefix-limit.post-import'] = 'postImport';
    return mapping;
  }
}
