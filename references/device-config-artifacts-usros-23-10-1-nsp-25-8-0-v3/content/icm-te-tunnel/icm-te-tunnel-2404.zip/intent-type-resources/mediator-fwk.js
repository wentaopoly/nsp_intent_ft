load({script: resourceProvider.getResource('intent-logger.js'), name: 'intent-logger.js'});

function MediatorFramework(type) {
    this.mediatorType = type;

    if (type === "MDC") {
        this.mediatorIp = "nsp-mdt-mdc-mediator-svc";
        this.mediatorPort = "80";
        this.mediatorProtocol = "http";
        this.contentType = "application/yang-patch+json";
    } else if (type === "NFMP") {
        this.mediatorIp = "nsp-mdt-nfmp-mediator-svc";
        this.mediatorPort = "80";
        this.mediatorProtocol = "http";
    } else if (type === "NSP") {
        this.mediatorIp = "nsp-mdt-nsp-mediator-svc";
        this.mediatorPort = "80";
        this.mediatorProtocol = "http";
    } else {
        try {
            this.imLogger.info("[MEDIATOR-FWK] this is an alien mediator");
            let mediatorManager = mds.getManagerByName(type);
            this.mediatorIp = mediatorManager.getIp();
            this.mediatorPort = mediatorManager.getPort();
            this.mediatorProtocol = mediatorManager.getProtocol();
            this.imLogger.info("[MEDIATOR-FWK] Constructor type: {} protocol: {} ip: {} port: {}", this.mediatorName, this.mediatorProtocol, this.mediatorIp, this.mediatorPort);
        } catch (e) {
            throw new RuntimeException (e);
        }
    }

}

MediatorFramework.prototype.mediatorIp = "";
MediatorFramework.prototype.mediatorPort = "";
MediatorFramework.prototype.mediatorProtocol = "";
MediatorFramework.prototype.mediatorType = "";
MediatorFramework.prototype.contentType = "application/json";
MediatorFramework.prototype.acceptType = "application/json";
MediatorFramework.prototype.imLogger = new IntentLogger();

MediatorFramework.prototype.setImLogger = function (logger) {
    this.imLogger = logger;
};

/*
   function: configRestClient
    since: NSP 21.11
    short_description: Set Restclient ip address and port
    input:
        url:
          description: URL where payload needs to be sent
          type: String
          mandatory: True
        httpMethod:
          description: POST/PUT/PATCH/DELETE
          type: String
          mandatory: True
*/
MediatorFramework.prototype.configRestClient = function (url, httpMethod) {
    if (requestScope && requestScope.get() && requestScope.get().get("imLogger")) {
        this.imLogger = requestScope.get().get("imLogger");
    }

    this.imLogger.debug("[MEDIATOR-FWK] Mediator-type: {} protocol: {} ip: {} port: {} URL :{} mediatorHttpMethod :{}", this.mediatorType, this.mediatorProtocol, this.mediatorIp, this.mediatorPort, url, httpMethod);
    restClient.setIp(this.mediatorIp);
    restClient.setPort(this.mediatorPort);
    restClient.setProtocol(this.mediatorProtocol);
};

/*
   function: fetch
    since: NSP 21.11
    short_description: Performs HTTP GET
    input:
        targetUrl:
          description: URL to be fetched
          type: String
          mandatory: True
    output:
      responseObj:
        type: Object
        description: Object that contains Response success state, httpStatus Code, and body
    example_responses:
      Success: |
        response:{
            success : true,
            response : http GET response (as Object)
        }
      Failed: |
        response:{
            success: false,
            msg: "Failed to fetch service from MDC, got response {"ietf-restconf:errors":{"error":[{"error-type":"application","error-tag":"bad-element","error-path":"/restconf/data/network-device-mgr:network-devices/network-device=2.2.2.2/root/nokia-conf:/configure/a","error-message":"Query failed INTERNAL: Path not part of module : nokia-conf:/configure......"}]}",
            response: {"ietf-restconf:errors":{"error":[{"error-type":"application","error-tag":"bad-element","error-path":"/restconf/data/network-device-mgr:network-devices/network-device=2.2.2.2/root/nokia-conf:/configure/a","error-message":"Query failed INTERNAL: Path not part of module : nokia-conf:/configure......"}]}
          }
*/
MediatorFramework.prototype.fetch = function (targetUrl) {
    var restStartTime = Date.now();
    var result = {};
    this.configRestClient(targetUrl, "GET");
    this.imLogger.info("[MEDIATOR-FWK][GET] URL: {}", targetUrl);
    var self = this;
    restClient.get(targetUrl, "application/json", function (exception, httpStatus, response) {
        result = {
            success: false,
            httpStatus: httpStatus,
            msg: "null"
        };
        self.imLogger.info("[MEDIATOR-FWK][GET] took : {} ms response : {}", Date.now() - restStartTime, response);
        if (exception) {
            self.imLogger.error("[MEDIATOR-FWK][GET] Exception Found " + exception);
            result.msg = "Couldn't connect to " + this.mediatorType + ", got response " + response + ", exception " + exception;
        } else if (httpStatus !== 200 && httpStatus !== 201) {
            result.msg = "Failed to fetch service from " + this.mediatorType + ", got response " + response;
            result.response = JSON.parse(response);
        } else {
            result.success = true;
            result.msg = JSON.parse(response);
            if (response && response !== "") {
                try {
                    result.response = JSON.parse(response);
                } catch (e) {
                    result.response = response;
                }
            }
        }
    });
    return result;
};

/*
   function: post
    since: NSP 21.11
    short_description: Performs HTTP POST
    input:
        targetUrl:
          description: URL for POST
          type: String
          mandatory: True
        payloadObj:
          description: Payload for POST
          type: Object
          mandatory: True
    output:
      responseObj:
        type: Object
        description: Object that contains Response success state, httpStatus Code, and body
    example_responses:
      Success: |
        response:{
            success : true,
            response : http POST response (as String - May need to parse)
        }
      Failed: |
        response:{
            success: false,
            msg: "Failed deployment to NFMP, got response {"generic.GenericObject.configureChildInstanceException":{"description":"[ app: generic:property:mutator ] [ class: epipe.Site ] [ instance: epipe.Site.1.1.1.1 ] [ descr: property mtu cannot be set to value passed in : -2. Value out of range., {mtu=-2} ]"},"objectFullName":""}",
            response: "{\"generic.GenericObject.configureChildInstanceException\":{\"description\":\"[ app: generic:property:mutator ] [ class: epipe.Site ] [ instance: epipe.Site.1.1.1.1 ] [ descr: property mtu cannot be set to value passed in : -2. Value out of range., {mtu=-2} ]\"},\"objectFullName\":\"\"}"
          }
*/
MediatorFramework.prototype.post = function (targetUrl, payloadObj) {
    var restStartTime = Date.now();
    var result = {};
    this.configRestClient(targetUrl, "POST");
    this.imLogger.info("[MEDIATOR-FWK][POST] URL: {}, Payload: {}", targetUrl, JSON.stringify(payloadObj, null, 2));
    var self = this;
    restClient.post(targetUrl, this.contentType, JSON.stringify(payloadObj), this.acceptType, function (exception, httpStatus, response) {
        result = {
            success: false,
            httpStatus: httpStatus,
            msg: "null"
        };
        self.imLogger.info("[MEDIATOR-FWK][POST] Took : {} ms Response {}", Date.now() - restStartTime, response);
        if (exception) {
            self.imLogger.error("[MEDIATOR-FWK][POST] Exception {}", exception);
            result.msg = "Couldn't connect to " + this.mediatorType + ", got response " + response + ", exception " + exception;
        } else if (httpStatus !== 200 && httpStatus !== 201 && httpStatus !== 204) {
            result.msg = "Failed deployment to " + this.mediatorType + ", got response " + response;
            result.response = response;
        } else {
            result.success = true;
            result.msg = "Deployment to " + this.mediatorType + " was successful, got response " + response;
            if (response && response !== "") {
                try {
                    result.response = JSON.parse(response);
                } catch (e) {
                    result.response = response;
                }
            }
        }
    });
    return result;
};

/*
   function: patch
    since: NSP 21.11
    short_description: Performs HTTP PATCH
    input:
        targetUrl:
          description: URL for PATCH
          type: String
          mandatory: True
        payloadObj:
          description: Payload for PATCH
          type: Object
          mandatory: True
    output:
      responseObj:
        type: Object
        description: Object that contains Response success state, httpStatus Code, and body
    example_responses:
      Success: |
        response:{
            success : true,
            response : http PATCH response (as String - May need to parse)
        }
      Failed: |
        response:{
            success: false,
            msg: "Failed deployment to MDC, got response {"ietf-yang-patch:yang-patch-status":{"patch-id":"unknown","ietf-restconf:errors":{"error":[{"error-type":"application","error-tag":"invalid-value","error-path":"nokia-conf:/configure/service","error-message":null}]}}}",
            response: "{\"ietf-yang-patch:yang-patch-status\":{\"patch-id\":\"unknown\",\"ietf-restconf:errors\":{\"error\":[{\"error-type\":\"application\",\"error-tag\":\"invalid-value\",\"error-path\":\"nokia-conf:/configure/service\",\"error-message\":null}]}}}"
          }
*/
MediatorFramework.prototype.patch = function (targetUrl, payloadObj) {
    var restStartTime = Date.now();
    if (this.mediatorType === "NSP") {
        targetUrl = "patch/" + targetUrl;
    }
    var result = {};
    this.configRestClient(targetUrl, "PATCH");
    this.imLogger.info("[MEDIATOR-FWK][PATCH] URL: {}, Payload: {}", targetUrl, JSON.stringify(payloadObj, null, 2));
    var self = this;
    restClient.patch(targetUrl, this.contentType, JSON.stringify(payloadObj), this.acceptType, function (exception, httpStatus, response) {
        self.imLogger.info("[MEDIATOR-FWK][PATCH]  Took : {} ms response : {}", Date.now() - restStartTime, response);
        result = {
            success: false,
            httpStatus: httpStatus,
            msg: "null"
        };
        if (exception) {
            self.imLogger.error("[MEDIATOR-FWK][PATCH] Exception {}", exception);
            result.msg = "Couldn't connect to " + this.mediatorType + ", got response " + response + ", exception " + exception;
        } else if (httpStatus !== 200 && httpStatus !== 201 && httpStatus !== 202 && httpStatus !== 204) {
            result.msg = "Failed deployment to " + this.mediatorType + "got response " + response;
            result.response = response;
        } else {
            result.success = true;
            result.msg = "Deployment to " + this.mediatorType + " was successful, got response " + response;
            if (response && response !== "") {
                try {
                    result.response = JSON.parse(response);
                } catch (e) {
                    result.response = response;
                }
            }
        }
    });
    return result;
};

/*
   function: put
    since: NSP 21.11
    short_description: Performs HTTP PUT
    input:
        targetUrl:
          description: URL for PUT
          type: String
          mandatory: True
        payloadObj:
          description: Payload for PUT
          type: Object
          mandatory: True
    output:
      responseObj:
        type: Object
        description: Object that contains Response success state, httpStatus Code, and body
    example_responses:
      Success: |
        response:{
            success : true,
            response : http PUT response (as String - May need to parse)
        }
      Failed: |
        response:{
            success: false,
            msg: "Failed deployment to MDC, got response {"ietf-yang-patch:yang-patch-status":{"patch-id":"unknown","ietf-restconf:errors":{"error":[{"error-type":"application","error-tag":"invalid-value","error-path":"nokia-conf:/configure/service","error-message":null}]}}}",
            response: "{\"ietf-yang-patch:yang-patch-status\":{\"patch-id\":\"unknown\",\"ietf-restconf:errors\":{\"error\":[{\"error-type\":\"application\",\"error-tag\":\"invalid-value\",\"error-path\":\"nokia-conf:/configure/service\",\"error-message\":null}]}}}"
          }
*/
MediatorFramework.prototype.put = function (targetUrl, payloadObj) {
    var restStartTime = Date.now();
    var result = {};
    this.configRestClient(targetUrl, "PUT");
    var self = this;
    this.imLogger.info("[MEDIATOR-FWK][PUT] URL: {}, Payload: {}", targetUrl, JSON.stringify(payloadObj, null, 2));
    restClient.put(targetUrl, this.contentType, JSON.stringify(payloadObj), this.acceptType, function (exception, httpStatus, response) {
        self.imLogger.info("[MEDIATOR-FWK][PUT] Took : {} ms response :{}", Date.now() - restStartTime, response);
        result = {
            success: false,
            httpStatus: httpStatus,
            msg: "null"
        };
        if (exception) {
            self.imLogger.error("[MEDIATOR-FWK][PUT] Exception Found {}", exception);
            result.msg = "Couldn't connect to " + this.mediatorType + ", got response " + response + ", exception " + exception;
        } else if (httpStatus !== 200 && httpStatus !== 201 && httpStatus !== 204) {
            result.msg = "Failed deployment to " + this.mediatorType + ", got response " + response;
            result.response = response;
        } else {
            result.success = true;
            result.msg = "Deployment to " + this.mediatorType + " was successful, got response " + response;
            if (response && response !== "") {
                try {
                    result.response = JSON.parse(response);
                } catch (e) {
                    result.response = response;
                }
            }
        }
    });
    return result;
};

/*
   function: delete
    since: NSP 21.11
    short_description: Performs HTTP DELETE
    input:
        deleteUrl:
          description: URL for DELETE
          type: String
          mandatory: True
    output:
      responseObj:
        type: Object
        description: Object that contains Response success state, httpStatus Code, and body
    example_responses:
      Success: |
        response:{
            success : true,
            response : http DELETE response (as String - May need to parse)
        }
      Failed: |
        response:{
            success: false,
            msg: "Failed deployment to MDC, got response {"ietf-restconf:errors":{"error":[{"error-type":"application","error-tag":"invalid-value","error-path":"/restconf/data/network-device-mgr:network-devices/network-device=2.2.2.2/root/nokia-conf:/configure/fasdfasdf","error-message":"java.lang.IllegalArgumentException: Path not part of module : nokia-conf:/configure/fasdfasdf"}]}}",
            response: "{\"ietf-restconf:errors\":{\"error\":[{\"error-type\":\"application\",\"error-tag\":\"invalid-value\",\"error-path\":\"/restconf/data/network-device-mgr:network-devices/network-device=2.2.2.2/root/nokia-conf:/configure/fasdfasdf\",\"error-message\":\"java.lang.IllegalArgumentException: Path not part of module : nokia-conf:/configure/fasdfasdf\"}]}}"
          }
*/
MediatorFramework.prototype.delete = function (deleteUrl) {
    var restStartTime = Date.now();
    var result = {};
    this.configRestClient(deleteUrl, "DELETE");
    var self = this;
    restClient.delete(deleteUrl, "application/json", function (exception, httpStatus, response) {
        self.imLogger.info("[MEDIATOR-FWK][DELETE]  deleteUrl: {} DELETE took : {} ms response : {}", deleteUrl, Date.now() - restStartTime, response);
        result = {
            success: false,
            httpStatus: httpStatus,
            msg: "null"
        };
        if (exception) {
            self.imLogger.error("[MEDIATOR-FWK][DELETE] Delete Exception Found {}", exception);
            result.msg = "Couldn't connect to " + this.mediatorType + ", got response " + response + ", exception " + exception;
        } else if (httpStatus !== 200 && httpStatus !== 201 && httpStatus !== 204) {
            result.msg = "Failed deployment to " + this.mediatorType + ", got response " + response;
            result.response = response;
        } else {
            result.success = true;
            result.msg = "Deployment to " + this.mediatorType + " was successful, got response " + response;
            if (response && response !== "") {
                try {
                    result.response = JSON.parse(response);
                } catch (e) {
                    result.response = response;
                }
            }
        }
    });
    return result;
};

MediatorFramework.prototype.setImLogger = function (logger) {
    this.imLogger = logger;
};
