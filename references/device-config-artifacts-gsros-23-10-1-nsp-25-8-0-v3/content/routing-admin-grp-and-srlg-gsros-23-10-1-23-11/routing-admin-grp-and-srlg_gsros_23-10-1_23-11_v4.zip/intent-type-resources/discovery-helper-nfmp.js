var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource("model-device-mapping.js"), name: "model-device-mapping"});

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let modelDeviceMapping = new ModelDeviceMapping();
    let util = new utilities();
    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let searchPayLoadAdminGrp = this.constructSearchString(neId, "rtr.AdminGroupPolicy");
        let searchResponseAdminGrp = nfmpFwk.post("/v3/search", searchPayLoadAdminGrp);
        if (!searchResponseAdminGrp.success)
        {
            logger.error("Failed to find Admin-groups on NE " + neId);
        }
        searchResponseAdminGrp = JSON.parse(searchResponseAdminGrp.response);

        let searchPayLoadSrlgGrp =this.constructSearchString(neId, "rtr.SharedRiskLinkGroup");
        let searchResponseSrlgGrp = nfmpFwk.post("/v3/search", searchPayLoadSrlgGrp);
        if (!searchResponseSrlgGrp.success)
        {
            logger.error("Failed to find srlg-groups on NE " + neId);
        }
        searchResponseSrlgGrp = JSON.parse(searchResponseSrlgGrp.response);


        let deviceConfig = {
            "admin-group": searchResponseAdminGrp["rtr.AdminGroupPolicy"] ? searchResponseAdminGrp["rtr.AdminGroupPolicy"] : [],
            "srlg-group": searchResponseSrlgGrp["rtr.SharedRiskLinkGroup"] ? searchResponseSrlgGrp["rtr.SharedRiskLinkGroup"] : []
        };
        return deviceConfig;
    }
    this.constructSearchString = function (neId, fullClassName) {
        let jsonPayLoad = {
            "fullClassName": fullClassName,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            }
        };
        return jsonPayLoad;
    }
    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        logger.info("***********************************deviceConfig***********************************************");
        logger.info(JSON.stringify(deviceConfig));
        logger.info("************************************parsedDefaultTargetData***********************************");
        logger.info(JSON.stringify(parsedDefaultTargetData));
        logger.info("**************************************************END******************************************");
        if (null !== deviceConfig)
        {
            let adminGrpArray = this.extractAdminGrpProperties(parsedDefaultTargetData["if-attribute"]["admin-group"], deviceConfig["admin-group"]);
            parsedDefaultTargetData["if-attribute"]["admin-group"] = adminGrpArray;

            let srlgGrpArray = this.extractSrlgGrpProperties(parsedDefaultTargetData["if-attribute"]["srlg-group"], deviceConfig["srlg-group"]);
            parsedDefaultTargetData["if-attribute"]["srlg-group"] = srlgGrpArray;
        }
        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData));
        return parsedDefaultTargetData;
    }
    this.extractAdminGrpProperties = function (defaultTargetData, deviceConfig) {
        let adminGrpArray = [];
        if (!Array.isArray(deviceConfig))
        {
            deviceConfig = [deviceConfig];
        }

        let adminGrpData = defaultTargetData;

        let mappings = modelDeviceMapping.getAdminGroupMapping();
        for (let i = 0; i < deviceConfig.length; i++)
        {
            let deviceAdminGrpConfig = deviceConfig[i];
            let keys = Object.keys(adminGrpData[0]);
            logger.info("keys = " + keys);
            for (let j = 0; j < keys.length; j++)
            {
                let targetKey = keys[j];
                let targetObj = adminGrpData[0][targetKey];
                let mappedKey = targetKey;
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, adminGrpData, deviceAdminGrpConfig);
            }
            adminGrpArray.push(JSON.parse(JSON.stringify(adminGrpData[0])));
        }
        return adminGrpArray;
    }

    this.extractSrlgGrpProperties = function (defaultTargetData, deviceConfig) {
        let srlgGrpArray = [];
        if (!Array.isArray(deviceConfig))
        {
            deviceConfig = [deviceConfig];
        }
        let srlgGrpData = defaultTargetData;
        let mappings = modelDeviceMapping.getSrlgGroupMapping();
        for (let i = 0; i < deviceConfig.length; i++)
        {
            let deviceSrlgGrpConfig = deviceConfig[i];
            let keys = Object.keys(srlgGrpData[0]);
            logger.info("keys = " + keys);
            for (let j = 0; j < keys.length; j++)
            {
                let targetKey = keys[j];
                let targetObj = srlgGrpData[0][targetKey];
                let mappedKey = targetKey;
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, srlgGrpData, deviceSrlgGrpConfig);
            }
            srlgGrpArray.push(JSON.parse(JSON.stringify(srlgGrpData[0])));
        }
        return srlgGrpArray;
    }

    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, deviceConfig) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = deviceConfig[nfmpKey];
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[0][targetKey] = deviceValue;
    }
}
