function ColorMapping() {
    this.colorMapping = function () {
        var mapping = {};
        mapping[10] = 'adminTag10';
        mapping[20] = 'adminTag20';
        return mapping;
    }
}
