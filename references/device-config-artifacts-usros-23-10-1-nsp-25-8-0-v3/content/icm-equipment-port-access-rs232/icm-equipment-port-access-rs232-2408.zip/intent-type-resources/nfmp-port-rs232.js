var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpPort() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    let nfmpFwk = new NfmpFwk();
    var savedObjects;
    var currentObjects;
    var isAudit = false;

    this.synchronize = function(input, result,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {
        // setting up topology
        var savedTopology = input.getCurrentTopology();
        logger.info("Saved Topology = "+savedTopology);
        savedObjects = {};
        currentObjects = {};
        //loading the saved objects from topology
        this.loadSavedObjectsFromTopology(savedTopology);
        var parseTarget = new ParseTarget();
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        logger.info("Target device = " + target);
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());
        logger.info("Target port = " + intentConfig[uniqueIdentifier]);
        intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        logger.info("Configuration to be pushed = "+JSON.stringify(intentConfig));

        if (input.getNetworkState().name() == "delete"){
            return this.syncDelete(target,intentConfig[uniqueIdentifier],result);
        }

        this.createOrModify(target,intentConfig[uniqueIdentifier],intentConfig);
        var currentTopo = this.loadCurrentObjectsToTopology(target);

        return util.setSuccessResult(result,currentTopo);
    }

    this.audit = function(target, config, svcTopo, adminState, auditReport,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {
        var savedTopology = svcTopo;
        currentObjects = {};
        var parseTarget = new ParseTarget();
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        var target = parseTarget.getNeIdFromTarget(target);
        logger.info("Target device = " + target);
        logger.info("Target port = " + intentConfig[uniqueIdentifier]);
        intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        logger.info("auditing configuration = "+JSON.stringify(intentConfig));
        isAudit = true;

        if(intentConfig){
            this.auditAndComparePort(target,intentConfig[uniqueIdentifier],intentConfig,auditReport);
            if(intentConfig['serialChannel']){
                this.auditAndCompareSerialChannel(target,intentConfig[uniqueIdentifier],intentConfig,auditReport);
            }

        }else{
            throw "configuration not available in the intent";
        }

        return auditReport;
    }

    this.createOrModify = function(target,portId,intentConfig){

        var result = this.portLevel(target,portId,intentConfig);
        this.modifyRequest(target, result);

        var result_serialChannel = this.createSerialChannel(target, portId, intentConfig);
        this.modifyRequest(target, result_serialChannel);

        if(intentConfig["serialChannel"]["ds0Channel-group"]){
            this.setDS0ChannelGroupsAdminState(target, portId, intentConfig);
        }
        return result;
    }

    this.auditAndComparePort = function(target,portId,intentConfig,auditReport){
        // port level attributes
        var portLevelPayload = this.portLevel(target,portId,intentConfig);
        var result = this.auditRequest(target, portLevelPayload);

        auditReport = util.reportMisaligned(target, result,auditReport);
        return auditReport;
    }

    this.auditAndCompareSerialChannel = function(target,portId,intentConfig,auditReport){

        var serialChannelPayload = this.createSerialChannel(target,portId,intentConfig);
        var result = this.auditRequest(target, serialChannelPayload);

        auditReport = util.reportMisaligned(target, result,auditReport);
        return auditReport;
    }

    this.portLevel = function(target,portId,intentConfig){
        var fullClassName = "equipment.PhysicalPort";                    // full class name for port
        var portLevelFdn = util.getBaseFdnForPort(target,portId);        // portlevel attributes fdn
        var objectFullName = portLevelFdn;                               // objectFullName is same as fdn for port level
        var properties = {};
        var childProperties = {};

        (intentConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";
        if (intentConfig["description"]){
            properties["description"] = intentConfig["description"];
        }
        var serialPortSpecificsPayload = this.createSerialPortSpecifics(target,intentConfig);
        childProperties['tdmequipment.SerialPortSpecifics'] = serialPortSpecificsPayload['tdmequipment.SerialPortSpecifics'];

        var portLevelPayload = util.editPayload(portLevelFdn,properties,childProperties,fullClassName,objectFullName);
        return portLevelPayload;
    }

    this.createSerialPortSpecifics = function(target,intentConfig){
        var fullClassName = "tdmequipment.SerialPortSpecifics";
        var properties = {};
        if(!isAudit){
            properties["serialType"] = "rs232";
        }
        return this.createChildObjectPayload(fullClassName,properties,null);

    }

    this.createSerialChannel = function(target, portId, intentConfig) {

        var fullClassName = "equipment.PhysicalPort";
        var serialChannelConfig = intentConfig["serialChannel"];
        var portLevelFdn = util.getBaseFdnForPort(target,portId);
        var objectFullName = portLevelFdn;
        var properties = {};
        var childProperties = {};

        if(serialChannelConfig){
            var modifyserialChannelPayload = this.modifySerialChannel(target,portId, intentConfig);
            childProperties['tdmequipment.SerialChannel'] = modifyserialChannelPayload['tdmequipment.SerialChannel'];
        }
        var serialChannelPayload = util.editPayload(portLevelFdn,properties,childProperties,fullClassName,objectFullName);
        return serialChannelPayload;


    }

    this.modifySerialChannel = function(target,portId, intentConfig) {
        var fullClassName = "tdmequipment.SerialChannel";
        var serialChannelConfig = intentConfig["serialChannel"];
        var portLevelFdn = util.getBaseFdnForPort(target,portId);
        var serialChannelFdn = portLevelFdn + ":serial-1";
        var objectFullName = serialChannelFdn;
        var properties = {};
        var childProperties = {};

        if(intentConfig["serialChannel"])
        {
            (serialChannelConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";
            if (!isAudit)
            {
                properties["portChannelType"] = "rs232";
                properties['displayedLocalChannelId'] = 1;
            }
            properties["serialSocket"] = serialChannelConfig["serial-socket-enabled"];

            var serialChannelSpecificsPayload = this.createSerialChannelSpecifics(target,intentConfig);
            childProperties['tdmequipment.SerialChannelSpecifics'] = serialChannelSpecificsPayload['tdmequipment.SerialChannelSpecifics'];

            if(intentConfig["serialChannel"]["socket"])
            {
                var serialSocketPayload =  this.createSerialSocket(target,intentConfig);
                childProperties['tdmequipment.SerialSocket'] =serialSocketPayload['tdmequipment.SerialSocket'];
            }

            var ds0ChannelGroupPayload =  this.createDS0ChannelGroup(target,intentConfig, portLevelFdn);
            childProperties['tdmequipment.DS0ChannelGroup'] =ds0ChannelGroupPayload['tdmequipment.DS0ChannelGroup'];

            return this.createChildObjectPayload(fullClassName,properties,childProperties);
        }
    }

    this.createSerialSocket = function(target, intentConfig){
        var fullClassName = "tdmequipment.SerialSocket";
        var serialSocket = intentConfig["serialChannel"]["socket"];
        var properties = {};

        (serialSocket["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";
        if(serialSocket["description"])
        {
            properties["description"] = serialSocket["description"];
        }

        return this.createChildObjectPayload(fullClassName,properties,null);

    }

    this.createSerialChannelSpecifics = function(target,intentConfig){
        var fullClassName = "tdmequipment.SerialChannelSpecifics";
        var serialChannelSpecificsConfig = intentConfig["serialChannel"];
        var properties = {};

        if(serialChannelSpecificsConfig["speed"])
        {
            properties["speed"] = 'speed' + serialChannelSpecificsConfig["speed"];
        }

        if(serialChannelSpecificsConfig["device-mode"])
        {
            properties["serialMode"] = serialChannelSpecificsConfig["device-mode"];
            if(!isAudit){
                if(properties["serialMode"] == "asynchronous"){
                    properties["clockSource"] = 'unspecified';
                }
                else{
                    properties["clockSource"] = 'slave';
                }
            }
        }
        return this.createChildObjectPayload(fullClassName,properties,null);

    }

    this.createDS0ChannelGroup = function(target,intentConfig, portLevelFdn){
        var fullClassName = "tdmequipment.DS0ChannelGroup";
        var ds0ChannelGroupConfig = intentConfig["serialChannel"]["ds0Channel-group"];
        var objectFullName = portLevelFdn + ":serial-1:ds0Grp-1";
        var properties = {};

        if(intentConfig['serialChannel']["ds0Channel-group"])
        {
            if(ds0ChannelGroupConfig["channel-group-id"] = "1"){
                properties["displayedLocalChannelId"] = "1";
            }
            if(!isAudit){
                properties["portChannelType"] = "pdhDs0Grp";
                properties["mode"] = "access";
                properties['administrativeState'] = "portOutOfService";
            }
            if(isAudit){
                (ds0ChannelGroupConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";
            }
            properties["encapType"] = util.convertToNfmpEncapType(ds0ChannelGroupConfig["encapType"]);
            if(ds0ChannelGroupConfig["description"]){
                properties["description"] = ds0ChannelGroupConfig["description"];
            }
            return this.createChildObjectPayload(fullClassName, properties,null);
        }
        else
        {
            this.removeDS0ChannelGroup(target, fullClassName, objectFullName);
            return {};
        }

    }


    this.removeDS0ChannelGroup = function (target, fullClassName, objectFullName) {

        var searchPayLoad =  util.constructSearchString(fullClassName, objectFullName);
        var searchResponse = nfmpFwk.find(target, searchPayLoad);
        if(searchResponse['response'] != "{}")
        {
            var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
            if (!deleteResult.success) {
                logger.info("[NFMP-PORT-RS232] removeDS0ChannelGroup(): Unable to Delete: " + deleteResult.msg);
                throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
            }
        }
        return {};
    }


    this.setDS0ChannelGroupsAdminState = function(target, portId, intentConfig){
        var fullClassName = "tdmequipment.DS0ChannelGroup";
        var ds0ChannelGroupFdn = util.getBaseFdnForPort(target,portId) + ":serial-1" + ":ds0Grp-1";
        var objectFullName = ds0ChannelGroupFdn;
        var ds0ChannelGroupConfig = intentConfig["serialChannel"]["ds0Channel-group"];
        var properties = {};
        (ds0ChannelGroupConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";
        var modifyAdminStatePayload = util.editPayload(ds0ChannelGroupFdn,properties,null,fullClassName,objectFullName);
        if(isAudit){
            return modifyAdminStatePayload;
        }
        this.modifyRequest(target,modifyAdminStatePayload);

    }

    this.createChildObjectPayload = function(fullClassName,properties, childProperties){
        var childObjectPayLoad = {};
        childObjectPayLoad[fullClassName] = properties;
        if(childProperties != null || childProperties != undefined)
        {
            childObjectPayLoad[fullClassName]["children-Set"] = childProperties;
        }
        return childObjectPayLoad;
    }

    this.auditRequest = function(target,payload){
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.modifyRequest = function(target,payload){
        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");

        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.syncDelete = function (target,portId,result) {

        var portLevelFdn = util.getBaseFdnForPort(target,portId);
        var objectFullName = portLevelFdn+":serial-1";
        logger.info("Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success) {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }

        result.setSuccess(true);
    }

    this.xml2object = function(xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('Input JSON: '+ json)
        return JSON.parse(json);
    }

    this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }
            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }
            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }

    this.loadCurrentObjectsToTopology = function(target) {
        var currentTopo = topologyFactory.createServiceTopology();
        if(Object.keys(currentObjects).length){
            for(var key in currentObjects){
                objectId = mapFwk.get(currentObjects,key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key,objectId,"INFRASTRUCTURE",target,""));
            }
        }
        return currentTopo;
    }

    this.loadSavedObjectsFromTopology = function(savedTopology) {
        if(savedTopology){
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0){
                topoObjects.forEach(function(topoObject){
                    mapFwk.set(savedObjects,topoObject.getObjectType(),topoObject.getObjectRelativeObjectID());
                });
            }
        }
    }



    this.deleteRemovedObjects = function(target) {
        if(Object.keys(savedObjects).length > 0){
            for(var key in savedObjects){
                var value = mapFwk.get(currentObjects,key);
                if(value == undefined || value =="undefined" || value == null) {
                    logger.info("To be Deleted " + key);
                    var objectFullName = key;
                    if (target && String(target).indexOf(':') !== -1) {
                           objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
                    }
                    var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

                    if (!deleteResult.success) {
                        throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
                    }
                }
            }
        }
    };
}
