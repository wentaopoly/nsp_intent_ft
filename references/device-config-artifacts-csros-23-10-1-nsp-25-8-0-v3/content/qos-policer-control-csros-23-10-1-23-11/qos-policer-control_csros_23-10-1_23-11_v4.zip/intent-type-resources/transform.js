function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
	   if(xpath == "maxframeBasedBWPercent" || xpath == "policing-PolicerControlArbiter.maxframeBasedBWPercent")
        {
            if(targetValue && !isNaN(targetValue) && !targetValue.contains("."))
            {
                targetValue = Number(targetValue);
                targetValue = targetValue.toFixed(1);
            }
        }
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey) {
         return targetValue;
    }
}
