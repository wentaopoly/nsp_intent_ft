load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {

    this.setSuccessResult = function (result, savedTopology) {
        result.setSuccess(true);
        if (savedTopology !== undefined) {
            result.setTopology(savedTopology);
        }
        return result;
    }

    this.reportMisaligned = function (target, result, auditReport) {
        var report = JSON.parse(result.response);
        if (!report.aligned) {
            for (var i = 0; i < report.misalignedAttributes.length; i++) {
                var attributeData = report.misalignedAttributes[i];
                if (attributeData.expected == "present") {
                    //misaligned object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                } else if (attributeData.expected == "not present") {
                    //undesired object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                } else {
                    var attributeFields = (attributeData.name).split("|");
                    if (attributeFields.length == 3 && attributeFields[2] == "type") {
                        attributeData.expected = this.transformIntentFilterType(attributeData.expected);
                        attributeData.actual = this.transformIntentFilterType(attributeData.actual);
                    }
                    var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                    auditReport.addMisAlignedAttribute(misalignedAttribute);
                }

            }
        }
        return auditReport
    }
    this.editPayload = function (fdn, properties, childProperties, fullClassName, objectFullName) {
        var payload = {};
        var configInfo = {};
        configInfo[fullClassName] = properties;
        configInfo[fullClassName]["children-Set"] = childProperties;
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName;
        payload["clearOnDeployFailure"] = true;
        payload["configInfo"] = configInfo;
        return payload;
    }


    this.getIfObjectExists = function (className, objectFullName) {

        let nfmpFwk = new NfmpFwk();
        var searchObjectJson = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        var ret = false;
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        logger.info(LOG_PREFIX + "Port Access Ingress Policy search results : " + JSON.stringify(resultFetch));
        var finalResponse = JSON.parse(resultFetch.response);
        if (JSON.stringify(finalResponse) === JSON.stringify({})) {
            logger.info(LOG_PREFIX + "Search results is empty: " + JSON.stringify(finalResponse));
            finalResponse = null;
        } else if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse["sasqos.PortAccessIngress"]];
            logger.info(LOG_PREFIX + "Search results: " + JSON.stringify(finalResponse));
        }
        return finalResponse;
    }

    /*
       function: delay
       description: Sometimes the object creation takes time, we can use delay for child-level operation.
    */
    this.delay = function (milliseconds) {
        var date = new Date();
        date.setMilliseconds(date.getMilliseconds() + milliseconds);
        while (new Date() < date) {
        }
    }

    this.bftransformColorMode = function (value) {
        var nfmptransformRateMode = "";
        switch (value) {
            case "colorAware":
                nfmptransformRateMode = "color-aware";
                break;
            case "colorBlind":
                nfmptransformRateMode = "color-blind";
                break;
            default:
                nfmptransformRateMode = undefined;
        }
        return nfmptransformRateMode;
    }
    this.gftransformColorMode = function (value) {
        var nfmptransformRateMode = "";
        switch (value) {
            case "color-aware":
                nfmptransformRateMode = "colorAware";
                break;
            case "color-blind":
                nfmptransformRateMode = "colorBlind";
                break;
            default:
                nfmptransformRateMode = undefined;
        }
        return nfmptransformRateMode;
    }
    this.bftransformRateMode = function (input) {
        var nfmptransformRateMode = "";
        switch (input) {
            case "trtcm1":
                nfmptransformRateMode = "trTCM(RFC-2698)";
                break;
            case "trtcm2":
                nfmptransformRateMode = "trTCM(RFC-4115)";
                break;
            case "srtcm":
                nfmptransformRateMode = "srTCM";
                break;
            default:
                nfmptransformRateMode = undefined;
        }
        return nfmptransformRateMode;
    }

    this.gftransformRateMode = function (input) {
        var nfmptransformRateMode = "";
        switch (input) {
            case "trTCM(RFC-2698)":
                nfmptransformRateMode = "trtcm1";
                break;
            case "trTCM(RFC-4115)":
                nfmptransformRateMode = "trtcm2";
                break;
            case "srTCM":
                nfmptransformRateMode = "srtcm";
                break;
            default:
                nfmptransformRateMode = undefined;
        }
        return nfmptransformRateMode;
    }

    this.gfconvertToTableClassificationCriteria = function (input) {
        var nfmpTableClassification = "";
        switch (input) {
            case "use-dscp":
                nfmpTableClassification = "dscp";
                break;
            case "use-dot1p":
                nfmpTableClassification = "dot1p";
                break;
            case "both-dscp-dot1p":
                nfmpTableClassification = "both";
                break;
            case "none":
                nfmpTableClassification = "none";
                break;
            default:
                nfmpTableClassification = undefined;
        }
        return nfmpTableClassification;
    }
    this.bfconvertToTableClassificationCriteria = function (input) {
        var nfmpTableClassification = "";
        switch (input) {
            case "dscp":
                nfmpTableClassification = "use-dscp";
                break;
            case "dot1p":
                nfmpTableClassification = "use-dot1p";
                break;
            case "both":
                nfmpTableClassification = "both-dscp-dot1p";
                break;
            case "none":
                nfmpTableClassification = "none";
                break;
            default:
                nfmpTableClassification = undefined;
        }
        return nfmpTableClassification;
    }


    this.bfNfmpDot1pClassification = function (input) {
        if (input !== undefined && input.startsWith("sasDot1pClassification:Dot1p-")) {
            var numericValue = parseInt(input.replace("sasDot1pClassification:Dot1p-", ""));
            return numericValue;
        }
        return input;
    }
    this.gfNfmpDot1pClassification = function (input) {
        if (input === undefined) {
            return undefined;
        }
        if (!input.toString().startsWith("sasDot1pClassification:Dot1p-")) {
            input = "sasDot1pClassification:Dot1p-" + input;
        }
        return input;
    };
    this.bfNfmpDscpClassification = function (input) {
        if (input !== undefined && input.startsWith("sasDSCPClassification:Dscp-")) {
            var numericValue = parseInt(input.replace("sasDSCPClassification:Dscp-", ""));
            return numericValue;
        }
        return input;
    }
    this.gfNfmpDscpClassification = function (input) {
        if (input === undefined) {
            return undefined;
        }
        if (!input.toString().startsWith("sasDSCPClassification:Dscp-")) {
            input = "sasDSCPClassification:Dscp-" + input;
        }
        return input;
    };
    this.gftransformCounterMode = function (value) {
        var nfmptransformRateMode = "";
        switch (value) {
            case "in-out-profile-count":
                nfmptransformRateMode = "inOutProfileCount";
                break;
            case "forward-drop-count":
                nfmptransformRateMode = "forwardDropCount";
                break;
            default:
                nfmptransformRateMode = undefined;
        }
        return nfmptransformRateMode;
    }
    this.bftransformCounterMode = function (value) {
        var nfmptransformRateMode = "";
        switch (value) {
            case "inOutProfileCount":
                nfmptransformRateMode = "in-out-profile-count";
                break;
            case "forwardDropCount":
                nfmptransformRateMode = "forward-drop-count";
                break;
            default:
                nfmptransformRateMode = undefined;
        }
        return nfmptransformRateMode;
    }
    this.distribute = function (neId, objectFullName, isLocalEdit) {
        var payload = {};
        var policyDefination = "policy.PolicyDefinition.distributeV2";
        if (isLocalEdit)
        {
            policyDefination = "policy.PolicyDefinition.setDistributionModeToLocalEditOnly";
        }
        payload[policyDefination] = {};
        payload[policyDefination]["clearOnDeployFailure"] = true;
        payload[policyDefination]["deployer"] = "immediate";
        payload[policyDefination]["instanceFullName"] = objectFullName;
        payload[policyDefination]["siteIds"] = {};
        payload[policyDefination]["siteIds"]["string"] = neId;
        return payload;
    }
    this.isObjectExists = function (className, objectFullName) {
        let nfmpFwk = new NfmpFwk();
        var ret = false;
        var searchObjectJson = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);

        logger.info(LOG_PREFIX + "isObjectExists data = {}", JSON.stringify(resultFetch));
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(LOG_PREFIX + "Final response of search = {}", JSON.stringify(finalResponse));
        if (Object.keys(finalResponse).length !== 0 && finalResponse.constructor === Object)
        {
            ret = true;
        }
        logger.info(LOG_PREFIX + "isObjectExists = {} ", ret);
        return ret;
    }

    this.modifyNeIdForIpV6 = function (objectFullName, neId) {
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }
}
