load({script: resourceProvider.getResource('nsp-restconf-fwk.js'), name: 'nsp-restconf-fwk'});
load({script: resourceProvider.getResource("discovery-helper-nfmp.js"), name: "discovery-helper-nfmp"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function ICMFwk() {
    const nspRestconfFwk = new NspRestconfFwk();

    // get the device configuration
    this.getDeviceConfiguration = function (targetWithTemplate, initialPropertyName) {
        var targetData = this.getTargetData(targetWithTemplate, initialPropertyName);
        return targetData;
    }
    this.getDefaultTargetData = function (templateName) {
        var templateObj = nspRestconfFwk.getByXpath("/nsp-icm:icm/templates/template=" + templateName);
        var defaultTargetData = templateObj['nsp-icm:template'][0]['target-data-struct'];
        return defaultTargetData;
    }
    this.getTargetData = function (targetWithTemplate, initialPropertyName) {
        var targetAr = targetWithTemplate.split("#");
        var templateName = targetAr[0];
        var defaultTargetData = this.getDefaultTargetData(templateName);
        var deviceConfig = this.getConfigurations(targetWithTemplate, initialPropertyName);
        if (typeof deviceConfig === 'string' && deviceConfig.indexOf('Failed to fetch service') > -1)
        {
            logger.error(deviceConfig);
            return deviceConfig;
        }
        return this.extractDeviceConfig(templateName, defaultTargetData, deviceConfig, initialPropertyName, targetWithTemplate);
    }
    this.getConfigurations = function (targetWithTemplate, initialPropertyName) {
        var discoveryHelper = this.getDiscoveryHelper();
        return discoveryHelper.getDeviceConfiguration(targetWithTemplate, initialPropertyName);

    }
    this.getDiscoveryHelper = function () {
        return this.createNfmpDiscoveryHelper()
    }
    this.createNfmpDiscoveryHelper = function () {
        return new NfmpDiscoveryHelper();
    }
    this.extractDeviceConfig = function (templateName, defaultTargetData, deviceConfig, initialPropertyName, targetWithTemplate) {
        var discoveryHelper = this.getDiscoveryHelper();
        return discoveryHelper.extractDeviceConfig(defaultTargetData, deviceConfig, initialPropertyName, targetWithTemplate);
    }
}
