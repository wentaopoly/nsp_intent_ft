var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource("model-device-mapping.js"), name: "model-device-mapping"});


function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();
    let modelDeviceMapping = new ModelDeviceMapping();
    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let keyGroupId = target.split("#")[2];
        let searchPayLoad = this.constructSearchString(neId, keyGroupId);
        let searchResponse = nfmpFwk.post("/v3/search", searchPayLoad);
        logger.info("searchResponse == {} ", JSON.stringify(searchResponse))
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find NGE Key-Group-Id  : " + keyGroupId);
        }
        searchResponse = JSON.parse(searchResponse.response);
        logger.info("searchResponse = {}", JSON.stringify(searchResponse));
        return searchResponse;
    }
    this.constructSearchString = function (neId, keyGroupId) {
        let objectFullName = "ngeMgr:kg-0.0.0.0/" + keyGroupId;
        let fullClassName = "nge.KeyGroup";
        let jsonPayLoad = {
            "fullClassName": "nge.KeyGroup",
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            },
            "resultFilter": {
                "children": {
                    "resultFilter": [
                        {
                            "children": "",
                            "attribute": [
                                "sdpFdn",
                                "destinationNodeId",
                                "sourceNodeId",
                                "pathId",
                                "objectFullName",
                                "adminEncryptionStatus"
                            ],
                            "class": "nge.KeyGroupSdpBinding"
                        }
                    ]
                }
            }
        }
        return jsonPayLoad;
    }
    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        let keyGroupConfig = deviceConfig["nge.KeyGroup"];
        let sdpConfig = {};
        if (deviceConfig["nge.KeyGroup"]["children-Set"])
        {
            if (deviceConfig["nge.KeyGroup"]["children-Set"]["nge.KeyGroupSdpBinding"])
            {
                sdpConfig = deviceConfig["nge.KeyGroup"]["children-Set"]["nge.KeyGroupSdpBinding"]
            }
        }
        deviceConfig = {
            "keyGroupConfig": keyGroupConfig,
            "sdpConfig": sdpConfig
        }
        logger.info("***********************************deviceConfig***********************************************");
        logger.info(JSON.stringify(deviceConfig));
        logger.info("************************************parsedDefaultTargetData***********************************");
        logger.info(JSON.stringify(parsedDefaultTargetData));
        logger.info("**************************************************END******************************************");
        if (null !== deviceConfig)
        {
            extractKeyGroupProperties(parsedDefaultTargetData["network-group-encryption"], deviceConfig["keyGroupConfig"]);
            let sdp = extractSdpProperties(parsedDefaultTargetData["network-group-encryption"]["sdp"], deviceConfig["sdpConfig"]);
            parsedDefaultTargetData['network-group-encryption']['sdp'] = sdp;
        }
        clearEmpties(parsedDefaultTargetData);
        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData));
        return parsedDefaultTargetData;
    }

    function extractKeyGroupProperties(defaultTargetData, deviceConfig) {
        let keys = Object.keys(defaultTargetData);
        //logger.info("keys = " + keys)
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj))
            if (targetObj !== null && typeof targetObj === 'object')
            {
                traverseAndUpdateKeyGroupConfig(targetKey, targetObj, deviceConfig);
            }
        }
        return defaultTargetData;
    }

    function extractSdpProperties(sdpTargetData, deviceConfig) {
        if (!Array.isArray(deviceConfig))
        {
            deviceConfig = [deviceConfig];
        }
        let sdpArray = [];
        let sdpData = sdpTargetData[0];
        let mappings = modelDeviceMapping.getSdpMapping();
        for (let i = 0; i < deviceConfig.length; i++)
        {
            let deviceSdpConfig = deviceConfig[i];
            let keys = Object.keys(sdpData);
            logger.info("keys = " + keys);
            for (let j = 0; j < keys.length; j++)
            {
                let targetKey = keys[j];
                let targetObj = sdpData[targetKey];
                let mappedKey = "network-group-encryption.sdp." + targetKey;
                //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj) + "\nmappedKey = " + mappedKey);
                getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, sdpData, deviceSdpConfig);
            }
            sdpArray.push(JSON.parse(JSON.stringify(sdpData)));
        }
        return sdpArray;
    }

    function traverseAndUpdateKeyGroupConfig(objKey, obj, deviceConfig) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            let mappings = modelDeviceMapping.getKeyGroupMapping();
            if (value != null && typeof value === 'object')
            {
                continue;
            }
            else
            {
                getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, deviceConfig);
            }

        }
        return obj;
    }

    function getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, targetObj, deviceConfigData) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = deviceConfigData[nfmpKey];
        if (mappedKey === "key-group.re-key")
        {
            let forceRekey = deviceConfigData["forceRekey"];
            let progressiveRekey = deviceConfigData["progressiveRekey"];
            if (forceRekey == "true" && progressiveRekey == "false")
            {
                deviceValue = "Force Rekey";
            }
            else if (forceRekey == "false" && progressiveRekey == "true")
            {
                deviceValue = "Progressive Rekey";
            }
            else
            {
                deviceValue = undefined;
            }
        }
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[targetKey] = (deviceValue) ? transformDeviceValue(mappedKey, deviceValue) : deviceValue;
    }

    function transformDeviceValue(mappedKey, deviceValue) {
        if (deviceValue !== null)
        {
            switch (mappedKey)
            {
                case "network-group-encryption.sdp.encrypt":
                    deviceValue = convertEncryptBrownfield(deviceValue);
                    break;
            }
            return deviceValue;
        }
    }

    function convertEncryptBrownfield(deviceValue) {
        if (deviceValue === "encrypt")
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    function clearEmpties(o) {
        for (let k in o)
        {
            if (!o[k] || typeof o[k] !== "object")
            {
                continue
            }

            clearEmpties(o[k]);
            if (Object.keys(o[k]).length === 0)
            {
                delete o[k];
            }
        }
    }
}