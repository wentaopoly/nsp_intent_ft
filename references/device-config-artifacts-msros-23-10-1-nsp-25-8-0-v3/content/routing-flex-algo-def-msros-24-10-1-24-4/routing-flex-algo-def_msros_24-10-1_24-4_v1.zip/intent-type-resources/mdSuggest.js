function MdSuggest() {
    this.getFlexAlgoName = function(neId, grpName) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/routing-options/flexible-algorithm-definitions/flex-algo?fields=flex-algo-name`;
    return this.getSuggestData(neId, url, "nokia-conf:flex-algo", "flex-algo-name");
   }

    this.getAdminGroupName = function(neId, grpName) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/routing-options/if-attribute/admin-group?fields=group-name`;
    return this.getSuggestData(neId, url, "nokia-conf:admin-group", "group-name");
   }

   this.getSuggestData = function(neId, url, initialProperty, propertyName) {
      const mdcFwk = new MdcFwk();
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg[initialProperty];
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data[propertyName]).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }
}