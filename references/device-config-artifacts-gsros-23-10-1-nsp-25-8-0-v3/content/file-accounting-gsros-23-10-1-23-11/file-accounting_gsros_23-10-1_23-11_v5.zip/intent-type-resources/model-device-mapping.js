function ModelDeviceMapping() {

    this.getMapping = function(type){
        switch(type){
            case "file":
                return this.getFilePolicyMapping();
            case "accounting":
                return this.getAccountingPolicyMapping();
            case "compactflashLocation":
                return this.getCompactFlashLocationMapping();
            case "customRecord":
                return this.getCustomRecordMapping();
            default:
                return this.getAccountingPolicyMapping();
        }
    }

    this.getFilePolicyMapping = function(){
        var mapping = {};

        mapping['log.file.file-id'] = 'id';
        mapping['log.file.file-policy-name'] = 'displayedName';
        mapping['log.file.description'] = 'description';
        mapping['log.file.rollover'] = 'collectionInterval';
        mapping['log.file.retention'] = 'retentionInterval';
        mapping['log.file.compact-flash-location.primary'] = 'drive';
        mapping['log.file.compact-flash-location.backup'] = 'backupPath';

        return mapping;
    }

    this.getCompactFlashLocationMapping = function(){
        var mapping = {};

        mapping['log.file.compact-flash-location.primary'] = 'drive';
        mapping['log.file.compact-flash-location.backup'] = 'backupPath';

        return mapping;
    }

    this.getAccountingPolicyMapping = function() {
        var mapping = {};

        mapping['log.accounting-policy.admin-state'] = 'administrativeState';
        mapping['log.accounting-policy.accounting-policy-name'] = 'displayedName';
        mapping['log.accounting-policy.description'] = 'description';
        mapping['log.accounting-policy.default'] = 'isDefault';
        mapping['log.accounting-policy.include-system-info'] = 'includeSystemInfo';
        mapping['log.accounting-policy.record'] = 'recordType';
        mapping['log.accounting-policy.align'] = 'align';
        mapping['log.accounting-policy.collection-interval'] = 'collectionInterval';

        return mapping;
    }

    this.getCustomRecordMapping = function() {
        var mapping = {};

        mapping['log.accounting-policy.custom-record.significant-change'] = 'delta';

        return mapping;
    }

    this.getQueueMapping = function() {
        var mapping = {};

        mapping['log.accounting-policy.custom-record.queue.id'] = '';
        mapping['log.accounting-policy.custom-record.queue.i-counters'] = '';
        mapping['log.accounting-policy.custom-record.queue.e-counters'] = '';

        return mapping;
    }
}
