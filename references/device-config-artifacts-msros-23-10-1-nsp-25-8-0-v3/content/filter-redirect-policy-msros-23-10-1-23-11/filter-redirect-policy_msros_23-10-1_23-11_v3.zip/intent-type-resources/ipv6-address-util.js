function IPv6AddressUtil()
{
   
     this.preAuditIpv6ModifyDestination = function(intentConfig) {
        var configEntries = intentConfig["destination"];
        if (!Array.isArray(configEntries)) {
            configEntries = [configEntries];
        }
        configEntries.forEach(function (config, i) {
            if (config && config["destination-address"]) {
                if(!(/^[^:]*(:[^:]*){3}$/.test(config["destination-address"]) && /^::ffff:.*/.test(config["destination-address"]))) {
                    if(!(/^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.|$)){4}$/.test(config["destination-address"]))) {
                        config["destination-address"] = expandIPv6Address(config["destination-address"]);
                    }
                    config["destination-address"] = MdIpv6ValidAddresssMaskSupport(config["destination-address"]);
                }
            }
            if (config && config["ping-test"] && config["ping-test"]["source-address"]) {
                if(!(/^[^:]*(:[^:]*){3}$/.test(config["ping-test"]["source-address"]) && /^::ffff:.*/.test(config["ping-test"]["source-address"]))) {
                    if(!(/^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.|$)){4}$/.test(config["ping-test"]["source-address"]))) {
                        config["ping-test"]["source-address"] = expandIPv6Address(config["ping-test"]["source-address"]);
                    }
                    config["ping-test"]["source-address"] = MdIpv6ValidAddresssMaskSupport(config["ping-test"]["source-address"]);
                }
            }
        });
        intentConfig['destination'] = configEntries;
        return intentConfig;
     }


    MdIpv6ValidAddresssMaskSupport = function(input) {
        if (input === undefined) {
            return undefined;
        }
        if (input.endsWith(':') || input.endsWith('::0')) {
            input += ":";
        }
        let hex = removeLeadingTrailingZeros(input)
        if(hex.indexOf('::')!==-1){
            hex=hex.replace(/(::)0+/g, '$1').replace(/:::/g, "::")
            return hex;
        }
        const hextets = hex.split(':').filter(part => part !== ''); // Remove empty parts
        let maxZeroLength = 0;
        let longestZeroIndex = -1;
        let currentZeroLength = 0;
        for (let i = 0; i < hextets.length; i++) {
            if (hextets[i] === '0') {
                currentZeroLength++;
                if (currentZeroLength > maxZeroLength) {
                    maxZeroLength = currentZeroLength;
                    longestZeroIndex = i - maxZeroLength + 1;
                }
            } else {
                currentZeroLength = 0;
            }
        }
        if (maxZeroLength > 1) {
            hextets.splice(longestZeroIndex, maxZeroLength, '::');
        }
        if (maxZeroLength === 1) {
            const zeroIndex = hextets.indexOf('0');
            const zeroCount = hextets.filter(part => part === '0').length;
            if (zeroIndex !== -1 && zeroCount === 1 && hextets.length !== 8) {
                hextets.splice(zeroIndex, 1, '::');
            }
        }

        let result = hextets.join(':').replace(/::+/g, '::');
        return result;
    }

    function removeLeadingTrailingZeros(input) {
        const parts = input.split(':');
        for (let i = 0; i < parts.length; i++) {
            if(parts[i] == ''){
                continue
            }else{
                parts[i] = removeLeadingZeros(parts[i]);
            }

        }
        return parts.join(':');
    }

    function removeLeadingZeros(part) {
        let result = '';
        let nonZeroEncountered = false;
        for (let i = 0; i < part.length; i++) {
            if (part[i] !== '0') {
                nonZeroEncountered = true;
            }
            if (nonZeroEncountered) {
                result += part[i];
            }
        }
        return result || '0';
    }

    function ipv6ToMappedIpv4(ipv6)
    {
        // Extract the hex part after "::ffff:"
        let hexPart = ipv6.replace("::ffff:", "");
        hexPart = hexPart.replace("::FFFF:", "");

        // Split the remaining part into two 16-bit sections
        const parts = hexPart.split(":");
        if (parts.length !== 2) {
            return ipv6;
        }

        // Convert each 16-bit hex value into two 8-bit decimal values
        const firstTwoOctets = parseInt(parts[0], 16); // Convert first 16 bits
        const lastTwoOctets = parseInt(parts[1], 16);  // Convert last 16 bits

        // Extract individual octets
        const octet1 = (firstTwoOctets >> 8) & 0xFF;
        const octet2 = firstTwoOctets & 0xFF;
        const octet3 = (lastTwoOctets >> 8) & 0xFF;
        const octet4 = lastTwoOctets & 0xFF;

        // Construct the final "::ffff:<IPv4>" format
        return "::ffff:" + octet1 + "." + octet2 + "." + octet3 + "." + octet4;
    }

    function expandIPv6Address(address)
        {
            var fullAddress = "";
            var validGroupCount = 8;

            var ipv4 = "";
            address = MdIpv6ValidAddresssMaskSupport(address);
            var extractIpv4 = /([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})/;
            var validateIpv4 = /((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})/;
            // look for embedded ipv4
            if(validateIpv4.test(address))
            {
                var groups = address.match(extractIpv4);
                for(var i=1; i<groups.length; i++)
                {
                    ipv4 += ("0" + (parseInt(groups[i], 10).toString(16)) ).slice(-2) + ( i==2 ? ":" : "" );
                }
                if(!address.startsWith("::ffff") && !address.startsWith("::FFFF"))
                {
                    address = address.replace(extractIpv4, ipv4);
                }
            }
            else
            {
                if(address.startsWith("::ffff") || address.startsWith("::FFFF"))
                {
                    address = ipv6ToMappedIpv4(address)
                }
            }

            if(address.indexOf("::") == -1) // All eight groups are present.
                fullAddress = address;
            else // Consecutive groups of zeroes have been collapsed with "::".
            {
                var sides = address.split("::");
                var groupsPresent = 0;
                for(var i=0; i<sides.length; i++)
                {
                    groupsPresent += sides[i].split(":").length;
                }
                fullAddress += (sides[0]? sides[0]:0) + ":";
                for(var i=0; i<validGroupCount-groupsPresent; i++)
                {
                    fullAddress += "0:";
                }
                if(sides[1])
                {
                    fullAddress += (sides[1].split("/")[0]?sides[1].split("/")[0]:"0")
                        + (sides[1].split("/")[1]?"/"+sides[1].split("/")[1]:"");
                }
                else
                {
                    fullAddress += "0";
                }

            }
            fullAddress = removeLeadingZeros(fullAddress);
            return fullAddress.toLowerCase();
        }
      this.MdIpv6ValidAddresssMaskSupport = MdIpv6ValidAddresssMaskSupport;
      this.expandIPv6Address = expandIPv6Address;
      this.ipv6ToMappedIpv4 = ipv6ToMappedIpv4;
}
