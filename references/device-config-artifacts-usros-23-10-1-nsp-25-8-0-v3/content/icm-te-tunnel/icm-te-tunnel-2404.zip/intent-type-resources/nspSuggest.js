load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'MediatorFramework'});



function NspSuggest(){
    this.mediatorFwk = new MediatorFramework("NSP");
}

NspSuggest.prototype.RESTCONF_HOST = "restconf-gateway";
NspSuggest.prototype.RESTCONF_PORT = "443";
NspSuggest.prototype.mediatorFwk = null;
NspSuggest.prototype.NSP_RESTCONF_INVENTORY_FIND_URL = "/restconf/operations/nsp-inventory:find";

NspSuggest.prototype.constructURL = function (path, method) {
    var url = "https://" + this.RESTCONF_HOST + ":" + this.RESTCONF_PORT + path;
    logger.info("[RestconfFwk] {}Calling restconf via NSP Mediator: {}", method, url);
    return url;
};

NspSuggest.prototype.findByXpath = function (xPath, depth, fields) {
    if (!depth)
    {
        depth = 3;
    }
    var url = this.constructURL(this.NSP_RESTCONF_INVENTORY_FIND_URL, "POST");
    var input = {};
    var ret = null;
    input["xpath-filter"] = xPath;
    input["depth"] = depth;
    if (fields !== undefined)
        input["fields"] = fields;
    var requestBody = {};
    requestBody["input"] = input;

    var response = this.mediatorFwk.post(url, requestBody);
    logger.info("[RestconfFwk][findByXpath] response = {}", JSON.stringify(response));

    if (response.httpStatus === 200 && response)
    {
        var lRes = response["response"];
        if (lRes && lRes["nsp-inventory:output"])
        {
            var data = response["response"]["nsp-inventory:output"]["data"];
            if (data.length !== 0)
                ret = data;
        }
    }
    return ret;
};

NspSuggest.prototype.getSites = function(neId) {
    var xPath = "/nsp-equipment:network/network-element";
    var result = [];
    var data = this.findByXpath(xPath, 3, 'ne-id');
    if (data)
    {
        var ret = data.map(function (ne) {
            if(ne["ne-id"] != neId)
                result.push(ne["ne-id"]);
        });
    }
    this.sortResult(result)
    return result;
};

NspSuggest.prototype.sortResult = function (result) {
    for (let i = 0; i < result.length - 1; i++) {
        for (let j = 0; j < result.length - i - 1; j++) {
            if (result[j] > result[j + 1]) {
                let temp = result[j];
                result[j] = result[j + 1];
                result[j + 1] = temp;
            }
        }
    }
};