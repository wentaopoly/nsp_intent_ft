var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpIpFilter() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    let nfmpFwk = new NfmpFwk();
    var parseTarget =  new ParseTarget();

    //var mapFwk = new MapFwk();
    var parseTarget =  new ParseTarget();
    var savedObjects;
    var currentObjects;
    var isAudit = false;
    var isLocalExists = false;
    var isGlobalExists = false;

    this.synchronize = function(input, result,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier)
    {
        // code to handle delete
        if (input.getNetworkState().name() === "delete")
        {
            return this.syncDelete(input,result);
        }

        var savedTopology = input.getCurrentTopology();
        logger.info(savedTopology);
        savedObjects = {};
        currentObjects = {};
        isAudit = false;
        //loading the saved objects from topology
        this.loadSavedObjectsFromTopology(savedTopology);

        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        var filterId = util.getIpFilterId(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        //intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        if(!intentConfig)
        {
            intentConfig = Object.create({});
        }
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());
        intentConfig["filter-id"] = parseInt(filterId);

        logger.info("Configuration to be pushed = "+JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target IP-Filter = " + intentConfig[uniqueIdentifier]);

        this.createOrModify(target,intentConfig);
        var currentTopo = this.loadCurrentObjectsToTopology(target);

        result = util.setSuccessResult(result,currentTopo);
        return result;
    }

    this.audit = function (target, config, svcTopo, adminState, auditReport,intentTypeName,xpath,initialPropertyName,uniqueIdentifier) {

        var savedTopology = svcTopo;
        savedObjects = {};
        currentObjects = {};
        isAudit = true;
        var filterId = util.getIpFilterId(target);
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        //intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        if(!intentConfig)
        {
            intentConfig = Object.create({});
        }
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        intentConfig["filter-id"] = parseInt(filterId);
        var neId = parseTarget.getNeIdFromTarget(target);
        logger.info("auditing configuration = "+JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target ip-filter = " + intentConfig[uniqueIdentifier]);

        if(intentConfig){
            this.auditAndCompare(neId,intentConfig,auditReport);
        }else{
            throw "configuration not available in the intent";
        }

        return auditReport
    }

    this.auditAndCompare = function(target,intentConfig,auditReport){

        var ipFilterPayload = this.createFilterLevelPayLoad(target,intentConfig, true);
        var result = this.auditRequest(target, ipFilterPayload);
        auditReport = util.reportMisaligned(target, result,auditReport);
        return auditReport;
    }

    this.createOrModify= function(target,intentConfig)
    {
        var fullClassName = "aclfilter.IpFilter";
        var filterFdn = "IP Filter";
        var objectFullName = filterFdn+":" + intentConfig["filter-id"];
        var localFilterFullName = "network:"+target+":"+objectFullName;
        if (target && String(target).indexOf(':') !== -1) {
            localFilterFullName = util.modifyNeIdForIpV6(localFilterFullName, target);
        }
        var localFilter = util.getIfObjectExists(fullClassName, localFilterFullName);
        var result;
        var ipFilterPayload;
        var distributeResult

        if(localFilter != null)
        {
            isLocalExists = true;
            isGlobalExists = true;
            if(localFilter[0]["properties"]["filterName"] !== intentConfig[uniqueIdentifier])
            {
                throw new RuntimeException("Already there exists a filter on "+target+" with filter name "+localFilter[0]["properties"]["filterName"]+ " with filter ID "+intentConfig["filter-id"]);
            }
            ipFilterPayload = this.createFilterLevelPayLoad(target,intentConfig,isLocalExists);

            result = this.modifyRequest(target, ipFilterPayload);
        }
        else
        {
            var globalFilter = util.getIfObjectExists("aclfilter.IpFilter", objectFullName);
            if(globalFilter != null)
            {
                isGlobalExists = true;
                if(globalFilter[0]["properties"]["filterName"] !== intentConfig[uniqueIdentifier])
                {
                    logger.info("[NFMP-IPFILTER-FWK] createOrModify(): There exists a ip-filter global filter in NFMP with filter name "+globalFilter[0]["properties"]["filterName"]+
                        " with same filter ID "+intentConfig["filter-id"]+" on "+target);
                    logger.info("[NFMP-IPFILTER-FWK] createOrModify(): Updating ip-filter global filter name to "+intentConfig[uniqueIdentifier] + "on "+target + " for filter "+ intentConfig["filter-id"]);
                    this.updateIpFilterName(target, objectFullName, intentConfig[uniqueIdentifier]);
                }

                distributeResult = this.distributeFilterPolicy(target, intentConfig, false);

                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Filter: ' + distributeResult.msg)
                }

                // Changing SyncWithGlobal To Local Edit Only
                distributeResult = this.distributeFilterPolicy(target, intentConfig, true);

                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Filter: ' + distributeResult.msg)
                }

                ipFilterPayload = this.createFilterLevelPayLoad(target,intentConfig,true);

                result = this.modifyRequest(target, ipFilterPayload);
            }
            else
            {
                //distributing empty filter
                ipFilterPayload = this.createFilterLevelPayLoad(target,intentConfig, false);
                result = this.modifyRequest(target, ipFilterPayload);

                distributeResult = this.distributeFilterPolicy(target, intentConfig, false);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Filter Policy: ' + distributeResult.msg)
                }
                // Changing SyncWithGlobal To Local Edit Only
                distributeResult = this.distributeFilterPolicy(target, intentConfig, true);

                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Filter Policy: ' + distributeResult.msg)
                }

                //updating the local filter with intent configuration
                ipFilterPayload = this.createFilterLevelPayLoad(target,intentConfig,true);
                result = this.modifyRequest(target, ipFilterPayload);
            }
        }
        return result;
    }

    this.updateIpFilterName = function (target, objectFullName, filterName)
    {
        var fullClassName = "aclfilter.IpFilter";
        var filterFdn = "IP Filter";
        var properties = {};

        properties["filterName"] = filterName;

        var payload  = {};
        var configInfo = {};
        configInfo["containedClassProperties"] = properties;
        configInfo["objectClassName"] = fullClassName;
        payload["distinguishedName"] = filterFdn;
        payload["objectFullName"] = objectFullName;
        payload["configInfo"] = configInfo;
        var result = this.modifyRequest(target, payload);
        return result;
    }

    this.createFilterLevelPayLoad = function(target,intentConfig, isLocalExists) {

        var fullClassName = "aclfilter.IpFilter";
        var filterFdn = "IP Filter";
        var objectFullName = "IP Filter:" + intentConfig["filter-id"];
        var localPolicyFullName = "network:"+target+":IP Filter:" + intentConfig["filter-id"];
        if (target && String(target).indexOf(':') !== -1) {
            localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, target);
        }
        if(isLocalExists)
        {
            objectFullName = localPolicyFullName;
        }
        var properties = {};

        properties["id"] = intentConfig["filter-id"];
        properties["filterName"] = intentConfig["filter-name"];
        properties["description"] = intentConfig["description"];
        properties["defaultAction"] = util.transformNfmpDefaultAction(intentConfig["default-action"]);

        var childProperties = [];
        if(isLocalExists)
        {
            if (intentConfig["entry"]){
                if(!Array.isArray(intentConfig["entry"])){
                    intentConfig["entry"] = [intentConfig["entry"]];
                }
                for(var index in intentConfig["entry"]){
                    var intentIPFilterEntryConfig = intentConfig["entry"][index];
                    var entryObjectFullName = objectFullName+":"+"entry-"+intentIPFilterEntryConfig["entry-id"];
                    //keeping key and value same as object full name of the queue
                    mapFwk.set(currentObjects,entryObjectFullName,entryObjectFullName);
                    var entryPayload = this.createIpFilterEntryPayLoad(target,intentIPFilterEntryConfig);
                    childProperties.push(entryPayload);
                }
            }
        }
        var filterLevelPayload = util.editPayload(filterFdn,properties,childProperties,fullClassName,objectFullName);
        return filterLevelPayload;
    }

    this.createIpFilterEntryPayLoad = function(target,intentIPFilterEntryConfig){

        var fullClassName = "aclfilter.IpFilterEntry";
        var properties = {};

        properties["id"] = intentIPFilterEntryConfig["entry-id"];
        properties["description"] = intentIPFilterEntryConfig["description"];
        if(intentIPFilterEntryConfig["match"])
        {
            if(intentIPFilterEntryConfig["match"]["protocol"])
            {
                properties["protocol"] = util.transformNfmpProtocol(intentIPFilterEntryConfig["match"]["protocol"]);
                properties["protocolListPointer"] = '';
            }
            if(intentIPFilterEntryConfig["match"]["protocol-list"])
            {
                properties["protocol"] = "ALL";
                properties["protocolListPointer"] = 'filterProtocolList:' + intentIPFilterEntryConfig["match"]["protocol-list"];
            }

            if(intentIPFilterEntryConfig["match"]["ip"])
            {
                if(intentIPFilterEntryConfig["match"]["ip"]["match-address-choice"] === "address-and-prefix-or-mask")
                {
                    if(intentIPFilterEntryConfig["match"]["ip"]["address"])
                    {
                        properties["ipAddress"] = intentIPFilterEntryConfig["match"]["ip"]["address"];
                    }
                    if(intentIPFilterEntryConfig["match"]["ip"]["mask"])
                    {
                        properties["ipAddressMask"] = 'ipAddrMask' + intentIPFilterEntryConfig["match"]["ip"]["mask"];
                    }
                    properties["ipPrefixListPointer"] = '';
                }

                if(intentIPFilterEntryConfig["match"]["ip"]["match-address-choice"] === "ip-prefix-list")
                {
                    properties["ipAddress"] = '0.0.0.0';
                    properties["ipAddressMask"] = 'ipAddrMask0';
                    properties["ipAddressFullMask"] = '0.0.0.0';
                    properties["ipPrefixListPointer"] = 'filterPrefixList:' + intentIPFilterEntryConfig["match"]["ip"]["ip-prefix-list"];
                }
            }

            if(intentIPFilterEntryConfig["match"]["src-ip"])
            {
                if(intentIPFilterEntryConfig["match"]["src-ip"]["address"] || intentIPFilterEntryConfig["match"]["src-ip"]["mask"])
                {
                    if(intentIPFilterEntryConfig["match"]["src-ip"]["address"])
                    {
                        properties["sourceIpAddress"] = intentIPFilterEntryConfig["match"]["src-ip"]["address"];
                    }
                    if(intentIPFilterEntryConfig["match"]["src-ip"]["mask"])
                    {
                        properties["sourceIpAddressMask"] = 'ipAddrMask' + intentIPFilterEntryConfig["match"]["src-ip"]["mask"];
                    }
                    properties["srcIpPrefixListPointer"] = '';
                }
                if(intentIPFilterEntryConfig["match"]["src-ip"]["ip-prefix-list"])
                {
                    properties["sourceIpAddress"] = '0.0.0.0';
                    properties["sourceIpAddressMask"] = 'ipAddrMask0';
                    properties["sourceIpAddressFullMask"] = '0.0.0.0';
                    properties["srcIpPrefixListPointer"] = 'filterPrefixList:' + intentIPFilterEntryConfig["match"]["src-ip"]["ip-prefix-list"];
                }
            }

            if(intentIPFilterEntryConfig["match"]["dst-ip"])
            {
                if(intentIPFilterEntryConfig["match"]["dst-ip"]["address"] || intentIPFilterEntryConfig["match"]["dst-ip"]["mask"])
                {
                    if(intentIPFilterEntryConfig["match"]["dst-ip"]["address"])
                    {
                        properties["destinationIpAddress"] = intentIPFilterEntryConfig["match"]["dst-ip"]["address"];
                    }
                    if(intentIPFilterEntryConfig["match"]["dst-ip"]["mask"])
                    {
                        properties["destinationIpAddressMask"] = 'ipAddrMask' + intentIPFilterEntryConfig["match"]["dst-ip"]["mask"];
                    }
                    properties["dstIpPrefixListPointer"] = '';
                }
                if(intentIPFilterEntryConfig["match"]["dst-ip"]["ip-prefix-list"])
                {
                    properties["destinationIpAddress"] = "0.0.0.0";
                    properties["destinationIpAddressMask"] = 'ipAddrMask0';
                    properties["destinationIpAddressFullMask"] = '0.0.0.0';
                    properties["dstIpPrefixListPointer"] = 'filterPrefixList:' + intentIPFilterEntryConfig["match"]["dst-ip"]["ip-prefix-list"];
                }
            }

            if(intentIPFilterEntryConfig["match"]["port"])
            {
                properties["portSelector"] = "OR_PORT";
                if(intentIPFilterEntryConfig["match"]["port"]["port"])
                {
                    if(intentIPFilterEntryConfig["match"]["port"]["port"] === "eq")
                    {
                        properties["portOperator"] = "EQUAL";
                        properties["port1"] =  intentIPFilterEntryConfig["match"]["port"]["eq"];
                        if(!isAudit)
                        {
                            properties["sourceOperator"] = "EQUAL";
                            properties["destinationOperator"] = "EQUAL";
                            properties["sourcePort1"] =  intentIPFilterEntryConfig["match"]["port"]["eq"];
                            properties["destinationPort1"] =  intentIPFilterEntryConfig["match"]["port"]["eq"];
                        }
                    }
                    else if(intentIPFilterEntryConfig["match"]["port"]["port"] === "lt")
                    {
                        properties["portOperator"] = "LESS_THAN";
                        properties["port1"] =  intentIPFilterEntryConfig["match"]["port"]["lt"];
                        if(!isAudit)
                        {
                            properties["sourceOperator"] = "LESS_THAN";
                            properties["destinationOperator"] = "LESS_THAN";
                            properties["sourcePort1"] = intentIPFilterEntryConfig["match"]["port"]["lt"];
                            properties["destinationPort1"] = intentIPFilterEntryConfig["match"]["port"]["lt"];
                        }
                    }
                    else if(intentIPFilterEntryConfig["match"]["port"]["port"] === "gt")
                    {
                        properties["portOperator"] = "GREATER_THAN";
                        properties["port1"] =  intentIPFilterEntryConfig["match"]["port"]["gt"];
                        if(!isAudit)
                        {
                            properties["sourceOperator"] = "GREATER_THAN";
                            properties["destinationOperator"] = "GREATER_THAN";
                            properties["sourcePort1"] = intentIPFilterEntryConfig["match"]["port"]["gt"];
                            properties["destinationPort1"] = intentIPFilterEntryConfig["match"]["port"]["gt"];
                        }
                    }
                    else if(intentIPFilterEntryConfig["match"]["port"]["port"] === "range")
                    {
                        properties["portOperator"] = "RANGE";
                        if(!isAudit)
                        {
                            properties["sourceOperator"] = "RANGE";
                            properties["destinationOperator"] = "RANGE";
                        }
                        if(intentIPFilterEntryConfig["match"]["port"]["range"])
                        {
                            properties["port1"] =  intentIPFilterEntryConfig["match"]["port"]["range"]["start"];
                            properties["port2"] =  intentIPFilterEntryConfig["match"]["port"]["range"]["end"];
                            if(!isAudit)
                            {
                                properties["sourcePort1"] = intentIPFilterEntryConfig["match"]["port"]["range"]["start"];
                                properties["destinationPort1"] = intentIPFilterEntryConfig["match"]["port"]["range"]["start"];
                                properties["sourcePort2"] = intentIPFilterEntryConfig["match"]["port"]["range"]["end"];
                                properties["destinationPort2"] = intentIPFilterEntryConfig["match"]["port"]["range"]["end"];
                            }
                        }
                    }
                    else if(intentIPFilterEntryConfig["match"]["port"]["port"] === "port-list")
                    {
                        properties["portListPointer"] = 'filterPortList:' + intentIPFilterEntryConfig["match"]["port"]["port-list"];
                        if(!isAudit)
                        {
                            properties["sourcePortListPointer"] = 'filterPortList:' + intentIPFilterEntryConfig["match"]["port"]["port-list"];
                            properties["destinationPortListPointer"] = 'filterPortList:' + intentIPFilterEntryConfig["match"]["port"]["port-list"];
                        }
                    }
                }
            }

            if(intentIPFilterEntryConfig["match"]["src-port"])
            {
                properties["portSelector"] = "AND_PORT";
                if(intentIPFilterEntryConfig["match"]["src-port"]["port"])
                {
                    if(intentIPFilterEntryConfig["match"]["src-port"]["port"] === "eq")
                    {
                        properties["sourceOperator"] = "EQUAL";
                        properties["sourcePort1"] =  intentIPFilterEntryConfig["match"]["src-port"]["eq"];
                    }
                    else if(intentIPFilterEntryConfig["match"]["src-port"]["port"] === "lt")
                    {
                        properties["sourceOperator"] = "LESS_THAN";
                        properties["sourcePort1"] =  intentIPFilterEntryConfig["match"]["src-port"]["lt"];
                    }
                    else if(intentIPFilterEntryConfig["match"]["src-port"]["port"] === "gt")
                    {
                        properties["sourceOperator"] = "GREATER_THAN";
                        properties["sourcePort1"] =  intentIPFilterEntryConfig["match"]["src-port"]["gt"];
                    }
                    else if(intentIPFilterEntryConfig["match"]["src-port"]["port"] === "range")
                    {
                        properties["sourceOperator"] = "RANGE";
                        if(intentIPFilterEntryConfig["match"]["src-port"]["range"])
                        {
                            properties["sourcePort1"] =  intentIPFilterEntryConfig["match"]["src-port"]["range"]["start"];
                            properties["sourcePort2"] =  intentIPFilterEntryConfig["match"]["src-port"]["range"]["end"];
                        }
                    }
                    else if(intentIPFilterEntryConfig["match"]["src-port"]["port"] === "port-list")
                    {
                        if(intentIPFilterEntryConfig["match"]["src-port"]["port-list"] != undefined)
                        {
                            properties["sourcePortListPointer"] = 'filterPortList:' + intentIPFilterEntryConfig["match"]["src-port"]["port-list"];
                        }
                        else{
                            properties["sourcePortListPointer"] = "";
                        }
                    }
                }
            }

            if(intentIPFilterEntryConfig["match"]["dst-port"])
            {
                properties["portSelector"] = "AND_PORT";
                if(intentIPFilterEntryConfig["match"]["dst-port"]["port"])
                {
                    if(intentIPFilterEntryConfig["match"]["dst-port"]["port"] === "eq")
                    {
                        properties["destinationOperator"] = "EQUAL";
                        properties["destinationPort1"] =  intentIPFilterEntryConfig["match"]["dst-port"]["eq"];
                    }
                    else if(intentIPFilterEntryConfig["match"]["dst-port"]["port"] === "lt")
                    {
                        properties["destinationOperator"] = "LESS_THAN";
                        properties["destinationPort1"] =  intentIPFilterEntryConfig["match"]["dst-port"]["lt"];
                    }
                    else if(intentIPFilterEntryConfig["match"]["dst-port"]["port"] === "gt")
                    {
                        properties["destinationOperator"] = "GREATER_THAN";
                        properties["destinationPort1"] =  intentIPFilterEntryConfig["match"]["dst-port"]["gt"];
                    }
                    else if(intentIPFilterEntryConfig["match"]["dst-port"]["port"] === "range")
                    {
                        properties["destinationOperator"] = "RANGE";
                        if(intentIPFilterEntryConfig["match"]["dst-port"]["range"])
                        {
                            properties["destinationPort1"] =  intentIPFilterEntryConfig["match"]["dst-port"]["range"]["start"];
                            properties["destinationPort2"] =  intentIPFilterEntryConfig["match"]["dst-port"]["range"]["end"];
                        }
                    }
                    else if(intentIPFilterEntryConfig["match"]["dst-port"]["port"] === "port-list")
                    {
                        if(intentIPFilterEntryConfig["match"]["dst-port"]["port-list"] != undefined)
                        {
                            properties["destinationPortListPointer"] = 'filterPortList:' + intentIPFilterEntryConfig["match"]["dst-port"]["port-list"];
                        }
                        else{
                            properties["destinationPortListPointer"] = "";
                        }
                    }
                }
            }
        }

        if(intentIPFilterEntryConfig["action"])
        {
            if(intentIPFilterEntryConfig["action"]["accept"] !== undefined)
            {
                properties["action"] = "forward";
            }
            if(intentIPFilterEntryConfig["action"]["drop"] !== undefined)
            {
                properties["action"] = "drop";
            }
        }

        return this.createChildObjectPayload(fullClassName,properties);
    }

    this.syncDelete = function (input,result) {

        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var filterId = util.getIpFilterId(input.getTarget());

        var searchPayLoad = this.constructSearchStringWithFilterID(neId, filterId);
        var searchResponse = nfmpFwk.find(neId, searchPayLoad);
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                logger.info("[NFMP-IPFILTER-FWK] syncDelete(): Unable to get Filter info from nfm-p for filter with Id:"+filterId+ " on "+ neId);
            if(JSON.parse(searchResponse["response"]).length === 0)
                logger.info("[NFMP-IPFILTER-FWK] syncDelete(): There is no ip-filter with Id:"+filterId+ " on "+ neId);
            result.setSuccess(false);
            return;
        }
        var objectFullName = "network:"+neId+":IP Filter:" + filterId;
        if (neId && String(neId).indexOf(':') !== -1) {
            objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        }
        logger.info("[NFMP-IPFILTER-FWK] syncDelete(): Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success) {
            logger.info("[NFMP-IPFILTER-FWK] syncDelete(): Unable to Delete: " + deleteResult.msg);
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }

    this.modifyRequest = function(target,payload){

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            logger.error("Error while deploying the request {}", JSON.stringify(result.msg));
		    let objFullName = payload["objectFullName"];
		    if (target && String(target).indexOf(':') !== -1) {
		        objFullName = util.modifyNeIdForIpV6(objFullName, target);
		    }
		    if(!(objFullName.indexOf("network") !== -1))
		    {
                logger.info("Redeploying the request ...  ");
                result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
                if (!result.success)
                {
                    throw new RuntimeException(result.msg)
                }
		    }
		    else
		    {
                throw new RuntimeException(result.msg)
		    }
        }
        return result;

    }

    this.createChildObjectPayload = function(fullClassName,properties){

        var childObjectPayLoad = {};
        childObjectPayLoad['objectClassName'] = fullClassName;
        childObjectPayLoad['containedClassProperties'] = properties;
        return childObjectPayLoad;
    }

    this.xml2object = function(xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: '+ json)
        return JSON.parse(json);
    }

    this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }

    this.loadSavedObjectsFromTopology = function(savedTopology) {

        if(savedTopology){
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0){
                topoObjects.forEach(function(topoObject){
                    mapFwk.set(savedObjects,topoObject.getObjectType(),topoObject.getObjectRelativeObjectID());
                });
            }
        }

    }

    this.loadCurrentObjectsToTopology = function(target) {

        var currentTopo = topologyFactory.createServiceTopology();
        if(Object.keys(currentObjects).length){
            for(var key in currentObjects){
                objectId = mapFwk.get(currentObjects,key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key,objectId,"INFRASTRUCTURE",target,""));
            }
        }
        return currentTopo;

    }

    this.auditRequest = function(target,payload){
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;

    }

    this.distributeFilterPolicy = function(nodeIp, intentConfig, localEdit) {

        logger.info(" localEdit: " + localEdit);
        var objectFullName = "IP Filter:" + intentConfig["filter-id"];
        var xmlReq = utilityService.processTemplate(resourceProvider.getResource(localEdit ? "distribute_local_edit.ftl" : "distribute.xml"), {nodeIp: nodeIp, objectFullName: objectFullName});
        logger.info(xmlReq);
        return nfmpFwk.passThroughRequest('/', xmlReq);

    }


    this.constructSearchStringWithFilterID = function(neId, filterId) {
        var filterExpression = "siteId='" + neId + "' AND id='" + filterId + "'";
        var jsonPayLoad = {
            "fullClassName": "aclfilter.IpFilter",
            "filter": {
                "filterExpression": filterExpression
            }
        };
        return jsonPayLoad;
    }

}
