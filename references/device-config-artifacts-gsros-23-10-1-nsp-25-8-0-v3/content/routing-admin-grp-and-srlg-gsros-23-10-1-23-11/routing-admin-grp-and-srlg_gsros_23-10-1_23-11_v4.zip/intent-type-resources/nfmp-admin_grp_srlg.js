var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpAdminGrpAndSrlg() {

    var util = new utilities();
    var savedTopology;
    var mapFwk = new MapFwk();
    var parseTarget =  new ParseTarget();
    var isAudit = false;
    var isEdit = false;
    let nfmpFwk = new NfmpFwk();
    var auditResult = {};
    var nfmpFwkPostRequest = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true"

    this.synchronize = function(input, result,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {
        if (input.getNetworkState().name() == "delete")
        {
            logger.info("Intent delete called.Ignoring Delete. Please delete Admin-Group and SRLG manually");
            return;
        }
        // code to handle sync
        savedTopology = input.getCurrentTopology();
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        //set the policy name from target
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);

        this.createOrModify(neId, intentConfig);
        result.setTopology(savedTopology);
        result.getTopology().setXtraInfo(savedTopology.getXtraInfo());
        return util.setSuccessResult(result, savedTopology);
    }


    this.audit = function (target, config, svcTopo, adminState, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        isAudit = true;
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        var neId = parseTarget.getNeIdFromTarget(target);
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        if (intentConfig)
        {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }
        return auditReport
    }

    this.auditRequest = function (neId, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        logger.info("Result" + JSON.stringify(result));
        return result;
    }


    this.updateAuditResult = function (aInAuditResult) {
        var resultResp = JSON.parse(aInAuditResult.response);
        var misalignedAttributes = resultResp.misalignedAttributes;
        if (Object.keys(auditResult).length === 0)
        {
            auditResult = resultResp;
        }
        else
        {
            if (misalignedAttributes.length > 0)
            {
                auditResult.misalignedAttributes = auditResult.misalignedAttributes.concat(misalignedAttributes);
                auditResult.aligned = false;
            }
        }
    }


    this.auditAndCompare = function (neId, intentConfig, auditReport) {
        this.createPolicyLevelPayLoad(neId, intentConfig);
        logger.info("Final audit result =\n" + JSON.stringify(auditResult));
        logger.info("Final audit report =\n" + JSON.stringify(auditReport));

        auditReport = util.reportMisaligned(neId, auditResult, auditReport);
        return auditReport;
    }

    this.createOrModify = function (neId, intentConfig) {
        this.createPolicyLevelPayLoad(neId, intentConfig);
    }

    this.createPolicyLevelPayLoad = function (neId, intentConfig) {
        if (savedTopology == null)
        {
            logger.info("Creating topology to store admin-group and srlg-group");
            savedTopology = topologyFactory.createServiceTopology();
        }
        this.deleteObject(neId, intentConfig);
        this.createAdminGrp(neId, intentConfig);
        this.createSrlgGrp(neId, intentConfig);
    }

    this.createAdminGrp = function(neId, intentConfig) {
        if(intentConfig['admin-group']) {
            if (!Array.isArray(intentConfig["admin-group"])) {
                intentConfig["admin-group"] = [intentConfig["admin-group"]];
            }
            for(var index in intentConfig['admin-group']) {
                isEdit = false;
                var adminGrpConfig = intentConfig['admin-group'][index];
                var fullClassName = "rtr.AdminGroupPolicy";
                var policyFdn = "rtrAdminGroup";
                var objectFullName = "rtrAdminGroup:" + adminGrpConfig['group-name'];

                var localPolicyFullName = "network:" + neId + ":" + objectFullName;
                localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
                if(util.isObjectExists(fullClassName, localPolicyFullName) || isAudit ) {
                    objectFullName = localPolicyFullName;
                    if(!isAudit) {
                        isEdit = true;
                    }
                }
                var entry = topologyFactory.createTopologyXtraInfoFrom(localPolicyFullName, fullClassName);
                savedTopology.addXtraInfo(entry);
                var properties = {};

                properties["displayedName"] = adminGrpConfig['group-name'];
                properties['value'] = adminGrpConfig['value'];

                var childProperties = {};
                var policyLevelPayload = util.editPayload(policyFdn, properties, childProperties, fullClassName, objectFullName);
                if (!isAudit)
                {
                    this.sendRequestAndDistribute(neId, policyLevelPayload, objectFullName, intentConfig);
                }
                else
                {
                    this.updateAuditResult(this.auditRequest(neId, policyLevelPayload));
                }
            }
        }
    }

    this.createSrlgGrp = function(neId, intentConfig) {
        if(intentConfig['srlg-group']) {
            if (!Array.isArray(intentConfig["srlg-group"])) {
                intentConfig["srlg-group"] = [intentConfig["srlg-group"]];
            }
            for(var index in intentConfig['srlg-group']) {
                isEdit = false;
                var srlgGrpConfig = intentConfig['srlg-group'][index];
                var fullClassName = "rtr.SharedRiskLinkGroup";
                var policyFdn = "rtrSrlgGroup";
                var objectFullName = "rtrSrlgGroup:srlg-" + srlgGrpConfig["name"];
                var localPolicyFullName = "network:" + neId + ":" + objectFullName;
                localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
                if(util.isObjectExists(fullClassName, localPolicyFullName) || isAudit ) {
                    objectFullName = localPolicyFullName;
                    if(!isAudit) {
                        isEdit = true;
                    }
                }
                var entry = topologyFactory.createTopologyXtraInfoFrom(localPolicyFullName, fullClassName);
                savedTopology.addXtraInfo(entry);
                var properties = {};

                properties["displayedName"] = srlgGrpConfig['name'];
                properties['value'] = srlgGrpConfig['value'];
                properties['penaltyWeight'] = srlgGrpConfig['penalty-weight'];

                var childProperties = {};
                var policyLevelPayload = util.editPayload(policyFdn, properties, childProperties, fullClassName, objectFullName);
                if (!isAudit)
                {
                    this.sendRequestAndDistribute(neId, policyLevelPayload, objectFullName, intentConfig);
                }
                else
                {
                    this.updateAuditResult(this.auditRequest(neId, policyLevelPayload));
                }
            }
        }
    }

    this.sendRequestAndDistribute = function (neId, payload, objectFullName, intentConfig) {
        this.modifyRequest(neId, payload);
        if (!isEdit)
        {
            logger.info("Distributing the policy to local");
            var distributePayload = util.distribute(neId, intentConfig, false, objectFullName);
            var distributeResult = nfmpFwk.post(nfmpFwkPostRequest, distributePayload);
            if (!distributeResult.success)
            {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }
            util.delay(2000);

            distributePayload = util.distribute(neId, intentConfig, true);
            distributeResult = nfmpFwk.post(nfmpFwkPostRequest, distributePayload);
            if (!distributeResult.success)
            {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }
        }
    }
    this.modifyRequest = function (neId, payload) {

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
           logger.error("Error result = {}",JSON.stringify(result));
           let errorMsg = result.msg;
           if(errorMsg.indexOf("object already exists") !== -1)
           {
               logger.info("Global policy Object already exists, Re-checking the Policy existence ");
               //util.delay(2000);
               let configInfo = payload.configInfo;
               let fullClassName;
               for (let key in configInfo) {
                 if (configInfo.hasOwnProperty(key)) {
                   fullClassName = key;
                   break;
                 }
               }
               let objectFullName = payload.objectFullName;
               objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
               logger.info("fullClassName = {}",fullClassName);
               logger.info("objectFullName = {}",objectFullName);
               if (!util.isObjectExists(fullClassName, objectFullName))
               {
                   throw new RuntimeException("Global Policy Object Not Found!!!");
               }
           }
           else
           {
               throw new RuntimeException(result.msg);
           }
        }
        return result;
    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('input json: ' + json)
        return JSON.parse(json);
    }


    this.deleteObject = function (neId, intentConfig) {
        var objectFullNameList = [];
        if (intentConfig["admin-group"] && !Array.isArray(intentConfig["admin-group"]))
        {
            intentConfig["admin-group"] = [intentConfig["admin-group"]];
        }
        objectFullNameList = objectFullNameList.concat(this.getAdminGrpsObjectFullName(neId, intentConfig["admin-group"], "admin-group"));

        if (intentConfig["srlg-group"] && !Array.isArray(intentConfig["srlg-group"]))
        {
            intentConfig["srlg-group"] = [intentConfig["srlg-group"]];
        }
        objectFullNameList = objectFullNameList.concat(this.getAdminGrpsObjectFullName(neId, intentConfig["srlg-group"], "srlg-group"));

        logger.info("List of admin-groups objects in intent = \n" + objectFullNameList);
        logger.info("List of admin-groups objects already exists = \n" + savedTopology.getXtraInfo());

        var intentlength = objectFullNameList.length;
        var XtraInfolength = savedTopology.getXtraInfo().length;

        var childObjectsBeDeleted = [];

        for (var index in savedTopology.getXtraInfo())
        {
            var xtraInfo = savedTopology.getXtraInfo()[index].getKey();
            var deleteFlag = true;
            for (var index in objectFullNameList)
            {
                if (xtraInfo == objectFullNameList[index])
                {
                    deleteFlag = false;
                    break;
                }
            }
            if (deleteFlag)
            {
                childObjectsBeDeleted.push(xtraInfo);
            }
        }

        for (var index in childObjectsBeDeleted)
        {
            logger.info(childObjectsBeDeleted[index]);
            this.syncDeleteChild(neId, childObjectsBeDeleted[index]);
        }
        savedTopology.setXtraInfo([]);
    }

    this.syncDeleteChild = function (neId, objectFullName) {
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        logger.info("Deleting : " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
    }


    this.getAdminGrpsObjectFullName = function (neId, intentAdminGrpConfig, type) {
        var objectFullNameList = [];
        for (var index in intentAdminGrpConfig)
        {
            var adminGrpsConfig = intentAdminGrpConfig[index];
            if (adminGrpsConfig)
            {
                var objectFullName;
                if (type === "admin-group")
                {
                    objectFullName = "network:" + neId + ":rtrAdminGroup:" + adminGrpsConfig['group-name'];
                    objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
                }
                else if(type === "srlg-group") {
                    objectFullName = "network:" + neId + "rtrSrlgGroup:srlg-" + adminGrpsConfig["name"];
                    objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
                }
                objectFullNameList = objectFullNameList.concat(objectFullName);
            }
        }
        return objectFullNameList;
    }
}
