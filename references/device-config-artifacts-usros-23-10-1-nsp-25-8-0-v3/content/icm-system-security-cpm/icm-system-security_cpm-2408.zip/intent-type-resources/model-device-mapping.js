function ModelDeviceMapping()
{
  this.getMapping = function(type)
  {
    switch(type)
    {
      case "cpmfilter":
        return this.getCPMFilterMapping();
      case "cpmIPfilter":
        return this.getIPFilterMapping();
      case "cpmIPv6filter":
        return this.getIPv6FilterMapping();
      case "cpmQueue":
        return this.getCPMQueueMapping();
      default:
        return this.getCPMFilterMapping();
    }
  }
  this.getCPMFilterMapping = function ()
  {
    var mapping = {};
    mapping['cpm-filter.ip-filter.admin-state'] = 'adminstrativeStatus';
    mapping['cpm-filter.ipv6-filter.admin-state'] = 'ipv6AdminstrativeStatus';

    return mapping;
  }

  this.getIPFilterMapping = function ()
  {
    var mapping = {};
    mapping['cpm-filter.ip-filter.entry.entry-id'] = 'id';
    mapping['cpm-filter.ip-filter.entry.description'] = 'description';

    return mapping;
  }

  this.getIPv6FilterMapping = function ()
  {
    var mapping = {};
    mapping['cpm-filter.ipv6-filter.entry.entry-id'] = 'id';
    mapping['cpm-filter.ipv6-filter.entry.description'] = 'description';

    return mapping;
  }

  this.getCPMQueueMapping = function ()
  {
    var mapping = {};
    mapping['cpm-queue.queue.queue-id'] = 'id';
    mapping['cpm-queue.queue.cbs'] = 'committedBurstSize';
    mapping['cpm-queue.queue.mbs'] = 'maximumBurstSize';
    mapping['cpm-queue.queue.rate.pir'] = 'pir';
    mapping['cpm-queue.queue.rate.cir'] = 'cir';

    return mapping;
  }
}
