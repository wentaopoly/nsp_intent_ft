var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();
    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let cpuPolicyId = parseTarget.getUniqueIdentifier(target);
        logger.info("neID = {}, CPU-PolicyId = {}", neId, cpuPolicyId);
        let searchPayLoad = this.constructSearchString(neId, cpuPolicyId);
        let searchResponse = nfmpFwk.post("search", searchPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find CPU Policy  : " + cpuPolicyId + " on NE " + neId);
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse[0];
    }
    this.constructSearchString = function (neId, cpuPolicyId) {
        let fullName = "fullName = 'network:" + neId + ":NE DoS Protection:" + cpuPolicyId + "'"
        if (neId && String(neId).indexOf(':') !== -1) {
            fullName = util.modifyNeIdForIpV6(fullName, neId);
        }
        let jsonPayLoad = {
            "filter": {
                "filterExpression": fullName
            },
            "fullClassName": "sitesec.DoSProtection"
        };
        return jsonPayLoad;
    }
    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        logger.info("***********************************deviceConfigSTART******************************************");
        logger.info(JSON.stringify(deviceConfig));
        logger.info("**********************************************************************************************");
        logger.info(JSON.stringify(parsedDefaultTargetData));
        logger.info("***********************************deviceConfigEND******************************************");
        let cpuPolicyConfig = deviceConfig["properties"];
        let ethCfmConfig = [];
        let cpuChildrenConfig = deviceConfig['children'];
        if (cpuChildrenConfig)
        {
            cpuChildrenConfig.forEach(function (element) {
                if (element.fullClassName === 'sitesec.CfmRateLimiting')
                {
                    ethCfmConfig.push(element['properties']);
                }
            });
        }
        let cpuPolicydeviceConfig = {
            "cpuPolicyConfig": cpuPolicyConfig,
            "ethCfmConfig": ethCfmConfig
        };

        logger.info("***********************************dCpuPolicydeviceConfigSTART******************************************");
        logger.info(JSON.stringify(cpuPolicydeviceConfig));
        logger.info("***********************************dCpuPolicydeviceConfigEND******************************************");

        if (null !== cpuPolicyConfig)
        {
            this.extractCpuPolicyProperties(parsedDefaultTargetData, cpuPolicydeviceConfig.cpuPolicyConfig);
        }
        logger.info("Intent data after extractCpuPolicyProperties :\n" + JSON.stringify(parsedDefaultTargetData));
        let ethCfmData = parsedDefaultTargetData['policy']['eth-cfm']["entry"];
        if (ethCfmData !== null && Array.isArray(ethCfmData) && ethCfmData.length !== 0)
        {
            let ethCfmArray = this.extractEthCfmProperties(parsedDefaultTargetData['policy']['eth-cfm']["entry"], cpuPolicydeviceConfig.ethCfmConfig);
            parsedDefaultTargetData['policy']['eth-cfm']["entry"] = ethCfmArray;
        }
        logger.info("Intent data after EthCfmArray :\n" + JSON.stringify(parsedDefaultTargetData));
        this.clearEmpties(parsedDefaultTargetData);
        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData));
        return parsedDefaultTargetData;
    }
    this.extractCpuPolicyProperties = function (defaultTargetData, deviceConfig) {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj))
            if (targetObj !== null && typeof targetObj === 'object')
            {
                let mappings = modelDeviceMapping.getCpuPolicyMapping();
                this.traverseAndUpdateCpuPolicyConfig(targetKey, targetObj, mappings, deviceConfig);
            }
        }
        return defaultTargetData;
    }
    this.extractEthCfmProperties = function (defaultTargetData, deviceConfig) {
        let ethCfmArray = [];
        let ethCfmData = defaultTargetData[0];
        let mappings = modelDeviceMapping.getEthCfmMapping();
        for (let i = 0; i < deviceConfig.length; i++)
        {
            let deviceEthCfmConfig = deviceConfig[i];
            let keys = Object.keys(ethCfmData);
            logger.info("keys = " + keys);
            for (let j = 0; j < keys.length; j++)
            {
                let targetKey = keys[j];
                let targetObj = ethCfmData[targetKey];
                logger.info("targetKey ======== {}", targetKey);
                let mappedKey = "policy.eth-cfm.entry." + targetKey;
                logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj) + "\nmappedKey = " + mappedKey);
                if (targetObj !== null && typeof targetObj === 'object')
                {
                    if (mappedKey.startsWith("policy.eth-cfm.entry.level") || mappedKey.startsWith("policy.eth-cfm.entry.opcode"))
                    {
                        let output = this.extractLevelAndOpcodeConfig(mappedKey, mappings, deviceEthCfmConfig);
                        if (mappedKey.startsWith("policy.eth-cfm.entry.level"))
                        {
                            ethCfmData.level = output;
                        }
                        else
                        {
                            ethCfmData.opcode = output;
                        }
                    }
                    else
                    {
                        this.traverseAndUpdateEthCfmConfig(mappedKey, targetObj, mappings, deviceEthCfmConfig)
                    }
                }
                else
                {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, ethCfmData, deviceEthCfmConfig);
                }
            }
            ethCfmArray.push(JSON.parse(JSON.stringify(ethCfmData)));
        }
        return ethCfmArray;
    }
    this.traverseAndUpdateCpuPolicyConfig = function (objKey, obj, mappings, deviceConfig) {
        logger.info("traverseAndUpdateCpuPolicyConfig,objKey = {}, \nobj={}, \nmappings={}, \ndeviceConfig={}", objKey, JSON.stringify(obj), JSON.stringify(mappings), JSON.stringify(deviceConfig))
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            logger.info("key = {}", key);
            logger.info("value = {}", JSON.stringify(value));
            logger.info("**********mappedKey = " + mappedKey);
            if (!mappedKey.startsWith("policy.eth-cfm"))
            {
                if (value != null && typeof value === 'object')
                {
                    this.traverseAndUpdateCpuPolicyConfig(mappedKey, value, mappings, deviceConfig);
                }
                else
                {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, deviceConfig);
                }
            }
        }
        return obj;
    }
    this.traverseAndUpdateEthCfmConfig = function (objKey, obj, mappings, deviceConfig) {
        logger.info("traverseAndUpdateEthCfmConfig,objKey = {}, \nobj={}, \nmappings={}, \ndeviceConfig={}", objKey, JSON.stringify(obj), JSON.stringify(mappings), JSON.stringify(deviceConfig))
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            logger.info("key = {}", key);
            logger.info("value = {}", JSON.stringify(value));
            logger.info("**********mappedKey = " + mappedKey);
            if (value != null && typeof value === 'object')
            {
                this.traverseAndUpdateCpuPolicyConfig(mappedKey, value, mappings, deviceConfig);
            }
            else
            {
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, deviceConfig);
            }
        }
        return obj;
    }
    this.extractLevelAndOpcodeConfig = function (objKey, mappings, deviceConfig) {
        logger.info("extractLevelAndOpcodeConfig,\nobjKey = {}, \n\nmappings={}, \n\ndeviceConfig={}", objKey, JSON.stringify(mappings), JSON.stringify(deviceConfig))
        let nfmpKey = mappings[objKey];
        let levelOpcodeArray = [];
        let levelOPcodeList = deviceConfig[nfmpKey];
        levelOPcodeList = levelOPcodeList.map(function (item) {
            //convert string to number........adding '+' infront of a string will convert it to number.
            return +item.replace("opCode", "").trim();
        }).sort(function (a, b) {
            return a - b;
        });
        logger.info("levelOPcodeList ====== {}", JSON.stringify(levelOPcodeList));
        for (let i = 0; i < levelOPcodeList.length; i++)
        {
            let levelOpcodeObject = {};
            levelOpcodeObject.start = levelOPcodeList[i];
            levelOpcodeObject.end = levelOPcodeList[i];
            let j = i;
            for (j; j < levelOPcodeList.length; j++)
            {
                if (levelOpcodeObject.end + 1 === levelOPcodeList[j + 1])
                {
                    levelOpcodeObject.end = levelOpcodeObject.end + 1;
                }
                else
                {
                    break;
                }
            }
            i = j;
            levelOpcodeArray.push(levelOpcodeObject);
            if (j + 1 === levelOPcodeList.length)
            {
                break;
            }
        }
        logger.info("********levelOpcodeArray = " + JSON.stringify(levelOpcodeArray));
        return levelOpcodeArray;
    }
    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, deviceConfigData) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = deviceConfigData[nfmpKey];
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);
    }
    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue !== null)
        {
            switch (mappedKey)
            {
                case "policy.overall-rate":
                case "policy.per-source-rate":
                case "policy.out-profile-rate.pir":
                case "policy.eth-cfm.entry.pir":
                    deviceValue = util.convertRateBrownField(deviceValue);
                    break;
            }
            return deviceValue;
        }
    }
    this.clearEmpties = function (o) {
        for (let k in o)
        {
            if (!o[k] || typeof o[k] !== "object")
            {
                continue
            }

            this.clearEmpties(o[k]);
            if (Object.keys(o[k]).length === 0)
            {
                delete o[k];
            }
        }
    }
}
