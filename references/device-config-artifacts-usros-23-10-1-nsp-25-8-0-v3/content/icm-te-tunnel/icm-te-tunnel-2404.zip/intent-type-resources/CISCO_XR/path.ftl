<#ftl output_format="JSON">
<#setting number_format="computer">

    {   
    <#if extraParams.name != "hopless" && extraParams["explicit-route-objects-always"]["route-object-include-exclude"].length != 0 >
        "hops":{ 
            "hop":[
            <#list extraParams["explicit-route-objects-always"]["route-object-include-exclude"]?values as value>
            {
                "index-number":${value.index},
                "ip-address":"${value.numbered\-node\-hop.node\-id}",
                "hop-type":"next-${value.numbered\-node\-hop.hop\-type}",
                "if-index":0,
                "num-type":"numbered"
            }
            <#if value?has_next>,</#if>
            </#list>
         ]
        },</#if>
        "name":"${extraParams.name}"
    }
    