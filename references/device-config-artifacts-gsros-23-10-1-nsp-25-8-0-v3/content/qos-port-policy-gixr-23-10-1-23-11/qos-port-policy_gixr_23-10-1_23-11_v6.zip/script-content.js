var RuntimeException = Java.type("java.lang.RuntimeException");

var prefixToNsMap = {
  "ibn": "http://www.nokia.com/management-solutions/ibn",
  "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
  "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
  "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders",
};

load({script:resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
var mdtFwk =  new MdtFwk();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('mdSuggest.js'), name: 'MdSuggest'})

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})

var LOG_PREFIX = "[Port QOS Policy 7250]: "

var intentTypeName = 'qos-port-policy_gixr_23-10-1_23-11';

var initialPropertyName = 'port-qos-policy';

var deviceYangModuleName = 'nokia-conf';

// unique identifier
var uniqueIdentifier = 'displayedName';

var parentXpath = 'configure/qos';

function synchronize(input) {
  logger.info(LOG_PREFIX + "Intent Synchronisation started for Port QOS Policy IXRQOS 7250");
  return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function onAudit(target, config, svcTopo, adminState) {
  logger.info(LOG_PREFIX + "Intent Audit started for Port QOS Policy IXRQOS 7250");
  return NspIntentHelper.audit(target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function suggestPortPolicyName(context) {
  logger.info(LOG_PREFIX + "suggestPortPolicyName context = \n" + context);
  var neId = getNeId(context);
  return navigateInstance(neId).getPolicyName(neId);
}

function suggestQueueMgmtPolicy(context) {
  var neId = getNeId(context);
  var className = "ixrqos.QueueMgmtPolicy";
  logger.info(LOG_PREFIX + "********** suggestQueueMgmtPolicy ********* ");
  var managerName = mdtFwk.getManagerName(neId);
  switch (managerName) {
    case "NFM-P":
      return new NfmpSuggest().getSupportedAttributeDataList(neId, className);
    case "MDC":
      return new MdSuggest().getSupportedAttributeDataList(neId, "queue_mgmt_policy");
  }
}

function getNeId(context) {
  var neId;
  var target = context.getInputValues()["target"]["objectidentifier"];
  logger.info(LOG_PREFIX + "target : {}", target)
  if (target) {
    if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
      neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
    }
    else {
      neId = target;
    }
  }
  logger.info(LOG_PREFIX + "NeId identified " + " : {}", neId);
  return neId;
}

function navigateInstance(neId) {
  var managerName = mdtFwk.getManagerName(neId);
  logger.info(LOG_PREFIX + 'Device: ' + neId + ' is managed by: ' + managerName);
  switch (managerName) {
    case "NFM-P":
      logger.info(LOG_PREFIX + 'Device is managed by NFMP');
      return new NfmpSuggest();
    case "MDC":
      logger.info(LOG_PREFIX + 'Device is managed by MDC');
      return new MdSuggest();
    default:
      logger.info(LOG_PREFIX + 'Device is not managed')
      throw new RuntimeException(LOG_PREFIX + 'Device is not Managed')
  }
}

/**
 * 
 * The function is used in Brownfield disscovery by ICM FW
 * It discover the configuration from the target device
 * and manipulate as per Template's default-target-data
 * 
 * 
 * @see ICMFwk for more details
 * @param {*} input - the config data of a deployment
 * @returns result - the result of the operation
 */
function getTargetData(input) {
  logger.info(LOG_PREFIX + "getTargetData input for brownfield = \n" + input);
  var target = input.target;
  var config = null;
  logger.info(LOG_PREFIX + "target = " + target);
  var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
  logger.info(JSON.stringify(deviceConfig));
  var data = gtdFwk.gtdSend(deviceConfig);
  return data.msg.result;
}

