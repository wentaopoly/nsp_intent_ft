function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {

        if(!payload["configInfo"]["ixrqos.IngressClassification"]["description"]) {
          payload["configInfo"]["ixrqos.IngressClassification"]["description"] = "N/A";
        }
        if(!payload["configInfo"]["ixrqos.IngressClassification"]["lspExpFcPointer"]) {
          payload["configInfo"]["ixrqos.IngressClassification"]["lspExpFcPointer"] = "";
        }
        if(!payload["configInfo"]["ixrqos.IngressClassification"]["dot1pFcPointer"]) {
          payload["configInfo"]["ixrqos.IngressClassification"]["dot1pFcPointer"] = "Dot1pFCMap7250SROS:default";
        }
        if(!payload["configInfo"]["ixrqos.IngressClassification"]["dscpFcPointer"]) {
          payload["configInfo"]["ixrqos.IngressClassification"]["dscpFcPointer"] = "";
        }

        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {

        if(targetValue!= "" && xpath == "dot1pFcPointer") {
          targetValue = "Dot1pFCMap7250SROS:" + targetValue;
        }
        if(targetValue!= "" && xpath == "dscpFcPointer") {
          targetValue = "DSCPFCMap7250SROS:" + targetValue;
        }
        if(targetValue!= "" && xpath == "lspExpFcPointer") {
          targetValue = "LspExpFCMap7250SROS:" + targetValue;
        }

        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {

        if(xpath == "dot1pFcPointer" || xpath == "dscpFcPointer" || xpath == "lspExpFcPointer") {
          return targetValue.split(":")[1];
        }
        if(targetKey == "dscpFc" && targetValue == "unspecified") {
          return null;
        }

        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
}
