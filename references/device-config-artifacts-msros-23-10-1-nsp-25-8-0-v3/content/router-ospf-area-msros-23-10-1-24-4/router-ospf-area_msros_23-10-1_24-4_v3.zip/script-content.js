var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
  "ibn" : "http://www.nokia.com/management-solutions/ibn",
  "nc" : "urn:ietf:params:xml:ns:netconf:base:1.0",
  "device-manager" : "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
  "http://www.nokia.com/management-solutions/anv-device-holders" : "anv-device-holders"
};


load({script:resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource('mdSuggest.js'), name: 'MdSuggest'});

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
var mdtFwk = new MdtFwk();

load({
  script: resourceProvider.getResource("parse-target.js"),
  name: "ParseTarget",
});

var parsedTarget = new ParseTarget();

var intentTypeName = 'router-ospf-area_msros_23-10-1_24-4';

// example port, sap-ingress etc..
var initialPropertyName = 'area';


// unique identifier
var uniqueIdentifier = 'area-id';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/router=Base/ospf=${ospf-instance}';

function synchronize(input) {
  logger.info('Intent Synchronisation started')
  return NspIntentHelper.synchronize(input,intentTypeName,getRootXPath(input),initialPropertyName,uniqueIdentifier);
}

function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started')
  return NspIntentHelper.audit(target, config, svcTopo, adminState,intentTypeName,getRootXPath(target),initialPropertyName,uniqueIdentifier);
}

function getNeId(context) {
  var neId;
  var target = context.getInputValues()["target"]["objectidentifier"];
  logger.info("target : {}", target)
  if (!target) {
    target = context.getInputValues()["arguments"]["__root"]["target_objectidentifier"];
  }
  if (target) {
    if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
      neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
    } else {
      neId = target;
    }
  }
  logger.info("NeId identified " + " : {}", neId);
  return neId;
}

function suggestOspfArea(context) {
  logger.info("suggestOspfArea context = \n" + context);
  let ospfInstance;
  ospfInstance = context.getInputValues()["arguments"]["target_ospf-instance"];
  if(!ospfInstance){
    ospfInstance = context.getInputValues()["target"]["ospf-instance"];
  }
  return new MdSuggest().getOspfArea(getNeId(context), ospfInstance);
}

function suggestOspfInstance(context) {
  logger.info("suggestOspfInstance context = \n" + context);
  return new MdSuggest().getOspfInstance(getNeId(context));
}

function suggestBierTemplateName(context) {
  logger.info("suggest Bier Template Name context = \n" + context);
  return new MdSuggest().getBierTemplateName(getNeId(context));
}

function suggestPolicyStatement(context) {
  logger.info("suggestOspfInstance context = \n" + context);
  return new MdSuggest().getPolicyStatement(getNeId(context));
}

function getTargetData(input) {
    logger.info("-------------------- script-content.js -> getTargetData() --------------------");
    logger.info("getTargetData input for brownfield = \n" + input);
    let target = input.target;
    let config = null;
    logger.info("target=" + target);
    let deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info("deviceConfig = {} ", JSON.stringify(deviceConfig));
    let data = gtdFwk.gtdSend(deviceConfig);
    logger.info("data = {}", JSON.stringify(data));
    logger.info("returning result = {}", JSON.stringify(data.msg.result));
    return data.msg.result;
}

function getRootXPath(input)
{
  var parseTarget = new ParseTarget();
  var ospfInstance = parseTarget.getOspfData(input,"ospfInstance");
  var parentXpath = 'configure/router=Base/ospf={$ospf-instance}';
  parentXpath = parentXpath.replace("{$ospf-instance}", ospfInstance);
  logger.info("parentXpath: " + parentXpath);
  return parentXpath;
}