function MdSuggest() {
     this.getTunnelGrp = function (neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/isa/tunnel-group`;
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}", neId, url);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg["nokia-conf:tunnel-group"];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse) ? finalResponse.filter(data =>data['multi-active']!==undefined).map(data => data['id']).filter(value => value != null) : [];
      logger.info("ret = " + JSON.stringify(ret));
      return ret;
   }

    this.getDomain = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/redundancy/multi-chassis/ipsec-domain?fields=id`;
      return this.getSuggestData(neId, url, "nokia-conf:ipsec-domain", "id");
   }

    this.getIsaNatGroupId = function(neId) {
        const url = "/restconf/data/network-device-mgr:network-devices/network-device="+neId+"/root/nokia-conf:/configure/isa/nat-group?fields=id";
        return this.getSuggestData(neId, url, "nokia-conf:nat-group", "id");
    }

    this.getKeychainsKeychainName = function(neId) {
        const url = "/restconf/data/network-device-mgr:network-devices/network-device="+neId+"/root/nokia-conf:/configure/system/security/keychains/keychain?fields=keychain-name";
        return this.getSuggestData(neId, url, "nokia-conf:keychain", "keychain-name");
    }

    this.getConfigurePortId = function(neId) {
        const url = "/restconf/data/network-device-mgr:network-devices/network-device="+neId+"/root/nokia-conf:/configure/port?fields=port-id";
        return this.getSuggestData(neId, url, "nokia-conf:port", "port-id");
    }

    this.getConfigureLagName = function(neId) {
        const url = "/restconf/data/network-device-mgr:network-devices/network-device="+neId+"/root/nokia-conf:/configure/lag?fields=lag-name";
        return this.getSuggestData(neId, url, "nokia-conf:lag", "lag-name");
    }

    this.getConfigurePwPortPwPortId = function(neId) {
        const url = "/restconf/data/network-device-mgr:network-devices/network-device="+neId+"/root/nokia-conf:/configure/pw-port?fields=pw-port-id";
        return this.getSuggestData(neId, url, "nokia-conf:pw-port", "pw-port-id");
    }

    this.getDiameterNodeOriginHost = function(neId) {
        const url = "/restconf/data/network-device-mgr:network-devices/network-device="+neId+"/root/nokia-conf:/configure/aaa/diameter/node?fields=origin-host";
        return this.getSuggestData(neId, url, "nokia-conf:node", "origin-host");
    }

   this.getSuggestData = function(neId, url, initialProperty, propertyName) {
      const mdcFwk = new MdcFwk();
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg[initialProperty];
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data[propertyName]).filter(value => value != null):[];
      logger.info("ret = {}", JSON.stringify(ret));
      return ret;
    }
}