function ModelDeviceMapping() {

    this.getMapping = function(type){
        switch(type){
            case "port":
                return this.getConnectorPortMapping();
            default:
                return this.getConnectorPortMapping();
        }
    }

    this.getConnectorPortMapping = function(){
        var mapping = {};

        mapping['port.admin-state'] = 'administrativeState';
        mapping['port.connector.breakout'] = 'portConnectorBreakoutType';
        mapping['port.connector.rs-fec-mode'] = 'portConnectorRsFecMode';

        return mapping;
    }

}
