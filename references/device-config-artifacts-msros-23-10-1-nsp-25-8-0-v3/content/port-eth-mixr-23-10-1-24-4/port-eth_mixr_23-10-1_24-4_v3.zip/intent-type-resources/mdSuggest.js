function MdSuggest() {

    this.getSlopePolicyName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/slope-policy";
        return this.getData(neId, url, "nokia-conf:slope-policy", "slope-policy-name");
    }

    this.getAccountingPolicyId = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/log/accounting-policy";
        return this.getData(neId, url, "nokia-conf:accounting-policy", "policy-id");
    }

    this.getEgressQueueGroupName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/queue-group-templates/egress/queue-group";
        return this.getData(neId, url, "nokia-conf:queue-group", "egress-queue-group-name");
    }

    this.getSchedulerPolicyName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/scheduler-policy";
        return this.getData(neId, url, "nokia-conf:scheduler-policy", "scheduler-policy-name");
    }

    this.getHwAggShaperSchedulerPolicyName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/hw-agg-shaper-scheduler-policy";
        return this.getData(neId, url, "nokia-conf:hw-agg-shaper-scheduler-policy", "name");
    }

    this.getPortSchedulerPolicyName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/port-scheduler-policy";
        return this.getData(neId, url, "nokia-conf:port-scheduler-policy", "name");
    }

    this.getRadiusServerPolicyName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/aaa/radius/server-policy";
        return this.getData(neId, url, "nokia-conf:server-policy", "name");
    }

    this.getNetworkQueuePolicy = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/network-queue";
        return this.getData(neId, url, "nokia-conf:network-queue", "network-queue-policy");
    }

    this.getOperGroupName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/service/oper-group";
        return this.getData(neId, url, "nokia-conf:oper-group", "name");
    }

    this.getDistCpuProtectionPolicyName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/system/security/dist-cpu-protection/policy";
        return this.getPortDistCpuProtectionPolicyData(neId, url, "nokia-conf:policy", "policy-name", "type");
    }

    this.getIngressQueueGroupName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/queue-group-templates/ingress/queue-group";
        return this.getData(neId, url, "nokia-conf:queue-group", "ingress-queue-group-name");
    }

    this.getMacPolicyId = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/macsec/mac-policy";
        return this.getData(neId, url, "nokia-conf:mac-policy", "mac-policy-id");
    }

    this.getCaName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/macsec/connectivity-association";
        return this.getData(neId, url, "nokia-conf:connectivity-association", "ca-name");
    }

    this.getRadiusPolicyName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/system/security/dot1x/radius-policy";
        return this.getData(neId, url, "nokia-conf:radius-policy", "policy-name");
    }

    this.getPortQosPolicyName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/port-qos-policy";
        return this.getData(neId, url, "nokia-conf:port-qos-policy", "port-qos-policy-name");
    }

    this.getHsPortPoolPolicyName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/hs-port-pool-policy";
        return this.getData(neId, url, "nokia-conf:hs-port-pool-policy", "name");
    }

    this.getHsSchedulerPolicyName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/hs-scheduler-policy";
        return this.getData(neId, url, "nokia-conf:hs-scheduler-policy", "name");
    }

    this.getMdAdminName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/eth-cfm/domain";
        return this.getData(neId, url, "nokia-conf:domain", "md-admin-name");
    }

    this.getPolicerControlPolicyName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/policer-control-policy";
        return this.getData(neId, url, "nokia-conf:policer-control-policy", "policer-control-policy-name");
    }

    this.getVlanQosPolicyName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/vlan-qos-policy";
        return this.getData(neId, url, "nokia-conf:vlan-qos-policy", "vlan-qos-policy-name");
    }

    this.getEgressQueueGroupQueueId = function (neId, egressQueueGroupName) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/queue-group-templates/egress/queue-group=" + egressQueueGroupName + "/queue";
        return this.getData(neId, url, "nokia-conf:queue", "queue-id");
    }

    this.getSchedulerName = function (neId, schedulerPolicyName) {
        var ret = [];

        for (var tierId=1; tierId <= 3; tierId++){
            var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/scheduler-policy=" + schedulerPolicyName + "/tier=" + tierId + "/scheduler";
            ret = ret.concat(this.getData(neId, url, "nokia-conf:scheduler", "scheduler-name"));
        }

        return ret;
    }

    this.getIngressQueueGroupQueueId = function (neId, ingressQueueGroupName) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/queue-group-templates/ingress/queue-group=" + ingressQueueGroupName + "/queue";
        return this.getData(neId, url, "nokia-conf:queue", "queue-id");
    }

    this.getMaAdminName = function (neId, mdAdminName) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/eth-cfm/domain=" + mdAdminName + "/association";
        return this.getData(neId, url, "nokia-conf:association", "ma-admin-name");
    }

    this.getData = function (neId, url, initialProperty, propertyName) {
        var mdcFwk = new MdcFwk();
        logger.info(LOG_PREFIX_PORT + "MdSuggest--getData---neId={}, url={}, type={}", neId, url, propertyName);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info("MDC resultFetch =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"][initialProperty];
        logger.info("finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                logger.info("Device " + propertyName + " Data = {}", finalResponse[index][propertyName]);
                ret.push(finalResponse[index][propertyName]);
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info("ret = \n" + JSON.stringify(ret));
        return ret;
    }

    this.getPortDistCpuProtectionPolicyData = function (neId, url, initialProperty, propertyName, policyType) {
        var mdcFwk = new MdcFwk();
        logger.info(LOG_PREFIX_PORT + "MdSuggest--getData---neId={}, url={}, type={}", neId, url, propertyName);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info("MDC resultFetch =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"][initialProperty];
        logger.info("finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                if (finalResponse[index][policyType] == "port")
                {
                    logger.info("Device " + propertyName + " Data = {}", finalResponse[index][propertyName]);
                    ret.push(finalResponse[index][propertyName]);
                }
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info("ret = \n" + JSON.stringify(ret));
        return ret;
    }
}