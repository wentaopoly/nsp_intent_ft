load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'})

function utilities() {
    var intentDeviationObj = new IntentDeviceDeviation();

    this.setSuccessResult = function (result, savedTopology) {
        result.setSuccess(true);
        if (savedTopology !== undefined)
        {
            result.setTopology(savedTopology);
        }
        return result;
    }
    this.reportMisaligned = function (target, result, auditReport) {
        var report = result;
        if (!report.aligned)
        {
            for (var i = 0; i < report.misalignedAttributes.length; i++)
            {
                var attributeData = report.misalignedAttributes[i];
                if (attributeData.expected == "present")
                {
                    //misaligned object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else if (attributeData.expected == "not present")
                {
                    //undesired object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                    auditReport.addMisAlignedAttribute(misalignedAttribute);
                }
            }
        }
        return auditReport
    }
    this.editPayload = function (fdn, properties, childProperties, fullClassName, objectFullName) {
        var payload = {};
        var configInfo = {};
        configInfo["containedClassProperties"] = properties;
        configInfo["containmentInfo"] = childProperties;
        configInfo["objectClassName"] = fullClassName;
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName;
        payload["configInfo"] = configInfo;
        return payload;
    }
    //convert admin-sate to NFMP administrate State.
    this.convertAdminStateGreenField = function (adminState) {
        if (adminState == "enable")
        {
            return "inService";
        }
        else if (adminState == "disable")
        {
            return "outOfService";
        }
    }

    //convert administrate State to intent admin-state.
    this.convertAdminStateBrownField = function (adminState) {
        if (adminState == "inService")
        {
            return "enable";
        }
        else if (adminState == "outOfService")
        {
            return "disable";
        }
    }

    this.convertXiomMdaSlotIdBrownField = function (neId, aInMdaSlotNumber) {
        var xiomMdaSlotNumber = aInMdaSlotNumber;
        var neFamily = intentDeviationObj.getNeFamilyRelease(neId);
        var neChassisType = intentDeviationObj.getChassisType(neFamily);
        logger.info("Chassis Type = " + neChassisType);
        if (neChassisType === "7750 SR-14s")
        {
            if (aInMdaSlotNumber == 3 || aInMdaSlotNumber == 5)
            {
                xiomMdaSlotNumber = 1;
            }
            if (aInMdaSlotNumber == 4 || aInMdaSlotNumber == 6)
            {
                xiomMdaSlotNumber = 2;
            }
        }
        else
        {
            if (aInMdaSlotNumber == 2)
            {
                xiomMdaSlotNumber = 1;
            }
            if (aInMdaSlotNumber == 3)
            {
                xiomMdaSlotNumber = 2;
            }
        }
        logger.info("xiomMdaSlotNumber = " + xiomMdaSlotNumber);
        return xiomMdaSlotNumber;
    }
    this.convertXiomMdaSlotIdGreenField = function (neId, aInXiomCardSlotNumber, aInMdaSlotNumber) {
        var xiomMdaSlotNumber = 0;
        var neFamily = intentDeviationObj.getNeFamilyRelease(neId);
        var neChassisType = intentDeviationObj.getChassisType(neFamily);
        logger.info("Chassis Type = " + neChassisType);
        if (neChassisType === "7750 SR-14s")
        {
            if (aInXiomCardSlotNumber == 1)
            {
                if (aInMdaSlotNumber == 1)
                {
                    xiomMdaSlotNumber = 3;
                }
                if (aInMdaSlotNumber == 2)
                {
                    xiomMdaSlotNumber = 4;
                }
            }
            if (aInXiomCardSlotNumber == 2)
            {
                if (aInMdaSlotNumber == 1)
                {
                    xiomMdaSlotNumber = 5;
                }
                if (aInMdaSlotNumber == 2)
                {
                    xiomMdaSlotNumber = 6;
                }
            }
        }
        else
        {
            if (aInXiomCardSlotNumber == 1)
            {
                if (aInMdaSlotNumber == 1)
                {
                    xiomMdaSlotNumber = 2;
                }
                if (aInMdaSlotNumber == 2)
                {
                    xiomMdaSlotNumber = 3;
                }
            }
        }
        logger.info("xiomMdaSlotNumber = " + xiomMdaSlotNumber);
        return xiomMdaSlotNumber;
    }

    this.modifyNeIdForIpV6 = function (objectFullName, neId) {
        logger.info("modifying NeId For IpV6");
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }
}
