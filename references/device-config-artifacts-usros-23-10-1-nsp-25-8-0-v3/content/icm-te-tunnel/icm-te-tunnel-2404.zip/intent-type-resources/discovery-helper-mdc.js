var RuntimeException = Java.type('java.lang.RuntimeException');

load({
    script: resourceProvider.getResource('mdc-fwk.js'),
    name: 'MdcFwk'
});
load({
    script: resourceProvider.getResource('parse-target.js'),
    name: 'ParseTarget'
});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
load({script: resourceProvider.getResource("color-mapping.js"),name: "color-mapping"});
colorAdminTagMapping = new ColorMapping().colorMapping();
MdcDiscoveryHelper.prototype.ietfUtil = new IetfUtilities();

mdcFwk = new MdcFwk();
parseTarget = new ParseTarget();

function MdcDiscoveryHelper() {

    var intentDeviationObj = new IntentDeviceDeviation();

    this.getDeviceConfiguration = function (targetWithTemplate, requestContext, neId) {
        var lspName = parseTarget.getUniqueIdentifier(targetWithTemplate);
        var templateMetaInfo = this.getDeviceTemplate(neId, requestContext);
        if (templateMetaInfo["type"] === "Juniper") {
            return this.getConfiguration(neId,  "label-switched-path", lspName, templateMetaInfo);
        }else{
        return this.getConfiguration(neId, "lsp", lspName, templateMetaInfo);
        }
    }

    this.getConfiguration = function (neId, configType, identifier, templateMetaInfo) {
        logger.info("getConfiguration: neId = {}, configType = {}, identifier = {}", neId, configType, identifier);
        var url;
        var getResult;
        var configFromDevice;
        if (templateMetaInfo["type"] === "Cisco" || (templateMetaInfo["type"] === "CiscoR-IOSXRV9000-CC")) {
            var interface_portnum = identifier.split("_")[1];
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/Cisco-IOS-XR-ifmgr-cfg:/interface-configurations/interface-configuration=act"
                + "=" + "tunnel-te" + interface_portnum;
            getResult = mdcFwk.fetch(neId, url);
            logger.info("getConfiguration: getResult >> {}", JSON.stringify(getResult));
            configFromDevice = getResult.msg["Cisco-IOS-XR-ifmgr-cfg:interface-configuration"];
           
        }
        else if (templateMetaInfo["type"] === "Juniper") {
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/configuration:/configuration/protocols/mpls/"
                + configType + "=" + identifier;
            getResult = mdcFwk.fetch(neId, url);
            logger.info("getConfiguration: getResult22 >> {}", JSON.stringify(getResult.msg["junos-conf-protocols:label-switched-path"]));
            configFromDevice = JSON.stringify(getResult.msg["junos-conf-protocols:" + configType]);
           
        } else if (templateMetaInfo["type"] === "ATN 950D" || templateMetaInfo["type"] === "ATN 910C-G" || templateMetaInfo["type"] === "NetEngine 8000" ) {
            var interface_portnum = identifier.split("_")[1];
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/huawei-ifm:/ifm/interfaces/interface"
            + "=" + "Tunnel" + interface_portnum;
            getResult = mdcFwk.fetch(neId, url);
            logger.info("getConfiguration: getResult22 >> {}", JSON.stringify(getResult.msg["huawei-ifm:interface"]));
            configFromDevice = JSON.stringify(getResult.msg["huawei-ifm:interface"]);
           
        } 
        else {
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base/mpls/"
                + configType + "=" + identifier;
            getResult = mdcFwk.fetch(neId, url);
            logger.info("getConfiguration: getResult >> {}", JSON.stringify(getResult));
            configFromDevice = getResult.msg["nokia-conf:" + configType];
           
        }
        if (configFromDevice == undefined) {
            throw new RuntimeException("cannot get configuration from device");
        }
        return configFromDevice;
    }

    this.getCiscoConfiguration = function (neId, configType, identifier) {
        logger.info("getConfiguration: neId = {}, configType = {}, identifier = {}", neId, configType, identifier);
         var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/Cisco-IOS-XR-ip-iep-cfg:/ip-explicit-paths/paths/path=name/name"
                + "=" + identifier;
        var getResult = mdcFwk.fetch(neId, url);
        logger.info("getConfiguration: getResult >> {}", JSON.stringify(getResult));
        var configFromDevice = getResult.msg["Cisco-IOS-XR-ip-iep-cfg:name"];
        if (configFromDevice == undefined) {
            throw new RuntimeException("cannot get configuration from device");
        }
        return configFromDevice;
    }


    this.getHuaweiConfiguration = function (neId, configType, identifier) {
        logger.info("getConfiguration: neId = {}, configType = {}, identifier = {}", neId, configType, identifier);
         var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/huawei-te:/te/explicit-paths/explicit-path"
                + "=" + identifier;
        var getResult = mdcFwk.fetch(neId, url);
        logger.info("getConfiguration: getResult >> {}", JSON.stringify(getResult));
        var configFromDevice = getResult.msg["huawei-te:explicit-path"];
        if (configFromDevice == undefined) {
            throw new RuntimeException("cannot get configuration from device");
        }
        return configFromDevice;
    }

    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, requestContext, neId) { 
        var parsedDefaultTargetData = JSON.parse(defaultTargetData);
        var templateMetaInfo = this.getDeviceTemplate(neId, requestContext);
        if (null !== deviceConfig) {
            if (templateMetaInfo["type"] === "Cisco" || (templateMetaInfo["type"] === "CiscoR-IOSXRV9000-CC")) {
                var mappings = resourceProvider.getResource("md-cisco-device-mapping.json");
                mappings = JSON.parse(mappings);
                var defaultTemplateDataMap = this.prepareDefaultTemplateDataMap(parsedDefaultTargetData);
                this.extractCiscoLSPProperties(defaultTemplateDataMap, deviceConfig[0], mappings, requestContext, templateMetaInfo);
            }
            else if (templateMetaInfo["type"] === "Juniper") {
                var mappings = resourceProvider.getResource("md-juniper-device-mapping.json");
                mappings = JSON.parse(mappings);
                var defaultTemplateDataMap = this.prepareDefaultTemplateDataMap(parsedDefaultTargetData);
                this.extractLSPProperties(defaultTemplateDataMap, deviceConfig[0], mappings, requestContext, templateMetaInfo);

            }else if (templateMetaInfo["type"] === "ATN 950D" || templateMetaInfo["type"] === "ATN 910C-G" || templateMetaInfo["type"] ==="NetEngine 8000") {
                var mappings = resourceProvider.getResource("md-huawei-device-mapping.json");
                mappings = JSON.parse(mappings);
                var defaultTemplateDataMap = this.prepareDefaultTemplateDataMap(parsedDefaultTargetData);
                this.extractHuaweiLSPProperties(defaultTemplateDataMap, deviceConfig[0], mappings, requestContext, templateMetaInfo);

            }
            
            else {
                var mappings = resourceProvider.getResource("md-device-mapping.json");
                mappings = JSON.parse(mappings);
                var defaultTemplateDataMap = this.prepareDefaultTemplateDataMap(parsedDefaultTargetData);
                this.extractLSPProperties(defaultTemplateDataMap, deviceConfig[0], mappings, requestContext, templateMetaInfo);
            }
        }
        parsedDefaultTargetData = JSON.parse(JSON.stringify(parsedDefaultTargetData));
        logger.debug("Intent data after updating from MD: \n{}", JSON.stringify(parsedDefaultTargetData))
        this.clearEmpties(parsedDefaultTargetData);
        logger.info("Intent data after clearing empties from MD: \n{}", JSON.stringify(parsedDefaultTargetData));
        return parsedDefaultTargetData;
    }

    this.extractProtection = function (deviceConfig, defaultTemplateDataMap) {
        if (deviceConfig["fast-reroute"] && deviceConfig["type"] != "p2p-sr-te") {
            var protectionType = null;
            switch (deviceConfig["fast-reroute"]["frr-method"]) {
                case "one-to-one":
                    protectionType = "lsp-protection-1-for-1";
                    break;
                case "facility":
                    protectionType = "lsp-protection-1-for-n";
                    break;
                default:
                    protectionType = "lsp-protection-1-for-1";
                    break;
            }
            defaultTemplateDataMap["default-target-data"]["protection"] = {
                "enable": true,
                "protection-type": protectionType
            }
        }
    }

    this.extractCiscoProtection =function (deviceConfig, defaultTemplateDataMap) {
        if (deviceConfig["tunnel-te-attributes"]["fast-reroute"] && deviceConfig["tunnel-te-attributes"]["fast-reroute"]["bandwidth-protection"] && deviceConfig["tunnel-te-attributes"]["fast-reroute"]["node-protection"]) {
            defaultTemplateDataMap["default-target-data"]["protection"] = {
                "enable": true
            }
        }
    }

    this.extractJuniperProtection =function (deviceConfig, defaultTemplateDataMap) {
        if (deviceConfig["fast-reroute"] && deviceConfig["fast-reroute"]) {
            defaultTemplateDataMap["default-target-data"]["protection"] = {
                "enable": true
            }
        }
    }

    this.extractHuaweiProtection =function (deviceConfig, defaultTemplateDataMap) {
        if (deviceConfig["tunnel-protocol"]["te-tunnel"]["rsvp-te"]["fast-reroute"]["mode"]) {
            defaultTemplateDataMap["default-target-data"]["protection"] = {
                "enable": true
               
            }
        }else{
            defaultTemplateDataMap["default-target-data"]["protection"] = {
            "enable": false
            }
        }
    }

    this.extractAdminTag = function (deviceConfig, defaultTemplateDataMap) {
        if (deviceConfig["admin-tag"]) {
            defaultTemplateDataMap["default-target-data"]["color"] = this.convertColorBrownField(deviceConfig["admin-tag"][0]["name"]);
        }
    }

    this.extractLSPProperties = function (defaultTemplateDataMap, deviceConfig, mappings, requestContext, templateMetaInfo) {
        this.extractProperties(defaultTemplateDataMap["default-target-data"], deviceConfig, mappings, templateMetaInfo);
        // Retrieve LSP association-objects (path-profile)
        if (deviceConfig["path-profile"]) {
            var pathProfileArray = this.extractContainerProperties(defaultTemplateDataMap["association-object-extended"], deviceConfig["path-profile"], mappings["association-objects"]["association-object-extended"][0],templateMetaInfo);
            logger.info("extractLSPProperties: pathProfileArray = {}", JSON.stringify(pathProfileArray))
            defaultTemplateDataMap["default-target-data"]["association-objects"] = { "association-object-extended": pathProfileArray }
        }


        if (templateMetaInfo["type"] === "Juniper"){
            this.extractJuniperProtection(deviceConfig, defaultTemplateDataMap);
        // Primary-path - start
        if(deviceConfig["primary"]!= undefined ){
        if (deviceConfig["primary"][0]["name"] != "hopless") {
            var primaryPathArray = this.extractContainerProperties(defaultTemplateDataMap["primary-paths"],
                [deviceConfig["primary"][0]], mappings["primary-paths"]["primary-path"][0], templateMetaInfo);
            defaultTemplateDataMap["default-target-data"]["primary-paths"] = {"primary-path": primaryPathArray}
            logger.info("extractLSPProperties: primaryPathArray = {}", JSON.stringify(primaryPathArray))
            // Update Primary path sub containers
            this.extractPathProperties(deviceConfig["primary"][0], defaultTemplateDataMap, deviceConfig["from"], deviceConfig["name"], true, 0, requestContext,templateMetaInfo);
            // Update path-computation
            this.populatePathComputationMethod(deviceConfig["path-computation-method"], defaultTemplateDataMap);
        } else {
            this.populateGlobalPriorities(defaultTemplateDataMap, deviceConfig["primary"][0]["priority"]["setup-priority"], deviceConfig["primary"][0]["priority"]["hold-priority"]);
        }
        }
        // Primary-path - end

        // Secondary-path - start
        if (deviceConfig["secondary"]) {
            var secondaryPathArray = this.extractContainerProperties(defaultTemplateDataMap["secondary-paths"],
                deviceConfig["secondary"], mappings["secondary-paths"]["secondary-path"][0], templateMetaInfo);
            logger.info("extractLSPProperties: secondaryPathArray = {}", JSON.stringify(secondaryPathArray))
            defaultTemplateDataMap["default-target-data"]["secondary-paths"] = {"secondary-path": secondaryPathArray}
            // Update Secondary path sub containers
            for (var pathIndex = 0; pathIndex < deviceConfig["secondary"].length; pathIndex++) {
                this.extractPathProperties(deviceConfig["secondary"][pathIndex], defaultTemplateDataMap, deviceConfig["from"], deviceConfig["name"], false, pathIndex, requestContext, templateMetaInfo);
            }
        }
    }else{
        this.extractProtection(deviceConfig, defaultTemplateDataMap);
        // Retrieve Admin-tag (Color)
        this.extractAdminTag(deviceConfig, defaultTemplateDataMap);
        if (deviceConfig["primary"][0]["path-name"] != "hopless") {
            var primaryPathArray = this.extractContainerProperties(defaultTemplateDataMap["primary-paths"],
                [deviceConfig["primary"][0]], mappings["primary-paths"]["primary-path"][0]);
            defaultTemplateDataMap["default-target-data"]["primary-paths"] = {"primary-path": primaryPathArray}
            logger.info("extractLSPProperties: primaryPathArray = {}", JSON.stringify(primaryPathArray))
            // Update Primary path sub containers
            this.extractPathProperties(deviceConfig["primary"][0], defaultTemplateDataMap, deviceConfig["from"], deviceConfig["lsp-name"], true, 0, requestContext, templateMetaInfo);
            // Update path-computation
            this.populatePathComputationMethod(deviceConfig["path-computation-method"], defaultTemplateDataMap);
        } else {
            this.populateGlobalPriorities(defaultTemplateDataMap, deviceConfig["primary"][0]["priority"]["setup-priority"], deviceConfig["primary"][0]["priority"]["hold-priority"]);
        }
        // Primary-path - end

        // Secondary-path - start
        if (deviceConfig["secondary"]) {
            var secondaryPathArray = this.extractContainerProperties(defaultTemplateDataMap["secondary-paths"],
                deviceConfig["secondary"], mappings["secondary-paths"]["secondary-path"][0]);
            logger.info("extractLSPProperties: secondaryPathArray = {}", JSON.stringify(secondaryPathArray))
            defaultTemplateDataMap["default-target-data"]["secondary-paths"] = {"secondary-path": secondaryPathArray}
            // Update Secondary path sub containers
            for (var pathIndex = 0; pathIndex < deviceConfig["secondary"].length; pathIndex++) {
                this.extractPathProperties(deviceConfig["secondary"][pathIndex], defaultTemplateDataMap, deviceConfig["from"], deviceConfig["lsp-name"], false, pathIndex, requestContext, templateMetaInfo);
            }
            // Secondary-path - end
    }    
    }
}


 /***Start Cisco */
 this.extractCiscoLSPProperties = function (defaultTemplateDataMap, deviceConfig, mappings, requestContext, templateMetaInfo) {
    this.extractProperties(defaultTemplateDataMap["default-target-data"], deviceConfig, mappings, templateMetaInfo);
    // Retrieve LSP association-objects (path-profile)
    if (deviceConfig["path-profile"]) {
        var pathProfileArray = this.extractContainerProperties(defaultTemplateDataMap["association-object-extended"], deviceConfig["path-profile"], mappings["association-objects"]["association-object-extended"][0], templateMetaInfo);
        logger.info("extractLSPProperties: pathProfileArray = {}", JSON.stringify(pathProfileArray))
        defaultTemplateDataMap["default-target-data"]["association-objects"] = { "association-object-extended": pathProfileArray }
    }

    // Retrieve LSP Protection
    this.extractCiscoProtection(deviceConfig, defaultTemplateDataMap);

    var priority = deviceConfig["tunnel-te-attributes"]["priority"];
    var bandwidth = deviceConfig["tunnel-te-attributes"]["bandwidth"];
    var destination = deviceConfig["tunnel-te-attributes"]["destination"]
    var pathOptionProtect = deviceConfig["tunnel-te-attributes"]["path-option-protects"]["path-option-protect"];
    var pathOption = pathOptionProtect[0]["path-options"]["path-option"];


    var index = -1;
    pathOption[0] = pathOptionProtect[0]["path-options"]["path-option"][0];
    // Copying priority and bandwidth properties to pathOption[0]
    pathOption[0].priority = priority;
    pathOption[0].bandwidth = bandwidth;
    pathOption[0].destination = destination;


    
    
    if (pathOption[0]["path-name"] != "hopless" &&  pathOption[0]["path-name"] != undefined) {
        var prim = [];
        var primaryPathArray = this.extractContainerProperties(defaultTemplateDataMap["primary-paths"],
            prim = [pathOption[0]], mappings["primary-paths"]["primary-path"][0],templateMetaInfo);
        defaultTemplateDataMap["default-target-data"]["primary-paths"] = { "primary-path": primaryPathArray }
        logger.info("extractLSPProperties: primaryPathArray = {}", JSON.stringify(primaryPathArray))
        // Update Primary path sub containers
        
        this.extractCiscoPathProperties(pathOption[0], defaultTemplateDataMap, pathOption[0].source, deviceConfig["tunnel-te-attributes"]["signalled-name"], true, 0, requestContext, index, templateMetaInfo);
        // Update path-computation
        
        this.populateCiscoPathComputationMethod(deviceConfig["tunnel-te-attributes"]["pce"], defaultTemplateDataMap);
    } else {
        if( pathOption[0]["priority"] !== undefined &&  pathOption[0]["priority"]["setup-priority"]!== undefined){
        this.populateGlobalPriorities(defaultTemplateDataMap, pathOption[0]["priority"]["setup-priority"], pathOption[0]["priority"]["hold-priority"]);
        }
    }
    // Primary-path - end


    // Secondary-path - start
    if (pathOption[1]!= undefined && pathOption[1]["path-name"]) {
        if (pathOption[1]["path-name"] && pathOption[2]== undefined) {
            // Merge the properties of pathOption2 into pathOption1
            var secondary = [];
            var secondaryPathArray = this.extractContainerProperties(defaultTemplateDataMap["secondary-paths"],
                secondary = [pathOption[1]], mappings["secondary-paths"]["secondary-path"][0], templateMetaInfo);
            logger.info("extractLSPProperties: secondaryPathArray = {}", JSON.stringify(secondaryPathArray));
        } else if (pathOption[1]["path-name"] && pathOption[2]["path-name"]) {
           
            var combinedArray = [];
            combinedArray.push(pathOption[1]);
            // Push pathOption[2] into the combined array
            combinedArray.push(pathOption[2]);
            var secondaryPathArray = this.extractContainerProperties(defaultTemplateDataMap["secondary-paths"],
                combinedArray, mappings["secondary-paths"]["secondary-path"][0], templateMetaInfo);
            logger.info("extractLSPProperties: secondaryPathArray = {}", JSON.stringify(secondaryPathArray));
        }

        defaultTemplateDataMap["default-target-data"]["secondary-paths"] = { "secondary-path": secondaryPathArray }
        for (var pathIndex = 1; pathIndex < pathOption.length; pathIndex++) {
            if(pathOption[pathIndex]["path-name"]!= undefined) {
            this.extractCiscoPathProperties(pathOption[pathIndex], defaultTemplateDataMap, pathOption[1].source, deviceConfig["tunnel-te-attributes"]["signalled-name"], false, pathIndex, requestContext, index, templateMetaInfo);
            }
        }
    }
// Secondary-path - end


    var newArray = [];
    // Iterate over the original array and push elements with the specified property into the new array
   for (const element of pathOption) {
       if (element["path-option-attribute-set-name"]) {
              newArray.push(element);
           }
        }
   
    var pathAffinityNames = this.extractCiscoAdminGroup(newArray);
        if (pathAffinityNames) {
                defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["path-affinity-names"] = pathAffinityNames;
            }  
    
}
/****Close Cisco */




//Huawei start
this.extractHuaweiLSPProperties = function (defaultTemplateDataMap, deviceConfig, mappings, requestContext, templateMetaInfo) {
    
    this.extractProperties(defaultTemplateDataMap["default-target-data"], deviceConfig, mappings, templateMetaInfo);
    // Retrieve LSP association-objects (path-profile)
    if (deviceConfig["path-profile"]) {
        var pathProfileArray = this.extractContainerProperties(defaultTemplateDataMap["association-object-extended"], deviceConfig["path-profile"], mappings["association-objects"]["association-object-extended"][0], templateMetaInfo);
        logger.info("extractLSPProperties: pathProfileArray = {}", JSON.stringify(pathProfileArray))
        defaultTemplateDataMap["default-target-data"]["association-objects"] = { "association-object-extended": pathProfileArray }
    }

    // Retrieve LSP Protection
    this.extractHuaweiProtection(deviceConfig, defaultTemplateDataMap);

    var setUpPriority = deviceConfig["tunnel-protocol"]["te-tunnel"]["rsvp-te"]["setup-priority"];
    var holdUpPriority = deviceConfig["tunnel-protocol"]["te-tunnel"]["rsvp-te"]["hold-priority"];
    var bandwidth = deviceConfig["tunnel-protocol"]["te-tunnel"]["rsvp-te"]["bandwidth"];
    var destination = deviceConfig["tunnel-protocol"]["te-tunnel"]["common-attributes"]["egress-lsr-id"];
    var lspPaths = deviceConfig["tunnel-protocol"]["te-tunnel"]["rsvp-te"]["lsp-paths"]["lsp-path"];
    var wtr = deviceConfig["tunnel-protocol"]["te-tunnel"]["rsvp-te"]["hotstandby"] != undefined ? deviceConfig["tunnel-protocol"]["te-tunnel"]["rsvp-te"]["hotstandby"]["wtr"] : null;
    var lspPrimaryPath;
    var lspSecPath;
    
    //var lspPath = lspPaths[0];
     var priority = {
        "setup-priority" : setUpPriority,
        "hold-priority"  : holdUpPriority
     }

    var index = -1;
     for (var key in lspPaths) {
        if (lspPaths[key]["path-type"] === "primary") {
            lspPrimaryPath = lspPaths[key];
        }
        if (lspPaths[key]["path-type"] === "ordinary") {
            lspSecPath = lspPaths[key];
        }
        if(lspPaths[key]["path-type"] === "hot-standby"){
            lspSecPath = lspPaths[key];
        }
    }
  
    // Copying priority and bandwidth properties to pathOption[0]
   // lspPrimaryPath.setUpPriority = setUpPriority;
    lspPrimaryPath.priority = priority;
    lspPrimaryPath.bandwidth = bandwidth;
    lspPrimaryPath.destination = destination;
    
    if (lspPrimaryPath != undefined  && lspPrimaryPath["explicit-path-name"] != undefined) {
        var prim = [];
        var primaryPathArray = this.extractContainerProperties(defaultTemplateDataMap["primary-paths"],
            prim = [lspPrimaryPath], mappings["primary-paths"]["primary-path"][0],templateMetaInfo);
        defaultTemplateDataMap["default-target-data"]["primary-paths"] = { "primary-path": primaryPathArray }
        logger.info("extractLSPProperties: primaryPathArray = {}", JSON.stringify(primaryPathArray))
        // Update Primary path sub containers
       
        this.extractHuaweiPathProperties(lspPrimaryPath, defaultTemplateDataMap, true, 0, requestContext, index, templateMetaInfo);
    } else {
        if( lspPrimaryPath["priority"] !== undefined &&  lspPrimaryPath["priority"]["setup-priority"]!== undefined){
        this.populateGlobalPriorities(defaultTemplateDataMap, lspPrimaryPath["priority"]["setup-priority"], lspPrimaryPath["priority"]["hold-priority"]);
        }
    }
    // Primary-path - end


    // Secondary-path - start
    
    if (lspSecPath != undefined && lspSecPath["explicit-path-name"]) {
       
            // Merge the properties of pathOption2 into pathOption1
            var secondary = [];
            var secondaryPathArray = this.extractContainerProperties(defaultTemplateDataMap["secondary-paths"],
                secondary = [lspSecPath], mappings["secondary-paths"]["secondary-path"][0], templateMetaInfo);
            logger.info("extractLSPProperties: secondaryPathArray = {}", JSON.stringify(secondaryPathArray));
        

        defaultTemplateDataMap["default-target-data"]["secondary-paths"] = { "secondary-path": secondaryPathArray }
       
           
            this.extractHuaweiPathProperties(lspSecPath, defaultTemplateDataMap,  false, 0, requestContext, index, templateMetaInfo,wtr);
            
        
    }

// Secondary-path - end
 
    
}
//Huawei close




    this.populatePathComputationMethod = function (pathComputationMethod, defaultTemplateDataMap) {
        if (pathComputationMethod == "pce") {
            defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["use-path-computation"] = true;
        } else {
            defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["use-path-computation"] = false;
        }
        defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["path-computation-method"] = this.convertPathComputationMethodBrownField(pathComputationMethod);
    }

    this.populateCiscoPathComputationMethod = function (pathComputationMethod, defaultTemplateDataMap) {
        if (pathComputationMethod != undefined && pathComputationMethod["delegation"] && pathComputationMethod["delegation"]["enable"]) {
            defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["use-path-computation"] = true;
        } else {
            defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["use-path-computation"] = false;
        }
        defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["path-computation-method"] = this.convertPathCiscoComputationMethodBrownField(pathComputationMethod);
    }

    this.populateGlobalPriorities = function (defaultTemplateDataMap, setupPriority, holdPriority) {
        defaultTemplateDataMap["default-target-data"]["setup-priority"] = setupPriority;
        defaultTemplateDataMap["default-target-data"]["hold-priority"] = holdPriority;
    }

    this.populateDefaultPriorities = function (pathDataMap) {
        if (!pathDataMap["setup-priority"]) {
            pathDataMap["setup-priority"] = 0
        }
        if (!pathDataMap["hold-priority"]) {
            pathDataMap["hold-priority"] = 0
        }
    }

    this.extractPathProperties = function (lspPathConfig, defaultTemplateDataMap, deviceId, lspName, isPrimaryPath, pathIndex, requestContext, templateMetaInfo) {
        var explicitRouteObjectsAlways;
        if(templateMetaInfo["type"] === "Juniper"){
        var provisionedPathConfig = this.getConfiguration(requestContext.get("neId"), "path", lspPathConfig["name"], templateMetaInfo);
        }else{
        var provisionedPathConfig = this.getConfiguration(requestContext.get("neId"), "path", lspPathConfig["path-name"], templateMetaInfo);
        }
        logger.info("extractPathProperties: pathConfig of path: {} is {}", lspPathConfig["name"], JSON.stringify(provisionedPathConfig));
        
        if (isPrimaryPath) {
            // Add Admin-group (path-affinity-names) and HopLimit container properties
            var pathAffinityNames = this.extractAdminGroup(lspPathConfig);
            if (pathAffinityNames) {
                defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["path-affinity-names"] = pathAffinityNames;
            }

            // Add Hop-limit (path-metric-bounds) container properties
            var pathMetricBounds = this.extractPathMetricBound(lspPathConfig);
            if (pathMetricBounds) {
                defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["path-metric-bounds"] = pathMetricBounds;
            }
            logger.debug("extractPathProperties: primary -> pathAffinityNames => {}", JSON.stringify(pathAffinityNames));

            // Primary - explicit-route-objects-always
            if(templateMetaInfo["type"] === "Juniper"){
             explicitRouteObjectsAlways = this.extractJuniperExplicitRouteObjects(provisionedPathConfig);
            }else{
             explicitRouteObjectsAlways = this.extractExplicitRouteObjects(provisionedPathConfig);
            }
            if (explicitRouteObjectsAlways) {
                defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["explicit-route-objects-always"] = explicitRouteObjectsAlways;
            }
            logger.info("extractPathProperties: primary -> explicitRouteObjectsAlways => {}", JSON.stringify(explicitRouteObjectsAlways));

            // Update primary path-name in Intent
            defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["name"]
                = defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["name"].replace(lspName + "_", "");

            // Update default priorities when not configured
            this.populateDefaultPriorities(defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]);
            // Update primary path priorities to LSP global priorities
            this.populateGlobalPriorities(defaultTemplateDataMap, defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["setup-priority"],
                defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["hold-priority"]);
        } else {
            // Add Restoration property
            if (lspPathConfig["standby"]) {
                defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][pathIndex]["restoration"] = {
                    "enable": true,
                    "restoration-scheme": "restoration-scheme-presignaled"
                }
            }
            if (lspPathConfig["srlg"]) {
                defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][pathIndex]["disjointness"] = "srlg"
            }

            var pathAffinityNames = this.extractAdminGroup(lspPathConfig);
            if (pathAffinityNames) {
                defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][pathIndex]["path-affinity-names"] = pathAffinityNames;
            }
            logger.debug("extractPathProperties: secondary -> pathAffinityNames => {}", JSON.stringify(pathAffinityNames));

            // Add Hop-limit (path-metric-bounds) container properties
            var pathMetricBounds = this.extractPathMetricBound(lspPathConfig);
            if (pathMetricBounds) {
                defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][pathIndex]["path-metric-bounds"] = pathMetricBounds;
            }
            logger.debug("extractPathProperties: secondary -> pathMetricBounds => {}", JSON.stringify(pathMetricBounds));

            // Primary - explicit-route-objects-always
            if(templateMetaInfo["type"] === "Juniper"){
                explicitRouteObjectsAlways = this.extractJuniperExplicitRouteObjects(provisionedPathConfig);
                }else{
                 explicitRouteObjectsAlways = this.extractExplicitRouteObjects(provisionedPathConfig);
                }
            if (explicitRouteObjectsAlways) {
                defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][pathIndex]["explicit-route-objects-always"] = explicitRouteObjectsAlways;
            }
            logger.debug("extractPathProperties: secondary -> explicitRouteObjectsAlways => {}", JSON.stringify(explicitRouteObjectsAlways));

            // Update secondary path-name in Intent
            defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][pathIndex]["name"]
                = defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][pathIndex]["name"].replace(lspName + "_secondary_", "")

            // Update default priorities when not configured
            this.populateDefaultPriorities(defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][pathIndex]);
        }
    }

    this.extractCiscoPathProperties = function (lspPathConfig, defaultTemplateDataMap, deviceId, lspName, isPrimaryPath, pathIndex, requestContext, count, templateMetaInfo) { 
      
        var provisionedPathConfig = this.getCiscoConfiguration(requestContext.get("neId"), "path", lspPathConfig["path-name"]);
        logger.info("extractPathProperties: pathConfig of path: {} is {}", lspPathConfig["path-name"], JSON.stringify(provisionedPathConfig));
    
        if (isPrimaryPath) {
        
                //Primary - explicit-route-objects-always
                var explicitRouteObjectsAlways = this.extractCiscoExplicitRouteObjects(provisionedPathConfig);
               
                if (explicitRouteObjectsAlways) {
                    defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["explicit-route-objects-always"] = explicitRouteObjectsAlways;
                }
                logger.info("extractPathProperties: primary -> explicitRouteObjectsAlways => {}", JSON.stringify(explicitRouteObjectsAlways));

                // Update primary path-name in Intent
                defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["name"]
                    = defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["name"].replace(lspName + "_", "");

                // Update default priorities when not configured
                this.populateDefaultPriorities(defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]);
                // Update primary path priorities to LSP global priorities
                this.populateGlobalPriorities(defaultTemplateDataMap, defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["setup-priority"],
                    defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["hold-priority"]);
            

        } else {
            count++;
            // Update secondary path-name in Intent
            defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][count]["name"]
                = defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][count]["name"].replace(lspName + "_secondary_", "")
        }
    }


    //Huawei-start

    this.extractHuaweiPathProperties = function (lspPathConfig, defaultTemplateDataMap, isPrimaryPath, pathIndex, requestContext, count, templateMetaInfo, wtr) { 
      
        var provisionedPathConfig = this.getHuaweiConfiguration(requestContext.get("neId"), "path", lspPathConfig["explicit-path-name"]);
        logger.info("extractPathProperties: pathConfig of path: {} is {}", lspPathConfig["explicit-path-name"], JSON.stringify(provisionedPathConfig));
        
    
        if (isPrimaryPath) {
        
                //Primary - explicit-route-objects-always
                var explicitRouteObjectsAlways = this.extractHuaweiExplicitRouteObjects(provisionedPathConfig);
               
                if (explicitRouteObjectsAlways) {
                    
                    defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["explicit-route-objects-always"] = explicitRouteObjectsAlways;
                }
                logger.info("extractPathProperties: primary -> explicitRouteObjectsAlways => {}", JSON.stringify(explicitRouteObjectsAlways));

                // Update primary path-name in Intent
                defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["name"]
                    = defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["name"];

                // Update default priorities when not configured
                this.populateDefaultPriorities(defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]);
                // Update primary path priorities to LSP global priorities
                this.populateGlobalPriorities(defaultTemplateDataMap, defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["setup-priority"],
                    defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["hold-priority"]);
                
                var pathAffinityNames = this.getHuaweiPathAffinityNames(lspPathConfig);
                if(pathAffinityNames){
                    defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["path-affinity-names"] = pathAffinityNames;
                }
            

        } else {
          if (lspPathConfig["path-type"]=="hot-standby") {
                defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][pathIndex]["restoration"] = { 
                    "enable": true,
                    "restoration-scheme": "restoration-scheme-presignaled",
                    "wait-to-revert": wtr
                }
            }
            var explicitRouteObjectsAlways = this.extractHuaweiExplicitRouteObjects(provisionedPathConfig);
            if (explicitRouteObjectsAlways) {
                defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][0]["explicit-route-objects-always"] = explicitRouteObjectsAlways;
            }
            logger.debug("extractPathProperties: secondary -> explicitRouteObjectsAlways => {}", JSON.stringify(explicitRouteObjectsAlways));
            logger.info("extractPathProperties: primary -> explicitRouteObjectsAlways => {}", JSON.stringify(explicitRouteObjectsAlways));
            // Update secondary path-name in Intent
            defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][0]["name"]
                = defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][0]["name"];
            var pathAffinityNames = this.getHuaweiPathAffinityNames(lspPathConfig);
            if (pathAffinityNames) {
                    defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][pathIndex]["path-affinity-names"] = pathAffinityNames;
            }
        }
    }

//Huawei-end

    /**
     * Fills AdminGroup attributes for the given lspPath.
     */
    this.extractAdminGroup = function (lspPathConfig) {
        if (lspPathConfig["include-admin-group"] || lspPathConfig["exclude-admin-group"]) {
            var pathAffinityNames = {
                "path-affinity-name": []
            }
            var includePathAffinityName = {
                "usage": "resource-aff-include-any",
                "affinity-name": []
            };
            var excludePathAffinityName = {
                "usage": "resource-aff-exclude-any",
                "affinity-name": []
            };

            if (lspPathConfig["include-admin-group"]) {
                pathAffinityNames["path-affinity-name"].push(includePathAffinityName)
                lspPathConfig["include-admin-group"]["group"].forEach(function (group) {
                    includePathAffinityName["affinity-name"].push({"name": group})
                })
            }

            if (lspPathConfig["exclude-admin-group"]) {
                pathAffinityNames["path-affinity-name"].push(excludePathAffinityName)
                lspPathConfig["exclude-admin-group"]["group"].forEach(function (group) {
                    excludePathAffinityName["affinity-name"].push({"name": group})
                })
            }
            return pathAffinityNames;
        }
        return null;
    }

    this.extractCiscoAdminGroup = function (lspPathConfig) {
        if (lspPathConfig.length !== 0) {
            var pathAffinityNames = {
                "path-affinity-name": []
            };
            var groupedNames = {}; // Object to store names grouped by usage
    
            for (var index = 0; index < lspPathConfig.length; index++) {
                var name = lspPathConfig[index]["path-option-attribute-set-name"];
                var preferenceLevel = lspPathConfig[index]["preference-level"];
                var usage = (preferenceLevel == 4 || preferenceLevel == 5) ? "resource-aff-exclude-any" : "resource-aff-include-any";
    
                // If the usage does not exist in groupedNames, initialize it
                if (!groupedNames[usage]) {
                    groupedNames[usage] = {
                        "usage": usage,
                        "affinity-name": []
                    };
                }
    
                // Push the name into the appropriate usage group
                groupedNames[usage]["affinity-name"].push({ "name": name });
            }
    
            // Convert the groupedNames object into the desired output format
            for (var key in groupedNames) {
                pathAffinityNames["path-affinity-name"].push(groupedNames[key]);
            }
            return pathAffinityNames;
        }
    
        return null;
    }

    this.extractPathMetricBound = function (lspPathConfig) {
        if (lspPathConfig["hop-limit"]) {
            return {
                "path-metric-bound": [
                    {
                        "metric-type": "path-metric-hop",
                        "upper-bound": lspPathConfig["hop-limit"]
                    }
                ]
            }
        }
        return null;
    }

    this.extractExplicitRouteObjects = function (provisionedPathConfig) {
        if (provisionedPathConfig[0]["hop"]) {
            var explicitRouteObjectsAlways = {
                "route-object-include-exclude": []
            }
            provisionedPathConfig[0]["hop"].forEach(function (numberedNodeHop) {
                var routeIExcludeObject = {
                    "index": numberedNodeHop["hop-index"],
                    "explicit-route-usage": "route-include-object",
                    "numbered-node-hop": {
                        "node-id": numberedNodeHop["ip-address"],
                        "hop-type": numberedNodeHop["type"]
                    }
                }
                explicitRouteObjectsAlways["route-object-include-exclude"].push(routeIExcludeObject);
            })
            return explicitRouteObjectsAlways;
        }
        return null;
    }

    this.extractJuniperExplicitRouteObjects = function (provisionedPathConfig) {
        var provisionedPathConfig = JSON.parse(provisionedPathConfig);
        if (provisionedPathConfig[0]["path-list"]) {
            var explicitRouteObjectsAlways = {
                "route-object-include-exclude": []
            }
            provisionedPathConfig[0]["path-list"].forEach(function (numberedNodeHop) {
                var randomNumber = Math.floor(Math.random() * 100);
                var routeIExcludeObject = {
                    "index": randomNumber.toString(),
                    "explicit-route-usage": "route-include-object",
                    "numbered-node-hop": {
                        "node-id": numberedNodeHop["name"],
                        "hop-type":"strict"
                    }
                }
                explicitRouteObjectsAlways["route-object-include-exclude"].push(routeIExcludeObject);
            })
            return explicitRouteObjectsAlways;
        }
        return null;
    }

    /***cisco start */
    this.extractCiscoExplicitRouteObjects = function (provisionedPathConfig) {
       
        var hops = provisionedPathConfig[0];
        var hops1 = hops["hops"];
        if (hops1 != undefined && hops1["hop"]) {
           
            var explicitRouteObjectsAlways = {
                "route-object-include-exclude": []
            }
            hops1["hop"].forEach(function (numberedNodeHop) {
                var hopType = numberedNodeHop["hop-type"];
                var hopType1 = hopType.replace(/^next-/, '');
                var routeIExcludeObject = {
                    "index": numberedNodeHop["index-number"],
                    "explicit-route-usage": "route-include-object",
                    "numbered-node-hop": {
                        "node-id": numberedNodeHop["ip-address"],
                        "hop-type": hopType1
                    }
                }
                explicitRouteObjectsAlways["route-object-include-exclude"].push(routeIExcludeObject);
            })
            return explicitRouteObjectsAlways;
        }
        return null;
    }
    /**cisco end */


    //huawei-starts
    this.extractHuaweiExplicitRouteObjects = function (provisionedPathConfig) {
       
        var hops = provisionedPathConfig[0];
        var hops1 = hops["hops"];
        if (hops1 != undefined && hops1["hop"]) {
           
            var explicitRouteObjectsAlways = {
                "route-object-include-exclude": []
            }
            hops1["hop"].forEach(function (numberedNodeHop) {
                var hopType = numberedNodeHop["er-hop-type"];
                var hopType1 = hopType.replace(/^include-/, '');
                var routeIExcludeObject = {
                    "index": numberedNodeHop["index"],
                    "explicit-route-usage": "route-include-object",
                    "numbered-node-hop": {
                        "node-id": numberedNodeHop["address"],
                        "hop-type": hopType1
                    }
                }
                explicitRouteObjectsAlways["route-object-include-exclude"].push(routeIExcludeObject);
            })
            return explicitRouteObjectsAlways;
        }
        return null;
    }
    //huawei end

    this.extractProperties = function (targetData, deviceConfig, mappings, templateMetaInfo) {
        var keys = Object.keys(targetData);
        for (var i = 0; i < keys.length; i++) {
            var targetKey = keys[i];
            var targetObj = targetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object') {
                this.traverseAndUpdateConfig(targetKey, targetObj, mappings[targetKey], deviceConfig,templateMetaInfo);
            } else {
                this.getAndUpdateFromDeviceConfig(mappings, targetKey, targetData, deviceConfig, templateMetaInfo);
            }
        }
        logger.info("extractProperties: returning, targetData = {}", JSON.stringify(targetData))
    }

    /**
     * Constructs and returns the distinct mapping of Tunnel containers
     */
    this.prepareDefaultTemplateDataMap = function (defaultTargetData) {
        var associationDefaultTemplate;
        if (defaultTargetData["association-objects"] && defaultTargetData["association-objects"]["association-object-extended"])
        {
            associationDefaultTemplate = JSON.parse(JSON.stringify(defaultTargetData["association-objects"]["association-object-extended"]));
        }
        else {
            associationDefaultTemplate = [
                {
                    "association-key": "path-profile,profile-id",
                    "type": null,
                    "id": "path-profile,profile-id",
                    "source": {
                        "id": "to",
                        "type": null
                    },
                    "global-source": null,
                    "extended-id": "path-profile,path-group"
                }
            ]
        }

        delete defaultTargetData["primary-paths"]["primary-path"][0]["path-metric-bound"]
        delete defaultTargetData["secondary-paths"]["secondary-path"][0]["path-metric-bound"]

        delete defaultTargetData["primary-paths"]["primary-path"][0]["path-affinity-name"]
        delete defaultTargetData["secondary-paths"]["secondary-path"][0]["path-affinity-name"]

        delete defaultTargetData["primary-paths"]["primary-path"][0]["route-object-include-exclude"]
        delete defaultTargetData["secondary-paths"]["secondary-path"][0]["route-object-include-exclude"]

        delete defaultTargetData["association-objects"];

        var primaryPathTemplate = JSON.parse(JSON.stringify(defaultTargetData["primary-paths"]["primary-path"]))
        var secondaryPathTemplate = JSON.parse(JSON.stringify(defaultTargetData["secondary-paths"]["secondary-path"]))
        delete defaultTargetData["primary-paths"];
        delete defaultTargetData["secondary-paths"];

        var defaultTemplateMap = {
            "primary-paths": primaryPathTemplate,
            "secondary-paths": secondaryPathTemplate,
            "association-object-extended": associationDefaultTemplate,
            "default-target-data": defaultTargetData
        }
        logger.debug("prepareDefaultTemplateDataMap: response = {}", JSON.stringify(defaultTemplateMap));
        return defaultTemplateMap;
    }

    /**
     * Extracts association-objects
     */
    this.extractContainerProperties = function (inputTargetData, inputDeviceConfig, mappings, templateMetaInfo) {
        //inputDeviceConfig = [inputDeviceConfig];
        logger.info("extractContainerProperties: inputTargetData = {}, \ninputDeviceConfig = {}, \nmappings = {}\n",
            JSON.stringify(inputTargetData), JSON.stringify(inputDeviceConfig), JSON.stringify(mappings));
        var resultArray = [];
        var targetData = inputTargetData[0];

        for (var i = 0; i < inputDeviceConfig.length; i++) {
            var deviceConfig = inputDeviceConfig[i];
            var keys = Object.keys(targetData);
            logger.info("extractContainerProperties: keys = {}", JSON.stringify(keys));
            for (var j = 0; j < keys.length; j++) {
                var targetKey = keys[j];
                var targetObj = targetData[targetKey];
                var mappedKey = targetKey;
                logger.info("extractContainerProperties: --> targetKey = {}, mappedKey = {}", JSON.stringify(targetKey), mappedKey);

                if (targetObj !== null && typeof targetObj === 'object') {
                    var tempMappings = mappings[targetKey];
                    this.traverseAndUpdateConfig(mappedKey, targetObj, tempMappings, deviceConfig, templateMetaInfo);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetData, deviceConfig, templateMetaInfo);
                }
            }
            resultArray.push(JSON.parse(JSON.stringify(targetData)));
        }
        return resultArray;
    }

    this.traverseAndUpdateConfig = function (objKey, obj, mappings, deviceConfig, templateMetaInfo) {
        var keys = Object.keys(obj);
        for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            var value = obj[key];
            var mappedKey = objKey + "." + key;
            logger.info("traverseAndUpdateConfig: key = {}, mappedKey = {}, value = {}", key, mappedKey, JSON.stringify(value))
            if (value !== null && typeof value === 'object') {
                var tempMappings = mappings[key];
                this.traverseAndUpdateConfig(mappedKey, value, tempMappings, deviceConfig, templateMetaInfo);
            } else {
                // call for each key with string value
                this.getAndUpdateFromDeviceConfig(mappings, key, obj, deviceConfig, templateMetaInfo);
            }
        }
        return obj;
    }

    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetObj, deviceConfig, templateMetaInfo) {
        var nfmpMappedKey = mappings[mappedKey];
        logger.debug("getAndUpdateFromDeviceConfig: mappedKey = {}, \ntargetObj = {}, \nnfmpMappedKey = {}, \nmappings = {}, \ntemplateMetaInfo = {}",
            mappedKey, JSON.stringify(targetObj), JSON.stringify(nfmpMappedKey), JSON.stringify(mappings), JSON.stringify(templateMetaInfo));
        var deviceValue;
        var tempDeviceConfig = deviceConfig;
        var nfmpKey = !nfmpMappedKey ? null : nfmpMappedKey.toString().split(",");

        logger.debug("getAndUpdateFromDeviceConfig: nfmpKey = {}, \ntempDeviceConfig = {}", JSON.stringify(nfmpKey), JSON.stringify(tempDeviceConfig));
        for (var i = 0; nfmpKey !== null && i < nfmpKey.length; i++) {
            deviceValue = tempDeviceConfig[nfmpKey[i]];
            // Check and update tempDeviceConfig
            if (deviceValue) {
                tempDeviceConfig = deviceValue;
            }
            if (templateMetaInfo !== undefined){
                  if(deviceConfig["tunnel-te-attributes"]!= undefined){
                  var pathOptionProtect = deviceConfig["tunnel-te-attributes"]["path-option-protects"]["path-option-protect"];
                  var pathOption = pathOptionProtect[0]["path-options"]["path-option"];
                  var segment = pathOption[0]["segment-routing"];
                  }
              if ( templateMetaInfo["type"] === "Cisco" || templateMetaInfo["type"] === "CiscoR-IOSXRV9000-CC"|| templateMetaInfo["type"] === "ATN 910C-G" || (templateMetaInfo["type"] === "ATN 950D") || templateMetaInfo["type"] === "NetEngine 8000"){
                var jsonString = JSON.stringify(templateMetaInfo);
                var obj = JSON.parse(jsonString);
                var neId = obj.baseUrl.match(/node=([\d.]+)/)[1];
                if (nfmpKey[i] == "source") {
                  deviceValue = neId;
              } if (nfmpKey[i] == "segment-routing") {
                deviceValue = segment;
            }

          }
      }
            logger.debug("getAndUpdateFromDeviceConfig: nfmpKey[{}] = {}, deviceValue = {}", i, JSON.stringify(nfmpKey[i]), JSON.stringify(deviceValue));
        }
        targetObj[mappedKey] = this.transformDeviceValue(mappedKey, deviceValue, templateMetaInfo);
    }

    this.transformDeviceValue = function (mappedKey, deviceValue, templateMetaInfo) {
        if (deviceValue) {
            switch (mappedKey) {
                case "admin-state":
                    if (templateMetaInfo !== undefined && (templateMetaInfo["type"] === "Cisco" || (templateMetaInfo["type"] === "CiscoR-IOSXRV9000-CC"))){
                    deviceValue = this.convertCiscoAdminStateBrownField(deviceValue);
                    }else if( templateMetaInfo !== undefined && (templateMetaInfo["type"] === "Juniper")){
                        deviceValue = this.convertJunoAdminStateBrownField(deviceValue);
                    }else if( templateMetaInfo !== undefined && (templateMetaInfo["type"] === "ATN 910C-G" ||templateMetaInfo["type"] === "ATN 950D" || templateMetaInfo["type"] ==="NetEngine 8000" )){
                        deviceValue = this.convertHuaweiAdminStateBrownField(deviceValue);
                    }
                else{
                        deviceValue = this.convertAdminStateBrownField(deviceValue);
                    }
                    break;
                case "signaling-type":
                    if (templateMetaInfo !== undefined &&(templateMetaInfo["type"] === "Cisco" || templateMetaInfo["type"] === "CiscoR-IOSXRV9000-CC")){
                        deviceValue = this.convertCiscoSignallingTypeBrownField(deviceValue);
                    }else{
                    deviceValue = this.convertSignallingTypeBrownField(deviceValue);
                    }
                    break;
                case "color":
                    deviceValue = this.convertColorBrownField(deviceValue);
                    break;
                case "path-computation-method":   
                    if(templateMetaInfo !== undefined && (templateMetaInfo["type"] === "Cisco" || templateMetaInfo["type"] === "CiscoR-IOSXRV9000-CC")){
                        deviceValue = this.convertPathCiscoComputationMethodBrownField(deviceValue);
                    
                    }else{
                    deviceValue = this.convertPathComputationMethodBrownField(deviceValue);
                        }
                    break;
                case "protection-type":
                    deviceValue = this.convertProtectionTypeBrownField(deviceValue);
                    break;
                case "generic":
                     if(templateMetaInfo !== undefined && (templateMetaInfo["type"] === "Juniper")){
                     deviceValue = (deviceValue);
                     }else if (templateMetaInfo !== undefined && (templateMetaInfo["type"] === "ATN 910C-G" || templateMetaInfo["type"] === "ATN 950D" || templateMetaInfo["type"] === "NetEngine 8000" ||templateMetaInfo["type"] === "Cisco" || templateMetaInfo["type"] === "CiscoR-IOSXRV9000-CC" )){
                        deviceValue = (deviceValue *= 1000).toString(); 
                     }
                     else{
                        deviceValue = (deviceValue *= 1000000).toString(); 
                     }
                    break;
                case "extended-id":
                    deviceValue = this.convertExtendedIdBrownField(deviceValue);
                    break;
            }
            return deviceValue;
        }
    }

    this.convertAdminStateBrownField = function (adminState) {
        switch (adminState) {
            case "enable":
                return "tunnel-admin-state-up";
            case "disabled":
                return "tunnel-admin-state-down";
            default:
                return "tunnel-admin-state-down";
        }
    }
    this.convertCiscoAdminStateBrownField = function (adminState) {
        switch (adminState) {
            case " ":
                return "tunnel-admin-state-up";
            case "null":
                return "tunnel-admin-state-down";
            default:
                return "tunnel-admin-state-down";
        }

    }
  this.convertHuaweiAdminStateBrownField = function (adminState) {
        switch (adminState) {
            case "up":
                return "tunnel-admin-state-up";
            case "down":
                return "tunnel-admin-state-down";
            default:
                return "tunnel-admin-state-down";
        }
    }
    this.convertJunoAdminStateBrownField = function (adminState) {
        switch (adminState) {
            case " ":
                return "tunnel-admin-state-up";
            case "null":
                return "tunnel-admin-state-down";
            default:
                return "tunnel-admin-state-down";
        }

    }

    this.convertProtectionTypeBrownField = function (protectionType) {
        if (protectionType == "oneToOne") {
            return "lsp-protection-1-for-1";
        } else if (protectionType == "manyToOne") {
            return "lsp-protection-1-for-n";
        }
    }

    this.convertSignallingTypeBrownField = function (signallingType) {
        if (signallingType == "p2p-rsvp") {
            return "path-setup-rsvp";
        } else if (signallingType == "p2p-sr-te") {
            return "path-setup-sr"
        }
    }

   this.convertCiscoSignallingTypeBrownField = function (signallingType) {
        if (signallingType == "segment-routing") {
            return "path-setup-sr"
            
        } else {
            return "path-setup-rsvp"; 
        }
    }

    this.convertPathComputationMethodBrownField = function (pathComputationMethod) {
        if (pathComputationMethod == "pce") {
            return "path-locally-computed";
        } else if (pathComputationMethod == "localCspf") {
            return "path-externally-queried";
        } else if (pathComputationMethod == "none") {
            return null;
        }
    }

    this.convertPathCiscoComputationMethodBrownField = function (pathComputationMethod) {
        if (pathComputationMethod == " ") {
            return "path-locally-computed";
        } else if (pathComputationMethod == "none") {
            return null;
        }
    }

    this.convertColorBrownField = function (color) {
        for (var colorValue in colorAdminTagMapping) {
            if (colorAdminTagMapping[colorValue] == color)
                return colorValue;
        }
    }

    /**
     * Converts Decimal to HexString
     * @param protectionType
     * @returns {number}
     */
    this.convertExtendedIdBrownField = function (extendedId) {
        extendedId = extendedId.toString(16);
        if(extendedId.length == 1) {
            extendedId = "0" + extendedId;
        }
        return extendedId;
    }

    this.clearEmpties = function (o) {
        for (var k in o) {
            if (!o[k] || typeof o[k] !== "object") {
                continue
            }
            this.clearEmpties(o[k]);
            if (Object.keys(o[k]).length === 0) {
                delete o[k];
            }
        }
    }
    this.getDeviceTemplate = function (neId, requestContext) {
        try {
            var ret = null;
            var lSourceNodeId = requestContext.get("neId");
            var templateMappings = utilityService.processTemplate(resourceProvider.getResource("mdm-template-mapping.json"),
                { deviceName: lSourceNodeId, name: requestContext.get("target") });
            logger.info("[ietf-mdm-instance][getDeviceTemplate] templateMappings {}", JSON.stringify(templateMappings));
            var json = JSON.parse(templateMappings);
            var mediatorDeviceInfo = this.ietfUtil.getDeviceInfo(lSourceNodeId);
            logger.info("[ietf-mdm-instance][getDeviceTemplate] mediatorDeviceInfo {}", JSON.stringify(mediatorDeviceInfo));

            json.forEach(function (element) {
                if (mediatorDeviceInfo.type.indexOf(element.type) !== -1 && mediatorDeviceInfo.type.indexOf(element.version) !== -1) {
                    ret = element;
                } else if (mediatorDeviceInfo.type.indexOf(element.type) !== -1 && (element.version === undefined || element.version === null)) {
                    ret = element;
                }
            });
            return ret;
        } catch (e) {
            throw new RuntimeException('Matching device not found for ' + neId + " " + e);
        }
    };

    this.getHuaweiPathAffinityNames = function (lspPathConfig) {
        if (lspPathConfig["include-any-affinity-name"] || lspPathConfig["exclude-affinity-name"]) {
            var pathAffinityNames = {
                "path-affinity-name": []
            }
            var includePathAffinityName = {
                "usage": "resource-aff-include-any",
                "affinity-name": []
            };
            var excludePathAffinityName = {
                "usage": "resource-aff-exclude-any",
                "affinity-name": []
            };

            if (lspPathConfig["include-any-affinity-name"]) {
                pathAffinityNames["path-affinity-name"].push(includePathAffinityName)
                lspPathConfig["include-any-affinity-name"].forEach(function (name) {
                    includePathAffinityName["affinity-name"].push({"name": name})
                })
            }

            if (lspPathConfig["exclude-affinity-name"]) {
                pathAffinityNames["path-affinity-name"].push(excludePathAffinityName)
                lspPathConfig["exclude-affinity-name"].forEach(function (name) {
                    excludePathAffinityName["affinity-name"].push({"name": name})
                })
            }
            return pathAffinityNames;
        }
        return null;
    }
}
