load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {
    this.setErrorResult = function (result) {
        result.setSuccess(false);
        result.setErrorCode(100);
        result.setErrorDetail("failed To set Topology.");
        return result
    }

    this.setSuccessResult = function (result,savedTopology) {
        result.setSuccess(true);
        if (savedTopology !== undefined){
            result.setTopology(savedTopology);
        }
        return result;
    }


    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        return JSON.parse(json);
    }



    this.reportMisaligned = function (target, result, auditReport) {
        var report = JSON.parse(result.response);
        if (!report.aligned)
        {
            for (var i = 0; i < report.misalignedAttributes.length; i++)
            {
                var attributeData = report.misalignedAttributes[i];

                if((attributeData.name).indexOf("significantIngressQueueCounter") > -1 ||
                  (attributeData.name).indexOf("significantEgressQueueCounter") > -1 ||
                  (attributeData.name).indexOf("significantIngressPolicerCounter") > -1 ||
                  (attributeData.name).indexOf("significantEgressPolicerCounter") > -1 ||
                  (attributeData.name).indexOf("ingressCounter") > -1 ||
                  (attributeData.name).indexOf("egressCounter") > -1 ||
                  (attributeData.name).indexOf("applicationAssuranceCounter") > -1 ||
                  (attributeData.name).indexOf("fromSubCounter") > -1 ||
                  (attributeData.name).indexOf("optionalAttributes") > -1 ||
                  (attributeData.name).indexOf("toSubCounter") > -1 )
                {
                    if(this.arraysAreEqual(attributeData.expected, attributeData.actual))
                    {
                      continue;
                    }
                }

                if (attributeData.expected == "present")
                {
                    //misaligned object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else if (attributeData.expected == "not present")
                {
                    //undesired object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                    auditReport.addMisAlignedAttribute(misalignedAttribute);
                }

            }
        }
        return auditReport
    }

    this.editPayload = function (fdn, properties, childProperties, fullClassName, objectFullName) {
        var payload = {};
        var configInfo = {};
        configInfo[fullClassName] = properties;
        configInfo[fullClassName]["children-Set"] = childProperties;
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName;
        payload["clearOnDeployFailure"] = true;
        payload["configInfo"] = configInfo;
        return payload;
    }

    this.getAccountingPolicyId = function(target){
        var uniqueIdentifier = target.split("#")[2];
        return uniqueIdentifier;
    }

    /*
     function: getIfObjectExists
     description: returns the object for objectFullName if exists.
     */
    this.getIfObjectExists = function(className, objectFullName){
        let nfmpFwk = new NfmpFwk();
        var expectedJson = {
            "fullClassName": className,
            "filter": {
                "equal":
                {
                  "name":"objectFullName",
                  "value": objectFullName
                }
            }
        };
        var ret = false;
        var resultFetch = nfmpFwk.post("/v3/search", expectedJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("Response = {}",JSON.stringify(finalResponse));
        if (JSON.stringify(finalResponse) === JSON.stringify({})) {
          finalResponse = null;
        }
        else if (!Array.isArray(finalResponse)) {
          finalResponse = [finalResponse[className]];
        }
        return finalResponse;
    }

    this.isObjectExists = function (className, objectFullName) {
        let nfmpFwk = new NfmpFwk();
        var ret = false;
        var searchObjectJson = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);

        logger.info("isObjectExists data = {}", JSON.stringify(resultFetch));
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("Final response of search = {}", JSON.stringify(finalResponse));
        if (Object.keys(finalResponse).length !== 0 && finalResponse.constructor === Object)
        {
            ret = true;
        }
        logger.info("isObjectExists = {} ", ret);
        return ret;
    }

    this.transformNfmpAdminState = function(adminState){
        var nfmpAdminState;
        if(adminState == "enable"){
            nfmpAdminState = "up";
        }else{
            nfmpAdminState = "Down";
        }
        return nfmpAdminState;
    }

    this.transformToIntentAdminState = function (deviceValue){
        var intentAdmintState;
        if(deviceValue == "up"){
            intentAdmintState = "enable";
        }else{
            intentAdmintState = "disable";
        }
        return intentAdmintState;
    }

    this.transformNfmpCFLocation = function(cfLocation){
        var drive;
        if(cfLocation == "cf1"){
            drive = "cf1";
        }else if (cfLocation == "cf2"){
            drive = "cf1A";
        }
        else if (cfLocation == "cf3"){
            drive = "cf1B";
        }else if (cfLocation == "uf1"){
            drive = "uf1";
        }else{
            drive = "default";
        }
        return drive;
    }

    this.transformToIntentPrimary = function(deviceValue){
        var intentPrimary;
        if(deviceValue == "cf1"){
            intentPrimary = "cf1";
        }else if (deviceValue == "cf1A"){
            intentPrimary = "cf2";
        }
        else if (deviceValue == "cf1B"){
            intentPrimary = "cf3";
        }
        else if (deviceValue == "uf1"){
            intentPrimary = "uf1";
        }
        else{
            intentPrimary = "cf-unspecified";
        }
        return intentPrimary;
    }

    this.transformNfmpRecordType = function(record){
        var recordType;
        switch(record){
            case 'service-ingress-octets' : recordType = 'svcIngressOctet';
                break;
            case 'service-egress-octets' : recordType = 'svcEgressOctet';
                break;
            case 'service-ingress-packets' : recordType = 'svcIngressPkt';
                break;
            case 'service-egress-packets' : recordType = 'svcEgressPkt';
                break;
            case 'network-ingress-octets' : recordType = 'netIngressOctet';
                break;
            case 'network-egress-octets' : recordType = 'netEgressOctet';
                break;
            case 'network-ingress-packets' : recordType = 'netIngressPkt';
                break;
            case 'network-egress-packets' : recordType = 'netEgressPkt';
                break;
            case 'compact-service-ingress-octets' : recordType = 'compactSvcInOctet';
                break;
            case 'combined-service-ingress' : recordType = 'combinedSvcIngress';
                break;
            case 'combined-network-ing-egr-octets' : recordType = 'combinedNetInEgOctet';
                break;
            case 'combined-service-ing-egr-octets' : recordType = 'combinedSvcInEgOctet';
                break;
            case 'complete-service-ingress-egress' : recordType = 'completeSvcInEg';
                break;
            case 'combined-sdp-ingress-egress' : recordType = 'combinedSvcSdpInEg';
                break;
            case 'complete-sdp-ingress-egress' : recordType = 'completeSvcSdpInEg';
                break;
            case 'complete-subscriber-ingress-egress' : recordType = 'completeSubsInEg';
                break;
            case 'aa-protocol' : recordType = 'aaProtocol';
                break;
            case 'aa-application' : recordType = 'aaApplication';
                break;
            case 'aa-app-group' : recordType = 'aaAppGroup';
                break;
            case 'aa-subscriber-protocol' : recordType = 'aaSubProtocol';
                break;
            case 'aa-subscriber-application' : recordType = 'aaSubApp';
                break;
            case 'custom-record-subscriber' : recordType = 'customRecordSubscriber';
                break;
            case 'custom-record-service' : recordType = 'customRecordService';
                break;
            case 'custom-record-aa-sub' : recordType = 'customRecordAaSub';
                break;
            case 'queue-group-octets' : recordType = 'queueGroupOctets';
                break;
            case 'queue-group-packets' : recordType = 'queueGroupPackets';
                break;
            case 'combined-queue-group' : recordType = 'combinedQueueGroup';
                break;
            case 'combined-mpls-lsp-ingress' : recordType = 'combinedMplsLspIngress';
                break;
            case 'combined-mpls-lsp-egress' : recordType = 'combinedMplsLspEgress';
                break;
            case 'combined-ldp-lsp-egress' : recordType = 'combinedLdpLspEgress';
                break;
            case 'saa' : recordType = 'saa';
                break;
            case 'video' : recordType = 'video';
                break;
            case 'combinedSvcInEgPkt' : recordType = 'combinedSvcInEgPkt';
                break;
            case 'combinedNetInEgPkt' : recordType = 'combinedNetInEgPkt';
                break;
            case 'aa-performance' : recordType = 'aaPerformance';
                break;
            case 'complete-ethernet-port' : recordType = 'completeEthernetPort';
                break;
            case 'extended-service-ingress-egress' : recordType = 'extendedSvcIngrEgr';
                break;
            case 'complete-network-ing-egr' : recordType = 'completeNetIngrEgr';
                break;
            case 'aa-partition' : recordType = 'aaPartition';
                break;
            case 'complete-pm' : recordType = 'completePm';
                break;
            case 'aa-admit-deny' : recordType = 'aaAdmitDeny';
                break;
            case 'network-interface-ingress-octets' : recordType = 'netInfIngressOctet';
                break;
            case 'network-interface-egress-octets' : recordType = 'netInfEgressOctet';
                break;
            case 'network-interface-ingress-packets' : recordType = 'netInfIngressPkt';
                break;
            case 'network-interface-egress-packets' : recordType = 'netInfEgressPkt';
                break;
            case 'combined-network-interface-ingress' : recordType = 'combinedNetInfIngress';
                break;
            case 'combined-network-interface-egress' : recordType = 'combinedNetInfEgress';
                break;
            case 'complete-network-interface-ing-egr' : recordType = 'completeNetInfIngrEgr';
                break;
            case 'access-egress-octets' : recordType = 'accessEgressOctet';
                break;
            case 'access-egress-packets' : recordType = 'accessEgressPkt';
                break;
            case 'combined-access-egress' : recordType = 'combinedAccessEgress';
                break;
            case 'combined-network-egress' : recordType = 'combinedNetEgress';
                break;
            case 'combined-mpls-srte-egress' : recordType = 'combinedMplsSrteEgress';
                break;
            case 'combined-sr-policy-egress' : recordType = 'combinedSrPolicyEgress';
                break;
            case 'serviceTestHead' : recordType = 'serviceTestHead';
                break;
            case 'natBindingPortBlock' : recordType = 'natBindingPortBlock';
                break;
            case 'accessIngressPkt' : recordType = 'accessIngressPkt';
                break;
            case 'accessIngressOct' : recordType = 'accessIngressOct';
                break;
            case 'combinedAccessIngress' : recordType = 'combinedAccessIngress';
                break;
            case 'completeAccessIngressEgress' : recordType = 'completeAccessIngressEgress';
                break;
            default : recordType = 'none';
                break;
        }
        return recordType;
    }

    this.transformToIntentRecord = function(deviceValue){
        var intentRecord;
        switch(deviceValue){
            case 'svcIngressOctet' : intentRecord = 'service-ingress-octets';
                break;
            case 'svcEgressOctet' : intentRecord = 'service-egress-octets';
                break;
            case 'svcIngressPkt' : intentRecord = 'service-ingress-packets';
                break;
            case 'svcEgressPkt' : intentRecord = 'service-egress-packets';
                break;
            case 'netIngressOctet' : intentRecord = 'network-ingress-octets';
                break;
            case 'netEgressOctet' : intentRecord = 'network-egress-octets';
                break;
            case 'netIngressPkt' : intentRecord = 'network-ingress-packets';
                break;
            case 'netEgressPkt' : intentRecord = 'network-egress-packets';
                break;
            case 'compactSvcInOctet' : intentRecord = 'compact-service-ingress-octets';
                break;
            case 'combinedSvcIngress' : intentRecord = 'combined-service-ingress';
                break;
            case 'combinedNetInEgOctet' : intentRecord = 'combined-network-ing-egr-octets';
                break;
            case 'combinedSvcInEgOctet' : intentRecord = 'combined-service-ing-egr-octets';
                break;
            case 'completeSvcInEg' : intentRecord = 'complete-service-ingress-egress';
                break;
            case 'combinedSvcSdpInEg' : intentRecord = 'combined-sdp-ingress-egress';
                break;
            case 'completeSvcSdpInEg' : intentRecord = 'complete-sdp-ingress-egress';
                break;
            case 'completeSubsInEg' : intentRecord = 'complete-subscriber-ingress-egress';
                break;
            case 'aaProtocol' : intentRecord = 'aa-protocol';
                break;
            case 'aaApplication' : intentRecord = 'aa-application';
                break;
            case 'aaAppGroup' : intentRecord = 'aa-app-group';
                break;
            case 'aaSubProtocol' : intentRecord = 'aa-subscriber-protocol';
                break;
            case 'aaSubApp' : intentRecord = 'aa-subscriber-application';
                break;
            case 'customRecordSubscriber' : intentRecord = 'custom-record-subscriber';
                break;
            case 'customRecordService' : intentRecord = 'custom-record-service';
                break;
            case 'customRecordAaSub' : intentRecord = 'custom-record-aa-sub';
                break;
            case 'queueGroupOctets' : intentRecord = 'queue-group-octets';
                break;
            case 'queueGroupPackets' : intentRecord = 'queue-group-packets';
                break;
            case 'combinedQueueGroup' : intentRecord = 'combined-queue-group';
                break;
            case 'combinedMplsLspIngress' : intentRecord = 'combined-mpls-lsp-ingress';
                break;
            case 'combinedMplsLspEgress' : intentRecord = 'combined-mpls-lsp-egress';
                break;
            case 'combinedLdpLspEgress' : intentRecord = 'combined-ldp-lsp-egress';
                break;
            case 'saa' : intentRecord = 'saa';
                break;
            case 'video' : intentRecord = 'video';
                break;
            case 'combinedSvcInEgPkt' : intentRecord = 'combinedSvcInEgPkt';
                break;
            case 'combinedNetInEgPkt' : intentRecord = 'combinedNetInEgPkt';
                break;
            case 'aaPerformance' : intentRecord = 'aa-performance';
                break;
            case 'completeEthernetPort' : intentRecord = 'complete-ethernet-port';
                break;
            case 'extendedSvcIngrEgr' : intentRecord = 'extended-service-ingress-egress';
                break;
            case 'completeNetIngrEgr' : intentRecord = 'complete-network-ing-egr';
                break;
            case 'aaPartition' : intentRecord = 'aa-partition';
                break;
            case 'completePm' : intentRecord = 'complete-pm';
                break;
            case 'aaAdmitDeny' : intentRecord = 'aa-admit-deny';
                break;
            case 'netInfIngressOctet' : intentRecord = 'network-interface-ingress-octets';
                break;
            case 'netInfEgressOctet' : intentRecord = 'network-interface-egress-octets';
                break;
            case 'netInfIngressPkt' : intentRecord = 'network-interface-ingress-packets';
                break;
            case 'netInfEgressPkt' : intentRecord = 'network-interface-egress-packets';
                break;
            case 'combinedNetInfIngress' : intentRecord = 'combined-network-interface-ingress';
                break;
            case 'combinedNetInfEgress' : intentRecord = 'combined-network-interface-egress';
                break;
            case 'completeNetInfIngrEgr' : intentRecord = 'complete-network-interface-ing-egr';
                break;
            case 'accessEgressOctet' : intentRecord = 'access-egress-octets';
                break;
            case 'accessEgressPkt' : intentRecord = 'access-egress-packets';
                break;
            case 'combinedAccessEgress' : intentRecord = 'combined-access-egress';
                break;
            case 'combinedNetEgress' : intentRecord = 'combined-network-egress';
                break;
            case 'combinedMplsSrteEgress' : intentRecord = 'combined-mpls-srte-egress';
                break;
            case 'combinedSrPolicyEgress' : intentRecord = 'combined-sr-policy-egress';
                break;
            case 'serviceTestHead' : intentRecord = 'serviceTestHead';
                break;
            case 'natBindingPortBlock' : intentRecord = 'natBindingPortBlock';
                break;
            case 'accessIngressPkt' : intentRecord = 'accessIngressPkt';
                break;
            case 'accessIngressOct' : intentRecord = 'accessIngressOct';
                break;
            case 'combinedAccessIngress' : intentRecord = 'combinedAccessIngress';
                break;
            case 'completeAccessIngressEgress' : intentRecord = 'completeAccessIngressEgress';
                break;
            default : intentRecord = 'none';
                break;
        }
        return intentRecord;
    }

    this.transformNfmpQueueIngressCounter = function(ingressCounter){
        var iCounter = [];
        if(ingressCounter["low-octets-offered-count"]){
        	iCounter.push("loo");
        }
        if(ingressCounter["low-packets-offered-count"]){
        	iCounter.push("lpo");
        }
        if(ingressCounter["high-octets-discarded-count"]){
        	iCounter.push("hod");
        }
        if(ingressCounter["all-packets-offered-count"]){
        	iCounter.push("apo");
        }
        if(ingressCounter["low-packets-discarded-count"]){
        	iCounter.push("lpd");
        }
        if(ingressCounter["all-octets-offered-count"]){
        	iCounter.push("aoo");
        }
        if(ingressCounter["high-packets-discarded-count"]){
        	iCounter.push("hpd");
        }
        if(ingressCounter["uncoloured-octets-offered-count"]){
        	iCounter.push("uco");
        }
        if(ingressCounter["out-profile-packets-forwarded-count"]){
        	iCounter.push("opf");
        }
        if(ingressCounter["in-profile-octets-forwarded-count"]){
        	iCounter.push("iof");
        }
        if(ingressCounter["low-octets-discarded-count"]){
        	iCounter.push("lod");
        }
        if(ingressCounter["high-packets-offered-count"]){
        	iCounter.push("hpo");
        }
        if(ingressCounter["high-octets-offered-count"]){
        	iCounter.push("hoo");
        }
        if(ingressCounter["in-profile-packets-forwarded-count"]){
        	iCounter.push("ipf");
        }
        if(ingressCounter["out-profile-octets-forwarded-count"]){
        	iCounter.push("oof");
        }
        if(ingressCounter["uncoloured-packets-offered-count"]){
        	iCounter.push("ucp");
        }
        return iCounter;
    }

    this.transformNfmpQueueEgressCounter = function(egressCounter){
        var eCounter = [];
        if(egressCounter["in-profile-octets-forwarded-count"]){
        	eCounter.push("iof");
        }
        if(egressCounter["in-profile-octets-discarded-count"]){
        	eCounter.push("lod");
        }
        if(egressCounter["out-profile-packets-discarded-count"]){
        	eCounter.push("opd");
        }
        if(egressCounter["out-profile-packets-forwarded-count"]){
        	eCounter.push("opf");
        }
        if(egressCounter["in-profile-packets-forwarded-count"]){
        	eCounter.push("ipf");
        }
        if(egressCounter["in-profile-packets-discarded-count"]){
        	eCounter.push("ipd");
        }
        if(egressCounter["out-profile-octets-forwarded-count"]){
        	eCounter.push("oof");
        }
        if(egressCounter["out-profile-octets-discarded-count"]){
        	eCounter.push("ood");
        }
        return eCounter;
    }

    this.transformNfmpPolicerIngressCounter = function(ingressCounter){
        var iCounter = [];
        if(ingressCounter["in-profile-octets-offered-count"]){
        	iCounter.push("hoo");
        }
        if(ingressCounter["uncoloured-octets-offered-count"]){
        	iCounter.push("uco");
        }
        if(ingressCounter["out-profile-packets-forwarded-count"]){
        	iCounter.push("opf");
        }
        if(ingressCounter["in-profile-packets-offered-count"]){
        	iCounter.push("hpo");
        }
        if(ingressCounter["in-profile-packets-discarded-count"]){
        	iCounter.push("hpd");
        }
        if(ingressCounter["out-profile-octets-discarded-count"]){
        	iCounter.push("lod");
        }
        if(ingressCounter["in-profile-octets-forwarded-count"]){
        	iCounter.push("iof");
        }
        if(ingressCounter["in-profile-octets-discarded-count"]){
        	iCounter.push("hod");
        }
        if(ingressCounter["out-profile-packets-discarded-count"]){
        	iCounter.push("lpd");
        }
        if(ingressCounter["out-profile-packets-offered-count"]){
        	iCounter.push("lpo");
        }
        if(ingressCounter["in-profile-packets-forwarded-count"]){
        	iCounter.push("ipf");
        }
        if(ingressCounter["out-profile-octets-offered-count"]){
        	iCounter.push("loo");
        }
        if(ingressCounter["out-profile-octets-forwarded-count"]){
        	iCounter.push("oof");
        }
        if(ingressCounter["uncoloured-packets-offered-count"]){
        	iCounter.push("ucp");
        }
        return iCounter;
    }

    this.transformNfmpPolicerEgressCounter = function(egressCounter){
        var eCounter = [];
        if(egressCounter["in-plus-profile-packets-forwarded-count"]){
        	eCounter.push("ppf");
        }
        if(egressCounter["exceed-profile-packets-discarded-count"]){
        	eCounter.push("xpd");
        }
        if(egressCounter["out-profile-packets-forwarded-count"]){
        	eCounter.push("opf");
        }
        if(egressCounter["in-profile-packets-discarded-count"]){
        	eCounter.push("hpd");
        }
        if(egressCounter["exceed-profile-octets-discarded-count"]){
        	eCounter.push("xod");
        }
        if(egressCounter["in-plus-profile-octets-forwarded-count"]){
        	eCounter.push("pof");
        }
        if(egressCounter["in-profile-octets-discarded-count"]){
        	eCounter.push("hod");
        }
        if(egressCounter["in-plus-profile-octets-offered-count"]){
        	eCounter.push("poo");
        }
        if(egressCounter["in-plus-profile-packets-offered-count"]){
        	eCounter.push("ppo");
        }
        if(egressCounter["out-profile-packets-discarded-count"]){
        	eCounter.push("lpd");
        }
        if(egressCounter["in-profile-packets-forwarded-count"]){
        	eCounter.push("ipf");
        }
        if(egressCounter["out-profile-packets-offered-count"]){
        	eCounter.push("lpo");
        }
        if(egressCounter["uncoloured-packets-offered-count"]){
        	eCounter.push("ucp");
        }
        if(egressCounter["in-plus-profile-packets-discarded-count"]){
        	eCounter.push("ppd");
        }
        if(egressCounter["exceed-profile-packets-offered-count"]){
        	eCounter.push("xpo");
        }
        if(egressCounter["in-profile-octets-offered-count"]){
        	eCounter.push("hoo");
        }
        if(egressCounter["uncoloured-octets-offered-count"]){
        	eCounter.push("uco");
        }
        if(egressCounter["in-profile-packets-offered-count"]){
        	eCounter.push("hpo");
        }
        if(egressCounter["out-profile-octets-discarded-count"]){
        	eCounter.push("lod");
        }
        if(egressCounter["in-profile-octets-forwarded-count"]){
        	eCounter.push("iof");
        }
        if(egressCounter["exceed-profile-octets-forwarded-count"]){
        	eCounter.push("xof");
        }
        if(egressCounter["in-plus-profile-octets-discarded-count"]){
        	eCounter.push("pod");
        }
        if(egressCounter["exceed-profile-octets-offered-count"]){
        	eCounter.push("xoo");
        }
        if(egressCounter["exceed-profile-packets-forwarded-count"]){
        	eCounter.push("xpf");
        }
        if(egressCounter["out-profile-octets-forwarded-count"]){
        	eCounter.push("oof");
        }
        if(egressCounter["out-profile-octets-offered-count"]){
        	eCounter.push("loo");
        }
        return eCounter;
    }

    this.transformNfmpApplicationAssuranceCounter = function(applicationAssuranceCounter){
        var aaCounter = [];
        if(applicationAssuranceCounter["long-duration-flow-count"]){
        	aaCounter.push("ldf");
        }
        if(applicationAssuranceCounter["total-flows-completed-count"]){
        	aaCounter.push("tfc");
        }
        if(applicationAssuranceCounter["total-flow-duration"]){
        	aaCounter.push("tfd");
        }
        if(applicationAssuranceCounter["medium-duration-flow-count"]){
        	aaCounter.push("mdf");
        }
        if(applicationAssuranceCounter["short-duration-flow-count"]){
        	aaCounter.push("sdf");
        }
        return aaCounter;
    }

    this.transformNfmpAaFromSubCounter = function(aaFromSubCounter){
        var fromSubCounter = [];
        if(aaFromSubCounter["packets-denied-count"]){
        	fromSubCounter.push("spd");
        }
        if(aaFromSubCounter["forwarding-class"]){
        	fromSubCounter.push("sfc");
        }
        if(aaFromSubCounter["flows-denied-count"]){
        	fromSubCounter.push("sfd");
        }
        if(aaFromSubCounter["max-throughput-octet-count"]){
        	fromSubCounter.push("sbm");
        }
        if(aaFromSubCounter["max-throughput-packet-count"]){
        	fromSubCounter.push("spm");
        }
        if(aaFromSubCounter["max-throughput-timestamp"]){
        	fromSubCounter.push("smt");
        }
        if(aaFromSubCounter["octets-denied-count"]){
        	fromSubCounter.push("sbd");
        }
        if(aaFromSubCounter["flows-active-count"]){
        	fromSubCounter.push("saf");
        }
        if(aaFromSubCounter["octets-admitted-count"]){
        	fromSubCounter.push("sba");
        }
        if(aaFromSubCounter["flows-admitted-count"]){
        	fromSubCounter.push("sfa");
        }
        if(aaFromSubCounter["packets-admitted-count"]){
        	fromSubCounter.push("spa");
        }
        return fromSubCounter;
    }

    this.transformNfmpAAOptionalAttributes = function(aaOptionalAttributes){
        var aaAttributes = [];
        if(aaOptionalAttributes["app-profile"]){
        	aaAttributes.push("appProfile");
        }
        if(aaOptionalAttributes["app-service-options"]){
        	aaAttributes.push("appServiceOption");
        }
        return aaAttributes;
    }

    this.transformNfmpAAtoSubCounter = function(toAaSubCounters){
        var toAASubCounters = [];
        if(toAaSubCounters["packets-denied-count"]){
        	toAASubCounters.push("npd");
        }
        if(toAaSubCounters["forwarding-class"]){
        	toAASubCounters.push("nfc");
        }
        if(toAaSubCounters["flows-denied-count"]){
        	toAASubCounters.push("nfd");
        }
        if(toAaSubCounters["max-throughput-octet-count"]){
        	toAASubCounters.push("nbm");
        }
        if(toAaSubCounters["max-throughput-packet-count"]){
        	toAASubCounters.push("npm");
        }
        if(toAaSubCounters["max-throughput-timestamp"]){
        	toAASubCounters.push("nmt");
        }
        if(toAaSubCounters["octets-denied-count"]){
        	toAASubCounters.push("nbd");
        }
        if(toAaSubCounters["flows-active-count"]){
        	toAASubCounters.push("naf");
        }
        if(toAaSubCounters["octets-admitted-count"]){
        	toAASubCounters.push("nba");
        }
        if(toAaSubCounters["flows-admitted-count"]){
        	toAASubCounters.push("nfa");
        }
        if(toAaSubCounters["packets-admitted-count"]){
        	toAASubCounters.push("npa");
        }
        return toAASubCounters;
    }

    this.transformToIntentAAtoSubCounter = function(deviceValue){
        var intentToAaSubCounters = true;

        return intentToAaSubCounters;
    }

    /*
     function: distribute
     description: Payload for Distribute Policy to local NE Level.
     */
    this.distribute = function (neId, objectFullName, isLocalEdit) {
        logger.info("localEdit: " + isLocalEdit);
        var payload = {};
        if (isLocalEdit === false) {
            payload["policy.PolicyDefinition.distributeV2"] = {};
            payload["policy.PolicyDefinition.distributeV2"]["clearOnDeployFailure"] = true;
            payload["policy.PolicyDefinition.distributeV2"]["deployer"] = "immediate";
            payload["policy.PolicyDefinition.distributeV2"]["instanceFullName"] = objectFullName;
            payload["policy.PolicyDefinition.distributeV2"]["siteIds"] = {};
            payload["policy.PolicyDefinition.distributeV2"]["siteIds"]["string"] = neId;
            logger.info(objectFullName + ": policy distribute Payload: " + JSON.stringify(payload));
        }
        else {
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"] = {};
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["clearOnDeployFailure"] = true;
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["deployer"] = "immediate";
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["instanceFullName"] = objectFullName;
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["siteIds"] = {};
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["siteIds"]["string"] = neId;
            logger.info(objectFullName + ": policy switch to local edit only Payload for " + neId+ " : " + JSON.stringify(payload));
        }

        return payload;
    }

    /*
    function: delay
    description: Sometimes the object creation takes time, we can use delay for child-level operation.
    */
    this.delay = function (milliseconds){
        var date = new Date();
        date.setMilliseconds(date.getMilliseconds() + milliseconds);
        while(new Date() < date){
        }
    }

    this.arraysAreEqual = function(arr1, arr2) {
        if(!Array.isArray(arr1))
        {
          arr1 = [arr1];
        }
        if(!Array.isArray(arr2))
        {
          arr2 = [arr2];
        }
        // Check if the arrays have the same length
        if (arr1.length !== arr2.length) {
          return false;
        }
        // Sort the arrays
        var sortedArr1 = arr1.slice().sort();
        var sortedArr2 = arr2.slice().sort();
        // Compare the sorted arrays
        for (var i = 0; i < sortedArr1.length; i++) {
          if (sortedArr1[i] !== sortedArr2[i]) {
            return false; // Elements are different, arrays are not equal
          }
        }
        return true; // Arrays are equal
    }

    this.modifyNeIdForIpV6 = function (objectFullName, neId) {
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }
}
