var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let util = new utilities();
    this.getDeviceConfiguration = function (neId, portId, initialPropertyName) {
        let nfmpPortFdn = util.getBaseFdnForPort(neId, portId);
        let portConfig = this.getEthernetPortConfiguration(nfmpPortFdn);
        let lldpConfig = this.getPortLldpConfiguration(nfmpPortFdn);
        let deviceConfig = {
            "portConfig": portConfig,
            "lldpConfig": lldpConfig
        };
        return deviceConfig;
    }

    this.getPortLldpConfiguration = function (nfmpPortFdn) {
        //let nfmpFwk = new MediatorFramework("NFMP");
        let url = "/rest/api/v1/managedobjects/children";

        //NearestBridge
        let payload = {
            "fdn": nfmpPortFdn + ":lldpportconfiguration-Nearest-Bridge",
            "fullClassNameList": [
                "lldp.TransmitMgmtAddress"
            ]
        };
        let lldpNearestBridgePortConfigResp = nfmpFwk.post(url, payload);
        if (!(lldpNearestBridgePortConfigResp.success && JSON.parse(lldpNearestBridgePortConfigResp["response"]).length !== 0))
            throw new RuntimeException("Failed to get LLDP information from NFMP: " + JSON.stringify(lldpNearestBridgePortConfigResp));


        //NearestCustomer
        payload = {
            "fdn": nfmpPortFdn + ":lldpportconfiguration-Nearest-Customer",
            "fullClassNameList": [
                "lldp.TransmitMgmtAddress"
            ]
        };

        let lldpNearestCustomerPortConfigResp = nfmpFwk.post(url, payload);
        if (!(lldpNearestCustomerPortConfigResp.success && JSON.parse(lldpNearestCustomerPortConfigResp["response"]).length !== 0))
            throw new RuntimeException("Failed to get LLDP information  from NFMP: " + JSON.stringify(lldpNearestCustomerPortConfigResp));


        //NearestNonTpmr
        payload = {
            "fdn": nfmpPortFdn + ":lldpportconfiguration-Nearest-Non-TPMR",
            "fullClassNameList": [
                "lldp.TransmitMgmtAddress"
            ]
        };
        let lldpNearestNonTPMRPortConfigResp = nfmpFwk.post(url, payload);
        if (!(lldpNearestNonTPMRPortConfigResp.success && JSON.parse(lldpNearestNonTPMRPortConfigResp['response']).length !== 0))
            throw new RuntimeException("Failed to get LLDP information  from NFMP: " + JSON.stringify(lldpNearestNonTPMRPortConfigResp));


        let lldpConfig = {};
        lldpConfig = {
            "nearest-bridge": JSON.parse(lldpNearestBridgePortConfigResp['response']),
            "nearest-customer": JSON.parse(lldpNearestCustomerPortConfigResp['response']),
            "nearest-non-tpmr": JSON.parse(lldpNearestNonTPMRPortConfigResp['response'])
        }

        //logger.info("Data from the node: " + JSON.stringify(lldpConfig));
        return lldpConfig;

    }

    this.getEthernetPortConfiguration = function (nfmpPortFdn) {
        //let nfmpFwk = new MediatorFramework("NFMP");
        let url = "/rest/api/v1/managedobjects/children";

        //NearestBridge
        let payload = {
            "fdn": nfmpPortFdn,
            "fullClassNameList": [
                "ethernetequipment.EthernetPortSpecifics"
            ]
        };
        let lPortConfigResponse = nfmpFwk.post(url, payload);
        if (!(lPortConfigResponse.success && JSON.parse(lPortConfigResponse["response"]).length !== 0))
            throw new RuntimeException("Failed to get port information from NFMP: " + JSON.stringify(lPortConfigResponse));
        lPortConfigResponse = JSON.parse(lPortConfigResponse["response"]);
        return lPortConfigResponse;

    }

    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        let portconfig = deviceConfig['portConfig'];
        if (null !== portconfig)
        {
            this.extractPortConfig(parsedDefaultTargetData, portconfig);
        }
        let lldpConfig = deviceConfig["lldpConfig"];
        if (null !== lldpConfig)
        {
            let portData = parsedDefaultTargetData['port'];
            let ethernetData = portData['ethernet'];
            let lldpData = ethernetData['lldp'];
            if (lldpData !== null && typeof lldpData === 'object')
            {
                this.extractLldpConfig(lldpData, lldpConfig);

            }

        }
        //logger.info("Target Data fetched from the node : " + JSON.stringify(parsedDefaultTargetData));
        return parsedDefaultTargetData;
    }

    this.extractPortConfig = function (defaultTargetData, portConfig) {
        ///return this.extractTargetData(defaultTargetData,portConfig);
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];

            if (targetObj !== null && typeof targetObj === 'object')
            {
                this.traverseAndUpdateEthernetPort(targetKey, targetObj, portConfig);
            }
        }
        return defaultTargetData;
    }

    this.extractLldpConfig = function (defaultLldpData, lldpConfig) {
        let defaultTargetData = defaultLldpData['dest-mac'];
        if (defaultTargetData !== null && Array.isArray(defaultTargetData) && defaultTargetData.length !== 0)
        {
            defaultTargetData = defaultTargetData[0];

            let lldpPortList = [];
            let destMacList = ["nearest-bridge", "nearest-non-tpmr", "nearest-customer"];
            for (let i = 0; i < 3; i++)
            {
                let lldpPortConfig = {};
                lldpPortConfig['mac-type'] = destMacList[i];
                let macType = lldpPortConfig['mac-type'];
                {
                    switch (macType)
                    {
                        case "nearest-bridge":
                            this.traverseAndUpdateLldp(macType, defaultTargetData, lldpPortConfig, lldpConfig['nearest-bridge']);
                            break;
                        case "nearest-non-tpmr":
                            this.traverseAndUpdateLldp(macType, defaultTargetData, lldpPortConfig, lldpConfig['nearest-non-tpmr']);
                            break;
                        case "nearest-customer":
                            this.traverseAndUpdateLldp(macType, defaultTargetData, lldpPortConfig, lldpConfig['nearest-customer']);
                            break;
                    }

                }
                lldpPortList.push(lldpPortConfig);
            }
            defaultLldpData['dest-mac'] = lldpPortList;
        }

    }


    this.traverseAndUpdateEthernetPort = function (objKey, obj, parsedDeviceConfig) {

        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];

            let mappedKey = objKey + "." + key;
            if (value != null && typeof value === 'object' && key !== "lldp")
            {
                this.traverseAndUpdateEthernetPort(mappedKey, value, parsedDeviceConfig);
            }
            else
            {
                // call for each key with string value
                this.getAndUpdateFromDeviceConfig(mappedKey, key, obj, parsedDeviceConfig);
            }
        }
        return obj;
    }


    this.traverseAndUpdateLldp = function (macType, defaultData, targetData, deviceConfig) {
        let mappings = modelDeviceMapping.getMapping("lldp");
        let keys = Object.keys(defaultData);
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            if (targetKey === "tx-tlvs")
            {
                this.updateLldpTxTLVs(targetData, deviceConfig);
            }
            else if (targetKey === "receive" || targetKey === "transmit")
            {
                this.updateLldpTransmitReceive(targetData, deviceConfig);
            }
            else if (targetKey === "mac-type")
            {
                targetData[targetKey] = macType;
            }
            else if (targetKey === "tx-mgmt-address")
            {
                let nfmpKey = mappings[targetKey];
                let deviceValue = deviceConfig[nfmpKey];
                targetData[targetKey] = this.updateTxMgmtAddress(defaultData[targetKey], deviceValue);
            }
            else
            {
                let nfmpKey = mappings[targetKey];
                let deviceValue = deviceConfig[nfmpKey];

                targetData[targetKey] = this.transformDeviceValue(targetKey, deviceValue);
            }
        }


    }

    this.updateTxMgmtAddress = function (defaultData, deviceConfig) {
        let txMgmtAddressList = [];
        if (defaultData !== null && Array.isArray(defaultData) && defaultData.length !== 0)
        {
            defaultData = defaultData[0];

            if (deviceConfig != null && Array.isArray(deviceConfig) && deviceConfig.length !== 0)
            {
                for (let i = 0; i < deviceConfig.length; i++)
                {
                    let txAddrDevice = deviceConfig[i];
                    let mappings = modelDeviceMapping.getMapping("txMgmtAddress");
                    let keys = Object.keys(defaultData);
                    let txAddrTarget = {};
                    for (let j = 0; j < keys.length; j++)
                    {
                        let targetKey = keys[j];
                        let nfmpKey = mappings[targetKey];
                        let deviceValue = txAddrDevice[nfmpKey];
                        if (targetKey == "admin-state")
                        {
                            txAddrTarget["admin-state"] = this.transformTxMgmtAdminstate(deviceValue);
                        }
                        else if (targetKey == "mgmt-address-system-type")
                        {
                            txAddrTarget["mgmt-address-system-type"] = this.transformTxAddressSysType(deviceValue);
                        }
                    }
                    //logger.info("TxMgmtAdress : " + JSON.stringify(txAddrTarget));
                    txMgmtAddressList.push(txAddrTarget);
                }

            }
        }

        return txMgmtAddressList;
    }

    this.transformTxMgmtAdminstate = function (adminState) {
        switch (adminState)
        {
            case "disabled":
                return "disable";
            case "enabled":
                return "enable";
        }
    }

    this.transformTxAddressSysType = function (sysType) {
        switch (sysType)
        {
            case "0":
                return "oob";
            case "1":
                return "system";
            case "2":
                return "system-ipv6";
            case "3":
                return "oob-ipv6";
        }

    }

    this.updateLldpTransmitReceive = function (targetData, deviceConfig) {
        let adminState = deviceConfig['portCfgAdminStatus'];
        switch (adminState)
        {
            case "txOnly":
                targetData['receive'] = "false";
                targetData['transmit'] = "true";
                break;
            case"rxOnly":
                targetData['receive'] = "true";
                targetData['transmit'] = "false";
                break;
            case "txAndRx":
                targetData['receive'] = "true";
                targetData['transmit'] = "true";
                break;
            case "disabled":
                targetData['receive'] = "false";
                targetData['transmit'] = "false";
                break;
        }

    }

    this.updateLldpTxTLVs = function (targetData, deviceConfig) {

        let txTlvs = {
            "sys-cap": false,
            "port-desc": false,
            "sys-name": false,
            "sys-desc": false
        };
        let deviceData = deviceConfig['portCfgTLVsTxEnable'];
        if (deviceData != null && deviceData.length !== 0)
        {
            for (let i = 0; i < deviceData.length; i++)
            {
                let tlv = deviceData[i];
                switch (tlv)
                {
                    case "sysCap":
                        txTlvs['sys-cap'] = true;
                        break;
                    case "portDesc":
                        txTlvs['port-desc'] = true;
                        break;
                    case "sysName":
                        txTlvs['sys-name'] = true;
                        break;
                    case "sysDesc":
                        txTlvs['sys-desc'] = true;
                        break;
                }
            }

        }
        targetData['tx-tlvs'] = txTlvs;
    }


    this.getAndUpdateFromDeviceConfig = function (mappedKey, targetKey, targetObj, parsedDeviceConfig) {
        let mappings = modelDeviceMapping.getMapping("port");
        // Get the key from mapping against targetKey
        // If the mapping key is not undefined, Get the value from deviceKey
        // if the value from deviceConfig against that mapping key is not n
        let nfmpKey = mappings[mappedKey];
        //logger.info("************************************************************************************************************")
        //logger.info("mappedKey = " + mappedKey + "\nnfmpKey = " + nfmpKey + "\ntargetKey = " + targetKey);

        if (nfmpKey !== undefined)
        {
            let fullName = nfmpKey.split(".");
            let fullClassName = fullName[0] + "." + fullName[1];
            let propertyName = fullName[2];
            let deviceValue = "";
            if (parsedDeviceConfig['className'] === fullClassName)
            {
                deviceValue = parsedDeviceConfig[propertyName];

            }
            else
            {

                let childObj = parsedDeviceConfig[fullClassName];
                if (childObj != null && typeof childObj === 'object')
                {
                    deviceValue = childObj[propertyName];
                }

            }
            //logger.info("deviceValue = " + deviceValue)
            //logger.info("************************************************************************************************************")
            targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);

        }

    }

    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue !== null)
        {

            if (mappedKey === "port.admin-state")
            {
                return this.transformPortAdminState(deviceValue);
            }
            else if (mappedKey === "port.ethernet.encap-type")
                return this.transformPortEncapType(deviceValue);
            else if (mappedKey === "port-id-subtype")
                return this.transformLldpPortSubType(deviceValue);
            else if (mappedKey === "port.ethernet.down-when-looped.admin-state")
                return this.transformDownWhenLoopedAdminState(deviceValue);
            else if (mappedKey === "port.ethernet.speed")
                return this.transformPortSpeed(deviceValue);
            else if ((mappedKey === "port.ethernet.dot1q-etype") || (mappedKey === "port.ethernet.qinq-etype") || (mappedKey === "port.ethernet.pbb-etype"))
                return this.transformEtypeValue(deviceValue);
            else if (mappedKey === "port.ethernet.accounting-policy" || mappedKey === "port.ethernet.network.accounting-policy"|| mappedKey === "port.ethernet.access.accounting-policy" || mappedKey === "port.ethernet.egress.port-qos-policy.policy-name")
                return this.transformAccountingPolicyId(deviceValue);
            else if (mappedKey === "port.ethernet.ssm.admin-state")
                return this.transformSsmAdminState(deviceValue);
            else if (mappedKey === "port.ethernet.crc-monitor.signal-degrade.threshold" ||
                mappedKey === "port.ethernet.crc-monitor.signal-failure.threshold")
                return this.transformCrcThreshold(deviceValue);
            else return deviceValue;
        }
    }

    this.transformCrcThreshold = function (thresholdValue) {
        if (thresholdValue !== "0")
        {
            return thresholdValue;
        }
    }

    this.transformPortAdminState = function (adminState) {
        switch (adminState)
        {
            case "portInService":
                return "enable";
            case "portOutOfService":
                return "disable";
        }
    }

    this.transformDownWhenLoopedAdminState = function (adminState) {
        switch (adminState)
        {
            case "disabled":
                return "disable";
            case "enabled":
                return "enable";
        }
    }

    this.transformSsmAdminState = function (adminState) {
        switch (adminState)
        {
            case "false":
                return "disable";
            case "true":
                return "enable";
        }
    }


    this.transformPortEncapType = function (adminState) {
        switch (adminState)
        {
            case "nullEncap":
                return "null";
            case "qEncap":
                return "dot1q";
            case "qinqEncap":
                return "qinq";
        }
    }


    this.transformPortSpeed = function (speed) {
        switch (speed)
        {
            case "ethernet10":
                return 10;
            case "ethernet100":
                return 100;
            case "ethernet1000":
                return 1000;
            case "ethernet10000":
                return 10000;
            case "ethernet40000":
                return 40000;
            case "ethernet100000":
                return 100000;
            case "ethernet25000":
                return 25000;
            case "ethernet50000":
                return 50000;

        }
    }

    this.transformEtypeValue = function (deviceValue) {
        let value = Number(deviceValue).toString(16);
        return "0x" + value;
    }

    this.transformAccountingPolicyId = function (deviceValue) {
        if (deviceValue)
        {
            return deviceValue.split(":")[1];
        }
    }

    this.transformLldpPortSubType = function (portIdSubtype) {
        switch (portIdSubtype)
        {
            case "interfaceName":
                return "tx-if-name";
            case "local":
                return "tx-local";
            case "interfaceAlias":
                return "tx-if-alias";

        }
    }
}
