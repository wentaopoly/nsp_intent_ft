function MdSuggest() {
    this.getPolicyName = function (neId, policyId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-state:/state/qos/network?fields=oper-policy-id";
        return this.getData(neId, url, "network-policy-name", policyId);
    }

    this.getPolicyId = function (neId, policyName) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-state:/state/qos/network?fields=oper-policy-id";
        if (policyName) {
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-state:/state/qos/network=" + policyName + "?fields=oper-policy-id";
        }
        return this.getData(neId, url, "oper-policy-id");
    }

    this.getSupportAttributeDataList = function (neId, dataType) {
        var url = "";
        if (dataType === "IPv4") {
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/match-list/ip-prefix-list";
            return this.getGlobalData(neId, url, "ip-prefix-list", "prefix-list-name");
        }
        if (dataType === "IPv6") {
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/match-list/ipv6-prefix-list";
            return this.getGlobalData(neId, url, "ipv6-prefix-list", "prefix-list-name");
        }
        if (dataType === "port_list") {
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/match-list/port-list";
            return this.getGlobalData(neId, url, "port-list", "port-list-name");
        }
    }

    this.getGlobalData = function (neId, url, classType, type) {
        var mdcFwk = new MdcFwk();
        logger.info(LOG_PREFIX + "MdSuggest QOS network --getData---neId={}, url={}, type={}", neId, url, type);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info(LOG_PREFIX + "MDC resultFetch QOS network =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"]["nokia-conf:" + classType];
        logger.info(LOG_PREFIX + "finalResponse = " + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        for (var index in finalResponse) {
            ret.push(finalResponse[index][type]);
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "ret = \n" + JSON.stringify(ret));
        return ret;
    }

    this.getData = function (neId, url, type, policyId) {
        var mdcFwk = new MdcFwk();
        logger.info(LOG_PREFIX + "MdSuggest QOS network --getData---neId={}, url={}, type={}", neId, url, type);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info(LOG_PREFIX + "MDC resultFetch QOS network =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"]["nokia-state:network"];
        logger.info(LOG_PREFIX + "finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                if (policyId) {
                    logger.info(LOG_PREFIX + "PolicyId Selected = {}", policyId);
                    logger.info(LOG_PREFIX + "Device policy ID = {}", finalResponse[index]["oper-policy-id"]);
                    if (finalResponse[index]["oper-policy-id"] == policyId) {
                        ret.push(finalResponse[index][type]);
                        break
                    }
                }
                else {
                    ret.push(finalResponse[index][type]);
                }
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "ret = \n" + JSON.stringify(ret));
        return ret;
    }
}