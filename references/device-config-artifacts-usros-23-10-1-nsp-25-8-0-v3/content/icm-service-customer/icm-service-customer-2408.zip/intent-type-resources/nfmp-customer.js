var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpCustomer() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    var parseTarget =  new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var savedObjects;
    var currentObjects;
    var isAudit = false;

    this.synchronize = function(input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, intentConfig) {
        // code to handle delete
        if (input.getNetworkState().name() == "delete") {
            logger.info(LOG_PREFIX + "Calling syncDelete");
            return this.syncDelete(input, result);
        }

        // code to handle sync
        var savedTopology = input.getCurrentTopology();
        logger.info(LOG_PREFIX + "Saved Topology = "+savedTopology);
        savedObjects = {};
        currentObjects = {};
        //loading the saved objects from topology
        this.loadSavedObjectsFromTopology(savedTopology);
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var customerId = util.getServiceCustomerId(input.getTarget());
        var customerName = util.getServiceCustomerName(input.getTarget());
        intentConfig = this.removeEmptyContainers("",intentConfig,"",neId);
        if(!intentConfig)
        {
            intentConfig = Object.create({});
        }
        intentConfig[uniqueIdentifier] = customerName;
        intentConfig["customer-id"] = parseInt(customerId);
        logger.info(LOG_PREFIX + "Configuration to be pushed = "+JSON.stringify(intentConfig));
        logger.info(LOG_PREFIX + "Target device = " + neId);
        this.createOrModify(neId,intentConfig);
        var currentTopo = this.loadCurrentObjectsToTopology(neId);

        return util.setSuccessResult(result, currentTopo);
    }

    this.createOrModify = function (neId, intentConfig) {
        var result = this.createSubscriberPayLoad(intentConfig)
        logger.info(LOG_PREFIX + "Payload to be pushed = "+JSON.stringify(result));
        this.modifyRequest(neId, result);

        return result;
    }

    this.createSubscriberPayLoad = function (intentConfig) {
        var fullClassName = "subscr.Subscriber";
        var fdn = "subscriber:" + intentConfig['customer-id'];
        var objectFullName = fdn;
        var subscriber = util.getIfSubscriberObjectExists(fullClassName, objectFullName)
        if (subscriber == null){
            fdn = "subscriber";
            objectFullName = fdn;
        }

        var properties = {};
        properties["subscriberId"] = intentConfig["customer-id"];
        properties["subscriberName"] = intentConfig["customer-name"];
        properties["description"] = intentConfig["description"];
        properties["phoneNumber"] = intentConfig["phone"];
        properties["contact"] = intentConfig["contact"];

        var childProperties = {};
        var sites = [];
        if(intentConfig['sites'])
        {
            sites = intentConfig['sites'];
        }
        var siteList = []
        for (var i=0; i<sites.length; i++)
        {
            var prop = {}
            prop["subscriberSiteId"] = sites[i]['site-id'];
            siteList.push(prop)
        }
        childProperties["subscr.Site"] = siteList;

        var subscriberPayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
        return subscriberPayload;
    }

    this.syncDelete = function (input, result) {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var customerId = util.getServiceCustomerId(input.getTarget());
        var customerName = util.getServiceCustomerName(input.getTarget());
        var objectFullName = "subscriber:" + customerId;// + ":site-" + neId;

        var searchPayload = this.constructSearchString(neId, objectFullName);
        logger.info(LOG_PREFIX + "Search payload : " + JSON.stringify(searchPayload));
        var searchResponse = nfmpFwk.find(neId, searchPayload);

        if (!(searchResponse.success && JSON.stringify(JSON.parse(searchResponse.response)) !== JSON.stringify({}))) {
            if(!(searchResponse.success)) {
                logger.info( LOG_PREFIX + "syncDelete(): Unable to get Customer info from nfm-p for customer with Name:" +
                    customerName + " and Id: " + customerId );
            }
            if(JSON.parse(searchResponse.response) === JSON.stringify({})) {
                logger.info(LOG_PREFIX + "syncDelete(): There is no Customer with Name:" +
                    customerName + " and Id: " + customerId + " on " + neId);
            }
            result.setSuccess(false);
            return;
        }

        logger.info(LOG_PREFIX + "syncDelete(): Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success) {
            logger.info(LOG_PREFIX + "syncDelete(): Unable to Delete: " + deleteResult.msg);
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }

    this.constructSearchString = function(neId, objectFullName) {
        logger.info(LOG_PREFIX + "Creating search payload for objectFullName : " + objectFullName);
        var jsonPayLoad = {
            "fullClassName": "subscr.Subscriber",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "objectFullName",
                            "value": objectFullName
                        }
                    ]
                }
            }
        };

        return jsonPayLoad;
    }

    this.modifyRequest = function (neId, payload) {
        logger.info(LOG_PREFIX + "Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop,intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop,intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }

    this.loadSavedObjectsFromTopology = function(savedTopology) {
        if(savedTopology){
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0){
                topoObjects.forEach(function(topoObject){
                    mapFwk.set(savedObjects,topoObject.getObjectType(),topoObject.getObjectRelativeObjectID());
                });
            }
        }
    }

    this.loadCurrentObjectsToTopology = function(target) {
        var currentTopo = topologyFactory.createServiceTopology();
        if(Object.keys(currentObjects).length){
            for(var key in currentObjects){
                objectId = mapFwk.get(currentObjects,key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key,objectId,"INFRASTRUCTURE",target,""));
            }
        }
        return currentTopo;
    }
}
