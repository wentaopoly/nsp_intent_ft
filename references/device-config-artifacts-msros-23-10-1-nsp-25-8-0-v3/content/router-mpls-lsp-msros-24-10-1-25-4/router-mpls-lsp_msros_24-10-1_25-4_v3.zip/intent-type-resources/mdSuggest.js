function MdSuggest() {
    this.getLspName = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/mpls/lsp?fields=lsp-name`;
    return this.getSuggestData(neId, url, "nokia-conf:lsp", "lsp-name");
   }

    this.getIfAttributeAdminGroupName = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/routing-options/if-attribute/admin-group?fields=group-name`;
    return this.getSuggestData(neId, url, "nokia-conf:admin-group", "group-name");
   }

    this.getMplsClassForwardingPolicyName = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/mpls/class-forwarding-policy?fields=policy-name`;
    return this.getSuggestData(neId, url, "nokia-conf:class-forwarding-policy", "policy-name");
   }


    this.getAdminTagData = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/routing-options/admin-tags/admin-tag?fields=tag`;
    return this.getSuggestData(neId, url, "nokia-conf:admin-tag", "tag");
   }

    this.getLogAccountingPolicyId = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/log/accounting-policy?fields=policy-id`;
    return this.getSuggestData(neId, url, "nokia-conf:accounting-policy", "policy-id");
   }

    this.getBfdTemplateName = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/bfd/bfd-template?fields=name`;
    return this.getSuggestData(neId, url, "nokia-conf:bfd-template", "name");
   }

    this.getPceAssociationsDiversityAssocName = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/pcep/pcc/pce-associations/diversity?fields=assoc-name`;
    return this.getSuggestData(neId, url, "nokia-conf:diversity", "assoc-name");
   }

    this.getPceAssociationsPolicyAssocName = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/pcep/pcc/pce-associations/policy?fields=assoc-name`;
    return this.getSuggestData(neId, url, "nokia-conf:policy", "assoc-name");
   }

    this.getMplsPathName = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/mpls/path?fields=path-name`;
      return this.getSuggestDataForPicker(neId, url, "nokia-conf:path", "path-name");
   }

   this.getSuggestData = function(neId, url, initialProperty, propertyName) {
      const mdcFwk = new MdcFwk();
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg[initialProperty];
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data[propertyName]).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getSuggestDataForPicker = function(neId, url, initialProperty, propertyName) {
         const mdcFwk = new MdcFwk();
         const resultFetch = mdcFwk.fetch(neId, url);
         const finalResponse = resultFetch.msg[initialProperty];
         logger.info(JSON.stringify(finalResponse));
         var ret = {};
         ret["data"] = JSON.stringify(finalResponse);
         return ret;
      }
}