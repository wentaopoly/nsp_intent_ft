var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpScheduerPolicy() {

    var util = new utilities();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var savedTopology;
    var isAudit = false;
    var isEdit = false;
    var modeChanged = false;
    var nfmpFwkPostRequest = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true"
    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        if (input.getNetworkState().name() == "delete")
        {
            logger.info("Calling syncDelete");
            return this.syncDelete(input, result);
        }
        savedTopology = input.getCurrentTopology();
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        var intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        //set the policy name from target
        intentConfig["scheduler-policy-name"] = input.getTarget().split("#")[2];
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        this.createOrModify(neId, intentConfig);
        return util.setSuccessResult(result, savedTopology);
    }
    this.syncDelete = function (input, result) {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyName = input.getTarget().split("#")[2];
        var objectFullName = "network:" + neId + ":sasPortSchedulerPolicy:" + policyName;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        logger.info("Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }
    this.createOrModify = function (neId, intentConfig) {
        var schedulerPayload = this.createPolicyLevelPayLoad(neId, intentConfig);
        var result = this.modifyRequest(neId, schedulerPayload);
        // distribute the policy to the local
        // Distribute Global Policy to Ne in Target
        if (!isEdit)
        {
            logger.info("Distributing the policy to local");
            var objectFullName = "sasPortSchedulerPolicy:" + intentConfig["scheduler-policy-name"]
            var fullClassName = "sasqos.PortScheduler";
            var localPolicyFullName = "network:" + neId + ":" + objectFullName;
            localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
            var distributePayload = util.distribute(neId, objectFullName, false);
            var distributeResult = nfmpFwk.post(nfmpFwkPostRequest, distributePayload);
            if (!distributeResult.success)
            {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }
            util.delay(2000);
            // Changing SyncWithGlobal To Local Edit Only
            distributePayload = util.distribute(neId, objectFullName, true);
            distributeResult = nfmpFwk.post(nfmpFwkPostRequest, distributePayload);
            if (!distributeResult.success)
            {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }
            util.delay(2000);
            if (!util.isObjectExists(fullClassName, localPolicyFullName))
            {
                throw new RuntimeException("Unable to Distribute existing Global Policy: " + objectFullName + " to local policy: " + localPolicyFullName + " , Kindly check the Global Policy configuration");
            }
        }
        return result;
    }
    this.createPolicyLevelPayLoad = function (neId, intentConfig) {
        if (savedTopology == null)
        {
            logger.info("Creating topology to save mode");
            savedTopology = topologyFactory.createServiceTopology();
        }
        var fullClassName = "sasqos.PortScheduler";
        var policyFdn = "sasPortSchedulerPolicy";
        var objectFullName = "sasPortSchedulerPolicy:" + intentConfig["scheduler-policy-name"];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        if (util.isObjectExists(fullClassName, localPolicyFullName) || isAudit)
        {
            objectFullName = localPolicyFullName;
            if (!isAudit)
            {
                isEdit = true;
            }
        }
        var properties = {};
        properties["displayedName"] = intentConfig["scheduler-policy-name"];
        properties["description"] = intentConfig["description"];
        properties["mode"] = util.convertModeGreenField(intentConfig["mode"]);

        var XtraInfolength = savedTopology.getXtraInfo().length;
        logger.info("XtraInfolength == {}", XtraInfolength);
        logger.info("savedTopology.getXtraInfo() == {}", savedTopology.getXtraInfo());
        if (XtraInfolength > 0)
        {
            for (var index in savedTopology.getXtraInfo())
            {
                var xtraInfoKey = savedTopology.getXtraInfo()[index].getKey();
                if (xtraInfoKey === "mode")
                {
                    var xtraInfoValue = savedTopology.getXtraInfo()[index].getValue();
                    if (xtraInfoValue !== properties["mode"])
                    {
                        modeChanged = true
                    }
                }
            }
        }

        var entry = topologyFactory.createTopologyXtraInfoFrom("mode", properties["mode"]);
        savedTopology.addXtraInfo(entry);


        var childProperties = {};
        if ((intentConfig["mode"] === "Weighted Round Robin" || intentConfig["mode"] === "Weighted Deficit Round Robin") && (intentConfig["queue-weights"]))
        {
            if (!Array.isArray(intentConfig["queue-weights"]))
            {
                intentConfig["queue-weights"] = [intentConfig["queue-weights"]];
            }
            for (var index in intentConfig["queue-weights"])
            {
                var intenQueueWeightConfig = intentConfig["queue-weights"][index];
                var queueWeightID = "queue" + intenQueueWeightConfig["queue-id"] + "Weight"
                properties[queueWeightID] = intenQueueWeightConfig["weight"];
            }
        }
        var policyLevelPayload = util.editPayload(policyFdn, properties, childProperties, fullClassName, objectFullName);
        return policyLevelPayload;
    }
    this.modifyRequest = function (neId, payload) {

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
           logger.error("Error result = {}",JSON.stringify(result));
           let errorMsg = result.msg;
           if(errorMsg.indexOf("object already exists") !== -1)
           {
               logger.info("Global policy Object already exists, Re-checking the Policy existence ");
               //util.delay(2000);
               let configInfo = payload.configInfo;
               let fullClassName;
               for (let key in configInfo) {
                 if (configInfo.hasOwnProperty(key)) {
                   fullClassName = key;
                   break;
                 }
               }
               let objectFullName = payload.objectFullName;
               objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
               logger.info("fullClassName = {}",fullClassName);
               logger.info("objectFullName = {}",objectFullName);
               if (!util.isObjectExists(fullClassName, objectFullName))
               {
                   throw new RuntimeException("Global Policy Object Not Found!!!");
               }
           }
           else
           {
               throw new RuntimeException(result.msg);
           }
        }
        if (modeChanged)
        {
            result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
            if (!result.success)
            {
               logger.error("Error result = {}",JSON.stringify(result));
               let errorMsg = result.msg;
               if(errorMsg.indexOf("object already exists") !== -1)
               {
                   logger.info("Global policy Object already exists, Re-checking the Policy existence ");
                   //util.delay(2000);
                   let configInfo = payload.configInfo;
                   let fullClassName;
                   for (let key in configInfo) {
                     if (configInfo.hasOwnProperty(key)) {
                       fullClassName = key;
                       break;
                     }
                   }
                   let objectFullName = payload.objectFullName;
                   objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
                   logger.info("fullClassName = {}",fullClassName);
                   logger.info("objectFullName = {}",objectFullName);
                   if (!util.isObjectExists(fullClassName, objectFullName))
                   {
                       throw new RuntimeException("Global Policy Object Not Found!!!");
                   }
               }
               else
               {
                   throw new RuntimeException(result.msg);
               }
            }
        }

        return result;
    }
    this.audit = function (input, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        isAudit = true;
        var lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        var intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        intentConfig["scheduler-policy-name"] = input.getTarget().split("#")[2];
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        if (intentConfig)
        {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }
        return auditReport
    }
    this.auditAndCompare = function (neId, intentConfig, auditReport) {
        var schedulerPayload = this.createPolicyLevelPayLoad(neId, intentConfig);
        var result = this.auditRequest(neId, schedulerPayload);
        auditReport = util.reportMisaligned(neId, result, auditReport);
        return auditReport;
    }
    this.auditRequest = function (neId, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }
}
