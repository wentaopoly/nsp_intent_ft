package com.nokia.nsp.md.resync.plugin.srl;

import com.alu.nms.common.util.model.ModelFdn;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nokia.nsp.md.common.IExecutionContext;
import com.nokia.nsp.md.common.IYangObject;
import com.nokia.nsp.md.common.YangObject;
import com.nokia.nsp.md.db.yang.api.ExecutionContext;
import com.nokia.nsp.md.db.yang.api.QueryParameters;
import com.nokia.nsp.md.db.yang.api.meta.IYangNode;
import com.nokia.nsp.md.db.yang.api.meta.IYangPath;
import com.nokia.nsp.md.ifg.yang.api.Field;
import com.nokia.nsp.md.ifg.yang.api.Fields;
import com.nokia.nsp.md.resync.api.IReadObjects;
import com.nokia.nsp.md.resync.plugin.common.DeviceInfo;
import com.nokia.nsp.md.resync.plugin.common.DeviceResyncClass;
import com.nokia.nsp.md.resync.plugin.common.IMDMPluginMdResyncProvider;
import com.nokia.nsp.md.resync.plugin.common.INspResyncDeviceClassHandler;
import com.nokia.nsp.md.resync.plugin.common.IPartialResyncContext;
import com.nokia.nsp.md.resync.plugin.common.ISaveTaskInfo;
import com.nokia.nsp.md.resync.plugin.common.IUnmanageNeContext;
import com.nokia.nsp.md.resync.plugin.common.ResyncClass;
import com.nokia.nsp.md.resync.plugin.common.Utils;
import com.nokia.nspos.model.domain.common.types.SourceType;
import com.nokia.nspos.persistence.impl.db.transaction.Transactor;
import com.nokia.nspos.persistence.impl.db.transaction.TxPhase;
import com.nokia.nspos.persistence.yang.api.IYangDB;
import com.nokia.nspos.persistence.yang.api.SourceData;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

public class SrlElanEndpointResyncHandler implements INspResyncDeviceClassHandler {
    private static final Logger handleRootDeviceLogger = LoggerFactory.getLogger(SrlElanEndpointResyncHandler.class.getName() + ".handleRootDevice");
    private static final Logger handlePartialDeviceResyncClassLogger = LoggerFactory.getLogger(SrlElanEndpointResyncHandler.class.getName() + ".handlePartialDeviceResyncClass");
    private static final Logger updateSyncEndpointLogger = LoggerFactory.getLogger(SrlElanEndpointResyncHandler.class.getName() + ".updateSyncEndpoint");
    private static final Logger createSyncEndpointLogger = LoggerFactory.getLogger(SrlElanEndpointResyncHandler.class.getName() + ".createSyncEndpoint");
    private static final Logger updateEndpointLogger = LoggerFactory.getLogger(SrlElanEndpointResyncHandler.class.getName() + ".updateEndpoint");
    private static final Logger createEndpointLogger = LoggerFactory.getLogger(SrlElanEndpointResyncHandler.class.getName() + ".createEndpoint");
    private static final Logger updateServiceEndpointLogger = LoggerFactory.getLogger(SrlElanEndpointResyncHandler.class.getName() + ".updateServiceEndpoint");
    private static final Logger handleUpdateLogger = LoggerFactory.getLogger(SrlElanEndpointResyncHandler.class.getName() + ".handleUpdate");
    private static final Logger handleDeleteLogger = LoggerFactory.getLogger(SrlElanEndpointResyncHandler.class.getName() + ".handleDelete");
    private static final Logger logger = LoggerFactory.getLogger(SrlElanEndpointResyncHandler.class.getName());
    public static final String SRL_NOKIA_INTERFACES_INTERFACE_SUBINTERFACE = "srl_nokia-interfaces:/interface/subinterface";
    private static ThreadLocal<Map<String,SrlResyncRequestWrapper>> resyncThreadLocal=new ThreadLocal<>();
    final SourceData sourceData = new SourceData(SourceType.other, ModelFdn.decode("fdn:app:resync"));
    private final static String SYNC_ENDPOINT_PATH = "/nsp-sync:sites/elan-site/endpoint";
    private final static String OPER_ENDPOINT_PATH = "/nsp-service:services/service-layer/elan/endpoint";
    private final static String SYNC_ENDPOINT_PATH_IP_DETAILS = "/nsp-sync:sites/elan-site/endpoint/ipservice-endpoint-detail";
    private final static String OPER_ENDPOINT_PATH_IP_DETAILS = "/nsp-service:services/service-layer/elan/endpoint/ipservice-endpoint-detail";
    static String fieldFilterRequestJson = "{\"index\":null,\"type\":null,\"admin-state\":null,\"name\":null,\"oper-state\":null,\"description\":null,\"srl_nokia-interfaces-vlans:vlan\":{\"encap\":{\"single-tagged\":{\"vlan-id\":null},\"untagged\":{}}}}";
    static HashMap fieldFilterMap =  new HashMap();

    public  int getDeviceMaxDepth(DeviceResyncClass aInDeviceClass,String aInNodeType,String aInNodeVersion)
    {
        if(aInDeviceClass.getDeviceClassPath().equals(SRL_NOKIA_INTERFACES_INTERFACE_SUBINTERFACE)) {
            return 3;
        } else{
            return 1;
        }
    }
    //needs to be handled
    @Override
    public boolean isHandleRootDevice(DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, ISaveTaskInfo aInISaveTaskInfo, DeviceInfo aInDeviceInfo) {
        return true;
    }

    //full resync
    @Override
    public void handleRootDevice(IYangPath aInIYangPath, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, Object aInDeviceObject, ISaveTaskInfo aInISaveTaskInfo, DeviceInfo aInDeviceInfo, IReadObjects aInIReadObjects, List<IYangObject> aOutProcessedObjects) {

        long startTime = System.currentTimeMillis();
        String lDevicePath = aInDeviceClass.getDeviceClassPath();
        IYangDB lYangDB = aInISaveTaskInfo.getIMDMPluginMdResyncProvider().getiMdResyncFw().getIYangDB();
        String lNeId = aInISaveTaskInfo.getNeId();
        Map lDeviceObject = (Map) aInDeviceObject;
        Object lDevFdn = (lDeviceObject).get("_fdn_");
        String lElanIfFdn = getDevObjFdn(lDeviceObject);
        String iterfaceName = getIfNameFromIfFdn(lElanIfFdn);
        handleRootDeviceLogger.info("lElanIfFdn: " + lElanIfFdn);
        handleRootDeviceLogger.debug("handleRootDevice : Filter response for endpoint {} on siteId : {} response {}  ",lDevFdn,lNeId,aInDeviceObject);

        if (lDevicePath.contains("/network-instance/interface") && null != iterfaceName && !iterfaceName.startsWith("irb")) {
            Map<String,Object> map = new HashMap<>();
            String interfaceId =  getIfNameFromIfFdn((String) ((Map)lDevFdn).get("fdn"));
            String endpointId = lNeId + "-" + interfaceId;
            //String lSyncEndpointPath = "/nsp-sync:sites/elan-site/endpoint[site-id='" + lNeId + "'][endpointid='" + endpointId + "']";

            map.put("site-id",lNeId);
            map.put("endpoint-id",endpointId);
            IYangObject lReadEpYo = aInIReadObjects.removeBaseOnParams(map);
            String lEndpointSource = Utils.buildSourceFdn((Map)lDevFdn, lNeId, true);
            //IYangObject lReadEpYo = aInIReadObjects.removeBasedOnSource(lEndpointSource);

            if(lReadEpYo == null){ // Given endpoint is not present in  Operational DB
                IYangObject lAlternativeReadObject = aInIReadObjects.getAlternativeReadObjects().removeBaseOnParams(map);
                if (null == lAlternativeReadObject) { // Given endpoint is not present in  Operational DB
                    //String lElanIfFdn = getDevObjFdn(lDeviceObject);
                    String lCreatedEpId = null;
                    lCreatedEpId = createEndpoint(lYangDB, lNeId, lElanIfFdn); //see if Oper site is present then create endpoint
                    if (null == lCreatedEpId) {
                        createSyncEndpoint(lYangDB, lNeId, lElanIfFdn, lEndpointSource); //see if Sync site is present then create endpoint
                    }
                }
            } else {
                aOutProcessedObjects.add(lReadEpYo);
            }
        } else if (lDevicePath.equals(SRL_NOKIA_INTERFACES_INTERFACE_SUBINTERFACE) && null != iterfaceName && !iterfaceName.startsWith("irb")) {
            //go thru the each unit,
            //find end-points from   aInIReadObjects , find it update it
            //if not find above, find out service-site, not find it, then ignore it.
            String lDeviceObjFdnStr = getDevObjFdn((Map) aInDeviceObject);
            String lIfNameStr = lDeviceObjFdnStr.substring(lDeviceObjFdnStr.indexOf("name"));
            String lIfName = lIfNameStr.substring(6, lIfNameStr.indexOf("]") - 1);
            if (handleRootDeviceLogger.isDebugEnabled()) {
                handleRootDeviceLogger.debug("lIfName: " + lIfName);
            }

            String sbIfidx = getSubIfNameFromIfFdn(lDeviceObjFdnStr);
            String lEpEndpointId = lNeId + "-" + lIfName + "." +sbIfidx;
            if (updateSyncEndpointLogger.isDebugEnabled()) {
                updateSyncEndpointLogger.debug("lEpEndpointId: " + lEpEndpointId);
            }

            Map<String,Object> map = new HashMap<>();
            //String lSyncEndpointPath = "/nsp-sync:sites/elan-site/endpoint[site-id='" + lNeId + "'][endpointid='" + endpointId + "']";

            map.put("site-id",lNeId);
            map.put("endpoint-id",lEpEndpointId);
            IYangObject lReadEpYo = aInIReadObjects.removeBaseOnParams(map);
            if(lReadEpYo == null){ // Given endpoint is not present in  Operational DB
                IReadObjects lAlternativeReadObjects = aInIReadObjects.getAlternativeReadObjects();
                if (null != lAlternativeReadObjects) {
                    IYangObject yangObject = lAlternativeReadObjects.removeBaseOnParams(map);
                    if(yangObject == null){  // Given endpoint is not present in  Sync DB
                        IYangObject  lExistEp = findElanEndpoint(lYangDB, lEpEndpointId,OPER_ENDPOINT_PATH);
                        if (null != lExistEp){
                            updateEndpoint(lYangDB, lExistEp, lDeviceObject, lNeId, lEpEndpointId);
                        } else {
                            updateSyncEndpointDetails(lYangDB, lNeId, aInDeviceObject, lEpEndpointId);
                        }
                    } else {
                        updateSyncEndpointDetails(lYangDB, lNeId, aInDeviceObject, lEpEndpointId);
                    }
                } else {  //there is no Sync end points
                    IYangObject  lExistEp = findElanEndpoint(lYangDB, lEpEndpointId,OPER_ENDPOINT_PATH);
                    if (null != lExistEp){
                        updateEndpoint(lYangDB, lExistEp, lDeviceObject, lNeId, lEpEndpointId);
                    }  else {
                        updateSyncEndpointDetails(lYangDB, lNeId, aInDeviceObject, lEpEndpointId);
                    }
                }
            } else {
                aOutProcessedObjects.add(lReadEpYo);
                updateEndpoint(lYangDB, lReadEpYo, lDeviceObject, lNeId, lEpEndpointId);
            }
        }
        if (handleRootDeviceLogger.isDebugEnabled()) {
            handleRootDeviceLogger.debug("It took [{}] ms to handle " + lDevicePath, (System.currentTimeMillis() - startTime));
        }
    }

    private void createSyncEndpoint (IYangDB aInYangDB, String aInNeId, String aInDevIfFdn, String aInEndpointSource) {
        String lSiteName = getSiteNameFromIfFdn(aInDevIfFdn);
        String lSyncSitePathToSearch = "/nsp-sync:sites/elan-site[site-id='" +
                aInNeId + "'][name='" + lSiteName + "']";
        if (createSyncEndpointLogger.isDebugEnabled()) {
            createSyncEndpointLogger.debug("lSyncSitePathToSearch: " + lSyncSitePathToSearch);
        }
        IYangObject lSyncSiteYo = aInYangDB.getSingle(lSyncSitePathToSearch);

        if (null != lSyncSiteYo) {
            QueryParameters lQueryParams = getlQueryParams();
            String lEpName = getIfNameFromIfFdn(aInDevIfFdn);
            String lEpEndpointId = aInNeId + "-" + lEpName;
            String lEPPath = "/nsp-sync:sites/elan-site[site-id='" + aInNeId + "'][name='" + lSiteName +
                    "']/endpoint[endpoint-id='" + lEpEndpointId + "']";
            if (createSyncEndpointLogger.isDebugEnabled()) {
                createSyncEndpointLogger.debug("lEPPath: " + lEPPath);
            }
            IYangObject lExistSyncEpYo = aInYangDB.getSingle(lEPPath);
            if (null == lExistSyncEpYo) {
                Map<String, Object> lSyncEpProps = new HashMap<String, Object>();
                lSyncEpProps.put("name", lEpName);
                lSyncEpProps.put("endpoint-id", lEpEndpointId);
                lSyncEpProps.put("site-id", aInNeId);

                YangObject lSyncEpYo = new YangObject(lSyncEpProps);
                List lSources = new ArrayList();
                lSources.add(aInEndpointSource);
                lSyncEpYo.addExtraData("sources", lSources);
                IYangObject lCreatedSyncEpYo = aInYangDB.createChild(lSyncSiteYo.getIdentifier(), "endpoint", lSyncEpYo, sourceData, lQueryParams);
                //if (createSyncEndpointLogger.isDebugEnabled()) {
                createSyncEndpointLogger.info("lCreatedSyncEpYo: " + lCreatedSyncEpYo.getIdentifier());
                //}
            }
        }
    }

    private IYangObject findElanEndpoint(IYangDB aInYangDB, String aInEndpointId,String parentPath) {
        QueryParameters lQueryParams= getlQueryParams();
        lQueryParams.setDepth(2);
        lQueryParams.getIExecutionContext().addExtraParameter("return-light-data", true);
        String lPathToSearch= parentPath + "[endpoint-id='" + aInEndpointId + "']";
        IYangObject lEndpointYo = aInYangDB.getSingle(lPathToSearch, lQueryParams);

        return lEndpointYo;
    }

    private  Map<String, Object> getVlanData (Map<String, Object> aInUnitObjMap,String aInNeId) {
        Map<String, Object> lVlanData = null;
        String lUnitVcId = null;
        if (null != aInUnitObjMap.get("srl_nokia-interfaces-vlans:vlan")) {
            Map temp = (LinkedHashMap) aInUnitObjMap.get("srl_nokia-interfaces-vlans:vlan");
            if (temp.containsKey("encap")) {
                temp = (LinkedHashMap)temp.get("encap");
                if (temp.containsKey("single-tagged")) {
                    temp = (LinkedHashMap) temp.get("single-tagged");
                    if(temp.containsKey("vlan-id")){
                        lVlanData = new HashMap<>();
                        lUnitVcId = String.valueOf(temp.get("vlan-id"));
                        if(null != lUnitVcId && lUnitVcId.equals("any")){
                            lUnitVcId = "4095";
                        }
                        lVlanData.put("@",getNspModelSources(temp,aInNeId));
                    }
                } else if(temp.containsKey("untagged")){
                    lVlanData = new HashMap<>();
                    lUnitVcId = "0";
                    lVlanData.put("@",getNspModelSources((Map)temp.get("untagged"),aInNeId));
                }
            }
        }

        String lEncapTypeStr = "null-encap";
        if (null != lUnitVcId) {
            lVlanData.put("inner-tag", -1);
            int outerVlanId = Integer.parseInt(lUnitVcId);
            lVlanData.put("outer-tag", outerVlanId);
            if(outerVlanId > 0) {
                lEncapTypeStr = "q-encap";
            }
            lVlanData.put("encap-type", lEncapTypeStr);
        }

        return lVlanData;
    }

    private  Map<String, Object> getTaggedVlan(Map<String, Object> aInUnitObjMap,String aInNeId,String lDevicePath) {
        Map<String, Object> lVlanData = null;
        String lUnitVcId = null;
        Map temp;
        if (lDevicePath.equals("srl_nokia-interfaces:/interface/subinterface/srl_nokia-interfaces-vlans:vlan/encap/single-tagged")) {
            if (aInUnitObjMap.containsKey("vlan-id")) {
                lVlanData = new HashMap<>();
                lUnitVcId = String.valueOf(aInUnitObjMap.get("vlan-id"));
                lVlanData.put("@", getNspModelSources(aInUnitObjMap, aInNeId));
            }
        } else if (lDevicePath.equals("srl_nokia-interfaces:/interface/subinterface/srl_nokia-interfaces-vlans:vlan/encap/untagged")) {
            lVlanData = new HashMap<>();
            lUnitVcId = "0";
            lVlanData.put("@", getNspModelSources( aInUnitObjMap, aInNeId));
        }

        String lEncapTypeStr = "null-encap";
        if (null != lUnitVcId) {
            lVlanData.put("inner-tag", -1);
            int outerVlanId = Integer.parseInt(lUnitVcId);
            lVlanData.put("outer-tag", outerVlanId);
            if(outerVlanId > 0) {
                lEncapTypeStr = "q-encap";
            }
            lVlanData.put("encap-type", lEncapTypeStr);
        }
        return lVlanData;
    }

    @Override
    public void handlePartialDeviceResyncClass(ISaveTaskInfo aInISaveTaskInfo, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, Map<String, Object> aInDeviceObject, String aInNeId, IMDMPluginMdResyncProvider aInMdResyncFw, DeviceInfo aInDeviceInfo, IPartialResyncContext aInIPartialResyncContext) {
        //handle update, specific resync
        String lDevicePath = aInDeviceClass.getDeviceClassPath();
        IYangDB lYangDB = aInISaveTaskInfo.getIMDMPluginMdResyncProvider().getiMdResyncFw().getIYangDB();

        if (handlePartialDeviceResyncClassLogger.isDebugEnabled()) {
            handlePartialDeviceResyncClassLogger.debug("DevicePath: " + lDevicePath);
        }

        String lElanIfFdn = getDevObjFdn(aInDeviceObject);
        String iterfaceName = getIfNameFromIfFdn(lElanIfFdn);
        handlePartialDeviceResyncClassLogger.info("lElanIfFdn: " + lElanIfFdn);

        if(lDevicePath.contains("/network-instance/interface") && null != iterfaceName && !iterfaceName.startsWith("irb")) {
            //String lElanIfFdn = getDevObjFdn(aInDeviceObject);
            if (handlePartialDeviceResyncClassLogger.isDebugEnabled()) {
                handlePartialDeviceResyncClassLogger.debug("lElanIfFdn: " + lElanIfFdn);
                handlePartialDeviceResyncClassLogger.debug("Filter response for endpoint {} on siteId : {} response {}  ",lElanIfFdn,aInNeId,aInDeviceObject);
            }
            IYangObject  lExistEp = getEndpoint(aInISaveTaskInfo, lYangDB,  aInNeId, lElanIfFdn,OPER_ENDPOINT_PATH);
            if (null == lExistEp)  {
                String lCreatedEpId = createEndpoint(lYangDB, aInNeId, lElanIfFdn);
                handlePartialDeviceResyncClassLogger.debug(" handlePartialDeviceResyncClass created endpoint for neId : {}  corresponding  Resync class :  {}",aInNeId,aInDeviceClass,aInNspClass);
                if (null == lCreatedEpId) {
                    String lEndpointSource = Utils.buildSourceFdn((Map)aInDeviceObject.get("_fdn_"), aInNeId, true);
                    createSyncEndpoint(lYangDB, aInNeId, lElanIfFdn, lEndpointSource);
                }
            } else {
                updateServiceEndpoint(lYangDB, aInNeId, lElanIfFdn, lExistEp);
            }
        } else if(lDevicePath.contains("/interface/subinterface") && null != iterfaceName && !iterfaceName.startsWith("irb")) {
            String lIfName = getIfNameFromUnitInfo(aInDeviceObject);
            if (handlePartialDeviceResyncClassLogger.isDebugEnabled()) {
                handlePartialDeviceResyncClassLogger.debug("lIfName: " + lIfName);

            }
            String lUnitName;
            String interfaceName = (String)aInDeviceObject.get("name");
            if (!interfaceName.contains(".")) {
                lUnitName = (String) aInDeviceObject.get("name");
            } else {
                lUnitName = ((String) interfaceName).substring(((String) interfaceName).indexOf(".") + 1);
            }
            if (handlePartialDeviceResyncClassLogger.isDebugEnabled()) {
                handlePartialDeviceResyncClassLogger.debug("lUnitName: " + lUnitName);
            }

            String lEndpointId ;
            lEndpointId =aInNeId + "-" + lIfName + "." + lUnitName;
            handlePartialDeviceResyncClassLogger.debug("Filter response for endpoint {} on siteId : {} response {}  ",lEndpointId,aInNeId,aInDeviceObject);
            IYangObject  lExistEp = findElanEndpoint(lYangDB, lEndpointId,OPER_ENDPOINT_PATH);
            IYangObject  lExistSyncEpYo = findElanEndpoint(lYangDB, lEndpointId,SYNC_ENDPOINT_PATH);
            if (null != lExistEp) {
                updateEndpoint (lYangDB, lExistEp, aInDeviceObject, aInNeId, lEndpointId);
            } else if(null != lExistSyncEpYo){
                updateSyncEndpointDetails(lYangDB,aInNeId,aInDeviceObject,lEndpointId);
            }
        }
    }

    private String convertAdminState(Object aInDeviceObject) {
        Map lDeviceObject = (Map) aInDeviceObject;
        String adminState = (String)lDeviceObject.get("admin-state");
        if (null != adminState) {
            if(adminState.equals("enable")){
                return "unlocked";
            } else if(adminState.equals("disable")){
                return "locked";
            }
        }
        return "unknown";
    }

    private String convertOperState(Object aInDeviceObject) {
        Map lDeviceObject = (Map) aInDeviceObject;
        String operState = (String)lDeviceObject.get("oper-state");
        if (null != operState) {
            if(operState.equals("up")){
                return "enabled";
            } else if(operState.equals("down")){
                return "disabled";
            }
        }

        return "unknown";
    }

    private String getIfNameFromUnitInfo(Map<String, Object> aInDeviceObject) {
        String  lUnitObjFdn = getDevObjFdn(aInDeviceObject);
        String lIfName = lUnitObjFdn.substring((lUnitObjFdn.indexOf("interface[name='") + 16), lUnitObjFdn.indexOf("']"));

        return lIfName;
    }

    private String getDevObjFdn(Map<String, Object> aInDeviceObject) {
        Object lDevObjFdn = aInDeviceObject.get("_fdn_");
        Map<String, Object> lDevObjFdnMap = new HashMap<>();
        lDevObjFdnMap.putAll((Map) lDevObjFdn);
        String lDevObjFdnStr = (String) lDevObjFdnMap.get("fdn");

        return lDevObjFdnStr;
    }

    private IYangObject getEndpoint(ISaveTaskInfo aInISaveTaskInfo, IYangDB aInYangDB,  String aInNeId, String aInDevIfFdn,String xpath) {
        IYangNode lEpYangNode = aInISaveTaskInfo.getIMDMPluginMdResyncProvider().getiMdResyncFw().getIYangMeta().findNode(xpath);

        List<String> lSources0 = new ArrayList<>();
        String lSvcEpSrc = "fdn:model:mdm:" + aInNeId + ":"  + aInDevIfFdn;
        lSources0 = new ArrayList<>(1);
        lSources0.add(lSvcEpSrc);
        QueryParameters lQueryParams0 = getlQueryParams();
        lQueryParams0.getIExecutionContext().addExtraParameter("sources:" + lEpYangNode.getQName(), lSources0);
        IYangObject lEpYo = aInYangDB.getSingle(lEpYangNode.getPathString(), lQueryParams0);

        return lEpYo;
    }

    private IYangObject findElanSite(IYangDB aInYangDB, String aInNeId, String aInSiteName) {
        QueryParameters lQueryParams= new QueryParameters();
        IExecutionContext lExecutionContext = new ExecutionContext(null, null, true, false);
        lQueryParams.setIExecutionContext(lExecutionContext);
        lQueryParams.setDepth(2);
        lQueryParams.getIExecutionContext().addExtraParameter("return-light-data", true);
        String lPathToSearch="/nsp-service:services/service-layer/elan/site[site-id='" + aInNeId + "'][name='" + aInSiteName + "']";
        IYangObject lSiteYo = aInYangDB.getSingle(lPathToSearch, lQueryParams);
        return lSiteYo;
    }

    private String getSiteNameFromIfFdn(String aInDevIfFdn) {
        String lElanSiteName = aInDevIfFdn.substring((aInDevIfFdn.indexOf("instance[name='") + 15), aInDevIfFdn.indexOf("']"));
        return lElanSiteName;
    }

    private String getIfNameFromIfFdn(String aInDevIfFdn) {
        String lElanIfName = aInDevIfFdn.substring((aInDevIfFdn.lastIndexOf("interface[name='") + 16), aInDevIfFdn.lastIndexOf("']"));
        return lElanIfName;
    }
    private String getSubIfNameFromIfFdn(String aInDevIfFdn) {
        String lElanSubIfName = aInDevIfFdn.substring((aInDevIfFdn.lastIndexOf("subinterface[index='") + 20), aInDevIfFdn.lastIndexOf("']"));
        return lElanSubIfName;
    }

    private String createEndpoint (IYangDB aInYangDB, String aInNeId, String aInDevIfFdn) {
        String lEpId = null;
        String lElanSiteName = getSiteNameFromIfFdn(aInDevIfFdn);
        String lElanIfName = getIfNameFromIfFdn(aInDevIfFdn);
        IYangObject lSiteYo = findElanSite(aInYangDB, aInNeId, lElanSiteName);

        if (null != lSiteYo) {
            if (createEndpointLogger.isDebugEnabled()) {
                createEndpointLogger.debug("lSiteYo: " + lSiteYo.getIdentifier());
            }
            String lSvcIdent = lSiteYo.getIdentifier().substring(0, lSiteYo.getIdentifier().lastIndexOf("/site"));
            if (createEndpointLogger.isDebugEnabled()) {
                createEndpointLogger.debug("lSvcIdent: " + lSvcIdent);
            }
            IYangObject lSvcYo = aInYangDB.getSingle(lSvcIdent);

            YangObject lEndpointYo = new YangObject();
            QueryParameters lEpQueryParams = new QueryParameters();

            lEndpointYo.setProperty("site", lSiteYo.getIdentifier());
            lEndpointYo.setProperty("site-id", aInNeId);
            lEndpointYo.setProperty("site-name", lSiteYo.getProperty("name"));
            lEndpointYo.setProperty("service", lSvcYo.getIdentifier());
            lEndpointYo.setProperty("service-name", lSvcYo.getProperty("name"));
            lEndpointYo.setProperty("type", "service-access-point");
            lEndpointYo.setProperty("name", lElanIfName);
            lEndpointYo.setProperty("endpoint-id", aInNeId + "-" + lElanIfName);
            lEndpointYo.setClassId("/nsp-service:services/service-layer/elan/nsp-service:endpoint");

            Map<String,Object> endpointExtension = new HashMap<>();
            endpointExtension.put("site-id",aInNeId);
            endpointExtension.put("ne-name",SrlElanResyncHandler.getNeNameByIdFromCache(aInNeId,lEpQueryParams,aInYangDB));
            lEndpointYo.setProperty("service-extension:elan-endpoint",endpointExtension);

            String lEpMdmFdn = "fdn:model:mdm:" + aInNeId + ":" + aInDevIfFdn;
            List<String> lEpSources = new ArrayList<>(1);
            lEpSources.add(lEpMdmFdn);
            lEndpointYo.addExtraData("sources", lEpSources);
            // createEndpointLogger.info("creating endpoint "+lElanIfName);
            final SourceData sourceData = new SourceData(SourceType.other, ModelFdn.decode("fdn:app:resync"));

            IExecutionContext lEpExecutionContext = new ExecutionContext(null, null, true, false);
            lEpQueryParams.setIExecutionContext(lEpExecutionContext);
            lEpQueryParams.setParentId(((YangObject) lSvcYo).getExtraData());
            lEpQueryParams.getIExecutionContext().addExtraParameter("return-light-data", true);
            lEpQueryParams.getIExecutionContext().addExtraParameter("db-id:" + lSvcYo.getIdentifier(), ((YangObject) lSvcYo).getExtraData());
            lEpQueryParams.getIExecutionContext().addExtraParameter("db-id:" + lSiteYo.getIdentifier(), ((YangObject) lSiteYo).getExtraData());
            IYangObject lEpYoCreated = aInYangDB.createChild(lSvcYo.getIdentifier(), "endpoint", lEndpointYo, sourceData, lEpQueryParams);
            lEpQueryParams.setParentId(null);
            lEpQueryParams.getIExecutionContext().extraFlags().remove("return-light-data");
            lEpId = lEpYoCreated.getIdentifier();

            // updateEndpointsInSite
            ArrayList lEndpoints = new ArrayList<>();
            lEndpoints.add(lEpYoCreated.getIdentifier());
            //if (createEndpointLogger.isDebugEnabled()) {
            createEndpointLogger.info("lEpYoCreated: " + lEpYoCreated.getIdentifier());
            //}
            Object lEndpointObj = lSiteYo.getProperty("endpoint");
            if (lEndpointObj != null && lEndpointObj instanceof ArrayList) {
                lEndpoints.addAll(((ArrayList) lEndpointObj));
            }
            IYangObject lSiteUpdateYo = new YangObject();
            lSiteUpdateYo.setProperty("endpoint", lEndpoints);
            aInYangDB.update(lSiteYo.getIdentifier(), lSiteUpdateYo, lEpQueryParams);
        }
        return lEpId;
    }

    private void updateServiceEndpoint (IYangDB aInYangDB, String aInNeId, String aInDevIfFdn, IYangObject  aInExistEp) {
        String lEpId = null;
        String lElanSiteName = getSiteNameFromIfFdn(aInDevIfFdn);
        String lElanIfName = getIfNameFromIfFdn(aInDevIfFdn);
        IYangObject lSiteYo = findElanSite(aInYangDB, aInNeId, lElanSiteName);
        if (null != lSiteYo) {
            if (updateServiceEndpointLogger.isDebugEnabled()) {
                updateServiceEndpointLogger.debug("lSiteYo: " + lSiteYo.getIdentifier());
            }
            String lSvcIdent = lSiteYo.getIdentifier().substring(0, lSiteYo.getIdentifier().lastIndexOf("/site"));
            if (updateServiceEndpointLogger.isDebugEnabled()) {
                updateServiceEndpointLogger.debug("lSvcIdent: " + lSvcIdent);
            }
            IYangObject lSvcYo = aInYangDB.getSingle(lSvcIdent);
            YangObject lEndpointYo = new YangObject();
            QueryParameters lEpQueryParams = new QueryParameters();

            lEndpointYo.setProperty("site", lSiteYo.getIdentifier());
            lEndpointYo.setProperty("site-id", aInNeId);
            lEndpointYo.setProperty("site-name", lSiteYo.getProperty("name"));
            lEndpointYo.setProperty("service", lSvcYo.getIdentifier());
            lEndpointYo.setProperty("service-name", lSvcYo.getProperty("name"));
            lEndpointYo.setProperty("type", "service-access-point");
            lEndpointYo.setProperty("name", lElanIfName);
            lEndpointYo.setProperty("endpoint-id", aInNeId + "-" + lElanIfName);
            lEndpointYo.setClassId("/nsp-service:services/service-layer/elan/nsp-service:endpoint");

            Map<String,Object> endpointExtension = new HashMap<>();
            endpointExtension.put("site-id",aInNeId);
            endpointExtension.put("ne-name",SrlElanResyncHandler.getNeNameByIdFromCache(aInNeId,lEpQueryParams,aInYangDB));
            lEndpointYo.setProperty("service-extension:elan-endpoint",endpointExtension);

            String lEpMdmFdn = "fdn:model:mdm:" + aInNeId + ":" + aInDevIfFdn;
            List<String> lEpSources = new ArrayList<>(1);
            lEpSources.add(lEpMdmFdn);
            lEndpointYo.addExtraData("sources", lEpSources);
            //createEndpointLogger.info("creating endpoint "+lElanIfName);
            final SourceData sourceData = new SourceData(SourceType.other, ModelFdn.decode("fdn:app:resync"));

            IExecutionContext lEpExecutionContext = new ExecutionContext(null, null, true, false);
            lEpQueryParams.setIExecutionContext(lEpExecutionContext);
            lEpQueryParams.setParentId(((YangObject) aInExistEp).getExtraData());
            lEpQueryParams.getIExecutionContext().addExtraParameter("return-light-data", true);
            lEpQueryParams.getIExecutionContext().addExtraParameter("db-id:" + aInExistEp.getIdentifier(), ((YangObject) aInExistEp).getExtraData());
            lEpQueryParams.getIExecutionContext().addExtraParameter("db-id:" + aInExistEp.getIdentifier(), ((YangObject) aInExistEp).getExtraData());
            // IYangObject lEpYoCreated = aInYangDB.createChild(lSvcYo.getIdentifier(), "endpoint", lEndpointYo, sourceData, lEpQueryParams);
            aInYangDB.update(aInExistEp.getIdentifier(), lEndpointYo, lEpQueryParams);
            updateServiceEndpointLogger.info("updated endpoint "+lElanIfName);
        }
    }

    private Map<String, Object> getNspModelSources(Map<String, Object> aInUnitObjMap,String aInNeId) {
        Object lUnitFdn = aInUnitObjMap.get("_fdn_");
        List<String> lSources = new ArrayList<>();
        String lUnitSource = Utils.buildSourceFdn((Map) lUnitFdn, aInNeId, true);
        lSources.add(lUnitSource);
        Map<String, Object> lMetaData = new HashMap<>();
        lMetaData.put("nsp-model:sources", lSources);
        return lMetaData;
    }

    private void updateEndpoint (IYangDB aInYangDB, IYangObject aInEndpointYo, Map<String, Object> aInUnitObjMap, String aInNeId, String aInIfName) {
        String lEpPath = aInEndpointYo.getIdentifier();
        Map<String, Object> lUpdateEpMap = new HashMap<>();

        if(aInUnitObjMap.get("admin-state") != null) {
            String adminState = convertAdminState(aInUnitObjMap);
            lUpdateEpMap.put("admin-state", adminState);
        }
        if(aInUnitObjMap.get("oper-state") != null) {
            String operState = convertOperState(aInUnitObjMap);
            lUpdateEpMap.put("oper-state", operState);
        }
        if(aInUnitObjMap.containsKey("description")) {
            lUpdateEpMap.put("description", aInUnitObjMap.get("description"));
        }
        lUpdateEpMap.put("type", "service-access-point");
        String lIfName = aInIfName.substring(aInIfName.indexOf("-") + 1);
        lUpdateEpMap.put("name", lIfName);
        lUpdateEpMap.put("@", getNspModelSources(aInUnitObjMap, aInNeId));

        Map<String, Object> lIedUpdateMap = getVlanData(aInUnitObjMap,aInNeId);
        if( null != lIedUpdateMap) {
            lUpdateEpMap.put("ipservice-endpoint-detail", lIedUpdateMap);
        }

        YangObject lEpUpdateYo = new YangObject(lUpdateEpMap);
        // port-binding
        String lPortId = lIfName.split("\\.")[0];
        QueryParameters lQueryParameters = new QueryParameters();
        lQueryParameters.setDepth(2);
        ArrayList<Field> lFieldList = new ArrayList<>();
        lFieldList.add(new Field("name"));
        Fields lFields = new Fields(lFieldList);
        lQueryParameters.setFields(lFields);
        String lPortFdn = "/nsp-equipment:network/network-element[ne-id='" + aInNeId + "']/hardware-component/port[name='" + lPortId + "']";
        String lClassName="equipment.Equipment";
        List<IYangObject> lYangEquipList = aInYangDB.getMany(lPortFdn, lQueryParameters);
        if  (null == lYangEquipList || lYangEquipList.isEmpty()) {
            lPortFdn = "/nsp-equipment:network/network-element[ne-id='" + aInNeId + "']/lag[name='" + lPortId + "']";
            lClassName="equipment.Lag";
            lYangEquipList = aInYangDB.getMany(lPortFdn, lQueryParameters);
        }
        if (null != lYangEquipList && lYangEquipList.size() == 1) {
            IYangObject lYangPort = lYangEquipList.get(0);
            String lPortIdent = lYangPort.getIdentifier();
            HashMap lPortBdgMap = new HashMap();
            lPortBdgMap.put("name", lPortId);
            lPortBdgMap.put("resource", lPortIdent);
            lPortBdgMap.put("class-name", lClassName);
            lPortBdgMap.put("admin-state", convertAdminState(aInUnitObjMap));
            lPortBdgMap.put("oper-state", convertOperState(aInUnitObjMap));
            Collection lCollection = new ArrayList();
            lCollection.add(lPortBdgMap);
            lEpUpdateYo.setProperty("port-bindings", lCollection);
            if (updateEndpointLogger.isDebugEnabled()) {
                updateEndpointLogger.debug("lPortIdent: " + lPortFdn);
            }
        }

        QueryParameters updateQps = getlQueryParams();
        aInYangDB.update(lEpPath, lEpUpdateYo, sourceData, updateQps);
        updateEndpointLogger.info("updating Operational endpoint on  aNeId {} EndpointId {} ",aInNeId,aInIfName);
    }
    private void updateEndpointIpDetails (IYangDB aInYangDB, IYangObject aInEndpointYo, Map<String, Object> aInUnitObjMap, String aInNeId,String lDevicePath) {
        Map<String, Object> lUpdateEpMap = new HashMap<>();
        Map<String, Object> lIedUpdateMap = getTaggedVlan(aInUnitObjMap,aInNeId, lDevicePath);
        if(null != lIedUpdateMap) {
            lUpdateEpMap.put("ipservice-endpoint-detail", lIedUpdateMap);
            QueryParameters updateQps = getlQueryParams();
            YangObject lEpUpdateYo = new YangObject(lUpdateEpMap);
            aInYangDB.update(aInEndpointYo.getIdentifier(), lEpUpdateYo, sourceData, updateQps);
        }
    }

    private void updateSyncEndpointDetails(IYangDB aInYangDB, String aInNeId, Object aInDeviceObject, String  lEpEndpointId) {

        IYangObject lExistSyncEpYo = findElanEndpoint(aInYangDB, lEpEndpointId,SYNC_ENDPOINT_PATH);
        if (null != lExistSyncEpYo) {
            Map lDeviceObject = (Map) aInDeviceObject;
            String ifDescription = (String) lDeviceObject.get("description");
            Map<String, Object> lSyncEpUpdateProps = new HashMap<String, Object>();
            if(lDeviceObject.get("admin-state") != null) {
                String adminState = convertAdminState(aInDeviceObject);
                lSyncEpUpdateProps.put("admin-state", adminState);
            }
            if(lDeviceObject.get("oper-state") != null) {
                String operState = convertOperState(aInDeviceObject);
                lSyncEpUpdateProps.put("oper-state", operState);
            }
            if(lDeviceObject.containsKey("description")) {
                lSyncEpUpdateProps.put("description", ifDescription);
            }
            lSyncEpUpdateProps.put("@",getNspModelSources((Map)aInDeviceObject,aInNeId));
            QueryParameters updateQps = getlQueryParams();
            Map<String, Object> lSyncIedUpdateMap = getVlanData((Map) aInDeviceObject,aInNeId);
            if( null != lSyncIedUpdateMap) {
                lSyncEpUpdateProps.put("ipservice-endpoint-detail", lSyncIedUpdateMap);
            }
            YangObject lSyncEpUpdateYo = new YangObject(lSyncEpUpdateProps);
            aInYangDB.update(lExistSyncEpYo.getIdentifier(), lSyncEpUpdateYo, updateQps);
            updateSyncEndpointLogger.info("updateSyncEndpointDetails aNeId {} Endpoint {} ",aInNeId,lEpEndpointId);
        }
    }

    @Override
    public void handleUpdate(ISaveTaskInfo aInISaveTaskInfo, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, Map<String, Object> aInDeviceObject, String aInNeId, IMDMPluginMdResyncProvider aInMdResyncFw, DeviceInfo aInDeviceInfo) {
        //update notification from mdm-notification
        //need to check interface or unit.
        IYangDB lYangDB = aInISaveTaskInfo.getIMDMPluginMdResyncProvider().getiMdResyncFw().getIYangDB();
        String lDevicePath = aInDeviceClass.getDeviceClassPath();

        String lElanIfFdn = getDevObjFdn(aInDeviceObject);
        String iterfaceName = getIfNameFromIfFdn(lElanIfFdn);
        if(lDevicePath.contains("/network-instance/interface") && null != iterfaceName && !iterfaceName.startsWith("irb")) {
            //String lElanIfFdn = getDevObjFdn(aInDeviceObject);
            if (handleUpdateLogger.isDebugEnabled()) {
                handleUpdateLogger.debug("lElanIfFdn: " + lElanIfFdn);
            }
            IYangObject  lExistEp = getEndpoint(aInISaveTaskInfo, lYangDB,  aInNeId, lElanIfFdn,OPER_ENDPOINT_PATH);
            if (null == lExistEp)  {
                String lCreatedEpId = createEndpoint(lYangDB, aInNeId, lElanIfFdn);
                //handleUpdateLogger.info("lCreatedEpId {} for neId : {}",lCreatedEpId,aInNeId);
                if (null == lCreatedEpId) { // Endpoint are not present for operational service, have to look in sync tables
                    handleUpdateLogger.info("Creating Sync endpoint for neId : {}",aInNeId);
                    String lEndpointSource = Utils.buildSourceFdn((Map)aInDeviceObject.get("_fdn_"), aInNeId, true);
                    lExistEp = getEndpoint(aInISaveTaskInfo,lYangDB, aInNeId, lElanIfFdn,SYNC_ENDPOINT_PATH);
                    if(null == lExistEp) {
                        createSyncEndpoint(lYangDB, aInNeId, lElanIfFdn, lEndpointSource);
                        triggerPartialResyncForSecondaryDeviceClasspath(aInDeviceClass, aInNspClass, aInNeId, aInMdResyncFw, aInDeviceInfo, lElanIfFdn);
                    } else {
                        //updateSyncEndpoint();
                    }
                } else {
                    triggerPartialResyncForSecondaryDeviceClasspath(aInDeviceClass, aInNspClass, aInNeId, aInMdResyncFw, aInDeviceInfo, lElanIfFdn);
                }
            } else{
                //updateServiceEndpoint(lYangDB, aInNeId, lElanIfFdn, lExistEp);
            }
        } else if(lDevicePath.equals(SRL_NOKIA_INTERFACES_INTERFACE_SUBINTERFACE) && null != iterfaceName && !iterfaceName.startsWith("irb")) {
            String lIfName = getIfNameFromUnitInfo(aInDeviceObject);
            if (handleUpdateLogger.isDebugEnabled()) {
                handleUpdateLogger.debug("lIfName: " + lIfName);
            }
            String lUnitName =  getSubIfNameFromIfFdn(getDevObjFdn(aInDeviceObject));
            if (handleUpdateLogger.isDebugEnabled()) {
                handleUpdateLogger.debug("lUnitName: " + lUnitName);
            }

            String lEndpointId ;
            lEndpointId = aInNeId + "-" + lIfName + "." + lUnitName;
            IYangObject  lExistEp = findElanEndpoint(lYangDB, lEndpointId,OPER_ENDPOINT_PATH);
            IYangObject lExistSyncEpYo = findElanEndpoint(lYangDB, lEndpointId,SYNC_ENDPOINT_PATH);
            if (null != lExistEp) {
                updateEndpoint (lYangDB, lExistEp, aInDeviceObject, aInNeId, lEndpointId);
            } else if(null != lExistSyncEpYo){
                updateSyncEndpointDetails(lYangDB,aInNeId,aInDeviceObject,lEndpointId);
            }
        } else if(lDevicePath.contains("srl_nokia-interfaces:/interface/subinterface/srl_nokia-interfaces-vlans:vlan/encap")){
            handleUpdateLogger.debug(" handleUpdate for neId : {}  inside encap block lDevicePath {} " ,lDevicePath);
            String lIfName = getIfNameFromUnitInfo(aInDeviceObject);
            if (handlePartialDeviceResyncClassLogger.isDebugEnabled()) {
                handlePartialDeviceResyncClassLogger.debug("lIfName: " + lIfName);
            }
            String lUnitName =  getSubIfNameFromIfFdn(getDevObjFdn(aInDeviceObject));
            if (handlePartialDeviceResyncClassLogger.isDebugEnabled()) {
                handlePartialDeviceResyncClassLogger.debug("lUnitName: " + lUnitName);
            }

            String lEndpointId ;
            lEndpointId =aInNeId + "-" + lIfName + "." + lUnitName;
            IYangObject  lExistEp = findElanEndpoint(lYangDB, lEndpointId,OPER_ENDPOINT_PATH);
            IYangObject lExistSyncEpYo = findElanEndpoint(lYangDB, lEndpointId,SYNC_ENDPOINT_PATH);
            if (null != lExistEp) {
                updateEndpointIpDetails(lYangDB, lExistEp, aInDeviceObject, aInNeId,lDevicePath);
            } else if(null != lExistSyncEpYo){
                updateEndpointIpDetails(lYangDB,lExistSyncEpYo,aInDeviceObject,aInNeId,lDevicePath);
            }
        }
    }

    private void triggerPartialResyncForSecondaryDeviceClasspath(DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, String aInNeId, IMDMPluginMdResyncProvider aInMdResyncFw, DeviceInfo aInDeviceInfo, String lElanIfFdn) {
        DeviceResyncClass secondaryDeviceResyncClass = aInNspClass.getDeviceResyncClass(aInDeviceClass.getSecondaryDeviceClassesToResync().get(0));
        String SubInterface = lElanIfFdn.substring(lElanIfFdn.lastIndexOf('=') + 1 ,lElanIfFdn.lastIndexOf(']') - 1);
        String [] interfaceDetails = SubInterface.split("\\.");
        String fdn = "/interface[name=" + interfaceDetails[0] + "']/subinterface[index='" + interfaceDetails[1] + "']";
        String sourceFdn = "fdn:model:mdm:" + fdn;
        scheduldePartialResync(secondaryDeviceResyncClass, aInNspClass, fdn, sourceFdn, aInNeId, aInMdResyncFw, aInDeviceInfo);
    }


    private void scheduldePartialResync(DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, String lfdn,String sourceFdn, String aInNeId, IMDMPluginMdResyncProvider aInMDMPluginMdResyncProvider, DeviceInfo aInDeviceInfo) {
        logger.info(" :scheduldePartialResync: Neid {}  deviceClassPath {} ",aInNeId,aInDeviceClass.getDeviceClassPath() );
        Map<String,SrlResyncRequestWrapper> lWrapperMap=resyncThreadLocal.get();
        if(null == lWrapperMap)
        {
            lWrapperMap=new HashMap<>();
            resyncThreadLocal.set(lWrapperMap);
            Transactor.getContext().addEventHandler(TxPhase.POST_ROLLBACK,(phase, context) -> {
                resyncThreadLocal.remove();
            });
            Transactor.getContext().addEventHandler(TxPhase.POST_COMMIT, (phase, context) -> {
                Map<String,SrlResyncRequestWrapper> lTmpWrapperMap=resyncThreadLocal.get();
                resyncThreadLocal.remove();
                if(null!=lTmpWrapperMap)
                {
                    for(Map.Entry<String,SrlResyncRequestWrapper> lEntry:lTmpWrapperMap.entrySet())
                    {
                        aInMDMPluginMdResyncProvider.submitPartialResyncTask(lEntry.getKey(),
                                lEntry.getValue().getResyncClasses(),lEntry.getValue().getXPaths(), aInNeId, aInDeviceInfo.getNodeType(), aInDeviceInfo.getNodeVersion(), aInDeviceInfo.getAmiName(), aInDeviceInfo.getAmiVersion(),null);
                    }
                }

            });
        }
        SrlResyncRequestWrapper lResyncWrapper=lWrapperMap.get(aInDeviceClass.getDeviceClassPath());
        if(null == lResyncWrapper)
        {
            Set<ResyncClass> lResyncClasses=new HashSet<>(1);
            lResyncClasses.add(aInNspClass);
            lResyncWrapper=new SrlResyncRequestWrapper(aInDeviceClass.getDeviceClassPath(),lResyncClasses);
            lWrapperMap.put(aInDeviceClass.getDeviceClassPath(), lResyncWrapper);
        }
        lResyncWrapper.addXPath(lfdn, sourceFdn);
    }


    @Override
    public void handleDelete(ISaveTaskInfo aInISaveTaskInfo, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, Map<String, Object> aInDeviceObject, String aInNeId, IMDMPluginMdResyncProvider aInMdResyncFw, DeviceInfo aInDeviceInfo) {
        //called from mdm-notification
        //need to check interface or unit.
        handleDeleteLogger.debug(" handleUpdate for neId : {}  corresponding  Resync class :  {}",aInNeId,aInDeviceClass,aInNspClass);
        IYangDB lYangDB = aInISaveTaskInfo.getIMDMPluginMdResyncProvider().getiMdResyncFw().getIYangDB();
        String lDevicePath = aInDeviceClass.getDeviceClassPath();
        String lElanIfFdn = getDevObjFdn(aInDeviceObject);
        String iterfaceName = getIfNameFromIfFdn(lElanIfFdn);

        if(lDevicePath.contains("/network-instance/interface") && null != iterfaceName && !iterfaceName.startsWith("irb")) {

            //String lElanIfFdn = getDevObjFdn(aInDeviceObject);
            //if (handleUpdateLogger.isDebugEnabled()) {
            handleDeleteLogger.info("lElanIfFdn: " + lElanIfFdn);
            //}
            IYangObject  lExistEp = getEndpoint(aInISaveTaskInfo, lYangDB,  aInNeId, lElanIfFdn,OPER_ENDPOINT_PATH);
            IYangObject  lSyncEnp = getEndpoint(aInISaveTaskInfo, lYangDB,  aInNeId, lElanIfFdn,SYNC_ENDPOINT_PATH);
            QueryParameters queryParameters = getlQueryParams();
            if (null != lExistEp)  {
                handleDeleteLogger.info("Deleting Oper table interface {} for neId : {}",lElanIfFdn,aInNeId);
                lYangDB.delete(lExistEp.getIdentifier(),queryParameters);
            } else if(null != lSyncEnp){
                handleDeleteLogger.info("Deleting Sync table interface {} for neId : {}",lElanIfFdn,aInNeId);
                lYangDB.delete(lSyncEnp.getIdentifier(),queryParameters);
            }
        } else if(lDevicePath.contains("srl_nokia-interfaces:/interface/subinterface/srl_nokia-interfaces-vlans:vlan/encap")){

        }
    }

    private QueryParameters getlQueryParams() {
        QueryParameters lQueryParams = new QueryParameters();
        IExecutionContext lExecutionContext = new ExecutionContext(null, null, true, false);
        lQueryParams.setIExecutionContext(lExecutionContext);
        return lQueryParams;
    }

    @Override
    public void handleDelete(ISaveTaskInfo aInISaveTaskInfo, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, ModelFdn aInDeviceObject, String aInNeId, IMDMPluginMdResyncProvider aInMdResyncFw, DeviceInfo aInDeviceInfo) {
        //called from data-deployer
        //need to check interface or unit.
    }

    public boolean isHandleUnmanageNode(ResyncClass aInNspClass,IUnmanageNeContext aInIUnmanageNeContext)
    {
        return true;
    }

    public List<String> buildResyncSearchIdsOnUnmanageNe(ResyncClass aInNspClass,IUnmanageNeContext aInIUnmanageNeContext)
    {
        List<String> lXPaths = new ArrayList<>(1);
        String lNeId = aInIUnmanageNeContext.getNeId();
        String lEndpointXPath = aInIUnmanageNeContext.getIYangPath().asString() + "[site-id='" + aInIUnmanageNeContext.getNeId()+ "']";
        lXPaths.add(lEndpointXPath);
        return lXPaths;
    }

    public QueryParameters buildSearchQueryParameter(ResyncClass aInNspClass,IUnmanageNeContext aInIUnmanageNeContext)
    {
        QueryParameters lQueryParams = new QueryParameters();
        lQueryParams.setFields(Fields.parse("endpoint-id"));
        return lQueryParams;
    }

    public void handleDeleteOnUnmanageNe(IYangObject aInIYangObject,ResyncClass aInNspClass,IUnmanageNeContext aInIUnmanageNeContext,QueryParameters aInQueryParameters)
    {
        aInIUnmanageNeContext.getIMDMPluginMdResyncProvider().getIYangDB().delete(aInIYangObject.getIdentifier(),aInQueryParameters);
    }

    @Override
    public Map<String, Object> buildFieldFilter(DeviceResyncClass aInDeviceClass, String aInNodeType, String aInNodeVersion) {
        if(aInDeviceClass.getDeviceClassPath().equals(SRL_NOKIA_INTERFACES_INTERFACE_SUBINTERFACE)) {
            if (fieldFilterMap == null || fieldFilterMap.isEmpty()) {
                try {
                    fieldFilterMap = new ObjectMapper().readValue(fieldFilterRequestJson, HashMap.class);
                } catch (IOException ie) {
                    logger.error("Failed to parse type=" + fieldFilterRequestJson + ", [ " + this + " ] ", ie);
                    fieldFilterMap = new HashMap();
                }
            }
            logger.debug("filter request " + fieldFilterRequestJson);
            return fieldFilterMap;
        } else {
            return INspResyncDeviceClassHandler.super.buildFieldFilter(aInDeviceClass, aInNodeType, aInNodeVersion);
        }
    }
}
