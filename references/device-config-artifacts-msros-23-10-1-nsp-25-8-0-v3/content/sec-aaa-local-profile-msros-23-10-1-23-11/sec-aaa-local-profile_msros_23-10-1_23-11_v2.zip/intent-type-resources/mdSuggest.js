function MdSuggest() {
    this.getLocalProfileName = function (neId) {
       const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/system/security/aaa/local-profiles/profile?fields=user-profile-name`;
       return this.getSuggestData(neId, url, "nokia-conf:profile", "user-profile-name");
    }

    this.getCliSessionGroupName = function (neId) {
           const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/system/security/aaa/cli-session-group?fields=cli-session-group-name`;
           return this.getSuggestData(neId, url, "nokia-conf:cli-session-group", "cli-session-group-name");
        }

   this.getSuggestData = function(neId, url, initialProperty, propertyName) {
      const mdcFwk = new MdcFwk();
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg[initialProperty];
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data[propertyName]).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }
}
