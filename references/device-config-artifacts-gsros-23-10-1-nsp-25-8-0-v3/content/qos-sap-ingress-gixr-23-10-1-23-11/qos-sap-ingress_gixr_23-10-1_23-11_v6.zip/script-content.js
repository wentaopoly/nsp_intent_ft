var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn" : "http://www.nokia.com/management-solutions/ibn",
    "nc" : "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager" : "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders" : "anv-device-holders"
};

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: 'nsp-intent-helper'})
var nspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
var mdtFwk =  new MdtFwk();

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})
load({script: resourceProvider.getResource('mdSuggest.js'), name: 'MdSuggest'})


var intentTypeName = 'qos-sap-ingress_gixr_23-10-1_23-11';
var initialPropertyName = 'sap-ingress';
var uniqueIdentifier = 'sap-ingress-policy-name';
var parentXpath = 'configure/qos';
var LOG_PREFIX = "[Sap-Ingress_IXR]: "

function synchronize(input) {

    logger.info('Intent Synchronisation started');
    var targetInfo = input.getTarget().split("#");
    var result = synchronizeResultFactory.createSynchronizeResult();
    if(targetInfo.length >=4 && isNaN(targetInfo[3]))
    {
        result.setSuccess(false);
        result.setErrorCode(100);
        result.setErrorDetail("failed To set Topology.");
        throw new RuntimeException("Invalid SAP Ingress policy ID: " + targetInfo[3]);
    }
    var esQuery = {
        "query": {
            "bool": {
                "should": [
                    {
                        "bool": {
                            "must": [
                                {
                                    "match": {
                                        "intent-type": "qos-sap-ingress_gixr_23-10-1_23-11"
                                    }
                                },
                                {
                                    "match": {
                                        "target.sap-ingress-policy-name": targetInfo[2]
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "bool": {
                            "must": [
                                {
                                    "match": {
                                        "intent-type": "qos-sap-ingress_gixr_23-10-1_23-11"
                                    }
                                },
                                {
                                    "match": {
                                        "target.policy-id": targetInfo[3]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    };
    var jsonQuery = JSON.stringify(esQuery);
    var esQueryData = esQueryService.queryESIntents(jsonQuery);
    var intentsEs = JSON.parse(esQueryData)['hits']['hits'];
    var intentTargetList = [];
    for (var esInCount = 0; esInCount < intentsEs.length; esInCount++)
    {
        var esIntent = intentsEs[esInCount];
        intentTargetList.push(esIntent["_source"]['target']['raw']);
    }

    var count = 0;
    for (var i = 0; i < intentTargetList.length; i++)
    {
        var intentObj = intentTargetList[i];
        var intentObjInfo = intentObj.split("#");
        if (targetInfo[0] === intentObjInfo[0])
        {
            if (targetInfo[1] === intentObjInfo[1])
            {
                if (targetInfo[2] === intentObjInfo[2])
                {
                    if (count != 0)
                    {
                        throw new RuntimeException("Sync operation is not allowed because more than one intents are created on same Policy Name : " + targetInfo[2] + ", with same template : " + targetInfo[0]);
                    }
                    count = count + 1;
                }

            }
        }
    }
    return nspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started');
    var targetInfo = target.split("#");
    var esQuery = {
        "query": {
            "bool": {
                "should": [
                    {
                        "bool": {
                            "must": [
                                {
                                    "match": {
                                        "intent-type": "qos-sap-ingress_gixr_23-10-1_23-11"
                                    }
                                },
                                {
                                    "match": {
                                        "target.sap-ingress-policy-name": targetInfo[2]
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "bool": {
                            "must": [
                                {
                                    "match": {
                                        "intent-type": "qos-sap-ingress_gixr_23-10-1_23-11"
                                    }
                                },
                                {
                                    "match": {
                                        "target.policy-id": targetInfo[3]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    };
    var jsonQuery = JSON.stringify(esQuery);
    var esQueryData = esQueryService.queryESIntents(jsonQuery);
    var intentsEs = JSON.parse(esQueryData)['hits']['hits'];
    var intentTargetList = [];
    for (var esInCount = 0; esInCount < intentsEs.length; esInCount++)
    {
        var esIntent = intentsEs[esInCount];
        intentTargetList.push(esIntent["_source"]['target']['raw']);
    }

    var count = 0;
    for (var i = 0; i < intentTargetList.length; i++)
    {
        var intentObj = intentTargetList[i];
        var intentObjInfo = intentObj.split("#");
        if (targetInfo[0] === intentObjInfo[0])
        {
            if (targetInfo[1] === intentObjInfo[1])
            {
                if (targetInfo[2] === intentObjInfo[2])
                {
                    if (count != 0)
                    {
                        throw new RuntimeException("Audit Operation is not allowed because more than one intents are created on same Policy Name : " + targetInfo[2] + ", with same template : " + targetInfo[0]);
                    }
                    count = count + 1;
                }
            }
        }
    }
    return nspIntentHelper.audit(target, config, svcTopo, adminState, intentTypeName,  parentXpath , initialPropertyName, uniqueIdentifier);
}

function getTargetData(input) {
    logger.info(input);
    var target = input.target;
    var config = null;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    //logger.info(JSON.stringify(deviceConfig));
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}

function suggestPolicyName(context) {
    logger.info("suggestPolicyName context = \n" + context);
    var policyId = context.getInputValues()["arguments"]["target_id"];
    logger.info("User  selected Policy ID : {}, searching Policy Name associaed to Policy-id - {}", policyId, policyId);
    var neId = getNeId(context);
    return navigateInstance(neId).getPolicyName(neId, policyId);
}

function suggestPolicyId(context) {
    logger.info("suggestPolicyId context = \n" + context);
    var policyName = context.getInputValues()["arguments"]["target_policyName"];
    logger.info("User  selected Policy Name : {}, searching Policy ID associaed to Policy Name - {}", policyName, policyName);
    var neId = getNeId(context);
    return navigateInstance(neId).getPolicyId(neId, policyName);
}

function suggestIngressClassificationPolicy(context) {
    logger.info("suggest Ingress Classification Policy context = \n" + context);
    var neId = getNeId(context);
    return navigateInstance(neId).getIngressClassificationPolicy(neId);
}

function getNeId(context) {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    logger.info(target)
    if (target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    logger.info("NeId : " + neId);
    return neId;
}

function navigateInstance(neId) {
    var managerName = mdtFwk.getManagerName(neId);
    logger.info('Device: ' + neId + ' is managed by: ' + managerName);
    switch (managerName)
    {
        case 'NFM-P':
            logger.info('Device is managed by NFMP')
            return new NfmpSuggest();
            break;
        case 'MDC':
            logger.info('Device is managed by MDM')
            return new MdSuggest();
            break;
        default:
            logger.info('Device is not managed')
            throw new RuntimeException('Device is not Managed')
    }
    return ''
}
