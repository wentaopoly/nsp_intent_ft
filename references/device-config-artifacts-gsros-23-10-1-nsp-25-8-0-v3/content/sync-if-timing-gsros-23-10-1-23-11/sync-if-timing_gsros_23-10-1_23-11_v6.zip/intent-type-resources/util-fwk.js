load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {

    this.setSuccessResult = function (result, savedTopology) {
        result.setSuccess(true);
        if (savedTopology !== undefined)
        {
            result.setTopology(savedTopology);
        }
        return result;
    }
    this.reportMisaligned = function (target, result, auditReport) {
        var report = JSON.parse(result.response);
        if (!report.aligned)
        {
            for (var i = 0; i < report.misalignedAttributes.length; i++)
            {
                var attributeData = report.misalignedAttributes[i];
                if (attributeData.expected == "present")
                {
                    //misaligned object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else if (attributeData.expected == "not present")
                {
                    //undesired object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                    auditReport.addMisAlignedAttribute(misalignedAttribute);
                }

            }
        }
        return auditReport
    }
    this.editPayload = function (fdn, properties, childProperties, fullClassName, objectFullName) {
        var payload = {};
        var configInfo = {};
        configInfo["containedClassProperties"] = properties;
        configInfo["containmentInfo"] = childProperties;
        configInfo["objectClassName"] = fullClassName;
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName;
        payload["configInfo"] = configInfo;
        return payload;
    }

    /*
        function: isObjectExists
        description: To Check the Object exists or not.
   */
    this.isObjectExists = function (className, objectFullName) {
        let nfmpFwk = new NfmpFwk();
        var ret = false;
        var searchObjectJson = {
            "fullClassName": className,
            "filter": {
                "filterExpression": "fullName='" + objectFullName + "'"
            }
        };
        var resultFetch = nfmpFwk.post("search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse))
        {
            ret = true;
        }
        return ret;
    }
    this.convertQualityLevelGreenField = function (qualityLevel) {
        if (qualityLevel == true)
        {
            return "enabled";
        }
        else if (qualityLevel == false)
        {
            return "disabled";
        }
    }
    this.convertQualityLevelBrownField = function (qualityLevel) {
        if (qualityLevel == "enabled")
        {
            return true;
        }
        else if (qualityLevel == "disabled")
        {
            return false;
        }
    }
    this.qualityLevelEnumGreenField = function (qualityLevel) {
        if (qualityLevel == "unused")
        {
            return "unknown";
        }
        return qualityLevel;
    }
    this.qualityLevelEnumBrownField = function (qualityLevel) {
        if (qualityLevel == "unknown")
        {
            return "unused";
        }
        return qualityLevel;
    }
    this.refOrderEnumGreenField = function (refOrder) {
        if (refOrder == "ref1")
        {
            return "referenceOne";
        }
        if (refOrder == "ref2")
        {
            return "referenceTwo";
        }
        if (refOrder == "none")
        {
            return undefined;
        }
        return refOrder;
    }
    this.refOrderEnumBrownField = function (refOrder) {
        if (refOrder == "referenceOne")
        {
            return "ref1";
        }
        if (refOrder == "referenceTwo")
        {
            return "ref2";
        }
        return refOrder;
    }
    this.convertAdminStateGreenField = function (adminState) {
        if (adminState == "enable")
        {
            return "up";
        }
        else if (adminState == "disable")
        {
            return "down";
        }
    }
    this.convertAdminStateBrownField = function (adminState) {
        if (adminState == "up")
        {
            return "enable";
        }
        else if (adminState == "down")
        {
            return "disable";
        }
    }
    this.convertInterfaceTypeGreenField = function (interfaceType) {
        if (interfaceType == "ds1-esf")
        {
            return "t1_esf";
        }
        else if (interfaceType == "ds1-sf")
        {
            return "t1_sf";
        }
        else if (interfaceType == "e1-pcm30crc")
        {
            return "e1_pcm30crc";
        }
        else if (interfaceType == "e1-pcm31crc")
        {
            return "e1_pcm31crc";
        }
        else if (interfaceType == "g703-2048khz")
        {
            return "two_mhz_square";
        }
        return interfaceType;
    }
    this.convertInterfaceTypeBrownField = function (interfaceType) {
        if (interfaceType == "t1_esf")
        {
            return "ds1-esf";
        }
        else if (interfaceType == "t1_sf")
        {
            return "ds1-sf";
        }
        else if (interfaceType == "e1_pcm30crc")
        {
            return "e1-pcm30crc";
        }
        else if (interfaceType == "e1_pcm31crc")
        {
            return "e1-pcm31crc";
        }
        else if (interfaceType == "two_mhz_square")
        {
            return "g703-2048khz";
        }
    }
    this.convertLineLengthGreenField = function (lineLength) {
        if (lineLength == "length-not-applicable")
        {
            return "lengthNotApplicable";
        }
        else if (lineLength == "110")
        {
            return "length0To110";
        }
        else if (lineLength == "220")
        {
            return "length110To220";
        }
        else if (lineLength == "330")
        {
            return "length220To330";
        }
        else if (lineLength == "440")
        {
            return "length330To440";
        }
        else if (lineLength == "550")
        {
            return "length440To550";
        }
        else if (lineLength == "660")
        {
            return "length550To660";
        }
        return lineLength;
    }
    this.convertLineLengthBrownField = function (lineLength) {
        if (lineLength == "lengthNotApplicable")
        {
            return "length-not-applicable";
        }
        else if (lineLength == "length0To110")
        {
            return "110";
        }
        else if (lineLength == "length110To220")
        {
            return "220";
        }
        else if (lineLength == "length220To330")
        {
            return "330";
        }
        else if (lineLength == "length330To440")
        {
            return "440";
        }
        else if (lineLength == "length440To550")
        {
            return "550";
        }
        else if (lineLength == "length550To660")
        {
            return "660";
        }
    }
    this.convertOutputSourceGreenField = function (outputSource) {
        if (outputSource == "line-ref")
        {
            return "lineRef";
        }
        else if (outputSource == "internal-clock")
        {
            return "internalClock";
        }
        return outputSource;
    }
    this.convertOutputSourceBrownField = function (outputSource) {
        if (outputSource == "lineRef")
        {
            return "line-ref";
        }
        else if (outputSource == "internalClock")
        {
            return "internal-clock";
        }
    }
    this.convertRefSourceBrownField = function (refSource) {
        if (refSource !== "N/A")
        {
            return refSource;
        }
    }
    this.getBaseFdnForPort = function (target, portId) {
        if (portId.startsWith("esat"))
        {
            return this.getBaseFdnForSatellitePort(target, portId);
        }
        var portIds = portId.split("/");
        var cardSlot;
        var xiomSlot;
        var mdaSlot;
        var connector;
        var portNumber

        portIds.forEach(function (item, index) {
            // logger.info("*********************item, index = " + item + "-----" + index);
            switch (index)
            {
                case 0:
                    cardSlot = item;
                    break;
                case 1:
                    //xiom
                    if (isNaN(item))
                    {
                        xiomSlot = item;
                    }
                    else
                    {
                        mdaSlot = item;
                    }
                    break;
                case 2:
                    //connector
                    if (isNaN(item))
                    {
                        connector = item;
                    }
                    else if (mdaSlot)
                    {
                        portNumber = item;
                    }
                    else
                    {
                        mdaSlot = item;
                    }
                    break;
                case 3:
                    //connector
                    if (isNaN(item))
                    {
                        connector = item;
                    }
                    else
                    {
                        portNumber = item;
                    }
                    break;
                case 4:
                    portNumber = item;
                    break;


            }
        });

        // logger.info("************ cardSlot =" + cardSlot + ",xiomSlot=" + xiomSlot + ",mdaSlot=" + mdaSlot + ",connector=" + connector + ",portNumber=" + portNumber);
        //"network:92.168.96.22:shelf-1:cardSlot-1:card:xioSlot-1:xiomCard:daughterCardSlot-1:daughterCard:conn-1:port-1"

        var portDn = "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card";
        if (xiomSlot)
        {
            portDn += ":xioSlot-" + xiomSlot.substring(1) + ":xiomCard";
        }
        if (mdaSlot)
        {
            portDn += ":daughterCardSlot-" + mdaSlot + ":daughterCard";
        }
        if (connector)
        {
            portDn += ":conn-" + connector.substring(1);
        }
        if (portNumber)
        {
            portDn += ":port-" + portNumber;
        }
        if (target && String(target).indexOf(':') !== -1) {
          portDn = this.modifyNeIdForIpV6(portDn, target);
        }
        logger.info("*********************portDn = " + portDn);
        return portDn;
        //return "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card:daughterCardSlot-" + mdaSlot + ":daughterCard:port-" + portNumber;
    }
    this.getBaseFdnForSatellitePort = function (target, portId) {

        var portIds = (portId.split("-")[1]).split("/");
        var shelf = "shelf-1-5-";
        shelf += portIds[0];
        var satId = portIds[0];
        var cardSlot = "cardSlot-1:card";
        var mdaSlot = "daughterCardSlot-1:daughterCard";
        var portNumber = portIds[2];
        var snmpPortId = this.getSatellitePortSnmpId(satId, 1, portNumber, false, 5)
        //logger.info("******satellite port = shelf = "+shelf+", portnumber = "+portNumber +"\n portid = "+ portId+"\n portids = "+ portIds);
        var portDn = "network:" + target + ":" + shelf + ":" + cardSlot + ":" + mdaSlot + ":port-" + snmpPortId;
        if (target && String(target).indexOf(':') !== -1) {
          portDn = this.modifyNeIdForIpV6(portDn, target);
        }
        logger.info("SatPortDN = " + portDn);
        return portDn;
    }
    this.getSatellitePortSnmpId = function (aInSatId, aInSlotId, aInPortId, aInUplink, aInPhyShelfClass) {
        var aInSnmpIndex = aInPortId;
        var lUplinkBit = 0;
        if (aInUplink)
        {
            lUplinkBit = 1;
        }
        var lSatId = aInSatId << 16;
        var lSlotId = aInSlotId << 11;
        var lUplink = lUplinkBit << 10;
        var lSat = 136 << 23;
        aInSnmpIndex = lSat | lSatId | lSlotId | lUplink | aInSnmpIndex;
        return aInSnmpIndex;
    }

    this.modifyNeIdForIpV6 = function (objectFullName, neId) {
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }
}
