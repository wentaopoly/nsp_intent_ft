load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});

function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {

        if (!isAudit) {
            if (payload["configInfo"]["sitesec.ManagementAccessFilter"]["children-Set"] && payload["configInfo"]["sitesec.ManagementAccessFilter"]["children-Set"]["sitesec.MafEntry"]) {
                for (var index in payload["configInfo"]["sitesec.ManagementAccessFilter"]["children-Set"]["sitesec.MafEntry"]) {
                    var mafEntryConfig = payload["configInfo"]["sitesec.ManagementAccessFilter"]["children-Set"]["sitesec.MafEntry"][index];

                    if(!mafEntryConfig["srcIpPrefixListPointer"]){
                        mafEntryConfig["srcIpPrefixListPointer"] = '';
                    }

                    payload["configInfo"]["sitesec.ManagementAccessFilter"]["children-Set"]["sitesec.MafEntry"][index] = mafEntryConfig;
                }
            }
            if (payload["configInfo"]["sitesec.ManagementAccessFilter"]["children-Set"] && payload["configInfo"]["sitesec.ManagementAccessFilter"]["children-Set"]["sitesec.MafIPv6Entry"]) {
                for (var index in payload["configInfo"]["sitesec.ManagementAccessFilter"]["children-Set"]["sitesec.MafIPv6Entry"]) {
                    var mafIPv6EntryConfig = payload["configInfo"]["sitesec.ManagementAccessFilter"]["children-Set"]["sitesec.MafIPv6Entry"][index];

                    if(!mafIPv6EntryConfig["srcIpPrefixListPointer"]){
                        mafIPv6EntryConfig["srcIpPrefixListPointer"] = '';
                    }

                    payload["configInfo"]["sitesec.ManagementAccessFilter"]["children-Set"]["sitesec.MafIPv6Entry"][index] = mafIPv6EntryConfig;
                }
            }
        }

        var ipv6AddressUtil = new IPv6AddressUtil();
        payload = ipv6AddressUtil.expandIPv6(payload);

        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        if(xpath == "sitesec-MafEntry.srcIpPrefixListPointer")
        {
            targetValue = 'filterPrefixList:'+ targetValue;
        }
        if(xpath == "sitesec-MafIPv6Entry.srcIpPrefixListPointer")
        {
            targetValue = 'filterPrefixList:' + targetValue + '#type-IPv6';
        }

        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
        if(xpath == "sitesec-MafEntry.srcIpPrefixListPointer")
        {
            targetValue = targetValue.replace('filterPrefixList:', '');
        }
        if(xpath == "sitesec-MafIPv6Entry.srcIpPrefixListPointer")
        {
            targetValue = (targetValue.replace('filterPrefixList:', '')).replace("#type-IPv6", "");
        }

        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
}