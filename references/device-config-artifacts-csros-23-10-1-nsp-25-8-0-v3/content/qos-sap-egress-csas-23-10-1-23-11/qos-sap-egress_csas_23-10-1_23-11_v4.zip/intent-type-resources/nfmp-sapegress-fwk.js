var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

var sap_egress_full_class_name = "sasqos.AccessEgress";
var sap_egress_policy_id = "policy-id";
var sap_egress_fdn = "sasAccessEgress";
var distribute_url = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true"

function NfmpSapEgress() {

    var util = new utilities();
    let nfmpFwk = new NfmpFwk();
    var parseTarget =  new ParseTarget();
    var savedTopology;
    var isAudit = false;
    var isEdit = false;
    var isLocalExists = false;
    var isGlobalExists = false;

    this.synchronize = function(input, result, intentTypeName, xpath, initialPropertyName) {

        if (input.getNetworkState().name() == "delete") {
            logger.info(LOG_PREFIX + "Calling syncDelete");
            return this.syncDelete(input, result);
        }

        savedTopology = input.getCurrentTopology();
        logger.info(LOG_PREFIX + "Saved Topology = " + savedTopology);
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyId = util.getSapEgressPolicyId(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        intentConfig = this.removeEmptyContainers("", intentConfig, "", neId);
        intentConfig[sap_egress_policy_id] = parseInt(policyId);
        logger.info(LOG_PREFIX + "Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info(LOG_PREFIX + "Target device = " + neId);
        logger.info(LOG_PREFIX + "Target sap-egress Policy ID = " + policyId);
        this.createOrModify(neId, intentConfig);
        return util.setSuccessResult(result, savedTopology);
    }

    this.syncDelete = function (input,result) {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyId = util.getSapEgressPolicyId(input.getTarget());
        var objectFullName = "network:" + neId + ":" + sap_egress_fdn + ":" + policyId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        if (util.isObjectExists(sap_egress_full_class_name, objectFullName)) {
            logger.info(LOG_PREFIX + "syncDelete(): Deleting " + objectFullName);
            var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
            if (!deleteResult.success) {
                logger.info(LOG_PREFIX + "syncDelete(): Unable to Delete: " + deleteResult.msg);
                throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
            }
            result.setSuccess(true);
        }
        else {
            logger.info(LOG_PREFIX + "syncDelete(): There is no Sap Egress QoS policy with ID:" +
                 policyId + " on " + neId);
            result.setSuccess(false);
        }
    }

    this.createOrModify= function(neId, intentConfig) {

        var objectFullName = sap_egress_fdn + ":" + intentConfig[sap_egress_policy_id];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        var localPolicy = util.getIfObjectExists(sap_egress_full_class_name, localPolicyFullName);
        var result;
        var sapEgressPayload;
        var distributePayload;
        var distributeResult;

        if (localPolicy != null) {
            isLocalExists = true;
            isGlobalExists = true;
            if (parseInt(localPolicy[0]["id"]) !== intentConfig[sap_egress_policy_id]) {
                throw new RuntimeException("Already there exists a policy on " + neId +
                    " with policy ID " + intentConfig[sap_egress_policy_id]);
            }
            sapEgressPayload = this.createSapEgressPayLoad(neId, intentConfig, isLocalExists, localPolicy);
            result = this.modifyRequest(neId, sapEgressPayload);
            if (!util.isObjectExists(sap_egress_full_class_name, localPolicyFullName)) {
                throw new RuntimeException('Unable to Create/Distribute Policy: ' + intentConfig[sap_egress_policy_id] +
                    " , Kindly check the intent configuration");
            }
        }
        else {
            logger.info(LOG_PREFIX + "****** Unable to find the local policy, Trying to fetch global policy if available *****");
            var searchPayload = this.constructSearchString(neId, intentConfig[sap_egress_policy_id]);
            var searchResponse = nfmpFwk.find(neId, searchPayload);
            if (!(searchResponse.success && JSON.stringify(searchResponse.response) === "")) {
                if (!searchResponse.success) {
                    logger.info(LOG_PREFIX + "createOrModify(): Unable to get Policy info from nfm-p for Ne " +
                        neId + " and Policy ID: " + intentConfig[sap_egress_policy_id]);
                }
                if (searchResponse.response === "") {
                    logger.info(LOG_PREFIX + "createOrModify(): There is no sap-egress policy with ID:" +
                        intentConfig[sap_egress_policy_id] + " on " + neId);
                }
            }
            else {
                throw new RuntimeException("createOrModify(): There exists a sap-egress policy on " +
                    neId + " with ID " + JSON.parse(searchResponse["response"])[0]["id"]);
            }

            var globalPolicy = util.getIfObjectExists(sap_egress_full_class_name, objectFullName);
            if (globalPolicy != null) {
                isGlobalExists = true;
                if (globalPolicy[0]["id"] !== intentConfig[sap_egress_policy_id]) {
                    logger.info(LOG_PREFIX + "createOrModify(): There exists a sap-egress global policy in NFMP with policy ID " +
                         intentConfig[sap_egress_policy_id] + " on node " + neId);
                    logger.info(LOG_PREFIX + "createOrModify(): Updating sap-egress global policy ID to " +
                        intentConfig[sap_egress_policy_id] + " on node " + neId );
                    this.updateSapEgressPolicyName(neId, objectFullName, intentConfig[sap_egress_policy_id]);
                }

                distributePayload = util.distribute(neId, objectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(neId, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                logger.info(LOG_PREFIX + "******** checking distribution of existing global policy  ****** ");
                if (!util.isObjectExists(sap_egress_full_class_name, localPolicyFullName)) {
                    throw new RuntimeException("Unable to Distribute existing Global Policy: " + intentConfig[sap_egress_policy_id] +
                        " , Kindly check the Global Policy configuration");
                }
                logger.info(LOG_PREFIX + "********* distribution of existing global policy was successful, updating with intent configuration *****");
                sapEgressPayload = this.createSapEgressPayLoad(neId, intentConfig, true, globalPolicy);
                result = this.modifyRequest(neId, sapEgressPayload);
                if (!util.isObjectExists(sap_egress_full_class_name, localPolicyFullName)) {
                    throw new RuntimeException('Unable to Create/Distribute Policy: ' + intentConfig[sap_egress_policy_id] +
                        " , Kindly check the intent configuration");
                }
            }
            else {
                //distributing empty policy
                logger.info(LOG_PREFIX + "******* Unable to find the Global Policy, distributing empty policy and updating *******");
                sapEgressPayload = this.createSapEgressPayLoad(neId, intentConfig, false, null);
                result = this.modifyRequest(neId, sapEgressPayload);
                distributePayload = util.distribute(neId, objectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(neId, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                //updating the local policy with intent configuration
                sapEgressPayload = this.createSapEgressPayLoad(neId, intentConfig, true, null);
                result = this.modifyRequest(neId, sapEgressPayload);
            }
        }
        return result;
    }

    this.updateSapEgressPolicyName = function (neId, objectFullName, policyId) {
        var payload = {};
        var configInfo = {};
        var properties = {};
        properties["id"] = policyId;

        configInfo[sap_egress_full_class_name] = properties;
        payload["distinguishedName"] = sap_egress_fdn;
        payload["objectFullName"] = objectFullName;
        payload["clearOnDeployFailure"] = true;
        payload["configInfo"] = configInfo;
        logger.info(LOG_PREFIX + "Payload for updating Global Policy ID : " + JSON.stringify(payload));
        return  this.modifyRequest(neId, payload);
    }

    this.constructSearchString = function(neId, policyId) {
        logger.info(LOG_PREFIX + "Creating search payload for NE ID : " + neId + " with Policy ID : " + policyId);
        var jsonPayLoad = {
            "fullClassName": sap_egress_full_class_name,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName",
                    "id"
                ]
            }
        };
        var idSearchObj = {
            "name": "id",
            "value": policyId
        };
        jsonPayLoad["filter"]["and"]["equal"].push(idSearchObj);
        return jsonPayLoad;
    }

    this.createSapEgressPayLoad = function(neId, intentConfig, isLocalExists, policyObject) {
        if (savedTopology == null)
        {
            logger.info(LOG_PREFIX + "Creating topology to save mode");
            savedTopology = topologyFactory.createServiceTopology();
        }
        var objectFullName = sap_egress_fdn + ":" + intentConfig[sap_egress_policy_id];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        if (isLocalExists || isAudit) {
            objectFullName = localPolicyFullName;
        }
        var properties = {};
        var childProperties = {};
        properties["id"] = intentConfig[sap_egress_policy_id];

        if (isLocalExists) {
            if ("description" in intentConfig) {
                properties["description"] = intentConfig["description"];
            }
            else {
                properties["description"] = "";
            }
            //SCOPE
            if ("scope" in intentConfig) {
                properties["scope"] = intentConfig["scope"];
            }
            //CLASSIFICATION-TYPE
            properties["dot1pClassificationPointer"] = "";
            properties["dscpClassificationPointer"] = "";
            properties["ipPrecClassificationPointer"] = "";
            if ("dot1p-classification" in intentConfig) {
                properties["dot1pClassificationPointer"] = "sasDot1pClassification:Dot1p-" + intentConfig["dot1p-classification"];
            }
            if ("dscp-classification" in intentConfig) {
                properties["dscpClassificationPointer"] = "sasDSCPClassification:Dscp-" + intentConfig["dscp-classification"];
            }
            if ("ip-prec-classification" in intentConfig) {
                properties["ipPrecClassificationPointer"] = "sasDSCPClassification:Dscp-" + intentConfig["ip-prec-classification"];
            }
            //REMARK POLICY
            if ("remark" in intentConfig) {
                properties["remarkPolicyPointer"] = "sasRemarkingPolicy:" + intentConfig["remark"];
                if (!isAudit) {
                    properties["remarkingPolicyApplicable"] = true;
                }
            }
            //REMARKING
            if ("remarking" in intentConfig) {
                properties["remarking"] = intentConfig["remarking"].toString();
            }
            //QUEUE
            if ("queue" in intentConfig) {
                this.createQueuePayLoad(intentConfig, childProperties);
            }
            else {
                childProperties["sasqos.QueueEntry"] = [];
            }
            //FC
            if ("fc" in intentConfig) {
                this.createFcPayload(intentConfig, childProperties);
            }
            else {
                childProperties["sasqos.AccessEgressForwardingClass"] = [];
            }
        }
        return util.editPayload(sap_egress_fdn, properties, childProperties, sap_egress_full_class_name, objectFullName);
    }

    this.createFcPayload = function (intentConfig, childProperties) {
        var fcPayloadArray = [];
        var fcClassName = "sasqos.AccessEgressForwardingClass";
        if (!Array.isArray(intentConfig["fc"])) {
            intentConfig["fc"] = [intentConfig["fc"]]
        }
        for (var idx in intentConfig["fc"]) {
            var fcConfig = intentConfig["fc"][idx];
            var properties = {};
            if (fcConfig["fc-name"]) {
                properties["forwardingClass"] = fcConfig["fc-name"];
            }
            if (fcConfig["queue"]) {
                properties["queueId"] = fcConfig["queue"];
            }
            fcPayloadArray.push(properties);
        }
        childProperties[fcClassName] = fcPayloadArray;
    }

    this.createQueuePayLoad = function (intentConfig, childProperties) {
        var queuePayloadArray = [];
        var queueClassName = "sasqos.QueueEntry";
        if (!Array.isArray(intentConfig["queue"])) {
            intentConfig["queue"] = [intentConfig["queue"]];
        }
        for (var idx in intentConfig["queue"]) {
            var queueConfig = intentConfig["queue"][idx];
            var queuePayload = this.configureQueuePayload(queueConfig);
            queuePayloadArray.push(queuePayload);
        }
        childProperties[queueClassName] = queuePayloadArray;
    }

    this.configureQueuePayload = function (queueConfig) {
        var properties = {};
        if ("queue-mgmt" in queueConfig) {
            properties["queuemgmtPolicyPointer"] = "sasQueueMgmtPolicy:" + queueConfig["queue-mgmt"];
        }
        else {
            properties["queuemgmtPolicyPointer"] = "sasQueueMgmtPolicy:default";
        }
        if ("slope-policy" in queueConfig) {
            properties["slopePolicyPointer"] = "sasSlope:" + queueConfig["slope-policy"];
        }
        else {
            properties["slopePolicyPointer"] = "sasSlope:default";
        }
        for (var queueData in queueConfig) {
            switch (queueData) {
                case "queue-id":
                    properties["id"] = queueConfig[queueData];
                    properties["isQueueDeployable"] = true;
                    break;
                case "cbs":
                    properties["committedBurstSize"] = queueConfig[queueData];
                    break;
                case "mbs":
                    properties["maximumBurstSize"] = queueConfig[queueData];
                    break;
                case "queue-mode":
                    properties["mode"] = queueConfig[queueData];
                    break;
                case "weight":
                    properties["weight"] = queueConfig[queueData];
                    break;
                case "priority":
                    properties["priority"] = queueConfig[queueData];
                    break;
                case "rate":
                    var rateObj = queueConfig[queueData];
                    if ("pir" in rateObj) {
                        if (rateObj["pir"] === "max") {
                            properties["pir"] = "-1";
                        }
                        else {
                            properties["pir"] = rateObj["pir"];
                        }
                    }
                    if ("cir" in rateObj) {
                        if (rateObj["cir"] === "max") {
                            properties["cir"] = "-1";
                        }
                        else {
                            properties["cir"] = rateObj["cir"];
                        }
                    }
                    break;
                case "adaptation-rule":
                    var adaptationObj = queueConfig[queueData];
                    if (adaptationObj["pir"]) {
                        properties["pirAdaptation"] = adaptationObj["pir"];
                    }
                    if (adaptationObj["cir"]) {
                        properties["cirAdaptation"] = adaptationObj["cir"];
                    }
                    break;
            }
        }
        return properties;
    }

    this.audit = function (input, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        isAudit = true;
        logger.info(LOG_PREFIX + "Starting the Sap Egress Intent audit");
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        intentConfig = this.removeEmptyContainers("", intentConfig, "", neId);
        logger.info(LOG_PREFIX + "intentConfig = {} ", JSON.stringify(intentConfig));
        intentConfig[sap_egress_policy_id] = util.getSapEgressPolicyId(input.getTarget());
        logger.info(LOG_PREFIX + "auditing configuration = " + JSON.stringify(intentConfig));
        logger.info(LOG_PREFIX + "Target device = " + neId);
        logger.info(LOG_PREFIX + "Target Network QoS Sap Egress = " + intentConfig[sap_egress_policy_id]);
        if (intentConfig) {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else {
            throw "configuration not available in the intent";
        }
        return auditReport
    }

    this.auditAndCompare = function(neId, intentConfig, auditReport) {
        var sapEgressPayload = this.createSapEgressPayLoad(neId, intentConfig, true, null);
        var result = this.auditRequest(neId, sapEgressPayload);
        auditReport = util.reportMisaligned(neId, result, auditReport);
        return auditReport;
    }

    this.auditRequest = function(neId, payload) {
        logger.info(LOG_PREFIX + "Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.modifyRequest = function(neId, payload) {
        logger.info(LOG_PREFIX + "Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success) {
           logger.error("Error result = {}",JSON.stringify(result));
           let errorMsg = result.msg;
           if(errorMsg.indexOf("object already exists") !== -1)
           {
               logger.info("Global policy Object already exists, Re-checking the Policy existence ");
               //util.delay(2000);
               let configInfo = payload.configInfo;
               let fullClassName;
               for (let key in configInfo) {
                 if (configInfo.hasOwnProperty(key)) {
                   fullClassName = key;
                   break;
                 }
               }
               let objectFullName = payload.objectFullName;
               objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
               logger.info("fullClassName = {}",fullClassName);
               logger.info("objectFullName = {}",objectFullName);
               if (!util.isObjectExists(fullClassName, objectFullName))
               {
                   throw new RuntimeException("Global Policy Object Not Found!!!");
               }
           }
           else
           {
               throw new RuntimeException(result.msg);
           }
        }
        return result;
    }

    this.removeEmptyContainers= function(prop, intentJson, path, target){
        if(Array.isArray(intentJson)) {
            var object = [];
            for(var prop in intentJson) {
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value) {
                    object.push(value);
                }
            }
            if(Object.keys(object).length !== 0) {
                return object;
            }
        }
        else if( typeof intentJson == 'object' ) {
            var object = {};
            for(var prop in intentJson) {
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ) {
                    object[prop] = value;
                }
            }
            if(Object.keys(object).length !== 0) {
                return object;
            }
        }
        else {
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if(intentJson!==undefined && intentJson!=="") {
                return intentJson;
            }
            return null;
        }
    }

    this.xml2object = function(xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info(LOG_PREFIX + "(xml2object) Input json: " + json)
        return JSON.parse(json);
    }
}