/**
 *
 *
 * ---------SAMPLE FILE -------------
 * This file is pure for reference perse
 * The intent-designer need to change it
 *
 *
 *
 */

function ModelDeviceMapping() {
    this.getMapping = function (type) {
        switch (type) {
            case "port":
                return this.getEthernetPortMapping();
            case "lldp":
                return this.getLldpMapping();
            default:
                return this.getEthernetPortMapping();
        }
    };
    this.getEthernetPortMapping = function () {
        var mapping = {};
        mapping["port.description"] = "equipment.PhysicalPort.description";
        mapping["port.admin-state"] = "equipment.PhysicalPort.administrativeState";
        mapping["port.ethernet.mtu"] = "equipment.PhysicalPort.mtuValue";
        mapping["port.ethernet.mode"] = "equipment.PhysicalPort.mode";
        mapping["port.ethernet.encap-type"] = "equipment.PhysicalPort.encapType";
        mapping["port.ethernet.speed"] = "equipment.PhysicalPort.speed";
        mapping["port.ethernet.accounting-policy"] =
            "equipment.PhysicalPort.accountingPolicyId";
        mapping["port.ethernet.autonegotiate"] =
            "ethernetequipment.EthernetPortSpecifics.autoNegotiate";
        mapping["port.ethernet.dot1q-etype"] =
            "ethernetequipment.EthernetPortSpecifics.dot1qEtype";
        mapping["port.ethernet.qinq-etype"] =
            "ethernetequipment.EthernetPortSpecifics.qinqEtype";
        mapping["port.ethernet.pbb-etype"] =
            "ethernetequipment.EthernetPortSpecifics.pbbEtype";

        //Hold-Time
        mapping["port.ethernet.hold-time.units"] =
            "ethernetequipment.EthernetPortSpecifics.holdTimeUnits";
        mapping["port.ethernet.hold-time.up"] =
            "ethernetequipment.EthernetPortSpecifics.holdTimeUp";
        mapping["port.ethernet.hold-time.down"] =
            "ethernetequipment.EthernetPortSpecifics.holdTimeDown";

        //DownWhenLooped
        mapping["port.ethernet.down-when-looped.admin-state"] =
            "ethernetequipment.EthernetPortSpecifics.downWhenLooped";
        mapping["port.ethernet.down-when-looped.use-broadcast-address"] =
            "ethernetequipment.EthernetPortSpecifics.useBroadCastAddress";
        mapping["port.ethernet.down-when-looped.retry-timeout"] =
            "ethernetequipment.EthernetPortSpecifics.retryTimeout";
        mapping["port.ethernet.down-when-looped.keep-alive"] =
            "ethernetequipment.EthernetPortSpecifics.keepAliveInterval";

        return mapping;
    };

    this.getLldpMapping = function () {
        var mapping = {};
        mapping["tunnel-nearest-bridge"] = "portCfgEnableTunneling";
        mapping["notification"] = "portCfgNotifyEnable";
        mapping["port-id-subtype"] = "portCfgPortIdSubtype";
        return mapping;
    };
}
