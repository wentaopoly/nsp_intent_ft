function RouterTopology() {

    var savedTopologyInterface = undefined;
    var savedTopologyOspf = undefined;
    var savedTopologyOspf3 = undefined;
    var savedTopologyLdp = undefined;
    var savedTopologyMpls = undefined;
    var savedTopologyRsvp = undefined;
    var savedTopologyISIS = undefined;

    this.setSavedTopologyISIS = function (isis) {
        this.savedTopologyISIS = isis;
    }

    this.getSavedTopologyISIS = function () {
        if (this.savedTopologyISIS == undefined) {
            this.savedTopologyISIS = topologyFactory.createServiceTopology();
        }
        return this.savedTopologyISIS;
    }

    this.setSavedTopologyMpls = function (mpls) {
        this.savedTopologyMpls = mpls;
    }

    this.getSavedTopologyMpls = function () {
        if (this.savedTopologyMpls == undefined) {
            this.savedTopologyMpls = topologyFactory.createServiceTopology();
        }
        return this.savedTopologyMpls;
    }

    this.setSavedTopologyRsvp = function (rsvp) {
        this.savedTopologyRsvp = rsvp;
    }

    this.getSavedTopologyRsvp = function () {
        if (this.savedTopologyLdp == undefined) {
            this.savedTopologyRsvp = topologyFactory.createServiceTopology();
        }
        return this.savedTopologyRsvp;
    }

    this.setSavedTopologyLdp = function (ldp) {
        this.savedTopologyldp = ldp;
    }

    this.getSavedTopologyLdp = function () {
        if (this.savedTopologyLdp == undefined) {
            this.savedTopologyLdp = topologyFactory.createServiceTopology();
        }
        return this.savedTopologyLdp;
    }

    this.setSavedTopologyInterface = function (interface) {
        this.savedTopologyInterface = interface;
    }

    this.getSavedTopologyInterface = function () {
        if (this.savedTopologyInterface == undefined) {
            this.savedTopologyInterface = topologyFactory.createServiceTopology();
        }
        return this.savedTopologyInterface;
    }

    this.setSavedTopologyOspf = function (ospf) {
        this.savedTopologyOspf = ospf;
    }

    this.getSavedTopologyOspf = function () {

        if (this.savedTopologyOspf == undefined) {
            this.savedTopologyOspf = topologyFactory.createServiceTopology();
        }

        return this.savedTopologyOspf;
    }

    this.setSavedTopologyOspf3 = function (ospf3) {
        this.savedTopologyOspf3 = ospf3;
    }

    this.getSavedTopologyOspf3 = function () {

        if (this.savedTopologyOspf3 == undefined) {
            this.savedTopologyOspf3 = topologyFactory.createServiceTopology();
        }

        return this.savedTopologyOspf3;
    }

}