load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'mediator-fwk'});
function NspRestconfFwk() {
    this.mediatorFwk = new MediatorFramework("NSP");
}

NspRestconfFwk.prototype.RESTCONF_HOST = "restconf-gateway";
NspRestconfFwk.prototype.RESTCONF_PORT = "443";
NspRestconfFwk.prototype.mediatorFwk = null;
NspRestconfFwk.prototype.SVC_CREATION_URL = "/restconf/data/nsp-service:services/service-layer?ignoreReadOnly=true";
NspRestconfFwk.prototype.SVC_UPDATE_URL = "/restconf/data/nsp-service:services/service-layer/{serviceType}={serviceId}?ignoreReadOnly=true";
NspRestconfFwk.prototype.SVC_GET_ALL_URL = "/restconf/data/nsp-service:services/service-layer";
NspRestconfFwk.prototype.SVC_DELETE_URL = "/restconf/data/nsp-service:services/service-layer/{serviceType}={serviceId}?ignoreReadOnly=true";
NspRestconfFwk.prototype.SVC_GET_URL = "/restconf/data/nsp-service:services/service-layer/{serviceType}={serviceId}";
NspRestconfFwk.prototype.TUNNEL_IDNEID_XPATH = "/nsp-service:services/tunnel-layer/mpls-tunnel[id='{id}'][source-ne-id='{neId}']|/nsp-service:services/tunnel-layer/gre-tunnel[id='{id}'][source-ne-id='{neId}']";
NspRestconfFwk.prototype.NSP_RESTCONF_INVENTORY_FIND_URL = "/restconf/operations/nsp-inventory:find";
NspRestconfFwk.prototype.SVC_FILTER = "/nsp-service:services/service-layer/{serviceType}/service-extension:{serviceType}-svc[intent-instance-identifier='{intentId}']";
NspRestconfFwk.prototype.NE_FILTER = "/nsp-equipment:network/network-element";
NspRestconfFwk.prototype.MPLSGRE_TUNNEL_XPATH_FILTER = "/nsp-service:services/tunnel-layer/mpls-tunnel[name='{tunnelName}']|/nsp-service:services/tunnel-layer/gre-tunnel[name='{tunnelName}']";
NspRestconfFwk.prototype.MPLS_TUNNEL_SOURCEDESTINATION_XPATH_FILTER = "/nsp-service:services/tunnel-layer/mpls-tunnel[source-ne-id='{source}'][destination-ne-id='{destination}']";
NspRestconfFwk.prototype.GRE_TUNNEL_SOURCEDESTINATION_XPATH_FILTER = "/nsp-service:services/tunnel-layer/gre-tunnel[source-ne-id='{source}'][destination-ne-id='{destination}']";
NspRestconfFwk.prototype.FIND_PORT_BY_NAME_XPATH_FILTER = "/nsp-equipment:network/network-element[ne-id='{neId}']/hardware-component/port[name='{portName}']";
NspRestconfFwk.prototype.FIND_LAG_BY_NAME_XPATH_FILTER = "/nsp-equipment:network/network-element[ne-id='{neId}']/lag[name='{portName}']";
NspRestconfFwk.prototype.ServiceSteeringParam = "/restconf/data/steering-parameters:parameters";

NspRestconfFwk.prototype.constructURL = function (path, method) {
    var url = "https://" + this.RESTCONF_HOST + ":" + this.RESTCONF_PORT + path;
    logger.debug("[RestconfFwk] {}Calling restconf via NSP Mediator: {}", method, url);
    return url;
};
NspRestconfFwk.prototype.getByXpath = function (xPath) {
    var url = this.constructURL("/restconf/data" + xPath, "GET");
    var response = this.mediatorFwk.fetch(url);
    logger.debug("[RestconfFwk][getByXpath] response = {}", JSON.stringify(response));
    if (response.httpStatus === 200)
    {
        return response["response"];
    }
    else
    {
        return null;
    }
};
NspRestconfFwk.prototype.findByXpath = function (xPath, depth, fields) {
    var url = this.constructURL(this.NSP_RESTCONF_INVENTORY_FIND_URL, "POST");
    var input = {};
    var ret = null;
    input["xpath-filter"] = xPath;

    if (depth !== undefined)
        input["depth"] = depth;

    if (fields !== undefined)
        input["fields"] = fields;
    var requestBody = {};
    requestBody["input"] = input;

    var response = this.mediatorFwk.post(url, requestBody);
    logger.debug("[RestconfFwk][findByXpath] response = {}", JSON.stringify(response));

    if (response.httpStatus === 200 && response)
    {
        var lRes = JSON.parse(response["response"]);
        if (lRes && lRes["nsp-inventory:output"])
        {
            var data = JSON.parse(response["response"])["nsp-inventory:output"]["data"];
            if (data.length !== 0)
                ret = data;
        }
    }
    return ret;
};

NspRestconfFwk.prototype.getPorts = function (neId) {
    if (!neId)
    {
        return [];
    }
    else
    {
        var portXPath = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/hardware-component/port[admin-state = '" + "locked" + "']";
        var ret = this.findByXpath(portXPath, 3, "name;description;admin-state;port-details");
        var result = {};
        if (ret)
        {
            var data = ret.map(function (port) {
                var obj = {};
                obj["port-id"] = (port["name"].replace("Port", "")).trim();
                if (port["port-details"])
                {
                    obj["port-index"] = port["port-details"][0]["port-index"]
                    obj["FDN"] = port["port-details"][0]["@"]["nsp-model:sources"];
                    obj["FDN"] = obj["FDN"][0];
                    let objFDNArr = obj["FDN"].split("network")[1].split("@portDetails");
                    obj["FDN"] = "network" + objFDNArr[0];
                }
                if(port["port-index"]){
                    obj["port-index"] = port["port-index"];
                }
                return obj;
            });
            result["data"] = JSON.stringify(data);
        }
        logger.info("RESULT IS : " + JSON.stringify(result["data"]));
        return result
    }
};

NspRestconfFwk.prototype.createService = function (serviceObj, serviceType) {
    logger.info("serviceType = {}, serviceObj = {}", serviceType, JSON.stringify(serviceObj));

    var url = this.constructURL(this.SVC_CREATION_URL, "POST");
    var requestBody = {};
    requestBody[serviceType] = [serviceObj];
    var response = this.mediatorFwk.post(url, requestBody);
    if (response.httpStatus !== 201)
    {
        logger.error("[RestconfFwk][createService] Failed to create service : {}", JSON.stringify(response));
    }
    else
    {
        logger.debug("[RestconfFwk][createService] Successfully created service : {}", JSON.stringify(requestBody));
    }
    return response;
};
NspRestconfFwk.prototype.updateService = function (serviceObj, serviceType) {
    logger.info("[RestconfFwk][updateService][PUT] serviceType = " + serviceType + ", serviceObj = " + JSON.stringify(serviceObj));

    var preurl = this.SVC_UPDATE_URL
        .replace("{serviceType}", serviceType)
        .replace("{serviceId}", serviceObj["service-id"]);
    var url = this.constructURL(preurl, "PUT");

    var requestBody = {};
    requestBody[serviceType] = [serviceObj];

    var response = this.mediatorFwk.put(url, requestBody);
    if (response.httpStatus !== 200 && response.httpStatus !== 204)
    {
        logger.error("[RestconfFwk][updateService] Failed to update service : {}", JSON.stringify(response));
    }
    else
    {
        logger.info("[RestconfFwk][updateService] Successfully updated service : {}", JSON.stringify(requestBody));
    }
    return response;
};
NspRestconfFwk.prototype.patchService = function (serviceObj, serviceType) {
    logger.info("[RestconfFwk][patchService][PATCH] serviceType = " + serviceType + ", serviceObj = " + JSON.stringify(serviceObj));

    var preurl = this.SVC_UPDATE_URL
        .replace("{serviceType}", serviceType)
        .replace("{serviceId}", serviceObj["service-id"]);
    var url = this.constructURL(preurl, "PATCH");

    var requestBody = {};
    requestBody[serviceType] = [serviceObj];

    var response = this.mediatorFwk.patch(url, requestBody);
    if (response.httpStatus !== 200 && response.httpStatus !== 204)
    {
        logger.error("[RestconfFwk][patchService] Failed to update service : {}", JSON.stringify(response));
    }
    else
    {
        logger.info("[RestconfFwk][patchService] Successfully updated service : {}", JSON.stringify(requestBody));
    }
    return response;
};
NspRestconfFwk.prototype.getNe = function (neIdFilter) {
    var xPath = null;
    if (neIdFilter)
    {
        xPath = this.NE_FILTER + "[contains('ne-id'," + neIdFilter + ")]";
    }
    else
    {
        xPath = this.NE_FILTER;
    }
    var result = {}
    var data = this.findByXpath(xPath, 2, 'ne-id;ne-name');
    if (data)
    {
        var ret = data.map(function (ne) {
            var obj = {}
            obj["deviceId"] = ne["ne-id"]
            obj["deviceName"] = ne['ne-name']
            return obj;
        });
        result["data"] = JSON.stringify(ret)
    }
    return result;
};
NspRestconfFwk.prototype.getAllServices = function () {
    var preurl = this.SVC_GET_ALL_URL;
    var url = this.constructURL(preurl, "GET");

    var response = this.mediatorFwk.fetch(url);
    logger.debug("[RestconfFwk][getAllServices] response = {}", JSON.stringify(response));
    return response;
};
NspRestconfFwk.prototype.getServiceByIntentId = function (serviceType, intentId) {
    var extSvc = this.getServiceExt(serviceType, intentId);
    var serviceId = null;
    if (extSvc && extSvc["@"] && extSvc["@"]["nsp-model:identifier"])
    {
        serviceId = extSvc["@"]["nsp-model:identifier"].split("'")[1];
    }

    if (serviceId)
    {
        var preurl = this.SVC_GET_URL
            .replace("{serviceType}", serviceType)
            .replace("{serviceId}", serviceId);
        var url = this.constructURL(preurl, "GET");

        var response = this.mediatorFwk.fetch(url);
        logger.debug("[RestconfFwk][getServiceByIntentId] response = {}", JSON.stringify(response));
        return response;
    }
    else
        return null;
};
NspRestconfFwk.prototype.getServiceExt = function (serviceType, intentId) {
    var preurl = this.SVC_FILTER
        .replace("{serviceType}", serviceType)
        .replace("{serviceType}", serviceType)
        .replace("{intentId}", intentId);

    var data = this.findByXpath(preurl, 2);
    if (data && data[0])
    {
        return data[0];
    }
    else
        return null;
};
NspRestconfFwk.prototype.deleteService = function (serviceType, serviceId) {
    var preurl = this.SVC_DELETE_URL
        .replace("{serviceType}", serviceType)
        .replace("{serviceId}", serviceId);
    var url = this.constructURL(preurl, "DELETE");

    var response = this.mediatorFwk.delete(url);
    logger.debug("[RestconfFwk][deleteService] response = {}", JSON.stringify(response));
    return response;
};
NspRestconfFwk.prototype.getTunnel = function (id, neId) {
    var xPathFilter = this.TUNNEL_IDNEID_XPATH
        .replace(/\{id\}/g, id)
        .replace(/\{neId\}/g, neId);
    var data = this.findByXpath(xPathFilter, 3);
    if (data)
    {
        return data[0];
    }
    else
        return null;
};
NspRestconfFwk.prototype.getServiceTunnelByName = function (tunnelName) {
    var xPathFilter = this.MPLSGRE_TUNNEL_XPATH_FILTER.replace(/\{tunnelName\}/g, tunnelName);
    var data = this.findByXpath(xPathFilter, 3);
    if (data)
    {
        return data[0];
    }
    else
        return null;
};
NspRestconfFwk.prototype.getPortByName = function (neId, portName) {
    var xPathFilter;
    if (portName && (portName.indexOf("LAG") !== -1 || portName.indexOf("Lag") !== -1 || portName.indexOf("lag") !== -1))
    {
        xPathFilter = this.FIND_LAG_BY_NAME_XPATH_FILTER
            .replace("{neId}", neId)
            .replace("{portName}", portName);
    }
    else
    {
        xPathFilter = this.FIND_PORT_BY_NAME_XPATH_FILTER
            .replace("{neId}", neId)
            .replace("{portName}", portName);
    }


    var data = this.findByXpath(xPathFilter, 3);
    if (data)
    {
        return data[0];
    }
    else
        return null;
};
NspRestconfFwk.prototype.getAccessHybridPortByNe = function (neId, seachText) {
    if (!neId)
    {
        return [];
    }
    else
    {
        var portXPath = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/hardware-component/port[boolean(port-details[port-mode='access' or port-mode='hybrid'])]";
        if (seachText)
        {
            portXPath = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/hardware-component/port[contains('name','" + seachText + "')][boolean(port-details[port-mode='access' or and port-mode='hybrid'])]"
        }
        var ret = this.findByXpath(portXPath, 3);
        if (ret)
        {
            var lagXpath = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/lag";
            if (seachText)
            {
                lagXpath = "/nsp-equipment:network/network-element[ne-id='" + neId + "']/lag[contains('name','" + seachText + "')]"
            }
            var lagData = this.findByXpath(lagXpath, 2);
            if (lagData)
            {
                //TODO -NSPD-268603-  LAG filter only hybid and access port
                ret = ret.concat(lagData);
            }
        }
        return ret.map(function (port) {
            return port["name"];
        });
    }
};
NspRestconfFwk.prototype.getServiceTunnelBySourceDestination = function (source, destination, steeringParam) {
    var xPathFilter = (this.MPLS_TUNNEL_SOURCEDESTINATION_XPATH_FILTER + "|" + this.GRE_TUNNEL_SOURCEDESTINATION_XPATH_FILTER)
        .replace(/\{source\}/g, source)
        .replace(/\{destination\}/g, destination);

    if (steeringParam)
    {
        xPathFilter = (this.MPLS_TUNNEL_SOURCEDESTINATION_XPATH_FILTER + "/service-extension:mpls-tunnel-ext/steering-parameter/labels[label='" + steeringParam + "']" + "|"
            + this.GRE_TUNNEL_SOURCEDESTINATION_XPATH_FILTER + "/service-extension:gre-tunnel-ext/steering-parameter/labels[label='" + steeringParam + "']")
            .replace(/\{source\}/g, source)
            .replace(/\{destination\}/g, destination);
    }
    var tunnelData = this.findByXpath(xPathFilter, 3);
    if (tunnelData && !steeringParam)
    {
        var ret = [];
        tunnelData.forEach(function (tunnel) {
            if (tunnel["id"])
            {
                ret.push(tunnel["id"]);
            }
        });
        logger.info("[RestconfFwk][getServiceTunnelBySourceDestination] ret = {}", JSON.stringify(ret));
        return ret;
    }
    else if (tunnelData && steeringParam)
    {
        var ret = [];
        tunnelData.forEach(function (tunnel) {
            if (tunnel["@"] && tunnel["@"]["nsp-model:identifier"])
            {
                ret.push(tunnel["@"]["nsp-model:identifier"].split("[")[1].replace("id='", "").replace("']", ""));
            }
        });
        logger.info("[RestconfFwk][getServiceTunnelBySourceDestination] ret = {}", JSON.stringify(ret));
        return ret;
    }
    else
        return [];
};
NspRestconfFwk.prototype.getSteeringParam = function () {
    var preurl = this.ServiceSteeringParam;
    var url = this.constructURL(preurl, "GET");
    var ret = [];
    var response = this.mediatorFwk.fetch(url)["response"];
    if (response["steering-parameters:parameters"]["parameter"])
    {
        response["steering-parameters:parameters"]["parameter"].forEach(function (param) {
            ret.push(param.label);
        });
    }
    logger.info("[RestconfFwk][getSteeringParam] response = {}", JSON.stringify(ret));
    return ret;
};
NspRestconfFwk.prototype.getNextSvcMgrId = function () {
    var url = this.constructURL("/restconf/data/nsp-resource-pool:resource-pools/numeric-resource-pools=ibsf-global-svc-id-pool,global/obtain-value-from-pool", "POST");
    var requestBody = {
        "nsp-resource-pool:input": {
            "total-number-of-resources": "1",
            "all-or-nothing": true,
            "owner": "svcmgrglobalid",
            "confirmed": true
        }
    };
    var svcMgrId = null;
    while (!svcMgrId)
    {
        var response = this.mediatorFwk.post(url, requestBody);
        if (!response.success)
        {
            logger.error("[RestconfFwk][createService] Failed to get svcMgrId : {}", JSON.stringify(response));
            throw new RuntimeException("Failed to populate svcMgrId : {}", response["response"]);
        }
        else
        {
            logger.debug("[RestconfFwk][createService] Successfully got svcMgrId : {}", JSON.stringify(requestBody));
        }
        if (response["response"])
        {
            response = JSON.parse(response["response"]);
            svcMgrId = response["nsp-resource-pool:output"]["result"][0]["value"];
            var nfmpPayload = {
                "fullClassName": "service.Service",
                "filter": {
                    "equal": {
                        "name": "objectFullName",
                        "value": "svc-mgr:service-" + svcMgrId
                    }
                },
                "resultFilter": {
                    "attribute": [
                        "objectFullName"
                    ],
                    "childrenFilters": []
                }
            };
            var nfmpFwk = new MediatorFramework("NFMP");
            var serviceFetch = nfmpFwk.post("/v3/search", nfmpPayload);
            if (serviceFetch.success && JSON.parse(serviceFetch.response).length > 0)
            {
                logger.error("[RestconfFwk][createService] svcMgrId : svc-mgr:service-{} is already in use. Fetching next number", svcMgrId);
                svcMgrId = null;
            }
        }
    }
    return svcMgrId;
};
