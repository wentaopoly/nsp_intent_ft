function NfmpSuggest() {
    this.getAreaSite = function (neId ,instanceId) {
        let className = "ospf.AreaSite";
        let searchObject = {
        "fullClassName": className,
        "filter": {
            "and": {
                "equal": [
                    {
                        "name": "siteId",
                        "value": neId
                    },
                    {
                       "name": "instanceIndex",
                       "value": instanceId

                   },
                   {
                      "name": "version",
                      "value": "2"
                   }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": [
                "areaId"
            ]
          }
        };
        return this.getData(searchObject, className, "areaId");
    }

  this.getSegmentRoutingAdjacencySetBinding = function (neId ,instanceId) {
        let className = "ospf.SegmentRoutingAdjacencySet";
        let searchObject = {
        "fullClassName": className,
        "filter": {
            "and": {
                "equal": [
                    {
                        "name": "siteId",
                        "value": neId
                    },
                    {
                       "name": "instanceIndex",
                       "value": instanceId
                   },
                   {
                      "name": "version",
                      "value": "2"
                   }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": [
                "adjsetId"
            ]
          }
        };
        return this.getData(searchObject, className, "adjsetId");
    }

   this.getInterfaceName = function (neId, actionConfig, areaId, instanceId) {
    let type = "displayedName";
    let classNames1 = "rtr.NetworkInterface";
    let classNames2 = "ospf.Interface";
    let searchObject1;
    let resultFetch1;
    let data1;
    let finalResult1;
    if (actionConfig === "associate" && !areaId) {
       return [];
    }
    let createSearchObject = function (className, nodeId) {
        let attributeList = [type];
        if (className === classNames1) {
            attributeList.push("id");
        } else if (className === classNames2) {
            attributeList.push("interfaceId");
        }
        let filter = {
            "and": {
                "equal": [
                    {
                        "name": "nodeId",
                        "value": nodeId
                    }
                ]
            }
        };
        if (actionConfig === "associate" && areaId && instanceId) {
            filter.and.equal.push({
                "name": "areaId",
                "value": areaId
            },{
              "name": "version",
              "value": "2"
            },
            {
              "name": "instanceIndex",
              "value": instanceId
            });
        }
        return {
            "fullClassName": className,
            "filter": filter,
            "resultFilter": {
                "children": "",
                "attribute": attributeList
            }
        };
    };
    if(actionConfig !== "associate" || actionConfig === undefined){
    searchObject1 = createSearchObject(classNames1, neId);
    resultFetch1 = nfmpFwk.post("/v3/search", searchObject1);
    data1 = JSON.parse(resultFetch1.response);
    finalResult1 = finalResponse(data1, classNames1, ["displayedName", "id"]);
    }
    let searchObject2 = createSearchObject(classNames2, neId);
    let resultFetch2 = nfmpFwk.post("/v3/search", searchObject2);
    let data2 = JSON.parse(resultFetch2.response);
    let finalResult2 = finalResponse(data2, classNames2, ["displayedName", "interfaceId"]);
    let result = [];
    if (actionConfig !== "associate"  && actionConfig !== undefined && finalResult2 !== undefined) {
        let displayedNames2 = new Set(finalResult2.map(item => item.displayedName));
        let filteredData1 = finalResult1.filter(item => item.id !== "1280" && !displayedNames2.has(item.displayedName));
        if (filteredData1.length > 0) {
            filteredData1.forEach(function (value) {
                result.push(value.displayedName);
            });
        }
    }else if (actionConfig === "associate" && finalResult2 !== undefined) {
       let filteredData2 = finalResult2.filter(item => item.interfaceId !== "1280");
        if (filteredData2.length > 0) {
            filteredData2.forEach(function (value) {
                result.push(value.displayedName);
            });
        }
    }else {
       let filteredData3 = finalResult1.filter(item => item.id !== "1280");
        if (filteredData3.length > 0) {
          filteredData3.forEach(function (value) {
          result.push(value.displayedName);
        });
      }
    }
    logger.info("finalResponse[{}] = " + JSON.stringify(result));
    return result;
};

function finalResponse(responseData, className, attributes) {
    let result = [];
    if (responseData !== undefined && responseData[className] !== undefined) {
        let finalResponse = responseData[className];
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        finalResponse.forEach(function (value) {
            let obj = {};
            attributes.forEach(attr => {
                obj[attr] = value[attr];
            });
            result.push(obj);
        });
    }
    return result;
}

    this.getInterfaceData = function (neId, interfaceData ,type, name) {
        let nfmpFwk = new NfmpFwk();
        let className = "rtr.NetworkInterface";
        let searchObject = {
        "fullClassName": className,
        "filter": {
            "and": {
                "equal": [
                    {
                        "name": "nodeId",
                        "value": neId
                    },
                    {
                        "name": name,
                        "value": interfaceData
                    }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": [
               type
             ]
           }
        };
    let resultFetch = nfmpFwk.post("/v3/search", searchObject);
    let finalResponse = JSON.parse(resultFetch.response);
    let data = (finalResponse[className] && finalResponse[className][type]);
    return data;
    }


   this.getData = function (searchObjectJson, className, type) {
        let nfmpFwk = new NfmpFwk();
        let ret = [];
        let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        let finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    ret.push(value[type]);
                })
            }
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

    this.getInstanceIndex = function (neId) {
        let className = "ospf.Site";
        let searchObject = {
        "fullClassName": className,
        "filter": {
            "and": {
                "equal": [
                    {
                        "name": "siteId",
                        "value": neId
                    },
                    {
                       "name": "version",
                       "value": "v2"
                    }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": [
                "instanceIndex"
             ]
           }
        };
        return this.getData(searchObject, className, "instanceIndex");
    }

    this.getAuthenticationKeyChain = function (neId) {
      let className = "security.KeyChain";
      let searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                         {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
             "displayedName"
                ]
            }
        };
        return this.getData(searchObject, className, "displayedName");
    }

    this.getRouteNextHopPointer = function (neId) {
      let className = "rtr.RouteNextHopPolicyTemplate";
      let searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                         {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
             "displayedName"
                ]
            }
        };
        return this.getData(searchObject, className, "displayedName");
    }

}
