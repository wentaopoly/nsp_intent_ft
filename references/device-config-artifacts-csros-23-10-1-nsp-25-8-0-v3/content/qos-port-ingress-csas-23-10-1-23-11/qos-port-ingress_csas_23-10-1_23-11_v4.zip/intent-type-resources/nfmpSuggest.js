load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {

    this.getPolicyId = function (neId) {
        var className = "sasqos.PortAccessIngress";
        var searchObject = {
            "fullClassName": className, "filter": {
                "and": {
                    "equal": [{
                        "name": "siteId", "value": neId
                    }]
                }
            }, "resultFilter": {
                "children": "", "attribute": ["id"]
            }
        };
        return this.getData(neId, searchObject, "id");
    }

    this.getDSCPClassificationPolicy = function (neId) {
        var searchObjectJson = {
            "fullClassName": "sasqos.DSCPClassification", "filter": {
                "and": {
                    "equal": [{
                        "name": "siteId", "value": neId
                    }]
                }
            }, "resultFilter": {
                "children": "", "attribute": ["id"]
            }
        };
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        finalResponse = finalResponse["sasqos.DSCPClassification"];
        logger.info(JSON.stringify(finalResponse));

        if (Object.keys(finalResponse).length !== 0) {
            if (!Array.isArray(finalResponse)) {
                finalResponse = [finalResponse];
            }
            finalResponse.forEach(function (value, index, array) {
                ret.push(value["id"]);
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

    this.getDot1pClassificationPolicy = function (neId) {
        var searchObjectJson = {
            "fullClassName": "sasqos.Dot1pClassification", "filter": {
                "and": {
                    "equal": [{
                        "name": "siteId", "value": neId
                    }]
                }
            }, "resultFilter": {
                "children": "", "attribute": ["id"]
            }
        };
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        finalResponse = finalResponse["sasqos.Dot1pClassification"];
        logger.info(JSON.stringify(finalResponse));

        if (Object.keys(finalResponse).length !== 0) {
            if (!Array.isArray(finalResponse)) {
                finalResponse = [finalResponse];
            }
            finalResponse.forEach(function (value, index, array) {
                ret.push(value["id"]);
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

    this.getData = function (target, searchObjectJson, type, PolicyAttribute) {
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.find(target, searchObjectJson);
        logger.info(LOG_PREFIX + resultFetch.response);
        var finalResponse = JSON.parse(resultFetch.response)["sasqos.PortAccessIngress"];
        logger.info(LOG_PREFIX + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                if (PolicyAttribute) {
                    logger.info(LOG_PREFIX + "Policy Selected = {}", PolicyAttribute);
                    logger.info(LOG_PREFIX + "Device policy = {}", finalResponse[index][type]);
                    ret.push(finalResponse[index][type]);
                    break;
                } else {
                    ret.push(finalResponse[index][type]);
                }
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "result = \n" + JSON.stringify(ret));
        return ret;
    }
}
