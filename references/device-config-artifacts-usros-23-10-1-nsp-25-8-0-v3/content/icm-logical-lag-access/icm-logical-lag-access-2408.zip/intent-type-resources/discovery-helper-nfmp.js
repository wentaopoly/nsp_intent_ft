var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});


function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();
    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let lagId = target.split("#")[3];
        let lagName = target.split("#")[2];

        let searchPayLoad = this.constructSearchString(neId, lagId);
        let searchResponse = nfmpFwk.post("search", searchPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find LAG-ID : " + lagId + ", LAG-Name : " + lagName + " on NE " + neId);
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse[0];
    }

    this.constructSearchString = function (neId, lagId) {
        let fullName = "fullName = 'network:" + neId + ":lag:interface-" + lagId + "'";
        let jsonPayLoad = {
            "filter": {
                "filterExpression": fullName
            },
            "fullClassName": "lag.Interface"
        };
        return jsonPayLoad;
    }

    this.extractDeviceConfig = function (defaultTargetData, fullDeviceConfig, initialPropertyName) {
        let lagConfig;
        let lagLacpConfig;
        let lagPortConfig = [];
        let lagBfdConfig;
        let lagBfdIpv6Config;
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        lagConfig = fullDeviceConfig['properties'];
        let lagChildrenConfig = fullDeviceConfig['children'];

        lagChildrenConfig.forEach(function (element) {
            if (element.fullClassName === 'lag.LacpConfiguration')
            {
                lagLacpConfig = element['properties'];
            }
            else if (element.fullClassName === 'lag.BFDConfiguration' && (element['properties']['familyType'] === "ipv4"))
            {
                lagBfdConfig = element['properties'];
            }
            else if (element.fullClassName === 'lag.BFDConfiguration' && (element['properties']['familyType'] === "ipv6"))
            {
                lagBfdIpv6Config = element['properties'];
            }
            else if (element.fullClassName === 'lag.PortTermination')
            {
                lagPortConfig.push(element['properties']);
            }
        });

        let deviceConfig = {
            "lagConfig": lagConfig,
            "lagLacpConfig": lagLacpConfig,
            "lagPortConfig": lagPortConfig,
            "lagBfdConfig": lagBfdConfig,
            "lagBfdIpv6Config": lagBfdIpv6Config
        };
        if (null !== lagConfig)
        {
            this.extractLagProperties(parsedDefaultTargetData, deviceConfig);
        }
        if (null !== lagLacpConfig)
        {
            this.extractLagLacpProperties(parsedDefaultTargetData['lag']['lacp'], deviceConfig);
        }

        let lagPortArray = this.extractLagPortProperties(parsedDefaultTargetData['lag']['port'], deviceConfig);
        parsedDefaultTargetData['lag']['port'] = lagPortArray;

        if (lagBfdConfig !== undefined)
        {
            this.extractLagBfdIpv4Properties(parsedDefaultTargetData['lag']['bfd-liveness']['ipv4'], deviceConfig, lagBfdConfig);
        }
        if (lagBfdIpv6Config !== undefined)
        {
            this.extractLagBfdIpv6Properties(parsedDefaultTargetData['lag']['bfd-liveness']['ipv6'], deviceConfig, lagBfdIpv6Config);
        }
        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData));
        //For IXR node Ipv6 is not supported
        if (parsedDefaultTargetData["lag"]["bfd-liveness"]["ipv6"]["admin-state"] === null)
        {
            delete parsedDefaultTargetData["lag"]["bfd-liveness"]["ipv6"];
        }
        return parsedDefaultTargetData;
    }

    this.extractLagProperties = function (defaultTargetData, deviceConfig) {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object')
            {
                let mappings = modelDeviceMapping.getLagMapping();
                this.traverseAndUpdateConfig(targetKey, targetObj, mappings, deviceConfig);
            }
        }
        if (defaultTargetData["lag"]["port-threshold"]["action"] !== "static-cost")
        {
            defaultTargetData["lag"]["port-threshold"]["cost"] = undefined;
        }
        return defaultTargetData;
    }
    this.extractLagBfdIpv4Properties = function (lagBfdTargetData, deviceConfig, lagBfdConfig) {
        let keys = Object.keys(lagBfdTargetData);
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = lagBfdTargetData[targetKey];
            let mappedKey = "lag.bfd-liveness.ipv4." + targetKey;
            let mappings = modelDeviceMapping.getLagBfdMapping();
            if (lagBfdConfig["familyType"] == "ipv4")
            {
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, lagBfdTargetData, deviceConfig);
            }

        }
        return lagBfdTargetData;
    }
    this.extractLagBfdIpv6Properties = function (lagBfdIpv6TargetData, deviceConfig, lagBfdIpv6Config) {
        let keys = Object.keys(lagBfdIpv6TargetData);
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = lagBfdIpv6TargetData[targetKey];
            let mappedKey = "lag.bfd-liveness.ipv6." + targetKey;
            let mappings = modelDeviceMapping.getLagBfdIpv6Mapping();
            if (lagBfdIpv6Config["familyType"] == "ipv6")
            {
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, lagBfdIpv6TargetData, deviceConfig);
            }

        }
        return lagBfdIpv6TargetData;
    }
    this.extractLagLacpProperties = function (lagLacpTargetData, deviceConfig) {
        let keys = Object.keys(lagLacpTargetData);
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = lagLacpTargetData[targetKey];
            let mappedKey = "lag.lacp." + targetKey;
            let mappings = modelDeviceMapping.getLagLacpMapping();
            this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, lagLacpTargetData, deviceConfig);
        }
        if (lagLacpTargetData.enableLacp === "false")
        {
            let keys = Object.keys(lagLacpTargetData);
            for (let i = 0; i < keys.length; i++)
            {
                let targetKey = keys[i];
                if (targetKey != "enableLacp")
                {
                    lagLacpTargetData[targetKey] = undefined;
                }
            }
        }
        else
        {
            if (lagLacpTargetData['system-priority'] == -1)
            {
                lagLacpTargetData['system-priority'] = undefined;
            }
        }
        return lagLacpTargetData;
    }

    this.extractLagPortProperties = function (lagPortTargetData, deviceConfig) {
        //logger.info("lagPortTargetData = \n" + JSON.stringify(lagPortTargetData) + "\n\n\nlagPortConfig = \n" + JSON.stringify(lagPortConfig));
        let lagPortArray = [];
        let portData = lagPortTargetData[0];
        let mappings = modelDeviceMapping.getLagPortMapping();
        for (let i = 0; i < deviceConfig.lagPortConfig.length; i++)
        {
            let devicePortConfig = deviceConfig.lagPortConfig[i];
            let keys = Object.keys(portData);
            logger.info("keys = " + keys);
            for (let j = 0; j < keys.length; j++)
            {
                let targetKey = keys[j];
                let targetObj = portData[targetKey];
                let mappedKey = "lag.port." + targetKey;
                //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj) + "\nmappedKey = " + mappedKey);
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, portData, devicePortConfig);
            }
            lagPortArray.push(JSON.parse(JSON.stringify(portData)));
        }
        return lagPortArray;
    }

    this.traverseAndUpdateConfig = function (objKey, obj, mappings, deviceConfig) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "lag.lacp" && mappedKey !== "lag.port" && mappedKey !== "lag.bfd-liveness")
            {
                if (value != null && typeof value === 'object')
                {
                    this.traverseAndUpdateConfig(mappedKey, value, mappings, deviceConfig);
                }
                else
                {
                    // call for each key with string value
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, deviceConfig);
                }
            }
        }
        return obj;
    }


    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, deviceConfig) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = "";
        if (mappedKey.startsWith("lag.lacp"))
        {
            deviceValue = deviceConfig.lagLacpConfig[nfmpKey];
        }
        else if (mappedKey.startsWith("lag.port."))
        {
            deviceValue = deviceConfig[nfmpKey];
        }
        else if (mappedKey.startsWith("lag.bfd-liveness.ipv4"))
        {
            deviceValue = deviceConfig.lagBfdConfig[nfmpKey];
        }
        else if (mappedKey.startsWith("lag.bfd-liveness.ipv6"))
        {
            deviceValue = deviceConfig.lagBfdIpv6Config[nfmpKey];
        }
        else
        {
            deviceValue = deviceConfig.lagConfig[nfmpKey];
        }
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);
    }

    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue !== null)
        {
            switch (mappedKey)
            {
                case "lag.admin-state":
                    deviceValue = util.convertToIntentAdminState(deviceValue);
                    break;
                case "lag.encap-type":
                    deviceValue = util.convertToIntentEncapType(deviceValue);
                    break;
                case "lag.port-threshold.action":
                    deviceValue = util.convertToIntentportThresholdAction(deviceValue);
                    break;
                case "system-id":
                    deviceValue = util.convertToIntentsystemId(deviceValue);
                    break;
                case "lag.bfd-liveness.ipv4.admin-state":
                    deviceValue = util.convertAdminStateBrownField(deviceValue);
                    break;
                case "lag.bfd-liveness.ipv6.admin-state":
                    deviceValue = util.convertAdminStateBrownField(deviceValue);
                    break;
                case "lag.port.sub-group":
                    deviceValue = util.convertSubGroupBrownField(deviceValue);
                    break;
                case "lag.bfd-liveness.ipv4.max-admin-down-time":
                    deviceValue = util.convertBfValueSupport(deviceValue);
                    break;
                case "lag.bfd-liveness.ipv4.max-setup-time":
                    deviceValue = util.convertBfValueSupport(deviceValue);
                    break;
                case "lag.bfd-liveness.ipv6.max-admin-down-time":
                    deviceValue = util.convertBfValueSupport(deviceValue);
                    break;
                case "lag.bfd-liveness.ipv6.max-setup-time":
                    deviceValue = util.convertBfValueSupport(deviceValue);
                    break;
            }
            return deviceValue;
        }
    }
}
