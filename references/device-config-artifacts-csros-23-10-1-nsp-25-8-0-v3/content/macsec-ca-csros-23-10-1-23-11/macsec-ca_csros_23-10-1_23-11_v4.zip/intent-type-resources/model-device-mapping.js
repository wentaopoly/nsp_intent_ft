function ModelDeviceMapping() {
    this.getMacSecCaMapping = function () {
        var mapping = {};
        mapping['connectivity-association.admin-state'] = 'administrativeState';
        mapping['connectivity-association.description'] = 'description';
        mapping['connectivity-association.replay-window-size'] = 'replayWindowSize';
        mapping['connectivity-association.replay-protection'] = 'replayProtect';
        mapping['connectivity-association.macsec-encrypt'] = 'macsecEncrypt';
        mapping['connectivity-association.clear-tag-mode'] = 'clearTagMode';
        mapping['connectivity-association.encryption-offset'] = 'encryptOffset';
        mapping['connectivity-association.cipher-suite'] = 'cipherSuite';
        mapping['connectivity-association.anysec-reserved'] = 'anySecReserved';
        mapping['keying-parameters.skip-offline-nodes'] = 'skipOfflineNodes';
        mapping['keying-parameters.key-source'] = 'hsmMode';
        mapping['keying-parameters.hsm-id'] = 'hsmConfigPointer';
        mapping['static-cak.active-psk'] = 'activePskIndex';
        mapping['static-cak.mka-hello-interval'] = 'helloInterval';
        mapping['static-cak.mka-key-server-priority'] = 'keyServerPriority';
        return mapping;
    }

    this.getPreSharedKeyMapping = function () {
        var mapping = {};
        mapping['pre-shared-key.psk-id'] = 'pskId';
        mapping['pre-shared-key.encryption-type'] = 'encryptType';
        return mapping;
    }

    this.getSiteMapping = function () {
        var mapping = {};
        mapping['sites.site-id'] = 'siteId';
        mapping['sites.delay-protection'] = 'delayProtection';
        mapping['inherit-global-parameters.admin-state'] = 'administrativeState';
        mapping['inherit-global-parameters.description'] = 'description';
        mapping['inherit-global-parameters.replay-window-size'] = 'replayWindowSize';
        mapping['inherit-global-parameters.replay-protection'] = 'replayProtect';
        mapping['inherit-global-parameters.mka-hello-interval'] = 'helloInterval';
        mapping['inherit-global-parameters.mka-key-server-priority'] = 'keyServerPriority';
        mapping['edit-admin-state'] = 'administrativeState';
        mapping['edit-description'] = 'description';
        mapping['edit-replay-window-size'] = 'replayWindowSize';
        mapping['edit-replay-protection'] = 'replayProtect';
        mapping['edit-mka-hello-interval'] = 'helloInterval';
        mapping['edit-mka-key-server-priority'] = 'keyServerPriority';
        return mapping;
    }
}
