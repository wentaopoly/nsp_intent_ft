load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
load({script: resourceProvider.getResource("parse-target.js"), name: "ParseTarget"});
load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
function CustomHooks() {
var ipv6AddressUtil = new IPv6AddressUtil();
    /**
   * PreAudit Hook
   */
  const preAudit = (inputObj) => {
     /**
     * Write your custom preAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName
     *
     */

    logger.info("[CUSTOM-HOOKS] preAudit call" + JSON.stringify(inputObj));
    var config = inputObj["intentConfig"];
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(config));

        if(config["ipv4-node-sid"] && config["ipv4-node-sid"]["clear-n-flag"] == false) {
          delete config["ipv4-node-sid"]["clear-n-flag"];
        }

        if(config["ipv6-node-sid"] && config["ipv6-node-sid"]["clear-n-flag"] == false) {
          delete config["ipv6-node-sid"]["clear-n-flag"];
        }

        var flag = 0;

        if(config["mesh-group"] && config["mesh-group"]["blocked"] == false) {
          flag = 1;
        }

        inputObj["intentConfig"] = config;
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

    var target = inputObj["target"];
    var intentConfig = inputObj["intentConfig"];
    var intentDeviationObj = new IntentDeviceDeviation();
    var neId = parseTarget.getNeIdFromTarget(target);
    intentConfig = intentDeviationObj.removeIntentConfig(JSON.stringify(intentConfig), neId);
    intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
    logger.info("preAudit intent config after removing deviation attributes: " + JSON.stringify(intentConfig));

    if(flag == 1) {
      intentConfig["mesh-group"] = {"blocked": [null]};
    }
    return intentConfig;

  };

  /**
   * PostAudit Hook
   */
  const postAudit = (inputObj) => {
    /**
     * Write your custom postAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName, auditReport
     *
     */

    logger.info("[CUSTOM-HOOKS] postAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));


  };

  /**
   * PreSync Hook
   */
    /**
     * PreSync Hook
     */
    const preSync = (inputObj) => {
        /**
         * Write your custom preSync logic here
         * inputObj by default contains the following keys:
         *          target, config, intentTypeName, rootXPath,
         *          intentContainer, uniqueIdentifier, deviceYangModuleName
         *          topology, state, syncResult
         */
        logger.info("[CUSTOM-HOOKS] preSync call");
        var config = JSON.parse(inputObj["config"]);
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(config));

        if(config[0]["router-isis-interface_msros_23-10-1_24-4:router-isis-interface_msros_23-10-1_24-4"]["interface"] && config[0]["router-isis-interface_msros_23-10-1_24-4:router-isis-interface_msros_23-10-1_24-4"]["interface"]["ipv4-node-sid"] && config[0]["router-isis-interface_msros_23-10-1_24-4:router-isis-interface_msros_23-10-1_24-4"]["interface"]["ipv4-node-sid"]["clear-n-flag"] == false) {
          delete config[0]["router-isis-interface_msros_23-10-1_24-4:router-isis-interface_msros_23-10-1_24-4"]["interface"]["ipv4-node-sid"]["clear-n-flag"];
        }


        if(config[0]["router-isis-interface_msros_23-10-1_24-4:router-isis-interface_msros_23-10-1_24-4"]["interface"] && config[0]["router-isis-interface_msros_23-10-1_24-4:router-isis-interface_msros_23-10-1_24-4"]["interface"]["ipv6-node-sid"] && config[0]["router-isis-interface_msros_23-10-1_24-4:router-isis-interface_msros_23-10-1_24-4"]["interface"]["ipv6-node-sid"]["clear-n-flag"] == false) {
          delete config[0]["router-isis-interface_msros_23-10-1_24-4:router-isis-interface_msros_23-10-1_24-4"]["interface"]["ipv6-node-sid"]["clear-n-flag"];
        }
        var flag = 0;
        if(config[0]["router-isis-interface_msros_23-10-1_24-4:router-isis-interface_msros_23-10-1_24-4"]["interface"] && config[0]["router-isis-interface_msros_23-10-1_24-4:router-isis-interface_msros_23-10-1_24-4"]["interface"]["mesh-group"] && config[0]["router-isis-interface_msros_23-10-1_24-4:router-isis-interface_msros_23-10-1_24-4"]["interface"]["mesh-group"]["blocked"]) {
          flag = 1;
        }

        var target = inputObj["target"];
        config = this.removeEmptyContainers("", config, "", target);

        if(flag == 1) {
          config[0]["router-isis-interface_msros_23-10-1_24-4:router-isis-interface_msros_23-10-1_24-4"]["interface"]["mesh-group"] = {"blocked":[null]};
        }



        var intentTypeName = inputObj["intentTypeName"];
        var intentContainer = inputObj["intentContainer"];
        var intentDeviationObj = new IntentDeviceDeviation();
        var neId = parseTarget.getNeIdFromTarget(target);
        if (!Array.isArray(config)) {
            config = [config];
        }
        let preSyncConf = [];
        for (var index in config) {
            var confObj= config[index][intentTypeName + ":" + intentTypeName][intentContainer];
            let configObj = JSON.stringify(confObj);
            if (confObj && confObj["entry"]) {
            for (let i=0; i<confObj["entry"].length; i++) {
            let psEntryConf = confObj["entry"][i];

             }
          }
           if (confObj && confObj["named-entry"]) {
           for (let j=0; j<confObj["named-entry"].length; j++) {
           let psNamedEntryConf = confObj["named-entry"][j];

             }
           }
            let deviatedObj = intentDeviationObj.removeIntentConfig(configObj, neId);
            let finalConfigObj = {};
            let intentKey = intentTypeName + ":" + intentTypeName
            finalConfigObj[intentKey] = {};
            finalConfigObj[intentKey][intentContainer] = deviatedObj;
            preSyncConf.push(finalConfigObj);
        }
        logger.info("intent config after removing deviation attributes: " + JSON.stringify(preSyncConf));
        return JSON.stringify(preSyncConf);
    };

  /**
   * PostSync Hook
   */
  const postSync = (inputObj) => {
    /**
     * Write your custom postSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] postSync call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

  };

  /**
   *
   * PostDiscovery Hook
   */
  const postDiscovery = (inputObj) => {
    /**
     * Write your custom postDiscovery logic here
     * inputObj by default contains the following keys:
     *        deviceConfig, intentContainer, neId,
     *        targetDataStruct, templateName, deviceYangModuleName
     */

    logger.info("[CUSTOM-HOOKS] postDiscovery call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

  }
    this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }

  this.preAudit = preAudit;
  this.postAudit = postAudit;
  this.preSync = preSync;
  this.postSync = postSync;
  this.postDiscovery = postDiscovery;

}