
var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
  "ibn" : "http://www.nokia.com/management-solutions/ibn",
  "nc" : "urn:ietf:params:xml:ns:netconf:base:1.0",
  "device-manager" : "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
  "http://www.nokia.com/management-solutions/anv-device-holders" : "anv-device-holders"
};


load({script:resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk()

load({script:resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var nspIntentHelper = new NspIntentHelper();


var intentTypeName = 'icm-equipment-port-e_m';
var initialPropertyName = 'port';
var uniqueIdentifier = "port-id";
var parentXpath = 'configure';


function synchronize(input) {
  //var result = synchronizeResultFactory.createSynchronizeResult();
  // Code to synchronize goes here

  logger.info("Intent Synchronization started !!!");
  return nspIntentHelper.synchronize(input,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier);

  //result.setSuccess(true);
  //return result;
}

function onAudit(target, config, svcTopo, adminState) {
  logger.info('Intent Audit started');

  return nspIntentHelper.audit(target, config, svcTopo, adminState,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier);
}

function getTargetData(input) {
  logger.info(input);
  var target = input.target;
  var config = null;
  logger.info("target=" + target);
  var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
  logger.info(JSON.stringify(deviceConfig));
  var data = gtdFwk.gtdSend(deviceConfig);
  return data.msg.result;
}
