function ModelDeviceMapping() {
    this.getTimingMapping = function () {
        var mapping = {};
        mapping['central-frequency-clock.ql-minimum'] = 'minQualityLevel';
        mapping['central-frequency-clock.ql-selection'] = 'qualityLevel';
        mapping['central-frequency-clock.revert'] = 'revertive';
        mapping['central-frequency-clock.wait-to-restore'] = 'waitToRestore';
        mapping['central-frequency-clock.ref-order.first'] = 'firstTimingReferenceInput';
        mapping['central-frequency-clock.ref-order.second'] = 'secondTimingReferenceInput';
        mapping['central-frequency-clock.ref-order.third'] = 'thirdTimingReferenceInput';
        mapping['central-frequency-clock.ref-order.fourth'] = 'fourthTimingReferenceInput';
        mapping['central-frequency-clock.ref-order.fifth'] = 'fifthTimingReferenceInput';
        mapping['central-frequency-clock.ref-order.sixth'] = 'sixthTimingReferenceInput';
        mapping['central-frequency-clock.ref1.admin-state'] = 'firstTimingReferenceAdministrativeState';
        mapping['central-frequency-clock.ref1.ql-override'] = 'firstTimingReferenceQualityLevel';
        mapping['central-frequency-clock.ref1.source-port'] = 'firstTimingReferencePortName';
        mapping['central-frequency-clock.ref2.admin-state'] = 'secondTimingReferenceAdministrativeState';
        mapping['central-frequency-clock.ref2.ql-override'] = 'secondTimingReferenceQualityLevel';
        mapping['central-frequency-clock.ref2.source-port'] = 'secondTimingReferencePortName';
        mapping['central-frequency-clock.bits.interface-type'] = 'bitsInterfaceType';
        mapping['central-frequency-clock.bits.ql-override'] = 'bitsQualityLevel';
        mapping['central-frequency-clock.bits.ssm-bit'] = 'saBit';
        mapping['central-frequency-clock.bits.input.admin-state'] = 'bitsAdministrativeState';
        mapping['central-frequency-clock.bits.output.admin-state'] = 'bitsOutputState';
        mapping['central-frequency-clock.bits.output.line-length'] = 'bitslineLength';
        mapping['central-frequency-clock.bits.output.ql-minimum'] = 'bitsOutQlMinimum';
        mapping['central-frequency-clock.bits.output.source'] = 'bitsSource';
        mapping['central-frequency-clock.bits.output.squelch'] = 'bitsOutSquelch';
        mapping['central-frequency-clock.ptp.admin-state'] = 'ptpAdministrativeState';
        mapping['central-frequency-clock.ptp.ql-override'] = 'ptpQualityLevel';
        mapping['central-frequency-clock.synce.admin-state'] = 'syncEAdministrativeState';
        mapping['central-frequency-clock.synce.ql-override'] = 'syncEQualityLevel';
        mapping['central-frequency-clock.gnss.admin-state'] = 'gnssAdminStatus';
        mapping['central-frequency-clock.gnss.ql-override'] = 'gnssQltyLevel';

        return mapping;
    }
}
