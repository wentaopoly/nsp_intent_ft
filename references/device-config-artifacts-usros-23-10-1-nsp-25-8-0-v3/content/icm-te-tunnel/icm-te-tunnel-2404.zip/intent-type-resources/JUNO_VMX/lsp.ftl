<#ftl output_format="JSON">
<#setting number_format="computer">
{
        "name": "${target}",
        "from": "${device}",
        "to": "${config["destination"]}",
        <#if config["protection"]["enable"] == true>
        "fast-reroute" : {},
    </#if> 
     
  <#if config["admin-state"] == "tunnel-admin-state-down">
        "admin-down" : ["null"],
    </#if>
   "description": "${config["description"]}"
             
   <#if extraParams.primary?size != 0>
    <#list extraParams.primary?values as value>

        <#if value["conf"]["preference"]?has_content>,</#if>
        <#if value["conf"]["preference"]??>
            "preference":"${value["conf"]["preference"]}"
        </#if>
        <#if value["name"]?has_content>,</#if>
        <#if value["name"]??>
        "primary":[ {
            "name": "${value["name"]}"
            <#if value["conf"]["te-bandwidth"]?has_content>,
            "bandwidth": {
                "per-traffic-class-bandwidth": "${value["conf"]["te-bandwidth"]["generic"]}"
            }
            </#if>
        }]
        </#if>
        
    </#list>
    </#if>



 <#if extraParams.secondary?size != 0>
 ,
    "secondary": [
        <#list extraParams.secondary?values as value>
        {
            "name": "${value["name"]}"
            <#if value["conf"]["te-bandwidth"]?has_content>,
            "bandwidth": {
                "per-traffic-class-bandwidth": "${value["conf"]["te-bandwidth"]["generic"]}"
            }
            </#if>
        }
        <#if value?has_next>,</#if>
        </#list>
    ]
    </#if>

}
