var RuntimeException = Java.type("java.lang.RuntimeException");

var prefixToNsMap = {
  ibn: "http://www.nokia.com/management-solutions/ibn",
  nc: "urn:ietf:params:xml:ns:netconf:base:1.0",
  "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
  "http://www.nokia.com/management-solutions/anv-device-holders":
    "anv-device-holders",
};

load({ script: resourceProvider.getResource("mdc-fwk.js"), name: "MdcFwk" });
const mdcFwk = new MdcFwk();

load({ script: resourceProvider.getResource("mdt-fwk.js"), name: "MdtFwk" });
var mdtFwk = new MdtFwk();

load({
  script: resourceProvider.getResource("parse-target.js"),
  name: "ParseTarget",
});
var parsedTarget = new ParseTarget();

/**
 * Load lodash and create object as underscore(_)
 */
load({
  script: resourceProvider.getResource("lodash.js"),
  name: "Lodash",
});
const _ = new Lodash();

/**
 * Load Deep-diff and create object as DeepDiff
 */
load({
  script: resourceProvider.getResource("deep-diff.js"),
  name: "DeepDiff",
});
const deepDiff = new DeepDiff();

/**
 *
 * Load and instantiate UtilFwk
 * @see UtilFwk
 */
load({
  script: resourceProvider.getResource("util-fwk.js"),
  name: "UtilFwk",
});
const utilFwk = new UtilFwk();

/**
 *
 * Load and instantiate ICMFwk
 * It contain ICM framework specific functions
 *
 * @see ICMFwk
 */
load({ script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk" });
const icmFwk = new ICMFwk();

/**
 * Load and instance IcmServiceFwk
 *
 * @see GtdFWk
 */
load({
  script: resourceProvider.getResource("icm-service-fwk.js"),
  name: "icm-service-fwk",
});
const icmServiceFwk = new IcmServiceFwk();

load({
  script: resourceProvider.getResource("common-utils.js"),
  name: "CommonUtil",
});

load({
  script: resourceProvider.getResource("custom-hooks.js"),
  name: "CustomHooks",
});

const customHooks = new CustomHooks();

load({script: resourceProvider.getResource('mdSuggest.js'), name: 'mdSuggest'});

var commonUtil = new CommonUtil();

const metadata = JSON.parse(resourceProvider.getResource("meta-data.json"));

var intentTypeName = 'router-ospf-interface_msros_24-10-1_24-4';

/**
 * The node which you would like to configure.
 * example port, sap-ingress etc.
 * In the intent-yang, you will see this as a container
 * which encapsulates all the different type of nodes
 */
var intentContainer = 'interface';

var deviceYangModuleName = 'nokia-conf';

// unique identifier
var uniqueIdentifier = 'interface-name';

// example "configure" , "configure/qos" etc..
var rootXPath = 'configure/router=Base/ospf={$ospf-instance}/area={$area-id}';

/**
 *
 * @param {*} input
 */
function validate(input) {
  logger.info("--------------Intent validate --------------");
  var config = formatConfig(input.getJsonIntentConfiguration());
  logger.info("config " + config);
}

/**
 *
 * This function is starting point by IM for sync operation
 *
 * @param {*} input
 * @returns
 */
function synchronize(input) {
  /**
   * Deployment of intents to the network, called for synchronize operations.
   * Used to apply create, update, delete and reconcile to managed devices.
   *
   * All created objects are remembered/restored as part of topology/extra-data
   * to apply house-keeping operations.
   *
   **/
  logger.info("--------------Intent Synchronisation started--------------");
  logger.info("input " + input);
  logger.info("intentTypeName " + intentTypeName);
  logger.info("intentContainer " + intentContainer);
  logger.info("uniqueIdentifier " + uniqueIdentifier);
  logger.info("deviceYangModuleName " + deviceYangModuleName);

  // TODO, so far the code is handling single intentContainer
  // but there can be multuple top level containers like the case of cpm-filter having ip-filter, ipv6-filter and mac-filter
  // format the config as per your use-case
  var config = formatConfig(input.getJsonIntentConfiguration());
  logger.info("config " + config);

  var target = input.getTarget();
  logger.info("rootXPath " + getRootXPath(target));
  var state = input.getNetworkState().name();
  logger.info("state " + state);
  var startTime = new Date().getTime();
  var syncResult = synchronizeResultFactory.createSynchronizeResult();
  logger.info(
    intentTypeName + ":synchronize(" + target + ") in state " + state
  );
  // current topology
  var topology = input.getCurrentTopology();
  if (topology == null) {
    topology = topologyFactory.createServiceTopology();
  }
  logger.info("topology " + JSON.stringify(topology));
  var resp = utilFwk.synchronize(
    target,
    config,
    intentTypeName,
    getRootXPath(target),
    intentContainer,
    uniqueIdentifier,
    deviceYangModuleName,
    topology,
    state,
    syncResult
  );
  var endTime = Date.now();
  var timeTaken = (endTime - startTime) / 1000; // seconds
  logger.info(
    "Time taken to synchronize " + timeTaken + " seconds for intent " + target
  );
  var endTime = Date.now();
  var timeTaken = (endTime - startTime) / 1000; // seconds
  logger.info("Time taken to synchronize " + timeTaken);
  logger.info("--------------Intent Synchronisation done--------------");
  return resp;
}

/**
 *
 * The function is starting point for audit operation in IM
 *
 * @param {*} input
 * @returns auditReport
 */
function audit(input) {
  logger.info("-------------- Intent Audit --------------");
  var startTime = new Date().getTime();
  var target = input.getTarget();
  var key = intentTypeName + ":" + intentTypeName;
  var intentConfig = JSON.parse(input.getJsonIntentConfiguration())[0][key][
    intentContainer
  ];
  var state = input.getNetworkState().name();
  var topology = input.getCurrentTopology();

  logger.info("target " + target);
  logger.info("topology " + topology);
  logger.info("state " + state);
  logger.info("intentConfig " + JSON.stringify(intentConfig));
  let auditReport = utilFwk.audit(
    target,
    intentConfig,
    topology,
    state,
    intentTypeName,
    getRootXPath(target),
    intentContainer,
    uniqueIdentifier,
    deviceYangModuleName
  );
  var endTime = Date.now();
  var timeTaken = (endTime - startTime) / 1000; // seconds
  logger.info(
    "Time taken to audit " + timeTaken + " seconds for intent " + target
  );
  return auditReport;
}

/**
 *
 * The function is used in Brownfield disscovery by ICM FW
 * It discover the configuration from the target device
 * and manipulate as per Template's default-target-data
 *
 *
 * @see ICMFwk for more details
 * @param {*} input - the config data of a deployment
 * @returns result - the result of the operation
 */
function getTargetData(input) {
  logger.info("-------- Intent getTargetData started ------");
  logger.info(JSON.stringify(input));
  var target = input.target;
  logger.info("target=" + target);
  var deviceConfig = icmFwk.getDeviceConfiguration(
    target,
    deviceYangModuleName,
    getRootXPath(target),
    intentContainer
  );
  logger.info(JSON.stringify(deviceConfig));
  var data = icmServiceFwk.gtdSend(deviceConfig);
  logger.info(JSON.stringify(data));
  logger.info(JSON.stringify(data.msg.result));
  return data.msg.result;
}

function getRootXPath(target)
{
  var parseTarget = new ParseTarget();
  var ospf_instance = parseTarget.getOspfInstance(target);
  var area_id = parseTarget.getOspfArea(target);
  var rootXPath = 'configure/router=Base/ospf={$ospf-instance}/area={$area-id}';
  rootXPath = rootXPath.replace("{$ospf-instance}", ospf_instance);
  rootXPath = rootXPath.replace("{$area-id}", area_id);
  logger.info("Root XPath: " + rootXPath);
  return rootXPath;
}
function suggestKeychain(context) {
  logger.info("suggetKeychain context = \n" + context);
  var neId = getNeId(context);
  logger.info("Suggest for Keychain under NE: "+ neId);
  return navigateInstance(neId).getKeychains(neId);
}

function suggestRouteNHTemplate(context) {
  logger.info("suggestRouteNHTemplate context = \n" + context);
  var neId = getNeId(context);
  logger.info("Suggest for RouteNHTemplate under NE: "+ neId);
  return navigateInstance(neId).getRouteNHTemplate(neId);
}

function suggestAdjacencySet(context) {
  logger.info("suggestAdjacencySet context = \n" + context);
  var neId = getNeId(context);
  var instanceId = context.getInputValues()["arguments"]["target_ospf-instance"];
  if(context.getInputValues()["target"])
  {
    instanceId = context.getInputValues()["target"]["ospf-instance"];
  }

  logger.info("Suggest for AdjacencySet under NE: "+ neId + " ospf-instance: " + instanceId);
  return navigateInstance(neId).getAdjacencySet(neId,instanceId);
}
function suggestOspfInstance(context) {
  logger.info("suggestOspfInstance context = \n" + context);
  var neId = getNeId(context);
  logger.info("Suggest for ospf instances under NE: "+ neId);
  return navigateInstance(neId).getOspfInstance(neId);
}

function suggestOspfArea(context) {
  logger.info("suggestOspfArea context = \n" + context);
  var neId = getNeId(context);
  var instanceId = context.getInputValues()["arguments"]["target_ospf-instance"];
  logger.info("Suggest for ospf areas under NE: "+ neId + " ,Instance: " + instanceId);
  return navigateInstance(neId).getOspfArea(neId, instanceId);
}

function suggestOspfInterfaceName(context) {
  logger.info("suggestOspfInterfaceName context = \n" + context);
  var neId = getNeId(context);
  var instanceId = context.getInputValues()["arguments"]["target_ospf-instance"];
  let actionData=context.getInputValues()["action"];
  var area = context.getInputValues()["arguments"]["target_area-id"];
  logger.info("Suggest for ospf interfaces under NE: "+ neId + " ,Instance: " + instanceId  + " ,Area: " + area + " ,action:"+actionData);
  return navigateInstance(neId).getOspfInterface(actionData, neId, instanceId, area);
}
function getNeId(context) {
  var neId;
  var target = context.getInputValues()["target"]["objectidentifier"];
  logger.info("target : {}", target)
  if (!target) {
    target = context.getInputValues()["arguments"]["__root"]["target_objectidentifier"];
  }
  if (target) {
    if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
      neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
    } else {
      neId = target;
    }
  }
  logger.info("NeId identified " + " : {}", neId);
  return neId;
}

function navigateInstance(neId) {
  var managerName = mdtFwk.getManagerName(neId);
  logger.info('Device: ' + neId + ' is managed by: ' + managerName);
  switch (managerName) {
    case 'MDC':
      logger.info('Device is managed by MDM')
      return new MdSuggest();
      break;
    default:
      logger.info('Device is not managed')
      throw new RuntimeException('Device is not Managed')
  }
  return ''
}

/**
 *
 * If there are multiple containers at in intent-yang for intentContainer name,
 * the config returned by the scriptEnginer is array
 *
 * @param {*} config
 * @returns
 */
const formatConfig = (config) => {
  if (Array.isArray(config)) {
    return config[0];
  } else {
    return config;
  }
};