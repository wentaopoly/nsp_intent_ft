package com.nokia.nsp.mdt.intents.ibsf.resync.mdc;

//this sets tunnel-binding source-ne-name, destination-ne-name and destination-ne-id for greenfield/brownfield
//Also sets extra sources in nsp-sync for brownfield

import com.nokia.nsp.md.common.IExecutionContext;
import com.nokia.nsp.md.common.IYangObject;
import com.nokia.nsp.md.common.YangObject;
import com.nokia.nsp.md.db.yang.api.ExecutionContext;
import com.nokia.nsp.md.db.yang.api.QueryParameters;
import com.nokia.nsp.md.ifg.yang.api.Fields;
import com.nokia.nsp.md.resync.api.IMdResyncFw;
import com.nokia.nsp.md.resync.api.IResyncClassHandler;
import com.nokia.nsp.md.resync.api.NotificationType;
import com.nokia.nspos.persistence.impl.db.transaction.Transactor;
import com.nokia.nspos.persistence.impl.db.transaction.TxPhase;
import com.nokia.nspos.persistence.yang.api.IYangDB;
import javax.persistence.FlushModeType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class PostProcessTunnelBindingResync implements IResyncClassHandler {
    private static final Logger logger = LoggerFactory.getLogger(PostProcessTunnelBindingResync.class.getName() + ".postProcessObject");
    static ThreadLocal<Map<String, Map<String, String>>> tunnelDetailsCache = new ThreadLocal<>();
    static ThreadLocal<Map<String, String>> neServiceIdCache = new ThreadLocal<>();
    IMdResyncFw iMdResyncFw;
    IYangDB yangDB;

    private static void addSources(Object aInSources, String aInNeServiceId, String aInNeId, String aInNspIdentifer, Map<String, Object> aInTunnelBindDetails) {
        if (aInSources != null && aInSources instanceof ArrayList) {
            ArrayList lSources = (ArrayList) aInSources;
            String lFdn = null;
            for (Object lSource : lSources) { //loop sources to find one with service-name and sdp-bind-id
                if (lSource.toString().contains("service-name") && lSource.toString().contains("sdp-bind-id")) { //need to change for multi-vendor
                    lFdn = lSource.toString();
                    break;
                }
            }

            List<String> fdnsToAdd = new ArrayList<>();
            if (aInNeServiceId != null) {

                String lSvcKeyAndId = "service-id='" + aInNeServiceId + "'";
                {
                    //TODO: xpath parser
                    final String lSdpName = lFdn.substring(lFdn.lastIndexOf("[") + 1, lFdn.lastIndexOf("]"));
                    final String lBindType = (aInTunnelBindDetails != null && aInTunnelBindDetails.containsKey("tunnel-binding-type") && aInTunnelBindDetails.get("tunnel-binding-type") != null && aInTunnelBindDetails.get("tunnel-binding-type").toString().equals("mesh")) ? "mesh" : "spoke";
                    //TODO: Verify if cmodel fdn should be mesh for mesh sdps?
                    String lMdmAmiModelObj = "fdn:app:mdm-ami-cmodel:" + aInNeId + ":service:ServiceResourceBinding:/service[" + lSvcKeyAndId + "]/" + "spoke" + "-sdp[" + lSdpName + "]";
                    fdnsToAdd.add(lMdmAmiModelObj);
                }
            }

            if (lFdn != null && lFdn.contains("state")) {
                fdnsToAdd.add(lFdn.replace("state", "configure"));
            } else if (lFdn != null && lFdn.contains("configure")) {
                fdnsToAdd.add(lFdn.replace("configure", "state"));
            } else {
                logger.error("fdn from nsp-model:sources should include state/configure. fdn=" + lFdn);
            }

            for (String fdnToAdd : fdnsToAdd) {
                if (!lSources.contains(fdnToAdd)) {
                    lSources.add(fdnToAdd);
                }
            }
        } else {
            logger.error("aInNspObject doesn't include nsp-model:sources. aInNspObject=" + aInNspIdentifer);
        }
    }

    @Override
    public void postProcessObject(Map<String, Object> aInData, IYangObject aInIYangObject, String aInNeId, NotificationType aInNotificationType, IMdResyncFw aInMdResyncFw) {
        if (aInNotificationType.equals(NotificationType.DELETE)) {
            return;
        }
        if (aInData.containsKey("_classId_") && aInData.get("_classId_") != null && aInData.get("_classId_").toString().startsWith("nokia-state")) {
            //run post processing on conf only
            return;
        }

        Map<String, Map<String, String>> lTunnelDetailsCache = tunnelDetailsCache.get();
        if (null == lTunnelDetailsCache) {
            lTunnelDetailsCache = new HashMap<>();
            tunnelDetailsCache.set(lTunnelDetailsCache);
            Transactor.getContext().addEventHandler(TxPhase.FINAL, (p, c) -> {
                tunnelDetailsCache.remove();
            });
        }
        Map<String, String> lneServiceIdCache = neServiceIdCache.get();
        if (null == lneServiceIdCache) {
            lneServiceIdCache = new HashMap<>();
            neServiceIdCache.set(lneServiceIdCache);
            Transactor.getContext().addEventHandler(TxPhase.FINAL, (p, c) -> {
                neServiceIdCache.remove();
            });
        }

        iMdResyncFw = aInMdResyncFw;
        yangDB = iMdResyncFw.getIYangDB();
        if (logger.isDebugEnabled()) {
            logger.debug("Starting post-processing tunnel binding object (" + aInNotificationType + "): " + aInIYangObject.getIdentifier());
        }


        QueryParameters lQp = new QueryParameters();
        lQp.setFields(Fields.parse("site;resource"));
        lQp.setDepth(2);
        IYangObject lTunnelBindingFind=null;
        if(Transactor.isInTransaction()) {
            FlushModeType lModeType = Transactor.getContext().getEntityManager().getFlushMode();
            Transactor.getContext().getEntityManager().setFlushMode(FlushModeType.COMMIT);
            lTunnelBindingFind = yangDB.getSingle(aInIYangObject.getIdentifier(), lQp);
            if (lModeType.equals(FlushModeType.AUTO)) {
                Transactor.getContext().getEntityManager().setFlushMode(FlushModeType.AUTO);
            }
        }else{
            lTunnelBindingFind = yangDB.getSingle(aInIYangObject.getIdentifier(), lQp);
        }
        boolean foundCmodelSource = false;
        Object lSources = lTunnelBindingFind.getExtraData("sources");


        if (lSources != null && lSources instanceof ArrayList) {
            ArrayList lSourcesA = (ArrayList) lSources;
            String lFdn = null;
            for (Object lSource : lSourcesA) { //loop sources to find one with service-name and sdp-bind-id
                if (lSource.toString().contains("mdm-ami-cmodel")) { //need to change for multi-vendor
                    foundCmodelSource = true;
                    break;
                }
            }
        }

        String lNeServiceId = null;
        if (foundCmodelSource == false && lTunnelBindingFind.hasProperty("site") && lTunnelBindingFind.get("site") != null) {
            //cmodel source will be null after stitch need to fetch ne-service-id from site
            final String lSiteKey = lTunnelBindingFind.get("site").toString().replaceAll(".*\\/site\\[", "[");
            lNeServiceId = lneServiceIdCache.get(lSiteKey);
            if (null == lNeServiceId) {
                if (logger.isDebugEnabled()) {
                    logger.debug("cache miss site: {}", lSiteKey);
                }
                QueryParameters lQpSite = new QueryParameters();
                lQpSite.setFields(Fields.parse("ne-service-id"));
                lQpSite.setDepth(2);
                IYangObject lSiteDetailFind=null;
                if(Transactor.isInTransaction()) {
                    FlushModeType lFlushModeType = Transactor.getContext().getEntityManager().getFlushMode();
                    Transactor.getContext().getEntityManager().setFlushMode(FlushModeType.COMMIT);
                    lSiteDetailFind = yangDB.getSingle(lTunnelBindingFind.get("site").toString() + "/ipservice-site-detail", lQpSite);
                    if (lFlushModeType.equals(FlushModeType.AUTO)) {
                        Transactor.getContext().getEntityManager().setFlushMode(FlushModeType.AUTO);
                    }
                }else{
                    lSiteDetailFind = yangDB.getSingle(lTunnelBindingFind.get("site").toString() + "/ipservice-site-detail", lQpSite);
                }
                if (lSiteDetailFind != null && lSiteDetailFind.hasProperty("ne-service-id") && lSiteDetailFind.get("ne-service-id") != null) {
                    lNeServiceId = lSiteDetailFind.get("ne-service-id").toString();
                }
            } else {
                if (logger.isDebugEnabled()) {
                    logger.debug("cache hit site: {}", lSiteKey);
                }
            }
        }


        Map<String, Object> lBindDetails = null;
        if (aInIYangObject.hasProperty("tunnel-binding-details") && aInIYangObject.get("tunnel-binding-details") != null && ((List) aInIYangObject.get("tunnel-binding-details")).size() > 0) {
            if (((List) aInIYangObject.get("tunnel-binding-details")).get(0) instanceof Map) {
                lBindDetails = (Map<String, Object>) ((List) aInIYangObject.get("tunnel-binding-details")).get(0);
            } else if (((List) aInIYangObject.get("tunnel-binding-details")).get(0) instanceof IYangObject) {//Binding modify event
                lBindDetails = ((IYangObject) ((List) aInIYangObject.get("tunnel-binding-details")).get(0)).asMap();
            }
        }
        addSources(lSources, lNeServiceId, aInNeId, aInIYangObject.getIdentifier(), lBindDetails);

        //always update ne-names and destination ne-id
        Map<String, String> lFoundTunnelDetails;
        if (lTunnelBindingFind.hasProperty("resource") && lTunnelBindingFind.get("resource") != null) {
            final String lTunnelFdn = lTunnelBindingFind.get("resource").toString();
            final String lTunnelKey = lTunnelFdn.replaceAll(".*\\/(gre|mpls)-tunnel", "");
            lFoundTunnelDetails = lTunnelDetailsCache.get(lTunnelKey);
            if (null == lFoundTunnelDetails) {
                if (logger.isDebugEnabled()) {
                    logger.debug("cache miss tunnel details: {}", lTunnelKey);
                }

                lFoundTunnelDetails = new HashMap<>();

                QueryParameters lQueryParameters = new QueryParameters();
                lQueryParameters.setDepth(2);

                IExecutionContext executionContextSvc = new ExecutionContext(null, null, false, false, false);
                lQueryParameters.setIExecutionContext(executionContextSvc);

                lQueryParameters.setFields(Fields.parse("source-ne-id;source-ne-name;destination-ne-id;destination-ne-name"));
                IYangObject lTunnelRes=null;
                if(Transactor.isInTransaction()) {
                    FlushModeType lPreFlushModeType = Transactor.getContext().getEntityManager().getFlushMode();
                    Transactor.getContext().getEntityManager().setFlushMode(FlushModeType.COMMIT);
                    lTunnelRes = aInMdResyncFw.getIYangDB().getSingle(lTunnelFdn, lQueryParameters);
                    if (lPreFlushModeType.equals(FlushModeType.AUTO)) {
                        Transactor.getContext().getEntityManager().setFlushMode(FlushModeType.AUTO);
                    }
                }else{
                    lTunnelRes = aInMdResyncFw.getIYangDB().getSingle(lTunnelFdn, lQueryParameters);
                }
                if (lTunnelRes != null) {
                    if (lTunnelRes.hasProperty("source-ne-id") && lTunnelRes.get("source-ne-id") != null) {
                        lFoundTunnelDetails.put("source-ne-id", lTunnelRes.get("source-ne-id").toString());
                    }
                    if (lTunnelRes.hasProperty("source-ne-name") && lTunnelRes.get("source-ne-name") != null) {
                        lFoundTunnelDetails.put("source-ne-name", lTunnelRes.get("source-ne-name").toString());
                    }
                    if (lTunnelRes.hasProperty("destination-ne-id") && lTunnelRes.get("destination-ne-id") != null) {
                        lFoundTunnelDetails.put("destination-ne-id", lTunnelRes.get("destination-ne-id").toString());
                    }
                    if (lTunnelRes.hasProperty("destination-ne-name") && lTunnelRes.get("destination-ne-name") != null) {
                        lFoundTunnelDetails.put("destination-ne-name", lTunnelRes.get("destination-ne-name").toString());
                    }
                    lTunnelDetailsCache.put(lTunnelKey, lFoundTunnelDetails);
                }
            } else {
                if (logger.isDebugEnabled()) {
                    logger.debug("cache hit tunnel details: {}", lTunnelKey);
                }
            }
        } else {
            lFoundTunnelDetails = new HashMap<>();
        }
        IYangObject lTunnelBindingDetailsYo = (lBindDetails != null) ? new YangObject(lBindDetails) : new YangObject();
        if (lFoundTunnelDetails.containsKey("source-ne-id") && lFoundTunnelDetails.get("source-ne-id") != null) {
            lTunnelBindingDetailsYo.setProperty("source-ne-id", lFoundTunnelDetails.get("source-ne-id").toString());
        }
        else {
            lTunnelBindingDetailsYo.setProperty("source-ne-id", aInNeId);
        }
        if (lFoundTunnelDetails.containsKey("source-ne-name") && lFoundTunnelDetails.get("source-ne-name") != null) {
            lTunnelBindingDetailsYo.setProperty("source-ne-name", lFoundTunnelDetails.get("source-ne-name").toString());
        }
        if (lFoundTunnelDetails.containsKey("destination-ne-id") && lFoundTunnelDetails.get("destination-ne-id") != null) {
            lTunnelBindingDetailsYo.setProperty("destination-ne-id", lFoundTunnelDetails.get("destination-ne-id").toString());
        }
        if (lFoundTunnelDetails.containsKey("destination-ne-name") && lFoundTunnelDetails.get("destination-ne-name") != null) {
            lTunnelBindingDetailsYo.setProperty("destination-ne-name", lFoundTunnelDetails.get("destination-ne-name").toString());
        }

        YangObject tunnelBindUpdate = new YangObject();

        tunnelBindUpdate.setProperty("tunnel-binding-details", lTunnelBindingDetailsYo);

        //if aInData has admin state use that and convert enum
        //delete admin-state will set to unlocked here
        if (aInData.containsKey("admin-state")) {
            //null on delete
            tunnelBindUpdate.setProperty("admin-state", (aInData.get("admin-state") != null && aInData.get("admin-state").toString().equals("disable")) ? "locked" : "unlocked");
        } else if (!(aInIYangObject.hasProperty("admin-state") && aInIYangObject.get("admin-state") != null)) { //Else if aInYang does not have admin-state default to unlocked
            //Don't default admin state could be other event or state
            //tunnelBindUpdate.setProperty("admin-state", "unlocked");
        }
        tunnelBindUpdate.setProperty("class-name", "service.Service");//set className
        tunnelBindUpdate.addExtraData("sources", lSources);

        QueryParameters lQpUpdate = new QueryParameters();//QueryParameters needed to disable readonly
        IExecutionContext lExecutionContextUpdate = new ExecutionContext(null, null, false, false, false);
        lQpUpdate.setIExecutionContext(lExecutionContextUpdate);
        yangDB.update(aInIYangObject.getIdentifier(), tunnelBindUpdate, null, lQpUpdate);
    }
}