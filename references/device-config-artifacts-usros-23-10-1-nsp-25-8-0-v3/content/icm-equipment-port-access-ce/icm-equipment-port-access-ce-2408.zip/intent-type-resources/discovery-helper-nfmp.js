var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"),name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'),name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"),name: "utilities"});


function NfmpDiscoveryHelper() {

    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function(target, initialPropertyName) {

        let neId = parseTarget.getNeIdFromTarget(target);
        let portId = parseTarget.getUniqueIdentifier(target);
        let searchPayLoad = this.constructSearchString(neId, portId);
        let searchResponse = nfmpFwk.find(neId, searchPayLoad);
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                throw new RuntimeException("Failed to get Port info from nfm-p for Ne " + neId + " and Port Id: " + portId);
            if(JSON.parse(searchResponse["response"]).length === 0)
                throw new RuntimeException("There is no port with Port Id:"+portId);
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse[0];

    }

    this.extractDeviceConfig = function(defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        let portconfig = deviceConfig['properties'];
        if (null !== portconfig) {
            this.extractPortProperties(parsedDefaultTargetData, portconfig);
        }
        let childrenConfig = deviceConfig["children"];
        if (null !== childrenConfig && childrenConfig.length !== 0) {

            this.extractDS1E1PortSpecificsProperties(parsedDefaultTargetData,childrenConfig);

            let defaultDS1E1ChannelData = parsedDefaultTargetData['port']['ds1e1Channel'];
            if (defaultDS1E1ChannelData !== null && defaultDS1E1ChannelData.length !== 0) {
                let ds1e1ChannelExtractedConfig = this.extractDS1E1ChannelProperties(defaultDS1E1ChannelData, childrenConfig);
                parsedDefaultTargetData['port']['ds1e1Channel']=ds1e1ChannelExtractedConfig;
            }
        }
        return parsedDefaultTargetData;
    }

    this.extractDS1E1PortSpecificsProperties = function(defaultDS1E1PortSpecificsData, childrenConfig) {

        let keys = Object.keys(defaultDS1E1PortSpecificsData);
        let ds1e1PortSpecificsConfig = {};
        for (let i = 0; i < childrenConfig.length; i++) {
            let childConfig = childrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass ==='tdmequipment.DS1E1PortSpecifics') {
                ds1e1PortSpecificsConfig=childConfig;
            }
        }
        for (let i = 0; i < keys.length; i++) {
            let targetKey = keys[i];
            let targetObj = defaultDS1E1PortSpecificsData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object') {
                let mappings = modelDeviceMapping.getMapping("ds1e1PortSpecifics");
                this.traverseAndUpdateDS1E1PortSpecificsConfig(targetKey, targetObj, ds1e1PortSpecificsConfig['properties'], mappings);
            }
        }

        return defaultDS1E1PortSpecificsData;
    }

    this.extractDS1E1ChannelProperties = function(defaultDS1E1ChannelData, childrenConfig) {
        let mappings = modelDeviceMapping.getMapping("ds1e1Channel");
        let isDS1E1ChannelInConfig = false;
        for (let i = 0; i < childrenConfig.length; i++) {
            let childConfig = childrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass ==='tdmequipment.DS1E1Channel') {
                isDS1E1ChannelInConfig = true;
                this.traverseAndUpdateDS1E1ChannelConfig('port.ds1e1Channel', defaultDS1E1ChannelData, childConfig['properties'], mappings);
                this.extractDS1E1ChannelSpecificsProperties(defaultDS1E1ChannelData,childConfig["children"]);
                let ds0ChannelGroupData = defaultDS1E1ChannelData['ds0Channel-group'];
                if(ds0ChannelGroupData !== null && ds0ChannelGroupData.length !== 0) {
                    let ds0ChannelGroupArray = this.extractDS0ChannelGroupProperties(ds0ChannelGroupData,childConfig["children"]);
                    defaultDS1E1ChannelData['ds0Channel-group'] = ds0ChannelGroupArray;
                }
            }
        }
        if(!isDS1E1ChannelInConfig){
            return undefined;
        }

        return defaultDS1E1ChannelData;

    }

    this.extractDS1E1ChannelSpecificsProperties = function(defaultDS1E1ChannelSpecificsData, ds1e1ChannelChildrenConfig) {
        let mappings = modelDeviceMapping.getMapping("ds1e1ChannelSpecifics");
        for (let i = 0; i < ds1e1ChannelChildrenConfig.length; i++) {
            let childConfig = ds1e1ChannelChildrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass ==='tdmequipment.DS1E1ChannelSpecifics') {
                this.traverseAndUpdateDS1E1ChannelSpecificsConfig('port.ds1e1Channel', defaultDS1E1ChannelSpecificsData, childConfig['properties'], mappings);
            }
        }
        return defaultDS1E1ChannelSpecificsData;
    }

    this.extractDS0ChannelGroupProperties = function(defaultDs0ChannelGroupData,ds1e1ChannelChildrenConfig) {
        let ds0ChannelGroupArray =[];
        let ds0ChannelGroupDefaults = defaultDs0ChannelGroupData[0];
        let mappings = modelDeviceMapping.getMapping("ds0Channel-group");

        for (let i = 0; i < ds1e1ChannelChildrenConfig.length; i++) {
            let childConfig = ds1e1ChannelChildrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass ==='tdmequipment.DS0ChannelGroup') {
                let ds0ChannelGroupData = JSON.parse(JSON.stringify(ds0ChannelGroupDefaults));
                this.traverseAndUpdateDS0ChannelGroupConfig('port.ds1e1Channel.ds0Channel-group', ds0ChannelGroupData, childConfig['properties'], mappings);
                this.extractDS0ChannelGroupSpecificsProperties(ds0ChannelGroupData,childConfig["children"]);
                ds0ChannelGroupArray.push(ds0ChannelGroupData)
            }
        }

        return ds0ChannelGroupArray;
    }

    this.extractDS0ChannelGroupSpecificsProperties = function(defaultDs0ChannelGroupSpecificsData,ds0ChannelGroupChildrenConfig){
        let mappings = modelDeviceMapping.getMapping("ds0ChannelGroupSpecifics");
        for (let i = 0; i < ds0ChannelGroupChildrenConfig.length; i++) {
            let childConfig = ds0ChannelGroupChildrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass ==='tdmequipment.DS0ChannelGroupSpecifics') {
                this.traverseAndUpdateDS0ChannelGroupSpecificsConfig('port.ds1e1Channel.ds0Channel-group', defaultDs0ChannelGroupSpecificsData, childConfig['properties'], mappings);
            }
        }

        return defaultDs0ChannelGroupSpecificsData;
    }

    this.extractPortProperties = function(defaultTargetData, portConfig) {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++) {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object') {
                let mappings = modelDeviceMapping.getMapping("port");
                this.traverseAndUpdatePortConfig(targetKey, targetObj, portConfig, mappings);
            }
        }
        return defaultTargetData;
    }

    this.traverseAndUpdatePortConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.ds1e1Channel" && mappedKey !== "port.port-type") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdatePortConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.traverseAndUpdateDS1E1PortSpecificsConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.ds1e1Channel" && mappedKey !== "port.admin-state" && mappedKey !== "port.description") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateDS1E1PortSpecificsConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.traverseAndUpdateDS1E1ChannelConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.ds1e1Channel.ds0Channel-group" && mappedKey !== "port.ds1e1Channel.channel-framing" && mappedKey !== "port.ds1e1Channel.signal-mode-cas") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateDS1E1ChannelConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.traverseAndUpdateDS1E1ChannelSpecificsConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];

            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.ds1e1Channel.ds0Channel-group" && mappedKey !== "port.ds1e1Channel.admin-state" ) {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateDS1E1ChannelSpecificsConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.traverseAndUpdateDS0ChannelGroupConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.ds1e1Channel.ds0Channel-group.timeslots") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateDS0ChannelGroupConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.traverseAndUpdateDS0ChannelGroupSpecificsConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.ds1e1Channel.ds0Channel-group.channel-group-id" && mappedKey !== "port.ds1e1Channel.ds0Channel-group.admin-state" && mappedKey !== "port.ds1e1Channel.ds0Channel-group.encap-type-cem") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateDS0ChannelGroupSpecificsConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.getAndUpdateFromDeviceConfig = function(mappings, mappedKey, targetKey, targetObj, parsedDeviceConfig) {
        // Get the key from mapping against targetKey
        // If the mapping key is not undefined, Get the value from deviceKey
        // if the value from deviceConfig against that mapping key is not n
        let nfmpKey = mappings[mappedKey];
        let deviceValue = parsedDeviceConfig[nfmpKey];
        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);
    }

    this.transformDeviceValue = function(mappedKey, deviceValue) {
        if (deviceValue !== null) {
            switch (mappedKey) {
                case "port.admin-state":
                case "port.ds1e1Channel.admin-state":
                case "port.ds1e1Channel.ds0Channel-group.admin-state":
                    deviceValue = this.transformAdminStateValue(deviceValue);
                    break;
                case "port.ds1e1Channel.signal-mode-cas":
                    deviceValue = this.transformSignalModeCasValue(deviceValue);
                    break;
                case "port.ds1e1Channel.ds0Channel-group.channel-group-id":
                    deviceValue = this.transformChannelGroupIdValue(deviceValue);
                    break;
                case "port.ds1e1Channel.ds0Channel-group.encap-type-cem":
                    deviceValue = this.transformEncapTypeCEMValue(deviceValue);
                    break;
                case "port.ds1e1Channel.ds0Channel-group.timeslots":
                    deviceValue = this.transformTimeSlotsValue(deviceValue);
                    break;
            }
            return deviceValue;
        }
    }

    this.constructSearchString = function(neId, portId) {
        let portFullName =  util.getBaseFdnForPort(neId, portId);
        let filterExpression = "siteId='" + neId + "' AND fullName='" + portFullName + "'";
        let jsonPayLoad = {
            "fullClassName": "equipment.PhysicalPort",
            "filter": {
                "filterExpression": filterExpression
            }
        };

        return jsonPayLoad;
    }

    this.transformAdminStateValue = function(deviceValue) {
        switch (deviceValue) {
            case "portInService":
                return "Up";
            case "portOutOfService":
                return 'Down';
        }
    }

    this.transformSignalModeCasValue = function(deviceValue){
        if (deviceValue === "cas"){
            return true;
        }
        return false;
    }

    this.transformChannelGroupIdValue = function(deviceValue){
        return parseInt(deviceValue);
    }

    this.transformEncapTypeCEMValue = function(deviceValue){
        if (deviceValue === "cemEncap"){
            return true;
        }
        return false;
    }

    this.transformTimeSlotsValue = function(deviceValue) {
        let timeSlotValue = "";
        if(!Array.isArray(deviceValue)){
            deviceValue = [deviceValue];
        }
        for(let index in deviceValue){
            timeSlotValue=timeSlotValue+deviceValue[index]+" ";
        }
        timeSlotValue = timeSlotValue.replace(/\s*$/,'');

        return timeSlotValue;
    }

}
