function MdSuggest() {

    this.getSapEgressPolicyName = function (neId, policyId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-state:/state/qos/sap-egress?fields=oper-policy-id";
        return this.getData(neId, url, "sap-egress-policy-name", "nokia-state:sap-egress", policyId);
    }

    this.getSapEgressPolicyId = function (neId, policyName) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-state:/state/qos/sap-egress?fields=oper-policy-id";
        if (policyName) {
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-state:/state/qos/sap-egress=" + policyName + "?fields=oper-policy-id";
        }
        return this.getData(neId, url, "oper-policy-id", "nokia-state:sap-egress", policyName);
    }
    
    this.getPostPolicerMapping = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/post-policer-mapping";
        return this.getData(neId, url, "name", "nokia-conf:post-policer-mapping");
    }
    
    this.getHsAttachmentPolicy = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/hs-attachment-policy";
        return this.getData(neId, url, "name", "nokia-conf:hs-attachment-policy");
    }
    
    this.getAdvConfigPolicy = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/adv-config-policy";
        return this.getData(neId, url, "adv-config-policy-name", "nokia-conf:adv-config-policy");
    }
    
    this.getWredQueuePolicy = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/slope-policy";
        return this.getData(neId, url, "slope-policy-name", "nokia-conf:slope-policy");
    }

    this.getQueueGroupNames = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/queue-group-templates/egress/queue-group";
        return this.getData(neId, url, "egress-queue-group-name", "nokia-conf:queue-group");
    }

    this.getQueueGroupQueues = function (neId, queueGroup) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/queue-group-templates/egress/queue-group=" + queueGroup + "/queue";
        return this.getData(neId, url, "queue-id", "nokia-conf:queue");
    }
    
    this.getIpPrefixList = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/match-list/ip-prefix-list";
        return this.getData(neId, url, "prefix-list-name", "nokia-conf:ip-prefix-list");
    }
    
    this.getIpV6PrefixList = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/match-list/ipv6-prefix-list";
        return this.getData(neId, url, "prefix-list-name", "nokia-conf:ipv6-prefix-list");
    }
    
    this.getData = function (neId, url, type, configName, objId) {
        var mdcFwk = new MdcFwk();
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        // logger.info("_____________________________________________________________________");
        // logger.info("MDC resultFetch Interfaces =\n" + JSON.stringify(resultFetch));
        // logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"][configName];
        // logger.info("finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                if (objId) {
                    logger.info("Policy Object Identifier Selected = {}", objId);
                    if (type === "sap-egress-policy-name") {
                        logger.info("entered policy name ");
                        if (finalResponse[index]["policy-id"] === objId) {
                            ret.push(finalResponse[index][type]);
                            break;
                        }
                    }
                    else {
                        if (finalResponse[index]["sap-egress-policy-name"] === objId) {
                            ret.push(finalResponse[index][type]);
                            break;
                        }
                    }
                }
                else {
                    ret.push(finalResponse[index][type]);
                }
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info("getData() of [" + configName + "] values = \n" + JSON.stringify(ret));
        return ret;
    }
}