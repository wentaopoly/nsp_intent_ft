var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk'});
load({script: resourceProvider.getResource('traverse-fwk.js'), name: 'TraverseFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
load({script: resourceProvider.getResource('intentConfigValueReplacer.js'), name: 'IntentConfigValueReplacer'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
function MdcIntentFwk() {
    var util = new utilities();
    var intentDeviationObj = new IntentDeviceDeviation();
    var intentConfigValueReplacerObj = new IntentConfigValueReplacer();

    this.restResponseHandler = function (exception, httpStatus, response) {
        logger.info("[IntentMgr] REST response : " + response);
        logger.info("[IntentMgr] REST httpStatus : " + httpStatus);
        if (exception) {
            throw new RuntimeException("Couldn't connect to device proxy for ; Response: " + response);
        }

        if (httpStatus !== 200 && httpStatus !== 201) {
            throw new RuntimeException("Failed to access device  using MDC; Response: " + response);
        }

        restResponse = JSON.parse(response);
    };

    this.synchronize = function (input, result, intentTypeName, xpath, initialPropertyName, uniqueIdentifier) {
        var traverseFwk = new TraverseFwk();
        var parseTarget = new ParseTarget();
        var target = parseTarget.getNeIdFromTarget(input.getTarget());

        // saved topology
        var savedTopology = input.getCurrentTopology();

        if (savedTopology == null) {
            savedTopology = topologyFactory.createServiceTopology();
        }

        if (input.getNetworkState().name() == "delete") {
            logger.info(JSON.stringify(savedTopology));
            traverseFwk.resetTheVariables();
            var requests = [];
            var deleteObj = {};
            deleteObj["operation"] = "delete";
            deleteObj["edit-id"] = "edit-" + new Date().getTime();
            deleteObj["target"] = "nokia-conf:/configure/qos/sap-ingress=" + parseTarget.getUniqueIdentifier(input.getTarget());
            requests.push(deleteObj)
            result = traverseFwk.syncRequest(target, requests, result, savedTopology);
            result.setTopology(null);
            return result;
        }
        var intentConfig;

        if (target !== "0.0.0.0") {
            var intentConfig;
            intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
            intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());
            var deviceType = util.getIxrType(target);
            if (intentConfig['mac-criteria']) {
               if(deviceType["type"].startsWith("7250 IXR-e2") || deviceType["type"].startsWith("7250 IXR-R6d") || deviceType["type"].startsWith("7250 IXR-R6dl") || deviceType["type"].startsWith("7250 IXR-x1") || deviceType["type"].startsWith("7250 IXR-x3") || deviceType["type"].startsWith("7250 IXR-xs") ||  deviceType["type"].startsWith("7250 IXR-e2c")){
                 delete intentConfig['mac-criteria']['type'];
               }
               if (intentConfig['mac-criteria']['entry']) {
                     intentConfig = this.MacCriteriaEntry(intentConfig['mac-criteria']['entry'], intentConfig);
               }
            }
            if (intentConfig['ipv6-criteria']) {
                if(deviceType["type"].startsWith("7250 IXR-e2") || deviceType["type"].startsWith("7250 IXR-R6d") || deviceType["type"].startsWith("7250 IXR-R6dl") || deviceType["type"].startsWith("7250 IXR-x1") || deviceType["type"].startsWith("7250 IXR-x3") || deviceType["type"].startsWith("7250 IXR-xs") ||  deviceType["type"].startsWith("7250 IXR-e2c")){
                  delete intentConfig['ipv6-criteria']['type'];
                }
                if (intentConfig['ipv6-criteria']['entry']) {
                    intentConfig = this.Ipv6CriteriaEntry(intentConfig['ipv6-criteria']['entry'], intentConfig);
                }
            }
          if (intentConfig['fc']) {
            if(deviceType["type"].startsWith("7250 IXR-e2") || deviceType["type"].startsWith("7250 IXR-R6d") || deviceType["type"].startsWith("7250 IXR-R6dl") || deviceType["type"].startsWith("7250 IXR-x1") || deviceType["type"].startsWith("7250 IXR-x3") || deviceType["type"].startsWith("7250 IXR-xs") ||  deviceType["type"].startsWith("7250 IXR-e2c") ||  deviceType["type"].startsWith("7250 IXR-x")){
               delete intentConfig['fc'];
            }
          }
            if(intentConfig['ip-criteria'] && intentConfig['ip-criteria']['type']){
              delete intentConfig['ip-criteria']['type'];
            }
            var policyId = input.getTarget().split("#")[3];
            intentConfig['policy-id'] = parseInt(policyId);
            //Removing deviations info
            intentConfig = intentDeviationObj.removeIntentConfig(intentConfig, target);
            //Replace Values
            intentConfig = intentConfigValueReplacerObj.replaceConfigValue(intentConfig);
            if (intentConfig) {
                savedTopology = traverseFwk.traverse(target, intentConfig, savedTopology, null, xpath, initialPropertyName);

                //sorting delete array
                var deleteRequests = traverseFwk.getDeleteRequests();
                deleteRequests.sort(function (a, b) {
                    return b["target"].length - a["target"].length;
                });

                // concating createrequests and deleterequests
                var createRequests = traverseFwk.getCreateRequests();
                var requests;
                if (deleteRequests && createRequests) {
                    requests = createRequests.concat(deleteRequests);
                }
                if (requests) {
                    result = traverseFwk.syncRequest(target, requests, result, savedTopology);
                }
                createRequests = undefined;
                deleteRequests = undefined;
                requests = undefined;
            } else {
                logger.info('')
                result = traverseFwk.deleteAllFromTopology(savedTopology, target, result);
            }

        }
        traverseFwk.resetTheVariables();
        return result;
    }

    this.audit = function (target, config, svcTopo, adminState, report, intentTypeName, xpath, initialPropertyName) {
        var currentConfig;
        var traverseFwk = new TraverseFwk();
        var parseTarget = new ParseTarget();
        var neid = parseTarget.getNeIdFromTarget(target);
        currentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        var deviceType = util.getIxrType(neid);
        if (currentConfig['mac-criteria']) {
          if(deviceType["type"].startsWith("7250 IXR-e2") || deviceType["type"].startsWith("7250 IXR-R6d") || deviceType["type"].startsWith("7250 IXR-R6dl") || deviceType["type"].startsWith("7250 IXR-x1") || deviceType["type"].startsWith("7250 IXR-x3") || deviceType["type"].startsWith("7250 IXR-xs") ||  deviceType["type"].startsWith("7250 IXR-e2c")){
             delete currentConfig['mac-criteria']['type'];
          }
          if (currentConfig['mac-criteria']['entry']) {
              currentConfig = this.MacCriteriaEntry(currentConfig['mac-criteria']['entry'], currentConfig);
          }
        }
        if (currentConfig['ipv6-criteria']) {
          if(deviceType["type"].startsWith("7250 IXR-e2") || deviceType["type"].startsWith("7250 IXR-R6d") || deviceType["type"].startsWith("7250 IXR-R6dl") || deviceType["type"].startsWith("7250 IXR-x1") || deviceType["type"].startsWith("7250 IXR-x3") || deviceType["type"].startsWith("7250 IXR-xs") ||  deviceType["type"].startsWith("7250 IXR-e2c")){
            delete currentConfig['ipv6-criteria']['type'];
          }
          if (currentConfig['ipv6-criteria']['entry']) {
                currentConfig = this.Ipv6CriteriaEntry(currentConfig['ipv6-criteria']['entry'], currentConfig);
          }
        }
        if (currentConfig['fc']) {
          if(deviceType["type"].startsWith("7250 IXR-e2") || deviceType["type"].startsWith("7250 IXR-R6d") || deviceType["type"].startsWith("7250 IXR-R6dl") || deviceType["type"].startsWith("7250 IXR-x1") || deviceType["type"].startsWith("7250 IXR-x3") || deviceType["type"].startsWith("7250 IXR-xs") ||  deviceType["type"].startsWith("7250 IXR-e2c")  ||  deviceType["type"].startsWith("7250 IXR-x")){
             delete currentConfig['fc'];
          }
        }
        if(currentConfig['ip-criteria'] && currentConfig['ip-criteria']['type']){
          delete currentConfig['ip-criteria']['type'];
        }
        currentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        var target = parseTarget.getNeIdFromTarget(target);
        //Ignoring deviations compare
        currentConfig = intentDeviationObj.removeIntentConfig(currentConfig, target);
        //Replace Values
        currentConfig = intentConfigValueReplacerObj.replaceConfigValue(currentConfig);
        if (target !== "0.0.0.0") {
            svcTopo = traverseFwk.traverse(target, currentConfig, svcTopo, report, xpath, initialPropertyName);
            // reseting the variables
            traverseFwk.resetTheVariables();
        }

        return report;

    }
    this.MacCriteriaEntry = function (currentConfigeration, currentConfig) {
        if (Array.isArray(currentConfigeration)) {
            var newConfig = [];
            for (var i = 0; i < currentConfigeration.length; i++) {
                var ConfigerationData = currentConfigeration[i];
                var MacCriteriaEntryData = this.MacCriteriaEntryData(ConfigerationData);
                newConfig.push(MacCriteriaEntryData);
            }
            var currentEntry = currentConfig['mac-criteria']['entry'];
            for (var i = 0; i < currentEntry.length && i < newConfig.length; i++) {
                var entryData = currentEntry[i];
                var newData = newConfig[i];
                if (newData['mac-criteria'] && newData['mac-criteria']['entry'] && newData['mac-criteria']['entry']['match']) {
                    entryData['mac-criteria']['entry']['match'] = newData['mac-criteria']['entry']['match'];
                }
            }
            return currentConfig;
        } else {
            var MacCriteriaEntryData = this.MacCriteriaEntryData(currentConfigeration);
            currentConfig['mac-criteria']['entry']['match']=MacCriteriaEntryData['match'];
            return currentConfig;
        }
    }

    this.MacCriteriaEntryData = function (ConfigerationData) {
        if (ConfigerationData['match']) {
            if (ConfigerationData['match']['etype'] !== undefined) {
                ConfigerationData['match']['etype'] = ConfigerationData['match']['etype'].toLowerCase();
            }
            if (ConfigerationData['match']['src-mac']) {
                if (ConfigerationData['match']['src-mac']['address'] !== undefined) {
                    ConfigerationData['match']['src-mac']['address'] = ConfigerationData['match']['src-mac']['address'].toLowerCase();
                }
                if (ConfigerationData['match']['src-mac']['mask'] !== undefined) {
                    ConfigerationData['match']['src-mac']['mask'] = ConfigerationData['match']['src-mac']['mask'].toLowerCase();
                }
            }
            if (ConfigerationData['match']['dst-mac']) {
                if (ConfigerationData['match']['dst-mac']['address'] !== undefined) {
                    ConfigerationData['match']['dst-mac']['address'] = ConfigerationData['match']['dst-mac']['address'].toLowerCase();
                }
                if (ConfigerationData['match']['dst-mac']['mask'] !== undefined) {
                    ConfigerationData['match']['dst-mac']['mask'] = ConfigerationData['match']['dst-mac']['mask'].toLowerCase();
                }
            }
        }
        return ConfigerationData;
    }

    this.Ipv6CriteriaEntry = function (currentConfigeration, currentConfig) {
        if (Array.isArray(currentConfigeration)) {
            var newConfig = [];
            for (var i = 0; i < currentConfigeration.length; i++) {
                var ConfigerationData = currentConfigeration[i];
                var Ipv6CriteriaEntryData = this.Ipv6CriteriaEntryData(ConfigerationData);
                newConfig.push(Ipv6CriteriaEntryData);
            }
            var currentEntry = currentConfig['ipv6-criteria']['entry'];
            for (var i = 0; i < currentEntry.length && i < newConfig.length; i++) {
                var entryData = currentEntry[i];
                var newData = newConfig[i];
                if (newData['ipv6-criteria'] && newData['ipv6-criteria']['entry'] && newData['ipv6-criteria']['entry']['match']) {
                    entryData['ipv6-criteria']['entry']['match'] = newData['ipv6-criteria']['entry']['match'];
                }
            }
            return currentConfig;
        } else {
            var Ipv6CriteriaEntryData = this.Ipv6CriteriaEntryData(currentConfigeration);
            currentConfig['ipv6-criteria']['entry']['match']=Ipv6CriteriaEntryData['match'];
            return currentConfig;
        }
    }
    this.Ipv6CriteriaEntryData = function (ConfigerationData) {
        if (ConfigerationData['match']) {
            if (ConfigerationData["match"]["src-ip"]) {
                if (ConfigerationData["match"]["src-ip"]["address"] !== undefined) {
                    ConfigerationData["match"]["src-ip"]["address"] = this.expandIPv6AddressForMd(ConfigerationData["match"]["src-ip"]["address"]);
                }
                if (ConfigerationData["match"]["src-ip"]["mask"] !== undefined) {
                    ConfigerationData["match"]["src-ip"]["mask"] = this.expandIPv6AddressForMd(ConfigerationData["match"]["src-ip"]["mask"]);
                }
            }
            if (ConfigerationData["match"]["dst-ip"]) {
                if (ConfigerationData["match"]["dst-ip"]["address"] !== undefined) {
                    ConfigerationData["match"]["dst-ip"]["address"] = this.expandIPv6AddressForMd(ConfigerationData["match"]["dst-ip"]["address"]);
                }
                if (ConfigerationData["match"]["dst-ip"]["mask"] !== undefined) {
                    ConfigerationData["match"]["dst-ip"]["mask"] = this.expandIPv6AddressForMd(ConfigerationData["match"]["dst-ip"]["mask"]);
                }
            }
        }
        return ConfigerationData;
    }
    this.getNodes = function (context) {
        var returnVal = []
        var url = "/restconf/meta/api/v1/nes"
        try {
            var managerList = []
            var managers = mds.getAllManagersOfType("REST");
            managers.forEach(function (manager) {
                if (mds.getManagerByName(manager).getConnectivityState().toString() === 'CONNECTED') {
                    managerList.push(manager)
                }
            })

            var devices = mds.getAllManagedDevicesFrom(managerList);

            devices.forEach(function (device) {
                returnVal.push(device.getName());
            });

            return returnVal;
        } catch (e) {
            logger.info("Exception *******************  : " + e);
            return {
                "Device Not Found": "Device Not Found"
            }
        }
    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }

    this.expandIPv6AddressForMd = function (input) {
        var expanded = util.expandIPv6ForMd(input);
        expanded = util.MdIpv6ValidAddresssMaskSupport(expanded);
        return expanded;
    };
}
