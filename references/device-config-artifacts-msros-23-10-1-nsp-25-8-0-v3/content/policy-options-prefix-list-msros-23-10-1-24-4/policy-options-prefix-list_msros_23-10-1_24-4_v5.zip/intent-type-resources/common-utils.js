
function CommonUtil() {
  /**
   * Get deviceConfig
   * @param {*} neId
   * @param {*} rootXPath
   * @param {*} intentContainer
   * @param {*} deviceYangModuleName
   * @returns
   */
  const getDeviceConfig = (
    neId,
    rootXPath,
    intentContainer,
    deviceYangModuleName,
    uniqueIdentifierValue
  ) => {
    let url = getUrl(
      neId,
      rootXPath,
      intentContainer,
      deviceYangModuleName,
      uniqueIdentifierValue
    );
    logger.info("url " + url);
    let deviceConfigResult = mdcFwk.fetch(neId, url);
    if (!deviceConfigResult["success"]) {
      throw new RuntimeException(deviceConfigResult["msg"]);
    }
    let containerKey;
    if(rootXPath.endsWith(":")){
      let moduleRef = getModuleRef(rootXPath);
      if(moduleRef){
        containerKey = moduleRef + ":" + intentContainer;
      }else {
         containerKey = deviceYangModuleName + ":" + intentContainer;
      }
    }else {
      containerKey = deviceYangModuleName + ":" + intentContainer;
    }
   
    let deviceConfig = deviceConfigResult["msg"][containerKey][0];
    logger.info("deviceConfig " + JSON.stringify(deviceConfig));
    return deviceConfig;
  };

  /**
   * Get the url for mdc
   * @param {} target
   * @returns
   */
  const getDeviceUrl = (target) => {
    return (
      "/restconf/data/network-device-mgr:network-devices/network-device=" +
      target +
      "/root/"
    );
  };

  /**
   *
   * @param {*} neId
   * @param {*} rootXPath
   * @param {*} intentContainer
   * @param {*} uniqueIdentifierValue
   * @returns
   */
  const getUrl = (
    neId,
    rootXPath,
    intentContainer,
    deviceYangModuleName,
    uniqueIdentifierValue
  ) => {
    let url = "";
    logger.info("------ Generating url ------");
    logger.info("neId device " + neId);
    logger.info("rootXPath " + rootXPath);
    logger.info("intentContainer " + intentContainer);
    logger.info("uniqueIdentifierValue " + uniqueIdentifierValue);

    if (!isFalsy(rootXPath)) {
      // module reference case in rootXPath
      if (rootXPath.endsWith(":")) {
        url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/${deviceYangModuleName}:/${rootXPath}${intentContainer}`;
      } else {
        url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/${deviceYangModuleName}:/${rootXPath}/${intentContainer}`;
      }
    } else {
      url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/${deviceYangModuleName}:/${intentContainer}`;
    }

    if (!isFalsy(uniqueIdentifierValue)) {
      logger.info("uniqueIdentifierValue " + uniqueIdentifierValue);
      url = url + "=" + encodeString(uniqueIdentifierValue);
    }
    url = url + "?content=config";
    logger.info("------ Generating url done and url is ------" + url);
    return url;
  };

  /**
   *
   * @param {*} value
   * @returns
   */
  const isFalsy = (value) => {
    if (value === undefined || value === null || value === "") {
      return true;
    } else {
      return false;
    }
  };

  /**
   * Encode the string
   * @param {*} key
   * @returns
   */
  const encodeString = (str) => {
    let new_array = [];
    let new_str;
    if (_.isArray(str)) {
      str.forEach((identifier) => {
        new_array.push(identifier.replace(/\//g,"%2F").replace(/:/g,"%3A"));
      })
      new_str = new_array.join(",").toString();
    } else {
      new_str = str.replace(/\//g, "%2F").replace(/:/g,"%3A");
    }
    return new_str;
  };

  /**
   * Check if the neType is SRLinux
   * @param {} neType
   * @returns
   */
  function isSRLinux(neType) {
    const regex = /SRLinux/g;
    const matches = neType && neType.match(regex);
    return matches ? true : false;
  }

  /**
   * Remove the moduleRef from deviceConf
   * @param {} deviceConf - the deviceConf
   */
  const removeModuleRef = (deviceConf) => {
    if (deviceConf != null) {
      if(_.isArray(deviceConf)){
        deviceConf.forEach(config => {
          removeModuleRef(config)
        })
      } else if(typeof deviceConf === "object"){
        let keys = Object.keys(deviceConf);
        keys.forEach((key) => {
          // top level key
          key = replaceKey(key, deviceConf)
          let value = deviceConf[key];
          if (Array.isArray(value)) {
            // iterate over each element in the array
            value.forEach((v, index) => {
              if(typeof v ==="object"){
              removeModuleRef(v);
              }else {
                // when value is array with integer or string
                let newValue = getValue(v);
                value[index] = newValue;
              }
            });
          } else if (typeof value === "object") {
            // recurse
            removeModuleRef(value);
          } else {
            if (value && _.includes(value, ":")) {
              replaceValue(key, value, deviceConf)
            }
          }
        });
      }else {
        if (deviceConf && _.includes(deviceConf, ":")) {
          replaceValue(key, value, deviceConf)
        }
      }
    } 
  };


  /**
   * remove the moduleReference from the key and replace it in the object
   * @param {*} key 
   * @param {*} object 
   */
  const replaceKey = (key, object) => {
    if (key && _.includes(key, ":")) {
      let newKey;
      let m = key.split(":")
      if (m.length > 2) {
        // this is case with multiple colon in the key
        let parts = key.split(':');
        parts.shift();
        newKey = parts.join(':');
      } else {
        newKey = m[1];
      }
      const descriptor = Object.getOwnPropertyDescriptor(object, key);
      if (descriptor) {
        Object.defineProperty(object, newKey, descriptor);
        delete object[key];
      }
      key = newKey;
    }
    return key;
  }

  /**
   * remove moduleRef in the value
   * @param {*} key 
   * @param {*} value 
   * @param {*} deviceConf 
   */
  const replaceValue = (key, value, deviceConf) => {
    if (_.includes(value, ":")) {
      let count = value.split(":").length;
      if(count <= 2){
        value = value.split(":")[1];
      }else {
        if(_.includes(value, "srl_")){
          value = value.substring(value.indexOf(value.split(":")[1]))
        }
        //value = value.split(":")[1];
      }
      deviceConf[key] = value;
    }
  }

  /**
   * remove moduleRef in the value
   * @param {*} key 
   * @param {*} value 
   * @param {*} deviceConf 
   */
  const getValue = (value) => {
    if (_.includes(value, ":")) {
      let count = value.split(":").length;
      if(count <= 2){
        if(_.includes(value, "srl_")){
          value = value.split(":")[1];
        }
      }else {
        if(_.includes(value, "srl_")){
          value = value.substring(value.indexOf(value.split(":")[1]))
        }
      }
    }
    return value;
  }
  
  /**
   * Get the module reference from rootXPath
   * @param {*} rootXPath 
   * @returns 
   */
  const getModuleRef = (rootXPath) => {
    let lastIndexOfColon = rootXPath.lastIndexOf(":");
    let lastIndexOfSlash = rootXPath.lastIndexOf("/");
    let moduleRef = rootXPath.substring(lastIndexOfSlash + 1, lastIndexOfColon);
    logger.info("moduleRef " + moduleRef);
    return moduleRef;
  }

  const prefixToSubnetConvert = (prefixval)=> {
    if (prefixval != undefined && prefixval && prefixval <= 32 && !isNaN(prefixval)) {
        var submask = [],
            converstion;
        for (var i = 0; i < 4; i++) {
            converstion = Math.min(prefixval, 8);
            submask.push(256 - Math.pow(2, 8 - converstion));
            prefixval -= converstion;
        }
        return submask.join('.');
    }
};

const subnetToPrefixConvert = (submask) => {
    var submaskArr = submask.split(".");
    var prefixval = 0;
    for (var i = 0; i < submaskArr.length; i++) {
        var subnetval = parseInt(submaskArr[i]);
        if (subnetval == 255) {
            prefixval += 8;
        } else if (subnetval < 255) {
            var bitArr = [128, 64, 32, 16, 8, 4, 2, 1];
            if (subnetval == bitArr[0]) {
                prefixval += 1;
            } else if (bitArr[0] < subnetval) {
                var bitcount = 0;
                for (var j = 0; j < bitArr.length; j++) {
                    bitcount += bitArr[j];
                    prefixval += 1;
                    if (subnetval == bitcount) {
                        break;
                    }

                }
            }
        } else {
            prefixval += 0;
        }
    }
    return prefixval;
};

  this.getDeviceConfig = getDeviceConfig;
  this.getDeviceUrl = getDeviceUrl;
  this.getUrl = getUrl;
  this.encodeString = encodeString;
  this.isSRLinux = isSRLinux;
  this.removeModuleRef = removeModuleRef;
  this.prefixToSubnetConvert = prefixToSubnetConvert;
  this.subnetToPrefixConvert = subnetToPrefixConvert;
}

/*
   function: compressIfIPV6
    since: NSP 25.4
    short_description: Compress to IPv6 short abbreviation in lowercase for md-sros
    input:
        address:
          description: ipv6 or ipv4 address with or without prefix
          type: String
          mandatory: True
    output:
      value:
        type: String
        description: Compressed IPv6 address or ipv4
*/
CommonUtil.prototype.compressIfIPV6 = function (address) {
    return (address.indexOf(":")>=0) ? this.compressIPV6(address) : address;
};

/*
   function: compressIPV6
    since: NSP 25.4
    short_description: Compress to IPv6 short abbreviation in lowercase for md-sros
    input:
        address:
          description: Expanded IPv6 address
          type: String
          mandatory: True
    output:
      value:
        type: String
        description: Compressed IPv6 address
*/
CommonUtil.prototype.compressIPV6 = function (address) {
    let i;
    address = this.expandIPv6Address(address);

    let ipv4MappedParts =/^0\:0\:0\:0\:0\:FFFF\:([A-F0-9]{1,4})\:([A-F0-9]{1,4})/i.exec(address)
    if (ipv4MappedParts) {
        let addrP1=ipv4MappedParts[1].length>2 ? /(.*?)(.{2})$/i.exec(ipv4MappedParts[1]) : ['','0',ipv4MappedParts[1]];
        let addrP2=ipv4MappedParts[2].length>2 ? /(.*?)(.{2})$/i.exec(ipv4MappedParts[2]) : ['','0',ipv4MappedParts[2]];
        let ipv4=Number("0x"+addrP1[1])+"."+Number("0x"+addrP1[2])+"."+Number("0x"+addrP2[1])+"."+Number("0x"+addrP2[2]);
        return "::ffff:"+ipv4;
    }

    // Split CIDR notation if present
    const parts = address.split('/');
    let ipv6 = parts[0];
    const cidr = parts[1] || '';

    // Split the address into groups
    let groups = ipv6.split(':');

    // Remove empty groups at the beginning and end
    while (groups[0] === '') groups.shift();
    while (groups[groups.length - 1] === '') groups.pop();

    // Find the position of the double colon if it exists
    const doubleColonIndex = groups.indexOf('');

    if (doubleColonIndex !== -1) {
        // Remove all empty groups
        groups = groups.filter(function(group) { return group !== ''; });

        // Insert the correct number of zero groups
        const zerosToAdd = 8 - groups.length;
        const zeros = [];
        for (i = 0; i < zerosToAdd; i++) {
            zeros.push('0');
        }
        groups.splice.apply(groups, [doubleColonIndex, 0].concat(zeros));
    }

    // Ensure we have 8 groups
    //while (groups.length < 8) groups.push('0');

    // Remove leading zeros from each group
    groups = groups.map(function(group) {
        return parseInt(group || '0', 16).toString(16);
    });

    // Find the longest run of zeros
    let longestZeroRun = {start: -1, length: 0};
    let currentRun = {start: -1, length: 0};

    for (i = 0; i < groups.length; i++) {
        if (groups[i] === '0') {
            if (currentRun.length === 0) currentRun.start = i;
            currentRun.length++;
            if (currentRun.length > longestZeroRun.length) {
                longestZeroRun = {start: currentRun.start, length: currentRun.length};
            }
        } else {
            currentRun = {start: -1, length: 0};
        }
    }

    // Replace the longest run of zeros with '::'
    if (longestZeroRun.length > 1) {
        groups.splice(longestZeroRun.start, longestZeroRun.length, '');
        if (longestZeroRun.start === 0) groups.unshift('');
        if (longestZeroRun.start + longestZeroRun.length === 8) groups.push('');
    }

    // Join the groups and add back the CIDR notation if it was present
    return groups.join(':') + (cidr ? '/' + cidr : '');
};

/*
   function: expandIPv6Address
    since: NSP 25.4
    short_description: Expand IPv6 short abbreviation. Used to expand and uppercase to match NFMP. Expanded shorten usually pads non 0 to 4 numbers but NFMP does not, optional flag
    input:
        address:
          description: Short IPv6 address
          type: String
          mandatory: True
    output:
      value:
        type: String
        description: Expanded IPv6 address
*/
CommonUtil.prototype.expandIPv6Address = function (address, padNonZero) {
    if (typeof address !== 'string') {
        return address;
    }
    if (typeof padNonZero === 'undefined') {
        padNonZero = false;
    }
    let fullAddress = [];
    let expandedAddress = "";
    const validGroupCount = 8;

    // Split CIDR notation if present
    const parts = address.split('/');
    let ipv6 = parts[0];
    const cidr = parts[1] || '';

    // Handle embedded IPv4
    let extractIpv4 = /([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})/;
    const validateIpv4 = /((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})/;

    // Look for embedded IPv4
    if (validateIpv4.test(ipv6)) {
        const groups = ipv6.match(extractIpv4);
        const ipv4 = groups.slice(1).map(function(g) {
            return ('00' + parseInt(g, 10).toString(16)).slice(-2);
        }).join('');
        ipv6 = ipv6.replace(extractIpv4, ipv4.slice(0, 4).replace(/^0+/, '') + ':' + ipv4.slice(4).replace(/^0+/, ''));
    }

    // Handle '::' notation
    if (ipv6.indexOf("::")>=0) {
        const sides = ipv6.split("::");
        const leftGroups = sides[0] ? sides[0].split(":") : [];
        const rightGroups = sides[1] ? sides[1].split(":") : [];
        const missingGroups = validGroupCount - (leftGroups.length + rightGroups.length);

        fullAddress = leftGroups;
        for (let i = 0; i < missingGroups; i++) {
            fullAddress.push('0');
        }
        fullAddress = fullAddress.concat(rightGroups);
    } else {
        fullAddress = ipv6.split(":");
    }

    // Ensure we have exactly 8 groups
    if (fullAddress.length !== validGroupCount) {
        throw new Error("Invalid IPv6 address");
    }

    // Expand each group
    expandedAddress = fullAddress.map(function(group) {
        group = group.toUpperCase();
        group = group.replace(/^0+/, '') || '0';
        if (group !== '0' && padNonZero) {
            group = ('0000' + group).slice(-4);
        }
        return group;
    }).join(':');

    // Add back the CIDR notation if it was present
    return expandedAddress + (cidr ? '/' + cidr : '');
};
// hackish way to use CommonUtil in test, due to non-support of export in IM
testCommonUtil = CommonUtil;
