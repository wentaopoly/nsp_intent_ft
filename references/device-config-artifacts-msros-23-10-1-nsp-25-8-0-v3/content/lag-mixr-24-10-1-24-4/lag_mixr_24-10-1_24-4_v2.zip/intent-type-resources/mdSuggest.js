function MdSuggest() {
    
    this.getPolicyName = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/lag?fields=lag-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:lag'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['lag-name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

  this.getMonitorOperGroup = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/service/oper-group?fields=name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:oper-group'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getVlanQosPolicy = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/vlan-qos-policy?fields=vlan-qos-policy-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:vlan-qos-policy'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['vlan-qos-policy-name']).filter(value => value != null):[];
      ret.push("default");
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getPortID = function(neId, type, mode, encaptype) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/port";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      logger.info("RESULT FETCH IS : " + JSON.stringify(resultFetch));
      const finalResponse = resultFetch.msg['nokia-conf:port'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['port-id']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      var result = [];
      if (Array.isArray(finalResponse)) {
            finalResponse.forEach((index) => {
            if(index["ethernet"] !== undefined){
                    if (index["ethernet"]["mode"] == mode && index["ethernet"]["encap-type"] == encaptype) {
                              result.push(index["port-id"]);

                    }
                    else if(undefined == mode && index["ethernet"]["encap-type"] == encaptype){
                              result.push(index["port-id"]);
                    }
                    else if(index["ethernet"]["mode"] == mode && undefined == encaptype){
                              result.push(index["port-id"]);
                    }

            }
            else if(index["ethernet"] == undefined && mode == undefined && encaptype == undefined){
                    result.push(index["port-id"]);
            }
            });
      }
      if(mode == "hybrid"){
            logger.info("Calling PXC ports");
            const Res = result.concat(this.getPXC(neId, type, mode, encaptype));
                return Res;
            }
            return result;
      }

   this.getPXC = function(neId,type,mode,encap) {
            const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/port";
            const mdcFwk = new MdcFwk();
            logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
            const resultFetch = mdcFwk.fetch(neId, url);
            logger.info("RESULT FETCH IS : " + JSON.stringify(resultFetch));
            const finalResponse = resultFetch.msg['nokia-conf:port'];
            logger.info("finalResponse = " + JSON.stringify(finalResponse));
            const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['port-id']).filter(value => value != null):[];
            logger.info("ret ="+ ret);
            var result = [];

           if (Array.isArray(finalResponse)) {
                  finalResponse.forEach((index) => {
                      logger.info("INDEX IS  "+ JSON.stringify(index));
                          if (index["ethernet"] && index["ethernet"]["mode"] && index["ethernet"]["mode"] == "hybrid" && index["ethernet"] && index["ethernet"]["encap-type"] && index["ethernet"]["encap-type"] == encap) {
                              result.push(index["port-id"]);

                          }
                          else{
                              if(/^pxc.+$/.test(index["port-id"])) {
                                result.push(index["port-id"]);
                              }
                          }
                  });
           }
           logger.info("PXC RESULT IS : "+ JSON.stringify(result));
           return result;
   }
}

