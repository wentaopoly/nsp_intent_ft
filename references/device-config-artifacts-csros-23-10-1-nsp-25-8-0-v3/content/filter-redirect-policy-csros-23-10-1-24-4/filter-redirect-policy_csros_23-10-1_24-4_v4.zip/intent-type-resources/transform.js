load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});

function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        var ipv6AddressUtil = new IPv6AddressUtil();
        payload = ipv6AddressUtil.expandIPv6(payload);
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        if(xpath === "vprnPointer")
        {
            targetValue = this.convertVprnToVprnPointer(targetValue,neId)
        }
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, neId) {
        if(xpath === "vprnPointer")
        {
            targetValue = this.convertVprnPointerToVprn(targetValue + ":" + neId, neId);
        }
        return targetValue;
    }
    this.convertVprnToVprnPointer = function (vprn, neId) {
        let className = "vprn.Site";
        let searchObject = {
            "fullClassName": className,
            "filter":
            {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "serviceName",
                            "value": vprn
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "objectFullName"
                ]
            }
        };
        let nfmpFwk = new NfmpFwk();
        let result = {};
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        let finalResponse = JSON.parse(resultFetch.response);
        finalResponse = finalResponse[className];
        //logger.info(JSON.stringify(finalResponse));
        return finalResponse["objectFullName"].replace(":"+neId, '');
    }
    this.convertVprnPointerToVprn = function (vprnPointer, neId) {
        let className = "vprn.Site";
        let searchObject = {
            "fullClassName": className,
            "filter":
            {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "objectFullName",
                            "value": vprnPointer
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "serviceName"
                ]
            }
        };
        let nfmpFwk = new NfmpFwk();
        let result = {};
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        let finalResponse = JSON.parse(resultFetch.response);
        finalResponse = finalResponse[className];
        //logger.info(JSON.stringify(finalResponse));
        return finalResponse["serviceName"];
    }
}