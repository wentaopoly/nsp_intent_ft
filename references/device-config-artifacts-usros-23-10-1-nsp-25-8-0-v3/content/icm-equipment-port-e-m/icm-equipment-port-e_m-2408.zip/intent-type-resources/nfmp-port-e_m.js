var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpPort() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    let nfmpFwk = new NfmpFwk();
    var savedObjects;
    var currentObjects;
    var isAudit = false;

    this.synchronize = function(input, result,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {
        // setting up topology
        var savedTopology = input.getCurrentTopology();
        logger.info("Saved Topology = "+savedTopology);
        savedObjects = {};
        currentObjects = {};
        //loading the saved objects from topology
        this.loadSavedObjectsFromTopology(savedTopology);
        var parseTarget = new ParseTarget();
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        logger.info("Target device = " + target);
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());
        logger.info("Target port = " + intentConfig[uniqueIdentifier]);
        intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        logger.info("Configuration to be pushed = "+JSON.stringify(intentConfig));

        if (input.getNetworkState().name() == "delete"){
            return this.syncDelete(target,intentConfig[uniqueIdentifier],result);
        }

        this.createOrModify(target,intentConfig[uniqueIdentifier],intentConfig);
        var currentTopo = this.loadCurrentObjectsToTopology(target);

        return util.setSuccessResult(result,currentTopo);
    }

    this.audit = function(target, config, svcTopo, adminState, auditReport,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {
        var savedTopology = svcTopo;
        currentObjects = {};
        var parseTarget = new ParseTarget();
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        logger.info("Target = "+ target)
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        var target = parseTarget.getNeIdFromTarget(target);
        logger.info("Target device = " + target);
        logger.info("Target port = " + intentConfig[uniqueIdentifier]);
        intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        logger.info("auditing configuration = "+JSON.stringify(intentConfig));
        isAudit = true;

        if(intentConfig){
            this.auditAndCompare(target,intentConfig[uniqueIdentifier],intentConfig,auditReport);
        }else{
            throw "configuration not available in the intent";
        }
        return auditReport;
    }

    this.createOrModify = function(target,portId,intentConfig){
        // port level attributes
        var result = this.portLevel(target,portId,intentConfig);
        this.modifyRequest(target, result);
        return result;
    }

    this.auditAndCompare = function(target,portId,intentConfig,auditReport){
        // port level attributes
        var portLevelPayload = this.portLevel(target,portId,intentConfig);
        var result = this.auditRequest(target, portLevelPayload);
        auditReport = util.reportMisaligned(target, result,auditReport);
        return auditReport;
    }

    this.portLevel = function(target,portId,intentConfig){

        var fullClassName = "equipment.PhysicalPort";                    // full class name for port
        var portLevelFdn = util.getBaseFdnForPort(target,portId);        // portlevel attributes fdn
        var objectFullName = portLevelFdn;                               // objectFullName is same as fdn for port level
        var properties = {};
        var childProperties = {};

        (intentConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";
        if (intentConfig["description"]){
            properties["description"] = intentConfig["description"];
        }
        var voicePortSpecificsPayload = this.createVoicePortSpecifics(target,intentConfig, portLevelFdn);
        childProperties['tdmequipment.VoicePortSpecifics'] = voicePortSpecificsPayload['tdmequipment.VoicePortSpecifics'];
        //creating Voice Channel
        var voiceChannelPayload = this.createVoiceChannel(target,intentConfig, portLevelFdn);
        childProperties['tdmequipment.VoiceChannel'] = voiceChannelPayload['tdmequipment.VoiceChannel'];

        var portLevelPayload = util.editPayload(portLevelFdn,properties,childProperties,fullClassName,objectFullName);

        return portLevelPayload;
    }

    this.createVoicePortSpecifics = function(target,intentConfig, portLevelFdn){
        var fullClassName = "tdmequipment.VoicePortSpecifics";
        var voicePortSpecificsConfig = intentConfig["voicePort"];
        var objectFullName = portLevelFdn + ":voiPort";
        var properties = {};
        if(voicePortSpecificsConfig && voicePortSpecificsConfig["tlp-rx"] !== undefined)
        {
            properties["rxTlp"] = voicePortSpecificsConfig["tlp-rx"];
        }
        if (voicePortSpecificsConfig && voicePortSpecificsConfig["tlp-tx"] !== undefined)
        {
            properties["txTlp"] = voicePortSpecificsConfig["tlp-tx"];
        }
        return this.createChildObjectPayload(fullClassName,properties,null);
    }

    this.createVoiceChannel = function(target,intentConfig, portLevelFdn) {
        var fullClassName = "tdmequipment.VoiceChannel";
        var voiceChannelConfig = intentConfig["voiceChannel"];
        var objectFullName = portLevelFdn + ":voice-1";
        var properties = {};
        var childProperties = {};

        if(intentConfig['voiceChannel']){

            (voiceChannelConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";
            properties['displayedLocalChannelId'] = 1;
            properties['portChannelType'] = "voiceEm";
            var voiceChannelSpecificsPayload = this.createVoiceChannelSpecifics(target,voiceChannelConfig, portLevelFdn);
            childProperties['tdmequipment.VoiceChannelSpecifics'] = voiceChannelSpecificsPayload['tdmequipment.VoiceChannelSpecifics'];
            var ds0ChannelGroupPayload =  this.createDS0ChannelGroup(target,voiceChannelConfig, portLevelFdn);
            childProperties['tdmequipment.DS0ChannelGroup'] =ds0ChannelGroupPayload['tdmequipment.DS0ChannelGroup'];

            return this.createChildObjectPayload(fullClassName, properties,childProperties);
        }
        else{

            this.removeChannel(target, fullClassName, objectFullName);
            return {};

        }
    }

    this.createVoiceChannelSpecifics = function(target,voiceChannelConfig, portLevelFdn){
        var fullClassName = "tdmequipment.VoiceChannelSpecifics";
        var voiceChannelSpecificsConfig = voiceChannelConfig;
        var objectFullName = portLevelFdn + ":voice-1:voiSpec";
        var properties = {};
        var childProperties = {};
        (voiceChannelSpecificsConfig["signal-mode"] == "Transmission-only") ? properties["transmissionMode"] = "transmitOnly" : properties["transmissionMode"] = "em";
        return this.createChildObjectPayload(fullClassName,properties,null);
    }

    this.createDS0ChannelGroup = function(target,voiceChannelConfig, portLevelFdn){
        var fullClassName = "tdmequipment.DS0ChannelGroup";
        var ds0ChannelGroupConfig = voiceChannelConfig["ds0Channel-group"];
        var objectFullName = portLevelFdn + ":voice-1:ds0Grp-1";
        var properties = {};
        var childProperties = {};

        if(voiceChannelConfig["ds0Channel-group"])
        {
            if(ds0ChannelGroupConfig["channel-group-id"] = "1"){
                properties["displayedLocalChannelId"] = "1";
            }
            if(!isAudit){
                properties["portChannelType"] = "pdhDs0Grp";
                properties["mode"] = "access";
            }

            properties["encapType"] = util.convertToNfmpEncapType(ds0ChannelGroupConfig["encapType"]);
            (ds0ChannelGroupConfig["admin-state"] == "Up") ? properties["administrativeState"] = "portInService" : properties["administrativeState"] = "portOutOfService";
            return this.createChildObjectPayload(fullClassName, properties,null);

        }
        else
        {
            this.removeChannel(target, fullClassName, objectFullName);
            return {};
        }
    }


    this.removeChannel = function (target, fullClassName, objectFullName) {

        var searchPayLoad =  util.constructSearchString(fullClassName, objectFullName);
        var searchResponse = nfmpFwk.find(target, searchPayLoad);
        if(searchResponse['response'] != "{}")
        {
            var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
            if (!deleteResult.success) {
                logger.info("[NFMP-PORT-E&M] removeChannel(): Unable to Delete: " + deleteResult.msg);
                throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
            }
        }
        return {};
    }


    this.createChildObjectPayload = function (fullClassName, properties, childProperties) {
        var childObjectPayLoad = {};
        childObjectPayLoad[fullClassName] = properties;
        if(childProperties != null || childProperties != undefined)
        {
            childObjectPayLoad[fullClassName]["children-Set"] = childProperties;
        }
        return childObjectPayLoad;
    }

    this.auditRequest = function(target,payload){
        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.modifyRequest = function(target,payload){
        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.syncDelete = function (target,portId,result) {
        var portLevelFdn = util.getBaseFdnForPort(target,portId);
        var objectFullName = portLevelFdn+":voice-1";
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success) {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }

    this.xml2object = function(xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('Input JSON: '+ json)
        return JSON.parse(json);
    }

    this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }
            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }
            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }

    this.loadCurrentObjectsToTopology = function(target) {
        var currentTopo = topologyFactory.createServiceTopology();
        if(Object.keys(currentObjects).length){
            for(var key in currentObjects){
                objectId = mapFwk.get(currentObjects,key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key,objectId,"INFRASTRUCTURE",target,""));
            }
        }
        return currentTopo;
    }

    this.loadSavedObjectsFromTopology = function(savedTopology) {
        if(savedTopology){
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0){
                topoObjects.forEach(function(topoObject){
                    mapFwk.set(savedObjects,topoObject.getObjectType(),topoObject.getObjectRelativeObjectID());
                });
            }
        }
    }

    this.deleteRemovedObjects = function(target) {
        if(Object.keys(savedObjects).length > 0){
            for(var key in savedObjects){
                var value = mapFwk.get(currentObjects,key);
                if(value == undefined || value =="undefined" || value == null) {
                    logger.info("To be Deleted " + key);
                    var objectFullName = key;
                    if (target && String(target).indexOf(':') !== -1) {
                                objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
                    }
                    var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

                    if (!deleteResult.success) {
                        throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
                    }
                }
            }
        }
    };
}

