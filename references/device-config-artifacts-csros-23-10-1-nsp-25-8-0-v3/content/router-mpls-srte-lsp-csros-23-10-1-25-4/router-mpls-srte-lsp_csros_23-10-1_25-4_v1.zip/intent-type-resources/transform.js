load({script: resourceProvider.getResource("nfmpSuggest.js"), name: "NfmpSuggest" });
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
function transformData() {
    let ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(\/(0|[1-9][0-9]?|1[0-1][0-9]?|12[0-8]))?$/;
    const nfmpSuggest = new NfmpSuggest();
    const util = new utilities();
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        let lspData;
        if(intentConfig.displayedName){
            lspData = nfmpSuggest.getLspData(neId, intentConfig.displayedName, "pathId", "displayedName");
            if(!isAudit && lspData == undefined)
            {
                let usedPathId = nfmpSuggest.getLspIds(neId, "pathId");
                let availablePathId = [];

                for (let i = 65536; availablePathId.length < 1000 && i <= 131071; i++) {
                    if (usedPathId==undefined || !usedPathId.has(i)) {
                        availablePathId.push(i);
                    }
                }
                //Pick a random one
                lspData = availablePathId[Math.floor(Math.random() * availablePathId.length)];

                let nfmpFwk = new NfmpFwk();
                let url = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true";
                let configureSRTELsp = nfmpFwk.post(url, util.configureSRTELSPPayload(intentConfig,lspData));
                if (!configureSRTELsp.success)
                {
                    throw new RuntimeException('Unable to Configure SRTE LSP: ' + configureSRTELsp.msg)
                }
            }
			intentConfig.pathId = lspData;
            objectFullName = objectFullName.replace(/id-[^:]+/, "id-"+lspData);
        }
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        let lspName = uniqueIdentifierValues[1];
        if(lspName){
            let lspData = nfmpSuggest.getLspData(neId, lspName, "pathId", "displayedName");
            objectFullName = objectFullName.replace(/id-[^:]+/, "id-"+lspData);
        }
		return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {

        if (payload && payload["configInfo"] && payload["configInfo"]["mpls.SegmentRoutingTeLsp"])
        {
            if(isAudit && payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["destinationNodeId"])
            {
                delete payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["destinationNodeId"];
            }
            if (!payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["egrAccountingPolicyObjectPointer"])
            {
                payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["egrAccountingPolicyObjectPointer"] = "";
            }
            if (payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["children-Set"])
            {
                if (payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["children-Set"]["mpls.LspPath"])
                {
                    for (var index in payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["children-Set"]["mpls.LspPath"]) {
                        var lspPathConfig = payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["children-Set"]["mpls.LspPath"][index];

                        if (!lspPathConfig["bfdTemplatePointer"]) {
                           lspPathConfig["bfdTemplatePointer"] = "";
                        }
                        if(!isAudit && !lspPathConfig["propertyInheritance"]){
                            lspPathConfig["propertyInheritance"] = {};
                            lspPathConfig["propertyInheritance"]["bit"] = [];
                        }

                        payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["children-Set"]["mpls.LspPath"][index] = lspPathConfig;
                    }
                }
                if (payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["children-Set"]["mpls.LspExtension"])
                {
                    if(!payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["children-Set"]["mpls.LspExtension"]["bfdTemplatePointer"]){
                        payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["children-Set"]["mpls.LspExtension"]["bfdTemplatePointer"] = "";
                    }
                    if(!payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["children-Set"]["mpls.LspExtension"]["policyNamePointer"]){
                        payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["children-Set"]["mpls.LspExtension"]["policyNamePointer"] = "";
                    }
                    if(!payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["children-Set"]["mpls.LspExtension"]["adminGroupInclude"]){
						payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["children-Set"]["mpls.LspExtension"]["adminGroupInclude"] = "0";
					}
					if(!payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["children-Set"]["mpls.LspExtension"]["adminGroupExclude"]){
						payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["children-Set"]["mpls.LspExtension"]["adminGroupExclude"] = "0";
					}
                    payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["children-Set"]["mpls.LspExtension"]["pathId"] = payload["configInfo"]["mpls.SegmentRoutingTeLsp"]["pathId"];
                }
            }

        }

        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
    	let ipv6AddrUtil = new IPv6AddressUtil();
        if(xpath == "mpls-LspExtension.bfdTemplatePointer" ||
           xpath == "mpls-LspPath.bfdTemplatePointer")
        {
            targetValue = 'BFDTemplate:'+ targetValue;
        }
        if(xpath == "egrAccountingPolicyObjectPointer")
        {
            targetValue = 'Accounting:'+ targetValue;
        }
        if(xpath == "mpls-LspExtension.policyNamePointer")
        {
            targetValue = 'network:' + neId + ':router-1:mpls:plcy-'+ targetValue;
            if (neId && String(neId).indexOf(':') !== -1) {
                targetValue = util.modifyNeIdForIpV6(targetValue, neId);
            }
        }
        if(isAudit && (xpath == 'sourceIpAddress' || xpath == 'destinationNodeId' || xpath == 'destinationIpAddress'))
        {
        	if(ipv6AddrUtil.matchExact(ipv6Regex, targetValue))
			{
				targetValue = ipv6AddrUtil.expandIPv6AddressForClassic(targetValue);
			}
        }
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
        if(xpath == "mpls-LspExtension.bfdTemplatePointer" ||
           xpath == "mpls-LspPath.bfdTemplatePointer")
        {
            targetValue = targetValue.replace('BFDTemplate:', '');
        }
        if(xpath == "egrAccountingPolicyObjectPointer")
        {
            targetValue = targetValue.replace('Accounting:', '');
        }
        if(xpath == "mpls-LspExtension.policyNamePointer")
        {
            targetValue = targetValue.split(':router-1:mpls:plcy-')[1];
        }
        if(xpath == "mpls-LspExtension.adminGroupInclude" ||
           xpath == "mpls-LspExtension.adminGroupExclude" ||
           xpath == "mpls-LspPath.adminGroupInclude" ||
           xpath == "mpls-LspPath.adminGroupExclude" )
        {
            let result = [];
            for (let i = 0; i < 32; i++) {
                if ((targetValue & (1 << i)) !== 0) {
                    result.push(`${i}`);
                }
            }
            targetValue = nfmpSuggest.getFormattedAdminGroupData(result, fullDeviceConfig["sourceNodeId"]);
        }

        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }

    this.transformIntentConfig = function (intentConfig) {
        function handleAdminGroupValue(value) {
            let binary = 0;
            if (!Array.isArray(value)) {
                value = [value];
            }
            value.forEach(item => {
                const match = item.match(/\((\d+)\)/);
                if (match) {
                    const bitPosition = Number(match[1]);
                    binary |= (1 << bitPosition);
                }
            });
            return binary.toString();
        };
        if(intentConfig["mpls-LspExtension"]) {
            if(intentConfig["mpls-LspExtension"]["adminGroupInclude"]) {
                intentConfig["mpls-LspExtension"]["adminGroupInclude"] = handleAdminGroupValue(intentConfig["mpls-LspExtension"]["adminGroupInclude"]);
            }
            if(intentConfig["mpls-LspExtension"]["adminGroupExclude"]) {
                intentConfig["mpls-LspExtension"]["adminGroupExclude"] = handleAdminGroupValue(intentConfig["mpls-LspExtension"]["adminGroupExclude"]);
            }
        }
        if(intentConfig["mpls-LspPath"]) {
            for (var index in intentConfig["mpls-LspPath"]) {
                var lspPathIConfig = intentConfig["mpls-LspPath"][index];
                if(lspPathIConfig["adminGroupInclude"]){
                    lspPathIConfig["adminGroupInclude"] = handleAdminGroupValue(lspPathIConfig["adminGroupInclude"]);
                }
                if(lspPathIConfig["adminGroupExclude"]){
                    lspPathIConfig["adminGroupExclude"] = handleAdminGroupValue(lspPathIConfig["adminGroupExclude"]);
                }
                intentConfig["mpls-LspPath"][index]=lspPathIConfig;
            }
        }
    }
}
