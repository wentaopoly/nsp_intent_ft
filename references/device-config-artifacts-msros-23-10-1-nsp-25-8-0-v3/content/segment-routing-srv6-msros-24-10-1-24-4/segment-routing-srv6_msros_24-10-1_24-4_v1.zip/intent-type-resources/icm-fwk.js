load({
  script: resourceProvider.getResource("mediator-fwk.js"),
  name: "mediator-fwk",
});
var nfmpFwk = new MediatorFramework("NFMP");

load({
  script: resourceProvider.getResource("nsp-restconf-fwk.js"),
  name: "nsp-restconf-fwk",
});
var nspRestconfFwk = new NspRestconfFwk();

load({
  script: resourceProvider.getResource("discovery-helper-nfmp.js"),
  name: "discovery-helper-nfmp",
});
load({
  script: resourceProvider.getResource("discovery-helper-mdc.js"),
  name: "discovery-helper-mdc",
});
load({
  script: resourceProvider.getResource("mdt-fwk.js"),
  name: "MdtFwk",
});
load({
  script: resourceProvider.getResource("parse-target.js"),
  name: "ParseTarget",
});


function ICMFwk() {
  let mdtFwk = new MdtFwk();
  let parseTarget = new ParseTarget();
  let mdcDiscoveryHelper = null;

  /**
   * get the device configuration
   * @param {*} targetWithTemplate
   * @param {*} deviceYangModuleName
   * @param {*} parentXpath
   * @param {*} intentContainer
   * @returns
   */
  this.getDeviceConfiguration = function (
    targetWithTemplate,
    deviceYangModuleName,
    parentXpath,
    intentContainer
  ) {
    logger.info("ICMFwk::getDeviceConfiguration");
    let targetAr = targetWithTemplate.split("#");
    let templateName = targetAr[0];
    let neId = parseTarget.getNeIdFromTarget(targetWithTemplate);
    let discoveryHelper = this.getDiscoveryHelper(neId);
    let targetDataStruct = this.getTargetDataStruct(templateName);
    let deviceConfig = discoveryHelper.getDeviceConfiguration(
      targetWithTemplate,
      deviceYangModuleName,
      parentXpath,
      intentContainer
    );
    if (
      typeof deviceConfig === "string" &&
      deviceConfig.indexOf("Failed to fetch service") > -1
    ) {
      logger.error(deviceConfig);
      return deviceConfig;
    }
    let postDiscObj = {
    deviceConfig: deviceConfig,
    intentContainer: intentContainer,
    neId: neId,
    targetDataStruct: targetDataStruct,
    templateName: templateName,
    deviceYangModuleName: deviceYangModuleName
  }
    customHooks.postDiscovery(postDiscObj);
    deviceConfig = postDiscObj.deviceConfig;
    intentContainer= postDiscObj.intentContainer;
    neId= postDiscObj.neId;
    targetDataStruct= postDiscObj.targetDataStruct;
    templateName= postDiscObj.templateName;
    deviceYangModuleName= postDiscObj.deviceYangModuleName;
    return discoveryHelper.extractDeviceConfig(
      targetDataStruct,
      deviceConfig,
      intentContainer,
      neId
    );
  };

  /**
   *
   * Get the template object from ICM
   *
   * @param {*} templateName
   * @returns
   */
  this.getTemplate = function (templateName) {
    logger.info("ICMFwk::getTemplate::templateName = " + templateName);
    return nspRestconfFwk.getByXpath(
      "/nsp-icm:icm/templates/template=" + templateName
    );
  };

  /**
   * Get the getTargetDataStructructure of a Template
   * @param {*} templateName
   * @returns
   */
  this.getTargetDataStruct = function (templateName) {
    let templateObj = nspRestconfFwk.getByXpath(
      "/nsp-icm:icm/templates/template=" + templateName
    );
    let targetDataStruct =
      templateObj["nsp-icm:template"][0]["target-data-struct"];
    logger.info("\nICMFwk::getTargetDataStruct\n" + targetDataStruct);
    targetDataStruct = '{"segment-routing-v6":{"origination-fpe": null, "source-address":null,"locator":[{"locator-name":null,"block-length":null,"function-length":null,"label-block":null,"argument-length":null,"admin-state":null,"algorithm":null,"prefix":{"ip-prefix":null},"static-function":{"max-entries":null,"label-block":null}}],"micro-segment":{"block-length":null,"global-sid-entries":null,"sid-length":null,"argument-length":null},"micro-segment-locator":[{"locator-name":null,"admin-state":null,"algorithm":null,"block":null,"un":{"srh-mode":null,"value":null}}],"base-routing-instance":{"locator":[{"locator-name":null,"function":{"end-dt4":{"value":null},"end-dt6":{"value":null},"end-dt46":{"value":null}},"end":[{"value":null,"srh-mode":null}],"end-x":[{"value":null,"srh-mode":null,"protection":null,"interface-name":null}],"end-x-auto-allocate":[{"srh-mode":null,"protection":null}]}],"micro-segment-locator":[{"locator-name":null,"function":{"udt4":{"value":null},"udt6":{"value":null},"udt46":{"value":null}},"ua":[{"value":null,"srh-mode":null,"protection":null,"interface-name":null}],"ua-auto-allocate":[{"srh-mode":null,"protection":null}]}]}}}';
    return targetDataStruct;
  };

  /**
   *
   * @param {*} neId
   * @returns
   */
  this.getDiscoveryHelper = function (neId) {
    let managerName = mdtFwk.getManagerName(neId);
    logger.info("Device: " + neId + " is managed by: " + managerName);

    switch (managerName) {
      case "NFM-P":
        logger.info("Device is managed by NFMP");
        return this.createNfmpDiscoveryHelper();
        break;
      case "MDC":
        logger.info("Device is managed by MDM");
        return this.createMdcDiscoveryHelper();
        break;
      default:
        logger.info("Device is not managed");
        throw new RuntimeException("Device is not Managed");
    }
    return "";
  };

  /**
   *
   * @returns
   */
  this.createNfmpDiscoveryHelper = function () {
    return new NfmpDiscoveryHelper();
  };

  /**
   *
   * @returns
   */
  this.createMdcDiscoveryHelper = function () {
    if (mdcDiscoveryHelper == null) {
      mdcDiscoveryHelper = new MdcDiscoveryHelper();
    }
    return mdcDiscoveryHelper;
  };
}
