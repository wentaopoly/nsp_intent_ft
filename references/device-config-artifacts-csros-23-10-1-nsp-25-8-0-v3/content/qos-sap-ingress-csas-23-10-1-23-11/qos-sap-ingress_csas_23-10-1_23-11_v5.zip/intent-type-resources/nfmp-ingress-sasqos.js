var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpSasIngress() {

    var util = new utilities();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var savedTopology;
    var isAudit = false;
    var isEdit = false;
    var isLocalExists = false;
    var isGlobalExists = false;
    var modeChanged = false;
    var auditResult = {};
    var distribute_url = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true";

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        if (input.getNetworkState().name() == "delete")
        {
            logger.info("Calling syncDelete");
            return this.syncDelete(input, result);
        }
        savedTopology = input.getCurrentTopology();
        isAudit = false;
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        var intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        intentConfig["sap-ingress-id"] = parseInt(input.getTarget().split("#")[2]);
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        this.createOrModify(neId, intentConfig, intentConfig["sap-ingress-id"]);
        return util.setSuccessResult(result, savedTopology);
    }
    this.syncDelete = function (input, result) {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyName = input.getTarget().split("#")[2];
        var objectFullName = "network:" + neId + ":sasAccessIngress:" + policyName;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        logger.info("Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }

    this.createOrModify= function(neId, intentConfig,uniqueIdentifier) {
        var fullClassName = "sasqos.AccessIngress";
        var objectFullName = "sasAccessIngress:" + intentConfig["sap-ingress-id"];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        var localPolicy = util.getIfObjectExists(fullClassName, localPolicyFullName);
        var result;
        var portEgressPayload;
        var distributePayload;
        var distributeResult;
        if (localPolicy != null) {

            isLocalExists = true;
            isGlobalExists = true;
            if (localPolicy[0]["id"] != uniqueIdentifier) {
                throw new RuntimeException("Already there exists a policy on " + neId +
                    " with policy id " + localPolicy[0]["id"] + " with policy ID " + intentConfig["sap-ingress-id"]);
            }
            portEgressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, isLocalExists, localPolicy);
            result = this.modifyRequest(neId, portEgressPayload);
            if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                throw new RuntimeException('Unable to Create/Distribute Policy: ' + intentConfig["sap-ingress-id"] +
                    " , Kindly check the intent configuration");
            }
        }
        else {
            logger.info( "Unable to find the local policy, Trying to fetch global policy if available ");
            var searchPayload = this.constructSearchString(fullClassName, objectFullName);
            var searchResponse = nfmpFwk.find(neId, searchPayload);
            if (!(searchResponse.success && JSON.stringify(searchResponse.response) === "")) {
                if (!searchResponse.success) {
                    logger.info( "createOrModify(): Unable to get Policy info from nfm-p for Ne " +
                        neId + " and Policy name: " + uniqueIdentifier);
                }
                if (searchResponse.response === "") {
                    logger.info("createOrModify(): There is no port-egress policy with ID:" +
                        uniqueIdentifier + " on " + neId);
                }
            }
            else {
                throw new RuntimeException("createOrModify(): There exists a port-egress policy " + uniqueIdentifier + " on " +
                    neId + " with ID " +intentConfig["policy-id"]);
            }

            var globalPolicy = util.getIfObjectExists(fullClassName, objectFullName);
            logger.info("GLOBAL policy : " + JSON.stringify(globalPolicy));
            if (globalPolicy != null) {
                isGlobalExists = true;
                if (globalPolicy[0]["id"] != uniqueIdentifier) {
                    logger.info("createOrModify(): There exists a port-egress global policy in NFMP with policy Id " + intentConfig["sap-ingress-id"] + " on " + neId);
                    this.updateAccessIngressPolicyId(neId, objectFullName, uniqueIdentifier);
                }

                distributePayload = util.distribute(neId, objectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(neId, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                logger.info("checking distribution of existing global policy was successful");
                if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                    throw new RuntimeException("Unable to Distribute existing Global Policy: " + uniqueIdentifier +
                        " , Kindly check the Global Policy configuration");
                }
                logger.info("distribution of existing global policy was successful, updating with intent configuration ");
                portEgressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, true, globalPolicy);
                result = this.modifyRequest(neId, portEgressPayload);
                if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                    throw new RuntimeException('Unable to Create/Distribute Policy: ' + uniqueIdentifier +
                        " , Kindly check the intent configuration");
                }
            }
            else {
                //distributing empty policy
                logger.info(" Unable to find the Global Policy, distributing empty policy and updating");
                portEgressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, false, null);
                result = this.modifyRequest(neId, portEgressPayload);
                distributePayload = util.distribute(neId, objectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(neId, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                //updating the local policy with intent configuration
                portEgressPayload = this.createPolicyLevelPayLoad(neId, intentConfig, true, null);
                result = this.modifyRequest(neId, portEgressPayload);
            }
        }
        return result;
    }


    this.createPolicyLevelPayLoad = function(neId, intentConfig, isLocalExists) {
        if (savedTopology == null)
        {
            savedTopology = topologyFactory.createServiceTopology();
        }
        var fullClassName = "sasqos.AccessIngress";
        var policyFdn = "sasAccessIngress";
        var objectFullName = "sasAccessIngress:" + intentConfig["sap-ingress-id"];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);

        if (isLocalExists) {
            objectFullName = localPolicyFullName;
        }

        var properties = {};
        var childProperties = {};
        properties["id"] = intentConfig["sap-ingress-id"];
        //properties["displayedName"] = intentConfig["sap-ingress-name"];
        properties["description"] = intentConfig["description"];
        properties["defaultFc"] = intentConfig["default-fc"];
        properties["numQosClassifiers"] = intentConfig["num-qos-classifiers"];
        properties["scope"] = intentConfig["scope"];
        properties["ipMacMatchClassificationType"] = this.convertToIpMacMatchClassificationType(intentConfig["ip-mac-match"]);
        if(intentConfig["dscp-classification"] != null) {
            properties["dscpClassificationPointer"] = "sasDSCPClassification:Dscp-" + intentConfig["dscp-classification"];
        }
        if(intentConfig["dot1p-classification"] != null) {
            properties["dot1pClassificationPointer"] = "sasDot1pClassification:Dot1p-" + intentConfig["dot1p-classification"];
        }
        properties["tableClassificationCriteria"] = this.convertToTableClassificationCriteria(intentConfig["table-classification-criteria"]);
        properties["defaultFcProfile"] = this.convertToProfile(intentConfig["profile"]);
        properties["macMatchCriteriaType"] = intentConfig["mac-match-criteria-type"];
        properties["ipMatchCriteriaType"] = intentConfig["ip-match-criteria-type"];
        properties["enableIpv6Classification"] = intentConfig["allow-any-ipv6-match"];
        if(intentConfig["allow-any-ipv6-match"] == "true") {
            properties["enableIpv6Classification"] = "true";
            properties["ipv6MatchCriteriaType"] = intentConfig["ipv6-match-criteria-type"];
        }
        else {
            properties["enableIpv6Classification"] = "false";
            properties["ipv6MatchCriteriaType"] = intentConfig["ipv6-match-criteria-type"];
        }
        properties["enableInnerDot1pMatch"] = intentConfig["enable-inner-dot1p-match-criteria"];


        var policyLevelPayload = util.editPayload(policyFdn, properties, childProperties, fullClassName, objectFullName);
        var meterPayload = [];
        if(intentConfig["meter"]) {
            if(!Array.isArray(intentConfig["meter"]["meter"])) {
                intentConfig["meter"] = [intentConfig["meter"]];
            }
            for(var index in intentConfig["meter"]["meter"]) {
                var meterLevelPayload = this.createMeter(neId, intentConfig, index);
                meterPayload.push(meterLevelPayload);
                childProperties["sasqos.Meter"] = JSON.parse(JSON.stringify(meterPayload));
            }
        }

        if(intentConfig["queue"]) {
            var queuePayload = [];
            if(!Array.isArray(intentConfig["queue"]["queue"])) {
                intentConfig["queue"] = [intentConfig["queue"]];
            }
            for(var index in intentConfig["queue"]["queue"]) {
                var queueLevelPayload = this.createQueue(neId, intentConfig, index);
                queuePayload.push(queueLevelPayload);
                childProperties["sasqos.AccessIngressQueue"] = JSON.parse(JSON.stringify(queuePayload));
            }
        }

        if(intentConfig["fc"]) {
            var fcPayload = [];
            if(!Array.isArray(intentConfig["fc"]["fc"])) {
                intentConfig["fc"] = [intentConfig["fc"]];
            }
            for(var index in intentConfig["fc"]["fc"]) {
                var fcLevelPayload = this.createFc(neId, intentConfig, index);
                fcPayload.push(fcLevelPayload);
                childProperties["sasqos.AccessIngressForwardingClass"] = JSON.parse(JSON.stringify(fcPayload));
            }
        }

        if(intentConfig["ip-criteria"]) {
            var ipPayload = [];
            if(!Array.isArray(intentConfig["ip-criteria"]["entry"])) {
                intentConfig["ip-criteria"] = [intentConfig["ip-criteria"]];
            }
            for(var index in intentConfig["ip-criteria"]["entry"]) {
                var ipCriteriaLevelPayload = this.createIpCriteria(neId, intentConfig, index);
                ipPayload.push(ipCriteriaLevelPayload);
                childProperties["sasqos.IpMatch"] = JSON.parse(JSON.stringify(ipPayload));
            }
        }

        if(intentConfig["ipv6-criteria"]) {
            var ipv6Payload = [];
            if(!Array.isArray(intentConfig["ipv6-criteria"]["entry"])) {
                intentConfig["ipv6-criteria"] = [intentConfig["ipv6-criteria"]];
            }
            for(var index in intentConfig["ipv6-criteria"]["entry"]) {
                var ipv6CriteriaLevelPayload = this.createIpv6Criteria(neId, intentConfig, index);
                ipv6Payload.push(ipv6CriteriaLevelPayload);
                childProperties["sasqos.Ipv6Match"] = JSON.parse(JSON.stringify(ipv6Payload));
            }
        }

        if(intentConfig["mac-criteria"]) {
            var macPayload = [];
            if(!Array.isArray(intentConfig["mac-criteria"]["entry"])) {
                intentConfig["mac-criteria"] = [intentConfig["mac-criteria"]];
            }
            for(var index in intentConfig["mac-criteria"]["entry"]) {
                var macCriteriaLevelPayload = this.createMacCriteria(neId, intentConfig, index);
                macPayload.push(macCriteriaLevelPayload);
                childProperties["sasqos.MacMatch"] = JSON.parse(JSON.stringify(macPayload));
            }
        }

        policyLevelPayload = util.editPayload(policyFdn, properties, childProperties, fullClassName, localPolicyFullName);


        if (!isAudit)
        {
            this.sendRequestAndDistribute(neId, policyLevelPayload, objectFullName, intentConfig);
        }

        if(isAudit)
        {
            this.updateAuditResult(this.auditRequest(neId, policyLevelPayload));
        }

        return policyLevelPayload;
    }


    this.createMeter = function(neId, intentConfig, index) {
        var fullClassName = "sasqos.Meter";
        var policyFdn = "sasAccessIngress";
        var objectFullName = "sasAccessIngress:" + intentConfig["sap-ingress-id"] + ":meter-entry-" + intentConfig["meter"]["meter-id"];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        var meterConfig = intentConfig["meter"]["meter"][index];
        var properties = {};

        properties["id"] = meterConfig["meter-id"];

        if(meterConfig["rate-mode"]) {
            properties["rateMode"] = this.convertToRateMode(meterConfig["rate-mode"]);
        }
        if(meterConfig["color-mode"]) {
            properties["colorMode"] = this.convertToColorMode(meterConfig["color-mode"]);
        }
        if(meterConfig["rate"]["cir-max"]) {
            properties["cir"] = -1;
        }
        if(meterConfig["rate"]["cir-max"] == false && meterConfig["rate"]["Cir"]) {
            properties["cir"] = meterConfig["rate"]["Cir"];
        }
        if(meterConfig["rate"]["pir-max"]) {
            properties["pir"] = -1;
        }
        if(meterConfig["rate"]["pir-max"] == false && meterConfig["rate"]["Pir"]) {
            properties["pir"] = meterConfig["rate"]["Pir"];
        }
        if(meterConfig["adaptation-rule"]["cir"]) {
            properties["cirAdaptation"] = meterConfig["adaptation-rule"]["cir"];
        }
        if(meterConfig["adaptation-rule"]["pir"]) {
            properties["pirAdaptation"] = meterConfig["adaptation-rule"]["pir"];
        }


        if(meterConfig["Burst-Size"]["default-cbs"]) {

            if(meterConfig["Burst-Size"]["CBS-type"]) {
                properties["cbsType"] = this.convertToCBS_MBSType(meterConfig["Burst-Size"]["CBS-type"]);
            }

            if(meterConfig["Burst-Size"]["CBS-type"] == "Kilobytes") {
                properties["cbsKiloBytes"] =-1;
            }
            else if(meterConfig["Burst-Size"]["CBS-type"] == "Bytes") {
                properties["cbsBytes"] = -1;
            }
            else {
                properties["cbs"] = -1;
            }
        }

        else{
            if(meterConfig["Burst-Size"]["CBS-type"]) {
                properties["cbsType"] = this.convertToCBS_MBSType(meterConfig["Burst-Size"]["CBS-type"]);
            }

            if(meterConfig["Burst-Size"]["CBS-type"] == "Kilobytes") {
                properties["cbsKiloBytes"] = meterConfig["Burst-Size"]["admin-CBS-kilobytes"];
            }
            else if(meterConfig["Burst-Size"]["CBS-type"] == "Bytes") {
                properties["cbsBytes"] = meterConfig["Burst-Size"]["admin-CBS-bytes"];
            }
            else {
                properties["cbs"] = meterConfig["Burst-Size"]["admin-CBS-kilobits"];
            }
        }

        if(meterConfig["Burst-Size"]["default-mbs"]) {

            if(meterConfig["Burst-Size"]["CBS-type"]) {
                properties["cbsType"] = this.convertToCBS_MBSType(meterConfig["Burst-Size"]["CBS-type"]);
            }

            if(meterConfig["Burst-Size"]["MBS-type"] == "Kilobytes") {
                properties["mbsKiloBytes"] =-1;
            }
            else if(meterConfig["Burst-Size"]["MBS-type"] == "Bytes") {
                properties["mbsBytes"] = -1;
            }
            else {
                properties["mbs"] = -1;
            }
        }
        else{
            if(meterConfig["Burst-Size"]["MBS-type"]) {
                properties["mbsType"] = this.convertToCBS_MBSType(meterConfig["Burst-Size"]["MBS-type"]);
            }

            if(meterConfig["Burst-Size"]["MBS-type"] == "Kilobytes") {
                properties["mbsKiloBytes"] = meterConfig["Burst-Size"]["admin-MBS-kilobytes"];
            }
            else if(meterConfig["Burst-Size"]["MBS-type"] == "Bytes") {
                properties["mbsBytes"] = meterConfig["Burst-Size"]["admin-MBS-bytes"];
            }
            else {
                properties["mbs"] = meterConfig["Burst-Size"]["admin-MBS-kilobits"];
            }

        }

        return properties;
    }


    this.createQueue = function(neId, intentConfig, index) {
        var fullClassName = "sasqos.AccessIngressQueue";
        var policyFdn = "sasAccessIngress";
        var objectFullName = "sasAccessIngress:" + intentConfig["sap-ingress-id"] + ":acq-" + intentConfig["queue"]["queue-id"];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        var queueConfig = intentConfig["queue"]["queue"][index];
        var properties = {};

        properties["id"] = queueConfig["queue-id"];

        if(queueConfig["name"]) {
            properties["displayedName"] = queueConfig["name"];
        }
        if(queueConfig["description"]) {
            properties["description"] = queueConfig["description"];
        }
        if(queueConfig["weight"]) {
            properties["weight"] = queueConfig["weight"];
        }
        if(queueConfig["priority"]) {
            properties["priority"] = queueConfig["priority"];
        }
        if(queueConfig["queue-management-policy"]) {
            properties["queuemgmtPolicyPointer"] = "sasQueueMgmtPolicy:" + queueConfig["queue-management-policy"];
        }
        if(queueConfig["slope-policy"]) {
            properties["slopePolicyPointer"] = "sasSlope:" + queueConfig["slope-policy"];
        }
        if(queueConfig["port-parent"]["port-parent"]) {
            properties["portParent"] = queueConfig["port-parent"]["port-parent"];
        }
        if(queueConfig["port-parent"]["weight"]) {
            properties["portParentWeight"] = "weight" + queueConfig["port-parent"]["weight"];
        }
        if(queueConfig["port-parent"]["Cir-level"]) {
            properties["portParentCirLevel"] = "level" + queueConfig["port-parent"]["Cir-level"];
        }


        if(queueConfig["rate"]["cir-max"]) {
            properties["cir"] = -1;
        }
        if(queueConfig["rate"]["cir-max"] == false && queueConfig["rate"]["Cir"]) {
            properties["cir"] = queueConfig["rate"]["Cir"];
        }
        if(queueConfig["rate"]["pir-max"]) {
            properties["pir"] = -1;
        }
        if(queueConfig["rate"]["pir-max"] == false && queueConfig["rate"]["Pir"]) {
            properties["pir"] = queueConfig["rate"]["Pir"];
        }
        if(queueConfig["adaptation-rule"]["cir"]) {
            properties["cirAdaptation"] = queueConfig["adaptation-rule"]["cir"];
        }
        if(queueConfig["adaptation-rule"]["pir"]) {
            properties["pirAdaptation"] = queueConfig["adaptation-rule"]["pir"];
        }


        if(queueConfig["Burst-Size"]["default-cbs"] == "false" && queueConfig["Burst-Size"]["admin-CBS"]) {
            properties["committedBurstSize"] = queueConfig["Burst-Size"]["admin-CBS"];
        }
        if(queueConfig["Burst-Size"]["default-cbs"]) {
            properties["committedBurstSize"] = 10;
        }

        if(queueConfig["Burst-Size"]["default-mbs"] == "false" && queueConfig["Burst-Size"]["admin-MBS"]) {
            properties["maximumBurstSize"] = queueConfig["Burst-Size"]["admin-MBS"];
        }
        if(queueConfig["Burst-Size"]["default-mbs"]) {
            properties["maximumBurstSize"] = 60;
        }



        return properties;
    }

    this.createFc = function(neId, intentConfig, index) {

        var fullClassName = "sasqos.AccessIngressForwardingClass";
        var policyFdn = "sasAccessIngress";
        var objectFullName = "sasAccessIngress:" + intentConfig["sap-ingress-id"] + ":forwarding-class-" + intentConfig["fc"]["fc-name"];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        var fcConfig = intentConfig["fc"]["fc"][index];
        var properties = {};

        properties["forwardingClass"] = fcConfig["fc-name"];

        if(fcConfig["meter-id"]) {
            properties["meterId"] = fcConfig["meter-id"];
        }
        if(fcConfig["multicast-queue-id"]) {
            properties["multicastQueueId"] = fcConfig["multicast-queue-id"];
        }
        if(fcConfig["broadcast-id"]) {
            properties["broadcastMeterId"] = fcConfig["broadcast-id"];
        }
        if(fcConfig["unknown-meter-id"]) {
            properties["unknownMeterId"] = fcConfig["unknown-meter-id"];
        }
        if(fcConfig["multicast-id"]) {
            properties["multicastMeterId"] = fcConfig["multicast-id"];
        }
        if(fcConfig["queue-id"]) {
            properties["queueId"] = fcConfig["queue-id"];
        }
        if(fcConfig["use-Dei"]) {
            properties["useDei"] = fcConfig["use-Dei"];
        }

        return properties;
    }

    this.createIpCriteria = function(neId, intentConfig, index) {

        var fullClassName = "sasqos.IpMatch";
        var policyFdn = "sasAccessIngress";
        var objectFullName = "sasAccessIngress:" + intentConfig["sap-ingress-id"] + ":ip-match-" + intentConfig["ip-criteria"]["entry"][index]["entry-id"];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        var ipCriteriaConfig = intentConfig["ip-criteria"]["entry"][index];
        var properties = {};

        properties["id"] = ipCriteriaConfig["entry-id"];

        if(ipCriteriaConfig["name"]) {
            properties["displayedName"] = ipCriteriaConfig["name"];
        }
        if(ipCriteriaConfig["description"]) {
            properties["description"] = ipCriteriaConfig["description"];
        }
        if(ipCriteriaConfig["match"]["protocol"] != "NONE") {
            properties["protocol"] = ipCriteriaConfig["match"]["protocol"];
        }
        else {
            properties["protocol"] = "ALL";
        }
        if(ipCriteriaConfig["match"]["src-ip"]["src"] && ipCriteriaConfig["match"]["src-ip"]["address"]) {
            properties["sourceIpAddress"] = ipCriteriaConfig["match"]["src-ip"]["address"];
        }
        if(ipCriteriaConfig["match"]["src-ip"]["src"] && ipCriteriaConfig["match"]["src-ip"]["mask"]) {
            properties["sourceIpAddressMask"] = "ipAddrMask" + ipCriteriaConfig["match"]["src-ip"]["mask"];
        }
        if(ipCriteriaConfig["match"]["dst-ip"]["dst"] && ipCriteriaConfig["match"]["dst-ip"]["address"]) {
            properties["destinationIpAddress"] = ipCriteriaConfig["match"]["dst-ip"]["address"];
        }
        if(ipCriteriaConfig["match"]["dst-ip"]["dst"] && ipCriteriaConfig["match"]["dst-ip"]["mask"]) {
            properties["destinationIpAddressMask"] = "ipAddrMask" + ipCriteriaConfig["match"]["dst-ip"]["mask"];
        }
        if(ipCriteriaConfig["match"]["src-port"]["src-port"] && ipCriteriaConfig["match"]["src-port"]["src-prt"]) {
            properties["sourceOperator"] = ipCriteriaConfig["match"]["src-port"]["src-prt"];
        }
        if(ipCriteriaConfig["match"]["src-port"]["port-src"] && ipCriteriaConfig["match"]["src-port"]["port-src"]) {
            properties["sourcePort1"] = ipCriteriaConfig["match"]["src-port"]["port-src"];
        }
        if(ipCriteriaConfig["match"]["dst-port"]["dst-port"] && ipCriteriaConfig["match"]["dst-port"]["dst-prt"]) {
            properties["destinationOperator"] = ipCriteriaConfig["match"]["dst-port"]["dst-prt"];
        }
        if(ipCriteriaConfig["match"]["dst-port"]["port-dst"] && ipCriteriaConfig["match"]["dst-port"]["port-dst"]) {
            properties["destinationPort1"] = ipCriteriaConfig["match"]["dst-port"]["port-dst"];
        }
        if(ipCriteriaConfig["match"]["dscp"]["dscp"] && ipCriteriaConfig["match"]["dscp"]["dscp-type"]) {
            properties["dscp"] = ipCriteriaConfig["match"]["dscp"]["dscp-type"];
        }
        if(ipCriteriaConfig["match"]["dscp"]["dscp"] && ipCriteriaConfig["match"]["dscp"]["dscp-value"]) {
            properties["dscpValue"] = ipCriteriaConfig["match"]["dscp"]["dscp-value"];
        }
        if(ipCriteriaConfig["match"]["dscp"]["dscp"] && ipCriteriaConfig["match"]["dscp"]["dscp-mask"]) {
            properties["dscpMask"] = ipCriteriaConfig["match"]["dscp"]["dscp-mask"];
        }
        if(ipCriteriaConfig["match"]["ip-precedence"]["ip-precedence"] && ipCriteriaConfig["match"]["ip-precedence"]["ip-precedence-value"]) {
            properties["ipPrecedence"] = "value_" + ipCriteriaConfig["match"]["ip-precedence"]["ip-precedence-value"];
        }
        if(ipCriteriaConfig["match"]["ip-precedence"]["ip-precedence"] && ipCriteriaConfig["match"]["ip-precedence"]["precedence-mask"]) {
            properties["ipPrecedenceMask"] = "value_" + ipCriteriaConfig["match"]["ip-precedence"]["precedence-mask"];
        }
        if(ipCriteriaConfig["action"]["fc"] == "default") {
            properties["forwardingClass"] = "";
        }
        else {
            properties["forwardingClass"] = ipCriteriaConfig["action"]["fc"];
        }

        return properties;

    }

    this.createIpv6Criteria = function(neId, intentConfig, index) {

        var fullClassName = "sasqos.Ipv6Match";
        var policyFdn = "sasAccessIngress";
        var objectFullName = "sasAccessIngress:" + intentConfig["sap-ingress-id"] + ":ipv6mat-" + intentConfig["ipv6-criteria"]["entry"][index]['entry-id'];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        var ipv6CriteriaConfig = intentConfig["ipv6-criteria"]["entry"][index];
        var properties = {};

        properties["id"] = ipv6CriteriaConfig["entry-id"];

        if(ipv6CriteriaConfig["name"]) {
            properties["displayedName"] = ipv6CriteriaConfig["name"];
        }
        if(ipv6CriteriaConfig["description"]) {
            properties["description"] = ipv6CriteriaConfig["description"];
        }
        if(ipv6CriteriaConfig["match"]["protocol"] != "NONE") {
            properties["protocol"] = ipv6CriteriaConfig["match"]["protocol"];
        }
        else {
            properties["protocol"] = "ALL";
        }
        if(ipv6CriteriaConfig["match"]["src-ip"]["src"] && ipv6CriteriaConfig["match"]["src-ip"]["address"]) {
            properties["sourceIpAddress"] = util.expandIPv6Address(ipv6CriteriaConfig["match"]["src-ip"]["address"]);
        }
        if(ipv6CriteriaConfig["match"]["src-ip"]["src"] && ipv6CriteriaConfig["match"]["src-ip"]["mask"]) {
            properties["sourceIpAddressMask"] = ipv6CriteriaConfig["match"]["src-ip"]["mask"];
        }
        if(ipv6CriteriaConfig["match"]["dst-ip"]["dst"] && ipv6CriteriaConfig["match"]["dst-ip"]["address"]) {
            properties["destinationIpAddress"] = util.expandIPv6Address(ipv6CriteriaConfig["match"]["dst-ip"]["address"]);
        }
        if(ipv6CriteriaConfig["match"]["dst-ip"]["dst"] && ipv6CriteriaConfig["match"]["dst-ip"]["mask"]) {
            properties["destinationIpAddressMask"] = ipv6CriteriaConfig["match"]["dst-ip"]["mask"];
        }
        if(ipv6CriteriaConfig["match"]["src-port"]["src-port"] && ipv6CriteriaConfig["match"]["src-port"]["src-prt"]) {
            properties["sourceOperator"] = ipv6CriteriaConfig["match"]["src-port"]["src-prt"];
        }
        if(ipv6CriteriaConfig["match"]["src-port"]["port-src"] && ipv6CriteriaConfig["match"]["src-port"]["port-src"]) {
            properties["sourcePort1"] = ipv6CriteriaConfig["match"]["src-port"]["port-src"];
        }
        if(ipv6CriteriaConfig["match"]["dst-port"]["dst-port"] && ipv6CriteriaConfig["match"]["dst-port"]["dst-prt"]) {
            properties["destinationOperator"] = ipv6CriteriaConfig["match"]["dst-port"]["dst-prt"];
        }
        if(ipv6CriteriaConfig["match"]["dst-port"]["port-dst"] && ipv6CriteriaConfig["match"]["dst-port"]["port-dst"]) {
            properties["destinationPort1"] = ipv6CriteriaConfig["match"]["dst-port"]["port-dst"];
        }
        if(ipv6CriteriaConfig["match"]["dscp"]["dscp"] && ipv6CriteriaConfig["match"]["dscp"]["dscp-type"]) {
            properties["dscp"] = ipv6CriteriaConfig["match"]["dscp"]["dscp-type"];
        }
        if(ipv6CriteriaConfig["match"]["dscp"]["dscp"] && ipv6CriteriaConfig["match"]["dscp"]["dscp-value"]) {
            properties["dscpValue"] = ipv6CriteriaConfig["match"]["dscp"]["dscp-value"];
        }
        if(ipv6CriteriaConfig["match"]["dscp"]["dscp"] && ipv6CriteriaConfig["match"]["dscp"]["dscp-mask"]) {
            properties["dscpMask"] = ipv6CriteriaConfig["match"]["dscp"]["dscp-mask"];
        }
        if(ipv6CriteriaConfig["match"]["ip-precedence"]["ip-precedence"] && ipv6CriteriaConfig["match"]["ip-precedence"]["ip-precedence-value"]) {
            properties["ipPrecedence"] = "value_" + ipv6CriteriaConfig["match"]["ip-precedence"]["ip-precedence-value"];
        }
        if(ipv6CriteriaConfig["match"]["ip-precedence"]["ip-precedence"] && ipv6CriteriaConfig["match"]["ip-precedence"]["precedence-mask"]) {
            properties["ipPrecedenceMask"] = "value_" + ipv6CriteriaConfig["match"]["ip-precedence"]["precedence-mask"];
        }
        if(ipv6CriteriaConfig["action"]["fc"] == "Default") {
            properties["forwardingClass"] = "";
        }
        else {
            properties["forwardingClass"] = ipv6CriteriaConfig["action"]["fc"];
        }

        return properties;

    }

    this.createMacCriteria = function(neId, intentConfig, index) {

        var fullClassName = "sasqos.MacMatch";
        var policyFdn = "sasAccessIngress";
        var objectFullName = "sasAccessIngress:" + intentConfig["sap-ingress-id"] + ":mac-match-" + intentConfig["mac-criteria"]["entry"][index]['entry-id'];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        var macConfig = intentConfig["mac-criteria"]["entry"][index];
        var properties = {};

        if(intentConfig["mac-match-criteria-type"] == "any") {

            properties["id"] = macConfig["entry-id"];
            if(macConfig["name"]) {
                properties["displayedName"] = macConfig["name"];
            }
            if(macConfig["description"]) {
                properties["description"] = macConfig["description"];
            }
            if(macConfig["match"]["dot1p"] && macConfig["match"]["dot1p-value"]) {
                properties["dot1pValue"] = this.convertToDot1pValue(macConfig["match"]["dot1p-value"]);
            }
            if(macConfig["match"]["dot1p"] && macConfig["match"]["dot1p-mask"]) {
                properties["dot1pMask"] = this.convertToDot1pMask(macConfig["match"]["dot1p-mask"]);
            }
            if(macConfig["match"]["inner-dot1p"] && macConfig["match"]["inner-dot1p-value"]) {
                properties["innerDot1pValue"] = this.convertToDot1pValue(macConfig["match"]["inner-dot1p-value"]);
            }
            if(macConfig["match"]["inner-dot1p"] && macConfig["match"]["inner-dot1p-mask"]) {
                properties["innerDot1pMask"] = this.convertToDot1pMask(macConfig["match"]["inner-dot1p-mask"]);
            }
            if(macConfig["match"]["outer-dot1p"] && macConfig["match"]["outer-dot1p-value"]) {
                properties["outerDot1pValue"] = this.convertToDot1pValue(macConfig["match"]["outer-dot1p-value"]);
            }
            if(macConfig["match"]["outer-dot1p"] && macConfig["match"]["outer-dot1p-mask"]) {
                properties["outerDot1pMask"] = this.convertToDot1pMask(macConfig["match"]["outer-dot1p-mask"]);
            }
            if(macConfig["match"]["e-type"] && macConfig["match"]["e-type-value"]) {
                properties["ethernetType"] = macConfig["match"]["e-type-value"];
            }
            if(macConfig["match"]["src"] && macConfig["match"]["src-mac"]) {
                properties["sourceMacAddress"] = macConfig["match"]["src-mac"];
            }
            if(macConfig["match"]["src"] && macConfig["match"]["src-mask"]) {
                properties["sourceMacAddressMask"] = macConfig["match"]["src-mask"];
            }
            if(macConfig["match"]["dst"] && macConfig["match"]["dst-mac"]) {
                properties["destinationMacAddress"] = macConfig["match"]["dst-mac"];
            }
            if(macConfig["match"]["dst"] && macConfig["match"]["dst-mask"]) {
                properties["destinationMacAddressMask"] = macConfig["match"]["dst-mask"];
            }
            if(macConfig["match"]["inner-tag"] && macConfig["match"]["inner-tag-value"]) {
                properties["innerTagValue"] = macConfig["match"]["inner-tag-value"];
            }
            if(macConfig["match"]["inner-tag"] && macConfig["match"]["inner-tag-vid-mask"]) {
                properties["innerTagMask"] = macConfig["match"]["inner-tag-vid-mask"];
            }
            if(macConfig["match"]["outer-tag"] && macConfig["match"]["outer-tag-value"]) {
                properties["outerTagValue"] = macConfig["match"]["outer-tag-value"];
            }
            if(macConfig["match"]["outer-tag"] && macConfig["match"]["outer-tag-vid-mask"]) {
                properties["outerTagMask"] = macConfig["match"]["outer-tag-vid-mask"];
            }
            if(macConfig["action"]["fc"] == "default") {
                properties["forwardingClass"] = "";
            }
            if(macConfig["action"]["fc"] != "default") {
                properties["forwardingClass"] = macConfig["action"]["fc"];
            }
            if(macConfig["action"]["profile"]) {
                properties["defaultFcProfile"] = this.convertToProfile(macConfig["action"]["profile"]);
            }

        }
        return properties;
    }

    this.createChildObjectPayload = function(fullClassName, properties, childProperties) {
        var childObjectPayLoad = {};
        childObjectPayLoad[fullClassName] = properties;
        if(childProperties != null || childProperties != undefined)
        {
            childObjectPayLoad[fullClassName]["children-Set"] = childProperties;
        }
        return childObjectPayLoad;
    }

    this.modifyRequest = function(neId, payload) {

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
           logger.error("Error result = {}",JSON.stringify(result));
           let errorMsg = result.msg;
           if(errorMsg.indexOf("object already exists") !== -1)
           {
               logger.info("Global policy Object already exists, Re-checking the Policy existence ");
               //util.delay(2000);
               let configInfo = payload.configInfo;
               let fullClassName;
               for (let key in configInfo) {
                 if (configInfo.hasOwnProperty(key)) {
                   fullClassName = key;
                   break;
                 }
               }
               let objectFullName = payload.objectFullName;
               objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
               logger.info("fullClassName = {}",fullClassName);
               logger.info("objectFullName = {}",objectFullName);
               if (!util.isObjectExists(fullClassName, objectFullName))
               {
                   throw new RuntimeException("Global Policy Object Not Found!!!");
               }
           }
           else
           {
               throw new RuntimeException(result.msg);
           }
        }
        if(modeChanged)
        {
            result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
            if (!result.success)
            {
               logger.error("Error result = {}",JSON.stringify(result));
               let errorMsg = result.msg;
               if(errorMsg.indexOf("object already exists") !== -1)
               {
                   logger.info("Global policy Object already exists, Re-checking the Policy existence ");
                   //util.delay(2000);
                   let configInfo = payload.configInfo;
                   let fullClassName;
                   for (let key in configInfo) {
                     if (configInfo.hasOwnProperty(key)) {
                       fullClassName = key;
                       break;
                     }
                   }
                   let objectFullName = payload.objectFullName;
                   objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
                   logger.info("fullClassName = {}",fullClassName);
                   logger.info("objectFullName = {}",objectFullName);
                   if (!util.isObjectExists(fullClassName, objectFullName))
                   {
                       throw new RuntimeException("Global Policy Object Not Found!!!");
                   }
               }
               else
               {
                   throw new RuntimeException(result.msg);
               }
            }
        }

        return result;
    }
    this.audit = function (input, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        isAudit = true;
        var lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        var intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];
        //intentConfig["sap-ingress-name"] = input.getTarget().split("#")[2];
        intentConfig["sap-ingress-id"] = parseInt(input.getTarget().split("#")[2]);
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        if (intentConfig)
        {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }
        return auditReport
    }
    this.auditAndCompare = function (neId, intentConfig, auditReport) {
        var sasPayload = this.createPolicyLevelPayLoad(neId, intentConfig);
        var result = this.auditRequest(neId, sasPayload);
        auditReport = util.reportMisaligned(neId, result, auditReport);
        return auditReport;
    }
    this.auditRequest = function (neId, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.convertToColorMode = function(value) {
        if(value == "color-blind") {
            return "colorBlind";
        }
        else if (value == "color-aware") {
            return "colorAware";
        }
    }

    this.convertToRateMode = function(value) {
        if(value == "srTCM") {
            return "srtcm";
        }
        else if(value == "trTCM(RFC-2698)") {
            return "trtcm1";
        }
        else {
            return "trtcm2";
        }
    }

    this.convertToCBS_MBSType = function(value) {
        if(value == "Kilobits") {
            return 'kbits';
        }
        else if (value == "Bytes") {
            return 'bytes';
        }
        else {
            return 'kbytes';
        }
    }

    this.convertToProfile = function(value) {
        if(value == "None") {
            return "none";
        }
        else if(value == "DEI") {
            return "dei";
        }
        else {
            return value;
        }
    }

    this.convertToTableClassificationCriteria = function(value) {
        if(value == "use-dscp") {
            return "dscp";
        }
        else if(value == "use-dotip") {
            return "dot1p";
        }
        else if(value == "both-dscp-dotip") {
            return "both";
        }
        else {
            return "none";
        }
    }

    this.convertToIpMacMatchClassificationType = function(value) {
        if(value == "ip-first") {
            return "ip_first";
        }
        else if(value == "mac-first") {
            return "mac_first";
        }
        else {
            return "none";
        }
    }

    this.convertToDot1pValue = function(value) {
        if(value == "Not Set (-1)") {
            return "default";
        }
        else {
            return "priority_" + value;
        }
    }

    this.convertToDot1pMask = function(value) {
        return "priority_" + value;
    }

    this.convertToProtocol = function (value) {
        if(value == "NONE") {
            return "ALL";
        }
        else if(value == "icmp") {
            return "ICMP";
        }
        else if(value == "igmp") {
            return "IGMP";
        }
        else if(value == "ip") {
            return "IP";
        }
        else if(value == "tcp") {
            return "TCP";
        }
        else if(value == "egp") {
            return "EGP";
        }
        else if(value == "igp") {
            return "IGP";
        }
        else if(value == "udp") {
            return "UDP";
        }
        else if(value == "rdp") {
            return "RDP";
        }
        else if(value == "ipv6") {
            return "IPV6";
        }
        else if(value == "ipv6-route") {
            return "IPV6-ROUTE";
        }
        else if(value == "ipv6-frag") {
            return "";
        }
    }

    this.updateAuditResult = function (aInAuditResult) {
        var resultResp = JSON.parse(aInAuditResult.response);
        var misalignedAttributes = resultResp.misalignedAttributes;
        if (Object.keys(auditResult).length === 0)
        {
            auditResult = resultResp;
        }
        else
        {
            if (misalignedAttributes.length > 0)
            {
                auditResult.misalignedAttributes = auditResult.misalignedAttributes.concat(misalignedAttributes);
                auditResult.aligned = false;
            }
        }
    }

    this.constructSearchString = function(className, objectFullName) {
        var expectedJson = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        return expectedJson;
    }

    this.updateAccessIngressPolicyId = function (target, objectFullName, PolicyId)
    {
        var fullClassName = "sasqos.AccessIngress";
        var Fdn = "sasAccessIngress";
        var properties = {};
        properties["id"] = PolicyId;

        var payload  = {};
        var configInfo = {};
        configInfo["containedClassProperties"] = properties;
        configInfo["objectClassName"] = fullClassName;
        payload["distinguishedName"] = Fdn;
        payload["objectFullName"] = objectFullName;
        payload["configInfo"] = configInfo;

        var result = this.modifyRequest(target, payload);
        return result;
    }

    this.sendRequestAndDistribute = function (neId, payload, objectFullName, intentConfig) {
        this.modifyRequest(neId, payload);
        if (!isEdit)
        {
            var distributePayload = util.distribute(neId, objectFullName, false);
            var distributeResult = nfmpFwk.post("/rest/api/v3/request", distributePayload);
            if (!distributeResult.success)
            {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }
            util.delay(2000);

            distributePayload = util.distribute(neId, objectFullName, true);
            distributeResult = nfmpFwk.post("/rest/api/v3/request", distributePayload);
            if (!distributeResult.success)
            {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }
        }
    }
}
