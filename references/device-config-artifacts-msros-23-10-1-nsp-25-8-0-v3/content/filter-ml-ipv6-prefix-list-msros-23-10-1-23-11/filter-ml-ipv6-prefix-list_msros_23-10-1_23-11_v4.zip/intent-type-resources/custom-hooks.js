load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});

function CustomHooks() {
    /**
   * PreAudit Hook
   */

  const preAudit = (inputObj) => {
     /**
     * Write your custom preAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer, 
     *          uniqueIdentifier, deviceYangModuleName
     *           
     */
    
    logger.info("[CUSTOM-HOOKS] preAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));


    let target = inputObj.target;
    let intentConfig = inputObj.intentConfig;
    var intentDeviationObj = new IntentDeviceDeviation();
    var neId = parseTarget.getNeIdFromTarget(target);
    intentConfig = intentDeviationObj.removeIntentConfig(intentConfig, neId);
    logger.info("preAudit intent config after removing deviation attributes: " + JSON.stringify(intentConfig));

    if (intentConfig && intentConfig["prefix"]) {
      var ipv6AddressUtil = new IPv6AddressUtil();
      intentConfig = ipv6AddressUtil.preAuditIpv6Modify(intentConfig);
    }
    if (intentConfig && intentConfig["prefix-exclude"]) {
      var ipv6AddressUtil = new IPv6AddressUtil();
        intentConfig = ipv6AddressUtil.preAuditIpv6ModifyExclude(intentConfig);
    }

  };

  /**
   * PostAudit Hook
   */
  const postAudit = (inputObj) => {
    /**
     * Write your custom postAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName, auditReport
     *
     */

    logger.info("[CUSTOM-HOOKS] postAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));


  };

  /**
   * PreSync Hook
   */
  const preSync = (inputObj) => {
    /**
     * Write your custom preSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] preSync call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
    let target = inputObj.target;
    let intentTypeName = inputObj.intentTypeName;
    let intentContainer = inputObj.intentContainer;


    let config = JSON.parse(inputObj.config);

    logger.info("preSync call for Ipv6 intent deviation implementation");
    var intentDeviationObj = new IntentDeviceDeviation();
    var neId = parseTarget.getNeIdFromTarget(target)
    if (!Array.isArray(config)) {
        config = [config];
    }
    let preSyncConf = [];
    for (var index in config) {
        let configObj = config[index][intentTypeName + ":" + intentTypeName][intentContainer];
        let deviatedObj = intentDeviationObj.removeIntentConfig(configObj, neId);
      
        let finalConfigObj = {};
        let intentKey = intentTypeName + ":" + intentTypeName
        finalConfigObj[intentKey] = {};
        finalConfigObj[intentKey][intentContainer] = deviatedObj;
        preSyncConf.push(finalConfigObj);
    }
    inputObj.config = JSON.stringify(preSyncConf);
    logger.info("intent config after removing deviation attributes: ");
    return JSON.stringify(inputObj);

  };

  /**
   * PostSync Hook
   */
  const postSync = (inputObj) => {
    /**
     * Write your custom postSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] postSync call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

  };

  /**
   *
   * PostDiscovery Hook
   */
  const postDiscovery = (inputObj) => {
    /**
     * Write your custom postDiscovery logic here
     * inputObj by default contains the following keys:
     *        deviceConfig, intentContainer, neId,
     *        targetDataStruct, templateName, deviceYangModuleName
     */

    logger.info("[CUSTOM-HOOKS] postDiscovery call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

  }

  this.preAudit = preAudit;
  this.postAudit = postAudit;
  this.preSync = preSync;
  this.postSync = postSync;
  this.postDiscovery = postDiscovery;

}