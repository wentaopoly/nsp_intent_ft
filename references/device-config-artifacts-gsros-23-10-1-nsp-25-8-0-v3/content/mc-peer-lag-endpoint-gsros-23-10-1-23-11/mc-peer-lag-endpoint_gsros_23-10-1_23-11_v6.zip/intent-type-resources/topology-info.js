function TopologyInfo() {

    var savedTopologyA = undefined;
    var savedTopologyB = undefined;

    this.setSavedTopologyA = function (svta) {
        this.savedTopologyA = svta;
    }

    this.setSavedTopologyB = function (svtb) {
        this.savedTopologyB = svtb;
    }

    this.getSavedTopologyA = function () {
        if (this.savedTopologyA) {
            return this.savedTopologyA;
        }
        return topologyFactory.createServiceTopology();
    }

    this.getSavedTopologyB = function () {
        if (this.savedTopologyB) {
            return this.savedTopologyB;
        }
        return topologyFactory.createServiceTopology();
    }

}
