var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});


function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);

        let searchPayLoad = this.constructSearchString(neId);
        let searchResponse = nfmpFwk.post("search", searchPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find Sync-If-Timing  on NE " + neId);
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse[0];
    }
    this.constructSearchString = function (neId) {
        let fullName = "fullName = 'network:" + neId + ":shelf-1:sync'";
        if (neId && String(neId).indexOf(':') !== -1) {
            fullName = util.modifyNeIdForIpV6(fullName, neId);
        }
        let jsonPayLoad = {
            "filter": {
                "filterExpression": fullName
            },
            "fullClassName": "sonet.SiteSync"
        };
        return jsonPayLoad;
    }
    this.extractDeviceConfig = function (defaultTargetData, fullDeviceConfig, initialPropertyName) {
        let timingConfig;

        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        logger.info("*****parsedDefaultTargetData = \n{}", JSON.stringify(parsedDefaultTargetData));
        timingConfig = fullDeviceConfig['properties'];

        let deviceConfig = {
            "timingConfig": timingConfig,
        };

        logger.info("*****deviceConfig = \n{}", JSON.stringify(deviceConfig));
        if (null !== timingConfig)
        {
            this.extractTimingProperties(parsedDefaultTargetData, deviceConfig);
        }

        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData))
        return parsedDefaultTargetData;
    }
    this.extractTimingProperties = function (defaultTargetData, deviceConfig) {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object')
            {
                let mappings = modelDeviceMapping.getTimingMapping();

                if(deviceConfig["timingConfig"]["waitToRestore"] == "0") {
                  delete mappings["central-frequency-clock.wait-to-restore"];
                  delete defaultTargetData["central-frequency-clock"]["wait-to-restore"];
                }
                this.traverseAndUpdateConfig(targetKey, targetObj, mappings, deviceConfig);
            }
        }
        return defaultTargetData;
    }
    this.traverseAndUpdateConfig = function (objKey, obj, mappings, deviceConfig) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;

            if (value != null && typeof value === 'object')
            {
                this.traverseAndUpdateConfig(mappedKey, value, mappings, deviceConfig);
            }
            else
            {
                // call for each key with string value
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, deviceConfig);
            }

        }
        return obj;
    }
    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, deviceConfig) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = deviceConfig.timingConfig[nfmpKey];
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);
    }
    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue !== null)
        {
            switch (mappedKey)
            {
                case "central-frequency-clock.ql-minimum":
                case "central-frequency-clock.ref1.ql-override":
                case "central-frequency-clock.ref2.ql-override":
                case "central-frequency-clock.bits.ql-override":
                case "central-frequency-clock.bits.output.ql-minimum":
                case "central-frequency-clock.ptp.ql-override":
                case "central-frequency-clock.synce.ql-override":
                case "central-frequency-clock.gnss.ql-override":
                    deviceValue = util.qualityLevelEnumBrownField(deviceValue);
                    break;
                case "central-frequency-clock.ql-selection":
                    deviceValue = util.convertQualityLevelBrownField(deviceValue);
                    break;
                case "central-frequency-clock.ref-order.first":
                case "central-frequency-clock.ref-order.second":
                case "central-frequency-clock.ref-order.third":
                case "central-frequency-clock.ref-order.fourth":
                case "central-frequency-clock.ref-order.fifth":
                case "central-frequency-clock.ref-order.sixth":
                    deviceValue = util.refOrderEnumBrownField(deviceValue);
                    break;
                case "central-frequency-clock.ref1.admin-state":
                case "central-frequency-clock.ref2.admin-state":
                case "central-frequency-clock.bits.input.admin-state":
                case "central-frequency-clock.bits.output.admin-state":
                case "central-frequency-clock.ptp.admin-state":
                case "central-frequency-clock.synce.admin-state":
                case "central-frequency-clock.gnss.admin-state":
                    deviceValue = util.convertAdminStateBrownField(deviceValue);
                    break;
                case "central-frequency-clock.bits.interface-type":
                    deviceValue = util.convertInterfaceTypeBrownField(deviceValue);
                    break;
                case "central-frequency-clock.bits.output.line-length":
                    deviceValue = util.convertLineLengthBrownField(deviceValue);
                    break;
                case "central-frequency-clock.bits.output.source":
                    deviceValue = util.convertOutputSourceBrownField(deviceValue);
                    break;
                case "central-frequency-clock.ref1.source-port":
                case "central-frequency-clock.ref2.source-port":
                    deviceValue = util.convertRefSourceBrownField(deviceValue);
                    break;

            }
            return deviceValue;
        }
    }
}
