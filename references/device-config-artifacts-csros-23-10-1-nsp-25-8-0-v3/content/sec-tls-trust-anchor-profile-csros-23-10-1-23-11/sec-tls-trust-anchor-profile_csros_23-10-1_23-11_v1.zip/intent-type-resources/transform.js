function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        if(!isAudit){
            if (payload["configInfo"]["sitesec.TlsTrustAnchorProfile"]["children-Set"] && payload["configInfo"]["sitesec.TlsTrustAnchorProfile"]["children-Set"]["sitesec.TlsTrustAnchorEntry"]) {
                for (var index in payload["configInfo"]["sitesec.TlsTrustAnchorProfile"]["children-Set"]["sitesec.TlsTrustAnchorEntry"]) {
                    var tlsTrustAnchorEntryConfig = payload["configInfo"]["sitesec.TlsTrustAnchorProfile"]["children-Set"]["sitesec.TlsTrustAnchorEntry"][index];

                    if (tlsTrustAnchorEntryConfig["trustAnchorCAProfilePointer"]) {
                        tlsTrustAnchorEntryConfig["trustAnchorCAProfileName"] = tlsTrustAnchorEntryConfig["trustAnchorCAProfilePointer"].replace("caProfile:capf-", "");
                    }

                    payload["configInfo"]["sitesec.TlsTrustAnchorProfile"]["children-Set"]["sitesec.TlsTrustAnchorEntry"][index] = tlsTrustAnchorEntryConfig;
                }
            }
        }

        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        if(xpath == "sitesec-TlsTrustAnchorEntry.trustAnchorCAProfilePointer")
        {
            targetValue = 'caProfile:capf-'+ targetValue;
        }

        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
        if(xpath == "sitesec-TlsTrustAnchorEntry.trustAnchorCAProfilePointer")
        {
            targetValue = targetValue.replace('caProfile:capf-', '');
        }
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
}