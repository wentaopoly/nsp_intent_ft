load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {
  this.setErrorResult = function (result) {
    result.setSuccess(false);
    result.setErrorCode(100);
    result.setErrorDetail("failed To set Topology.");
    return result
  }

  this.setSuccessResult = function (result,savedTopology) {
    result.setSuccess(true);
    if (savedTopology !== undefined){
      result.setTopology(savedTopology);
    }
    return result;
  }

  this.xml2object = function (xmlElement) {
    var lXml = Java.type("org.json.XML");
    var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
    var serializer = lsImpl.createLSSerializer();
    serializer.getDomConfig().setParameter("xml-declaration", false);
    var str = serializer.writeToString(xmlElement);
    var json = lXml.toJSONObject(str).toString();
    return JSON.parse(json);
  }

    this.reportMisaligned = function (target, result, auditReport) {
        var report = JSON.parse(result.response);
        if (!report.aligned)
        {
            for (var i = 0; i < report.misalignedAttributes.length; i++)
            {
                var attributeData = report.misalignedAttributes[i];
                if (attributeData.expected == "present")
                {
                    //misaligned object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else if (attributeData.expected == "not present")
                {
                    //undesired object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    var attributeFields = (attributeData.name).split("|");
                    if(attributeFields.length == 3 && attributeFields[2] == "type")
                    {
                        attributeData.expected = this.transformIntentFilterType(attributeData.expected);
                        attributeData.actual = this.transformIntentFilterType(attributeData.actual);
                    }
                    var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                    auditReport.addMisAlignedAttribute(misalignedAttribute);
                }

            }
        }
        return auditReport
    }

    this.getIfObjectExists = function (className, objectFullName) {

    let nfmpFwk = new NfmpFwk();
    var expectedJson = {
      "fullClassName": className,
      "filter": {
        "equal": {
          "name": "objectFullName",
          "value": objectFullName
        }
      },
      "resultFilter": {
        "children": "",
        "attribute": [
          "policyName",
          "id"
        ]
      }
    };
    var ret = false;
    var resultFetch = nfmpFwk.post("/v3/search", expectedJson);
    logger.info(LOG_PREFIX + "SAP Ingress Policy search results : " + JSON.stringify(resultFetch));
    var finalResponse = JSON.parse(resultFetch.response);
    if (JSON.stringify(finalResponse) === JSON.stringify({})) {
      logger.info(LOG_PREFIX + "Search results is empty: " + JSON.stringify(finalResponse));
      finalResponse = null;
    } else if (!Array.isArray(finalResponse)) {
      finalResponse = [finalResponse["aingr.Policy"]];
      logger.info(LOG_PREFIX + "Search results: " + JSON.stringify(finalResponse));
    }
    return finalResponse;
  }

  this.editPayload = function (fdn, properties, childProperties, fullClassName, objectFullName) {
    var payload = {};
    var configInfo = {};
    configInfo[fullClassName] = properties;
    configInfo[fullClassName]["children-Set"] = childProperties;
    payload["distinguishedName"] = fdn;
    payload["objectFullName"] = objectFullName,
        payload["clearOnDeployFailure"] = true;
    payload["configInfo"] = configInfo;
    return payload;
  }
  this.transformNfmpProtocol = function (intentFrameTypeValue) {
    var nfmpProtocolValue = "";
    switch (intentFrameTypeValue) {
      case "ethernet-ii":
        nfmpProtocolValue = "ethernetII";
        break;
      default:
        nfmpProtocolValue = undefined;
    }
    return nfmpProtocolValue;
  }
  this.transformBrownfieldProtocol = function (intentFrameTypeValue) {
    var nfmpProtocolValue = "";
    switch (intentFrameTypeValue) {
      case "ethernetII":
        nfmpProtocolValue = "ethernet-ii";
        break;
      default:
        nfmpProtocolValue = undefined;
    }
    return nfmpProtocolValue;
  }
  this.nfmpDot1p= function (input) {
    if (input === undefined) {
      return undefined;
    }
    if (!input.toString().startsWith("priority_")) {
      input = "priority_" + input;
    }
    return input;
  };
  this.brownFieldNfmpdot1p = function (input) {
    if (input !== undefined && input.startsWith("priority_")) {
      var numericValue = parseInt(input.replace("priority_", ""));
      return numericValue;
    }
    return input;
  }
  this.brownFieldNfmpValidMacAddress = function (macAddress) {
    if (macAddress !== undefined) {
      var formattedMacAddress = macAddress.replace(/-/g, ':').toLowerCase();
      return formattedMacAddress;
    }
    return macAddress;
  }
  this.nfmpValidMacAddress = function (macAddress) {
    if (macAddress !== undefined) {
      var formattedMacAddress = macAddress.replace(/:/g, '-').toUpperCase();
      return formattedMacAddress;
    }
    return macAddress;
  }
  this.nfmpPolicerAllocation= function (policerAllocation) {
    var nfmppolicerAllocationValue = "";
    switch (policerAllocation) {
      case "none":
        nfmppolicerAllocationValue = "none";
        break;
      case "per-fc":
        nfmppolicerAllocationValue = "perFc";
        break;
      case "per-2-fc":
        nfmppolicerAllocationValue = "per2fc";
        break;
      case "per-4-fc":
        nfmppolicerAllocationValue = "per4fc";
        break;
      case "per-2-fc-unicast-multipoint":
        nfmppolicerAllocationValue = "per2fcunicastmultipoint";
        break;
      case "per-2-fc-unicast-multicast":
        nfmppolicerAllocationValue = "per2fcunicastmulticast";
        break;
      case "per-4-fc-unicast-multipoint":
        nfmppolicerAllocationValue = "per4fcunicastmultipoint";
        break;
      case "per-4-fc-unicast-multicast":
        nfmppolicerAllocationValue = "per4fcunicastmulticast";
        break;
      case "per-fc-unicast-multipoint":
        nfmppolicerAllocationValue = "perFcUniMultipoint";
        break;
      case "per-fc-unicast-multicast":
        nfmppolicerAllocationValue = "perFcUniMulticast";
        break;
      case "per-fc-unicast-broadcast-unknown-multicast":
        nfmppolicerAllocationValue = "perFcUniBroadUnknownMulticast";
        break;
      default:
        nfmppolicerAllocationValue = undefined;
    }
    return nfmppolicerAllocationValue;
  }

  this.nfmpPolicerAllocationBf= function (policerAllocation) {
    var nfmppolicerAllocationValue = "";
    switch (policerAllocation) {
      case "none":
        nfmppolicerAllocationValue = "none";
        break;
      case "perFc":
        nfmppolicerAllocationValue = "per-fc";
        break;
      case "per2fc":
        nfmppolicerAllocationValue = "per-2-fc";
        break;
      case "per4fc":
        nfmppolicerAllocationValue = "per-4-fc";
        break;
      case "per2fcunicastmultipoint":
        nfmppolicerAllocationValue = "per-2-fc-unicast-multipoint";
        break;
      case "per2fcunicastmulticast":
        nfmppolicerAllocationValue = "per-2-fc-unicast-multicast";
        break;
      case "per4fcunicastmultipoint":
        nfmppolicerAllocationValue = "per-4-fc-unicast-multipoint";
        break;
      case "per4fcunicastmulticast":
        nfmppolicerAllocationValue = "per-4-fc-unicast-multicast";
        break;
      case "perFcUniMultipoint":
        nfmppolicerAllocationValue = "per-fc-unicast-multipoint";
        break;
      case "perFcUniMulticast":
        nfmppolicerAllocationValue = "per-fc-unicast-multicast";
        break;
      case "perFcUniBroadUnknownMulticast":
        nfmppolicerAllocationValue = "per-fc-unicast-broadcast-unknown-multicast";
        break;
      default:
        nfmppolicerAllocationValue = undefined;
    }
    return nfmppolicerAllocationValue;
  }

  this.transformPolicerStatModeBf = function (policerStat) {
    switch (policerStat) {
      case "offeredProfileWithDiscards":
        return "offered-profile-with-discards";
      default:
        return "no-stats"
    }
  }
  this.getSapIngressPolicyID= function(target){
    var uniqueIdentifier = target.split("#")[3];
    return uniqueIdentifier;

  }
    this.expandIPv6Address =  function (address)
    {
        var ipv6AddressUtil = new IPv6AddressUtil();
        return ipv6AddressUtil.expandIPv6AddressForClassic(address);
    }

    this.MdIpv6ValidAddresssMaskSupport = function(input) {
        if (input === undefined) {
            return undefined;
        }
        if (input.endsWith(':') || input.endsWith('::0')) {
            input += ":";
        }
        let hex = removeLeadingTrailingZeros(input)
        if(hex.indexOf('::')!==-1){
            hex=hex.replace(/(::)0+/g, '$1').replace(/:::/g, "::")
            return hex;
        }
        const hextets = hex.split(':').filter(part => part !== ''); // Remove empty parts
        let maxZeroLength = 0;
        let longestZeroIndex = -1;
        let currentZeroLength = 0;
        for (let i = 0; i < hextets.length; i++) {
            if (hextets[i] === '0') {
                currentZeroLength++;
                if (currentZeroLength > maxZeroLength) {
                    maxZeroLength = currentZeroLength;
                    longestZeroIndex = i - maxZeroLength + 1;
                }
            } else {
                currentZeroLength = 0;
            }
        }
        if (maxZeroLength > 1) {
            hextets.splice(longestZeroIndex, maxZeroLength, '::');
        }
        if (maxZeroLength === 1) {
            const zeroIndex = hextets.indexOf('0');
            const zeroCount = hextets.filter(part => part === '0').length;
            if (zeroIndex !== -1 && zeroCount === 1 && hextets.length !== 8) {
                hextets.splice(zeroIndex, 1, '::');
            }
        }

        let result = hextets.join(':').replace(/::+/g, '::');
        return result;
    }

    function removeLeadingTrailingZeros(input) {
        const parts = input.split(':');
        for (let i = 0; i < parts.length; i++) {
            if(parts[i] == ''){
                continue
            }else{
                parts[i] = removeLeadingZeros(parts[i]);
            }

        }
        return parts.join(':');
    }

    function removeLeadingZeros(part) {
        let result = '';
        let nonZeroEncountered = false;
        for (let i = 0; i < part.length; i++) {
            if (part[i] !== '0') {
                nonZeroEncountered = true;
            }
            if (nonZeroEncountered) {
                result += part[i];
            }
        }
        return result || '0';
    }


    this.extractIPAddress=function(inputString) {
        var firstColonIndex = inputString.indexOf(":");
        var secondColonIndex = inputString.indexOf(":", firstColonIndex + 1);
        if (firstColonIndex !== -1 && secondColonIndex !== -1) {
            return inputString.substring(firstColonIndex + 1, secondColonIndex);
        } else {
            return undefined;
        }
    }

    this.getIxrType= function (target) {
        var deviceInfos = mds.getAllInfoFromDevices(target);
        if (null == deviceInfos || deviceInfos.size() === 0) {
            throw new RuntimeException("Device not found :" + target);
        }
        var deviceInfo = deviceInfos.get(0);
        var deviceType = deviceInfo.getFamilyTypeRelease();
        if (deviceType == null) {
            throw new RuntimeException("Device Family type and release not found for device: " + target);
        }
        var type= deviceType.split(':');
        log.info(null, "Device type:" + type);
        var deviceType;
        deviceType = {
            type: type[2]
        };
        return deviceType;
    };
    this.gfNfmpIpAddressMask= function (input) {
        if (input === undefined) {
            return undefined;
        }
        if (!input.toString().startsWith("ipAddrMask")) {
            input = "ipAddrMask" + input;
        }
        return input;
    };
    this.distribute = function (neId, objectFullName, isLocalEdit) {
        var payload = {};
        var policyDefination = "policy.PolicyDefinition.distributeV2";
        if (isLocalEdit)
        {
            policyDefination = "policy.PolicyDefinition.setDistributionModeToLocalEditOnly";
        }
        payload[policyDefination] = {};
        payload[policyDefination]["clearOnDeployFailure"] = true;
        payload[policyDefination]["deployer"] = "immediate";
        payload[policyDefination]["instanceFullName"] = objectFullName;
        payload[policyDefination]["siteIds"] = {};
        payload[policyDefination]["siteIds"]["string"] = neId;
        return payload;
    }
    this.isObjectExists = function (className, objectFullName) {
        let nfmpFwk = new NfmpFwk();
        var ret = false;
        var searchObjectJson = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);

        logger.info(LOG_PREFIX + "isObjectExists data = {}", JSON.stringify(resultFetch));
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(LOG_PREFIX + "Final response of search = {}", JSON.stringify(finalResponse));
        if (Object.keys(finalResponse).length !== 0 && finalResponse.constructor === Object)
        {
            ret = true;
        }
        logger.info(LOG_PREFIX + "isObjectExists = {} ", ret);
        return ret;
    }
    this.delay = function (milliseconds) {
        var date = new Date();
        date.setMilliseconds(date.getMilliseconds() + milliseconds);
        while (new Date() < date)
        {
        }
    }
    this.transformBFCriteriaType = function (Value) {
        var nfmpProtocolValue = "";
        switch (Value) {
            case "normal":
                nfmpProtocolValue = "normal";
                break;
            case "vxlanvni":
                nfmpProtocolValue = "vxlan-vni";
                break;
            case "vid":
                nfmpProtocolValue = "vid";
                break;
            case "taggedEntries":
                nfmpProtocolValue = "tagged-entries";
                break;
            default:
                nfmpProtocolValue = undefined;
        }
        return nfmpProtocolValue;
    }

    this.transformGFCriteriaType = function (Value) {
        var nfmpProtocolValue = "";
        switch (Value) {
            case "normal":
                nfmpProtocolValue = "normal";
                break;
            case "vxlan-vni":
                nfmpProtocolValue = "vxlanvni";
                break;
            case "vid":
                nfmpProtocolValue = "vid";
                break;
            case "tagged-entries":
                nfmpProtocolValue = "taggedEntries";
                break;
            default:
                nfmpProtocolValue = undefined;
        }
        return nfmpProtocolValue;
    }

    this.modifyNeIdForIpV6 = function (objectFullName, neId) {
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }

    function ipv6ToMappedIpv4WithSuffix(address){
        // Preserve CIDR suffix if present
        let cidrSuffix = '';
        if (address.indexOf('/') !== -1) {
            var splitParts = address.split('/');
            address = splitParts[0];
            cidrSuffix = '/' + splitParts[1];
        }
        address = ipv6ToMappedIpv4(address);
        return address+cidrSuffix;
    }

    function ipv6ToMappedIpv4(ipv6)
    {
        // Extract the hex part after "::ffff:"
        let hexPart = ipv6.replace("::ffff:", "");
        hexPart = hexPart.replace("::FFFF:", "");

        // Split the remaining part into two 16-bit sections
        const parts = hexPart.split(":");
        if (parts.length !== 2) {
            return ipv6;
        }

        // Convert each 16-bit hex value into two 8-bit decimal values
        const firstTwoOctets = parseInt(parts[0], 16); // Convert first 16 bits
        const lastTwoOctets = parseInt(parts[1], 16);  // Convert last 16 bits

        // Extract individual octets
        const octet1 = (firstTwoOctets >> 8) & 0xFF;
        const octet2 = firstTwoOctets & 0xFF;
        const octet3 = (lastTwoOctets >> 8) & 0xFF;
        const octet4 = lastTwoOctets & 0xFF;

        // Construct the final "::ffff:<IPv4>" format
        return "::ffff:" + octet1 + "." + octet2 + "." + octet3 + "." + octet4;
    }

    this.expandIPv6ForMd = function(address) {
        var fullAddress = "";
        var validGroupCount = 8;

        var ipv4 = "";
        var extractIpv4 = /([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})/;
        var validateIpv4 = /((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})/;
        // look for embedded ipv4
        if (validateIpv4.test(address)) {
            var groups = address.match(extractIpv4);
            for (var i = 1; i < groups.length; i++) {
                ipv4 += ("0" + (parseInt(groups[i], 10).toString(16))).slice(-2) + (i == 2 ? ":" : "");
            }
            if(!address.startsWith("::ffff") && !address.startsWith("::FFFF"))
			{
				address = address.replace(extractIpv4, ipv4);
			}
        }
        else
        {
            if(address.startsWith("::ffff") || address.startsWith("::FFFF"))
            {
                address = ipv6ToMappedIpv4WithSuffix(address)
            }
        }

        if (address.indexOf("::") == -1) // All eight groups are present.
            fullAddress = address;
        else // Consecutive groups of zeroes have been collapsed with "::".
        {
            var sides = address.split("::");
            var groupsPresent = 0;
            for (var i = 0; i < sides.length; i++) {
                groupsPresent += sides[i].split(":").length;
            }
            fullAddress += (sides[0] ? sides[0] : 0) + ":";
            for (var i = 0; i < validGroupCount - groupsPresent; i++) {
                fullAddress += "0:";
            }
            if (sides[1]) {
                fullAddress += (sides[1].split("/")[0] ? sides[1].split("/")[0] : "0") +
                    (sides[1].split("/")[1] ? "/" + sides[1].split("/")[1] : "");
            } else {
                fullAddress += "0";
            }

        }
        fullAddress = removeLeadingZeros(fullAddress);
        return fullAddress.toLowerCase();
    }
}
