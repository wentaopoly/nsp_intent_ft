function MdSuggest() {

    this.getReservedLabelBlock = function (neId) {
        const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/mpls-labels/reserved-label-block?fields=label-block-name`;
        return this.getSuggestData(neId, url, "nokia-conf:reserved-label-block", "label-block-name");
    }

    this.getLogAccountingPolicyId = function (neId) {
        const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/log/accounting-policy?fields=policy-id`;
        return this.getSuggestData(neId, url, "nokia-conf:accounting-policy", "policy-id");
    }

    this.getMaintenancePolicyName = function (neId) {
        const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/segment-routing/maintenance-policy?fields=policy-name`;
        return this.getSuggestData(neId, url, "nokia-conf:maintenance-policy", "policy-name");
    }

    this.getV6LocatorName = function (neId) {
        const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/segment-routing/segment-routing-v6/locator?fields=locator-name`;
        return this.getSuggestData(neId, url, "nokia-conf:locator", "locator-name");
    }

    this.getV6MicroSegmentLocatorName = function (neId) {
        const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/segment-routing/segment-routing-v6/micro-segment-locator?fields=locator-name`;
        return this.getSuggestData(neId, url, "nokia-conf:micro-segment-locator", "locator-name");
    }

    this.getSuggestData = function(neId, url, initialProperty, propertyName) {
        const mdcFwk = new MdcFwk();
        const resultFetch = mdcFwk.fetch(neId, url);
        logger.info("123456 =", JSON.stringify(resultFetch));
        const finalResponse = resultFetch.msg[initialProperty];
        const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data[propertyName]).filter(value => value != null):[];
        logger.info("ret =", JSON.stringify(ret));
        return ret;
    }
}
