function MdSuggest() {
    
    this.getPolicyName = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/match-list/ipv6-prefix-list?fields=prefix-list-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:ipv6-prefix-list'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['prefix-list-name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }
}
