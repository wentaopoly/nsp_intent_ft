package com.nokia.nsp.md.resync.plugin.srl;

import com.alu.nms.common.util.model.ModelFdn;
import com.nokia.nsp.md.common.IExecutionContext;
import com.nokia.nsp.md.common.IYangObject;
import com.nokia.nsp.md.common.YangObject;
import com.nokia.nsp.md.db.yang.api.ExecutionContext;
import com.nokia.nsp.md.db.yang.api.QueryParameters;
import com.nokia.nsp.md.db.yang.api.meta.IYangNode;
import com.nokia.nsp.md.db.yang.api.meta.IYangPath;
import com.nokia.nsp.md.resync.api.IReadObjects;
import com.nokia.nsp.md.resync.plugin.common.*;
import com.nokia.nspos.model.domain.common.types.SourceType;
import com.nokia.nspos.persistence.impl.db.transaction.Transactor;
import com.nokia.nspos.persistence.impl.db.transaction.TxPhase;
import com.nokia.nspos.persistence.yang.api.IYangDB;
import com.nokia.nspos.persistence.yang.api.SourceData;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class SrlElanVxlanResyncHandler implements INspResyncDeviceClassHandler {
    private static final Logger handleRootDeviceLogger = LoggerFactory.getLogger(SrlElanVxlanResyncHandler.class.getName() + ".handleRootDevice");
    private static final Logger handlePartialDeviceResyncClassLogger = LoggerFactory.getLogger(SrlElanVxlanResyncHandler.class.getName() + ".handlePartialDeviceResyncClass");
    private static final Logger handleUpdateLogger = LoggerFactory.getLogger(SrlElanVxlanResyncHandler.class.getName() + ".handleUpdate");
    private static final Logger handleDeleteLogger = LoggerFactory.getLogger(SrlElanVxlanResyncHandler.class.getName() + ".handleDelete");
    private static final Logger logger = LoggerFactory.getLogger(SrlElanVxlanResyncHandler.class.getName());
    private final static String NSP_SERVICE_OPER_VXLAN_INSTANCE_PATH = "/nsp-service:services/service-layer/elan/site/service-extension:elan-site/vxlan/instance";
    private final static String NSP_SERVICE_OPER_SITE_EXT_PATH = "/nsp-service:services/service-layer/elan/site/service-extension:elan-site";
    public static final String SRL_NOKIA_NETWORK_INSTANCE_NETWORK_INSTANCE_VXLAN_INTERFACE = "srl_nokia-network-instance:/network-instance/vxlan-interface";
    private static final SourceData sourceData = new SourceData(SourceType.other, ModelFdn.decode("fdn:app:resync"));
    private static ThreadLocal<Map<String,SrlResyncRequestWrapper>> resyncThreadLocal=new ThreadLocal<>();

    public  int getDeviceMaxDepth(DeviceResyncClass aInDeviceClass,String aInNodeType,String aInNodeVersion)
    {
        return 1;
    }
    //needs to be handled
    @Override
    public boolean isHandleRootDevice(DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, ISaveTaskInfo aInISaveTaskInfo, DeviceInfo aInDeviceInfo) {
        return true;
    }

    //full resync
    @Override
    public void handleRootDevice(IYangPath aInIYangPath, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, Object aInDeviceObject, ISaveTaskInfo aInISaveTaskInfo, DeviceInfo aInDeviceInfo, IReadObjects aInIReadObjects, List<IYangObject> aOutProcessedObjects) {
        // for full resync
        long startTime = System.currentTimeMillis();
        String lDevicePath = aInDeviceClass.getDeviceClassPath();
        IYangDB lYangDB = aInISaveTaskInfo.getIMDMPluginMdResyncProvider().getiMdResyncFw().getIYangDB();
        String lNeId = aInISaveTaskInfo.getNeId();
        Map lDeviceObject = (Map) aInDeviceObject;
        Object lDevFdn = (lDeviceObject).get("_fdn_");

        if (lDevicePath.equals("srl_nokia-tunnel-interfaces:/tunnel-interface/vxlan-interface/ingress")) {
            String lDeviceObjFdnStr = getDevObjFdn((Map) aInDeviceObject);
            String vxlanInterfaceFdn = "fdn:model:mdm:" + lNeId + ":" + lDeviceObjFdnStr;
            handleRootDeviceLogger.info("lElanIfFdn: " + vxlanInterfaceFdn);
            IYangObject lExistOperElanYo = aInIReadObjects.removeBasedOnSource(vxlanInterfaceFdn);
            // IYangObject lExistOperElanYo = getElanDBYoFromSource(aInISaveTaskInfo, lYangDB,  lNeId, lDeviceObjFdnStr, NSP_SERVICE_OPER_VXLAN_INSTANCE_PATH);
            if (null != lExistOperElanYo) {
                updateVxlanInstance(lYangDB,lExistOperElanYo,lDeviceObject);
                handleRootDeviceLogger.info("updated vxlan for : " + lDeviceObjFdnStr + " for operSite : " + lExistOperElanYo.getIdentifier() + " on node : " + lNeId);
                aOutProcessedObjects.add(lExistOperElanYo);
            }
        }
        if (handleRootDeviceLogger.isDebugEnabled()) {
            handleRootDeviceLogger.debug("It took [{}] ms to handle " + lDevicePath, (System.currentTimeMillis() - startTime));
        }
    }

    private void createVxlanInstance(IYangDB lYangDB, Map lDeviceObject, IYangObject lExistOperElanYo, String aInNeId) {
        QueryParameters lQueryParams = getlQueryParams();
        lQueryParams.getIExecutionContext().addExtraParameter("return-light-data", true);
        //Map<String, Object> aOutVxlanIntanceObj = populateVxlanProperties(lDeviceObject,aInNeId);

        Map<String, Object> aOutNspSiteObject =lExistOperElanYo.getProperties();
        aOutNspSiteObject.remove("object-details");
        Map<String, Object> aOutVxlanIntanceObj = populateVxlanProperties(lDeviceObject,aInNeId);
        List<String> sources = (List) lExistOperElanYo.getExtraData("sources");
        sources.removeIf(element -> element.contains("tunnel-interface"));
        String vxlanInstance = getVxlanInstance(lDeviceObject);
        String vxlanInstanceSources = "fdn:model:mdm:" + aInNeId + ":" + getTunnelInterfaceIdentifier(vxlanInstance);
        sources.add(vxlanInstanceSources);
        if(aOutNspSiteObject.containsKey("service-extension:elan-site")) {
            IYangObject lExistOperExtSiteYo = (IYangObject) aOutNspSiteObject.get("service-extension:elan-site");
            if (lExistOperExtSiteYo.getProperty("vxlan") != null) {
                //IYangObject lExistOperExtSiteYo = (IYangObject) aOutNspSiteObject.get("service-extension:l3vpn-site");
                //ArrayList<IYangObject> bgpObjList = ((IYangObject) lExistOperExtSiteYo.getProperty("bgp-evpn")).getProperty("bgp");

                //lYangDB.replace(lExistOperElanYo.getIdentifier(), new YangObject(aOutVxlanIntanceObj), lQueryParams);
                //Map<String, Object> aOutBgpObj = bgpObjList.get(0).getProperties();
                //List<String> bgpSources = (List) bgpObjList.get(0).getExtraData("sources");
                // Map<String, Object> lMetaData = new HashMap<>();
                // lMetaData.put("nsp-model:sources", bgpSources);
                //aOutBgpObj.put("@", lMetaData);

                Map<String, Object> aOutBgpEvpObj = new HashMap<String, Object>();
                Map<String, Object> aOutOperExtSiteObj = lExistOperExtSiteYo.getProperties();
                List<Map<String, Object>> bgpInstList = new ArrayList<>();
                //BGP
                //aOutBgpObj.put(("vxlan"), aOutVxlanIntanceObj);
                //bgpInstList.add(aOutBgpObj);
                // aOutBgpEvpObj.put(("bgp"), bgpInstList);
                //aOutOperExtSiteObj.put("bgp-evpn", aOutBgpEvpObj);

                //Ext-Site
                List<String> siteExtSources = (List) lExistOperExtSiteYo.getExtraData("sources");
                Map<String, Object> lMetaDataExtSite = new HashMap<>();
                lMetaDataExtSite.put("nsp-model:sources", siteExtSources);
                aOutOperExtSiteObj.put("@", lMetaDataExtSite);
                aOutOperExtSiteObj.put("vxlan", aOutVxlanIntanceObj);

                //Site
                Map<String, Object> lMetaDataSite = new HashMap<>();
                lMetaDataSite.put("nsp-model:sources", sources);
                aOutNspSiteObject.put("@", lMetaDataSite);
                aOutNspSiteObject.put("service-extension:elan-site", aOutOperExtSiteObj);


                //lYangDB.replace(lExistOperElanYo.getIdentifier(), new YangObject(aOutNspSiteObject), sourceData, lQueryParams);
                lYangDB.replace(lExistOperExtSiteYo.getIdentifier(), new YangObject(aOutOperExtSiteObj), sourceData, lQueryParams);
            } else {
                lYangDB.createChild(lExistOperElanYo.getIdentifier(), "vxlan", new YangObject(aOutVxlanIntanceObj), lQueryParams);
            }
        }
    }

    private IYangObject getElanDBYoFromSource(ISaveTaskInfo aInISaveTaskInfo, IYangDB aInYangDB, String aInNeId, String aInDevIfFdn, String xpath) {
        IYangNode lEpYangNode = aInISaveTaskInfo.getIMDMPluginMdResyncProvider().getiMdResyncFw().getIYangMeta().findNode(xpath);
        String lSvcEpSrc = "fdn:model:mdm:" + aInNeId + ":"  + aInDevIfFdn;
        List<String> lSources0 = new ArrayList<>(1);
        lSources0.add(lSvcEpSrc);
        QueryParameters lQueryParams0 = getlQueryParams();
        lQueryParams0.getIExecutionContext().addExtraParameter("sources:" + lEpYangNode.getQName(), lSources0);
        IYangObject lEpYo = aInYangDB.getSingle(lEpYangNode.getPathString(), lQueryParams0);

        return lEpYo;
    }

    private QueryParameters getlQueryParams() {
        QueryParameters lQueryParams = new QueryParameters();
        IExecutionContext lExecutionContext = new ExecutionContext(null, null, true, false);
        lQueryParams.setIExecutionContext(lExecutionContext);
        return lQueryParams;
    }

    @Override
    public Map<String, Object> buildFieldFilter(DeviceResyncClass aInDeviceClass, String aInNodeType, String aInNodeVersion) {
        //if you want to fetch specific data from device, basically for performance.
        return null;
    }

    @Override
    public void handlePartialDeviceResyncClass(ISaveTaskInfo aInISaveTaskInfo, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, Map<String, Object> aInDeviceObject, String aInNeId, IMDMPluginMdResyncProvider aInMdResyncFw, DeviceInfo aInDeviceInfo, IPartialResyncContext aInIPartialResyncContext) {

        String lDevicePath = aInDeviceClass.getDeviceClassPath();
        IYangDB lYangDB = aInISaveTaskInfo.getIMDMPluginMdResyncProvider().getiMdResyncFw().getIYangDB();
        if (handlePartialDeviceResyncClassLogger.isDebugEnabled()) {
            handlePartialDeviceResyncClassLogger.info("DevicePath: " + lDevicePath);
        }

        if(lDevicePath.contains("/tunnel-interface")) {

            String lElanIfFdn = getDevObjFdn(aInDeviceObject);
            if (handlePartialDeviceResyncClassLogger.isDebugEnabled()) {
                handlePartialDeviceResyncClassLogger.info("lElanIfFdn: " + lElanIfFdn);
            }
            IYangObject lExistOperElanYo = getElanDBYoFromSource(aInISaveTaskInfo, lYangDB,  aInNeId, lElanIfFdn, NSP_SERVICE_OPER_VXLAN_INSTANCE_PATH);
            if(null != lExistOperElanYo){
                updateVxlanInstance(lYangDB, lExistOperElanYo, aInDeviceObject);
                handleUpdateLogger.info("updating VxlanServiceSiteYo object : {}  lneId : {} ",lExistOperElanYo.getIdentifier(),aInNeId);
            }
        }
    }

    private void triggerPartialResyncForSecondaryDeviceClasspath(DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, String aInNeId, IMDMPluginMdResyncProvider aInMdResyncFw, DeviceInfo aInDeviceInfo, String lElanIfFdn) {
        DeviceResyncClass secondaryDeviceResyncClass = aInNspClass.getDeviceResyncClass(aInDeviceClass.getSecondaryDeviceClassesToResync().get(0));
        String SubInterface = lElanIfFdn.substring(lElanIfFdn.lastIndexOf('=') + 1 ,lElanIfFdn.lastIndexOf(']') - 1);
        String [] interfaceDetails = SubInterface.split("\\.");
        String fdn = "/tunnel-interface[name=" + interfaceDetails[0] + "']/vxlan-interface[index='" + interfaceDetails[1] + "']/ingress";
        String sourceFdn = "fdn:model:mdm:" + fdn;
        scheduldePartialResync(secondaryDeviceResyncClass, aInNspClass, fdn, sourceFdn, aInNeId, aInMdResyncFw, aInDeviceInfo);
    }

    private void scheduldePartialResync(DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, String lfdn,String sourceFdn, String aInNeId, IMDMPluginMdResyncProvider aInMDMPluginMdResyncProvider, DeviceInfo aInDeviceInfo) {
        logger.info(" :scheduldePartialResync: Neid {}  deviceClassPath {} ",aInNeId,aInDeviceClass.getDeviceClassPath() );
        Map<String,SrlResyncRequestWrapper> lWrapperMap=resyncThreadLocal.get();
        if(null == lWrapperMap)
        {
            lWrapperMap=new HashMap<>();
            resyncThreadLocal.set(lWrapperMap);
            Transactor.getContext().addEventHandler(TxPhase.POST_ROLLBACK,(phase, context) -> {
                resyncThreadLocal.remove();
            });
            Transactor.getContext().addEventHandler(TxPhase.POST_COMMIT, (phase, context) -> {
                Map<String,SrlResyncRequestWrapper> lTmpWrapperMap=resyncThreadLocal.get();
                resyncThreadLocal.remove();
                if(null!=lTmpWrapperMap)
                {
                    for(Map.Entry<String,SrlResyncRequestWrapper> lEntry:lTmpWrapperMap.entrySet())
                    {
                        aInMDMPluginMdResyncProvider.submitPartialResyncTask(lEntry.getKey(),
                                lEntry.getValue().getResyncClasses(),lEntry.getValue().getXPaths(), aInNeId, aInDeviceInfo.getNodeType(), aInDeviceInfo.getNodeVersion(), aInDeviceInfo.getAmiName(), aInDeviceInfo.getAmiVersion(),null);
                    }
                }

            });
        }
        SrlResyncRequestWrapper lResyncWrapper=lWrapperMap.get(aInDeviceClass.getDeviceClassPath());
        if(null == lResyncWrapper)
        {
            Set<ResyncClass> lResyncClasses=new HashSet<>(1);
            lResyncClasses.add(aInNspClass);
            lResyncWrapper=new SrlResyncRequestWrapper(aInDeviceClass.getDeviceClassPath(),lResyncClasses);
            lWrapperMap.put(aInDeviceClass.getDeviceClassPath(), lResyncWrapper);
        }
        lResyncWrapper.addXPath(lfdn, sourceFdn);
    }

    private String getDevObjFdn(Map<String, Object> aInDeviceObject) {
        Object lDevObjFdn = aInDeviceObject.get("_fdn_");
        Map<String, Object> lDevObjFdnMap = new HashMap<>();
        lDevObjFdnMap.putAll((Map) lDevObjFdn);
        String lDevObjFdnStr = (String) lDevObjFdnMap.get("fdn");

        return lDevObjFdnStr;
    }

    private void updateVxlanInstance(IYangDB aInYangDB, IYangObject aInExistVxIf, Map<String, Object> aInDeviceObject) {
        QueryParameters lQueryParams = new QueryParameters();
        IExecutionContext lExecutionContext = new ExecutionContext(null, null, true, false);
        lQueryParams.setIExecutionContext(lExecutionContext);
        int vni = getVnifromDeviceObjcet(aInDeviceObject);
        if(vni != -1){
            aInExistVxIf.setProperty("vni", vni);
            aInYangDB.update(aInExistVxIf.getIdentifier(), aInExistVxIf, sourceData, lQueryParams);
        }
    }

    private Map<String, Object> populateVxlanProperties( Map<String, Object> lDeviceObjectMap,String aInNeId) {
        String aInVxlanIfName = getVxlanInstance(lDeviceObjectMap);
        Map<String, Object> aOutExtSiteVxlanObject = new HashMap<String, Object>();
        Map<String, Object> vxlanInstanceObject = new HashMap<String, Object>();

        List<Map<String, Object>> vxInstList = new ArrayList<>();
        if(null != aInVxlanIfName){
            vxlanInstanceObject.put("vxlan-instance-id", 1);
            String[] vxIndexArr = aInVxlanIfName.split("\\.");
            if(vxIndexArr.length == 2) {
                String vxlanInterfaceXpath = "/tunnel-interface[name='" + vxIndexArr[0] + "']/vxlan-interface[index='" + vxIndexArr[1] + "']/ingress";
                String vxlanInterfaceFdn = "fdn:model:mdm:" + aInNeId + ":" + vxlanInterfaceXpath;
                List<String> lSources = new ArrayList<>();
                lSources.add(vxlanInterfaceFdn);
                Map<String, Object> lMetaData = new HashMap<>();
                lMetaData.put("nsp-model:sources", lSources);
                vxlanInstanceObject.put("vni", vxIndexArr[1]);
                vxlanInstanceObject.put("@", lMetaData);
            }
            vxInstList.add(vxlanInstanceObject);
            aOutExtSiteVxlanObject.put("instance", vxInstList);
        }
        return aOutExtSiteVxlanObject;
    }

    private String getTunnelInterfaceIdentifier(String identifier){
        String vxlanInterfaceXpath = null;
        if(null != identifier && identifier.contains(".")) {
            String[] vxIndexArr = identifier.split("\\.");
            vxlanInterfaceXpath = "/tunnel-interface[name='" + vxIndexArr[0] + "']/vxlan-interface[index='" + vxIndexArr[1] + "']/ingress";
        }
        return vxlanInterfaceXpath;
    }

    private int getVnifromDeviceObjcet(Map<String, Object> aInDeviceObject){
        int lvni = -1;
        lvni = (Integer) aInDeviceObject.get("vni");
        return lvni;
    }

    private String getNetInstance(Map aInDeviceObject) {
        Object lObjectFdn = aInDeviceObject.get("_fdn_");
        String nm = (String)((Map)lObjectFdn).get("fdn");
        int startIndex = nm.indexOf("name");
        String netIns = nm.substring(startIndex + 6, nm.indexOf("'", startIndex + 6));
        return netIns;
    }

    private String getVxlanInstance(Map aInDeviceObject) {
        Object lObjectFdn = aInDeviceObject.get("_fdn_");
        String nm = (String)((Map)lObjectFdn).get("fdn");
        int startIndex = nm.lastIndexOf("name");
        String vxlanInstance = nm.substring(startIndex + 6, nm.indexOf("'", startIndex + 6));
        return vxlanInstance;
    }

    @Override
    public void handleUpdate(ISaveTaskInfo aInISaveTaskInfo, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, Map<String, Object> aInDeviceObject, String aInNeId, IMDMPluginMdResyncProvider aInMdResyncFw, DeviceInfo aInDeviceInfo) {
        //update notification from mdm-notification
        //need to check interface or unit.
        String lDevicePath = aInDeviceClass.getDeviceClassPath();
        IYangDB lYangDB = aInISaveTaskInfo.getIMDMPluginMdResyncProvider().getiMdResyncFw().getIYangDB();
        String aNeId =  aInISaveTaskInfo.getNeId();
        if(lDevicePath.equals(SRL_NOKIA_NETWORK_INSTANCE_NETWORK_INSTANCE_VXLAN_INTERFACE)){
            String netInst = getNetInstance(aInDeviceObject);
            if(null != netInst) {
                String netInstFdn = "/network-instance[name='" + netInst + "']";
                //IYangObject lparentYo = getElanDBYoFromSource(aInISaveTaskInfo,lYangDB,aInNeId,netInstFdn,NSP_SERVICE_OPER_SITE_EXT_PATH);
                String lOperationalSitePath = "/nsp-service:services/service-layer/elan/site[site-id='" + aNeId + "'][name='" + netInst + "']";
                IYangObject lparentYo = lYangDB.getSingle(lOperationalSitePath);
                if(null != lparentYo) {
                    createVxlanInstance(lYangDB,aInDeviceObject,lparentYo,aInNeId);
                    handleUpdateLogger.info("Created vxlanInterface : {} lneId : {} ", getDevObjFdn(aInDeviceObject),aInNeId);
                    triggerPartialResyncForSecondaryDeviceClasspath(aInDeviceClass,aInNspClass,aInNeId,aInMdResyncFw,aInDeviceInfo,getDevObjFdn(aInDeviceObject));
                }
            }
        } else if(lDevicePath.contains("/tunnel-interface")) {
            String lElanIfFdn = getDevObjFdn(aInDeviceObject);
            handleUpdateLogger.info("lElanIfFdn: " + lElanIfFdn);

            IYangObject lExistOperElanYo = getElanDBYoFromSource(aInISaveTaskInfo, lYangDB,  aInNeId, lElanIfFdn, NSP_SERVICE_OPER_VXLAN_INSTANCE_PATH);
            if(null != lExistOperElanYo){
                updateVxlanInstance(lYangDB, lExistOperElanYo, aInDeviceObject);
                handleUpdateLogger.info("Updated VxlanServiceSiteYo object :  {}  lneId : {} ",lExistOperElanYo.getIdentifier(),aInNeId);
            } else {
            }
        }
        // }
    }

    @Override
    public void handleDelete(ISaveTaskInfo aInISaveTaskInfo, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, Map<String, Object> aInDeviceObject, String aInNeId, IMDMPluginMdResyncProvider aInMdResyncFw, DeviceInfo aInDeviceInfo) {
        //called from mdm-notification
        //need to check interface or unit.
        String lDevicePath = aInDeviceClass.getDeviceClassPath();
        IYangDB lYangDB = aInISaveTaskInfo.getIMDMPluginMdResyncProvider().getiMdResyncFw().getIYangDB();
        if(lDevicePath.equals(SRL_NOKIA_NETWORK_INSTANCE_NETWORK_INSTANCE_VXLAN_INTERFACE)){
            String vxlanInterfaceIdentifier = getTunnelInterfaceIdentifier(getVxlanInstance(aInDeviceObject));
            if(null != vxlanInterfaceIdentifier){
                IYangObject lVxlanInstanceYo = getElanDBYoFromSource(aInISaveTaskInfo,lYangDB,aInNeId,vxlanInterfaceIdentifier,NSP_SERVICE_OPER_VXLAN_INSTANCE_PATH);
                if(null != lVxlanInstanceYo){
                    QueryParameters lQueryParams =getlQueryParams();
                    lYangDB.delete(lVxlanInstanceYo.getIdentifier(),lQueryParams);
                    handleDeleteLogger.info("Deleted VxlanInstance : {}  lneId : {} ", lVxlanInstanceYo.getIdentifier(),aInNeId);
                }
            }
        }
    }

    @Override
    public void handleDelete(ISaveTaskInfo aInISaveTaskInfo, DeviceResyncClass aInDeviceClass, ResyncClass aInNspClass, ModelFdn aInDeviceObject, String aInNeId, IMDMPluginMdResyncProvider aInMdResyncFw, DeviceInfo aInDeviceInfo) {
        //called from data-deployer
        //need to check interface or unit.
    }

    public boolean isHandleUnmanageNode(ResyncClass aInNspClass,IUnmanageNeContext aInIUnmanageNeContext)
    {
        return false;
    }

    public void handleDeleteOnUnmanageNe(IYangObject aInIYangObject,ResyncClass aInNspClass,IUnmanageNeContext aInIUnmanageNeContext,QueryParameters aInQueryParameters)
    {
        aInIUnmanageNeContext.getIMDMPluginMdResyncProvider().getIYangDB().delete(aInIYangObject.getIdentifier(),aInQueryParameters);
    }
}
