var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk" });
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities" });
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk' });
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget' });

function NfmpScheduerPolicy() {

	var util = new utilities();
	var mapFwk = new MapFwk();
	var parseTarget = new ParseTarget();
	let nfmpFwk = new NfmpFwk();
	var savedObjects;
	var currentObjects;
    var isAudit = false;
    var isEdit = false;

	this.synchronize = function(input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
		if (input.getNetworkState().name() == "delete")
		{
			logger.info("Calling syncDelete");
			return this.syncDelete(input, result);
		}
		var savedTopology = input.getCurrentTopology();
		savedObjects = {};
		currentObjects = {};
		var target = parseTarget.getNeIdFromTarget(input.getTarget());
		var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
	    //set the policy name from target
	    intentConfig["displayedName"] = input.getTarget().split("#")[2];
		intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
		logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
		logger.info("Target device = " + target);
		this.createOrModify(target, intentConfig);
		return util.setSuccessResult(result, savedTopology);

	}

	this.xml2object = function(xmlElement) {
		var lXml = Java.type("org.json.XML");
		var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
		var serializer = lsImpl.createLSSerializer();
		serializer.getDomConfig().setParameter("xml-declaration", false);
		var str = serializer.writeToString(xmlElement);
		var json = lXml.toJSONObject(str).toString();
		logger.info('input json: ' + json)
		return JSON.parse(json);
	}

	this.removeEmptyContainers = function(prop, intentJson, path, target) {

		if (Array.isArray(intentJson)) {
			var object = [];
			for (var prop in intentJson) {
				var value = this.removeEmptyContainers(prop, intentJson[prop], path, target);
				if (value) {
					object.push(value);
				}

			}
			if (Object.keys(object).length !== 0) {
				return object;
			}
		} else if (typeof intentJson == 'object') {
			var object = {};
			for (var prop in intentJson) {
				var pPath = path + "/" + prop;
				var value = this.removeEmptyContainers(prop, intentJson[prop], pPath, target);
				if ((value && value !== null) || value == 0) {
					object[prop] = value;
				}

			}
			if (Object.keys(object).length !== 0) {
				return object;
			}
		} else {
			//if(intentJson && intentJson!=="" && this.validateElements(path,target)){
			if (intentJson !== undefined && intentJson !== "") {
				return intentJson;
			}

			return null;
		}
	}

	this.syncDelete = function(input, result) {

		var target = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyName = input.getTarget().split("#")[2];
		var objectFullName = "network:"+target+":Scheduler:" + policyName;
		objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
		logger.info("Deleting " + objectFullName);
		var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

		if (!deleteResult.success) {
			throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
		}
		result.setSuccess(true);
	}

	this.createOrModify = function(target, intentConfig) {

		var schedulerPayload = this.createPolicyLevelPayLoad(target, intentConfig);

		var result = this.modifyRequest(target, schedulerPayload);

		// distribute the policy to the local
		// Distribute Global Policy to Ne in Target
		if(!isEdit)
		{
		    let distributeResult = this.distributePolicy(target, intentConfig, false);

            if (!distributeResult.success) {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }

            util.delay(2000);

            // Changing SyncWithGlobal To Local Edit Only
            distributeResult = this.distributePolicy(target, intentConfig, true);

            if (!distributeResult.success) {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }
		}

		return result;

	}

	this.createPolicyLevelPayLoad = function(target, intentConfig) {

		var fullClassName = "vs.Policy";
		var policyFdn = "Scheduler";
		var objectFullName = "Scheduler:" + intentConfig["displayedName"];
		var localPolicyFullName = "network:"+target+":"+objectFullName;
		localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, target);
		if(util.isObjectExists(fullClassName,localPolicyFullName) || isAudit)
		{
            objectFullName = localPolicyFullName;
            if(!isAudit)
            {
                isEdit = true;
            }
		}

		var properties = {};

		properties["displayedName"] = intentConfig["displayedName"];
		properties["description"] = intentConfig["description"];
		if(intentConfig["frame-based-accounting"])
		{
			properties["schedulerPolicyFrameBasedAccnt"] = intentConfig["frame-based-accounting"];
		}
		else
		{
			properties["schedulerPolicyFrameBasedAccnt"] = false
		}

		var childProperties = [];

		if (intentConfig["tier"]) {
			if (!Array.isArray(intentConfig["tier"])) {
				intentConfig["tier"] = [intentConfig["tier"]];
			}
			for (var index in intentConfig["tier"]) {
				var intentTierConfig = intentConfig["tier"][index];
				if (intentTierConfig["tier-id"] == 1) {
					if (intentTierConfig["parent-location"] == "auto") {
						properties["tier1ParentLoc"] = "none";
					}
					else {
						properties["tier1ParentLoc"] = intentTierConfig["parent-location"];
					}
				}
				if (intentTierConfig["scheduler"]) {
					if (!Array.isArray(intentTierConfig["scheduler"])) {
						intentTierConfig["scheduler"] = [intentTierConfig["scheduler"]];
					}
					for (var scheduler in intentTierConfig["scheduler"]) {
						var intentTierSchedulerConfig = intentTierConfig["scheduler"][scheduler];

						var tierPayload = this.createTierSchedulerPayLoad(target, objectFullName, intentTierConfig["tier-id"], intentTierSchedulerConfig);
						childProperties.push(tierPayload);
					}
				}
				else
				{
				    throw new RuntimeException('Tier must have at least one Scheduler');
				}
			}
		}
		//sort the tier in increasing order , so that tier1 gets deployed first.
		//with this tier2 and tier3 will has option to choose scheduler-parent as tier1
		childProperties.sort(function(a, b) {
            if (a["containedClassProperties"]["tier"] > b["containedClassProperties"]["tier"]){
                return 1;
            }
            else if (a["containedClassProperties"]["tier"] < b["containedClassProperties"]["tier"]){
                return -1;
            }
            else{
              return 0;
            }
            });

		var policyLevelPayload = util.editPayload(policyFdn, properties, childProperties, fullClassName, objectFullName);
		return policyLevelPayload;
	}

	this.createTierSchedulerPayLoad = function(target, schedulerObjectFullName, tierId, intentTierSchedulerConfig) {
		var fullClassName = "vs.Entry";
		//var objectFullName = schedulerObjectFullName + ":tier-" + tierId + "-virtual-scheduler-" + intentTierSchedulerConfig["scheduler-name"];
		var properties = {};
		properties["tier"] = convertToNfmpTierId(tierId);
		properties["displayedName"] = intentTierSchedulerConfig["scheduler-name"];
		properties["description"] = intentTierSchedulerConfig["description"];
		if(intentTierSchedulerConfig["limit-unused-bandwidth"])
		{
			properties["limitUnusedBandwidth"] = intentTierSchedulerConfig["limit-unused-bandwidth"];
		}
        else
        {
			properties["limitUnusedBandwidth"] = false
		}
		if (intentTierSchedulerConfig["rate"])
		{
		    if(!(intentTierSchedulerConfig["rate"]["pir"] === undefined))
		    {
		        properties["pir"] = intentTierSchedulerConfig["rate"]["pir"];
		    }
		    else
		    {
		        properties["pir"] = -1;
		    }

		    if(!(intentTierSchedulerConfig["rate"]["cir"] === undefined))
		    {
		        if(intentTierSchedulerConfig["rate"]["cir"] == -3)
                {
                    properties["cir"] = 0;
                    properties["summedCir"] = "true";
                }
                else
                {
                    properties["cir"] = intentTierSchedulerConfig["rate"]["cir"];
                    properties["summedCir"] = "false";
                }
		    }
		    else
		    {
		        properties["cir"] = 0;
		        properties["summedCir"] = "true";
		    }
			properties["rateType"] = "kbps";
		}
		else if (intentTierSchedulerConfig["percent-rate"])
		{
		    if(!(intentTierSchedulerConfig["percent-rate"]["pir"] === undefined))
		    {
		        properties["pirPercent"] = convertToNfmpPercentRate(intentTierSchedulerConfig["percent-rate"]["pir"]);
		    }
		    else
		    {
		        properties["pirPercent"] = convertToNfmpPercentRate(100);
		    }
		    if(!(intentTierSchedulerConfig["percent-rate"]["cir"] === undefined))
		    {
		        if(intentTierSchedulerConfig["percent-rate"]["cir"] == -3)
                {
                    properties["cirPercent"] = convertToNfmpPercentRate(0);
                    properties["summedCir"] = "true";
                }
                else
                {
                    properties["cirPercent"] = convertToNfmpPercentRate(intentTierSchedulerConfig["percent-rate"]["cir"]);
                    properties["summedCir"] = "false";
                }
		    }
		    else
		    {
		        properties["cirPercent"] = convertToNfmpPercentRate(0);
		        properties["summedCir"] = "true";
		    }
			if (intentTierSchedulerConfig["percent-rate"]["reference-rate"] == "local-limit")
			{
				properties["rateType"] = "percentLocalLimit";
			}
			else
			{
				properties["rateType"] = "percentReferencePortLimit";
			}
		}

		if (intentTierSchedulerConfig["port-parent"])
		{
			//clear scheduler-parent. (Port Parent and other Parent commands are mutually exclusive)
			properties["nextSchedulerName"] = '';

		    if(!(intentTierSchedulerConfig["port-parent"]["level"] === undefined))
		    {
		        properties["portParentLevel"] = convertToNfmpLevel(intentTierSchedulerConfig["port-parent"]["level"]);
		    }
		    else
		    {
		        properties["portParentLevel"] = convertToNfmpLevel(1);
		    }
		    if(!(intentTierSchedulerConfig["port-parent"]["cir-level"] === undefined) && (intentTierSchedulerConfig["port-parent"]["cir-level"] !== 0) )
		    {
		        properties["portParentCirLevel"] = convertToNfmpLevel(intentTierSchedulerConfig["port-parent"]["cir-level"]);
		    }
		    else
		    {
		        properties["portParentCirLevel"] = "defaultLevel";
		    }
		    if(!(intentTierSchedulerConfig["port-parent"]["weight"] === undefined))
            {
                properties["portParentWeight"] = convertToNfmpWeight(intentTierSchedulerConfig["port-parent"]["weight"]);
            }
            else
            {
                properties["portParentWeight"] = convertToNfmpWeight(1);
            }
            if(!(intentTierSchedulerConfig["port-parent"]["cir-weight"] === undefined))
            {
                properties["portParentCirWeight"] = convertToNfmpWeight(intentTierSchedulerConfig["port-parent"]["cir-weight"]);
            }
            else
            {
                properties["portParentCirWeight"] = convertToNfmpWeight(0);
            }
			properties["portParent"] = "true";
		}
		else if (intentTierSchedulerConfig["scheduler-parent"] && !(intentTierSchedulerConfig["scheduler-parent"]["scheduler-name"] === undefined))
		{
			//clear port Parent. (Port Parent and other Parent commands are mutually exclusive)
			properties["portParent"] = "false";

			properties["nextSchedulerName"] = intentTierSchedulerConfig["scheduler-parent"]["scheduler-name"];
			if(!(intentTierSchedulerConfig["scheduler-parent"]["level"] === undefined))
			{
			    properties["level"] = convertToNfmpLevel(intentTierSchedulerConfig["scheduler-parent"]["level"]);
			}
			else
			{
			    properties["level"] = convertToNfmpLevel(1);
			}
			if(!(intentTierSchedulerConfig["scheduler-parent"]["cir-level"]=== undefined) && (intentTierSchedulerConfig["scheduler-parent"]["cir-level"] !== 0))
            {
                properties["cirLevel"] = convertToNfmpLevel(intentTierSchedulerConfig["scheduler-parent"]["cir-level"]);
            }
            else
            {
                properties["cirLevel"] = "defaultLevel";
            }
            if(!(intentTierSchedulerConfig["scheduler-parent"]["weight"]=== undefined))
            {
                properties["weight"] = convertToNfmpWeight(intentTierSchedulerConfig["scheduler-parent"]["weight"]);
            }
            else
            {
                properties["weight"] = convertToNfmpWeight(1);
            }
            if(!(intentTierSchedulerConfig["scheduler-parent"]["cir-weight"]=== undefined))
            {
                properties["cirWeight"] = convertToNfmpWeight(intentTierSchedulerConfig["scheduler-parent"]["cir-weight"]);
            }
            else
            {
                properties["cirWeight"] = convertToNfmpWeight(1);
            }
		}

		return this.createChildObjectPayload(fullClassName, properties);

	}
	this.createChildObjectPayload = function(fullClassName, properties) {

		var childObjectPayLoad = {};
		childObjectPayLoad['objectClassName'] = fullClassName;
		childObjectPayLoad['containedClassProperties'] = properties;
		return childObjectPayLoad;

	}

	this.modifyRequest = function(target, payload) {

		logger.info("Sending the modify request for mdt");
		logger.info(JSON.stringify(payload));
		var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
		if (!result.success) {
		    logger.error("Error while deploying the request {}", JSON.stringify(result.msg));
		    let objFullName = payload["objectFullName"];
		    objFullName = util.modifyNeIdForIpV6(objFullName, target);
		    if(!(objFullName.indexOf("network") !== -1))
		    {
                logger.info("Redeploying the request ...  ");
                result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
                if (!result.success)
                {
                    throw new RuntimeException(result.msg)
                }
		    }
		    else
		    {
                throw new RuntimeException(result.msg)
		    }
		}
		return result;

	}

	this.distributePolicy = function(nodeIp, intentConfig, localEdit) {

		logger.info(" localEdit: " + localEdit);
		var objectFullName = "Scheduler:" + intentConfig["displayedName"];
		var xmlReq = utilityService.processTemplate(resourceProvider.getResource(localEdit ? "distribute_local_edit.ftl" : "distribute.xml"), { nodeIp: nodeIp, objectFullName: objectFullName });
		logger.info(xmlReq);
		return nfmpFwk.passThroughRequest('/', xmlReq);

	}


	this.audit = function (input, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
		isAudit = true;
		//var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
		var lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
		var intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];

		intentConfig["displayedName"] = input.getTarget().split("#")[2];
		var target = parseTarget.getNeIdFromTarget(input.getTarget());
		intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
		logger.info("auditing configuration = " + JSON.stringify(intentConfig));
		logger.info("Target device = " + target);
		if (intentConfig) {
			this.auditAndCompare(target, intentConfig, auditReport);
		} else {
			throw "configuration not available in the intent";
		}

		return auditReport
	}

	this.auditAndCompare = function(target, intentConfig, auditReport) {

		var schedulerPayload = this.createPolicyLevelPayLoad(target, intentConfig);
		var result = this.auditRequest(target, schedulerPayload);
		auditReport = util.reportMisaligned(target, result, auditReport);
		return auditReport;
	}

	this.auditRequest = function(target, payload) {
		logger.info("Sending the audit request for mdt");
		logger.info(JSON.stringify(payload));
		var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
		if (!result.success) {
			throw new RuntimeException(result.msg);
		}
		return result;

	}
    //convert tierId to NFMP Tier Enum name.
    function convertToNfmpTierId(tierId)
    {
        return "tier"+tierId;
    }

    //convert Percent-Rate PIR/CIR to decimal format.
    function convertToNfmpPercentRate(percentRate)
    {
        if(util.isInteger(percentRate))
        {
            return Number(percentRate).toFixed(1);
        }
        return percentRate;
    }

    //convert level to NFMP level enum name.
    function convertToNfmpLevel(level)
    {
        return "level"+level;
    }

    //convert weight to NFMP weight enum name.
    function convertToNfmpWeight(weight)
    {
        return "weight"+weight;
    }

}
