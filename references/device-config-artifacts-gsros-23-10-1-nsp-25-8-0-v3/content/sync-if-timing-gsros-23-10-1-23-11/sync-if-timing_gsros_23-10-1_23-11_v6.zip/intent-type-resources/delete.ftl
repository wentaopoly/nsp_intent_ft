{
          "operation":"delete",
          "target": ${targetUrl}
}
