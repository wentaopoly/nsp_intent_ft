var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk'});
load({ script: resourceProvider.getResource('traverse-fwk.js'), name: 'TraverseFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});

function MdcIntentFwk() {
    var intentDeviationObj = new IntentDeviceDeviation();

    this.restResponseHandler = function(exception, httpStatus, response) {
        logger.info("[IntentMgr] REST response : " + response);
        logger.info("[IntentMgr] REST httpStatus : " + httpStatus);
        if (exception) {
            throw new RuntimeException("Couldn't connect to device proxy for ; Response: "+response);
        }
        if (httpStatus !== 200 && httpStatus !== 201) {
            throw new RuntimeException("Failed to access device  using MDC; Response: "+response);
        }
        restResponse = JSON.parse(response);
    };

    this.synchronize = function(input, result,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {

        var traverseFwk = new TraverseFwk();
        var parseTarget = new ParseTarget();
        var target = parseTarget.getNeIdFromTarget(input.getTarget());

        // saved topology
        var savedTopology = input.getCurrentTopology();

        if(savedTopology == null){
            savedTopology = topologyFactory.createServiceTopology();
        }

        if (input.getNetworkState().name() == "delete"){
            logger.info(JSON.stringify(savedTopology));
            traverseFwk.resetTheVariables();
            var requests = [];
            var deleteIpfilterObj = {};
            deleteIpfilterObj["operation"] = "delete";
            deleteIpfilterObj["edit-id"] = "edit-" + new Date().getTime();
            deleteIpfilterObj["target"] = "nokia-conf:/configure/filter/ip-filter=" + parseTarget.getUniqueIdentifier(input.getTarget());
            requests.push(deleteIpfilterObj)
            result = traverseFwk.syncRequest(target, requests, result, savedTopology);
            result.setTopology(null);
            return result;

        }

        if(target !== "0.0.0.0"){
            var intentConfig;
            intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
            if(!intentConfig){
                intentConfig={}
            }
            var filterName = input.getTarget().split("#")[2];
            var filterId = input.getTarget().split("#")[3];
            intentConfig[uniqueIdentifier] = filterName;
            intentConfig['filter-id'] = parseInt(filterId);

            if (intentConfig){
                intentConfig = intentDeviationObj.removeIntentConfig(intentConfig, target);
                savedTopology = traverseFwk.traverse(target,intentConfig,savedTopology,null,parentXpath,initialPropertyName);

                //sorting delete array
                var deleteRequests = traverseFwk.getDeleteRequests();

                var deleteReqObjects = [];
                for (var delCount = 0; delCount < deleteRequests.length; delCount++) {
                    var delReqObj = deleteRequests[delCount];
                    var targetUrl = delReqObj['target'].split('/');
                    if (targetUrl[targetUrl.length-1] !== "protocol" && targetUrl[targetUrl.length-1] !== "protocol-list" && targetUrl[targetUrl.length-1] !== "address" && targetUrl[targetUrl.length-1] !== "mask" && targetUrl[targetUrl.length-1] !== "ip-prefix-list" && targetUrl[targetUrl.length-1] !== "eq" && targetUrl[targetUrl.length-1] !== "lt" && targetUrl[targetUrl.length-1] !== "gt" && targetUrl[targetUrl.length-1] !== "range" && targetUrl[targetUrl.length-1] !== "start" && targetUrl[targetUrl.length-1] !== "end") {
                        deleteReqObjects.push(delReqObj)
                    }
                }
                deleteRequests = deleteReqObjects;

                deleteRequests.sort(function(a, b){
                    return b["target"].length - a["target"].length;
                });

                // concating createrequests and deleterequests
                var createRequests = traverseFwk.getCreateRequests();
                var requests;
                if(deleteRequests && createRequests){
                    requests = createRequests.concat(deleteRequests);
                }
                if ( requests ){
                    result = traverseFwk.syncRequest(target,requests,result,savedTopology);
                }
                createRequests = undefined;
                deleteRequests = undefined;
                requests = undefined;
            } else {
                logger.info('')
                result = traverseFwk.deleteAllFromTopology(savedTopology, target, result);
            }
        }
        traverseFwk.resetTheVariables();
        return result;
    }

    this.audit = function(target, config, svcTopo, adminState, report,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier) {
        var currentConfig;
        var traverseFwk = new TraverseFwk();
        var parseTarget = new ParseTarget();
        var targetNeId = parseTarget.getNeIdFromTarget(target);

        if(target !== "0.0.0.0"){
            currentConfig  = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
            if(!currentConfig){
                currentConfig={}
            }
            var filterName = target.split("#")[2];
            var filterId = target.split("#")[3];
            currentConfig[uniqueIdentifier] = filterName;
            currentConfig['filter-id'] = parseInt(filterId);

            currentConfig = intentDeviationObj.removeIntentConfig(currentConfig, targetNeId);

            svcTopo = traverseFwk.traverse(targetNeId,currentConfig,svcTopo,report,parentXpath,initialPropertyName);
            // reseting the variables
            traverseFwk.resetTheVariables();
        }

        return report;

    }

    this.xml2object = function(xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: '+ json)
        return JSON.parse(json);
    }
}
