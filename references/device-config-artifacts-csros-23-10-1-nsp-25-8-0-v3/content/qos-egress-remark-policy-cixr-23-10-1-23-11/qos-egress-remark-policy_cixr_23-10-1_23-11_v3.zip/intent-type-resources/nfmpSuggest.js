function NfmpSuggest() {
    this.getPolicyName = function (neId) {
        let className = "ixrqos.EgressRemarkPolicy";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObject, className, "displayedName")
    }
    this.getDot1pMappingName = function (neId) {
        let className = "ixrqos.FcDot1pMap";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObject, className, "displayedName")
    }
    this.getFC_DSCP_Mapping= function (neId) {
        let className = "ixrqos.FcDSCPMap";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObject, className, "displayedName")
    }
    this.getLSP_EXP_Mapping = function (neId) {
        let className = "ixrqos.FcLspExpMap";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObject, className, "displayedName")
    }
    this.getData = function (searchObjectJson, className, type) {
        logger.info("inside get data check1");
        let nfmpFwk = new NfmpFwk();
        let ret = [];
        let resultFetch = nfmpFwk.post("v3/search", searchObjectJson);
        logger.info(resultFetch.response);
        let finalResponse = JSON.parse(resultFetch.response);
        finalResponse = finalResponse[className];
        logger.info("final response" + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse))
        {
            finalResponse = [finalResponse];
        }
        if (Object.keys(finalResponse).length !== 0)
        {
            finalResponse.forEach(function (value, index, array) {
                ret.push(value[type]);
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }
}
