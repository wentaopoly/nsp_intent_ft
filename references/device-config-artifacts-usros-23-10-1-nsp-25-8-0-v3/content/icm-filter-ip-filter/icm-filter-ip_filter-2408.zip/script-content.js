var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn" : "http://www.nokia.com/management-solutions/ibn",
    "nc" : "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager" : "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders" : "anv-device-holders"
};


load({script:resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

var intentTypeName = 'icm-filter-ip_filter';

// example port, sap-ingress etc..
var initialPropertyName = 'ip-filter';


// unique identifier
var uniqueIdentifier = 'filter-name';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/filter';

function synchronize(input) {
    logger.info('Intent Synchronisation started')

    return NspIntentHelper.synchronize(input,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier);
}

function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started')

    return NspIntentHelper.audit(target, config, svcTopo, adminState,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier);
}

function getTargetData(input) {
    logger.info("getTargetData input for brownfield = \n" + input);
    var target = input.target;
    var config = null;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info(JSON.stringify(deviceConfig));
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}


