load({script: resourceProvider.getResource('intent-logger.js'), name: 'intent-logger.js'});
load({script: resourceProvider.getResource('ietf-utilities.js'), name: 'ietf-utilities.js'});
load({script: resourceProvider.getResource('ietf-intent-validator.js'), name: 'ietf-intent-validator.js'});
load({script: resourceProvider.getResource('ietf-nfmp-instance.js'), name: 'ietf-nfmp-instance.js'});
load({script: resourceProvider.getResource('ietf-mdm-instance.js'), name: 'ietf-mdm-instance.js'});
load({script: resourceProvider.getResource('ietf-nsp-instance.js'), name: 'ietf-nsp-instance.js'});
load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'mediator-fwk.js'});
IntentHelper.prototype.extensionConfig = null;
IntentHelper.prototype.imLogger = new IntentLogger();

var ThreadLocal = Java.type('java.lang.ThreadLocal');
var HashMap = Java.type('java.util.HashMap');
var Arrays = Java.type("java.util.Arrays");
var requestScope = new ThreadLocal();
var ietfUtils = new IetfUtilities();
var intentValidator = new IntentValidator(this.imLogger);

/*
 * Constructor Function. We'll attach more property and methods by updating "prototype" object.
 */
function IntentHelper() {
    // The single input which MUST have all mandatory call back functions and properties to override behaviour.
    this.extensionConfig = null;
}

IntentHelper.prototype.synchronize = function (input) {
    this.imLogger.info("[IETF-Intent-helper][synchronize], input = {}", input);
    var result = synchronizeResultFactory.createSynchronizeResult();
    result.setSuccess(true);

    var requestContext = this.setRequestContext(input);

    // Step 1: Determine Devices to be configured by this intent
    var deviceInfos = this.extensionConfig.getDevicesInvolved();

    // Step 2 : update NSP Source
    var nfmpTunnelId = new NSPInstance(this.imLogger).preDeploy(deviceInfos, requestContext, this.navigateInstance);
    this.imLogger.info("[IETF-Intent-helper][synchronize]: nfmpTunnelId = {}",JSON.stringify(nfmpTunnelId))
    // Step 3: Iterate over devices & perform sync
    this.executeSync(deviceInfos, result, requestContext, nfmpTunnelId);


    requestScope.remove();
    return result;
};

IntentHelper.prototype.executeSync = function (deviceInfos, result, requestContext, nfmpTunnelId) {
    for (var i = 0; i < deviceInfos.length; i++) {
        var deviceId = deviceInfos[i];
        this.imLogger.info("[IETF-Intent-helper][executeSync] deviceId {} ", deviceId);
        var neFamily = this.getNeFamilyRelease(deviceId);
        var neType = this.getNeType(neFamily);
        this.imLogger.info("[IETF-Intent-helper][executeSync] neType {} ", neType);
        var instanceFwk = this.navigateInstance(deviceId, requestContext);
        this.imLogger.info('[executeSync] instanceFwk: {} networkState: {}', instanceFwk.constructor.name, requestContext.get("networkState"));
        if (requestContext.get("networkState") === "delete") {
            instanceFwk.deleteSync(requestContext, result, deviceId);
        } else {
            if (!nfmpTunnelId) nfmpTunnelId = {};
            instanceFwk.deploySync(requestContext, result, deviceId, nfmpTunnelId[deviceId], neType);
        }
    }
    result.setTopology(this.copyTopoObjects(deviceInfos, requestContext.get("currentTopology"),
        requestContext.get("target")));
    return result;
};

IntentHelper.prototype.audit = function (input) {
    this.imLogger.info("[IETF-Intent-helper][audit] Audit Start ");
    var report = auditFactory.createAuditReport(null, null);
    var requestContext = this.setRequestContext(input);

    try {
        // Step 1: Determine Devices to be configured by this intent
        var deviceInfos = this.extensionConfig.getDevicesInvolved();
        // Step 2: update NSP Source
        var nfmpTunnelId = new NSPInstance(this.imLogger).preDeploy(deviceInfos, requestContext, this.navigateInstance);
        this.imLogger.info("[IETF-Intent-helper][audit] nfmpTunnelId = {}", JSON.stringify(nfmpTunnelId))
        if (!nfmpTunnelId) {
            this.imLogger.info("[IETF-Intent-helper][audit]: nfmpTunnelId not found!");
            throw "nfmpTunnelId not found for device: " + device;
        }
    } catch (e) {
        imLogger.error("IntentHelper.prototype.audit: error in preDeploy: " + e);
    }

    // Step 3: Iterate over devices & perform audit
    this.executeAudit(deviceInfos, requestContext, report, nfmpTunnelId);
    
    requestScope.remove();
    return report;
};

IntentHelper.prototype.executeAudit = function (deviceInfos, requestContext, auditReport, nfmpTunnelId) {
    for (var i = 0; i < deviceInfos.length; i++) {
        var deviceInfo = deviceInfos[i];
        var neFamily = this.getNeFamilyRelease(deviceInfo);
        var neType = this.getNeType(neFamily);
        this.imLogger.info("[IETF-Intent-helper][executeAudit] neType {} ", neType);
        var instanceFwk = this.navigateInstance(deviceInfo, requestContext);
        requestContext.put("nfmpTunnelId", nfmpTunnelId[deviceInfo]);
        instanceFwk.audit(requestContext, deviceInfo, auditReport, neType);
    }
    return auditReport;
};

IntentHelper.prototype.validate = function (input) {
    this.imLogger.debug("[IETF-Intent-helper][validate]");
    var contextualErrorJsonObj = {};
    var requestContext = this.setRequestContext(input);

    if (input.getNetworkState().toString() === "active") {
        intentValidator.validateSignalingTypes(requestContext.get("intentConfigJson"), contextualErrorJsonObj);
        intentValidator.validateRouteObjects(requestContext.get("intentConfigJson"), contextualErrorJsonObj);
        intentValidator.validateNe(requestContext, this.navigateInstance, this.extensionConfig.getDevicesInvolved());
        if (!requestContext.get("createTopo")) { //Modify checks
            intentValidator.validateOnModify(requestContext, requestContext.get("intentConfigJson"), contextualErrorJsonObj);
        }
    }

    this.imLogger.info("[IETF-Intent-helper][validate] contextualErrorJsonObj {}", contextualErrorJsonObj);

    if (Object.keys(contextualErrorJsonObj).length !== 0) {
        utilityService.throwContextErrorException(contextualErrorJsonObj);
    }
};

IntentHelper.prototype.setRequestContext = function (input) {
    var requestContext = new HashMap();
    requestScope.set(requestContext);

    requestContext.put("sync-input", input);
    requestContext.put("target", input.getTarget().split("#")[2]);
    requestContext.put("originalTarget", input.getTarget().split("#")[2]);
    var lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
    var lJson = lConfig[Object.keys(lConfig)[0]];
    this.imLogger.info("[setRequestContext] getJsonIntentConfiguration {} ", JSON.stringify(lJson));
    requestContext.put("intentConfigJson", lJson);
    requestContext.put("isBF", false);

    //BrownField
    var lTarget = input.getTarget().split("_");
    this.imLogger.info("[setRequestContext] lTarget {} ", JSON.stringify(lTarget));
    if (lTarget && lTarget.length > 1) {
        if (lTarget[0] && lTarget[0] === lJson["source"]) {
            var modifiedTarget = lTarget.splice(1, lTarget.length - 1).join("_");
            this.imLogger.warn("BrownField Tunnel {} using {}", input.getTarget(), modifiedTarget);
            requestContext.put("target", modifiedTarget);
            requestContext.put("isBF", true);
        }
    }
    this.extensionConfig.setIntentTypeNameAndVersion();

    this.setImLogger(new IntentLogger(requestContext.get("intentType"), requestContext.get("intentTypeVersion"), requestContext.get("target")));
    requestContext.put("imLogger", this.imLogger);

    var topo = input.getCurrentTopology();
    requestContext.put("createTopo", false);
    if (topo === null) {
        this.imLogger.info("Creating topology");
        topo = topologyFactory.createServiceTopology();
        requestContext.put("createTopo", true);
    }
    requestContext.put("currentTopology", topo);
    requestContext.put("networkState", input.getNetworkState().name());
    requestContext.put("lspPathMap", {});
    this.imLogger.info("[setRequestContext] requestContext {} ", requestContext);

    return requestContext;
};

IntentHelper.prototype.setExtensionConfig = function (inputConfig) {
    this.extensionConfig = inputConfig;
};

IntentHelper.prototype.setImLogger = function (logger) {
    this.imLogger = logger;
    ietfUtils.setImLogger(logger);
};

IntentHelper.prototype.navigateInstance = function (deviceId, requestContext) {
    var managerName = ietfUtils.getManagerName(deviceId);
    var lInstance = "";

    var lSourceNodeId = {};
    if (requestContext.get("sourceNodeId")) lSourceNodeId = requestContext.get("sourceNodeId");
    lSourceNodeId[deviceId] = deviceId;

    //Openconfig loopback handling
    if (!managerName) {
        this.imLogger.info('[navigateInstance] Lookup Openconfig Loopback Address {}', deviceId);
        var nspMediator = new MediatorFramework("NSP");
        var payload = {
            "input": {
                "xpath-filter": "/openconfig-interfaces:interfaces/interface/subinterfaces/subinterface[boolean(config[nsp-openconfig-interfaces-augments:loopback='true'])]/openconfig-if-ip:ipv4/addresses/address[ip='" + deviceId + "']",
                "depth": "2"
            }
        };
        var openIntRes = nspMediator.post("https://restconf-gateway:443/restconf/operations/nsp-inventory:find", payload);
        if (openIntRes && openIntRes.success) {
            if (openIntRes.response["nsp-inventory:output"] && openIntRes.response["nsp-inventory:output"]["data"] && openIntRes.response["nsp-inventory:output"]["data"].length === 1) {
                lSourceNodeId[deviceId] = openIntRes.response["nsp-inventory:output"]["data"][0]["@"]["nsp-model:network-id"];
                managerName = ietfUtils.getManagerName(lSourceNodeId[deviceId]);
                if (!managerName)
                    throw new RuntimeException('Device is not Managed');
            } else if (openIntRes.response["nsp-inventory:output"] && openIntRes.response["nsp-inventory:output"]["data"] && openIntRes.response["nsp-inventory:output"]["data"].length > 1) {
                throw new RuntimeException('Found more than one Loopback in system');
            } else {
                throw new RuntimeException('Device is not Managed');
            }
        }
    }
    requestContext.put("sourceNodeId", lSourceNodeId);

    this.imLogger.info('[navigateInstance] SourceNodeId of deviceId is {}', lSourceNodeId[deviceId]);

    this.imLogger.info('[navigateInstance] Device: {} is managed by: {}', deviceId, managerName);

    if (!managerName) {
        throw new RuntimeException('Device is not Managed');
    }
    if (managerName.indexOf("MDC") !== -1)
    {
        lInstance = new MDMInstance();
        lInstance.setImLogger(this.imLogger);
    }
    else if (managerName.indexOf("NFM-P") !== -1)
    {
        lInstance = new NFMPInstance(lSourceNodeId[deviceId]);
        lInstance.setImLogger(this.imLogger);
    }
    else
        throw new RuntimeException('Device is not Managed')


    /* switch (managerName) {
         case 'NFM-P':
             lInstance = new NFMPInstance();
             lInstance.setImLogger(this.imLogger);
             break;
         case 'MDC':
             lInstance = new MDMInstance();
             lInstance.setImLogger(this.imLogger);
             break;
         default:
             throw new RuntimeException('Device is not Managed')
     }*/
    return lInstance;
};

IntentHelper.prototype.copyTopoObjects = function (deviceList, sourceTopologyObj, target) {
    var newTopo = topologyFactory.createServiceTopology();
    for (var i = 0; i < deviceList.length; i++) {
        newTopo.addTopologyObject(topologyFactory.createTopologyObjectFrom("Sites",
            deviceList[i].replaceAll(":", "-") + ":" + target, "INFRASTRUCTURE"));
    }

    if (sourceTopologyObj && sourceTopologyObj.getXtraInfo() !== null && !sourceTopologyObj.getXtraInfo().isEmpty()) {
        sourceTopologyObj.getXtraInfo().forEach(function (extraInfo) {
            newTopo.addXtraInfo(topologyFactory.createTopologyXtraInfoFrom(extraInfo.getKey(), extraInfo.getValue()));
        })
    }

    this.imLogger.debug("[IETF-Intent-helper][copyTopoObjects] new Topology - {}", newTopo);
    return newTopo;
};

IntentHelper.prototype.getNeFamilyRelease = function (target) {
    var neId = target;
    var returnNeType = ''
    try
    {
        var managerList = []
        var managers = mds.getAllManagersOfType("REST");
        managers.forEach(function (manager) {
            if (mds.getManagerByName(manager).getConnectivityState().toString() === 'CONNECTED')
            {
                managerList.push(manager)
            }
        });
        var devices = mds.getAllManagedDevicesFrom(managerList);
        devices.forEach(function (device) {
            var deviceName = device.getName();
            //logger.info(device);
            var result = deviceName.localeCompare(neId);
            if (result == 0)
            {
                returnNeType = device.getFamilyTypeRelease();
                return returnNeType;
            }
        });
        return returnNeType;
    } catch (e)
    {
        logger.error(null, "Exception *******************  : " + e);
        return {
            "Device Not Found": "Device Not Found"
        }
    }
}
IntentHelper.prototype.getNeType = function (neFamily) {
    var neFamilyArr = neFamily.split(":");
    return neFamilyArr[0];
}
IntentHelper.prototype.getNeVersion = function (neFamily) {
    var neFamilyArr = neFamily.split(":");
    return neFamilyArr[1];
}
IntentHelper.prototype.getChassisType = function (neFamily) {
    var neFamilyArr = neFamily.split(":");
    return neFamilyArr[2];
}
