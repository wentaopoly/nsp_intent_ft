var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};

load({script:resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();


var intentTypeName = 'qos-schedulerpolicy_gsros_23-10-1_23-11';

// example port, sap-ingress etc..
var initialPropertyName = 'scheduler-policy';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/qos';

// unique identifier
var uniqueIdentifier = 'displayedName';

function synchronize(input) {
    return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

/*function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started')
    return NspIntentHelper.audit(target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier)
}*/

function audit(input) {
    logger.info('Intent Audit started')
    return NspIntentHelper.audit(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier)
}

/*
* suggestParentNames list the Parent Scheduler Names.
* Ex: For Tier-2 all the schedulers of Tier-1 are listed and for
* Tier-3 all the schedulers of Tier-1 and Tier-2 will be listed
*/
function suggestParentNames(context) {
    var schedulerNames = [];

    try {
        var currentTierId = context['inputValues']['arguments']['__parent']['tier-id'];
        var tiers = context['inputValues']['arguments']['__parent']['__parent']['scheduler-policy']['tier'];
        for (var i = 0; i < tiers.length; i++) {
            var tierObj = tiers[i];
            var parentTierId = tierObj['tier-id'];
            var schedulers = tierObj['scheduler'];
            for (var j = 0; j < schedulers.length && parentTierId < currentTierId; j++) {
                var schObj = schedulers[j];
                schedulerNames.push(schObj['scheduler-name']);
            }
        }
    } catch (e) {
        logger.error("Unable to get Scheduler Parent Name \n" + context);
    }

    return schedulerNames;
}

function getTargetData(input) {
    logger.info(input);
    var target = input.target;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}
