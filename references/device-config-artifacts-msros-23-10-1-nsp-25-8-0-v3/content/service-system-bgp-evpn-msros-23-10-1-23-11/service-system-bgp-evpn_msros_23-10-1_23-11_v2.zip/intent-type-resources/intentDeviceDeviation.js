function IntentDeviceDeviation() {

    this.removeIntentConfig = function (intentConfig, neId) {
        var deviationData = undefined;
        try {
            deviationData = this.deviationData();
        } catch (err) {
            return intentConfig;
        }

        var neFamily = this.getNeFamilyRelease(neId);
        var neType = this.getNeType(neFamily);
        var chassisType = this.getChassisType(neFamily);
        var neVersion = this.getNeVersion(neFamily);
        var deviationInfoArr = deviationData['devitaionInfo'];
        for (var i = 0; i < deviationInfoArr.length; i++) {
            var deviationObj = deviationInfoArr[i];
            var deviationNetype = deviationObj['neType'];
            var deviationNeVersion = deviationObj['neVersion'];
            var deviationChassisType = deviationObj['chassisTypes'];
            var chassisFlag = deviationChassisType.length == 0;
            if (!chassisFlag) {
                chassisFlag = deviationChassisType.indexOf(chassisType) != -1;
            }
            var result = ((neType.localeCompare(deviationNetype) == 0) && chassisFlag);

            var neversionResult = ((deviationNeVersion.localeCompare('') == 0) || deviationNeVersion.includes(neVersion))
            logger.info("neType : " + neType + ", chassisType : " + chassisType + ",result = " + result + ", neversionResult : " + neversionResult);

            if (result && neversionResult) {
                var notSupportedObjects = deviationObj['NotSupportedAttributes'];
                for (var j = 0; j < notSupportedObjects.length; j++) {
                    var obj = notSupportedObjects[j];
                    var attributeName = obj['attributeName'];
                    var attrValues = obj['value'];
                    logger.info("attributeName : " + attributeName + ", attrValues : " + attrValues);
                   removeProperty(intentConfig, attributeName, attrValues);
                }
            }
        }
        return intentConfig;
    }

    function removeProperty(intentConfig, removeAttr, removeAttrValues) {

        for (var prop in intentConfig) {
            var attrComp = prop.localeCompare(removeAttr);
            if (attrComp == 0) {
                var intentAttrValue = intentConfig[prop];
                logger.info("intentAttrValue : " + intentAttrValue);
                var removeFalg = (removeAttrValues.length === 0);
                var removeFlag1 = false;
                for (var i = 0; i < removeAttrValues.length; i++) {
                    var attr = removeAttrValues[i];
                    removeFlag1 = attr.localeCompare(intentAttrValue) == 0;
                    logger.info("attr : " + attr + ", intentAttrValue : " + intentAttrValue + ", removeFlag1 : " + removeFlag1)
                    if (removeFlag1)
                        break;
                }
                logger.info("intentAttrValue : " + intentAttrValue + ", removeAttr : " + removeAttr + ", removeAttrValues : " + removeAttrValues + ", removeFlag1 : " + removeFlag1);
                if (removeFalg || removeFlag1) {
                    delete intentConfig[prop];
                }
            } else if (typeof intentConfig[prop] === 'object')
                removeProperty(intentConfig[prop], removeAttr, removeAttrValues);
        }
    }

    this.getNeType = function (neFamily) {
        var neFamilyArr = neFamily.split(":");
        return neFamilyArr[0];
    }

    this.getChassisType = function (neFamily) {
        var neFamilyArr = neFamily.split(":");
        return neFamilyArr[2];
    }

    this.getNeVersion = function (neFamily) {
        var neFamilyArr = neFamily.split(":");
        return neFamilyArr[1];
    }

    this.deviationData = function () {
        var deviationObj = resourceProvider.getResource("intentDeviations.json");
        logger.info("Deviation Info Data : " + deviationObj);
        return JSON.parse(deviationObj);
    }

    this.getNeFamilyRelease = function (target) {
        var neId = target;
        var returnNeType = ''
        try {
            var managerList = []
            var managers = mds.getAllManagersOfType("REST");
            managers.forEach(function (manager) {
                if (mds.getManagerByName(manager).getConnectivityState().toString() === 'CONNECTED') {
                    managerList.push(manager)
                }
            });
            var devices = mds.getAllManagedDevicesFrom(managerList);
            devices.forEach(function (device) {
                var deviceName = device.getName();
                logger.info(device);
                var result = deviceName.localeCompare(neId);
                if (result == 0) {
                    returnNeType = device.getFamilyTypeRelease();
                    return returnNeType;
                }
            });
            return returnNeType;

        } catch (e) {
            logger.error(null, "[LOGGER-DEMO] Exception *******************  : " + e);
            return {
                "Device Not Found": "Device Not Found"
            }

        }
    }
}
