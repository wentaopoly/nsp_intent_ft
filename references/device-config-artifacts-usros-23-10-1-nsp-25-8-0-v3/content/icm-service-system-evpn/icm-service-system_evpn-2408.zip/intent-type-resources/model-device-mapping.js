function ModelDeviceMapping() {


    this.getMapping = function(type){
        switch(type){
            case "ethernetsegment":
                return this.getEthernetSegmentMapping();
            default:
                return this.getEthernetSegmentMapping();
            //return this.get
        }
    }

    this.getEthernetSegmentMapping = function() {
        var mapping = {};
        mapping['ethernet-segment.admin-state'] = 'ethSegAdminState';
        mapping['ethernet-segment.esi'] = 'ethSegEsiValue';
        mapping['ethernet-segment.multi-homing-mode'] = 'ethSegMultiHoming';
        mapping['ethernet-segment.df-election.es-activation-timer'] = 'ethSegEsActivationTimer';

        return mapping;
    }
}
