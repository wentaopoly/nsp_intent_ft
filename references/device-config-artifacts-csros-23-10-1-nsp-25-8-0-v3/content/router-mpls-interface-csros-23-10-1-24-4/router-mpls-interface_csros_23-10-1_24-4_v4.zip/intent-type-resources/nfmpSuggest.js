function NfmpSuggest() {

  
    this.get_SRLG_Names = function (neId) {
           let className = "rtr.SharedRiskLinkGroup";
           let searchObject = {
           "fullClassName": className,
           "filter": {
               "and": {
                   "equal": [
                       {
                           "name": "siteId",
                           "value": neId
                       }
                   ]
               }
           },
           "resultFilter": {
               "children": "",
               "attribute": [
                   "displayedName"
               ]
             }
           };
           return this.getData(searchObject, className, "displayedName");
       }
     
     this.getInterfaceName = function (neId, actionData) {
       let className;
       let searchObject;
       if(actionData === "associate"){
         className = "mpls.Interface";
         searchObject = {
           "fullClassName": className,
           "filter": {
               "and": {
                   "equal": [
                       {
                           "name": "nodeId",
                           "value": neId
                       }
                   ]
               }
           },
           "resultFilter": {
               "children": "",
               "attribute": [
                  "displayedName"
                ]
              }
           };
       }else{
       className = "rtr.NetworkInterface";
         searchObject = {
           "fullClassName": className,
           "filter": {
               "and": {
                   "equal": [
                       {
                           "name": "nodeId",
                           "value": neId
                       }
                   ],
                   "notEqual":[
                       {
                           "name": "primaryIPv4Address",
                           "value":""
                       }
                   ]
               }
           },
           "resultFilter": {
               "children": "",
               "attribute": [
                  "displayedName"
                ]
              }
           };
       }
      return this.getData(searchObject, className, "displayedName");
       }
       this.getInterfaceData = function (neId, interfaceData ,type, name) {
           let nfmpFwk = new NfmpFwk();
           let className = "rtr.NetworkInterface";
           let searchObject = {
           "fullClassName": className,
           "filter": {
               "and": {
                   "equal": [
                       {
                           "name": "nodeId",
                           "value": neId
                       },
                       {
                           "name": name,
                           "value": interfaceData
                       }
                   ]
               }
           },
           "resultFilter": {
               "children": "",
               "attribute": [
                  type
                ]
              }
           };
       let resultFetch = nfmpFwk.post("/v3/search", searchObject);
       let finalResponse = JSON.parse(resultFetch.response);
       let data = (finalResponse[className] && finalResponse[className][type]);
       return data;
       }
     
     this.getData = function (searchObjectJson, className, type) {
        let nfmpFwk = new NfmpFwk();
        let ret = [];
        let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        let finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));
   
        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));
   
        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    ret.push(value[type]);
                })
            }
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

    this.getAdminGroups = function (neId) {
            let className = "rtr.AdminGroupPolicy";
            let searchObject = {
                "fullClassName": className,
                "filter": {
                    "equal": {
                        "name": "siteId",
                        "value": neId
                    }
                },
                "resultFilter": {
                    "children": "",
                    "attribute": [
                        "displayedName",
                        "value"
                    ]
                }
            };
            return this.getAdminGroupPolicyData(searchObject, className, "displayedName", "value")
    }

    this.getAdminGroupPolicyData = function (searchObjectJson, className, type1,type2) {
            var nfmpFwk = new NfmpFwk();
            var ret = [];
            var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
            var finalResponse = JSON.parse(resultFetch.response);
            logger.info("finalResponse = {}",JSON.stringify(finalResponse));

            finalResponse = finalResponse[className];
            logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

            if (finalResponse !== undefined)
            {
                if (!Array.isArray(finalResponse))
                {
                    finalResponse = [finalResponse];
                }
                if (Object.keys(finalResponse).length !== 0)
                {
                    finalResponse.forEach(function (value, index, array) {
                        if(Number(value[type2])<=31)
                        ret.push(value[type1]+"("+value[type2]+")");
                    })
                }
            }

            logger.info("result = {}", JSON.stringify(ret));
            return ret;
    }

    this.getFormattedAdminGroupData = function (values,neId) {
        let className = "rtr.AdminGroupPolicy";

        function createFilterObject(values) {
            return {
                or: {
                equal: values.map(str => ({
                    name: "value",
                    value: str
                }))
                }
            };
        };

        let searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ],
                    "or": createFilterObject(values)["or"]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName",
                    "value"
                ]
            }
        };

        return this.getAdminGroupPolicyData(searchObject, className, "displayedName", "value")
    }
}
   