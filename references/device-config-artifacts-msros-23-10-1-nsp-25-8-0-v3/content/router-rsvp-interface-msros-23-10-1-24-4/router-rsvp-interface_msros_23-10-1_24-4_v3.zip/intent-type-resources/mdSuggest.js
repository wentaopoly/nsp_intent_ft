function MdSuggest() {

   this.getInterfaceName = function (neId, action) {
      logger.info("getInterfaceName ==> neId = {}", neId);
      let url;
      url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base/rsvp/interface?fields=interface-name";
      if(action != "associate")
      {
          url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base/rsvp/interface?fields=interface-name";
      }
      logger.info("getInterfaceName ==> url = {}", url);
      return this.getData(neId, url, "interface-name", "nokia-conf:interface");
   }
   this.getKeyChainName = function (neId) {
      logger.info("getKeyChainName ==> neId = {}", neId);
      const url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/system/security/keychains/keychain";
      return this.getData(neId, url, "keychain-name", "nokia-conf:keychain");
   }

   this.getData = function (neId, url, type, configName) {
      var mdcFwk = new MdcFwk();
      var resultFetch = mdcFwk.fetch(neId, url);
      var finalResponse = resultFetch["msg"][configName];
      const ret = Array.isArray(finalResponse) ? finalResponse.map(Data => Data[type]).filter(value => value != null) : [];
      logger.info("getData() of [" + configName + "] values = \n" + JSON.stringify(ret));
      return ret;
   }
}