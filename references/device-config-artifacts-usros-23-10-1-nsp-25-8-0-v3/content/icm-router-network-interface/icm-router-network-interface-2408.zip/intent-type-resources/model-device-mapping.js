function ModelDeviceMapping()
{
    this.getMapping = function(type)
    {
        switch(type)
        {
            case "networkInterface":
                return this.getInterfaceMapping();
            case "primaryIpAddress":
                return this.getPrimaryIPAddressMapping();
            case "ipAddress":
                return this.getIPAddressMapping();
            case "ipv6Address":
                return this.getIPv6AddressMapping();
            case "bfdConfig":
                return this.getBfdConfigMapping();
            case "bfdV6Config":
                return this.getBfdV6ConfigMapping();
            default:
                return this.getInterfaceMapping();
        }
    }
    this.getInterfaceMapping = function ()
    {
        var mapping = {};
        mapping['interface.description'] = 'description';
        mapping['interface.admin-state'] = 'administrativeState';
        mapping['interface.cpu-protection'] = 'dosProtection';
        mapping['interface.port-binding.port'] = 'portPointer';
        mapping['interface.port-binding.outer-tag'] = 'outerEncapValue';
        mapping['interface.port-binding.inner-tag'] = 'innerEncapValue';
        mapping['interface.port-binding.loopback'] = 'loopbackEnabled';
        mapping['interface.ldp-sync-timer.seconds'] = 'ldpSyncTimer';
        mapping['interface.egress.qos.vlan-qos-policy.policy-name'] = 'egressVlanQosPolicyObjectPointer';
        mapping['interface.egress.qos.egress-remark-policy.policy-name'] = 'egressRemarkPolicyObjectPointer';
        mapping['interface.ingress.qos.network-ingress.policy-name'] = 'networkIngressPolicyObjectPointer';
        mapping['interface.qos.network-policy'] = 'networkPolicyObjectPointer';

        return mapping;
    }

    this.getPrimaryIPAddressMapping = function ()
    {
        var mapping = {};
        mapping['interface.ipv4.primary.address'] = 'ipAddress';
        mapping['interface.ipv4.primary.prefix-length'] = 'prefixLength';

        return mapping;
    }

    this.getIPAddressMapping = function ()
    {
        var mapping = {};
        mapping['interface.ipv4.secondary.address'] = 'ipAddress';
        mapping['interface.ipv4.secondary.prefix-length'] = 'prefixLength';

        return mapping;
    }

    this.getIPv6AddressMapping = function ()
    {
        var mapping = {};
        mapping['interface.ipv6.address.ipv6-address'] = 'ipAddress';
        mapping['interface.ipv6.address.prefix-length'] = 'prefixLength';

        return mapping;
    }

    this.getBfdConfigMapping = function ()
    {
        var mapping = {};
        mapping['interface.ipv4.bfd.admin-state'] = 'adminStatus';
        mapping['interface.ipv4.bfd.transmit-interval'] = 'bfdTxInterval';
        mapping['interface.ipv4.bfd.receive'] = 'bfdRxInterval';
        mapping['interface.ipv4.bfd.multiplier'] = 'bfdMultiplier';
        mapping['interface.ipv4.bfd.type'] = 'bfdTermType';

        return mapping;
    }
    this.getBfdV6ConfigMapping = function ()
    {
        var mapping = {};
        mapping['interface.ipv6.bfd.admin-state'] = 'adminStatus';
        mapping['interface.ipv6.bfd.transmit-interval'] = 'bfdTxInterval';
        mapping['interface.ipv6.bfd.receive'] = 'bfdRxInterval';
        mapping['interface.ipv6.bfd.multiplier'] = 'bfdMultiplier';
        mapping['interface.ipv6.bfd.type'] = 'bfdTermType';

        return mapping;
    }
}
