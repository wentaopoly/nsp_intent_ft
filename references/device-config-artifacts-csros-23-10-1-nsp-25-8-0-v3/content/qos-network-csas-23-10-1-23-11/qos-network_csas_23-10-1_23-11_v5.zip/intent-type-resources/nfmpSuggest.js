load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {

    this.getPolicyId = function (neId, pId, type) {
        var className = "sasqos.Network";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id",
                    "nwPolicyId"
                ]
            }
        };
        var policyFilter = {};
        if (pId && type === "nwPolicyId") {
            policyFilter["name"] = "id";
            policyFilter["value"] = pId;
            searchObject["filter"]["and"]["equal"].push(policyFilter);
        }
        if (pId && type === "id") {
            policyFilter["name"] = "nwPolicyId";
            policyFilter["value"] = pId;
            searchObject["filter"]["and"]["equal"].push(policyFilter);
        }
        return this.getData(neId, searchObject, type, pId);
    }

    this.getSupportAttributePolicyDetails = function (neId, className, ipPrec) {
        var searchObject = {
            "fullClassName": "",
            "filter": {
                "and": {
                    "equal":
                        [
                            {
                                "name": "isLocal",
                                "value": 0
                            },
                            {
                                "name": "isBackup",
                                "value": 0
                            }
                        ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id",
                    "displayedName"
                ]
            }
        };
        switch (className) {
            case "sasqos.MplsLspExpMap":
            case "sasqos.Dot1pClassification":
            case "sasqos.DSCPClassification":
            case "sasqos.MplsLspExpClassification":
            case "sasqos.Remark":
                searchObject["fullClassName"] = className;
                return this.getGlobalData(neId, searchObject, className, false, "id");
            case "sasqos.SlopePolicy":
                searchObject["fullClassName"] = className;
                return this.getGlobalData(neId, searchObject, className, false, "displayedName");
            default:
                logger.info(LOG_PREFIX + "Unknown class name : " + className);
        }
    }

    this.getGlobalData = function (target, searchObjectJson, className, ipPrec, type) {
        let nfmpFwk = new NfmpFwk();
        var result = [];
        var resultFetch = nfmpFwk.find(target, searchObjectJson);
        logger.info(LOG_PREFIX + resultFetch.response);
        var finalResponse = JSON.parse(resultFetch.response)[className];
        logger.info(LOG_PREFIX + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                result.push(finalResponse[index][type])
            }
        }
        logger.info(LOG_PREFIX + "NFMP Global Data suggest result = \n" + JSON.stringify(result));
        return result;
    }

    this.getData = function (target, searchObjectJson, type, policyAttribute) {
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.find(target, searchObjectJson);
        logger.info(LOG_PREFIX + resultFetch.response);
        var finalResponse = JSON.parse(resultFetch.response)["sasqos.Network"];
        logger.info(LOG_PREFIX + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                if (policyAttribute) {
                    logger.info(LOG_PREFIX + "Policy Selected = {}", policyAttribute);
                    logger.info(LOG_PREFIX + "Device policy = {}", finalResponse[index][type]);
                    ret.push(finalResponse[index][type]);
                    break;
                }
                else {
                    ret.push(finalResponse[index][type]);
                }
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "result = \n" + JSON.stringify(ret));
        return ret;
    }
}