function ParseTarget(){

    this.getNeIdFromTarget = function(target){
        if(String(target).indexOf("ne-id") !== -1 ){
            var nedId = target.split("#")[1];
            var result = nedId.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'","").split("=")[1];
            logger.info("NeId = " + result);
            return result;
        }else{
            var neid = target.split("#")[1];
            logger.info("NeId = " + neid);
            return neid;
        }
    }

    this.getPortIdFromTarget = function(target){
        if(String(target).indexOf("ne-id") !== -1 ){
            var tempTarget = target.split("#")[1];
            var portId = tempTarget.match("port=\\S+'")[0].replaceAll("'","").split("=")[1];
            if(String(portId).indexOf("/") == -1){
                var cardId= tempTarget.match("(slot|Slot)=(\\d)+")[0];
                tempTarget = tempTarget.replace(cardId,"");
                cardId = cardId.split("=")[1];
                var mdaId = tempTarget.match("(slot|Slot)=(\\d)+")[0];
                mdaId = mdaId.split("=")[1];
                portId = tempTarget.match("port=(\\d)+")[0].split("=")[1];
                portId =  cardId + "/" +mdaId + "/" + portId;
            }
            return portId;
        }else{
            var portid = target.split("#")[2];
            logger.info("PortId = " + portid);
            return portid;
        }
    }

    this.getUniqueIdentifier = function(target){

        //write code here
        var uniqueIdentifier = target.split("#")[2];
        // replace port for nfmp ports if present
        uniqueIdentifier = uniqueIdentifier.replaceAll("Port ","");
        return uniqueIdentifier;

    }
}