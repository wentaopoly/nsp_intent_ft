function ModelDeviceMapping() {


    this.getMapping = function(type){
        switch(type){
            case "port":
                return this.getPortMapping();
            case "voiceChannel":
                return this.getVoiceChannelMapping();
            case "voiceChannelSpecifics":
                return this.getVoiceChannelSpecificsMapping();
            case "voicePort":
                return this.getVoicePortMapping();
            case "ds0Channel-group":
                return this.getDs0ChannelGroupMapping();
            default:
                return this.getPortMapping();
        }
    }

    this.getPortMapping = function() {
        var mapping = {};

        mapping['port.admin-state'] = 'administrativeState';
        mapping['port.description'] = 'description';

        return mapping;
    }

    this.getVoiceChannelMapping = function() {
        var mapping = {};
        mapping['port.voiceChannel.admin-state'] = 'administrativeState';
        return mapping;
    }

    this.getVoiceChannelSpecificsMapping = function() {
        var mapping = {};
        mapping['port.voiceChannel.signal-mode'] = 'transmissionMode';
        return mapping;
    }

    this.getVoicePortMapping = function() {

        var mapping = {};

        mapping['port.voicePort.tlp-rx'] = 'rxTlp';
        mapping['port.voicePort.tlp-tx'] = 'txTlp';

        return mapping;

    }


    this.getDs0ChannelGroupMapping = function() {
        var mapping = {};
        mapping['port.voiceChannel.ds0Channel-group.channel-group-id'] = 'displayedLocalChannelId';
        mapping['port.voiceChannel.ds0Channel-group.admin-state'] = 'administrativeState';
        mapping['port.voiceChannel.ds0Channel-group.encapType'] = 'encapType';

        return mapping;
    }

}
