function AuditUtil() {
  /**
 * The function is entry point to generate audit report
 * It expect lsh(intentConfig) and rhs(deviceConfig) as object, something like below
 * Example:
 * 
 * intentConfig = {
      port: {
        "port-id": "1/1/1",
        "admin-state": "enable",
        description: "description",
        ethernet: {
          mode: "access",
          "encap-type": "null",
          mtu: 1600,
        },
      },
    };
    deviceConfig = {
      port: {
        "port-id": "1/1/1",
        "admin-state": "enable",
        description: "description",
        ethernet: {
          mode: "access",
          "encap-type": "null",
          mtu: 1600,
        },
      },
    };
 *
 *
 * @param {*} lhs - the intentConfig object
 * @param {*} rhs - the deviceConfig object
 * @param {*} auditReport - the IBN object
 * @param {*} xPath - the root xPath of the intent/nodal config like - "configure"
 * @param {*} deviceYangModuleName - e.g. "nokia-conf" for MD-SROS
 */
  const findDiff = (
    intentConfig,
    deviceConfig,
    auditReport,
    xPath,
    deviceYangModuleName
  ) => {
    // consider the first object, in-case an array is passed
    if (_.isArray(intentConfig)) {
      intentConfig = intentConfig[0];
    }
    if (_.isArray(deviceConfig)) {
      deviceConfig = deviceConfig[0];
    }
    let orignalXPath = xPath;
    let metaDataPath = xPath;
    let metaKeys = null;
    if (_.isObject(intentConfig)) {
      let lhsKeys = Object.keys(intentConfig);
      _.forEach(lhsKeys, (key) => {
        let lhsValue = intentConfig[key];
        let rhsValue = deviceConfig[key];
        if (_.isArray(lhsValue)) {
          // take the first object, this array should have single object
          lhsValue = lhsValue[0];
          rhsValue = rhsValue[0];
        }
        // module reference in the xPath
        if (xPath.endsWith(":")) {
          xPath = xPath !== "" ? `${xPath}${key}` : key;
        } else {
          // append the key in the xPath to make it something like this nokia-conf:/configure/port
          xPath = xPath !== "" ? `${xPath}/${key}` : key;
        }
        // begining hence metaDataPath is xPath
        metaDataPath = xPath;
        // get the key from meta-data.json
        if (isListWithKey(metaDataPath, deviceYangModuleName)) {
          metaKeys = getKeysForList(metaDataPath, deviceYangModuleName);
        }
        if (lhsValue && metaKeys) {
          _.forEach(metaKeys, (metaKey) => {
            if (Object.keys(lhsValue)[0] !== metaKey) {
              // key should be the first key-value in lhs and rhs
              let pickedLhs = _.pick(lhsValue, metaKey);
              lhsValue = _.omit(lhsValue, metaKey);
              lhsValue = _.merge(pickedLhs, lhsValue);

              let pickedRhs = _.pick(rhsValue, metaKey);
              rhsValue = _.omit(rhsValue, metaKey);
              rhsValue = _.merge(pickedRhs, rhsValue);
            }
          });
        }
        // find diff for each top level attribute
        findDiffByKey(
          lhsValue,
          rhsValue,
          auditReport,
          xPath,
          deviceYangModuleName,
          metaKeys,
          metaDataPath
        );
        // reset the xPath
        xPath = orignalXPath;
      });
    }
  };

  /**
   *
   * The function is same as findDiff with additional parameter metaKeys from meta-data.json
   *
   *
   * @param {*} lhs
   * @param {*} rhs
   * @param {*} auditReport
   * @param {*} xPath
   * @param {*} deviceYangModuleName
   * @param {*} metaKeys
   */
  const findDiffByKey = (
    lhs,
    rhs,
    auditReport,
    xPath,
    deviceYangModuleName,
    metaKeys,
    metaDataPath
  ) => {
    // preseve the original xPath so that it can be used in other loops
    // for diffLhsKeys and diffRhsKeys
    let orignalXPath = xPath;
    // first check if lhs are rhs are objects
    if (_.isObject(lhs) && _.isObject(rhs)) {
      let lhsKeys = Object.keys(lhs),
        rhsKeys = Object.keys(rhs);

      // find diff of matching keys, need to return xPath
      xPath = findMatchingDiff(
        lhs,
        rhs,
        lhsKeys,
        rhsKeys,
        auditReport,
        xPath,
        deviceYangModuleName,
        metaKeys,
        metaDataPath
      );

      // find diff of additional attribute from intentConfig
      findLhsDiff(
        lhs,
        lhsKeys,
        rhsKeys,
        auditReport,
        orignalXPath,
        orignalXPath,
        deviceYangModuleName,
        metaDataPath
      );
      // find diff of additional attribute from deviceConfig
      findRhsDiff(
        rhs,
        rhsKeys,
        lhsKeys,
        orignalXPath,
        deviceYangModuleName,
        auditReport,
        metaDataPath
      );
    }
  };

  /**
   *
   * Find diff between matching keys of lhs and rhs
   *
   * @param {*} lhs
   * @param {*} rhs
   * @param {*} lhsKeys
   * @param {*} rhsKeys
   * @param {*} auditReport
   * @param {*} xPath
   * @param {*} deviceYangModuleName
   * @param {*} metaKeys
   */
  const findMatchingDiff = (
    lhs,
    rhs,
    lhsKeys,
    rhsKeys,
    auditReport,
    xPath,
    deviceYangModuleName,
    metaKeys,
    metaDataPath
  ) => {
    let matchingKeys = _.intersection(lhsKeys, rhsKeys);
    // pick only matching one from lhs, rest ignore it
    let pickedRhs = _.pick(rhs, matchingKeys);
    if (matchingKeys.length > 0 && !_.isEqual(lhs, pickedRhs)) {
      _.forEach(matchingKeys, (key) => {
        let obj1Val = lhs[key],
          obj2Val = pickedRhs[key];
        // path = configure/port=1/1/1/description
        let path = `${xPath}/${key}`;
        if (!metaKeys) {
          metaKeys = getKeysForList(metaDataPath, deviceYangModuleName);
        }
        // If the key is the identifier, then we need to append the value in the path.
        if (metaKeys && _.includes(metaKeys, key)) {
          if (!_.isObject(obj1Val) && !_.isArray(obj1Val)) {
            // append the xPath="configure/port=1/1/1"
            if (!_.includes(xPath, obj1Val)) {
              xPath = `${xPath}=${obj1Val}`;
            }
          }
        }
        if (!_.isEqual(obj1Val, obj2Val)) {
          if (
            (_.isBoolean(obj1Val) && _.isBoolean(obj2Val)) ||
            (_.isNumber(obj1Val) && _.isNumber(obj2Val))
          ) {
            path = `${xPath}/${key}`;
            findPrimitiveDiff(
              obj1Val,
              obj2Val,
              auditReport,
              path,
              deviceYangModuleName,
              metaDataPath
            );
            // check empty({}, null, undefined are all empty values)
          } else if (isEmpty(obj1Val)) {
            if (!isEmpty(obj2Val)) {
              let objPath = `${deviceYangModuleName}:/${path}`;
              if (_.isObject(obj2Val)) {
                // since obj1Val is empty, add obj2Val as misalined object with key
                createMisalignedObject(objPath, true, auditReport);
              } else {
                createMisAlignedAttribute(objPath, "-", obj2Val, auditReport);
              }
            }
            // are both arrays
          } else if (_.isArray(obj1Val) && _.isArray(obj2Val)) {
            let pMetaDataPath = `${metaDataPath}/${key}`;
            // assuming the first attribute in the objects are key of the array like entry-id
            // if the above assumption is wrong, we will have to find from the meta-data.json
            findArrayDiff(
              obj1Val,
              obj2Val,
              auditReport,
              path,
              deviceYangModuleName,
              pMetaDataPath
            );
          } else if (_.isObject(obj1Val) && _.isObject(obj2Val)) {
            // check if they are same, then ignore
            // check if their keys length are same. if they have different keys, then we need to compare the
            let areEquals = _.isEqual(obj1Val, obj2Val);
            if (!areEquals) {
              let pMetaDataPath = `${metaDataPath}/${key}`;
              // call recursively
              findDiffByKey(
                obj1Val,
                obj2Val,
                auditReport,
                path,
                deviceYangModuleName,
                metaKeys,
                pMetaDataPath
              );
            }
          } else {
            findPrimitiveDiff(
              obj1Val,
              obj2Val,
              auditReport,
              path,
              deviceYangModuleName,
              metaDataPath
            );
          }
        }
      });
    }
    return xPath;
  };
  /**
   *
   * Find diff for extra attribute on lhs
   *
   * @param {*} lhs
   * @param {*} lhsKeys
   * @param {*} rhsKeys
   * @param {*} orignalXPath
   * @param {*} xPath
   * @param {*} deviceYangModuleName
   * @param {*} auditReport
   */
  const findLhsDiff = (
    lhs,
    lhsKeys,
    rhsKeys,
    auditReport,
    orignalXPath,
    xPath,
    deviceYangModuleName,
    metaDataPath
  ) => {
    let keys = getKeysForList(metaDataPath, deviceYangModuleName);
    xPath = getXPathFromKeys(keys, lhs, xPath);
    let diffLhsKeys = _.difference(lhsKeys, rhsKeys);
    _.forEach(diffLhsKeys, (key) => {
      let lhsvalue = lhs[key];
      let path = `${xPath}/${key}`;
      if (_.isArray(lhsvalue)) {
        metaDataPath = `${metaDataPath}/${key}`;
        let keys = getKeysForList(metaDataPath, deviceYangModuleName);
        findArrayDiff_lhs(
          lhsvalue,
          null,
          auditReport,
          path,
          deviceYangModuleName,
          keys,
          metaDataPath
        );
      } else {
        if (!isEmpty(lhsvalue)) {
          let objPath = `${deviceYangModuleName}:/${path}`;
          if (_.isObject(lhsvalue)) {
            createMisalignedObject(objPath, false, auditReport);
          } else {
            createMisAlignedAttribute(objPath, lhsvalue, "-", auditReport);
          }
        }
      }
    });
  };

  /**
   *
   * Find diff for extra attribute on rhs
   *
   * @param {*} rhs
   * @param {*} rhsKeys
   * @param {*} lhsKeys
   * @param {*} xPath
   * @param {*} deviceYangModuleName
   * @param {*} auditReport
   */
  const findRhsDiff = (
    rhs,
    rhsKeys,
    lhsKeys,
    xPath,
    deviceYangModuleName,
    auditReport,
    metaDataPath
  ) => {
    let keys = getKeysForList(metaDataPath, deviceYangModuleName);
    xPath = getXPathFromKeys(keys, rhs, xPath);
    let diffRhsKeys = _.difference(rhsKeys, lhsKeys);
    _.forEach(diffRhsKeys, (key) => {
      let rhsvalue = rhs[key];
      let path = `${xPath}/${key}`;
      let objPath = `${deviceYangModuleName}:/${path}`;
      if (_.includes(rhsvalue, null)) {
        createMisalignedObject(objPath, true, auditReport);
      } else {
        if (_.isArray(rhsvalue)) {
          createMisalignedObject(objPath, true, auditReport);
        } else if (_.isObject(rhsvalue)) {
          createMisalignedObject(objPath, true, auditReport);
        } else {
          createMisAlignedAttribute(objPath, "-", rhsvalue, auditReport);
        }
      }
    });
  };

  /**
   *
   * @param {*} key
   * @param {*} obj1Val
   * @param {*} obj2Val
   * @param {*} auditReport
   */
  const findPrimitiveDiff = (
    obj1Val,
    obj2Val,
    auditReport,
    xPath,
    deviceYangModuleName
  ) => {
    // if deviceValue is number, intentConfig value also should be number
    if (_.isNumber(obj2Val)) {
      let parsedValue = parseInt(obj1Val);
      obj1Val = isNaN(parsedValue) ? obj1Val : parsedValue;
    }
    // if intentConfig is number, deviceValue value also should be number
    if (_.isNumber(obj1Val)) {
      let parsedValue = parseInt(obj2Val);
      obj2Val = isNaN(parsedValue) ? obj2Val : parsedValue;
    }
    let areEquals = _.isEqual(obj1Val, obj2Val);
    if (!areEquals) {
      let objPath = `${deviceYangModuleName}:/${xPath}`;
      let dd = deepDiff.diff(obj1Val, obj2Val);
      generateAuditReport(dd, auditReport, objPath);
    }
  };

  /**
   *
   * @param {*} lhsArray
   * @param {*} rhsArray
   * @param {*} auditReport
   * @param {*} xPath
   * @param {*} deviceYangModuleName
   */
  const findArrayDiff = (
    lhsArray,
    rhsArray,
    auditReport,
    xPath,
    deviceYangModuleName,
    metaDataPath
  ) => {
    // get the key from meta-data.json
    let keys = getKeysForList(metaDataPath, deviceYangModuleName);
    //  an array without key   
    if (!keys) {
      if (lhsArray.length && rhsArray.length) {
        let lshArrayCopy = _.cloneDeep(lhsArray)
        let rshArrayCopy = _.cloneDeep(rhsArray)
        if (!_.isEqual(lshArrayCopy.sort(), rshArrayCopy.sort())) {
          createMisAlignedAttribute(xPath, lhsArray, rhsArray, auditReport)
        }
        return
      }
    }
    
    findArrayDiff_lhs(
      lhsArray,
      rhsArray,
      auditReport,
      xPath,
      deviceYangModuleName,
      keys,
      metaDataPath
    );
    // now loop over rhs and find the non-matching object and it add as misaligned object

    findArrayDiff_rhs(
      rhsArray,
      lhsArray,
      auditReport,
      xPath,
      deviceYangModuleName,
      keys,
      metaDataPath
    );
  };
  /**
   *
   * @param {*} rhsArray
   * @param {*} lhsArray
   * @param {*} auditReport
   * @param {*} xPath
   * @param {*} deviceYangModuleName
   * @param {*} keys
   */
  const findArrayDiff_rhs = (
    rhsArray,
    lhsArray,
    auditReport,
    xPath,
    deviceYangModuleName,
    keys,
    metaDataPath
  ) => {
    // first get the key for this list
    keys = getKeysForList(metaDataPath, deviceYangModuleName);
    // then get the value from rhs object
    if (_.includes(rhsArray, null)) {
      let objPath = `${deviceYangModuleName}:/${xPath}`;
      createMisalignedObject(xPath, true, auditReport);
    } else if(_.isEmpty(lhsArray)) {
        let objPath = `${deviceYangModuleName}:/${xPath}`;
        createMisalignedObject(objPath, true, auditReport);
    } else {
      _.forEach(rhsArray, function (rhsValue) {
        let rhsKeyValue = null;
        let path = `${xPath}`;
        let lhsValue = null;
        if (keys && keys.length > 1) {
          let rhsWithKey = {}
          let objPath;
          // handle multiple keys also
          if (_.every(keys, (key) => {
            objPath = objPath == null ? `${rhsValue[key]}` : `${objPath},${rhsValue[key]}`;
            rhsWithKey[key] = rhsValue[key]
            return key in rhsValue
          })) {
            rhsValue
          };
          // add the keys in the path
          if( !_.includes(objPath, path)){
            path = `${path}=${objPath}`
          }

          // find rhsValue for matching keys
          lhsArray && _.forEach(lhsArray, function (lhsObj) {
            let lhsWithKey = {}
            _.forEach(keys, (key) => {
              lhsWithKey[key] = lhsObj[key];
            })
            if (_.isEqual(rhsWithKey, lhsWithKey)) {
              lhsValue = lhsObj
            }

          }

          );
        } else {
          if (keys) {
            _.forEach(keys, (key) => {
              path = `${xPath}=${rhsValue[key]}`;
              rhsKeyValue = rhsValue[key];
            });

            _.forEach(keys, (key) => {
              lhsValue = _.find(lhsArray, function (o) {
                return o[key] === rhsKeyValue;
              });
            });
          }
        }
        // matching lhs is not found, hence add rhs as misaligned object
        if (!lhsValue) {
          let objPath = `${deviceYangModuleName}:/${path}`;
          if (_.isObject(rhsValue)) {
            if (!isEmpty(rhsValue)) {
                // lhs values are NOT configured on device, hence second parameter is false
                createMisalignedObject(objPath, true, auditReport);
            }
          } else {
            createMisAlignedAttribute(objPath, "-", rhsValue, auditReport);
          }
        }
      });

    }
  };

  /**
   *
   * @param {*} lhsArray
   * @param {*} rhsArray
   * @param {*} auditReport
   * @param {*} xPath
   * @param {*} deviceYangModuleName
   * @param {*} keys
   */
  const findArrayDiff_lhs = (
    lhsArray,
    rhsArray,
    auditReport,
    xPath,
    deviceYangModuleName,
    keys,
    metaDataPath
  ) => {
    // some speciall handling for value like this [null]
    if (_.includes(lhsArray, null)) {
      let objPath = `${deviceYangModuleName}:/${xPath}`;
      createMisalignedObject(objPath, false, auditReport);
    } else if(_.isEmpty(rhsArray)) {
      let objPath = `${deviceYangModuleName}:/${xPath}`;
      createMisalignedObject(objPath, false, auditReport);
    } else {
      _.forEach(lhsArray, function (lhsValue) {
        let keys = getKeysForList(metaDataPath, deviceYangModuleName);
        let lhsKeyValue = null;
        let path = `${xPath}`;
        let rhsValue = null;
        if (keys && keys.length > 1) {
          let lhsWithKey = {}
          let objPath;
          // handle multiple keys also
          if (_.every(keys, (key) => {
            objPath = objPath == null ? `${lhsValue[key]}` : `${objPath},${lhsValue[key]}`;
            lhsWithKey[key] = lhsValue[key]
            return key in lhsValue
          })) {
            lhsValue
          };
          // add the keys in the path
          if( !_.includes(objPath, path)){
            path = `${path}=${objPath}`
          }
          // find rhsValue for matching keys
          rhsArray && _.forEach(rhsArray, function (rhsObj) {
            let rhsWithKey = {}
            _.forEach(keys, (key) => {
              rhsWithKey[key] = rhsObj[key];
            })
            if (_.isEqual(lhsWithKey, rhsWithKey)) {
              rhsValue = rhsObj
            }
          }
          );
        } else {
          if (keys) {
            _.forEach(keys, (key) => {
              path = `${xPath}=${lhsValue[key]}`;
              lhsKeyValue = lhsValue[key];
            });
          }
          // find the rhsValue for the same key
          _.forEach(keys, (key) => {
            rhsValue = _.find(rhsArray, function (o) {
              return o[key] === lhsKeyValue;
            });
          });
        }
        // check type of object, its attribute should have array to re-curse else generate the diff.
        // if rhs is found in the rhsArray with same key, find the diff
        if (rhsValue && !isEmpty(rhsValue)) {
          let areEquals = _.isEqual(lhsValue, rhsValue);
          if (!areEquals) {
            let objPath = `${deviceYangModuleName}:/${path}`;
            if (_.isArray(lhsValue) && _.isArray(rhsValue)) {
              // TODO
            } else {
              if (_.isObject(lhsValue) && _.isObject(rhsValue)) {
                let metaKeys = null;
                if (isListWithKey(metaDataPath, deviceYangModuleName)) {
                  metaKeys = getKeysForList(metaDataPath, deviceYangModuleName);
                }
                findDiffByKey(
                  lhsValue,
                  rhsValue,
                  auditReport,
                  path,
                  deviceYangModuleName,
                  metaKeys,
                  metaDataPath
                );
              } else {
                let dd = deepDiff.diff(lhsValue, rhsValue);
                generateAuditReport(dd, auditReport, objPath);
              }
            }
          }
        } else {
          if (lhsValue) {
            // generate lhs as misalignedattribute/mislingned object
            let objPath = `${deviceYangModuleName}:/${path}`;
            if (_.isObject(lhsValue)) {
                // lhs values are NOT configured on device, hence second parameter is false
                createMisalignedObject(objPath, false, auditReport);
            } else {
              createMisAlignedAttribute(objPath, lhsValue, "-", auditReport);
            }
          }
        }
      });
    }
  };

  /**
   * Add the diff objects to auditReport
   * @param {*} diff
   * @param {*} auditReport
   */
  const generateAuditReport = (diff, auditReport, xPath) => {
    for (let i = 0; i < diff.length; i++) {
      let diffObj = diff[i];
      // logger.info("diffObj " + JSON.stringify(diffObj));
      let path = xPath;
      if (diffObj["path"]) {
        if (xPath) {
          path = `${xPath}/${diffObj["path"].slice().join("/")}`;
        } else {
          path = diffObj["path"].slice().join("/");
        }
      }
      let expectedValue = diffObj["lhs"];
      let actualValue = diffObj["rhs"];
      let kind = diffObj["kind"];
      // kind E,  indicates a property/element was edited. Match the key on both rhs and lhs but has different value
      // kind N, indicates a newly added property/element on rhs(device)
      // kind D - indicates a property/element was deleted from rhs(device) while present on intent
      // kind A - indicates a change occurred within an array, yet to see Use-case
      if (kind === "E") {
        createMisAlignedAttribute(
          path,
          expectedValue,
          actualValue,
          auditReport
        );
      } else if (kind === "N") {
        // isConfigured will be set as true if rhs has a new object which is missing in the lhs
        if (_.isArray(actualValue)) {
          let len = actualValue.length;
          if (len > 0) {
            createMisalignedObject(path, true, auditReport);
          }
        } else if (_.isObject(actualValue)) {
          if (!isEmpty(actualValue)) {
            createMisalignedObject(path, true, auditReport);
          }
        }
      } else if (kind === "D") {
        // check for array
        if (_.isArray(expectedValue)) {
          let len = expectedValue.length;
          if (len > 0) {
            createMisalignedObject(path, false, auditReport);
          }
        } else if (_.isObject(expectedValue)) {
          // ignore to report empty object {}
          if (!isEmpty(expectedValue)) {
            createMisalignedObject(path, false, auditReport);
          }
        } else {
          createMisAlignedAttribute(path, expectedValue, "—", auditReport);
        }
      }
    }
  };

  /**
   * Creates the misaligned object
   * @param {*} path
   * @param {*} isConfigured
   */
  const createMisalignedObject = (path, isConfigured, auditReport) => {
    let pathExists = false;
    // put a check if path is not there in the auditReport, then only add
    let existingMisalignedObjects = auditReport && auditReport.report && auditReport.report.misalignedObject &&  auditReport.report.misalignedObject;
    existingMisalignedObjects && existingMisalignedObjects.forEach((misalignedObj) => {
      misalignedObj && misalignedObj["MisAlignedObject"] && misalignedObj["MisAlignedObject"].forEach(obj => {
        if (obj["objectId"] === path) {
          pathExists = true;
        }
      })
    })
    // avoid adding duplicate path in the auditReport
    if (!pathExists) {
      let misalignedObject = auditFactory.createMisAlignedObject(
        path,
        isConfigured
      );
      auditReport.addMisAlignedObject(misalignedObject);
    }
  };

  /**
   *
   * @param {*} path
   * @param {*} expectedValue
   * @param {*} actualValue
   * @param {*} auditReport
   */
  const createMisAlignedAttribute = (
    path,
    expectedValue,
    actualValue,
    auditReport
  ) => {
    // remove modfule if expectedValue contains moduleReference (typically in SRL)
    if(!(path.endsWith("authentication-key") || path.endsWith("md5")))
    {
      expectedValue = getValue(expectedValue)
      actualValue = getValue(actualValue)
      if (expectedValue !== actualValue) {
        let misAlignedAttr = auditFactory.createMisAlignedAttribute(
            path,
            expectedValue,
            actualValue
        );
        auditReport.addMisAlignedAttribute(misAlignedAttr);
      }
    }
  };

  /**
   * get the keys from meta-data.json file for list
   * @param {*} xPath
   * @returns
   */
  const getKeysForList = (xPath, deviceYangModuleName) => {
    if (_.isUndefined(deviceYangModuleName)) {
      throw new Error("deviceYangModuleName is null");
    }
    //TODO, can be removed
    let path = replacePortLikeValue(xPath);
    if (!_.includes(xPath, deviceYangModuleName)) {
      path = `${deviceYangModuleName}:/${path}`;
    }
    // TODO, can be removed
    path = getMetaDataPath(path);
    let keys = metadata && metadata[path] && metadata[path]["keys"];
    if (keys && typeof keys === "string") {
      keys = keys.split(",");
    }
    return keys;
  };

  /**
   * check if the xPath is a list with keys from meta-data.json file for container
   * "isList": true,
   * "isListWithKey": true
   * @param {*} xPath
   * @returns
   */
  const isListWithKey = (xPath, deviceYangModuleName) => {
    if (_.isUndefined(deviceYangModuleName)) {
      throw new Error("deviceYangModuleName is null");
    }
    let path = replacePortLikeValue(xPath);
    if (!_.includes(xPath, deviceYangModuleName)) {
      path = `${deviceYangModuleName}:/${xPath}`;
    }
    path = getMetaDataPath(path);
    let isTrue = metadata && metadata[path] && metadata[path]["isListWithKey"];
    if (!isTrue) {
      isTrue = isNodeTypeList(xPath, deviceYangModuleName);
    }
    return isTrue;
  };

  /**
   * check if the xPath is a list nodeType from meta-data.json file for container
   * @param {*} xPath
   * @param {*} deviceYangModuleName
   * @returns
   */
  const isNodeTypeList = (xPath, deviceYangModuleName) => {
    if (_.isUndefined(deviceYangModuleName)) {
      throw new Error("deviceYangModuleName is null");
    }
    let path = replacePortLikeValue(xPath);
    if (!_.includes(xPath, deviceYangModuleName)) {
      path = `${deviceYangModuleName}:/${xPath}`;
    }
    path = getMetaDataPath(path);
    return metadata && metadata[path] && metadata[path]["nodeType"] === "list"
      ? true
      : false;
  };

  /**
   * Get appended xPath from keys
   * @param {*} keys
   * @param {*} rhs
   * @param {*} xPath
   */
  const getXPathFromKeys = (keys, obj, xPath) => {
    if (keys) {
      _.forEach(keys, (key) => {
        let value = obj[key];
        // check if xPath contains the value at the end
        let lastValue = xPath.substring(xPath.lastIndexOf("=") + 1, xPath.length)
        if (value != lastValue) {
          if( !_.includes(xPath, value)){
            xPath = `${xPath}=${obj[key]}`;
          }
        }
      });
    }
    return xPath;
  };

  /**
   *
   * @param {*} path
   * @returns
   */
  const replacePortLikeValue = (path) => {
    const regex = /=\d+\/[^/]+\/\d+/g;
    const regex_ethernet_like = /=ethernet-1\/1\b|\b1\/1\/1\b/g;
    let newPath = path.replace(regex, "");
    newPath = newPath.replace(regex_ethernet_like, "");
    return newPath;
  };

  /**
   *
   *
   * @param {*} path
   * @returns
   */
  const getMetaDataPath = (path) => {
    const pattern = /=[^/]+/g;
    return path.replace(pattern, "");
  };

  /**
   * Check empty objects
   * @param {*} obj
   * @returns
   */
  function isEmpty(obj) {
    if (_.isObject(obj)) {
      if (Object.keys(obj).length === 0) return true;
      return _.every(_.map(obj, (v) => isEmpty(v)));
    } else if (obj === "string") {
      return !obj.length;
    }
    return false;
  }


  /**
   * remove moduleRef in the value
   * @param {*} key 
   * @param {*} value 
   * @param {*} deviceConf 
   */
  const getValue = (value) => {
    if (_.includes(value, ":")) {
        if(_.includes(value, "srl_")){
          value = value.substring(value.indexOf(value.split(":")[1]))
        }
      }
    return value;
  }

  this.getKeysForList = getKeysForList;
  this.findDiff = findDiff;
  this.getValue = getValue;
}
// hackish way to use AuditUtil in test, due to non-support of export in IM
testAuditUtil = AuditUtil;