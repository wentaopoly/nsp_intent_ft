load({ script: resourceProvider.getResource("nfmpSuggest.js"), name: "NfmpSuggest" });
function transformData() {
    const nfmpSuggest = new NfmpSuggest();
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        let interfaceData;
        if(intentConfig.interfaceId){
            interfaceData = nfmpSuggest.getInterfaceData(neId, intentConfig.interfaceId, "id", "displayedName");
            objectFullName = objectFullName.replace(/interface-[^:]+/, "interface-"+interfaceData);
        }
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        let interfaceData;
        let interfaceName = uniqueIdentifierValues[0];
        if(interfaceName){
            interfaceData = nfmpSuggest.getInterfaceData(neId, interfaceName, "id", "displayedName");
            objectFullName = objectFullName.replace(/interface-[^:]+/, "interface-"+interfaceData);
        }
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        if (payload.configInfo)
        {
            if (payload.configInfo["rsvp.Interface"])
            {
                let rsvpInterface = payload.configInfo["rsvp.Interface"];
                if (rsvpInterface.interfaceId)
                {
                    let interfaceData = nfmpSuggest.getInterfaceData(neId, rsvpInterface.interfaceId, "id", "displayedName");
                    rsvpInterface.interfaceId = interfaceData;
                }
                if(rsvpInterface["inheritGlobalCtBw"] == true)
                {
                    delete rsvpInterface["ct0BwPercent"];
                    delete rsvpInterface["ct1BwPercent"];
                    delete rsvpInterface["ct2BwPercent"];
                    delete rsvpInterface["ct3BwPercent"];
                    delete rsvpInterface["ct4BwPercent"];
                    delete rsvpInterface["ct5BwPercent"];
                    delete rsvpInterface["ct6BwPercent"];
                    delete rsvpInterface["ct7BwPercent"];
                }
                if(rsvpInterface["children-Set"] && rsvpInterface["children-Set"]["rsvp.TeThresholds"])
                {
                    let rsvpTeThresholds = rsvpInterface["children-Set"]["rsvp.TeThresholds"];
                    let inheritTeUpThresholdsCheck = false;
                    let inheritTeDownThresholdsCheck = false;
                    if(isAudit)
                    {
                        let rsvpTeThresholdsObj = nfmpSuggest.getInheritTeThresholds(neId, rsvpInterface["interfaceId"]);
                         if(rsvpTeThresholds["inheritTeUpThresholds"] == false && (rsvpTeThresholdsObj["inheritTeUpThresholds"] === "true") == true)
                         {
                            inheritTeUpThresholdsCheck = true;
                         }
                         if(rsvpTeThresholds["inheritTeDownThresholds"] == false && (rsvpTeThresholdsObj["inheritTeDownThresholds"] === "true") == true)
                          {
                             inheritTeDownThresholdsCheck = true;
                          }
                    }
                    if(rsvpTeThresholds["inheritTeUpThresholds"] == true || (isAudit && inheritTeUpThresholdsCheck))
                    {
                        delete rsvpTeThresholds["teThresholdLevelUp1"];
                        delete rsvpTeThresholds["teThresholdLevelUp2"];
                        delete rsvpTeThresholds["teThresholdLevelUp3"];
                        delete rsvpTeThresholds["teThresholdLevelUp4"];
                        delete rsvpTeThresholds["teThresholdLevelUp5"];
                        delete rsvpTeThresholds["teThresholdLevelUp6"];
                        delete rsvpTeThresholds["teThresholdLevelUp7"];
                        delete rsvpTeThresholds["teThresholdLevelUp8"];
                        delete rsvpTeThresholds["teThresholdLevelUp9"];
                        delete rsvpTeThresholds["teThresholdLevelUp10"];
                        delete rsvpTeThresholds["teThresholdLevelUp11"];
                        delete rsvpTeThresholds["teThresholdLevelUp12"];
                        delete rsvpTeThresholds["teThresholdLevelUp13"];
                        delete rsvpTeThresholds["teThresholdLevelUp14"];
                        delete rsvpTeThresholds["teThresholdLevelUp15"];
                        delete rsvpTeThresholds["teThresholdLevelUp16"];
                    }
                    if(rsvpTeThresholds["inheritTeDownThresholds"] == true || (isAudit && inheritTeDownThresholdsCheck))
                    {
                        delete rsvpTeThresholds["teThresholdLevelDown1"];
                        delete rsvpTeThresholds["teThresholdLevelDown2"];
                        delete rsvpTeThresholds["teThresholdLevelDown3"];
                        delete rsvpTeThresholds["teThresholdLevelDown4"];
                        delete rsvpTeThresholds["teThresholdLevelDown5"];
                        delete rsvpTeThresholds["teThresholdLevelDown6"];
                        delete rsvpTeThresholds["teThresholdLevelDown7"];
                        delete rsvpTeThresholds["teThresholdLevelDown8"];
                        delete rsvpTeThresholds["teThresholdLevelDown9"];
                        delete rsvpTeThresholds["teThresholdLevelDown10"];
                        delete rsvpTeThresholds["teThresholdLevelDown11"];
                        delete rsvpTeThresholds["teThresholdLevelDown12"];
                        delete rsvpTeThresholds["teThresholdLevelDown13"];
                        delete rsvpTeThresholds["teThresholdLevelDown14"];
                        delete rsvpTeThresholds["teThresholdLevelDown15"];
                        delete rsvpTeThresholds["teThresholdLevelDown16"];
                    }
                }
            }
        }
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        if (xpath === "rsvp-AuthenticationKey.authKeychain") {
            if (targetValue !== undefined && !targetValue.startsWith("KeyChain:"))
            {
                targetValue = "KeyChain:" + targetValue;
            }
        }
        if(isAudit == true)
        {
            if (xpath === "rsvp-AuthenticationKey.key") {
                targetValue = "";
            }
        }
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig) {
        if (xpath === "rsvp-AuthenticationKey.authKeychain") {
            if (targetValue !== undefined && targetValue.startsWith("KeyChain:"))
            {
                targetValue = targetValue.replace("KeyChain:", "");
            }
        }
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
}