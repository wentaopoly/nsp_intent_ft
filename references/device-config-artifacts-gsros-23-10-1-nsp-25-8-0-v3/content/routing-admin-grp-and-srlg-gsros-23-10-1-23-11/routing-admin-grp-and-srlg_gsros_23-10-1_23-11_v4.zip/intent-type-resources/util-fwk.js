load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {

  this.setSuccessResult = function (result,savedTopology) {
    result.setSuccess(true);
    if (savedTopology !== undefined){
      result.setTopology(savedTopology);
    }
    return result;
  }

  this.delay = function (milliseconds) {
    var date = new Date();
    date.setMilliseconds(date.getMilliseconds() + milliseconds);
    while (new Date() < date)
    {
    }
  }

  this.xml2object = function (xmlElement) {
    var lXml = Java.type("org.json.XML");
    var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
    var serializer = lsImpl.createLSSerializer();
    serializer.getDomConfig().setParameter("xml-declaration", false);
    var str = serializer.writeToString(xmlElement);
    var json = lXml.toJSONObject(str).toString();
    return JSON.parse(json);
  }


  this.reportMisaligned = function (target, result, auditReport) {
    var report = result;
    if (!report.aligned)
    {
      for (var i = 0; i < report.misalignedAttributes.length; i++)
      {
        var attributeData = report.misalignedAttributes[i];
        if (attributeData.expected == "present")
        {
          //misaligned object
          var objectDn = attributeData.name;
          var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
          auditReport.addMisAlignedObject(misalignedObject);
        }
        else if (attributeData.expected == "not present")
        {
          //undesired object
          var objectDn = attributeData.name;
          var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
          auditReport.addMisAlignedObject(misalignedObject);
        }
        else
        {
          var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
          auditReport.addMisAlignedAttribute(misalignedAttribute);
        }

      }
    }
    return auditReport
  }

  this.isObjectExists = function (className, objectFullName) {
    let nfmpFwk = new NfmpFwk();
    var ret = false;
    var searchObjectJson = {
      "fullClassName": className,
      "filter": {
        "equal": {
          "name": "objectFullName",
          "value": objectFullName
        }
      }
    };
    var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);

    var finalResponse = JSON.parse(resultFetch.response);
    logger.info("Final response of search = {}", JSON.stringify(finalResponse));
    if (Object.keys(finalResponse).length !== 0 && finalResponse.constructor === Object)
    {
      ret = true;
    }
    logger.info("isObjectExists = {} ", ret);
    return ret;
  }

  this.distribute = function (neId, intentConfig, isLocalEdit, objectFullName) {
    var payload = {};
    var policyDefination = "policy.PolicyDefinition.distributeV2";
    if (isLocalEdit)
    {
      policyDefination = "policy.PolicyDefinition.setDistributionModeToLocalEditOnly";
    }
    payload[policyDefination] = {};
    payload[policyDefination]["clearOnDeployFailure"] = true;
    payload[policyDefination]["deployer"] = "immediate";
    payload[policyDefination]["instanceFullName"] = objectFullName;
    payload[policyDefination]["siteIds"] = {};
    payload[policyDefination]["siteIds"]["string"] = neId;
    return payload;
  }

  this.editPayload = function (fdn, properties, childProperties, fullClassName, objectFullName) {
    var payload = {};
    var configInfo = {};
    configInfo[fullClassName] = properties;
    configInfo[fullClassName]["children-Set"] = childProperties;
    payload["distinguishedName"] = fdn;
    payload["objectFullName"] = objectFullName;
    payload["clearOnDeployFailure"] = true;
    payload["configInfo"] = configInfo;
    return payload;
  }

    this.modifyNeIdForIpV6 = function (objectFullName, neId) {
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }
}
