function utilities() {
  this.setErrorResult = function (result) {
    result.setSuccess(false);
    result.setErrorCode(100);
    result.setErrorDetail("failed To set Topology.");
    return result
  }
  
  this.setSuccessResult = function (result,savedTopology) {
    result.setSuccess(true);
    if (savedTopology !== undefined){
      result.setTopology(savedTopology);
    }
    return result;
  }
  
  this.payloadBuilder = function (target,card,type) {
    if(type === "create_card"){
      var payload = {
          fdn:"network:"+target+":shelf-1:cardSlot-"+card["slot-number"] ,
          slotId:card["slot-number"],
          specificType:"card_" + card["card-type"].split('-').join('_'),    
       } 
      return payload
    }
    if(type === "edit_card"){
      var payload = {
        fdn:"network:"+target+":shelf-1:cardSlot-"+card["slot-number"],
        objectFullName:"network:"+target+":shelf-1:cardSlot-"+card["slot-number"],
        cardPowerSave:card["power-save"],
        cardAssignedLevel:card["level"],
        resetOnRecoverableError:card["reset-on-recoverable-error"],
      }
      if ( card["fail-on-error"] ){
        payload["failOnError"]=card["fail-on-error"]
      }
      if(card["admin-state"]=== "enable"){
        payload["administrativeState"]="inService"
      }
      else{
        payload["administrativeState"]="outOfService"
      }
      return payload
    }
    
    if(type === "create_mda"){
      var mda =card.mda
      var payload = {
        fdn:"network:"+target+":shelf-1:cardSlot-"+card["slot-number"]+":card:daughterCardSlot-"+mda["mda-slot"],
        slotId:card["slot-number"] ,
        daughterCardSlotId: mda["mda-slot"],
        specificType: "mda_" + mda["mda-type"].split('-').join('_')
      }
      if(mda["admin-state"]=== "enable"){
        payload["administrativeState"]="inService"
      }
      else{
        payload["administrativeState"]="outOfService"
      }
      return payload
    }
    
    if(type === "edit_mda"){
      var mda =card.mda
      var payload = {
        objectFullName:"network:"+target+":shelf-1:cardSlot-"+card["slot-number"]+":card:daughterCardSlot-"+mda["mda-slot"]+":daughterCard",
      }
      if(mda["admin-state"]=== "enable"){
        payload["administrativeState"]="inService"
      }
      else{
        payload["administrativeState"]="outOfService"
      }
      return payload
    }
    
    if(type === "scheduler_body"){
      var schedulerAdjustment=card["virtual-scheduler-adjustment"]
      var payload = {
        objectFullName:"network:"+target+":shelf-1:cardSlot-"+card["slot-number"]+":VrSchAdj",
        rateCalcfastMinInt:schedulerAdjustment["interval"]["rate-calculation-minimum"]["fast-queue"].toFixed(1),
        taskSchedInt: schedulerAdjustment["interval"]["task-scheduling"].toFixed(1),
        schedRunMinInt:schedulerAdjustment["interval"]["rate-calculation-minimum"]["slow-queue"].toFixed(1),
        rateCalcslowMinInt:schedulerAdjustment["interval"]["scheduler-run-minimum"].toFixed(1),
        slowQueueThresh:schedulerAdjustment["slow-queue-threshold-rate"]
      }
      var mode = schedulerAdjustment["internal-scheduler-weight-mode"]
      if(mode === "auto"){
        payload["internalSchedWeightMode"] = "default"
      }
      if(mode==='force-equal'){
        payload["internalSchedWeightMode"] = "forceEqual"
      }
      if(mode==='offered-load'){
        payload["internalSchedWeightMode"] = "offeredLoad"
      }
      if(mode==="capped-offered-load"){
        payload["internalSchedWeightMode"] = "cappedOfferedLoad"
      }
      return payload
    } 
    
    if (type === "audit_card"){
      var payload = [
        {
          fdn:"network:"+target+":shelf-1:cardSlot-"+card["slot-number"]+":card" ,
          objectFullName:"network:"+target+":shelf-1:cardSlot-"+card["slot-number"]+":card",
          slotId:card["slot-number"],
          specificType:"card_" + card["card-type"].split('-').join('_')
        },{
          fdn:"network:"+target+":shelf-1:cardSlot-"+card["slot-number"] ,
          objectFullName:"network:"+target+":shelf-1:cardSlot-"+card["slot-number"],
          //cardPowerSave:card["power-save"].toString(),
          cardAssignedLevel:card["level"],
          //resetOnRecoverableError:card["reset-on-recoverable-error"].toString(),
        } 
      ]
      if ( card["fail-on-error"] ){
       payload[1]["failOnError"]=card["fail-on-error"]
      }
      if(card["admin-state"]=== "enable"){
        payload[1]["administrativeState"]="inService"
      }
      else{
        payload[1]["administrativeState"]="outOfService"
      }
     return payload
    }
    
    
    if (type === "audit_mda"){
      var mda =card.mda
      var payload = {
        fdn:"network:"+target+":shelf-1:cardSlot-"+card["slot-number"]+":card:daughterCardSlot-"+mda["mda-slot"]+":daughterCard" ,
        objectFullName:"network:"+target+":shelf-1:cardSlot-"+card["slot-number"]+":card:daughterCardSlot-"+mda["mda-slot"]+":daughterCard" ,
        slotId:card["slot-number"] ,
        daughterCardSlotId: mda["mda-slot"],
        specificType: "mda_" + mda["mda-type"].split('-').join('_'),
      }
      if(mda["admin-state"]=== "enable"){
        payload["administrativeState"]="inService"
      }
      else{
        payload["administrativeState"]="outOfService"
      }
      return payload
    }
  }

  this.xml2object = function (xmlElement) {
    var lXml = Java.type("org.json.XML");
    var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
    var serializer = lsImpl.createLSSerializer();
    serializer.getDomConfig().setParameter("xml-declaration", false);
    var str = serializer.writeToString(xmlElement);
    var json = lXml.toJSONObject(str).toString();
    return JSON.parse(json);
  }
  
  this.metaData = function (target, response , card, savedTopology) {
    var configurationResponse = JSON.parse(response);
    if (configurationResponse != null && configurationResponse.objectFullName != null) {
        var objectFullName = "network:"+target+":shelf-1:cardSlot-"+card["slot-number"]
        if (target && String(target).indexOf(':') !== -1) {
            objectFullName = this.modifyNeIdForIpV6(objectFullName, target);
        }
        var mdaFullName = "network:"+target+":shelf-1:cardSlot-"+card["slot-number"]+":card:daughterCardSlot-"+card["mda"]["mda-slot"]
        if (target && String(target).indexOf(':') !== -1) {
            mdaFullName = this.modifyNeIdForIpV6(mdaFullName, target);
        }
        var topoValue = [card["card-type"],mdaFullName,card["mda"]["mda-type"]]
        var xtraInfo = topologyFactory.createTopologyXtraInfoFrom(objectFullName, topoValue);
        xtraInfo.setTarget(target);
        xtraInfo.setIntentType("Classic_Card_Conf");
        savedTopology.addXtraInfo(xtraInfo);
    }
    return savedTopology
  }

  this.getRequestType = function (card, savedTopology,target){
    var fdn = "network:"+target+":shelf-1:cardSlot-"+card["slot-number"]
    if (target && String(target).indexOf(':') !== -1) {
        fdn = this.modifyNeIdForIpV6(fdn, target);
    }
    var specificType = this.extractInfo(savedTopology,fdn,0)
    if (specificType === undefined){
      return "create"
    }
    else if(specificType !== card["card-type"]) {
      return "replace"
    }
    else 
      return "edit"
  }
  
  this.getMdaRequestType = function (card, savedTopology,target){  
    var fdn = "network:"+target+":shelf-1:cardSlot-"+card["slot-number"]
    if (target && String(target).indexOf(':') !== -1) {
        fdn = this.modifyNeIdForIpV6(fdn, target);
    }
    var mdaType = this.extractInfo(savedTopology,fdn,2)
    if (mdaType === undefined){
      return "create"
    }
    else if(mdaType !== card["mda"]["mda-type"]) {
      return "replace"
    }
    else 
      return "edit"
  }

  this.extractInfo = function (topology, key,i) {
    var values;
    if (topology != null && topology.getXtraInfo() != null) {
        topology.getXtraInfo().forEach(function (extraInfo) {
            if (extraInfo.getKey() == key) {
                var value = extraInfo.getValue();
                values = value.split(",")
                
            }
        });
    }
    
    if (values === undefined)
      return values
    else
      return values[i];
  }
  
  this.reportMisaligned = function (target,result, auditReport){
   var report = JSON.parse(result.response);
    if (!report.aligned) {
      for (var i = 0; i < report.misalignedAttributes.length; i++) {
          var attributeData = report.misalignedAttributes[i];
          var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
          auditReport.addMisAlignedAttribute(misalignedAttribute);
          
      }
    }
    return auditReport
  }
  
  this.updatecCardDelete = function (target,savedTopology,cardList) {
    var topologyXtraInfo = savedTopology.getXtraInfo()
        
    var newTopology = topologyFactory.createServiceTopology();
    newTopology.setTarget(target)
    newTopology.setIntentType("classic_card_conf_lv_2_with_nfmp_fwk");
    var deletedCardList = []
    var j = 0;
    var cardsDeleted = false
    for( var i = 0; i < cardList.length ; i++ ) {       
      var objectFullName = "network:"+target+":shelf-1:cardSlot-"+cardList[i]["slot-number"];
      if (target && String(target).indexOf(':') !== -1) {
          objectFullName = this.modifyNeIdForIpV6(objectFullName, target);
      }
      var card=cardList[i]
      if(topologyXtraInfo[j].getKey() !== objectFullName) {
        while (j<topologyXtraInfo.length){
          deletedCardList.push(topologyXtraInfo[j].getKey()+":card")
          cardsDeleted = true
          j++
          if(topologyXtraInfo[j].getKey() === objectFullName) {
            i--
            break
          }
        }
      }      
      
      else {
          var objectFullName = "network:"+target+":shelf-1:cardSlot-"+card["slot-number"]
          if (target && String(target).indexOf(':') !== -1) {
            objectFullName = this.modifyNeIdForIpV6(objectFullName, target);
          }
        var mdaFullName = "network:"+target+":shelf-1:cardSlot-"+card["slot-number"]+":card:daughterCardSlot-"+card["mda"]["mda-slot"]
        if (target && String(target).indexOf(':') !== -1) {
            mdaFullName = this.modifyNeIdForIpV6(mdaFullName, target);
        }
        var topoValue = [card["card-type"],mdaFullName,card["mda"]["mda-type"]]
        var xtraInfo = topologyFactory.createTopologyXtraInfoFrom(objectFullName, topoValue);
        xtraInfo.setTarget(target);
        xtraInfo.setIntentType("Classic_Card_Conf");
        newTopology.addXtraInfo(xtraInfo) 
          j++
      }
    }
    var result = {
      newTopology:newTopology,
      deletedCardList:deletedCardList,
      cardsDeleted:cardsDeleted
    }
    log.info(null,"/n/n/n[Util-fwk] : Got result for updatecCardDelete :  "+ result.newTopology+JSON.stringify(result))
    return result
  }

  this.getBaseFdnForPort = function (target, portId) {
    if(portId.startsWith("esat"))
    {
      return this.getBaseFdnForSatellitePort(target,portId);
    }
    var portIds = portId.split("/");
    var cardSlot;
    var xiomSlot;
    var mdaSlot;
    var connector;
    var portNumber

    portIds.forEach(function (item, index) {
      // logger.info("*********************item, index = " + item + "-----" + index);
      switch (index)
      {
        case 0:
          cardSlot = item;
          break;
        case 1:
          //xiom
          if (isNaN(item))
          {
            xiomSlot = item;
          }
          else
          {
            mdaSlot = item;
          }
          break;
        case 2:
          //connector
          if (isNaN(item))
          {
            connector = item;
          }
          else if(mdaSlot)
          {
            portNumber = item;
          }
          else
          {
            mdaSlot = item;
          }
          break;
        case 3:
          //connector
          if (isNaN(item))
          {
            connector = item;
          }
          else
          {
            portNumber = item;
          }
          break;
        case 4:
          portNumber = item;
          break;


      }
    });

    // logger.info("************ cardSlot =" + cardSlot + ",xiomSlot=" + xiomSlot + ",mdaSlot=" + mdaSlot + ",connector=" + connector + ",portNumber=" + portNumber);
    //"network:92.168.96.22:shelf-1:cardSlot-1:card:xioSlot-1:xiomCard:daughterCardSlot-1:daughterCard:conn-1:port-1"

    var portDn = "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card";
    if (xiomSlot)
    {
      portDn += ":xioSlot-" + xiomSlot.substring(1) + ":xiomCard";
    }
    if (mdaSlot)
    {
      portDn += ":daughterCardSlot-" + mdaSlot + ":daughterCard";
    }
    if (connector)
    {
      portDn += ":conn-" + connector.substring(1);
    }
    if (portNumber)
    {
      portDn += ":port-" + portNumber;
    }
    if (target && String(target).indexOf(':') !== -1) {
      portDn = this.modifyNeIdForIpV6(portDn, target);
    }
    logger.info("*********************portDn = " + portDn);
    return portDn;
    //return "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card:daughterCardSlot-" + mdaSlot + ":daughterCard:port-" + portNumber;
  }

  this.getBaseFdnForSatellitePort = function (target, portId) {

    var portIds = (portId.split("-")[1]).split("/");
    var shelf = "shelf-1-5-";
    shelf += portIds[0];
    var satId =portIds[0];
    var cardSlot = "cardSlot-1:card" ;
    var mdaSlot = "daughterCardSlot-1:daughterCard";
    var portNumber = portIds[2];
    var snmpPortId = this.getSatellitePortSnmpId(satId,1,portNumber,false,5)
    //logger.info("******satellite port = shelf = "+shelf+", portnumber = "+portNumber +"\n portid = "+ portId+"\n portids = "+ portIds);
    var portDn = "network:" + target + ":"+shelf+":" + cardSlot +":" +mdaSlot+":port-"+snmpPortId ;
    if (target && String(target).indexOf(':') !== -1) {
         portDn = this.modifyNeIdForIpV6(portDn, target);
    }
    logger.info("SatPortDN = " + portDn);
    return portDn;
  }

  this.getSatellitePortSnmpId = function (aInSatId,aInSlotId, aInPortId, aInUplink, aInPhyShelfClass){
      var aInSnmpIndex = aInPortId;
      var lUplinkBit = 0;
      if(aInUplink)
      {
        lUplinkBit = 1;
      }
      var lSatId = aInSatId << 16;
      var lSlotId = aInSlotId << 11;
      var lUplink = lUplinkBit << 10;
      var lSat = 136 << 23;
      aInSnmpIndex = lSat | lSatId | lSlotId | lUplink | aInSnmpIndex;
      return aInSnmpIndex;
  }
  
  this.editPayload = function(fdn,properties,fullClassName,objectFullName){
    
    var payload  = {};
    var configInfo = {};
    configInfo["containedClassProperties"] = properties;
    configInfo["objectClassName"] = fullClassName;
    // payload["fdn"] = fdn;
    payload["distinguishedName"] = fdn;
    payload["objectFullName"] = objectFullName,
    payload["configInfo"] = configInfo;
    return payload;
    
  }

  this.modifyNeIdForIpV6 = function (objectFullName, neId) {
     logger.info("modifying NeId For IpV6");
     objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
     return objectFullName;
  }
}
