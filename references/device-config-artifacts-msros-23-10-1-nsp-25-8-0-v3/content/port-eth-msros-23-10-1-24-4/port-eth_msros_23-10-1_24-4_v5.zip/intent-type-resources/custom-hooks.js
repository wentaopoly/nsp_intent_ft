load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
load({script: resourceProvider.getResource("parse-target.js"), name: "ParseTarget"});
load({script: resourceProvider.getResource('mdSuggest.js'), name: "MdSuggest"});

function CustomHooks() {
    var mdSuggest = new MdSuggest();
    /**
     * PreAudit Hook
     */
    const preAudit = (inputObj) => {
        /**
         * Write your custom preAudit logic here
         * inputObj by default contains the following keys:
         *          target, intentConfig, svcTopo, adminState,
         *          intentTypeName, rootXPath, intentContainer,
         *          uniqueIdentifier, deviceYangModuleName
         *
         */

        logger.info("[CUSTOM-HOOKS] preAudit call");
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
        var target = inputObj["target"];
        var intentConfig = inputObj["intentConfig"];

        logger.info("preAudit call for Port MD intent config deviation");
        var intentDeviationObj = new IntentDeviceDeviation();
        var neId = parseTarget.getNeIdFromTarget(target);
        if(!isOtuSupported(target))
        {
            delete intentConfig["otu"];
        }
        intentConfig = intentDeviationObj.removeIntentConfig(JSON.stringify(intentConfig), neId);
        logger.info("preAudit intent config after removing deviation attributes: " + JSON.stringify(intentConfig));
        return intentConfig;
    };

    /**
     * PostAudit Hook
     */
    const postAudit = (inputObj) => {
        /**
         * Write your custom postAudit logic here
         * inputObj by default contains the following keys:
         *          target, intentConfig, svcTopo, adminState,
         *          intentTypeName, rootXPath, intentContainer,
         *          uniqueIdentifier, deviceYangModuleName, auditReport
         *
         */

        logger.info("[CUSTOM-HOOKS] postAudit call");
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));


    };

    /**
     * PreSync Hook
     */
    const preSync = (inputObj) => {
        /**
         * Write your custom preSync logic here
         * inputObj by default contains the following keys:
         *          target, config, intentTypeName, rootXPath,
         *          intentContainer, uniqueIdentifier, deviceYangModuleName
         *          topology, state, syncResult
         */
        logger.info("[CUSTOM-HOOKS] preSync call");
        var config = JSON.parse(inputObj["config"]);
        //logger.info("[CUSTOM-HOOKS] config = {}",JSON.stringify(config));
        //logger.info("[CUSTOM-HOOKS] ========================================================");
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

        var target = inputObj["target"];
        var intentTypeName = inputObj["intentTypeName"];
        var intentContainer = inputObj["intentContainer"];
        var intentDeviationObj = new IntentDeviceDeviation();
        var neId = parseTarget.getNeIdFromTarget(target);
        if (!Array.isArray(config)) {
            config = [config];
        }
        let preSyncConf = [];
        for (var index in config) {
            var confObj= config[index][intentTypeName + ":" + intentTypeName][intentContainer];
            if (confObj["ethernet"]["mode"] !== undefined ){
                let ethernetMode = confObj["ethernet"]["mode"];
                if (ethernetMode == 'access'){
                    delete confObj["ethernet"]["network"];
                }
                if (ethernetMode == 'network' ){
                    delete confObj["ethernet"]["access"];
                }
            }else {
                delete confObj["ethernet"]["access"];
            }
            if(!isOtuSupported(target))
            {
                delete confObj["otu"];
            }
            let configObj = JSON.stringify(confObj);
            let deviatedObj = intentDeviationObj.removeIntentConfig(configObj, neId);
            let finalConfigObj = {};
            let intentKey = intentTypeName + ":" + intentTypeName
            finalConfigObj[intentKey] = {};
            finalConfigObj[intentKey][intentContainer] = deviatedObj;
            preSyncConf.push(finalConfigObj);
        }
        logger.info("intent config after removing deviation attributes: " + JSON.stringify(preSyncConf));
        return JSON.stringify(preSyncConf);
    };

    const isOtuSupported = (target) => {
        //fetch the mda-type to check if the mda supports otu configuration or not
        var neId = parseTarget.getNeIdFromTarget(target);
        var portIds = (parseTarget.getUniqueIdentifier(target)[0]).split("/");
        var cardSlot = portIds[0];
        var mdaSlot = portIds[1];
        var mdaList = mdSuggest.getMDAType(neId, cardSlot, mdaSlot);
        var mdaType = mdaList.length != 0 ? mdaList[0] :"";
        logger.info("[CUSTOM-HOOKS] MDA TYPE = "+ mdaType);
        //delete otu container on mda which doesn't support otu configuration
        if(!(mdaType == "p1-100g-tun-b" || mdaType == "me10-10gb-sfp+" || mdaType == "me1-100gb-cfp2" || mdaType == "me6-10gb-sfp+" || mdaType == "x2-100g-tun" ||
         mdaType == "x4-100g-cfp2" || mdaType == "me3-200gb-cfp2-dco" || mdaType == "x6-200g-cfp2-dco" || mdaType == "ms6-200gb-cfp2-dco" || mdaType == "ms3-200gb-cfp2-dco" ||
         mdaType == "maxp1-100gb-cfp2"))
        {
            return false;
        }
        return true;
    }

    /**
     * PostSync Hook
     */
    const postSync = (inputObj) => {
        /**
         * Write your custom postSync logic here
         * inputObj by default contains the following keys:
         *          target, config, intentTypeName, rootXPath,
         *          intentContainer, uniqueIdentifier, deviceYangModuleName
         *          topology, state, syncResult
         */
        logger.info("[CUSTOM-HOOKS] postSync call");
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

    };

    /**
     *
     * PostDiscovery Hook
     */
    const postDiscovery = (inputObj) => {
        /**
         * Write your custom postDiscovery logic here
         * inputObj by default contains the following keys:
         *        deviceConfig, intentContainer, neId,
         *        targetDataStruct, templateName, deviceYangModuleName
         */

        logger.info("[CUSTOM-HOOKS] postDiscovery call");
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

    }

    this.preAudit = preAudit;
    this.postAudit = postAudit;
    this.preSync = preSync;
    this.postSync = postSync;
    this.postDiscovery = postDiscovery;

}