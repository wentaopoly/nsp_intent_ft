load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {

    this.setSuccessResult = function (result, savedTopology) {
        result.setSuccess(true);
        if (savedTopology !== undefined) {
            result.setTopology(savedTopology);
        }
        return result;
    }

    this.reportMisaligned = function (target, result, auditReport) {
        var report = JSON.parse(result.response);
        if (!report.aligned)
        {
            for (var i = 0; i < report.misalignedAttributes.length; i++)
            {
                var attributeData = report.misalignedAttributes[i];
                if (attributeData.expected == "present")
                {
                    //misaligned object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else if (attributeData.expected == "not present")
                {
                    //undesired object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    var attributeFields = (attributeData.name).split("|");
                    if(attributeFields.length == 3 && attributeFields[2] == "type")
                    {
                        attributeData.expected = this.transformIntentFilterType(attributeData.expected);
                        attributeData.actual = this.transformIntentFilterType(attributeData.actual);
                    }
                    var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                    auditReport.addMisAlignedAttribute(misalignedAttribute);
                }

            }
        }
        return auditReport
    }

    this.getIfObjectExists = function (className, objectFullName) {

        let nfmpFwk = new NfmpFwk();
        var expectedJson = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "filterName",
                    "id"
                ]
            }
        };
        var ret = false;
        var resultFetch = nfmpFwk.post("/v3/search", expectedJson);
        logger.info(LOG_PREFIX + "MAC Filter Policy search results : " + JSON.stringify(resultFetch));
        var finalResponse = JSON.parse(resultFetch.response);
        if (JSON.stringify(finalResponse) === JSON.stringify({})) {
            logger.info(LOG_PREFIX + "Search results is empty: " + JSON.stringify(finalResponse));
            finalResponse = null;
        } else if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse["aclfilter.MacFilter"]];
            logger.info(LOG_PREFIX + "Search results: " + JSON.stringify(finalResponse));
        }
        return finalResponse;
    }


    /*
     function: delay
     description: Sometimes the object creation takes time, we can use delay for child-level operation.
     */
    this.delay = function (milliseconds) {
        var date = new Date();
        date.setMilliseconds(date.getMilliseconds() + milliseconds);
        while (new Date() < date) {
        }
    }

    this.editPayload = function (fdn, properties, childProperties, fullClassName, objectFullName) {
        var payload = {};
        var configInfo = {};
        configInfo[fullClassName] = properties;
        configInfo[fullClassName]["children-Set"] = childProperties;
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName,
            payload["clearOnDeployFailure"] = true;
        payload["configInfo"] = configInfo;
        return payload;
    }

    this.nfmpDot1p= function (input) {
        if (input === undefined) {
            return undefined;
        }
        if (!input.toString().startsWith("priority_")) {
            input = "priority_" + input;
        }
        return input;
    };

    this.brownFieldNfmpdot1p = function (input) {
        if (input !== undefined && input.startsWith("priority_")) {
            var numericValue = parseInt(input.replace("priority_", ""));
            return numericValue;
        }
        return input;
    }

    this.transformNfmpDefaultAction = function (intentDefaultAction) {
        var nfmpDefaultAction = "";
        switch (intentDefaultAction) {
            case "drop":
                nfmpDefaultAction = "drop";
                break;
            case "accept":
                nfmpDefaultAction = "forward";
                break;
            default:
                nfmpDefaultAction = "drop";
        }
        return nfmpDefaultAction;
    }

    this.transformIntentDefaultAction = function (nfmpDefaultAction) {
        var intentDefaultAction = "";
        switch (nfmpDefaultAction) {
            case "drop":
                intentDefaultAction = "drop";
                break;
            case "forward":
                intentDefaultAction = "accept";
                break;
            default:
                intentDefaultAction = "drop";
        }
        return intentDefaultAction;
    }

    this.getMacFilterId = function (target) {
        var filterId = target.split("#")[3];
        return filterId;
    }

    /*
    function: getMacFilterName
    description: Getting the Filter Name from target.
    */
    this.getMacFilterName = function (target) {

        //write code here
        var filterName = target.split("#")[2];
        return filterName;

    }

    this.transformBrownfieldProtocol = function (intentFrameTypeValue) {
        var nfmpProtocolValue = "";
        switch (intentFrameTypeValue) {
            case "e802dot3":
                nfmpProtocolValue = "802dot3";
                break;
            case "e802dot2LLC":
                nfmpProtocolValue = "802dot2-llc";
                break;
            case "e802dot2SNAP":
                nfmpProtocolValue = "802dot2-snap";
                break;
            case "ethernetII":
                nfmpProtocolValue = "ethernet-ii";
                break;
            default:
                nfmpProtocolValue = undefined;
        }
        return nfmpProtocolValue;
    }

    this.transformNfmpProtocol = function (intentFrameTypeValue) {
        var nfmpProtocolValue = "";
        switch (intentFrameTypeValue) {
            case "802dot3":
                nfmpProtocolValue = "e802dot3";
                break;
            case "802dot2-llc":
                nfmpProtocolValue = "e802dot2LLC";
                break;
            case "802dot2-snap":
                nfmpProtocolValue = "e802dot2SNAP";
                break;
            case "ethernet-ii":
                nfmpProtocolValue = "ethernetII";
                break;
            default:
                nfmpProtocolValue = undefined;
        }
        return nfmpProtocolValue;
    }

    this.brownFieldTransformNfmpSnapOuiName = function (inputSnapOuiValue) {
        var nfmpSnapOuiValue = "";
        switch (inputSnapOuiValue) {
            case "nonZero":
                nfmpSnapOuiValue = "non-zero";
                break;
            case "zero":
                nfmpSnapOuiValue = "zero";
                break;
            default:
                nfmpSnapOuiValue = undefined;
        }
        return nfmpSnapOuiValue;
    }

    this.transformNfmpSnapOuiName = function (inputSnapOuiValue, nodeType) {
        var nfmpSnapOuiValue = "";
        switch (inputSnapOuiValue) {
            case "non-zero":
                nfmpSnapOuiValue = "nonZero";
                break;
            case "zero":
                nfmpSnapOuiValue = "zero";
                break;
            default:
                if (nodeType["type"].startsWith("7750") || nodeType["type"].startsWith("7450") || nodeType["type"].startsWith("7950")) {
                    nfmpSnapOuiValue = "off";
                } else {
                    nfmpSnapOuiValue = undefined;
                }
        }
        return nfmpSnapOuiValue;
    }

    this.brownFieldTransformNfmpPbrName = function (inputPbrValue) {
        var nfmpPbrValue = "";
        switch (inputPbrValue) {
            case "filterDefault":
                nfmpPbrValue = "filter-default-action";
                break;
            case "forward":
                nfmpPbrValue = "forward";
                break;
            case "drop":
                nfmpPbrValue = "drop";
                break;
            default:
                nfmpPbrValue = undefined;
        }
        return nfmpPbrValue;
    }

    this.transformNfmpPbrName = function (inputPbrValue) {
        var nfmpPbrValue = "";
        switch (inputPbrValue) {
            case "filter-default-action":
                nfmpPbrValue = "filterDefault";
                break;
            case "forward":
                nfmpPbrValue = "forward";
                break;
            case "drop":
                nfmpPbrValue = "drop";
                break;
            default:
                nfmpPbrValue = undefined;
        }
        return nfmpPbrValue;
    }

    this.brownFieldNfmpValidMacAddress = function (macAddress) {
        if (macAddress !== undefined) {
            var formattedMacAddress = macAddress.replace(/-/g, ':').toLowerCase();
            return formattedMacAddress;
        }
        return macAddress;
    }
    this.nfmpValidMacAddress = function (macAddress) {
        if (macAddress !== undefined) {
            var formattedMacAddress = macAddress.replace(/:/g, '-').toUpperCase();
            return formattedMacAddress;
        }
        return macAddress;
    }

    this.extractPort = function (input) {
        var colonIndex = input.indexOf(":");
        if (colonIndex !== -1) {
            var port = input.substring(0, colonIndex);
            return port.trim();
        } else {
            return input.trim();
        }
    }

    this.extractPathId = function (pathId) {
        if (pathId !== undefined) {
            var ids = pathId.split(":");
            var extractedPathId = ids[0];
            return extractedPathId;
        }
        return pathId;
    }

    this.extractVCId = function (VCId) {
        if (VCId !== undefined) {
            var ids = VCId.split(":");
            var extractedVCId = ids[1];
            return extractedVCId;
        }
        return VCId;
    }

    this.extractInnerEncapValue = function (input) {
        if (input === undefined) {
            return undefined;
        }
        var startIndex = input.indexOf(':');
        var endIndex = input.lastIndexOf(".");
        if (( endIndex !== -1) && (endIndex > startIndex)) {
            var InnerEncapValue = input.substring(endIndex+1).trim();
            logger.info("StartIndex"+ startIndex +"EndIndex"+ endIndex +"PORT  : "+input+"InnerEncapValue  is " + InnerEncapValue);
            return InnerEncapValue;
        } else logger.info("InnerEncapValue is not there port"+ input );
        return undefined;
    }

    this.extractOuterEncapValue = function (input) {
        if (input === undefined) {
            return undefined;
        }
        var startIndex = input.indexOf(":");
        var endIndex = input.lastIndexOf(".");

        if (startIndex !== -1) {
            var OuterEncapValue;
            if(startIndex<endIndex){
                OuterEncapValue = input.substring(startIndex + 1,endIndex );
                logger.info("StartIndex"+ startIndex +"EndIndex"+ endIndex +"PORT  : "+input+"OuterEncapValue  is " + OuterEncapValue);
            } else {
                OuterEncapValue = input.substring(startIndex + 1).trim();
                logger.info("StartIndex"+startIndex+ "PORT  : "+ input +"OuterEncapValue  is " + OuterEncapValue);
            }
            logger.info("PORT  : "+input+"OuterEncapValue for " + OuterEncapValue);
            return OuterEncapValue;
        }else logger.info("OuterEncapValue is not there port"+ input );
        return undefined;
    }

    this.brownFieldSap = function (SapPortName, SapOuterEncapValue, SapInnerEncapValue, SapEncapType) {
        if (SapEncapType === null) {
            return SapPortName;
        }
        if (SapEncapType === 'qEncap') {
            return SapPortName + ':' + SapOuterEncapValue;
        } else if (SapEncapType === 'qinqEncap') {
            return SapPortName + ':' + SapOuterEncapValue + '.' + SapInnerEncapValue;
        }
        return SapPortName;
    }

    this.esiVplsNfmpPattern = function (esiVpls) {
        if (esiVpls !== undefined && !esiVpls.toString().startsWith("svc-mgr:service-")) {
            esiVpls = "svc-mgr:service-" + esiVpls;
        }
        return esiVpls;
    }

    this.distribute = function (neId, objectFullName, isLocalEdit) {
        var payload = {};
        var policyDefination = "policy.PolicyDefinition.distributeV2";
        if (isLocalEdit)
        {
            policyDefination = "policy.PolicyDefinition.setDistributionModeToLocalEditOnly";
        }
        payload[policyDefination] = {};
        payload[policyDefination]["clearOnDeployFailure"] = true;
        payload[policyDefination]["deployer"] = "immediate";
        payload[policyDefination]["instanceFullName"] = objectFullName;
        payload[policyDefination]["siteIds"] = {};
        payload[policyDefination]["siteIds"]["string"] = neId;
        return payload;
    }

    this.isObjectExists = function (className, objectFullName) {
        let nfmpFwk = new NfmpFwk();
        var ret = false;
        var searchObjectJson = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);

        logger.info(LOG_PREFIX + "isObjectExists data = {}", JSON.stringify(resultFetch));
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(LOG_PREFIX + "Final response of search = {}", JSON.stringify(finalResponse));
        if (Object.keys(finalResponse).length !== 0 && finalResponse.constructor === Object)
        {
            ret = true;
        }
        logger.info(LOG_PREFIX + "isObjectExists = {} ", ret);
        return ret;
    }

    this.modifyNeIdForIpV6 = function (objectFullName, neId) {
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }
}
