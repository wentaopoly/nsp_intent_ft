function ModelDeviceMapping() {
    this.getNQueuePolicyMapping = function () {
        var mapping = {};
        mapping['network-queue.description'] = 'description';
        return mapping;
    }
    this.getQueueMapping = function () {
        var mapping = {};
        mapping['queue.queue-id'] = 'id';
        mapping['queue.displayed-name'] = 'displayedName';
        mapping['queue.description'] = 'description';
        mapping['adaptation-rule.pir'] = 'pirAdaptation';
        mapping['adaptation-rule.cir'] = 'cirAdaptation';
        mapping['rate.pir'] = 'pir';
        mapping['rate.cir'] = 'cir';
        mapping['burst-size.committed-burst-size'] = 'committedBurstSize';
        mapping['burst-size.maximum-burst-size'] = 'maximumBurstSize';
        mapping['queue.mode'] = 'mode';
        mapping['queue.weight'] = 'weight';
        mapping['queue.priority'] = 'priority';
        mapping['queue.queue-management-policy'] = 'queuemgmtPolicyPointer';
        mapping['queue.slope-policy'] = 'slopePolicyPointer';
        return mapping;
    }
    this.getFcMapping = function () {
        var mapping = {};
        mapping['fc.queue-id'] = 'queueId';
        mapping['fc.forwarding-class'] = 'forwardingClass';
        return mapping;
    }
}
