package com.nokia.nsp.mdt.intents.ibsf.resync.mdc;

import com.nokia.nsp.md.common.IExecutionContext;
import com.nokia.nsp.md.common.IYangObject;
import com.nokia.nsp.md.common.YangObject;
import com.nokia.nsp.md.db.yang.api.ExecutionContext;
import com.nokia.nsp.md.db.yang.api.QueryParameters;
import com.nokia.nsp.md.ifg.yang.api.Fields;
import com.nokia.nsp.md.resync.api.IMdResyncFw;
import com.nokia.nsp.md.resync.api.INspObjectDeleteFilter;

//This allows us to keep all ibsf created tunnels even if they are not on node
// If they are on node deployed misaligned type it does not create a new object in db
//Tunnels discovered can be deleted
public class TunnelDeleteFilter implements INspObjectDeleteFilter {
    @Override
    public boolean canDeleteNspObject(IYangObject aInIYangObject, String aInSbiClassId, IMdResyncFw aInIMdResyncFw) {
        //If the tunnel has slc-state, tunnel was created by ibsf (could be planned) else it can be deleted
        String lTunnelType = null;
        IYangObject lYangExtObj = null;
        Boolean lCanDelete = null;
        final String extPath = aInIYangObject.getIdentifier().contains("gre-tunnel") ? "service-extension:gre-tunnel-ext" : "service-extension:mpls-tunnel-ext";

        if (aInIYangObject.hasProperty(extPath)) {
            lYangExtObj = (IYangObject) aInIYangObject.get(extPath);
            if (lYangExtObj.hasProperty("slc-state")){
                lCanDelete=lYangExtObj.get("slc-state") == null;
            }
        }

        if(lCanDelete==null){//aInIYangObject probably doesn't have full depth. Brownfield MPLS/GRE have steering MPLS have lsp
            QueryParameters lQp = new QueryParameters();
            lQp.setFields(Fields.parse("slc-state"));
            lQp.setDepth(2);
            lQp.setEnableMetaData(false);
            lYangExtObj = aInIMdResyncFw.getIYangDB().getSingle(aInIYangObject.getIdentifier() + "/" + extPath, lQp);
            lCanDelete = (!(lYangExtObj!=null && lYangExtObj.hasProperty("slc-state") && lYangExtObj.get("slc-state") != null));
        }

        if (lCanDelete == false) {
            //set oper-state unknown
            QueryParameters lQpUpdate = new QueryParameters();//QueryParameters needed to disable readonly
            IExecutionContext lExecutionContextUpdate = new ExecutionContext(null, null, false, false, false);
            lQpUpdate.setIExecutionContext(lExecutionContextUpdate);

            IYangObject lUpdate = new YangObject();
            lUpdate.setProperty("oper-state", "unknown");

            aInIMdResyncFw.getIYangDB().update(aInIYangObject.getIdentifier(), lUpdate, null, lQpUpdate);
        }
        return Boolean.TRUE.equals(lCanDelete);
    }
}