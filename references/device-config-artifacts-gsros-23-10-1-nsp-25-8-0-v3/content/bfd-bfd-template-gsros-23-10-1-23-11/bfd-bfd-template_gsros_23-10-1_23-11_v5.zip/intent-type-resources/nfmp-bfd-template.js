var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});

var bfd_template_class_name = "mplstp.BFDTemplate";
var bfd_template_name = "displayedName";
var bfd_template_policy_fdn = "BFDTemplate";

function NfmpBfdTemplate() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    var parseTarget =  new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var isAudit = false;
    var isLocalExists = false;
    var isGlobalExists = false;
    var isEdit = false;
    var intentDeviationObj = new IntentDeviceDeviation();

    this.synchronize = function(input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        // code to handle delete
        if (input.getNetworkState().name() == "delete") {
            logger.info(LOG_PREFIX + "Calling syncDelete");
            return this.syncDelete(input, result);
        }

        var savedTopology = input.getCurrentTopology();
        logger.info(LOG_PREFIX + "Saved Topology = " + savedTopology);
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        var bfdTemplateName = parseTarget.getUniqueIdentifier(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        if(intentConfig == "") {
            intentConfig = {};
        }
        intentConfig[bfd_template_name] = bfdTemplateName;
        intentConfig = this.removeEmptyContainers("", intentConfig,"", target);
        intentConfig[bfd_template_name] = bfdTemplateName;
        logger.info(LOG_PREFIX + "Configuration of BFD Template to be pushed = "+JSON.stringify(intentConfig));
        logger.info(LOG_PREFIX + "Target device = " + target);
        logger.info(LOG_PREFIX + "BFD Template = " + bfdTemplateName);
        this.createOrModify(target, intentConfig);

        //Code to check if local Policy exists or not
        var objectFullName = bfd_template_policy_fdn + ":" + intentConfig[bfd_template_name];
        let fullClassName = "mplstp.BFDTemplate";
        var localObjectFullName = "network:" + target + ":" + objectFullName;
        localObjectFullName = util.modifyNeIdForIpV6(localObjectFullName, target);
        util.delay(2000);
        let localPolicyExists = util.isObjectExists(fullClassName, localObjectFullName);
        if(!localPolicyExists) {
            throw new RuntimeException("Unable to find local Policy : '"+ localObjectFullName + "', for the Class Name: '" + fullClassName + "'. Please check NFMP for any deployment errors.")
        }

        // code to handle sync
        return util.setSuccessResult(result, savedTopology);
    }

    this.createOrModify = function (target, intentConfig) {
        var objectFullName = bfd_template_policy_fdn + ":" + intentConfig[bfd_template_name];
        var localObjectFullName = "network:" + target + ":" + objectFullName;
        localObjectFullName = util.modifyNeIdForIpV6(localObjectFullName, target);
        var localTemplate = util.getIfObjectExists(bfd_template_class_name, localObjectFullName);
        logger.info(LOG_PREFIX + "localTemplate: " + JSON.stringify(localTemplate));
        var result;
        var bfdTemplatePayload;
        if (localTemplate != null) {
            isLocalExists = true;
            isGlobalExists = true;
            if (localTemplate[0]["displayedName"] !== intentConfig[bfd_template_name]) {
                throw new RuntimeException("Already there exists a BFD Template on " + target +
                    " with name " + localTemplate[0]["displayedName"]);
            }
            bfdTemplatePayload = this.createBfdTemplatePayload(target, intentConfig, isLocalExists, null);
            result = this.modifyRequest(target, bfdTemplatePayload);
        }
        else {
            bfdTemplatePayload = this.createBfdTemplatePayload(target, intentConfig, false, null);
            result = this.modifyRequest(target, bfdTemplatePayload);
            // Distribute the policy to the local
            // Distribute Global Policy to Ne in Target
            let distributeResult;
            if (!isEdit) {
                distributeResult = this.distributePolicy(target, intentConfig, false);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributeResult = this.distributePolicy(target, intentConfig, true);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
            }
        }
        return result;
    }

    this.createBfdTemplatePayload = function (target, intentConfig, isLocalExists, templateObject) {
        var objectFullName = bfd_template_policy_fdn + ":" + intentConfig[bfd_template_name];
        var localObjectFullName = "network:" + target + ":" + objectFullName;
        localObjectFullName = util.modifyNeIdForIpV6(localObjectFullName, target);
        if (isAudit || isLocalExists) {
            objectFullName = localObjectFullName;
            if (!isAudit) {
                isEdit = true;
            }
        }

        var properties = {};
        var childProperties = {};
        properties["displayedName"] = intentConfig[bfd_template_name];
        for (var attribute in intentConfig) {
            switch (attribute) {
                case "multiplier":
                    properties["multiplier"] = intentConfig[attribute];
                    break;
                case "transmit-interval":
                    properties["transmitTimer"] = intentConfig[attribute];
                    break;
                case "echo-receive":
                    properties["echoReceiveInterval"] = intentConfig[attribute];
                    break;
                case "receive-interval":
                    properties["receiveTimer"] = intentConfig[attribute];
                    break;
                case "type":
                    var neFamily = intentDeviationObj.getNeFamilyRelease(target);
                    var chassisType = intentDeviationObj.getChassisType(neFamily);
                    if (chassisType === "7250 IXR-10" || chassisType === "7750-SR12" || neFamily.startsWith("7450")) {
                        properties["templateType"] = "auto";
                    }
                    else {
                        properties["templateType"] = util.transformBfdTemplateTypeGf(intentConfig[attribute]);
                    }
                    break;
            }
        }
        return util.editPayload(bfd_template_policy_fdn, properties, childProperties, bfd_template_class_name, objectFullName);
    }

    this.modifyRequest = function (neId, payload) {
        logger.info(LOG_PREFIX + "Sending the modify request for MDT");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
           logger.error("Error result = {}",JSON.stringify(result));
           let errorMsg = result.msg;
           if(errorMsg.indexOf("object already exists") !== -1)
           {
               logger.info("Global policy Object already exists, Re-checking the Policy existence ");
               //util.delay(2000);
               let configInfo = payload.configInfo;
               let fullClassName;
               for (let key in configInfo) {
                 if (configInfo.hasOwnProperty(key)) {
                   fullClassName = key;
                   break;
                 }
               }
               let objectFullName = payload.objectFullName;
               objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
               logger.info("fullClassName = {}",fullClassName);
               logger.info("objectFullName = {}",objectFullName);
               if (!util.isObjectExists(fullClassName, objectFullName))
               {
                   throw new RuntimeException("Global Policy Object Not Found!!!");
               }
           }
           else
           {
               throw new RuntimeException(result.msg);
           }
        }
        return result;
    }

    this.distributePolicy = function(nodeIp, intentConfig, localEdit) {
        logger.info(LOG_PREFIX + "localEdit : " + localEdit);
        var objectFullName = bfd_template_policy_fdn + ":" + intentConfig[bfd_template_name];
        var payload = {};
        if (localEdit === false) {
            payload["policy.PolicyDefinition.distributeV2"] = {};
            payload["policy.PolicyDefinition.distributeV2"]["clearOnDeployFailure"] = true;
            payload["policy.PolicyDefinition.distributeV2"]["deployer"] = "immediate";
            payload["policy.PolicyDefinition.distributeV2"]["instanceFullName"] = objectFullName;
            payload["policy.PolicyDefinition.distributeV2"]["siteIds"] = {};
            payload["policy.PolicyDefinition.distributeV2"]["siteIds"]["string"] = nodeIp;
            logger.info(LOG_PREFIX + objectFullName + ": policy distribute Payload: " + JSON.stringify(payload));
        }
        else {
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"] = {};
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["clearOnDeployFailure"] = true;
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["deployer"] = "immediate";
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["instanceFullName"] = objectFullName;
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["siteIds"] = {};
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["siteIds"]["string"] = nodeIp;
            logger.info(LOG_PREFIX + objectFullName + ": policy switch to local edit only Payload for " + nodeIp+ " : " + JSON.stringify(payload));
        }

        return nfmpFwk.post("/rest/api/v3/request", payload);
    }

    this.audit = function(target, config, svcTopo, adminState, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        var savedTopology = svcTopo;
        isAudit = true;
        var neId = parseTarget.getNeIdFromTarget(target);
        var bfdTemplateName = parseTarget.getUniqueIdentifier(target);
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        if(intentConfig == "") {
            intentConfig = {};
        }
        intentConfig[bfd_template_name] = bfdTemplateName;
        intentConfig = this.removeEmptyContainers("",intentConfig,"",neId);
        logger.info(LOG_PREFIX + "auditing configuration = "+JSON.stringify(intentConfig));
        logger.info(LOG_PREFIX + "Target device = " + neId);
        logger.info(LOG_PREFIX + "Target Network QoS = " + bfdTemplateName);
        intentConfig[bfd_template_name] = bfdTemplateName;
        if (intentConfig) {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else {
            throw "configuration not available in the intent";
        }
        return auditReport;
    }

    this.auditAndCompare = function (target, intentConfig, auditReport) {

        var bfdTemplatePayload = this.createBfdTemplatePayload(target, intentConfig, true, null);
        var result = this.auditRequest(target, bfdTemplatePayload);
        auditReport = util.reportMisaligned(target, result, auditReport);
        return auditReport;
    }

    this.auditRequest = function (target, payLoad) {
        logger.info(LOG_PREFIX + "Sending the audit request for mdt");
        logger.info(JSON.stringify(payLoad));
        var result = nfmpFwk.compare(target, JSON.stringify(payLoad), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.syncDelete = function (input, result) {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var bfdTemplateName = parseTarget.getUniqueIdentifier(input.getTarget());
        var objectFullName = bfd_template_policy_fdn + ":" + bfdTemplateName;
        var localObjectFullName = "network:" + neId + ":" + objectFullName;
        localObjectFullName = util.modifyNeIdForIpV6(localObjectFullName, neId);
        var localTemplate = util.getIfObjectExists(bfd_template_class_name, objectFullName);
        logger.info(LOG_PREFIX + "Deleting search response : " + JSON.stringify(localTemplate));
        if (localTemplate != null) {
            logger.info(LOG_PREFIX + "syncDelete(): Deleting " + localObjectFullName);
            var deleteResult = nfmpFwk.deployDelete(localObjectFullName, "application/json");
            if (!deleteResult.success) {
                logger.info(LOG_PREFIX + "syncDelete(): Unable to Delete: " + deleteResult.msg);
                throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
            }
            result.setSuccess(true);
        }
        else {
            logger.info(LOG_PREFIX + "syncDelete(): There is no BFD Template with Name:" +
                bfdTemplateName + " on " + neId);
            result.setSuccess(false);
        }
    }

    this.xml2object = function(xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: '+ json)
        return JSON.parse(json);
    }

    this.removeEmptyContainers= function(prop, intentJson, path, target){

        if(Array.isArray(intentJson)) {
            var object = [];
            for(var prop in intentJson) {
                var value = this.removeEmptyContainers(prop,intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }
        else if( typeof intentJson == 'object' ) {
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop,intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }
        else {
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }
            return null;
        }
    }
}
