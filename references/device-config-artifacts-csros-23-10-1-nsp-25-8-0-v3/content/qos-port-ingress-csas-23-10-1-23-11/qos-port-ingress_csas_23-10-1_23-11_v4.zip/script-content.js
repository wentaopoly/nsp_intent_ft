var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})

load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
mdtFwk = new MdtFwk();


var LOG_PREFIX = "[Port QOS Access Ingress 7210]: "

var intentTypeName = 'qos-port-ingress_csas_23-10-1_23-11';

var initialPropertyName = 'port-qos-ingress';

var parentXpath = 'configure/qos';

// unique identifier
var uniqueIdentifier = 'port-qos-policy-name';

function synchronize(input) {
    return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function audit(input) {
    logger.info('Intent Audit started')
    logger.info("*******config ===== {}", input);
    return NspIntentHelper.audit(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier)
}

function getTargetData(input) {
    logger.info(input);
    var target = input.target;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}

function suggestPortIngressPolicyId(context) {
    logger.info("suggestPortIngressPolicyId context = \n" + context);
    var neId = getNeId(context);
    return navigateInstance(neId).getPolicyId(neId);
}

function getNeId(context) {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    logger.info(target)
    if (target) {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        } else {
            neId = target;
        }
    }
    logger.info("NeId : " + neId);
    return neId;
}

function suggestDSCPClassificationPolicy(context) {
    logger.info("suggest DSCP Classification Policy context = \n" + context);
    var neId = getNeId(context);
    return navigateInstance(neId).getDSCPClassificationPolicy(neId);
}

function suggestDot1pClassificationPolicy(context) {
    logger.info("suggest Dot1p Classification Policy context = \n" + context);
    var neId = getNeId(context);
    return navigateInstance(neId).getDot1pClassificationPolicy(neId);
}

function suggestUniCastMeterId(context) {
    var meterIds = [];
    logger.info("Suggest MeterId Function")
    logger.info(context);
    var meters = context['inputValues']['arguments']['__root']['port-qos-ingress']['meter'];
    meters.forEach(function (meterObject) {
        logger.info("Meter Id in Input : " + meterObject['meter-id']);
        if (meterObject['multi-point'] == "false")
        {
            meterIds.push(meterObject['meter-id']);
        }
    });
    return meterIds;
}

function suggestMultiCastMeterId(context) {
    var mmeterIds = [];
    logger.info("Suggest Multicast MeterId Function")
    logger.info(context);
    var mmeters = context['inputValues']['arguments']['__root']['port-qos-ingress']['meter'];
    mmeters.forEach(function (mmeterObject) {
        logger.info("Queue Id in Input : " + mmeterObject['meter-id']);
        if (mmeterObject['multi-point'] == "true")
        {
            mmeterIds.push(mmeterObject['meter-id']);
        }
    });
    return mmeterIds;
}

function navigateInstance(neId) {
    var managerName = mdtFwk.getManagerName(neId);
    logger.info('Device: ' + neId + ' is managed by: ' + managerName);
    switch (managerName) {
        case 'NFM-P':
            logger.info('Device is managed by NFMP')
            return new NfmpSuggest();
            break;
        default:
            logger.info('Device is not managed')
            throw new RuntimeException('Device is not Managed')
    }
    return ''
}




