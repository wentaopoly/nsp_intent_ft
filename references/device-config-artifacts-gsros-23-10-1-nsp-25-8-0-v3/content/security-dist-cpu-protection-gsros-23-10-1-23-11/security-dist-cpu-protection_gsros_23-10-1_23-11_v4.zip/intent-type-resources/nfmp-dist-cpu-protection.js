var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpDistCpuProtection() {

    var util = new utilities();
    var mapFwk = new MapFwk();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var isAudit = false;
    var isEdit = false;

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        logger.info("input = \n" + input + "-------" + result + "-------" + intentTypeName + "-------" + initialPropertyName + "-------" + uniqueIdentifier);
        // code to handle delete
        if (input.getNetworkState().name() == "delete")
        {
            logger.info("Calling syncDelete");
            return this.syncDelete(input, result);
        }
        // code to handle sync
        var savedTopology = input.getCurrentTopology();
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyName = parseTarget.getUniqueIdentifier(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        logger.info("Policy Name = " + policyName);
        intentConfig["policyName"] = policyName;
        this.createOrModify(neId, intentConfig);
        return util.setSuccessResult(result, savedTopology);
    }
    this.audit = function (target, config, svcTopo, adminState, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        logger.info("AUDIT STARTED");
        var savedTopology = svcTopo;
        savedObjects = {};
        currentObjects = {};
        isAudit = true;
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        intentConfig["policyName"] = parseTarget.getUniqueIdentifier(target);
        var neId = parseTarget.getNeIdFromTarget(target);
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        if (intentConfig)
        {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }
        return auditReport
    }
    this.auditAndCompare = function (neID, intentConfig, auditReport) {
        var distCpuPolicyPayload = this.createPolicyLevelPayLoad(neID, intentConfig);
        var result = this.auditRequest(neID, distCpuPolicyPayload);
        auditReport = util.reportMisaligned(neID, result, auditReport);
        return auditReport;
    }
    this.auditRequest = function (neId, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }
    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('input json: ' + json)
        return JSON.parse(json);
    }
    this.syncDelete = function (input, result) {
        var neID = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyName = parseTarget.getUniqueIdentifier(input.getTarget());
        var objectFullName = "network:" + neID + ":DCpuProtection:" + policyName;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neID);
        logger.info("Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }
    this.createOrModify = function (neID, intentConfig) {
        var distCpuPolicyPayload = this.createPolicyLevelPayLoad(neID, intentConfig);
        var result = this.modifyRequest(neID, distCpuPolicyPayload);
        // distribute the policy to the local
        // Distribute Global Policy to Ne in Target
        if (!isEdit)
        {
            let distributeResult = this.distributePolicy(neID, intentConfig, false);
            if (!distributeResult.success)
            {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }
            util.delay(2000);
            // Changing SyncWithGlobal To Local Edit Only
            distributeResult = this.distributePolicy(neID, intentConfig, true);
            if (!distributeResult.success)
            {
                throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
            }
        }
        return result;
    }
    this.modifyRequest = function (target, payload) {
        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            logger.error("Error while deploying the request {}", JSON.stringify(result.msg));
		    let objFullName = payload["objectFullName"];
		    objFullName = util.modifyNeIdForIpV6(objFullName, target);
		    if(!(objFullName.indexOf("network") !== -1))
		    {
                logger.info("Redeploying the request ...  ");
                result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
                if (!result.success)
                {
                    throw new RuntimeException(result.msg)
                }
		    }
		    else
		    {
                throw new RuntimeException(result.msg)
		    }
        }
        return result;
    }
    this.createPolicyLevelPayLoad = function (neID, intentConfig) {
        var fullClassName = "sitesec.DCpuProtection";
        var policyFdn = "DCpuProtection";
        var objectFullName = "DCpuProtection:" + intentConfig["policyName"];
        var localPolicyFullName = "network:" + neID + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neID);
        if (util.isObjectExists(fullClassName, localPolicyFullName) || isAudit)
        {
            objectFullName = localPolicyFullName;
            if (!isAudit)
            {
                isEdit = true;
            }
        }
        var properties = {};
        properties["displayedName"] = intentConfig["policyName"];
        properties["description"] = intentConfig["description"];
        properties["dCpuProtectionPolicyType"] = util.convertPolicyTypeGreenField(intentConfig["type"]);
        var childProperties = [];
        if (intentConfig["static-policer"])
        {
            if (!Array.isArray(intentConfig["static-policer"]))
            {
                intentConfig["static-policer"] = [intentConfig["static-policer"]];
            }
            for (var index in intentConfig["static-policer"])
            {
                var intentStaticPolicerConfig = intentConfig["static-policer"][index];
                var staticPolicierPayload = this.createStaticPolicerPayLoad(neID, objectFullName, intentStaticPolicerConfig);
                childProperties.push(staticPolicierPayload);
            }
        }
        if (intentConfig["local-monitoring-policer"])
        {
            if (!Array.isArray(intentConfig["local-monitoring-policer"]))
            {
                intentConfig["local-monitoring-policer"] = [intentConfig["local-monitoring-policer"]];
            }
            for (var index in intentConfig["local-monitoring-policer"])
            {
                var intentLocalMonitoringPolicerConfig = intentConfig["local-monitoring-policer"][index];
                var localMonitoringPolicerPayload = this.createLocalMonitoringPolicerPayLoad(neID, objectFullName, intentLocalMonitoringPolicerConfig);
                childProperties.push(localMonitoringPolicerPayload);
            }
        }
        if (intentConfig["protocol"])
        {
            if (!Array.isArray(intentConfig["protocol"]))
            {
                intentConfig["protocol"] = [intentConfig["protocol"]];
            }
            for (var index in intentConfig["protocol"])
            {
                var intentProtocolConfig = intentConfig["protocol"][index];
                var protocolPayload = this.createProtocolPayLoad(neID, objectFullName, intentProtocolConfig);
                childProperties.push(protocolPayload);
            }
        }
        var policyLevelPayload = util.editPayload(policyFdn, properties, childProperties, fullClassName, objectFullName);
        return policyLevelPayload;
    }
    this.createStaticPolicerPayLoad = function (neID, objectFullName, intentStaticPolicerConfig) {
        logger.info("Creating Static Policer payload for \nneID={},\nObjectFullName={},\nIntent Static Policer Config={}", neID, objectFullName, JSON.stringify(intentStaticPolicerConfig));
        var fullClassName = "sitesec.DCpuProtectionStaticPlcrEntry";
        var properties = {};
        properties["displayedName"] = intentStaticPolicerConfig["policer-name"];
        properties["description"] = intentStaticPolicerConfig["description"];
        properties["detectionTime"] = intentStaticPolicerConfig["detection-time"];
        properties["logEventsState"] = util.convertLogEventsTypeGreenField(intentStaticPolicerConfig["log-events"]);
        if (intentStaticPolicerConfig["exceed-action"])
        {
            properties["exceedAction"] = util.convertExceedActionGreenField(intentStaticPolicerConfig["exceed-action"]["action"]);
            properties["holdDownDuration"] = util.convertHoldDownDurationGreenField(intentStaticPolicerConfig["exceed-action"]["hold-down"]);
        }
        if (intentStaticPolicerConfig["rate"])
        {
            if (intentStaticPolicerConfig["rate"]["packets"])
            {
                properties["rateType"] = "packets";
                properties["packetRateLimit"] = util.convertRateGreenField(intentStaticPolicerConfig["rate"]["packets"]["limit"]);
                properties["timeLimit"] = intentStaticPolicerConfig["rate"]["packets"]["within"];
                properties["initPacketLimit"] = intentStaticPolicerConfig["rate"]["packets"]["initial-delay"];

            }
            if (intentStaticPolicerConfig["rate"]["kbps"])
            {
                properties["rateType"] = "kbps";
                properties["kbpsRateLimit"] = util.convertRateGreenField(intentStaticPolicerConfig["rate"]["kbps"]["limit"]);
                properties["bufferSpace"] = intentStaticPolicerConfig["rate"]["kbps"]["mbs"];
            }
        }
        logger.info("StaticPolicerConfig = {}", JSON.stringify(properties));
        return this.createChildObjectPayload(fullClassName, properties);
    }
    this.createLocalMonitoringPolicerPayLoad = function (neID, objectFullName, intentLocalMonitoringPolicerConfig) {
        logger.info("Creating Local Monitoring Policer payload for \nneID={},\nObjectFullName={},\nIntent Local Monitoring Policer Config={}", neID, objectFullName, JSON.stringify(intentLocalMonitoringPolicerConfig));
        var fullClassName = "sitesec.DCpuProtectionLocMonPlcrEntry";
        var properties = {};
        properties["displayedName"] = intentLocalMonitoringPolicerConfig["policer-name"];
        properties["description"] = intentLocalMonitoringPolicerConfig["description"];
        properties["logEventsState"] = util.convertLogEventsTypeGreenField(intentLocalMonitoringPolicerConfig["log-events"]);
        properties["exceedAction"] = util.convertExceedActionGreenField(intentLocalMonitoringPolicerConfig["exceed-action"]);
        if (intentLocalMonitoringPolicerConfig["rate"])
        {
            if (intentLocalMonitoringPolicerConfig["rate"]["packets"])
            {
                properties["rateType"] = "packets";
                properties["packetRateLimit"] = util.convertRateGreenField(intentLocalMonitoringPolicerConfig["rate"]["packets"]["limit"]);
                properties["timeLimit"] = intentLocalMonitoringPolicerConfig["rate"]["packets"]["within"];
                properties["initPacketLimit"] = intentLocalMonitoringPolicerConfig["rate"]["packets"]["initial-delay"];

            }
            if (intentLocalMonitoringPolicerConfig["rate"]["kbps"])
            {
                properties["rateType"] = "kbps";
                properties["kbpsRateLimit"] = util.convertRateGreenField(intentLocalMonitoringPolicerConfig["rate"]["kbps"]["limit"]);
                properties["bufferSpace"] = intentLocalMonitoringPolicerConfig["rate"]["kbps"]["mbs"];
            }
        }
        logger.info("LocalMonitoringPolicerConfig = {}", JSON.stringify(properties));
        return this.createChildObjectPayload(fullClassName, properties);
    }
    this.createProtocolPayLoad = function (neID, objectFullName, intentProtocolConfig) {
        logger.info("Creating Protocol payload for \nneID={},\nObjectFullName={},\nIntent Protocol Config={}", neID, objectFullName, JSON.stringify(intentProtocolConfig));
        var fullClassName = "sitesec.DCpuProtectionProtocolEntry";
        var properties = {};
        properties["protocolId"] = util.convertProtocolTypeGreenField(intentProtocolConfig["protocol-name"]);
        //default enforcement on classis node is 'enforcement dynamic "local-mon-bypass"'
        properties["enforcementPolicerName"] = "local-mon-bypass";
        properties["enforceType"] = "dynamic";
        if (intentProtocolConfig["enforcement"])
        {
            if (intentProtocolConfig["enforcement"]["static"])
            {
                properties["enforcementPolicerName"] = intentProtocolConfig["enforcement"]["static"]["policer-name"];
                properties["enforceType"] = "static";
            }
            if (intentProtocolConfig["enforcement"]["dynamic"])
            {
                properties["enforcementPolicerName"] = intentProtocolConfig["enforcement"]["dynamic"]["mon-policer-name"];
                properties["enforceType"] = "dynamic";
            }
            if (intentProtocolConfig["enforcement"]["shared"])
            {
                properties["enforcementSharedPolicerName"] = intentProtocolConfig["enforcement"]["shared"]["shared-policer-name"];
                properties["enforceType"] = "shared";
                properties["enforcementPolicerName"] = undefined;
            }
        }
        if (intentProtocolConfig["dynamic-parameters"])
        {
            properties["detectionTime"] = intentProtocolConfig["dynamic-parameters"]["detection-time"];
            properties["logEventsState"] = util.convertLogEventsTypeGreenField(intentProtocolConfig["dynamic-parameters"]["log-events"]);
            if (intentProtocolConfig["dynamic-parameters"]["exceed-action"])
            {
                properties["exceedAction"] = util.convertExceedActionGreenField(intentProtocolConfig["dynamic-parameters"]["exceed-action"]["action"]);
                properties["holdDownDuration"] = util.convertHoldDownDurationGreenField(intentProtocolConfig["dynamic-parameters"]["exceed-action"]["hold-down"]);
            }
            if (intentProtocolConfig["dynamic-parameters"]["rate"])
            {
                if (intentProtocolConfig["dynamic-parameters"]["rate"]["packets"])
                {
                    properties["rateType"] = "packets";
                    properties["packetRateLimit"] = util.convertRateGreenField(intentProtocolConfig["dynamic-parameters"]["rate"]["packets"]["limit"]);
                    properties["timeLimit"] = intentProtocolConfig["dynamic-parameters"]["rate"]["packets"]["within"];
                    properties["initPacketLimit"] = intentProtocolConfig["dynamic-parameters"]["rate"]["packets"]["initial-delay"];

                }
                if (intentProtocolConfig["dynamic-parameters"]["rate"]["kbps"])
                {
                    properties["rateType"] = "kbps";
                    properties["kbpsRateLimit"] = util.convertRateGreenField(intentProtocolConfig["dynamic-parameters"]["rate"]["kbps"]["limit"]);
                    properties["bufferSpace"] = intentProtocolConfig["dynamic-parameters"]["rate"]["kbps"]["mbs"];
                }
            }
        }
        logger.info("Protocol Config = {}", JSON.stringify(properties));
        return this.createChildObjectPayload(fullClassName, properties);

    }
    this.distributePolicy = function (nodeIp, intentConfig, localEdit) {
        logger.info(" localEdit: " + localEdit);
        var objectFullName = "DCpuProtection:" + intentConfig["policyName"];
        var xmlReq = utilityService.processTemplate(resourceProvider.getResource(localEdit ? "distribute_local_edit.ftl" : "distribute.xml"), {
            nodeIp: nodeIp,
            objectFullName: objectFullName
        });
        logger.info(xmlReq);
        return nfmpFwk.passThroughRequest('/', xmlReq);
    }
    this.createChildObjectPayload = function (fullClassName, properties) {
        var childObjectPayLoad = {};
        childObjectPayLoad['objectClassName'] = fullClassName;
        childObjectPayLoad['containedClassProperties'] = properties;
        return childObjectPayLoad;
    }
}
