function ModelDeviceMapping() {
    this.getPortIngressMapping = function () {
        var mapping = {};
        mapping['port-qos-ingress.description'] = 'description';
        mapping['port-qos-ingress.default-fc'] = 'defaultFc';
        mapping['port-qos-ingress.counter-mode'] = 'ingressCounterType'
        mapping['port-qos-ingress.num-qos-classifiers'] = 'numQosClassifiers';
        mapping['port-qos-ingress.table-classification-criteria'] = 'tableClassificationCriteria';
        mapping['port-qos-ingress.dscp-classification'] = 'dscpClassificationPointer';
        mapping['port-qos-ingress.dot1p-classification'] = 'dot1pClassificationPointer';
        mapping['port-qos-ingress.profile'] = 'defaultFcProfile';
        return mapping;
    }
}


