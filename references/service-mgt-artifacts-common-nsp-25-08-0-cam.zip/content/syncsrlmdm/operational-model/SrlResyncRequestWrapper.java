package com.nokia.nsp.md.resync.plugin.srl;

import com.nokia.nsp.md.resync.plugin.common.ResyncClass;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class SrlResyncRequestWrapper
{
    String deviceClass;
    Set<ResyncClass> resyncClasses;
    Map<String, String> xPaths = new HashMap<>();

    public SrlResyncRequestWrapper(String aInDeviceClass, Set<ResyncClass> aInResyncClasses)
    {
        deviceClass = aInDeviceClass;
        resyncClasses = aInResyncClasses;
    }

    public String getDeviceClass()
    {
        return deviceClass;
    }

    public Set<ResyncClass> getResyncClasses()
    {
        return resyncClasses;
    }

    public void addXPath(String aInFdn, String lXpath)
    {
        xPaths.put(aInFdn, lXpath);
    }

    public Map<String, String> getXPaths()
    {
        return xPaths;
    }
}
