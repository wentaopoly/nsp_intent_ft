var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};


load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource('nsp-restconf-fwk.js'), name: 'nsp-restconf-fwk'});
var nspRestconfFwk = new NspRestconfFwk();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

var intentTypeName = 'icm-logical-lag-access';

// example port, sap-ingress etc..
var initialPropertyName = 'lag';


// unique identifier
var uniqueIdentifier = 'lag-name';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure';

function synchronize(input) {
    logger.info('Intent Synchronisation started')
    var targetInfo = input.getTarget().split("#");

    var lagId = targetInfo[3];
    var lagName = targetInfo[2].split("lag-")[1];
    if (!isNaN(lagName))
    {
        if (lagId !== lagName)
        {
            throw new RuntimeException('Inconsistent Value error - the ID contained in the lag name must be equal to the actual ID')
        }
    }

    var intentConfigList = ibnService.getConfiguredIntentsByIntentTypeName(intentTypeName);
    var lagNameCount = 0;
    var lagIdCount = 0;
    for (var i = 0; i < intentConfigList.length; i++)
    {
        var intentObj = intentConfigList[i];
        var intentObjInfo = intentObj.target.split("#");
        if (targetInfo[0] === intentObjInfo[0])
        {
            if (targetInfo[1] === intentObjInfo[1])
            {
                if (targetInfo[2] === intentObjInfo[2])
                {
                    if (lagNameCount != 0)
                    {
                        throw new RuntimeException("Sync operation is not allowed because more than one intents are created on same lag Name : " + targetInfo[2] + ", with same template : " + targetInfo[0]);
                    }
                    lagNameCount = lagNameCount + 1;
                }
                if (targetInfo[3] === intentObjInfo[3])
                {
                    if (lagIdCount != 0)
                    {
                        throw new RuntimeException("Sync operation is not allowed because more than one intents are created on same lag ID : " + targetInfo[3] + ", with same template : " + targetInfo[0]);
                    }
                    lagIdCount = lagIdCount + 1;
                }
            }
        }
    }
    return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started')
    var intentConfigList = ibnService.getConfiguredIntentsByIntentTypeName(intentTypeName);
    var targetInfo = target.split("#");
    var lagId = targetInfo[3];
    var lagName = targetInfo[2].split("lag-")[1];
    if (!isNaN(lagName))
    {
        if (lagId !== lagName)
        {
            throw new RuntimeException('Inconsistent Value error - the ID contained in the lag name must be equal to the actual ID')
        }
    }
    var lagNameCount = 0;
    var lagIdCount = 0;
    for (var i = 0; i < intentConfigList.length; i++)
    {
        var intentObj = intentConfigList[i];
        var intentObjInfo = intentObj.target.split("#");
        if (targetInfo[0] === intentObjInfo[0])
        {
            if (targetInfo[1] === intentObjInfo[1])
            {
                if (targetInfo[2] === intentObjInfo[2])
                {
                    if (lagNameCount != 0)
                    {
                        throw new RuntimeException("Audit Operation is not allowed because more than one intents are created on same lag Name : " + targetInfo[2] + ", with same template : " + targetInfo[0]);
                    }
                    lagNameCount = lagNameCount + 1;
                }
                if (targetInfo[3] === intentObjInfo[3])
                {
                    if (lagIdCount != 0)
                    {
                        throw new RuntimeException("Audit Operation is not allowed because more than one intents are created on same lag ID : " + targetInfo[3] + ", with same template : " + targetInfo[0]);
                    }
                    lagIdCount = lagIdCount + 1;
                }
            }
        }
    }
    return NspIntentHelper.audit(target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function suggestPortIds(context) {
    try
    {
        var neId;
        var mode = context.getInputValues()["arguments"]["__parent"]["lag"]["mode"];
        if (mode === 'network')
        {
            mode = 'trunk';
        }
        var encapType = context.getInputValues()["arguments"]["__parent"]["lag"]["encap-type"];
        if (encapType == "null")
        {
            encapType = "null-encap";
        }
        var target = context.getInputValues()["target"]["objectidentifier"];
        if (target)
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = context.getInputValues()["arguments"]["__parent"]["target_objectidentifier"];
        }
        logger.info("listing ports for NeId : " + neId);

        ret = nspRestconfFwk.getPorts(neId, mode, encapType);
    } catch (e)
    {
        logger.error(" " + e.message);
    }
    return ret;
}

function getTargetData(input) {
    logger.info("getTargetData input for brownfield = \n" + input);
    var target = input.target;
    var config = null;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info(JSON.stringify(deviceConfig));
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}