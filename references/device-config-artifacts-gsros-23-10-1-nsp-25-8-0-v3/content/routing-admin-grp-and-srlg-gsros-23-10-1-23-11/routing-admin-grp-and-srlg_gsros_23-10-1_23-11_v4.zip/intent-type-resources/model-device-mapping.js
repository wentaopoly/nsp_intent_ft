function ModelDeviceMapping() {


  this.getMapping = function(type){
    switch(type){
      case "admin-group":
        return this.getAdminGroupMapping();
      case "srlg-group":
        return this.getSrlgGroupMapping();
      default:
        return this.getAdminGroupMapping();
    }
  }
  this.getAdminGroupMapping = function() {
    var mapping = {};
    mapping['group-name'] = 'displayedName';
    mapping['value'] = 'value';
    return mapping;
  }

  this.getSrlgGroupMapping = function() {
    var mapping = {};
    mapping['name']="displayedName";
    mapping['value']="value";
    mapping['penalty-weight']="penaltyWeight";
    return mapping;
  }

}
