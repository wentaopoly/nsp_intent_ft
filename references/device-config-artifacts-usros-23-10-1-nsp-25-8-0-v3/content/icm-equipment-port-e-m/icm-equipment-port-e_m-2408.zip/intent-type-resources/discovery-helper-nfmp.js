var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"),name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'),name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"),name: "utilities"});


function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function(target, initialPropertyName) {

        let neId = parseTarget.getNeIdFromTarget(target);
        let portId = parseTarget.getUniqueIdentifier(target);
        let searchPayLoad = this.constructSearchString(neId, portId);
        logger.info("searchPayLoad = "+JSON.stringify(searchPayLoad));
        let searchResponse = nfmpFwk.find(neId, searchPayLoad);


        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                throw new RuntimeException("Failed to get Port info from nfm-p for Ne " + neId + " and Port Id: " + portId);
            if(JSON.parse(searchResponse["response"]).length === 0)
                throw new RuntimeException("There is no port with Port Id:"+portId);
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse;
    }

    this.extractDeviceConfig = function(defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        logger.info("PARSED DEFAULT TARGET DATA : " + JSON.stringify(parsedDefaultTargetData));
        logger.info("DEVICE CONFIG : " + JSON.stringify(deviceConfig));
        let portconfig = deviceConfig['equipment.PhysicalPort'];
        if (null !== portconfig) {
            this.extractPortProperties(parsedDefaultTargetData, portconfig);
        }
        let childrenConfig = portconfig["children-Set"];

        if (null !== childrenConfig && childrenConfig.length !== 0) {

            let voicePortSpecificsConfig = childrenConfig['tdmequipment.VoicePortSpecifics'];

            let defaultVoicePortSpecificsData = parsedDefaultTargetData['port']['voicePort'];
            if (defaultVoicePortSpecificsData !== null && voicePortSpecificsConfig !== undefined && defaultVoicePortSpecificsData.length !== 0) {
                let voicePortSpecificsExtractedConfig = this.extractVoicePortSpecificsProperties(defaultVoicePortSpecificsData, voicePortSpecificsConfig);
                parsedDefaultTargetData['port']['voicePort']=voicePortSpecificsExtractedConfig;
            }
            if (voicePortSpecificsConfig === undefined){
                parsedDefaultTargetData['port']['voicePort'] = undefined;
            }

            let voiceChannelConfig = childrenConfig['tdmequipment.VoiceChannel'];
            let defaultVoiceChannelData = parsedDefaultTargetData['port']['voiceChannel'];
            if (defaultVoiceChannelData !== null && voiceChannelConfig !== undefined && defaultVoiceChannelData.length !== 0) {
                let voiceChannelExtractedConfig = this.extractVoiceChannelProperties(defaultVoiceChannelData, voiceChannelConfig);

                parsedDefaultTargetData['port']['voiceChannelEnabled'] = true;

                parsedDefaultTargetData['port']['voiceChannel']=voiceChannelExtractedConfig;
            }
            if (voiceChannelConfig === undefined){
                parsedDefaultTargetData['port']['voiceChannel'] = undefined;
            }

        }
        logger.info("parsedDefaultTargetData : " + JSON.stringify(parsedDefaultTargetData));

        return parsedDefaultTargetData;
    }

    this.extractVoicePortSpecificsProperties = function(defaultVoicePortSpecificsData, voicePortSpecificsConfig) {
        let mappings = modelDeviceMapping.getMapping("voicePort");
        this.traverseAndUpdateVoicePortSpecificsConfig('port.voicePort', defaultVoicePortSpecificsData, voicePortSpecificsConfig, mappings);
        return defaultVoicePortSpecificsData;
    }

    this.extractVoiceChannelProperties = function(defaultVoiceChannelData, voiceChannelConfig) {
        let mappings = modelDeviceMapping.getMapping("voiceChannel");
        this.traverseAndUpdateVoiceChannelConfig('port.voiceChannel', defaultVoiceChannelData, voiceChannelConfig, mappings);
        let childrenConfig = voiceChannelConfig["children-Set"];
        if (null !== childrenConfig && childrenConfig.length !== 0) {
            //VoiceChannelSpecifics
            let voiceChannelSpecificsConfig = childrenConfig['tdmequipment.VoiceChannelSpecifics'];
            if (voiceChannelSpecificsConfig !== null && voiceChannelSpecificsConfig.length !== 0){
                let voiceChannelExtractedConfig = this.extractVoiceChannelSpecificsProperties(defaultVoiceChannelData,voiceChannelSpecificsConfig);
            }

            //DS0ChannelGroup
            let dS0ChannelGroupConfig = childrenConfig['tdmequipment.DS0ChannelGroup'];
            let ds0ChannelGroupData = defaultVoiceChannelData['ds0Channel-group'];
            if (ds0ChannelGroupData !== null && ds0ChannelGroupData.length !== 0){
                let ds0ChannelGroupArray = this.extractDs0ChannelGroupProperties(ds0ChannelGroupData,dS0ChannelGroupConfig);
                defaultVoiceChannelData['ds0Channel-group'] = ds0ChannelGroupArray;
            }
        }
        return defaultVoiceChannelData;
    }



    this.extractVoiceChannelSpecificsProperties = function(defaultVoiceChannelSpecificsData,  voiceChannelSpecificsConfig) {
        let mappings = modelDeviceMapping.getMapping("voiceChannelSpecifics");

        this.traverseAndUpdateVoiceChannelSpecificsConfig('port.voiceChannel', defaultVoiceChannelSpecificsData, voiceChannelSpecificsConfig, mappings);
        return defaultVoiceChannelSpecificsData;
    }



    this.extractDs0ChannelGroupProperties = function(defaultDs0ChannelGroupData,dS0ChannelGroupConfig) {
        let ds0ChannelGroupArray =[];
        let ds0ChannelGroupDefaults = defaultDs0ChannelGroupData[0];
        let mappings = modelDeviceMapping.getMapping("ds0Channel-group");
        let ds0ChannelGroupData = JSON.parse(JSON.stringify(ds0ChannelGroupDefaults));
        if (dS0ChannelGroupConfig !== null && dS0ChannelGroupConfig !== undefined && dS0ChannelGroupConfig.length!= 0){
            for (let i =0; i < defaultDs0ChannelGroupData.length; i++){
                this.traverseAndUpdateDS0ChannelGroupConfig('port.voiceChannel.ds0Channel-group', ds0ChannelGroupData, dS0ChannelGroupConfig, mappings);
                ds0ChannelGroupArray.push(ds0ChannelGroupData);
            }
        }
        return ds0ChannelGroupArray;
    }

    this.extractPortProperties = function(defaultTargetData, portConfig) {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++) {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object') {
                let mappings = modelDeviceMapping.getMapping("port");
                this.traverseAndUpdatePortConfig(targetKey, targetObj, portConfig, mappings);
            }
        }
        return defaultTargetData;
    }

    this.traverseAndUpdatePortConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.voiceChannel" && mappedKey !== "port.voicePort") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdatePortConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.traverseAndUpdateVoicePortSpecificsConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];

            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.voicePort") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateVoicePortSpecificsConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.traverseAndUpdateVoiceChannelConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.voiceChannel.signal-mode" && mappedKey !== "port.voiceChannel.ds0Channel-group") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateVoiceChannelConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.traverseAndUpdateVoiceChannelSpecificsConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];

            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.voiceChannel.admin-state" && mappedKey !== "port.voiceChannel.ds0Channel-group") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateVoiceChannelSpecificsConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.traverseAndUpdateDS0ChannelGroupConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (value != null && typeof value === 'object') {
                this.traverseAndUpdateDS0ChannelGroupConfig(mappedKey, value, parsedDeviceConfig, mappings);
            } else {
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
            }
        }
        return obj;
    }

    this.getAndUpdateFromDeviceConfig = function(mappings, mappedKey, targetKey, targetObj, parsedDeviceConfig) {
        // Get the key from mapping against targetKey
        // If the mapping key is not undefined, Get the value from deviceKey
        // if the value from deviceConfig against that mapping key is not n
        let nfmpKey = mappings[mappedKey];
        let deviceValue = parsedDeviceConfig[nfmpKey];

        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);
    }

    this.transformDeviceValue = function(mappedKey, deviceValue) {
        if (deviceValue !== null) {
            switch (mappedKey) {
                case "port.admin-state":
                case "port.voiceChannel.admin-state":
                case "port.voiceChannel.ds0Channel-group.admin-state":
                    deviceValue = this.transformAdminStateValue(deviceValue);
                    break;
                case "port.voiceChannel.ds0Channel-group.encapType":
                    deviceValue = this.transformEncapTypeValue(deviceValue);
                    break;
                case "port.voiceChannel.signal-mode":
                    deviceValue = this.convertToTransmissionMode(deviceValue);
                    break;
            }
            return deviceValue;
        }
    }

    this.constructSearchString = function(neId, portId) {
        let portFullName =  util.getBaseFdnForPort(neId, portId);
        let jsonPayLoad = {
            "fullClassName": "equipment.PhysicalPort",
            "filter":{
                "equal":{
                    "name":"objectFullName",
                    "value":portFullName
                }
            }
        };

        return jsonPayLoad;
    }

    this.transformAdminStateValue = function(deviceValue) {
        switch (deviceValue) {
            case "portInService":
                return "Up";
            case "portOutOfService":
                return 'Down';
        }
    }

    this.convertToTransmissionMode = function (deviceValue) {
        if (deviceValue == "em") {
            return "EM";
        }
        else {
            return "Transmission-only";
        }
    }

    this.transformEncapTypeValue = function(deviceValue) {
        switch (deviceValue) {
            case "cemEncap":
                return 'CEM';
        }
    }

}
