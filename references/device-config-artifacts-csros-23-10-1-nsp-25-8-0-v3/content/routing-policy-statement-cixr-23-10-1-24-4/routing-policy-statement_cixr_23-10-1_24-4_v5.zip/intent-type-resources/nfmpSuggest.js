function NfmpSuggest() {
  this.getPolicyStatementName = function (neId) {
        let className = "rp.PolicyStatement";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "policyStatementName"
                ]
            }
        };
        return this.getData(searchObject, className, "policyStatementName")
  }
  this.getPrefixListName = function (neId) {
          let className = "rp.PrefixList";
          let searchObject = {
              "fullClassName": className,
              "filter": {
                  "equal": {
                      "name": "siteId",
                      "value": neId
                  }
              },
              "resultFilter": {
                  "children": "",
                  "attribute": [
                      "prefixListName"
                  ]
              }
          };
          return this.getData(searchObject, className, "prefixListName")
    }

    this.getPrefixListNameCondExpr = function (neId) {
          let className = "rp.PrefixList";
          let searchObject = {
              "fullClassName": className,
              "filter": {
                  "equal": {
                      "name": "siteId",
                      "value": neId
                  }
              },
              "resultFilter": {
                  "children": "",
                  "attribute": [
                      "prefixListName"
                  ]
              }
          };
          let prefixLists = this.getData(searchObject, className, "prefixListName")
          return prefixLists.map(item => `[${item}]`);
    }

    this.getCommunityListName = function (neId) {
          let className = "rp.Community";
          let searchObject = {
              "fullClassName": className,
              "filter": {
                  "equal": {
                      "name": "siteId",
                      "value": neId
                  }
              },
              "resultFilter": {
                  "children": "",
                  "attribute": [
                      "communityName"
                  ]
              }
          };
          return this.getData(searchObject, className, "communityName")
    }
    this.getGlobalVariableName = function (neId, contextConfig) {
          let retArray = [];
          let className = "rp.GlobalVariables";
          let searchObject = {
              "fullClassName": className,
              "filter": {
                  "equal": {
                      "name": "siteId",
                      "value": neId
                  }
              },
              "resultFilter": {
                  "children": "",
                  "attribute": [
                      "globalVarName"
                  ]
              }
          };
          retArray = this.getData(searchObject, className, "globalVarName");
          let policyVariablesList = [];
          if(contextConfig["rp-PolicyStatement"])
          {
            let policyStmtEntries = contextConfig["rp-PolicyStatement"]["rp-PolicyStatementEntry"]
            if(policyStmtEntries)
            {
                policyStmtEntries.forEach(entry => {
                    if(entry["rp-FromCriteria"] && entry["rp-FromCriteria"]["rp-PSPolicyVariables"])
                    {
                        let policyVariables = entry["rp-FromCriteria"]["rp-PSPolicyVariables"];
                        policyVariables.forEach(variable => {
                            if (policyVariablesList.indexOf(variable["policyVarName"]) === -1) { // indexOf() checks if "variable" exists in the array
                                policyVariablesList.push(variable["policyVarName"]);
                            }
                        });
                    }
                });
            }
          }
          else if(contextConfig["rp-FromCriteria"] && contextConfig["rp-FromCriteria"]["rp-PSPolicyVariables"])
          {
            let policyVariables = contextConfig["rp-FromCriteria"]["rp-PSPolicyVariables"];
            policyVariables.forEach(variable => {
                if (policyVariablesList.indexOf(variable["policyVarName"]) === -1) { // indexOf() checks if "variable" exists in the array
                    policyVariablesList.push(variable["policyVarName"]);
                }
            });
          }
          logger.info("Policy Variables********************" + policyVariablesList);
          retArray = retArray.concat(policyVariablesList);
          return retArray;
    }
  this.getAdminTagPolicy = function (neId) {
        let className = "rtr.AdminTagPolicy";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "policyName"
                ]
            }
        };
        return this.getData(searchObject, className, "policyName")
  }
  this.getASPathName = function (neId) {
        let className = "rp.ASPath";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "pathName"
                ]
            }
        };
        return this.getData(searchObject, className, "pathName")
  }
    this.getDampingProfile = function (neId) {
        let className = "rp.Damping";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "dampingName"
                ]
            }
        };
        return this.getData(searchObject, className, "dampingName")
  }
  this.getSRv6Locator = function (neId) {
        let className = "rtr.SRv6Locator";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "locatorName"
                ]
            }
        };
        return this.getData(searchObject, className, "locatorName")
      }
    this.getMulticastRedirectionInterface = function (neId) {
        let className = "rtr.DirectInterfaceCtp";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "nodeId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "terminatedObjectName"
                ]
            }
        };
        return this.getData(searchObject, className, "terminatedObjectName")
      }

       this.getInterfaceData = function (neId, interfaceData ,type, name)
       {
           let nfmpFwk = new NfmpFwk();
           let className = "rtr.DirectInterfaceCtp";

           // Initialize the filter with the type and interfaceData
           let searchFilter = {
               "and": {
                   "equal": [
                       {
                           "name": type,
                           "value": interfaceData
                       }
                   ]
               }
           };

           // Conditionally add neId to the filter only if it is not empty
           if (neId) {
               searchFilter.and.equal.unshift({
                   "name": "nodeId",
                   "value": neId
               });
           }

           // Create the searchObject with the updated filter
           let searchObject = {
               "fullClassName": className,
               "filter": searchFilter,
               "resultFilter": {
                   "children": "",
                   "attribute": [
                       name
                   ]
               }
           };

           let resultFetch = nfmpFwk.post("/v3/search", searchObject);
           let finalResponse = JSON.parse(resultFetch.response);
           let data = (finalResponse[className] && finalResponse[className][name]);
           return data;
       }

    this.getASPathGroupName = function (neId) {
          let className = "rp.ASPathGroup";
          let searchObject = {
              "fullClassName": className,
              "filter": {
                  "equal": {
                      "name": "siteId",
                      "value": neId
                  }
              },
              "resultFilter": {
                  "children": "",
                  "attribute": [
                      "asPathGroupName"
                  ]
              }
          };
          return this.getData(searchObject, className, "asPathGroupName")
    }
    this.getSRMaintPolicy = function (neId) {
      let className = "rtr.SegmentRoutingMaintenancePolicy";
      let searchObject = {
          "fullClassName": className,
          "filter": {
              "equal": {
                  "name": "siteId",
                  "value": neId
              }
          },
          "resultFilter": {
              "children": "",
              "attribute": [
                  "displayedName"
              ]
          }
      };
      return this.getData(searchObject, className, "displayedName")
    }
  this.getRouteDistinguisher = function (neId) {
      let className = "rp.RouteDistinguisher";
      let searchObject = {
          "fullClassName": className,
          "filter": {
              "equal": {
                  "name": "siteId",
                  "value": neId
              }
          },
          "resultFilter": {
              "children": "",
              "attribute": [
                  "routeDistinguisherName"
              ]
          }
      };
      return this.getData(searchObject, className, "routeDistinguisherName")
  }

  this.getPolicyVarValue = function(neId) {
      let communityListName = this.getCommunityListName(neId);
      let asPathName = this.getASPathName(neId);
      let asPathGroupName = this.getASPathGroupName(neId);
      let prefixListName = this.getPrefixListName(neId);

      let combinedResult = [].concat(communityListName, asPathName, asPathGroupName, prefixListName);

      return combinedResult;
  }

  this.getInterfaceNames = function (neId) {
        let className = "rtr.NetworkInterface";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "equal": {
                    "name": "nodeId",
                    "value": neId
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObject, className, "displayedName")
    }

  this.getData = function (searchObjectJson, className, type) {
        let nfmpFwk = new NfmpFwk();
        let ret = [];
        let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        let finalResponse = JSON.parse(resultFetch.response);

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    ret.push(value[type]);
                })
            }
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
  }
}
