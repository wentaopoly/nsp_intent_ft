function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        localObjectFullName = ifIpv6AddrExist(localObjectFullName);
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        objectFullName = ifIpv6AddrExist(objectFullName);
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
       if (payload.configInfo) {
           if (payload.configInfo["nqueue.Policy"]) {
              let nQueuePolicyData = payload.configInfo["nqueue.Policy"];
              if (nQueuePolicyData.egrHsmdaWrrPlcy) {
                if (!nQueuePolicyData.egrHsmdaWrrPlcy.toString().startsWith("HSMDA Slope:")) {
                  let nfmpNameExtension = "HSMDA Slope:"
                  let egrHsmdaWrrPlcyData  = nfmpNameExtension + nQueuePolicyData.egrHsmdaWrrPlcy;
                  nQueuePolicyData.egrHsmdaWrrPlcy = egrHsmdaWrrPlcyData;
                }
              }
              if (nQueuePolicyData.hsAttachmentPolicy) {
                if (!nQueuePolicyData.hsAttachmentPolicy.toString().startsWith("HsAttachmentPolicy:hsAtt-")) {
                  let nfmpNameExtension = "HsAttachmentPolicy:hsAtt-"
                  let hsAttachmentPolicyData  = nfmpNameExtension + nQueuePolicyData.hsAttachmentPolicy;
                  nQueuePolicyData.hsAttachmentPolicy = hsAttachmentPolicyData;
                }
              }
              const nQueueEntryData = nQueuePolicyData && nQueuePolicyData["children-Set"] && nQueuePolicyData["children-Set"]["nqueue.Entry"];
                if (nQueueEntryData) {
                   nQueueEntryData.forEach(nQueueSlopePolicyPointer => {
                     if (nQueueSlopePolicyPointer.hasOwnProperty("slopePolicyPointer") && (!nQueueSlopePolicyPointer.slopePolicyPointer.toString().startsWith("Slope:"))) {
                      let nfmpNameExtension = "Slope:";
                        nQueueSlopePolicyPointer.slopePolicyPointer = nfmpNameExtension + nQueueSlopePolicyPointer.slopePolicyPointer;
                     }
                   });
                   nQueueEntryData.forEach(nQueuehsWredQueueSlopePlcy => {
                      if (nQueuehsWredQueueSlopePlcy.hasOwnProperty("hsWredQueueSlopePlcyPointer") && (!nQueuehsWredQueueSlopePlcy.hsWredQueueSlopePlcyPointer.toString().startsWith("Slope:"))) {
                      let nfmpNameExtension = "Slope:"
                        nQueuehsWredQueueSlopePlcy.hsWredQueueSlopePlcyPointer = nfmpNameExtension + nQueuehsWredQueueSlopePlcy.hsWredQueueSlopePlcyPointer;
                     }
                   });
                }
           }
       }
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
      if(xpath == "nqueue-Entry.portAvgOverhead" || xpath == "nqueue-Entry.cbs" || xpath == "nqueue-Entry.mbs"|| xpath == "nqueue-Entry.hsMbs")
       {
          if(targetValue && !isNaN(targetValue) && !targetValue.contains("."))
          {
              targetValue = Number(targetValue);
             targetValue = targetValue.toFixed(1);
          }
       }
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
       if (xpath === "egrHsmdaWrrPlcy") {
           targetValue = brownFieldNfmpNameSupport(targetValue, "HSMDA Slope:");
       } else if (xpath === "hsAttachmentPolicy") {
           targetValue = brownFieldNfmpNameSupport(targetValue, "HsAttachmentPolicy:hsAtt-");
       }
       function brownFieldNfmpNameSupport(input, nameExtension) {
         if (input !== undefined && input.startsWith(nameExtension)) {
            var input1 = input.replace(nameExtension, "");
            return input1;
         }
         return input;
        }
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
    function ifIpv6AddrExist(input) {
      let firstColonIndex = input.indexOf(':') + 1;
      let lastColonIndex = input.lastIndexOf(':') - 14;
      let ip = input.substring(firstColonIndex, lastColonIndex);
      ip = ip.replaceAll(':', '_');
      let result = input.substring(0, firstColonIndex) + ip + input.substring(lastColonIndex);
      return result;
   }
}
