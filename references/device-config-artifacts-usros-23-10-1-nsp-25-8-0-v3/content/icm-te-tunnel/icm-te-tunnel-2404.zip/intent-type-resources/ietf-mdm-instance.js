load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'mediator-fwk.js'});
MDMInstance.prototype.imLogger = null;
MDMInstance.prototype.ietfUtil = new IetfUtilities();
MDMInstance.prototype.nspMediator = new MediatorFramework("NSP");
MDMInstance.prototype.pathArr = null;

load({script: resourceProvider.getResource("color-mapping.js"),name: "color-mapping"});
colorAdminTagMapping = new ColorMapping().colorMapping();

function MDMInstance() {
    this.imLogger = new IntentLogger();
}

MDMInstance.prototype.setImLogger = function (logger) {
    this.imLogger = logger;
    this.ietfUtil.setImLogger(logger);
    this.nspMediator.setImLogger(logger);
};

MDMInstance.prototype.deploySync = function (requestContext, results, device, tunnelId, neType) {
    this.imLogger.info("[ietf-mdm-instance][deploySync] device {}", device);
    var destination = requestContext.get("intentConfigJson")["destination"];
    if (destination === device && requestContext.get("intentConfigJson")["bidirectional"]) {
        destination = requestContext.get("intentConfigJson")["source"];
    }

    var templateMetaInfo = this.getDeviceTemplate(device, requestContext);
    this.imLogger.debug("[ietf-mdm-instance][deploySync] templateMappings {}", JSON.stringify(templateMetaInfo));
    if (!templateMetaInfo)
        throw new RuntimeException('Cannot resolve template file for ' + device + ". Please check mdm-template-mapping.json");

    var pathPayload = this.pathPayload(requestContext, device, destination, templateMetaInfo, false);

    var config = requestContext.get("intentConfigJson");
    if (config["association-objects"] && config["association-objects"]["association-object-extended"] && config["association-objects"]["association-object-extended"][0]) {
        config["path-profile"] = config["association-objects"]["association-object-extended"][0]["id"];
        if (config["association-objects"]["association-object-extended"][0]["extended-id"]) {
            config["path-group"] = parseInt(config["association-objects"]["association-object-extended"][0]["extended-id"].replace(":", ''), 16);
        }
    }
    if(config["color"])
    {
        config["color"] = colorAdminTagMapping[config["color"]];
    }
    if(config["signaling-type"] == "path-setup-sr")
        config["protection"]["enable"] = false;
    var lspPayload = this.objectPayload(templateMetaInfo["lspTemplate"], requestContext.get("target"), config, device, destination, this.pathArr);
    if (lspPayload["secondary"] && lspPayload["secondary"].length === 0) delete lspPayload.secondary;

    //Augment to enable egress monitoring to on always
    if(templateMetaInfo["type"] !== "Cisco" && templateMetaInfo["type"] !== "CiscoR-IOSXRV9000-CC" && templateMetaInfo["type"] !== "Juniper"&& templateMetaInfo["type"] !== "ATN 950D" && templateMetaInfo["type"] !== "ATN 910C-G" && templateMetaInfo["type"] !== "NetEngine 8000" ){
        if(neType.indexOf("IXR") == -1) {
            this.imLogger.debug("[ietf-mdm-instance][deploySync] enable egress monitoring");
            this.populateEgressStats(lspPayload);
        }
    }
    var payload = this.constructPayload(pathPayload, lspPayload, templateMetaInfo["lspTarget"], requestContext.get("target"), "replace", templateMetaInfo["type"]);
    this.imLogger.debug("[ietf-mdm-instance][deploySync] payload {}", JSON.stringify(payload, null, 2));
    this.send(templateMetaInfo["baseUrl"], payload);
    return results;
};

MDMInstance.prototype.getPathName = function (pathType, lspName, pathName, requestContext, type) {
    if (pathType === "hopless") {
        return "hopless"
    } else if (pathType === "primary") {
        this.imLogger.debug("[ietf-mdm-instance][getPathName] secondary name contains {}", pathName.indexOf(lspName + "_"));

        if(type == "ATN 950D" || type == "ATN 910C-G" || type == "NetEngine 8000"){
            return pathName;
        }
        else {

        if (pathName.indexOf(lspName + "_") !== -1) {
            return pathName;
        } else if (requestContext && requestContext.get("isBF")) {
            return pathName;
        }else {
            return lspName + "_" + pathName;
        }
    }
    } else {
        this.imLogger.debug("[ietf-mdm-instance][getPathName] secondary name contains {}", pathName.indexOf("_secondary_"));
        if(type == "ATN 950D" || type == "ATN 910C-G" || type == "NetEngine 8000"){
            return pathName;
        }
        else{
        if (pathName.indexOf("_secondary_") !== -1) {
            return pathName;
        } else if (requestContext && requestContext.get("isBF")) {
            return pathName;
        } else{
            return lspName + "_secondary_" + pathName;
        }
    }
    }
};

MDMInstance.prototype.pathPayload = function (requestContext, device, destination, templateMetaInfo, onlyPathName) {
    this.pathArr = {"primary": [], "secondary": [], "hopless": []};
    var pathPayloadArr = [];
    var config = requestContext.get("intentConfigJson");
    this.imLogger.debug("[ietf-mdm-instance][pathPayload]  config {} ", JSON.stringify(config, null, 2));

    if (!config["primary-paths"] || !config["primary-paths"]["primary-path"]) {
        //common hopless - No primary path specified - uni
        this.imLogger.debug("[ietf-mdm-instance][pathPayload] common hopless - No primary path specified {}", device);
        this.populateEachPath(requestContext, device, destination, templateMetaInfo, {"name": "hopless"}, pathPayloadArr, "hopless", onlyPathName);
    } else {
        var primaryConf = config["primary-paths"]["primary-path"][0];
        //Bi-directional checks
        if (config["destination"] === device && config["bidirectional"]) {
            //common hopless - No primary path specified - reverse
            if (!primaryConf["primary-reverse-path"] || primaryConf["primary-reverse-path"] === "" || (primaryConf["primary-reverse-path"] && !primaryConf["primary-reverse-path"]["name"])) {
                this.populateEachPath(requestContext, device, destination, templateMetaInfo, {"name": "hopless"}, pathPayloadArr, "hopless", onlyPathName);
            } else {
                //if route-object-include-exclude doesnt exists, then init empty array to avoid freemarker failures
                if (primaryConf["primary-reverse-path"]["explicit-route-objects-always"] === "") primaryConf["primary-reverse-path"]["explicit-route-objects-always"] = {};
                if (!primaryConf["primary-reverse-path"]["explicit-route-objects-always"]["route-object-include-exclude"]
                    || primaryConf["primary-reverse-path"]["explicit-route-objects-always"]["route-object-include-exclude"] === "")
                    primaryConf["primary-reverse-path"]["explicit-route-objects-always"]["route-object-include-exclude"] = [];

                //Explicit reverse path
                this.populateEachPath(requestContext, device, destination, templateMetaInfo, primaryConf["primary-reverse-path"], pathPayloadArr, "primary", onlyPathName);
            }
        } else {
            //if route-object-include-exclude doesnt exists, then init empty array to avoid freemarker failures
            if (primaryConf["explicit-route-objects-always"] === "") primaryConf["explicit-route-objects-always"] = {};
            if (!primaryConf["explicit-route-objects-always"]["route-object-include-exclude"]
                || primaryConf["explicit-route-objects-always"]["route-object-include-exclude"] === "")
                primaryConf["explicit-route-objects-always"]["route-object-include-exclude"] = [];

            //Explicit path
            this.populateEachPath(requestContext, device, destination, templateMetaInfo, primaryConf, pathPayloadArr, "primary", onlyPathName);
        }
    }

    //Secondary path
    if (config["secondary-paths"] && config["secondary-paths"]["secondary-path"]) {
        for (var h = 0; h < config["secondary-paths"]["secondary-path"].length; h++) {
            //if route-object-include-exclude doesnt exists, then init empty array to avoid freemarker failures
            if (config["secondary-paths"]["secondary-path"][h]["explicit-route-objects-always"] === "") config["secondary-paths"]["secondary-path"][h]["explicit-route-objects-always"] = {};
            if (!config["secondary-paths"]["secondary-path"][h]["explicit-route-objects-always"]["route-object-include-exclude"]
                || config["secondary-paths"]["secondary-path"][h]["explicit-route-objects-always"]["route-object-include-exclude"] === "")
                config["secondary-paths"]["secondary-path"][h]["explicit-route-objects-always"]["route-object-include-exclude"] = [];

            this.populateEachPath(requestContext, device, destination, templateMetaInfo, config["secondary-paths"]["secondary-path"][h], pathPayloadArr, "secondary", onlyPathName);
        }
    }

    //Secondary reverse path
    if (config["destination"] === device && config["bidirectional"] && config["secondary-reverse-paths"] && config["secondary-reverse-paths"] ["secondary-reverse-path"]) {
        for (var i = 0; i < config["secondary-reverse-paths"]["secondary-reverse-path"].length; i++) {
            //if route-object-include-exclude doesnt exists, then init empty array to avoid freemarker failures
            if (config["secondary-reverse-paths"] ["secondary-reverse-path"][i]["explicit-route-objects-always"] === "") config["secondary-reverse-paths"] ["secondary-reverse-path"][i]["explicit-route-objects-always"] = {};
            if (!config["secondary-reverse-paths"] ["secondary-reverse-path"][i]["explicit-route-objects-always"]["route-object-include-exclude"]
                || config["secondary-reverse-paths"] ["secondary-reverse-path"][i]["explicit-route-objects-always"]["route-object-include-exclude"] === "")
                config["secondary-reverse-paths"] ["secondary-reverse-path"][i]["explicit-route-objects-always"]["route-object-include-exclude"] = [];

            this.populateEachPath(requestContext, device, destination, templateMetaInfo, config["secondary-reverse-paths"]["secondary-reverse-path"][i], pathPayloadArr, "secondary", onlyPathName);
        }
    }

    this.imLogger.info("[ietf-mdm-instance][pathPayload]  pathPayloadArr {} ", JSON.stringify(pathPayloadArr, null, 2));
    return pathPayloadArr;
};

MDMInstance.prototype.populateEachPath = function (requestContext, device, destination, templateMetaInfo, config, pathPayloadArr, pathType, onlyPathName) {
    var bw = 0;
    var hopCount = 0;
    var isStandby = false;
    var isSrlg = false;
    var lspConfig = requestContext.get("intentConfigJson");
    var setupPriority = lspConfig["setup-priority"];
    var holdPriorioty = lspConfig["hold-priority"];
    var includeAdminGroup = [];
    var excludeAdminGroup = [];
    var wtr = 10;

    if (config["te-bandwidth"] && config["te-bandwidth"]["generic"]) {
        if(templateMetaInfo["type"] === "ATN 950D" || templateMetaInfo["type"] === "ATN 910C-G" || templateMetaInfo["type"] == "NetEngine 8000" || templateMetaInfo["type"] === "Cisco" || templateMetaInfo["type"] === "CiscoR-IOSXRV9000-CC"){
            bw = parseInt(config["te-bandwidth"]["generic"]) / 1000;

        }else{
        bw = parseInt(config["te-bandwidth"]["generic"]) / 1000000;
        }
    } else if (lspConfig["te-bandwidth"] && lspConfig["te-bandwidth"]["generic"]) {
        if(templateMetaInfo["type"] === "ATN 950D" || templateMetaInfo["type"] === "ATN 910C-G" || templateMetaInfo["type"] == "NetEngine 8000"|| templateMetaInfo["type"] === "Cisco" || templateMetaInfo["type"] === "CiscoR-IOSXRV9000-CC"){
            bw = parseInt(config["te-bandwidth"]["generic"]) / 1000;
        }else{
        bw = parseInt(lspConfig["te-bandwidth"]["generic"]) / 1000000;
        }
    }

    if (config["setup-priority"] && config["setup-priority"] !== 7) {
        setupPriority = config["setup-priority"];
    }

    if (config["hold-priority"] && config["hold-priority"] !== 0) {
        holdPriorioty = config["hold-priority"];
    }

    if (config["restoration"] && config["restoration"]["enable"] && config["restoration"]["restoration-scheme"] === "restoration-scheme-presignaled") {
        isStandby = true;
        wtr = config["restoration"]["wait-to-revert"];
    }

    if (config["disjointness"] && config["disjointness"] === "srlg") {
        isSrlg = true;
    }

    if (config["path-metric-bounds"] && config["path-metric-bounds"]["path-metric-bound"]){
        config["path-metric-bounds"]["path-metric-bound"].forEach(function (lPathMetric) {
            if (lPathMetric["metric-type"] === "path-metric-hop"){
                hopCount = lPathMetric["upper-bound"];
            }
        })
    }

    if (config["path-affinity-names"] && config["path-affinity-names"]["path-affinity-name"]) {
        config["path-affinity-names"]["path-affinity-name"].forEach(function (type) {
            if (type["usage"] === "resource-aff-include-any") {
                type["affinity-name"].forEach(function (name) {
                    includeAdminGroup.push(name["name"])
                })
            }
            if (type["usage"] === "resource-aff-exclude-any") {
                type["affinity-name"].forEach(function (name) {
                    excludeAdminGroup.push(name["name"])
                })
            }
        })
    }

    config["name"] = this.getPathName(pathType, requestContext.get("target"), config["name"], requestContext, templateMetaInfo["type"]);
    this.pathArr[pathType].push({
        "type": pathType,
        "name": config["name"],
        "conf": config,
        "bandwidth": Math.round(bw),
        "hop": parseInt(hopCount),
        "setupPriority": setupPriority,
        "holdPriorioty": holdPriorioty,
        "isStandby": isStandby,
        "isSrlg": isSrlg,
        "includeAdminGroup": includeAdminGroup,
        "excludeAdminGroup": excludeAdminGroup,
        "wtr": wtr
    });

    if (onlyPathName) { //Delete Usecase
        if (pathType !== "hopless") {
            pathPayloadArr.push({
                "target": templateMetaInfo["pathTarget"],
                "pathName": config["name"]
            });
        }
    } else { //Create/Audit Usecase
        var pathPay = this.objectPayload(templateMetaInfo["pathTemplate"], requestContext.get("target"), requestContext.get("intentConfigJson"), device, destination, config);
        pathPayloadArr.push({
            "payload": pathPay,
            "target": templateMetaInfo["pathTarget"],
            "pathName": config["name"]
        });
    }
};

MDMInstance.prototype.deleteSync = function (requestContext, results, device) {
    this.imLogger.info("[ietf-mdm-instance][deploySync] device {}", device);
    var destination = requestContext.get("intentConfigJson")["destination"];
    if (destination === device && requestContext.get("intentConfigJson")["bidirectional"]) {
        destination = requestContext.get("intentConfigJson")["source"];
    }

    var templateMetaInfo = this.getDeviceTemplate(device, requestContext);
    this.imLogger.debug("[ietf-mdm-instance][deploySync] templateMappings {}", JSON.stringify(templateMetaInfo));
    if (!templateMetaInfo)
        throw new RuntimeException('Cannot resolve template file for ' + device + ". Please check mdm-template-mapping.json");

    var pathPayload = this.pathPayload(requestContext, device, destination, templateMetaInfo, true);

    var payload = this.constructPayload(pathPayload, {}, templateMetaInfo["lspTarget"], requestContext.get("target"), "delete", templateMetaInfo["type"]);
    this.imLogger.info("[ietf-mdm-instance][deleteSync] payload {}", JSON.stringify(payload, null, 2));

    this.send(templateMetaInfo["baseUrl"], payload);

    return results;
};


MDMInstance.prototype.audit = function (requestContext, device, auditReport, neType) {

    var templateMetaInfo = this.getDeviceTemplate(device, requestContext);
    var type = templateMetaInfo["type"];

    this.imLogger.debug("[ietf-mdm-instance][audit] templateMappings {}", JSON.stringify(templateMetaInfo));
    if (!templateMetaInfo)
        throw new RuntimeException('Cannot resolve template file for ' + device + ". Please check mdm-template-mapping.json");

    var config = requestContext.get("intentConfigJson");
    var destination = requestContext.get("intentConfigJson")["destination"];
    if (destination === device && requestContext.get("intentConfigJson")["bidirectional"]) {
        destination = requestContext.get("intentConfigJson")["source"];
    }
    if(config["color"])
    {
        config["color"] = colorAdminTagMapping[config["color"]];
    }

    if (config["primary-paths"] && config["primary-paths"]["primary-path"])
    {
        const resp = this.nspMediator.fetch(templateMetaInfo["pathGetUrl"] + requestContext.get("target") + "_" + config["primary-paths"]["primary-path"][0]["name"]);
        if (!resp.success)
            requestContext.put("isBF", true);
    }

    //Populate Path Config payload
    var pathPayloadArr = this.pathPayload(requestContext, device, destination, templateMetaInfo, false);
    this.imLogger.debug("[ietf-mdm-instance][audit] pathPayload {}", JSON.stringify(pathPayloadArr));

    //Populate LSP Config payload
    var lspPayload = this.objectPayload(templateMetaInfo["lspTemplate"], requestContext.get("target"), requestContext.get("intentConfigJson"), device, destination, this.pathArr);
    this.populatePathProfile(lspPayload, requestContext.get("intentConfigJson"));
    if(templateMetaInfo["type"] !== "Cisco" && templateMetaInfo["type"] !== "CiscoR-IOSXRV9000-CC" && templateMetaInfo["type"] !== "Juniper" ){
        if(neType.indexOf("IXR") == -1) {
            this.imLogger.debug("[ietf-mdm-instance][audit] enable egress monitoring");
            this.populateEgressStats(lspPayload);
        }
    }
    if (lspPayload["secondary"] && lspPayload["secondary"].length === 0) delete lspPayload.secondary;
    this.imLogger.info("[ietf-mdm-instance][audit] lspPayload {}", JSON.stringify(lspPayload));

    //Fetch Path and compare
    var self = this;
    pathPayloadArr.forEach(function (pathConf) {
        var pathDeviceConfig = self.nspMediator.fetch(templateMetaInfo["pathGetUrl"] + pathConf.pathName);
        if (!pathDeviceConfig.success)
            throw new RuntimeException('Failed fetch Path');
        pathDeviceConfig = pathDeviceConfig.response[Object.keys(pathDeviceConfig.response)[0]][0];
        // Sort device path configurations
        pathDeviceConfig = self.ietfUtil.sortJSON(pathDeviceConfig, eval(templateMetaInfo["pathKeys"]));
        // Sort intent path configurations
        pathConf.payload = self.ietfUtil.sortJSON(pathConf.payload, eval(templateMetaInfo["pathKeys"]));
        self.imLogger.info("[ietf-mdm-instance][audit] pathDeviceConfig After Sorting {}", JSON.stringify(pathDeviceConfig));
        self.auditJson(type,pathConf.payload, pathDeviceConfig, device, auditReport, pathConf.pathName);
    });

    //Fetch LSP and compare
    var target = requestContext.get("target");
    var interface_portnum = target.split("_")[1];
    if(templateMetaInfo["type"] === "Cisco" || (templateMetaInfo["type"] === "CiscoR-IOSXRV9000-CC")){
    var lspDeviceConfig = this.nspMediator.fetch(templateMetaInfo["lspGetUrl"]+"=tunnel-te"+interface_portnum);
    }else if(templateMetaInfo["type"] !== "ATN 950D" || templateMetaInfo["type"] !== "ATN 910C-G" || templateMetaInfo["type"] !== "NetEngine 8000"){
        var lspDeviceConfig = this.nspMediator.fetch(templateMetaInfo["lspGetUrl"]+"=Tunnel"+interface_portnum);
    }
    else{
    var lspDeviceConfig = this.nspMediator.fetch(templateMetaInfo["lspGetUrl"]);
    }
    this.imLogger.info("[ietf-mdm-instance][audit] lspDeviceConfig After Sorting  {}", JSON.stringify(lspDeviceConfig));
    if (!lspDeviceConfig.success)
        throw new RuntimeException('Failed fetch LSP');
    lspDeviceConfig = lspDeviceConfig.response[Object.keys(lspDeviceConfig.response)[0]][0];
    lspDeviceConfig = this.ietfUtil.sortJSON(lspDeviceConfig, eval(templateMetaInfo["lspKeys"]));
    if(lspDeviceConfig["secondary"]) this.sortPath(lspDeviceConfig["secondary"])
    if(lspPayload["secondary"]) this.sortPath(lspPayload["secondary"])
    this.imLogger.info("[ietf-mdm-instance][audit] lspDeviceConfig After Sorting  {}", JSON.stringify(lspDeviceConfig));
    this.auditJson(type,lspPayload, lspDeviceConfig, device, auditReport);

    return auditReport;
};

MDMInstance.prototype.populatePathProfile = function (lspPayload, config) {
    if (config["association-objects"] && config["association-objects"]["association-object-extended"]) {
        var pathProfile = [{
                "profile-id": config["association-objects"]["association-object-extended"][0]["id"],
        }]
        var extendedId = config["association-objects"]["association-object-extended"][0]["extended-id"];
        if (extendedId) {
            pathProfile[0]["path-group"] = parseInt(extendedId, 16);
        }
        lspPayload["path-profile"] = pathProfile;
    }
}

MDMInstance.prototype.populateEgressStats = function (lspPayload) {
    lspPayload["egress-statistics"] = {
        "admin-state": "enable"
    }
}

MDMInstance.prototype.getDeviceTemplate = function (device, requestContext) {
    try {
        var ret = null;
        var lSourceNodeId = requestContext.get("sourceNodeId")[device];
        var templateMappings = utilityService.processTemplate(resourceProvider.getResource("mdm-template-mapping.json"),
            {deviceName: lSourceNodeId, name: requestContext.get("target")});
        this.imLogger.debug("[ietf-mdm-instance][getDeviceTemplate] templateMappings {}", JSON.stringify(templateMappings));
        var json = JSON.parse(templateMappings);
        var mediatorDeviceInfo = this.ietfUtil.getDeviceInfo(lSourceNodeId);
        this.imLogger.debug("[ietf-mdm-instance][getDeviceTemplate] mediatorDeviceInfo {}", JSON.stringify(mediatorDeviceInfo));

        json.forEach(function (element) {
            if (mediatorDeviceInfo.type.indexOf(element.type) !== -1 && mediatorDeviceInfo.type.indexOf(element.version) !== -1) {
                ret = element;
            } else if (mediatorDeviceInfo.type.indexOf(element.type) !== -1 && (element.version === undefined || element.version === null)) {
                ret = element;
            }
        });
        return ret;
    } catch (e) {
        throw new RuntimeException('Matching device not found for ' + device + " " + e);
    }
};

MDMInstance.prototype.objectPayload = function (resourceName, target, config, device, destination, extraParams) {
    this.imLogger.debug("[ietf-mdm-instance][objectPayload] config {}", JSON.stringify(config));
    this.imLogger.debug("[ietf-mdm-instance][objectPayload] extraParams {}", JSON.stringify(extraParams));
    var defaultAttributes = this.getDefaultAttributes(resourceName);
    try {
        return JSON.parse(utilityService.processTemplate(resourceProvider.getResource(resourceName), {
            "config": config,
            "target": target,
            "device": device,
            "destination": destination,
            "extraParams": extraParams,
            "default" : defaultAttributes
        }));
    } catch (e) {
        throw new RuntimeException("MDM Parsing " + resourceName + " template failed for " + device + " " + e);
    }
};

MDMInstance.prototype.constructPayload = function (pathPayloadArr, lspPayload, lspTarget, target, operation, type) {
    var ret ={};
    var i =0;
    var interface_portnum = target.split("_")[1];

    ret = {
        "ietf-yang-patch:yang-patch": {
            "patch-id": "edit-ietf-te-1",
            "edit": []
        }
    }

    if(operation === "delete")
    {
        this.buildLspPayload(type, ret, target, lspTarget, interface_portnum, operation, lspPayload);
        this.buildPathPayload(pathPayloadArr, ret, operation);
    }
    else
    {
        this.buildPathPayload(pathPayloadArr, ret, operation);
        this.buildLspPayload(type, ret, target, lspTarget, interface_portnum, operation, lspPayload);
    }

    return ret;
};

MDMInstance.prototype.buildLspPayload = function (type, ret, target, lspTarget, interface_portnum, operation, lspPayload) {
    if(type === "Cisco" || type === "CiscoR-IOSXRV9000-CC"){
        ret["ietf-yang-patch:yang-patch"]["edit"].push({
            "edit-id": "config-lsp-1",
            "target": lspTarget + "=" +"tunnel-te"+interface_portnum,
            "operation": operation,
            "value": lspPayload
        })
    }
    else if (type == "ATN 910C-G" || type == "ATN 950D" || type == "NetEngine 8000") {
        ret["ietf-yang-patch:yang-patch"]["edit"].push({
            "edit-id": "config-lsp-1",
            "target": lspTarget + "=" + "Tunnel" + interface_portnum,
            "operation": operation,
            "value": lspPayload
        })
    }
     else {
        ret["ietf-yang-patch:yang-patch"]["edit"].push({
            "edit-id": "config-lsp-1",
            "target": lspTarget + "=" + target,
            "operation": operation,
            "value": lspPayload
        })
    }
};

MDMInstance.prototype.buildPathPayload = function (pathPayloadArr, ret, operation) {
    pathPayloadArr.forEach(function (pathPayload) {
        ret["ietf-yang-patch:yang-patch"]["edit"].push({
            "edit-id": "config-path-" + pathPayload.pathName,
            "target": pathPayload.target + "=" + pathPayload.pathName,
            "operation": operation,
            "value": pathPayload.payload
        })
    });
};

MDMInstance.prototype.send = function (url, payload) {
    this.nspMediator.contentType = "application/yang-patch+json";
    var response = this.nspMediator.patch(url, payload);
    if (!response.success) {
        throw new RuntimeException("Failed to deploy URL " + url + " Response - " + JSON.stringify(response));
    }
};

MDMInstance.prototype.handleNullArrayExpect = function(obj) {
    var lCleanObj = removeEmptyObjects(obj);
    return lCleanObj;
};

function removeEmptyObjects(obj) {
    var rtn = JSON.parse(JSON.stringify(obj)); // Perform a deep copy of obj

    if (typeof(obj) === 'object') {
        for (var key in obj) {
            if (obj[key] === null  || (Array.isArray(obj[key]) && obj[key].toString() === [null, null].toString()) || obj[key] === undefined ) {
                rtn[key]=[""]; // Delete key-value pair from rtn
            }
            if((Array.isArray(obj[key]) && obj[key].every(item => item === null)))
            {
                rtn[key]=[""];
            }
            if(obj[key] === "null"){
                rtn[key]= "";
            }

        }
    }
    return rtn;
}

MDMInstance.prototype.handleDefault = function(obj) {
    var lCleanObj = removeDefaultObjects(obj);
    return lCleanObj;
};

function removeDefaultObjects(obj) {
    var rtn = JSON.parse(JSON.stringify(obj)); // Perform a deep copy of obj

    // Define an array of keys to check for specific operations
    var defaultKeysToDelete = [
        "clear-ip-df", "cpudefend", "l2-mode-enable", "mtu",
        "router-type", "spread-mtu-flag", "statistic-mode",
        "igp-attr", "mpls-tunnel-service-class", "mplstunnelpipe", "auto-bandwidths",
        "best-effort-enable", "bit-error-detection", "bypass",
        "disable-cspf", "entropy-label", "inter-area-reoptimization",
        "metric-inherit-igp", "ordinary-enable", "path-disjoint-calculate",
        "path-metric-type", "pce-delegate", "reoptimization",
        "reoptimization-aggressive", "reserve-style",
        "self-ping", "self-ping-duration", "soft-preempt-enable", "tie-breaking",
        "vrf-name", "soft-preempt-block", "link-up-down-trap-enable", "address-type",
        "backup-frr-inuse", "hot-standby", "mode", "detect-multiplier",
        "bandwidth-protection-enable", "bypass-attributes", "frr-switch-degrade","egress-statistics"
    ];

    if(isRootObject(rtn)){
        if (defaultKeysToDelete.indexOf("statistic-enable") === -1) {
            defaultKeysToDelete.push("statistic-enable");
          }
    }

    if(isSecondaryPathType(rtn)){
        if (defaultKeysToDelete.indexOf("hop-limit") === -1) {
            defaultKeysToDelete.push("hop-limit");
          }
    }

    if (typeof obj === 'object') {
        for (var key in obj) {
            if (obj[key] === null || (Array.isArray(obj[key]) && obj[key].toString() === [null, null].toString()) || obj[key] === undefined) {
                rtn[key] = [""];
            }
            if (Array.isArray(obj[key]) && obj[key].every(item => item === null)) {
                rtn[key] = [""];
            }
            if (obj[key] === "null") {
                rtn[key] = "";
            }
            if (obj[key] === "0x0") {
                delete rtn[key];
            }
            if (obj[key] != null && isSecondaryPathType(obj[key]) && obj[key]["explicit-path-name"] === undefined) {
                // This is for handling empty secondary path in node response even if CLI doesn't have it
                delete rtn[key];
            }
            if (defaultKeysToDelete.indexOf(key)!== -1) {
                delete rtn[key];
            }
        }
    }
    return rtn;
}

MDMInstance.prototype.auditJson = function (type,expectedJson, nodeJson, objKey, auditReport, auditPath, pathType) {
    this.imLogger.debug(" [ietf-mdm-instance] auditJson {expected}: " + JSON.stringify(expectedJson));

    if(type === "Cisco" || type === "CiscoR-IOSXRV9000-CC" || type === "Juniper"){
    expectedJson = this.handleNullArrayExpect(expectedJson);
    nodeJson = this.handleNullArrayExpect(nodeJson);
    }

    if( type === "ATN 950D" || type === "ATN 910C-G" || type == "NetEngine 8000"){
        expectedJson = this.handleDefault(expectedJson);
        nodeJson = this.handleDefault(nodeJson);
        }

    var totalKeys = Object.keys(nodeJson);
    if(type !== "Cisco" && type !== "CiscoR-IOSXRV9000-CC" && type !== "Juniper" && type !== "ATN 950D" && type !== "ATN 910C-G"  && type !== "NetEngine 8000"){
    var index = totalKeys.indexOf("egress-statistics")
    if(index != -1) totalKeys.splice(index,1)
    }
    Object.keys(expectedJson).forEach(function (key) {
        if (totalKeys.indexOf(key) === -1) {
            totalKeys.push(key);
        }
    });
    var self = this;
    totalKeys.forEach(function (key) {
        self.imLogger.debug("[ietf-mdm-instance] BiggestKeySet loop: values for " + key + " are {expected, node}: {" + JSON.stringify(expectedJson[key]) + ", " + JSON.stringify(nodeJson[key]) + "}");
        if(key == "admin-tag") {
           expectedJson["admin-tag"] = [expectedJson["admin-tag"]]
        }
        if ((typeof expectedJson[key] === "object") && (typeof nodeJson[key] === "object")) {
            self.imLogger.debug("[ietf-mdm-instance] Found JSON child => " + key);
            if (key == "primary" || key == "secondary"){
                pathType = key;
            }
            else if (pathType == "primary" || pathType == "secondary") {
                if (expectedJson[key]["path-name"])
                    auditPath = expectedJson[key]["path-name"];
                self.imLogger.debug("[ietf-mdm-instance] pathType {} auditPath {}", JSON.stringify(pathType), JSON.stringify(auditPath));
            }
	     if( type === "ATN 950D" || type === "ATN 910C-G" || type == "NetEngine 8000"){
                if(key == 0 || key == 1){
                    if(expectedJson[key]["path-type"] != undefined || expectedJson[key]["path-type"]!=null){
                        if (expectedJson[key]["path-type"]=="primary"){
                            auditPath = "PrimaryPath" + ":" + expectedJson[key]["explicit-path-name"];
                        }else{
                            auditPath = "SecondaryPath" + ":" + expectedJson[key]["explicit-path-name"];
                        }
                    }else{
                        auditPath = auditPath + ":" + key;
                    }

                }

                else if(auditPath != undefined){
                    auditPath = auditPath + ":" + key;
                }
            }
            new MDMInstance().auditJson(type, expectedJson[key], nodeJson[key], objKey + ":" + key, auditReport, auditPath, pathType);
        } else {
            self.imLogger.debug("[ietf-mdm-instance] Values for " + key + " are {expected, node}: {" + expectedJson[key] + ", " + nodeJson[key] + "}");
            if (expectedJson[key] === nodeJson[key]) {
                self.imLogger.debug("[ietf-mdm-instance] Values for " + key + " are the same.");
            } else {
                var expectedValue = Object.keys(expectedJson).indexOf(key) !== -1 ? expectedJson[key] : "{empty}";
                var actualValue = Object.keys(nodeJson).indexOf(key) !== -1 ? nodeJson[key] : "{empty}";
                if (typeof expectedValue === "object") {
                    expectedValue = JSON.stringify(expectedValue);
                }
                if (typeof actualValue === "object") {
                    actualValue = JSON.stringify(actualValue);
                }
                self.imLogger.error("[ietf-mdm-instance] key - {}, auditPath - {}", key, JSON.stringify(auditPath));
                self.imLogger.error("[ietf-mdm-instance] key - {}, expectedValue - {}", key, JSON.stringify(expectedValue));
                self.imLogger.error("[ietf-mdm-instance] key - {}, actualValue - {}", key, JSON.stringify(actualValue));
                if( type === "ATN 950D" || type === "ATN 910C-G" || type == "NetEngine 8000"){
                    if(auditPath==undefined && key == "ability"){
                        key = "bfd-enable";
                    }

                    if(shouldIgnoreAttributeInAudit(key, expectedValue, actualValue))
                    {
                        return;
                    }
                }

                auditReport.addMisAlignedAttribute(auditFactory.createMisAlignedAttribute((auditPath ? auditPath + "|" + key : key), expectedValue, actualValue, objKey));
            }
        }
    });
};

// This is Huawei specific method to exclude attributes with default values from audit
function shouldIgnoreAttributeInAudit(key, expectedValue, actualValue)
{
    switch (key) {
        case "reoptimization-frequency":
            if (expectedValue === "{empty}" && actualValue === 3600)
                return true;
            break;
        case "hop-limit":
            if (expectedValue === "{empty}" && actualValue === 32)
                return true;
            break;
        default:
            if (expectedValue === "{empty}" && actualValue === "{\"exclude-any\":\"0x0\",\"hop-limit\":32,\"include-any\":\"0x0\",\"path-type\":\"best-effort\"}")
                return true;
            break;
    }
    return false;
};


MDMInstance.prototype.sortPath = function (pathJson) {
    for (let i = 0; i < pathJson.length - 1; i++) {
        for (let j = 0; j < pathJson.length - i - 1; j++) {
            if (pathJson[j]['path-name'] > pathJson[j + 1]['path-name']) {
                let temp = pathJson[j];
                pathJson[j] = pathJson[j + 1];
                pathJson[j + 1] = temp;
            }
        }
    }
};



MDMInstance.prototype.getDefaultAttributes = function(resource){
    const resourceDirectory = resource.split("/", 2)[0];
    var defaultFileName = resourceDirectory + "/default.json";
    var defaultAttributes;
    try {
    var mappings = resourceProvider.getResource(defaultFileName);
    defaultAttributes = JSON.parse(mappings);
    }
    catch (e) {
        this.imLogger.error("[ietf-mdm-instance] {} file not found in resources", defaultFileName);
    }

    return defaultAttributes;

};


function isSecondaryPathType(obj) {
    if (obj["path-type"] && (obj["path-type"] === "hot-standby" || obj["path-type"] === "best-effort") || obj["path-type"] === "ordinary") {
      return true;
    }
    return false;
  };

function isRootObject(obj) {
    if (obj["admin-status"]) {
      return true;
    }
    return false;
  };
