function MediatorFramework(type) {
    this.mediatorType = type;
    if (type === "MDC")
    {
        this.mediatorIp = "nsp-mdt-mdc-mediator-svc";
        this.mediatorPort = "80";
        this.mediatorProtocol = "http";
        this.contentType = "application/yang-patch+json";
    }
    else if (type === "NFMP")
    {
        this.mediatorIp = "nsp-mdt-nfmp-mediator-svc";
        this.mediatorPort = "80";
        this.mediatorProtocol = "http";
    }
    else if (type === "NSP")
    {
        this.mediatorIp = "nsp-mdt-nsp-mediator-svc";
        this.mediatorPort = "80";
        this.mediatorProtocol = "http";
    }
}

MediatorFramework.prototype.mediatorIp = "";
MediatorFramework.prototype.mediatorPort = "";
MediatorFramework.prototype.mediatorProtocol = "";
MediatorFramework.prototype.mediatorType = "";
MediatorFramework.prototype.contentType = "application/json";
MediatorFramework.prototype.acceptType = "application/json";

MediatorFramework.prototype.configRestClient = function (url, httpMethod) {
    logger.info("[MEDIATOR-FWK] Mediator-type: {} protocol: {} ip: {} port: {} URL :{} mediatorHttpMethod :{}", this.mediatorType, this.mediatorProtocol, this.mediatorIp, this.mediatorPort, url, httpMethod);
    restClient.setIp(this.mediatorIp);
    restClient.setPort(this.mediatorPort);
    restClient.setProtocol(this.mediatorProtocol);
};

MediatorFramework.prototype.fetch = function (targetUrl) {
    var result = {};
    this.configRestClient(targetUrl, "GET");
    logger.info("[MEDIATOR-FWK] GET URL: {}", targetUrl);
    restClient.get(targetUrl, "application/json", function (exception, httpStatus, response) {
        result = {
            success: false,
            httpStatus: httpStatus,
            msg: "null"
        };
        logger.info("[MEDIATOR-FWK]  GET response : {}", response);
        if (exception)
        {
            logger.error("[MEDIATOR-FWK] GET Exception Found " + exception);
            result.msg = "Couldn't connect to " + this.mediatorType + ", got response " + response + ", exception " + exception;
        }
        else if (httpStatus !== 200 && httpStatus !== 201)
        {
            result.msg = "Failed to fetch service from " + this.mediatorType + ", got response " + response;
            result.response = JSON.parse(response);
        }
        else
        {
            result.success = true;
            result.msg = JSON.parse(response);
            result.response = JSON.parse(response);
        }
    });
    return result;
};

MediatorFramework.prototype.post = function (targetUrl, expectedJson) {
    var result = {};
    this.configRestClient(targetUrl, "POST");
    logger.info("[MEDIATOR-FWK] POST URL: {}, Payload: {}", targetUrl, JSON.stringify(expectedJson, null, 2));
    restClient.post(targetUrl, "application/json", JSON.stringify(expectedJson), "application/json", function (exception, httpStatus, response) {
        result = {
            success: false,
            httpStatus: httpStatus,
            msg: "null"
        };
        //logger.info("[MEDIATOR-FWK] POST Response {}", response);
        if (exception)
        {
            logger.error("[MEDIATOR-FWK] POST Exception {}", exception);
            result.msg = "Couldn't connect to " + this.mediatorType + ", got response " + response + ", exception " + exception;
        }
        else if (httpStatus !== 200 && httpStatus !== 201)
        {
            result.msg = "Failed deployment to " + this.mediatorType + ", got response " + response;
            result.response = response;
        }
        else
        {
            result.success = true;
            result.msg = "Deployment to " + this.mediatorType + " was successful, got response " + response;
            result.response = response;
        }
    });
    return result;
};

MediatorFramework.prototype.patch = function (targetUrl, expectedJson) {
    if (this.mediatorType === "NSP")
    {
        targetUrl = "patch/" + targetUrl;
    }
    var result = {};
    this.configRestClient(targetUrl, "PATCH");
    logger.info("[MEDIATOR-FWK] PATCH URL: {}, Payload: {}", targetUrl, JSON.stringify(expectedJson, null, 2));
    restClient.patch(targetUrl, this.contentType, JSON.stringify(expectedJson), this.acceptType, function (exception, httpStatus, response) {
        logger.info("[MEDIATOR-FWK]  PATCH response : {}", response);
        result = {
            success: false,
            httpStatus: httpStatus,
            msg: "null"
        };
        if (exception)
        {
            logger.error("[MEDIATOR-FWK] PATCH Exception {}", exception);
            result.msg = "Couldn't connect to " + this.mediatorType + ", got response " + response + ", exception " + exception;
        }
        else if (httpStatus !== 200 && httpStatus !== 201)
        {
            result.msg = "Failed deployment to " + this.mediatorType + "got response " + response;
            result.response = response;
        }
        else
        {
            result.success = true;
            result.msg = "Deployment to " + this.mediatorType + " was successful, got response " + response;
            result.response = response
        }
    });
    return result;
};

MediatorFramework.prototype.put = function (targetUrl, expectedJson) {
    var result = {};
    this.configRestClient(targetUrl, "PUT");
    logger.info("[MEDIATOR-FWK] PUT URL: {}, Payload: {}", targetUrl, JSON.stringify(expectedJson, null, 2));
    restClient.put(targetUrl, this.contentType, JSON.stringify(expectedJson), this.acceptType, function (exception, httpStatus, response) {
        logger.info("[MEDIATOR-FWK]  PUT response :{}", response);
        result = {
            success: false,
            httpStatus: httpStatus,
            msg: "null"
        };
        if (exception)
        {
            logger.error("[MEDIATOR-FWK] PUT Exception Found {}", exception);
            result.msg = "Couldn't connect to " + this.mediatorType + ", got response " + response + ", exception " + exception;
        }
        else if (httpStatus !== 200 && httpStatus !== 201)
        {
            result.msg = "Failed deployment to " + this.mediatorType + ", got response " + response;
            result.response = response;
        }
        else
        {
            result.success = true;
            result.msg = "Deployment to " + this.mediatorType + " was successful, got response " + response;
            result.response = response;
        }
    });
    return result;
};

MediatorFramework.prototype.delete = function (deleteUrl) {
    var result = {};
    this.configRestClient(deleteUrl, "DELETE");
    restClient.delete(deleteUrl, "application/json", function (exception, httpStatus, response) {
        logger.info("[MEDIATOR-FWK]  deleteUrl: {} DELETE response : {}", deleteUrl, response);
        result = {
            success: false,
            httpStatus: httpStatus,
            msg: "null"
        };
        if (exception)
        {
            logger.error("[MEDIATOR-FWK] Delete Exception Found {}", exception);
            result.msg = "Couldn't connect to " + this.mediatorType + ", got response " + response + ", exception " + exception;
        }
        else if (httpStatus !== 200 && httpStatus !== 201 && httpStatus !== 204)
        {
            result.msg = "Failed deployment to " + this.mediatorType + ", got response " + response;
            result.response = response;
        }
        else
        {
            result.success = true;
            result.msg = "Deployment to " + this.mediatorType + " was successful, got response " + response;
            result.response = response;
        }
    });
    return result;
};
