var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});

load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

load({script: resourceProvider.getResource("model-device-mapping.js"), name: "model-device-mapping"});

load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});


var network_qos_class_name = "sasqos.Network";
var network_qos_fdn = "sasNetwork";

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let modelDeviceMapping = new ModelDeviceMapping();
    let util = new utilities();

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let networkQosPolicyId = util.getNetworkQosPolicyId(target);
        let networkQosNwMgrId = util.getNetworkQosManagerId(target);
        let searchPayLoad = this.constructSearchString(neId, networkQosNwMgrId);
        let searchResponse = nfmpFwk.post("/v3/search", searchPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find Network QoS Policy ID : " + networkQosPolicyId + " on NE " + neId);
        }
        let finalResponse = JSON.parse(searchResponse.response);
        if (JSON.stringify(finalResponse) === JSON.stringify({})) {
            throw new RuntimeException("search results is empty for policy ID : " + networkQosPolicyId + " finalResponse: " + JSON.stringify(finalResponse));
        }
        else if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse[network_qos_class_name]];
            logger.info(LOG_PREFIX + "Search results: " + JSON.stringify(finalResponse));
        }
        return finalResponse[0];
    }

    this.constructSearchString = function (neId, nwMgrPolicyId) {
        let objectFullName = "network:" + neId + ":" + network_qos_fdn + ":" + nwMgrPolicyId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        let jsonPayLoad = {
            "fullClassName": network_qos_class_name,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        return jsonPayLoad;
    }

    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedTargetData = JSON.parse(defaultTargetData)[initialPropertyName];
        let loadingTargetData = JSON.parse(JSON.stringify(parsedTargetData));
        logger.info(LOG_PREFIX + "Default data: " + JSON.stringify(loadingTargetData));
        this.extractNonChildProperties(parsedTargetData, deviceConfig);
        let netQosChildConfigs = deviceConfig["children-Set"];
        for (let childAttribute in netQosChildConfigs) {
            switch (childAttribute) {
                case "sasqos.NetworkIngressForwardingClass":
                    {
                        let ingressFcConfig = netQosChildConfigs[childAttribute];
                        parsedTargetData["ingress"]["fc"] = this.extractDeviceProperties(ingressFcConfig, loadingTargetData["ingress"]["fc"][0], "fc", "ingress.fc");
                        break;
                    }
                case "sasqos.NetworkIngressDot1p":
                    {
                        let ingressDot1pConfig = netQosChildConfigs[childAttribute];
                        parsedTargetData["ingress"]["dot1p"] = this.extractDeviceProperties(ingressDot1pConfig, loadingTargetData["ingress"]["dot1p"][0], "dot1p", "ingress.dot1p");
                        break;
                    }
                case "sasqos.NetworkIngressDscp":
                    {
                        let ingressDscpConfig = netQosChildConfigs[childAttribute];
                        parsedTargetData["ingress"]["dscp"] = this.extractDeviceProperties(ingressDscpConfig, loadingTargetData["ingress"]["dscp"][0], "dscp", "ingress.dscp");
                        break;
                    }
                case "sasqos.NetworkIngressLspExp":
                    {
                        let ingressLspExpConfig = netQosChildConfigs[childAttribute];
                        parsedTargetData["ingress"]["lsp-exp"] = this.extractDeviceProperties(ingressLspExpConfig, loadingTargetData["ingress"]["lsp-exp"][0], "lsp-exp", "ingress.lsp-exp");
                        break;
                    }
                case "sasqos.NetworkIngressMeter":
                    {
                        let ingressMeterConfig = netQosChildConfigs[childAttribute];
                        let loadingMeterConfig = loadingTargetData["ingress"]["meter"][0];
                        delete loadingMeterConfig["cbs"];
                        delete loadingMeterConfig["mbs"];
                        parsedTargetData["ingress"]["meter"] = this.extractDeviceProperties(ingressMeterConfig, loadingMeterConfig, "meter", "ingress.meter");
                        break;
                    }
                case "sasqos.NetworkIngressQueue":
                    {
                        let ingressQueueConfig = netQosChildConfigs[childAttribute];
                        parsedTargetData["ingress"]["queue"] = this.extractDeviceProperties(ingressQueueConfig, loadingTargetData["ingress"]["queue"][0], "queue", "ingress.queue");
                        break;
                    }
                case "sasqos.NetworkEgressForwardingClass":
                    {
                        let egressFcConfig = netQosChildConfigs[childAttribute];
                        parsedTargetData["egress"]["fc"] = this.extractDeviceProperties(egressFcConfig, loadingTargetData["egress"]["fc"][0], "fc", "egress.fc");
                        break;
                    }
            }
        }
        let finalTargetData = {};
        finalTargetData[initialPropertyName] = parsedTargetData;
        logger.info(LOG_PREFIX + "Intent data after updating from NFMP: \n" + JSON.stringify(finalTargetData));
        return finalTargetData;
    }

    this.extractNonChildProperties = function (parsedTargetData, deviceConfig) {
        let ingressMapping = modelDeviceMapping.getNetQosIngressMapping();
        let egressMapping = modelDeviceMapping.getNetQosEgressMapping();
        parsedTargetData["description"] = deviceConfig["description"];
        parsedTargetData["scope"] = deviceConfig["scope"];
        if (deviceConfig["nwPolicyType"] === "Type_port") {
            parsedTargetData["type"] = "port";
        }
        if (deviceConfig["nwPolicyType"] === "Type_interface") {
            parsedTargetData["type"] = "ip-interface";
        }
        let ingressObj = parsedTargetData["ingress"];
        delete ingressObj["fc"];
        delete ingressObj["dot1p"];
        delete ingressObj["dscp"];
        delete ingressObj["lsp-exp"];
        delete ingressObj["meter"];
        delete ingressObj["queue"];
        this.traverseAndUpdateConfig("ingress", ingressObj, deviceConfig, ingressMapping, "ingress");
        logger.info(LOG_PREFIX + "Updated properties for Network Qos Ingress - " + JSON.stringify(ingressObj));
        parsedTargetData["ingress"] = ingressObj;

        let egressObj = parsedTargetData["egress"];
        delete egressObj["fc"];
        this.traverseAndUpdateConfig("egress", egressObj, deviceConfig, egressMapping, "egress");
        logger.info(LOG_PREFIX + "Updated properties for Network Qos Egress - " + JSON.stringify(egressObj));
        parsedTargetData["egress"] = egressObj;
    }

    this.extractDeviceProperties = function (configData, defaultDataObj, keyPrefix, mapKey) {
        let configDataArray = [];
        let mappings = modelDeviceMapping.getMapping(mapKey);
        if (!Array.isArray(configData)) {
            configData = [configData];
        }
        for (let idx in configData) {
            let configDataObj = configData[idx];
            let defData = JSON.parse(JSON.stringify(defaultDataObj));
            this.traverseAndUpdateConfig(keyPrefix, defData, configDataObj, mappings, mapKey);
            if (mapKey === "egress.fc" && "de-mark" in defData) {
                if (defData["de-mark"]["force"] === "default") {
                    delete defData["de-mark"];
                }
            }
            if (mapKey === "ingress.fc") {
                if (defData["queue"] === "0") {
                    delete defData["queue"];
                }
                if (defData["multicast-queue"] === "0") {
                    delete defData["multicast-queue"];
                }
                if (defData["multicast-meter"] === "noMeter") {
                    delete defData["multicast-meter"];
                }
                if (defData["meter"] === "noMeter") {
                    delete defData["meter"];
                }
            }
            if (mapKey === "ingress.lsp-exp" && defData["profile"] === "unspecified") {
                delete defData["profile"];
            }
            configDataArray.push(defData);
        }
        logger.info(LOG_PREFIX + "parsedTargetData for: [" + keyPrefix + "]: " + JSON.stringify(configDataArray));
        return configDataArray;
    }

    this.traverseAndUpdateConfig = function (objKey, defDataObj, deviceConfig, mappings, fixKey) {
        let keys = Object.keys(defDataObj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = defDataObj[key];
            let mappedKey = objKey + "." + key;
            if (value != null && typeof value === "object") {
                this.traverseAndUpdateConfig(mappedKey, value, deviceConfig, mappings, fixKey);
            }
            else {
                let nfmpKey = mappings[mappedKey];
                if (mappedKey === "meter.cbs-type") {
                    defDataObj[key] = deviceConfig[nfmpKey];
                    switch (deviceConfig[nfmpKey]) {
                        case "kbits":
                            if (deviceConfig["cbs"] === "-1") {
                                defDataObj["cbs"] = "default";
                            }
                            else {
                                defDataObj["cbs"] = deviceConfig["cbs"];
                            }
                            break;
                        case "kbytes":
                            if (deviceConfig["cbsKiloBytes"] === "-1") {
                                defDataObj["cbs"] = "default";
                            }
                            else {
                                defDataObj["cbs"] = deviceConfig["cbsKiloBytes"];
                            }
                            break;
                        case "bytes":
                            if (deviceConfig["cbsBytes"] === "-1") {
                                defDataObj["cbs"] = "default";
                            }
                            else {
                                defDataObj["cbs"] = deviceConfig["cbsBytes"];
                            }
                            break;
                    }
                }
                if (mappedKey === "meter.mbs-type") {
                    defDataObj[key] = deviceConfig[nfmpKey];
                    switch (deviceConfig[nfmpKey]) {
                        case "kbits":
                            if (deviceConfig["mbs"] === "-1") {
                                defDataObj["mbs"] = "default";
                            }
                            else {
                                defDataObj["mbs"] = deviceConfig["mbs"];
                            }
                            break;
                        case "kbytes":
                            if (deviceConfig["mbsKiloBytes"] === "-1") {
                                defDataObj["mbs"] = "default";
                            }
                            else {
                                defDataObj["mbs"] = deviceConfig["mbsKiloBytes"];
                            }
                            break;
                        case "bytes":
                            if (deviceConfig["mbsBytes"] === "-1") {
                                defDataObj["mbs"] = "default";
                            }
                            else {
                                defDataObj["mbs"] = deviceConfig["mbsBytes"];
                            }
                            break;
                    }
                }
                else {
                    defDataObj[key] = this.transformDeviceValue(mappedKey, deviceConfig[nfmpKey], fixKey);
                }
            }
        }
        return defDataObj;
    }

    this.transformDeviceValue = function (mappedKey, deviceValue, objectKey) {
        if (deviceValue != null) {
            if (objectKey === "ingress") {
                switch (mappedKey) {
                    case "ingress.default-action.profile":
                        if (deviceValue === "dei") {
                            deviceValue = "use-dei";
                        }
                        break;
                    case "ingress.mpls-lsp-exp-profile-map":
                        deviceValue = deviceValue.split(":")[1];
                        break;
                    case "ingress.classification-type.dscp-classification":
                        deviceValue = deviceValue.split(":Dscp-")[1];
                        break;
                    case "ingress.classification-type.dot1p-classification":
                        deviceValue = deviceValue.split(":Dot1p-")[1];
                        break;
                    case "ingress.classification-type.mpls-lsp-exp-classification":
                        deviceValue = deviceValue.split(":lspexp-")[1];
                        break;
                }
            }
            if (objectKey === "egress") {
                switch (mappedKey) {
                    case "egress.remark":
                        deviceValue = deviceValue.split(":")[1];
                        break;
                    case "egress.remarking-type":
                        if (deviceValue === "use_dot1p") {
                            deviceValue = "use-dot1p";
                        }
                        if (deviceValue === "use_dscp") {
                            deviceValue = "use-dscp"
                        }
                        break;
                }
            }
            if (objectKey === "ingress.dot1p") {
                switch (mappedKey) {
                    case "dot1p.dot1p-value":
                        deviceValue = deviceValue.split("_")[1];
                        break;
                    case "dot1p.profile":
                        if (deviceValue === "dei") {
                            deviceValue = "use-dei";
                        }
                        break;
                }
            }
            if (objectKey === "ingress.lsp-exp" && mappedKey === "lsp-exp.lsp-exp-value") {
                deviceValue = deviceValue.split("_")[1];
            }
            if (objectKey === "ingress.meter") {
                switch (mappedKey) {
                    case "meter.mode":
                        if (deviceValue === "trtcm1") {
                            deviceValue = "trtcml";
                        }
                        break;
                    case "meter.rate.pir":
                    case "meter.rate.cir":
                        if (deviceValue === "-1") {
                            deviceValue = "max";
                        }
                        break;
                }
            }
            if (objectKey === "ingress.queue") {
                switch (mappedKey) {
                    case "queue.slope-policy":
                        deviceValue = deviceValue.split(":")[1];
                        break;
                }
            }
            if (objectKey === "egress.fc") {
                switch (mappedKey) {
                    case "fc.dot1p-in-profile":
                    case "fc.dot1p-out-profile":
                    case "fc.dot1p":
                    case "fc.lsp-exp-in-profile":
                    case "fc.lsp-exp-out-profile":
                        deviceValue = deviceValue.split("_")[1];
                        break;
                }
            }
            return deviceValue;
        }
    }
}
