var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});

var network_qos_class_name = "sasqos.Network";
var network_qos_policy_id = "network-policy-id";
var network_qos_nw_mgr_id = "network-manager-id";
var network_qos_fdn = "sasNetwork";
var distribute_url = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true"

function NfmpNetworkFwk() {

    var util = new utilities();
    let nfmpFwk = new NfmpFwk();
    var parseTarget =  new ParseTarget();
    var savedTopology;
    var isAudit = false;
    var isLocalExists = false;
    var isGlobalExists = false;
    var intentDeviationObj = new IntentDeviceDeviation();

    this.synchronize = function(input, result, intentTypeName, xpath, initialPropertyName) {

        if (input.getNetworkState().name() == "delete") {
            logger.info(LOG_PREFIX + "Calling syncDelete");
            return this.syncDelete(input, result);
        }

        savedTopology = input.getCurrentTopology();
        logger.info(LOG_PREFIX + "Saved Topology = " + savedTopology);
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyId = util.getNetworkQosPolicyId(input.getTarget());
        var nwMgrId = util.getNetworkQosManagerId(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        intentConfig = this.removeEmptyContainers("", intentConfig, "", neId);
        intentConfig[network_qos_policy_id] = parseInt(policyId);
        intentConfig[network_qos_nw_mgr_id] = parseInt(nwMgrId);
        logger.info(LOG_PREFIX + "Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info(LOG_PREFIX + "Target device = " + neId);
        logger.info(LOG_PREFIX + "Target Network QoS Policy ID = " + policyId);
        this.createOrModify(neId, intentConfig);
        return util.setSuccessResult(result, savedTopology);
    }

    this.syncDelete = function (input, result) {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyId = util.getNetworkQosPolicyId(input.getTarget());
        var nwMgrId = util.getNetworkQosManagerId(input.getTarget());
        var objectFullName = "network:" + neId + ":" + network_qos_fdn + ":" + nwMgrId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        if (util.isObjectExists(network_qos_class_name, objectFullName)) {
            logger.info(LOG_PREFIX + "syncDelete(): Deleting " + objectFullName);
            var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
            if (!deleteResult.success) {
                logger.info(LOG_PREFIX + "syncDelete(): Unable to Delete: " + deleteResult.msg);
                throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
            }
            result.setSuccess(true);
        }
        else {
            logger.info(LOG_PREFIX + "syncDelete(): There is no Network QoS policy :" +
                nwMgrId + " on " + neId);
            result.setSuccess(false);
        }
    }

    this.createOrModify= function(neId, intentConfig) {

        var objectFullName = network_qos_fdn + ":" + intentConfig[network_qos_nw_mgr_id];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        logger.info(LOG_PREFIX + "Searching if any local policy exists on NE: " + neId);
        var localPolicy = util.getIfObjectExists(network_qos_class_name, localPolicyFullName);
        var result;
        var networkQosPayload;
        var distributePayload;
        var distributeResult;

        if (localPolicy != null) {
            isLocalExists = true;
            isGlobalExists = true;
            if (parseInt(localPolicy[0]["nwPolicyId"]) !== intentConfig[network_qos_policy_id]) {
                throw new RuntimeException("Already there exists a policy on " + neId +
                    " with policy ID " + intentConfig[network_qos_policy_id]);
            }
            networkQosPayload = this.createNetworkQosPayLoad(neId, intentConfig, isLocalExists, localPolicy);
            result = this.modifyRequest(neId, networkQosPayload);
            if (!util.isObjectExists(network_qos_class_name, localPolicyFullName)) {
                throw new RuntimeException('Unable to Create/Distribute Policy: ' + intentConfig[network_qos_policy_id] +
                    ", Kindly check the intent configuration");
            }
        }
        else {
            logger.info(LOG_PREFIX + "Unable to find the local policy, Trying to fetch global policy if available");
            var globalPolicy = util.getIfObjectExists(network_qos_class_name, objectFullName);
            if (globalPolicy != null) {
                isGlobalExists = true;
                if (parseInt(globalPolicy[0]["nwPolicyId"]) !== intentConfig[network_qos_policy_id]) {
                    logger.info(LOG_PREFIX + "createOrModify(): There exists a Network QoS global policy in NFMP with policy ID " +
                        intentConfig[network_qos_policy_id] + " on " + neId);
                    logger.info(LOG_PREFIX + "createOrModify(): Updating Network QoS global policy ID to " +
                        intentConfig[network_qos_policy_id] + " on " + neId);
                    this.updateNetworkQosPolicyName(neId, objectFullName, intentConfig[network_qos_policy_id]);
                }

                distributePayload = util.distribute(neId, objectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(neId, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                logger.info(LOG_PREFIX + "***** checking distribution of existing global policy *******");
                if (!util.isObjectExists(network_qos_class_name, localPolicyFullName)) {
                    throw new RuntimeException("Unable to Distribute existing Global Policy: " + intentConfig[network_qos_policy_id] +
                        ", Kindly check the Global Policy configuration");
                }
                logger.info(LOG_PREFIX + "****** Distribution of existing global policy was successful, updating with intent configuration ******");
                networkQosPayload = this.createNetworkQosPayLoad(neId, intentConfig, true, globalPolicy);
                result = this.modifyRequest(neId, networkQosPayload);
                if (!util.isObjectExists(network_qos_class_name, localPolicyFullName)) {
                    throw new RuntimeException('Unable to Create/Distribute Policy: ' + intentConfig[network_qos_policy_id] +
                        ", Kindly check the intent configuration");
                }
            }
            else {
                //distributing empty policy
                logger.info(LOG_PREFIX + "***** Unable to find the Global Policy, distributing empty policy and updating *****");
                networkQosPayload = this.createNetworkQosPayLoad(neId, intentConfig, false, null);
                result = this.modifyRequest(neId, networkQosPayload);
                distributePayload = util.distribute(neId, objectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(neId, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                //updating the local policy with intent configuration
                networkQosPayload = this.createNetworkQosPayLoad(neId, intentConfig, true, null);
                result = this.modifyRequest(neId, networkQosPayload);
            }
        }
        return result;
    }

    this.updateNetworkQosPolicyName = function (neId, objectFullName, policyId) {
        var payload = {};
        var configInfo = {};
        var properties = {};
        properties["nwPolicyId"] = policyId;

        configInfo[network_qos_class_name] = properties;
        payload["distinguishedName"] = network_qos_fdn;
        payload["objectFullName"] = objectFullName;
        payload["clearOnDeployFailure"] = true;
        payload["configInfo"] = configInfo;
        logger.info(LOG_PREFIX + "Payload for updating Global Policy ID : " + JSON.stringify(payload));
        return this.modifyRequest(neId, payload);
    }

    this.createNetworkQosPayLoad = function(neId, intentConfig, isLocalExists, policyObject) {
        if (savedTopology == null)
        {
            logger.info(LOG_PREFIX + "Creating topology to save mode");
            savedTopology = topologyFactory.createServiceTopology();
        }
        var objectFullName = network_qos_fdn + ":" + intentConfig[network_qos_nw_mgr_id];
        var localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        if (isLocalExists || isAudit) {
            objectFullName = localPolicyFullName;
        }
        var properties = {};
        var childProperties = {};
        properties["id"] = intentConfig[network_qos_nw_mgr_id];
        properties["nwPolicyId"] = intentConfig[network_qos_policy_id];
        if ("type" in intentConfig) {
            if (intentConfig["type"] === "port") {
                properties["nwPolicyType"] = "Type_port";
            }
            if (intentConfig["type"] === "ip-interface") {
                properties["nwPolicyType"] = "Type_interface";
            }
        }

        if (isLocalExists) {
            for (var attribute in intentConfig) {
                switch (attribute) {
                    case "description":
                        properties["description"] = intentConfig[attribute];
                        break;
                    case "scope":
                        properties["scope"] = intentConfig[attribute];
                        break;
                    case "ingress":
                        this.createIngressPayload(intentConfig[attribute], properties, childProperties, neId);
                        break;
                    case "egress":
                        this.createEgressPayload(intentConfig[attribute], properties, childProperties, neId);
                        break;
                }
            }
        }
        return util.editPayload(network_qos_fdn, properties, childProperties, network_qos_class_name, objectFullName);
    }
    
    this.createIngressPayload = function (ingressConfig, properties, childProperties, neId) {

        if ("default-action" in ingressConfig) {
            var defAction = ingressConfig["default-action"];
            if (defAction["fc"]) {
                properties["defaultFc"] = defAction["fc"];
            }
            if (defAction["profile"]) {
                if (defAction["profile"] === "use-dei") {
                    properties["defaultProfile"] = "dei";
                }
                else {
                    properties["defaultProfile"] = defAction["profile"];
                }
            }
        }

        if ("mpls-lsp-exp-profile-map" in ingressConfig) {
            properties["mplsLspExpMapPointer"] = "sasMplsLspExpMap:" + ingressConfig["mpls-lsp-exp-profile-map"];
        }
        else {
            properties["mplsLspExpMapPointer"] = "sasMplsLspExpMap:1";
        }

        //CLASSIFICATION-TYPE
        properties["dscpClassificationPointer"] = "";
        properties["dot1pClassificationPointer"] = "";
        properties["mplsLspExpClassificationPointer"] = "";
        if ("classification-type" in ingressConfig) {
            var classificationObj = ingressConfig["classification-type"];
            if (classificationObj["dscp-classification"]) {
                properties["dscpClassificationPointer"] = "sasDSCPClassification:Dscp-" + classificationObj["dscp-classification"];
            }
            if (classificationObj["dot1p-classification"]) {
                properties["dot1pClassificationPointer"] = "sasDot1pClassification:Dot1p-" + classificationObj["dot1p-classification"];
            }
            if (classificationObj["mpls-lsp-exp-classification"]) {
                properties["mplsLspExpClassificationPointer"] = "sasMplsLspExpClassification:lspexp-" + classificationObj["mpls-lsp-exp-classification"];
            }
        }
        //DSCP
        if ("dscp" in ingressConfig) {
            this.setDscpConfig(ingressConfig, childProperties);
        }
        else {
            childProperties["sasqos.NetworkIngressDscp"] = [];
        }
        //LSP-EXP
        if ("lsp-exp" in ingressConfig) {
            this.setLspExpConfig(ingressConfig, childProperties);
        }
        else {
            childProperties["sasqos.NetworkIngressLspExp"] = [];
        }
        //DOT1P
        if ("dot1p" in ingressConfig) {
            this.setDot1pConfig(ingressConfig, childProperties);
        }
        else {
            childProperties["sasqos.NetworkIngressDot1p"] = [];
        }
        //FC
        if ("fc" in ingressConfig) {
            this.setFcConfig(ingressConfig, childProperties);
        }
        else {
            childProperties["sasqos.NetworkIngressForwardingClass"] = [];
        }
        //QUEUE
        if ("queue" in ingressConfig) {
            this.setQueueConfig(ingressConfig, childProperties);
            if (isAudit) {
                this.getAttributeAuditConfig(neId, "sasqos.NetworkIngressQueue", properties, childProperties, "id");
            }
        }
        else {
            childProperties["sasqos.NetworkIngressQueue"] = [];
        }
        //METER
        if ("meter" in ingressConfig) {
            this.setMeterConfig(ingressConfig, childProperties);
        }
        else {
            childProperties["sasqos.NetworkIngressMeter"] = [];
        }
    }

    this.getAttributeAuditConfig = function (neId, className, properties, childProperties, data) {
        var searchObj = this.constructSearchString(neId, className, properties["nwPolicyId"]);
        var resultFetch = nfmpFwk.find(neId, searchObj);
        var defaultConfig = JSON.parse(resultFetch.response)[className];
        if (defaultConfig !== undefined) {
            if (!Array.isArray(defaultConfig)) {
                defaultConfig = [defaultConfig];
            }
            var intentConfig = childProperties[className];
            var auditConfig = [];
            for (var defIdx in defaultConfig) {
                var flag = 0;
                var defData = defaultConfig[defIdx][data];
                for (var intentIdx in intentConfig) {
                    if (intentConfig[intentIdx][data] == defData) {
                        flag = 1;
                        auditConfig.push(intentConfig[intentIdx]);
                    }
                }
                if (flag === 0) {
                    auditConfig.push(defaultConfig[defIdx]);
                }
            }
            logger.info(LOG_PREFIX + "*********** AUDIT DATA FOR " + className + "*************");
            childProperties[className] = auditConfig;
            logger.info(LOG_PREFIX + JSON.stringify(auditConfig));
        }
    }

    this.createEgressPayload = function (egressConfig, properties, childProperties, neId) {
        if ("remarking" in egressConfig) {
            properties["egressRemark"] = egressConfig["remarking"].toString();
        }
        if ("remark" in egressConfig) {
            properties["remarkPolicyPointer"] = "sasRemarkingPolicy:" + egressConfig["remark"];
        }
        if ("remarking-type" in egressConfig) {
            switch (egressConfig["remarking-type"]) {
                case "use-dot1p":
                    properties["egressRemarkType"] = "use_dot1p";
                    break;
                case "use-dscp":
                    properties["egressRemarkType"] = "use_dscp";
                    break;
                default:
                    properties["egressRemarkType"] = "all";
            }
        }
        if ("fc" in egressConfig) {
            this.setEgressFcConfig(egressConfig, childProperties);
            if (isAudit) {
                var egressFcClassName = "sasqos.NetworkEgressForwardingClass";
                var egressFcSearchObj = this.constructSearchString(neId, egressFcClassName, properties["nwPolicyId"]);
                var resultFetch = nfmpFwk.find(neId, egressFcSearchObj);
                var defaultFcConfig = JSON.parse(resultFetch.response)[egressFcClassName];
                if (defaultFcConfig !== undefined) {
                    var intentFcConfig = childProperties[egressFcClassName];
                    var auditFcConfig = [];
                    for (var defIdx in defaultFcConfig) {
                        var flag = 0;
                        var defFc = defaultFcConfig[defIdx]["forwardingClass"];
                        for (var fcIdx in intentFcConfig) {
                            if (intentFcConfig[fcIdx]["forwardingClass"] === defFc) {
                                flag = 1;
                                auditFcConfig.push(intentFcConfig[fcIdx]);
                            }
                        }
                        if (flag === 0) {
                            auditFcConfig.push(defaultFcConfig[defIdx]);
                        }
                    }
                    logger.info(LOG_PREFIX + "*********** EGRESS FC DATA for Audit *************");
                    childProperties[egressFcClassName] = auditFcConfig;
                    logger.info(LOG_PREFIX + JSON.stringify(auditFcConfig));
                }
            }
        }
        else {
            childProperties["sasqos.NetworkEgressForwardingClass"] = [];
        }
    }

    this.constructSearchString = function(neId, className, policyId) {
        var searchObj = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "containingPolicyId",
                            "value": policyId
                        }
                    ]
                }
            }
        };
        return searchObj;
    }

    this.setDscpConfig = function (ingressConfig, childProperties) {
        var ingressDscpArray = []
        var dscpClassName = "sasqos.NetworkIngressDscp";
        if (!Array.isArray(ingressConfig["dscp"])) {
            ingressConfig["dscp"] = [ingressConfig["dscp"]];
        }
        for (var index in ingressConfig["dscp"]) {
            var ingressDscpConfig = ingressConfig["dscp"][index];
            var ingressDscpPayLoad = this.createIngressDscpPayLoad(ingressDscpConfig);
            ingressDscpArray.push(ingressDscpPayLoad);
        }
        childProperties[dscpClassName] = ingressDscpArray;
    }

    this.setLspExpConfig = function (ingressConfig, childProperties) {
        var ingressLspExpArray = [];
        var lspExpClassName = "sasqos.NetworkIngressLspExp";
        if (!Array.isArray(ingressConfig["lsp-exp"])) {
            ingressConfig["lsp-exp"] = [ingressConfig["lsp-exp"]];
        }
        for (var lspExpIdx in ingressConfig["lsp-exp"]) {
            var ingressLspExpConfig = ingressConfig["lsp-exp"][lspExpIdx];
            var ingressLspExpPayload = this.createIngressLspExpPayLoad(ingressLspExpConfig);
            ingressLspExpArray.push(ingressLspExpPayload);
        }
        childProperties[lspExpClassName] = ingressLspExpArray;
    }

    this.setDot1pConfig = function (ingressConfig, childProperties) {
        var ingressDot1pArray = [];
        var dot1pClassName = "sasqos.NetworkIngressDot1p";
        if (!Array.isArray(ingressConfig["dot1p"])) {
            ingressConfig["dot1p"] = [ingressConfig["dot1p"]];
        }
        for (var dot1pIdx in ingressConfig["dot1p"]) {
            var ingressDot1pConfig = ingressConfig["dot1p"][dot1pIdx];
            var ingressDot1pPayload = this.createIngressDot1pPayLoad(ingressDot1pConfig);
            ingressDot1pArray.push(ingressDot1pPayload);
        }
        childProperties[dot1pClassName] = ingressDot1pArray;
    }

    this.setFcConfig = function (ingressConfig, childProperties) {
        var ingressFcArray = [];
        var fcClassName = "sasqos.NetworkIngressForwardingClass";
        if (!Array.isArray(ingressConfig["fc"])) {
            ingressConfig["fc"] = [ingressConfig["fc"]];
        }
        for (var fcIdx in ingressConfig["fc"]) {
            var ingressFcConfig = ingressConfig["fc"][fcIdx];
            var ingressFcPayload = this.createIngressFcPayLoad(ingressFcConfig, ingressConfig);
            ingressFcArray.push(ingressFcPayload);
        }
        childProperties[fcClassName] = ingressFcArray;
    }

    this.setQueueConfig = function (ingressConfig, childProperties) {
        var queuePayloadArray = [];
        var queueClassName = "sasqos.NetworkIngressQueue";
        if (!Array.isArray(ingressConfig["queue"])) {
            ingressConfig["queue"] = [ingressConfig["queue"]];
        }
        for (var idx in ingressConfig["queue"]) {
            var queueConfig = ingressConfig["queue"][idx];
            var queuePayload = this.createQueuePayload(queueConfig);
            queuePayloadArray.push(queuePayload);
        }
        childProperties[queueClassName] = queuePayloadArray;
    }

    this.setMeterConfig = function (ingressConfig, childProperties) {
        var meterPayloadArray = [];
        var meterClassName = "sasqos.NetworkIngressMeter";
        if (!Array.isArray(ingressConfig["meter"])) {
            ingressConfig["meter"] = [ingressConfig["meter"]];
        }
        for (var idx in ingressConfig["meter"]) {
            var meterConfig = ingressConfig["meter"][idx];
            var meterPayload = this.createMeterPayload(meterConfig);
            meterPayloadArray.push(meterPayload);
        }
        childProperties[meterClassName] = meterPayloadArray;
    }

    this.setEgressFcConfig = function (egressConfig, childProperties) {
        var egressFcPayloadArray = [];
        var egressFcClassName = "sasqos.NetworkEgressForwardingClass";
        if (!Array.isArray(egressConfig["fc"])) {
            egressConfig["fc"] = [egressConfig["fc"]];
        }
        for (var idx in egressConfig["fc"]) {
            var egressFcConfig = egressConfig["fc"][idx];
            var egressFcPayload = this.createEgressFcPayload(egressFcConfig);
            egressFcPayloadArray.push(egressFcPayload);
        }
        childProperties[egressFcClassName] = egressFcPayloadArray;
    }

    this.createIngressDscpPayLoad = function (ingressDscpConfig) {
        var properties = {};
        for (var dscpData in ingressDscpConfig) {
            switch (dscpData) {
                case "dscp-name":
                    properties["dscp"] = ingressDscpConfig[dscpData];
                    break;
                case "fc":
                    properties["forwardingClass"] = ingressDscpConfig[dscpData];
                    break;
                case "profile":
                    properties["profile"] = ingressDscpConfig[dscpData];
                    break;
            }
        }
        return properties;
    }

    this.createIngressLspExpPayLoad = function (ingressLspExpConfig) {
        var properties = {};
        for (var lspExpData in ingressLspExpConfig) {
            switch (lspExpData) {
                case "lsp-exp-value":
                    properties["lspExp"] = "lspExp_" + ingressLspExpConfig[lspExpData];
                    break;
                case "fc":
                    properties["forwardingClass"] = ingressLspExpConfig[lspExpData];
                    break;
                case "profile":
                    properties["profile"] = ingressLspExpConfig[lspExpData];
                    break;
            }
        }
        return properties;
    }

    this.createIngressDot1pPayLoad = function (ingressDot1pConfig) {
        var properties = {};
        for (var dot1pData in ingressDot1pConfig) {
            switch (dot1pData) {
                case "dot1p-value":
                    properties["dot1p"] = "value_" + ingressDot1pConfig[dot1pData];
                    break;
                case "fc":
                    properties["forwardingClass"] = ingressDot1pConfig[dot1pData];
                    break;
                case "profile":
                    if (ingressDot1pConfig[dot1pData] === "use-dei") {
                        properties["profile"] = "dei";
                    }
                    else {
                        properties["profile"] = ingressDot1pConfig[dot1pData];
                    }
                    break;
            }
        }
        return properties;
    }

    this.createIngressFcPayLoad = function (ingressFcConfig, ingressConfig) {
        var properties = {};
        properties["forwardingClass"] = ingressFcConfig["fc-name"];
        for (var fcData in ingressFcConfig) {
            switch (fcData) {
                case "multicast-meter":
                    if ("meter" in ingressConfig) {
                        if (!Array.isArray(ingressConfig["meter"])) {
                            ingressConfig["meter"] = [ingressConfig["meter"]];
                        }
                        for (var idx in ingressConfig["meter"]) {
                            var multiCastMeterConfig = ingressConfig["meter"][idx];
                            if (ingressFcConfig["multicast-meter"] == multiCastMeterConfig["meter-id"]) {
                                properties["mCastMeter"] = ingressFcConfig["multicast-meter"];
                            }
                        }
                        if (properties["mCastMeter"] != ingressFcConfig["multicast-meter"]) {
                            throw new RuntimeException("The specified MultiCast Meter id: " + ingressFcConfig["multicast-meter"] + " does not exist!, which is configured for FC: " + properties["forwardingClass"]);
                        }
                    }
                    else {
                        throw new RuntimeException("The specified MultiCast Meter id: " + ingressFcConfig["multicast-meter"] + " does not exist!, which is configured for FC: " + properties["forwardingClass"]);
                    }
                    break;
                case "use-dei":
                    properties["useDei"] = ingressFcConfig[fcData].toString();
                    break;
                case "meter":
                    if ("meter" in ingressConfig) {
                        if (!Array.isArray(ingressConfig["meter"])) {
                            ingressConfig["meter"] = [ingressConfig["meter"]];
                        }
                        for (var mIdx in ingressConfig["meter"]) {
                            var meterConfig = ingressConfig["meter"][mIdx];
                            if (ingressFcConfig["meter"] == meterConfig["meter-id"]) {
                                properties["meter"] = ingressFcConfig["meter"];
                            }
                        }
                        if (properties["meter"] != ingressFcConfig["meter"]) {
                            throw new RuntimeException("The specified Meter id: " + ingressFcConfig["meter"] + " does not exist!, which is configured for FC: " + properties["forwardingClass"]);
                        }
                    }
                    else {
                        throw new RuntimeException("The specified Meter id: " + ingressFcConfig["meter"] + " does not exist!, which is configured for FC: " + properties["forwardingClass"]);
                    }
                    break;
                case "multicast-queue":
                    if ("queue" in ingressConfig) {
                        if (!Array.isArray(ingressConfig["queue"])) {
                            ingressConfig["queue"] = [ingressConfig["queue"]];
                        }
                        for (var mqIdx in ingressConfig["queue"]) {
                            var mCastQConfig = ingressConfig["queue"][mqIdx];
                            if (ingressFcConfig["multicast-queue"] == mCastQConfig["queue-id"]) {
                                properties["multicastQueueId"] = ingressFcConfig["multicast-queue"];
                            }
                        }
                        if (properties["multicastQueueId"] != ingressFcConfig["multicast-queue"]) {
                            throw new RuntimeException("The specified Multicast Queue id: " + ingressFcConfig["multicast-queue"] + " does not exist!, which is configured for FC: " + properties["forwardingClass"]);
                        }
                    }
                    else {
                        throw new RuntimeException("Queue entries are not configured hence, The specified Multicast Queue id: " + ingressFcConfig["multicast-queue"] + " does not exist!, which is configured for FC: " + properties["forwardingClass"]);
                    }
                    break;
                case "queue":
                    if ("queue" in ingressConfig) {
                        if (!Array.isArray(ingressConfig["queue"])) {
                            ingressConfig["queue"] = [ingressConfig["queue"]];
                        }
                        for (var index in ingressConfig["queue"]) {
                            var intentQueueConfig = ingressConfig["queue"][index];
                            if (ingressFcConfig["queue"] == intentQueueConfig["queue-id"]) {
                                properties["queueId"] = ingressFcConfig["queue"];
                            }
                        }
                        if (properties["queueId"] != ingressFcConfig["queue"]) {
                            throw new RuntimeException("The specified Queue id: " + ingressFcConfig["queue"] + " does not exist!, which is configured for FC: " + properties["forwardingClass"]);
                        }
                    }
                    else {
                        throw new RuntimeException("Queue entries are not configured hence, The specified Queue id: " + ingressFcConfig["queue"] + " does not exist!, which is configured for FC: " + properties["forwardingClass"]);
                    }
                    break;
            }
        }
        return properties;
    }

    this.createQueuePayload = function (queueConfig) {
        var properties = {};
        if ("slope-policy" in queueConfig) {
            properties["slopePolicyPointer"] = "sasSlope:" + queueConfig["slope-policy"];
        }
        else {
            properties["slopePolicyPointer"] = "sasSlope:default";
        }
        for (var queueData in queueConfig) {
            switch (queueData) {
                case "queue-id":
                    properties["id"] = queueConfig[queueData];
                    break;
                case "cbs":
                    properties["committedBurstSize"] = queueConfig[queueData];
                    break;
                case "mbs":
                    properties["maximumBurstSize"] = queueConfig[queueData];
                    break;
                case "weight":
                    properties["weight"] = queueConfig[queueData];
                    break;
                case "priority":
                    properties["priority"] = queueConfig[queueData];
                    break;
                case "rate":
                    var rateObj = queueConfig[queueData];
                    if (rateObj["pir"]) {
                        properties["pir"] = rateObj["pir"];
                    }
                    if (rateObj["cir"]) {
                        properties["cir"] = rateObj["cir"];
                    }
                    break;
                case "adaptation-rule":
                    var adaptationObj = queueConfig[queueData];
                    if (adaptationObj["pir"]) {
                        properties["pirAdaptation"] = adaptationObj["pir"];
                    }
                    if (adaptationObj["cir"]) {
                        properties["cirAdaptation"] = adaptationObj["cir"];
                    }
                    break;
            }
        }
        return properties;
    }
    
    this.createMeterPayload = function (meterConfig) {
        var properties = {};
        for (var meterData in meterConfig) {
            switch (meterData) {
                case "meter-id":
                    properties["id"] = meterConfig[meterData];
                    break;
                case "multipoint":
                    properties["mCast"] = meterConfig[meterData].toString();
                    break;
                case "mode":
                    if (meterConfig[meterData] === "trtcml") {
                        properties["mode"] = "trtcm1";
                    }
                    else {
                        properties["mode"] = meterConfig[meterData];
                    }
                    break;
                case "cbs-type":
                    properties["cbsType"] = meterConfig[meterData];
                    if (meterConfig[meterData] === "kbits") {
                        if ("cbs" in meterConfig) {
                            if (meterConfig["cbs"] === "default") {
                                properties["cbs"] = "-1";
                            }
                            else {
                                properties["cbs"] = meterConfig["cbs"];
                            }
                        }
                    }
                    if (meterConfig[meterData] === "kbytes") {
                        if ("cbs" in meterConfig) {
                            if (meterConfig["cbs"] === "default") {
                                properties["cbsKiloBytes"] = "-1";
                            }
                            else {
                                properties["cbsKiloBytes"] = meterConfig["cbs"];
                            }
                        }
                    }
                    if (meterConfig[meterData] === "bytes") {
                        if ("cbs" in meterConfig) {
                            if (meterConfig["cbs"] === "default") {
                                properties["cbsBytes"] = "-1";
                            }
                            else {
                                properties["cbsBytes"] = meterConfig["cbs"];
                            }
                        }
                    }
                    break;
                case "mbs-type":
                    properties["mbsType"] = meterConfig[meterData];
                    if (meterConfig[meterData] === "kbits") {
                        if ("mbs" in meterConfig) {
                            if (meterConfig["mbs"] === "default") {
                                properties["mbs"] = "-1";
                            }
                            else {
                                properties["mbs"] = meterConfig["mbs"];
                            }
                        }
                    }
                    if (meterConfig[meterData] === "kbytes") {
                        if ("mbs" in meterConfig) {
                            if (meterConfig["mbs"] === "default") {
                                properties["mbsKiloBytes"] = "-1";
                            }
                            else {
                                properties["mbsKiloBytes"] = meterConfig["mbs"];
                            }
                        }
                    }
                    if (meterConfig[meterData] === "bytes") {
                        if ("mbs" in meterConfig) {
                            if (meterConfig["mbs"] === "default") {
                                properties["mbsBytes"] = "-1";
                            }
                            else {
                                properties["mbsBytes"] = meterConfig["mbs"];
                            }
                        }
                    }
                    break;
                case "rate":
                    var rateObj = meterConfig[meterData];
                    if ("pir" in rateObj) {
                        if (rateObj["pir"] === "max") {
                            properties["pir"] = "-1";
                        }
                        else {
                            properties["pir"] = rateObj["pir"];
                        }
                    }
                    if ("cir" in rateObj) {
                        if (rateObj["cir"] === "max") {
                            properties["cir"] = "-1";
                        }
                        else {
                            properties["cir"] = rateObj["cir"];
                        }
                    }
                    break;
                case "adaptation-rule":
                    var adaptationObj = meterConfig[meterData];
                    if (adaptationObj["pir"]) {
                        properties["pirAdaptation"] = adaptationObj["pir"];
                    }
                    if (adaptationObj["cir"]) {
                        properties["cirAdaptation"] = adaptationObj["cir"];
                    }
                    break;
            }
        }
        return properties;
    }

    this.createEgressFcPayload = function (egressFcConfig) {
        var properties = {};
        properties["forwardingClass"] = egressFcConfig["fc-name"]
        properties["deMark"] = false;
        properties["forceDeValue"] = "default";
        for (var fcData in egressFcConfig) {
            switch (fcData) {
                case "dot1p-in-profile":
                    properties["dot1pInProfile"] = "priority_" + egressFcConfig[fcData];
                    break;
                case "dot1p-out-profile":
                    properties["dot1pOutProfile"] = "priority_" + egressFcConfig[fcData];
                    break;
                case "dscp-in-profile":
                    properties["dscpInProfile"] = egressFcConfig[fcData];
                    break;
                case "dscp-out-profile":
                    properties["dscpOutProfile"] = egressFcConfig[fcData];
                    break;
                case "lsp-exp-in-profile":
                    properties["lspExpInProfile"] = "lspExp_" + egressFcConfig[fcData];
                    break;
                case "lsp-exp-out-profile":
                    properties["lspExpOutProfile"] = "lspExp_" + egressFcConfig[fcData];
                    break;
                case "de-mark":
                    properties["deMark"] = true;
                    properties["forceDeValue"] = egressFcConfig[fcData]["force"]
                    break;
                case "dot1p":
                    properties["dot1pProfile"] = "priority_" + egressFcConfig[fcData];
                    break;
            }
        }
        return properties;
    }

    this.audit = function (input, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        isAudit = true;
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        intentConfig = this.removeEmptyContainers("", intentConfig, "", neId);
        logger.info(LOG_PREFIX + "intentConfig = {} ", JSON.stringify(intentConfig));
        intentConfig[network_qos_policy_id] = util.getNetworkQosPolicyId(input.getTarget());
        intentConfig[network_qos_nw_mgr_id] = util.getNetworkQosManagerId(input.getTarget());
        logger.info(LOG_PREFIX + "auditing configuration = " + JSON.stringify(intentConfig));
        logger.info(LOG_PREFIX + "Target device = " + neId);
        logger.info(LOG_PREFIX + "Target Network QoS Policy ID = " + intentConfig[network_qos_policy_id]);
        if (intentConfig) {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else {
            throw "configuration not available in the intent";
        }
        return auditReport
    }

    this.auditAndCompare = function(neId, intentConfig, auditReport) {
        var networkQosPayload = this.createNetworkQosPayLoad(neId, intentConfig, true, null);
        var result = this.auditRequest(neId, networkQosPayload);
        auditReport = util.reportMisaligned(neId, result, auditReport);
        return auditReport;
    }

    this.auditRequest = function(neId, payload) {
        logger.info(LOG_PREFIX + "Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.modifyRequest = function(neId, payload) {
        logger.info(LOG_PREFIX + "Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success) {
           logger.error("Error result = {}",JSON.stringify(result));
           let errorMsg = result.msg;
           if(errorMsg.indexOf("object already exists") !== -1)
           {
               logger.info("Global policy Object already exists, Re-checking the Policy existence ");
               //util.delay(2000);
               let configInfo = payload.configInfo;
               let fullClassName;
               for (let key in configInfo) {
                 if (configInfo.hasOwnProperty(key)) {
                   fullClassName = key;
                   break;
                 }
               }
               let objectFullName = payload.objectFullName;
               objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
               logger.info("fullClassName = {}",fullClassName);
               logger.info("objectFullName = {}",objectFullName);
               if (!util.isObjectExists(fullClassName, objectFullName))
               {
                   throw new RuntimeException("Global Policy Object Not Found!!!");
               }
           }
           else
           {
               throw new RuntimeException(result.msg);
           }
        }
        return result;
    }

    this.removeEmptyContainers= function(prop, intentJson, path, target){
        if(Array.isArray(intentJson)) {
            var object = [];
            for(var prop in intentJson) {
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value) {
                    object.push(value);
                }
            }
            if(Object.keys(object).length !== 0) {
                return object;
            }
        }
        else if( typeof intentJson == 'object' ) {
            var object = {};
            for(var prop in intentJson) {
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ) {
                    object[prop] = value;
                }
            }
            if(Object.keys(object).length !== 0) {
                return object;
            }
        }
        else {
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if(intentJson!==undefined && intentJson!=="") {
                return intentJson;
            }
            return null;
        }
    }

    this.xml2object = function(xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info(LOG_PREFIX + "(xml2object) Input json: " + json)
        return JSON.parse(json);
    }
}