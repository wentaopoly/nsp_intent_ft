function ModelDeviceMapping() {
    this.getAdminTagMapping = function () {
        var mapping = {};
        mapping['admin-tags.admin-tag.tag'] = 'tagName';
        return mapping;
    }

    this.getAdminTagPolicyMapping = function () {
        var mapping = {};
        mapping['admin-tags.route-admin-tag-policy.policy-name'] = 'policyName';
        mapping['admin-tags.route-admin-tag-policy.tag'] = 'tagName';
        return mapping;
    }

}
