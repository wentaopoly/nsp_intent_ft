load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
function CustomHooks() {
  /**
   * PreAudit Hook
   */
  const preAudit = (inputObj) => {
    /**
     * Write your custom preAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName
     *
     */

    let target = inputObj.target;
    let intentConfig = inputObj.intentConfig;
    logger.info("[CUSTOM-HOOKS] preAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
    logger.info("preAudit call for ospf interface intent config deviation");
    let intentDeviationObj = new IntentDeviceDeviation();
    let neId = parseTarget.getNeIdFromTarget(target);
    intentConfig = intentDeviationObj.removeIntentConfig(JSON.stringify(intentConfig), neId);
    logger.info("preAudit intent config after removing deviation attributes: " + JSON.stringify(intentConfig));
    inputObj.intentConfig = intentConfig;
    return inputObj;
  };

  /**
   * PostAudit Hook
   */
  const postAudit = (inputObj) => {
    /**
     * Write your custom postAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName, auditReport
     *
     */

    logger.info("[CUSTOM-HOOKS] postAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));


  };

  /**
   * PreSync Hook
   */
  const preSync = (inputObj) => {
    /**
     * Write your custom preSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] preSync call");
    let config = JSON.parse(inputObj["config"]);
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

    let target = inputObj["target"];
    let intentTypeName = inputObj["intentTypeName"];
    let intentContainer = inputObj["intentContainer"];
    let intentDeviationObj = new IntentDeviceDeviation();
    let neId = parseTarget.getNeIdFromTarget(target);
    if (!Array.isArray(config)) {
        config = [config];
    }
    var preSyncConf = [];
    for (let index in config) {
        var interfaceConfig= config[index][intentTypeName + ":" + intentTypeName][intentContainer];
        if (Object.keys(interfaceConfig["node-sid"]).length === 0 && interfaceConfig["node-sid"].constructor === Object) {
            delete interfaceConfig["node-sid"];
        }

        // Check and remove "adjacency-sid" if it is an empty object
        if (Object.keys(interfaceConfig["adjacency-sid"]).length === 0 && interfaceConfig["adjacency-sid"].constructor === Object) {
            delete interfaceConfig["adjacency-sid"];
        }
        let configObj = interfaceConfig;
        let deviatedObj = intentDeviationObj.removeIntentConfig(JSON.stringify(configObj), neId);
        let finalConfigObj = {};
        let intentKey = intentTypeName + ":" + intentTypeName
        finalConfigObj[intentKey] = {};
        finalConfigObj[intentKey][intentContainer] = deviatedObj;
        preSyncConf.push(finalConfigObj);

    }
    inputObj.config = JSON.stringify(preSyncConf)
    logger.info("intent config after removing deviation attributes: " + JSON.stringify(preSyncConf));
    return JSON.stringify(preSyncConf);
  };

  /**
   * PostSync Hook
   */
  const postSync = (inputObj) => {
    /**
     * Write your custom postSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] postSync call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

  };

  /**
   *
   * PostDiscovery Hook
   */
  const postDiscovery = (inputObj) => {
    /**
     * Write your custom postDiscovery logic here
     * inputObj by default contains the following keys:
     *        deviceConfig, intentContainer, neId,
     *        targetDataStruct, templateName, deviceYangModuleName
     */

    logger.info("[CUSTOM-HOOKS] postDiscovery call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

  }

  this.preAudit = preAudit;
  this.postAudit = postAudit;
  this.preSync = preSync;
  this.postSync = postSync;
  this.postDiscovery = postDiscovery;

}