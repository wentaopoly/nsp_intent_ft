var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
  "ibn" : "http://www.nokia.com/management-solutions/ibn",
  "nc" : "urn:ietf:params:xml:ns:netconf:base:1.0",
  "device-manager" : "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
  "http://www.nokia.com/management-solutions/anv-device-holders" : "anv-device-holders"
};

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();


load({script:resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource('nsp-restconf-fwk.js'), name: 'nsp-restconf-fwk'});
var nspRestconfFwk = new NspRestconfFwk();


var intentTypeName = 'icm-service-system_evpn';

// example port, sap-ingress etc..
var initialPropertyName = 'ethernet-segment';


// unique identifier
var uniqueIdentifier = 'ethernet-segment-name';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/service/system/bgp/evpn';

function synchronize(input)
{
    logger.info('Intent Synchronisation started')
    var esi = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName]['esi'];
    if(esi)
    {
        esi = esi.replaceAll(" ", ":");
        esi = esi.replaceAll("-", ":");

        var isValidESI = this.validateESI(esi)
        if(!isValidESI)
        {
            throw new RuntimeException("Invalid ESI value: "+ esi
                +". It's a 10 byte hexadecimal value similar to xx:xx:xx:xx:xx:xx:xx:xx:xx:xx where x = [0..F] Hex separated by either ' ' or ':' or '-'. And the bytes 2-7 cannot be all '0'")
        }
    }
    return NspIntentHelper.synchronize(input,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier);
}

this.validateESI = function (esi)
{
    var ESI_INVALID_VALUE_WITH_SEP = "00:00:00:00:00:00";
    if(/^([a-fA-F\d]{2}:)([a-fA-F\d]{2}:){8}[a-fA-F\d]{2}$/.test(esi))
    {
        if(esi.indexOf(ESI_INVALID_VALUE_WITH_SEP) == 3)
        {
            return false;
        }
        logger.info("Valid ESI Value: "+esi);
        return true;
    }
    else
    {
        return false;
    }
}

this.xml2object = function (xmlElement)
{
    var lXml = Java.type("org.json.XML");
    var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
    var serializer = lsImpl.createLSSerializer();
    serializer.getDomConfig().setParameter("xml-declaration", false);
    var str = serializer.writeToString(xmlElement);
    var json = lXml.toJSONObject(str).toString();
    logger.info('inp json: ' + json)
    return JSON.parse(json);
}

function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started')
  
  return NspIntentHelper.audit(target, config, svcTopo, adminState,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier);
}
function suggestPortIds(context) {
  try
  {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    if (target)
    {
      neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
    }
    else
    {
        neId = context.getInputValues()["arguments"]["__parent"]["target_objectidentifier"];
        if(neId.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = neId.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
    }
    logger.info("listing ports for NeId : " + neId);

    ret = nspRestconfFwk.getPorts(neId);
  } catch (e)
  {
    logger.error(" " + e.message);
  }
  return ret;
}

function suggestLagIds(context) {
  try
  {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    if (target)
    {
      neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
    }
    else
    {
      neId = context.getInputValues()["arguments"]["__parent"]["target_objectidentifier"];
      if(neId.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
      {
          neId = neId.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
      }
    }
    logger.info("listing LAGS for NeId : " + neId);

    ret = nspRestconfFwk.getLagNames(neId);
  } catch (e)
  {
    logger.error(" " + e.message);
  }
  return ret;
}

function getTargetData(input) {
  logger.info("getTargetData input for brownfield = \n" + input);
  var target = input.target;
  var config = null;
  logger.info("target=" + target);
  var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
  logger.info(JSON.stringify(deviceConfig));
  var data = gtdFwk.gtdSend(deviceConfig);
  return data.msg.result;
}

