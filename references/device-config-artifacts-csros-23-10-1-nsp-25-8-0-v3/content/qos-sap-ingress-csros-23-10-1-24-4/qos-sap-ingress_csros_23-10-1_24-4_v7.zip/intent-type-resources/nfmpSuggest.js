function NfmpSuggest() {

    this.getIpPrefixListName = function () {
        var className = "qosprefixlist.PrefixList";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "prefixListType",
                            "value": "ipv4"
                        },
                        {
                            "name": "isLocal",
                            "value": "false"
                        },
                        {
                            "name": "isBackup",
                            "value": "false"
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className,"displayedName");
        return ret
    }

    this.getIpv6PrefixListName = function () {
        var className = "qosprefixlist.PrefixList";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "prefixListType",
                            "value": "ipv6"
                        },
                        {
                            "name": "isLocal",
                            "value": "false"
                        },
                        {
                            "name": "isBackup",
                            "value": "false"
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className,"displayedName");
        return ret
    }

    this.getParentArbiterName = function () {
        var className = "policing.PolicerControlArbiter";
        var searchObject = {
            "fullClassName": className,
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className,"displayedName");
    }

    this.getSchedulerName = function () {
        var className = "vs.Entry";
        var searchObject = {
            "fullClassName": className,
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className,"displayedName");
    }

    this.getSlopePolicyName = function () {
        var className = "slope.Policy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "isLocal",
                            "value": "false"
                        },
                        {
                            "name": "isBackup",
                            "value": "false"
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className,"displayedName");
        return ret
    }

    this.getSlopePolicerId = function () {
        var className = "slope.Policy";
        var searchObject = {
            "fullClassName": className,
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className,"displayedName");
    }

    this.getPolicyId = function (neId, policyName) {
        var className = "aingr.Policy";
        let equalFilter = [
                            {
                              "name": "siteId",
                              "value": neId
                            }
                          ];
        if(policyName)
        {
            let policyNameFilter = {
                                     "name": "policyName",
                                     "value": policyName
                                   };
            equalFilter.push(policyNameFilter);
        }
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": equalFilter
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "id");
    }

    this.getPolicyName = function (neId, policyId) {
            var className = "aingr.Policy";
            let equalFilter = [
                                {
                                  "name": "siteId",
                                  "value": neId
                                }
                              ];
            if(policyId)
            {
                let policyIdFilter = {
                                         "name": "id",
                                         "value": policyId
                                       };
                equalFilter.push(policyIdFilter);
            }
            var searchObject = {
                "fullClassName": className,
                "filter": {
                    "and": {
                        "equal": equalFilter
                    }
                },
                "resultFilter": {
                    "children": "",
                    "attribute": [
                        "policyName"
                    ]
                }

            };
            logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
            return this.getData(searchObject, className, "policyName");
        }

    this.getQueueId = function (neId) {
        var className = "aingr.Queue";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "id");
    }

    this.getPolicerId = function (neId) {
        var className = "aingr.Policer";

        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        return this.getData(searchObject, className, "id");
    }

    this.getAdvancedConfigPolicyName = function (neId) {
        var className = "vs.AdvancedConfigPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal":
                        [{
                            "name": "isLocal",
                            "value": "false"
                        },
                        {
                            "name": "isBackup",
                            "value": "false"
                        }]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", JSON.stringify(searchObject));
        var ret = this.getData(searchObject, className, "displayedName");
        return ret
    }

    this.getData = function (searchObjectJson, className, type) {
        var nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    ret.push(value[type]);
                })
            }
        }

        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

}