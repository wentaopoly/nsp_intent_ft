function CustomHooks() {
  /**
 * PreAudit Hook
 */
  const preAudit = (inputObj) => {
    /**
    * Write your custom preAudit logic here
    * inputObj by default contains the following keys:
    *          target, intentConfig, svcTopo, adminState,
    *          intentTypeName, rootXPath, intentContainer, 
    *          uniqueIdentifier, deviceYangModuleName
    *           
    */

    logger.info("[CUSTOM-HOOKS] preAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj " + JSON.stringify(inputObj));
    var target = inputObj["target"];
    inputObj["intentConfig"] = this.removeEmptyContainers("", inputObj["intentConfig"], "", target);
    logger.info("preAudit intent config after removing deviation attributes:" + JSON.stringify(inputObj));

    return inputObj;
  };

/**
 * PostAudit Hook
 */
  const postAudit = (inputObj) => {
    /**
     * Write your custom postAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer, 
     *          uniqueIdentifier, deviceYangModuleName, auditReport
     *           
     */

    logger.info("[CUSTOM-HOOKS] postAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj " + JSON.stringify(inputObj));


  };

/**
 * PreSync Hook
 */
  const preSync = (inputObj) => {
    /**
     * Write your custom preSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] preSync call");
    logger.info("[CUSTOM-HOOKS] inputObj " + JSON.stringify(inputObj));
    var config = JSON.parse(inputObj["config"]);
    var target = inputObj["target"];
    config = this.removeEmptyContainers("", config, "", target);
    inputObj["config"] = JSON.stringify(config);
    logger.info("prepreSync intent config after removing deviation attributes:" + JSON.stringify(inputObj));

    return inputObj;
  };  

/**
 * PostSync Hook
 */
const postSync = (inputObj) => {
  /**
   * Write your custom postSync logic here
   * inputObj by default contains the following keys:
   *          target, config, intentTypeName, rootXPath,
   *          intentContainer, uniqueIdentifier, deviceYangModuleName
   *          topology, state, syncResult
   */
  logger.info("[CUSTOM-HOOKS] postSync call");
  logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
  
};

/**
 * 
 * PostDiscovery Hook
 */
const postDiscovery = (inputObj) => {
  /**
   * Write your custom postDiscovery logic here
   * inputObj by default contains the following keys:
   *        deviceConfig, intentContainer, neId,
   *        targetDataStruct, templateName, deviceYangModuleName
   */

  logger.info("[CUSTOM-HOOKS] postDiscovery call");
  logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

} 

  this.removeEmptyContainers = function (prop, intentJson, path, target) {

    if (Array.isArray(intentJson)) {
      var object = [];
      for (var prop in intentJson) {
        var value = this.removeEmptyContainers(prop, intentJson[prop], path, target);
        if (value) {
          object.push(value);
        }

      }
      if (Object.keys(object).length !== 0) {
        return object;
      }
    } else if (typeof intentJson == 'object') {
      var object = {};
      for (var prop in intentJson) {
        var pPath = path + "/" + prop;
        var value = this.removeEmptyContainers(prop, intentJson[prop], pPath, target);
        if ((value && value !== null) || value == 0) {
          object[prop] = value;
        }

      }
      if (Object.keys(object).length !== 0) {
        return object;
      }
    } else {
      if (intentJson !== undefined && intentJson !== "") {
        return intentJson;
      }

      return null;
    }
  }


this.preAudit = preAudit;
this.postAudit = postAudit;
this.preSync = preSync;
this.postSync = postSync;
this.postDiscovery = postDiscovery;

}