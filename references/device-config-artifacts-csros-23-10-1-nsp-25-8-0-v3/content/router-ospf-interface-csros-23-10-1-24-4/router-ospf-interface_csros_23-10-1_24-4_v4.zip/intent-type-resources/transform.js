load({ script: resourceProvider.getResource("nfmpSuggest.js"), name: "NfmpSuggest" });
function transformData() {
    const nfmpSuggest = new NfmpSuggest();
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
      let interfaceData;
      if(intentConfig.interfaceId){
        interfaceData = nfmpSuggest.getInterfaceData(neId, intentConfig.interfaceId, "id", "displayedName");
        if(intentConfig.instanceIndex==0){
        objectFullName = objectFullName.replace(/ospf-[^:]+-instance-[^:]+/, "ospf-v2").replace(/interface-[^:]+/, "interface-"+interfaceData);
        }else{
           objectFullName = objectFullName.replace(/ospf-[^:]+?(?=-instance)/,"ospf-v2").replace(/interface-[^:]+/, "interface-"+interfaceData);
        }
      }
      return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
     let interfaceData;
     let instanceIndex = uniqueIdentifierValues[0];
     let areaId = uniqueIdentifierValues[1];
     let interfaceName = uniqueIdentifierValues[2];
    if(interfaceName){
        interfaceData = nfmpSuggest.getInterfaceData(neId, interfaceName, "id", "displayedName");
        if(instanceIndex==0){
        objectFullName = objectFullName.replace(/ospf-[^:]+-instance-[^:]+/, "ospf-v2").replace(/areaSite-[^:]+/, "areaSite-"+areaId).replace(/interface-[^:]+/, "interface-"+interfaceData);
        }else{
           objectFullName = objectFullName.replace(/ospf-[^:]+?(?=-instance)/,"ospf-v2").replace(/instance-[^:]+/,"instance-" +instanceIndex).replace(/areaSite-[^:]+/, "areaSite-"+areaId).replace(/interface-[^:]+/, "interface-"+interfaceData);
        }
      }
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
     if(intentConfig.instanceIndex==0){
        fdn = fdn.replace(/ospf-[^:]+-instance-[^:]+/, "ospf-v2");
     }
      else
     {
      fdn = fdn.replace(/ospf-[^:]+?(?=-instance)/,"ospf-v2");
     }
     return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
     if (payload.configInfo) {
        if (payload.configInfo["ospf.Interface"]) {
            let ospfInterface = payload.configInfo["ospf.Interface"];
            if (ospfInterface.interfaceId) {
                let interfaceData = nfmpSuggest.getInterfaceData(neId, ospfInterface.interfaceId, "id","displayedName");
                ospfInterface.interfaceId = interfaceData;
            }
            if (ospfInterface.authKeychain) {
              if (!ospfInterface.authKeychain.toString().startsWith("KeyChain:")) {
                let nfmpNameExtension = "KeyChain:"
                let authKeychainData  = nfmpNameExtension + ospfInterface.authKeychain;
                ospfInterface.authKeychain = authKeychainData;
              }
            } else payload.configInfo["ospf.Interface"].authKeychain = '';
            if ((isAudit && ospfInterface.authenticationKey) || (ospfInterface.authenticationKey == '')) {
                delete ospfInterface.authenticationKey;
            }
            if (ospfInterface.routeNextHopPointer) {
              if (!ospfInterface.routeNextHopPointer.toString().startsWith("rtrRouteNextHopTemp:rnhpt-")) {
                let nfmpNameExtension = "rtrRouteNextHopTemp:rnhpt-"
                let routeNextHopPointerData  = nfmpNameExtension + ospfInterface.routeNextHopPointer;
                ospfInterface.routeNextHopPointer = routeNextHopPointerData;
              }
            } else payload.configInfo["ospf.Interface"].routeNextHopPointer = '';
            if (ospfInterface["children-Set"] && ospfInterface["children-Set"]["ospf.Md5Key"]&& ospfInterface["children-Set"]["ospf.Md5Key"]) {
            for (var j in ospfInterface["children-Set"]["ospf.Md5Key"]) {
            let md5KeyItem = ospfInterface["children-Set"]["ospf.Md5Key"][j];
            if (((isAudit) && (md5KeyItem.hasOwnProperty("key"))) || (md5KeyItem.hasOwnProperty("key") == '')) {
                delete md5KeyItem["key"];
            }
           }
          }
        }
     }
     return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig) {
      if (xpath === "routeNextHopPointer") {
          targetValue = brownFieldNfmpNameSupport(targetValue, "rtrRouteNextHopTemp:rnhpt-");
      } else if (xpath === "authKeychain") {
          targetValue = brownFieldNfmpNameSupport(targetValue, "KeyChain:");
      } else if (xpath === "authenticationKey") {
          targetValue = ''
      }
      function brownFieldNfmpNameSupport(input, nameExtension) {
         if (input !== undefined && input.startsWith(nameExtension)) {
            var input1 = input.replace(nameExtension, "");
            return input1;
       }
       return input;
     }
     return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }
}
