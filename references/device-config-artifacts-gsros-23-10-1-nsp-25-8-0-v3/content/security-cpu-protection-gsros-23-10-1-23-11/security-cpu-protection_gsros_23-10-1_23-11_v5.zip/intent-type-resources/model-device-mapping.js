function ModelDeviceMapping() {
    this.getCpuPolicyMapping = function () {
        var mapping = {};
        mapping['policy.description'] = 'description';
        mapping['policy.alarm'] = 'polAlarm';
        mapping['policy.overall-rate'] = 'overallRateLimit';
        mapping['policy.per-source-rate'] = 'packetRateLimit';
        mapping['policy.out-profile-rate.pir'] = 'outProfileRate';
        mapping['policy.out-profile-rate.log-events'] = 'outProfRateLogEvnt';
        mapping['policy.per-source-parameters.ip-src-monitoring.limit-dhcp-ci-addr-zero'] = 'limDhcpCiAddrZero';
        return mapping;
    }
    this.getEthCfmMapping = function () {
        var mapping = {};
        mapping['policy.eth-cfm.entry.id'] = "id";
        mapping['policy.eth-cfm.entry.pir'] = "packetRateLimit";
        mapping['policy.eth-cfm.entry.level'] = "levelSet";
        mapping['policy.eth-cfm.entry.level.start'] = "levelSet";
        mapping['policy.eth-cfm.entry.level.end'] = "levelSet";
        mapping['policy.eth-cfm.entry.opcode'] = "opCodeSet";
        mapping['policy.eth-cfm.entry.opcode.start'] = "opCodeSet";
        mapping['policy.eth-cfm.entry.opcode.end'] = "opCodeSet";
        return mapping;
    }
}