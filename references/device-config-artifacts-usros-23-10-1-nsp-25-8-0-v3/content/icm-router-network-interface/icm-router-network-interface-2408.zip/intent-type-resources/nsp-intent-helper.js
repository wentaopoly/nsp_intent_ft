load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
load({script: resourceProvider.getResource('mdc-intent-fwk.js'), name: 'MdcIntentFwk'})
load({script: resourceProvider.getResource('nfmp-network-interface.js'), name: 'NfmpNetworkInterface'})
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'})
load({script: resourceProvider.getResource('routerTopology.js'), name: 'RouterTopology'})

function NspIntentHelper() {

    var mdtFwk = new MdtFwk();

    this.synchronize = function (input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, topologyInfo) {

        logger.info('Nsp Intent Helper -> Synchronise');
        try {

            var result = synchronizeResultFactory.createSynchronizeResult();

            var instanceFwk = this.navigateInstance(input.getTarget());

            var routerTopologyObj = topologyInfo[input.getTarget()];
            if (routerTopologyObj == null || routerTopologyObj == undefined) {
                routerTopologyObj = new RouterTopology();
            }

            result = instanceFwk.synchronize(input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, routerTopologyObj);

            if (input.getNetworkState().name() == "delete") {
                delete topologyInfo[input.getTarget()];
            } else {
                topologyInfo[input.getTarget()] = routerTopologyObj;
            }

            return result
        } catch (e) {
            logger.info('Error Occured while Synchronising with error: ' + e)
            throw new RuntimeException('Error Executing Intent: ' + e)
        }
    }

    this.audit = function (target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, topologyInfo) {

        try {
            var instanceFwk = this.navigateInstance(target);
            logger.info('instanceFwk ' + instanceFwk)

            var report = auditFactory.createAuditReport(null, null);
            var routerTopologyObj = topologyInfo[target];
            if (routerTopologyObj == null || routerTopologyObj == undefined) {
                routerTopologyObj = new RouterTopology();
            }
            //Calling the audit of respective fwk
            instanceFwk.audit(target, config, svcTopo, adminState, report, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, routerTopologyObj);

            return report
        } catch (e) {
            logger.info('Error Occured while Auditing with error: ' + e)
            throw new RuntimeException('Error Executing Intent: ' + e)
        }
    }

    this.navigateInstance = function (target) {


        var managerName = mdtFwk.getManagerName(new ParseTarget().getNeIdFromTarget(target));

        logger.info('Device: ' + target + ' is managed by: ' + managerName);

        switch (managerName) {
            case 'NFM-P':
                logger.info('Device is managed by NFMP')
                return this.createNfmpInstance()
                break;
            case 'MDC':
                logger.info('Device is managed by MDM')
                return this.createMdcInstance()
                break;
            default:
                logger.info('Device is not managed')
                throw new RuntimeException('Device is not Managed')
        }

        return ''
    }

    this.createNfmpInstance = function () {
        return new NfmpNetworkInterface()
    }

    this.createMdcInstance = function () {
        return new MdcIntentFwk()
    }

}
