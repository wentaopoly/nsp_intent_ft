var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk'});
load({ script: resourceProvider.getResource('traverse-fwk.js'), name: 'TraverseFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function MdcIntentFwk() {

    var savedTopologyMap = {};

    this.restResponseHandler = function(exception, httpStatus, response) {
        logger.info("[IntentMgr] REST response : " + response);
        logger.info("[IntentMgr] REST httpStatus : " + httpStatus);
        if (exception) {
            throw new RuntimeException("Couldn't connect to device proxy for ; Response: "+response);
        };
        if (httpStatus !== 200 && httpStatus !== 201) {
            throw new RuntimeException("Failed to access device  using MDC; Response: "+response);
        };
        restResponse = JSON.parse(response);
    };

    this.synchronize = function(input, result,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier, intentConfig, topologyMap) {

        savedTopologyMap = topologyMap[input.getTarget()];
        if(savedTopologyMap === undefined || savedTopologyMap === null)
        {
            savedTopologyMap = {};
        }
        var target = input.getTarget();
        var targetAttrs = target.split('#');
        var customerId = targetAttrs[3];
        var customerName = targetAttrs[2];

        var traverseFwk = new TraverseFwk();
        var sites = intentConfig['sites'];
        delete intentConfig['sites'];



        if (input.getNetworkState().name() == "delete")
        {
            if (sites == undefined || sites.length == 0){
                result.success = true;
            }
            else
            {
                for(var i=0; i < sites.length; i++)
                {
                    target = sites[i]['site-id'];
                    if(target != null && target != undefined && target != "0.0.0.0")
                    {
                        traverseFwk.resetTheVariables();
                        if (savedTopologyMap[target] ==undefined || savedTopologyMap[target] == null)
                        {
                            savedTopologyMap[target] = topologyFactory.createServiceTopology();
                        }
                        var requests = [];
                        var deleteObj = {};
                        deleteObj["operation"] = "delete";
                        deleteObj["edit-id"] = "edit-" + new Date().getTime();
                        deleteObj["target"] = "nokia-conf:/configure/service/customer=" + customerName;
                        requests.push(deleteObj)
                        result = traverseFwk.syncRequest(target, requests, result, savedTopologyMap[target]);
                        result.setTopology(null);
                        //result = traverseFwk.deleteAllFromTopology(savedTopology,target,result);
                        logger.info("Delete Result ::: "+result)
                    }
                }
            }
            delete topologyMap[input.getTarget()];
            return result;
        }

        if(savedTopologyMap !== undefined && Object.keys(savedTopologyMap).length)
        {
            for(var key in savedTopologyMap)
            {
                if(!this.includes(key,sites))
                {
                    logger.info("{} is deleted form intentConfig.",key);
                    var requests = [];
                    var deleteObj = {};
                    deleteObj["operation"] = "delete";
                    deleteObj["edit-id"] = "edit-" + new Date().getTime();
                    deleteObj["target"] = "nokia-conf:/configure/service/customer=" + customerName;
                    requests.push(deleteObj)
                    result = traverseFwk.syncRequest(key, requests, result, savedTopologyMap[key]);
                    result.setTopology(null);
                    if(!result['success']){
                        throw new RuntimeException("Unable to Delete: "+result.errorDetail);
                    }
                    delete savedTopologyMap[key];
                }
            }
        }

        if (sites !== undefined && sites != null && sites.length != 0)
        {
            var i = 0;
            do
            {
                var startTimeTargetDeployment = Date.now()
                target = sites[i]['site-id'];
                logger.info("Target Site = {}",target)
                if(target !== "0.0.0.0")
                {
                    intentConfig[uniqueIdentifier] = customerName;
                    intentConfig['customer-id'] = parseInt(customerId);

                    if (savedTopologyMap[target] === undefined || savedTopologyMap[target] === null)
                    {
                        savedTopologyMap[target] = topologyFactory.createServiceTopology();
                    }
                    var topology = this.deployInformation(intentConfig, result, target, traverseFwk, savedTopologyMap[target], parentXpath, initialPropertyName);
                    savedTopologyMap[target] = topology;
                }
                logger.info("Time Taken for sync on target {} is {} ms.",target,Date.now()-startTimeTargetDeployment)
                i++;
            } while (result['success'] && (i < sites.length))
        }
        else{
            result['success']=true;
        }

        topologyMap[input.getTarget()] = savedTopologyMap;
        return result;
    }

    this.deployInformation = function (intentConfig, result, target, traverseFwk, savedTopology, parentXpath, initialPropertyName)
    {
        if (intentConfig) {
            savedTopology = traverseFwk.traverse(target, intentConfig, savedTopology, null, parentXpath, initialPropertyName);

            //sorting delete array
            var deleteRequests = traverseFwk.getDeleteRequests();
            deleteRequests.sort(function (a, b) {
                return b["target"].length - a["target"].length;
            });

            // concating createrequests and deleterequests
            var createRequests = traverseFwk.getCreateRequests();
            var requests;
            if (deleteRequests && createRequests) {
                requests = createRequests.concat(deleteRequests);
            }
            if (requests) {
                logger.info("SyncRequest of site = {}",target);
                result = traverseFwk.syncRequest(target, requests, result, savedTopology);
            }

        } else {

            result = traverseFwk.deleteAllFromTopology(savedTopology, target, result);
        }

        traverseFwk.resetTheVariables();

        return savedTopology;
    }

    this.includes = function(obj,arr)
    {
        for (var item in arr)
        {
            if(arr[item]['site-id'] !== undefined && JSON.stringify(obj) === JSON.stringify(arr[item]['site-id']))
            {
                return true
            }
        }
        return false
    }

}
