var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();
    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let policyId = target.split("#")[2];
        let policyName = parseTarget.getUniqueIdentifier(target);
        let neId = parseTarget.getNeIdFromTarget(target);
        let className = "sasqos.PortAccessEgress";
        let objectFullName = "network:" + neId + ":sasPortAccessEgress:" + policyId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        let searchPayLoad = this.constructSearchString(className, objectFullName);
        let searchResponse = nfmpFwk.post("/v3/search", searchPayLoad);
        if (!(searchResponse.success && searchResponse["response"].length > 2))
        {
            if (!(searchResponse.success))
            throw new RuntimeException("Failed to get Port Egress Policy info from nfm-p for Ne " + neId + " and Port Egress Policy Id: " + policyId);
            if (searchResponse["response"].length <= 2)
            throw new RuntimeException("There is no Port Egress with Name:" + policyName + " and Id:" + policyId);
        }
        searchResponse = JSON.parse(searchResponse.response);
        logger.info("searchResponse = {}", JSON.stringify(searchResponse));
        return searchResponse;
    }

    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        logger.info("the parseTargetData" + JSON.stringify(parsedDefaultTargetData));
        let sasEgressConfig = deviceConfig['sasqos.PortAccessEgress'];
        if (null !== sasEgressConfig && sasEgressConfig !== undefined) {
            this.extractPolicyLevelProperties(parsedDefaultTargetData, sasEgressConfig);
        }
        let childrenConfig = sasEgressConfig['children-Set'];
        if (undefined !== childrenConfig && null !== childrenConfig && childrenConfig.length !== 0) {
            let fcData = parsedDefaultTargetData['port-qos-egress']['forwardingClass']['forwardingClass'];
            if (fcData !== null && Array.isArray(fcData) && fcData.length !== 0) {
                let childFcConfig = childrenConfig['sasqos.PortAccessEgressForwardingClass'];
                if (childFcConfig != undefined && childFcConfig.length != 0) {
                    let fcArray = this.extractFcData(fcData, childFcConfig);
                    parsedDefaultTargetData['port-qos-egress']["forwardingClass"]['forwardingClass'] = fcArray;
                } else {
                    delete parsedDefaultTargetData['port-qos-egress']["forwardingClass"]['forwardingClass'];
                }
            }

            let queueData = parsedDefaultTargetData['port-qos-egress']['queue']['queue'];
            if (queueData !== null && Array.isArray(queueData) && queueData.length !== 0) {
                let childQueueConfig = childrenConfig['sasqos.PortAccessEgressQueue'];
                if (childQueueConfig != undefined && childQueueConfig.length != 0) {
                    let queueDataArray = this.extractQueueData(queueData, childQueueConfig);
                    parsedDefaultTargetData['port-qos-egress']['queue']['queue'] = queueDataArray;
                } else {
                    delete parsedDefaultTargetData['port-qos-egress']['queue']['queue'];
                }
            }

        }
        return parsedDefaultTargetData;
    }

    this.extractPolicyLevelProperties = function (defaultTargetData, PortEgressConfig) {
        let PortData = JSON.parse(JSON.stringify(defaultTargetData));
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++) {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object') {
                let mappings = {};

                if(PortEgressConfig["description"]) {
                    mappings['port-qos-egress.description'] = 'description';
                }
                if(PortEgressConfig["scope"]) {
                    mappings['port-qos-egress.scope'] = 'scope';
                }
                if(PortEgressConfig["egressRemark"]) {
                    mappings['port-qos-egress.egress-remark'] = 'egressRemark';
                }
                if(PortEgressConfig["remarkingType"]) {
                    mappings['port-qos-egress.remarking-type'] = 'remarkingType';
                }
                if(PortEgressConfig["remarkPolicyPointer"]) {
                    mappings["port-qos-egress.remarking-policy"] = "remarkPolicyPointer";
                }


                this.traverseAndUpdateConfig(targetKey, targetObj, PortEgressConfig, mappings);
            }
        }
    }

    this.extractFcData = function (defaultFcEntry, childrenConfiguration) {
        let fcEntryDefaults = defaultFcEntry[0];
        let fcEntryArray = [];
        if (childrenConfiguration !== undefined && childrenConfiguration !== null) {
            if (Array.isArray(childrenConfiguration)) {
                for (let i = 0; i < childrenConfiguration.length; i++) {
                    let childConfig = childrenConfiguration[i];
                    let fcEntryData = this.fcEntryData(fcEntryDefaults, childConfig);
                    fcEntryArray.push(fcEntryData);
                }
            } else {
                let childConfig = childrenConfiguration;
                let fcEntryData = this.fcEntryData(fcEntryDefaults, childConfig);
                fcEntryArray.push(fcEntryData);
            }
        }
        return fcEntryArray;
    }
    this.fcEntryData = function (fcEntryDefaults, childConfig) {
        let ForwardingClassData = JSON.parse(JSON.stringify(fcEntryDefaults));
        if (childConfig['forwardingClass']) {
            ForwardingClassData['forwarding-class'] = childConfig['forwardingClass'];
        }
        if (childConfig['dot1pProfile']) {
            ForwardingClassData['dot1p']['dot1p'] = this.convertToDot1p(childConfig['dot1pProfile']);
        }
        if (childConfig['inDot1p']) {
            ForwardingClassData["dot1p"]["dot1p_in_profile"] = this.convertToDot1p(childConfig['inDot1p']);
        }
        if (childConfig['outDot1p']) {
            ForwardingClassData['dot1p']['dot1p_out_profile'] = this.convertToDot1p(childConfig['outDot1p']);
        }
        if (childConfig['dscpInProfile']) {
            ForwardingClassData['dscp']['dscp_in_profile'] = childConfig['dscpInProfile'];
        }
        if (childConfig['dscpOutProfile']) {
            ForwardingClassData['dscp']['dscp_out_profile'] = childConfig['dscpOutProfile'];
        }
        if (childConfig['deMark']) {
            ForwardingClassData['de']['mark-de-bit'] = childConfig['deMark'];
        }
        if (childConfig['forceDeValue']) {
            ForwardingClassData['de']['force-de-value'] = childConfig['forceDeValue'];
        }
        this.clearEmptiesAndNull(ForwardingClassData);
        return ForwardingClassData;
    }

    this.extractQueueData = function (defaultQueueEntry, childrenConfiguration) {
        let queueEntryDefaults = defaultQueueEntry[0];
        let queueEntryArray = [];
        if (childrenConfiguration !== undefined && childrenConfiguration !== null) {
            if (Array.isArray(childrenConfiguration)) {
                for (let i = 0; i < childrenConfiguration.length; i++) {
                    let childConfig = childrenConfiguration[i];
                    let queueEntryData = this.QueueData(queueEntryDefaults, childConfig);
                    queueEntryArray.push(queueEntryData);
                }
            } else {
                let childConfig = childrenConfiguration;
                let queueEntryData = this.QueueData(queueEntryDefaults, childConfig);
                queueEntryArray.push(queueEntryData);
            }
        }
        return queueEntryArray;
    }

    this.QueueData = function (queueEntryDefaults, childConfig) {

        let queueEntryData = JSON.parse(JSON.stringify(queueEntryDefaults));

        if(childConfig["id"]) {
            queueEntryData['queue-id'] = childConfig['id'];
        }
        if (childConfig['mode']) {
            queueEntryData['mode'] = childConfig['mode'];
        }
        if (childConfig['queuemgmtPolicyPointer']) {
            queueEntryData['queue-management-policy'] = this.convertToQueueMgmtPolicy(childConfig['queuemgmtPolicyPointer']);
        }
        if (childConfig['weight']) {
            queueEntryData['weight'] = childConfig['weight'];
        }
        if (childConfig['rateType']) {
            queueEntryData['rate']['rate-type'] = childConfig['rateType'];
        }
        if (childConfig['cir'] == "-1") {
            queueEntryData['rate']['cir'] = "max";
        }
        else if(childConfig["cir"]) {
            queueEntryData["rate"]["cir"] = childConfig["cir"];
        }
        if (childConfig['cirPercent']) {
            queueEntryData['rate']['cir-percent'] = childConfig['cirPercentInDecimals'];
        }
        if (childConfig['cirAdaptation']) {
            queueEntryData['adaptation-rule']['cir-adaptation'] = childConfig['cirAdaptation'];
        }
        if (childConfig['pir'] == "-1") {
            queueEntryData['rate']['pir'] = "max";
        }
        else if(childConfig["pir"]) {
            queueEntryData["rate"]["pir"] = childConfig["pir"];
        }
        if (childConfig['pirPercent']) {
            queueEntryData['rate']['pir-percent'] = childConfig['pirPercentInDecimals'];
        }
        if (childConfig['pirAdaptation']) {
            queueEntryData['adaptation-rule']['pir-adaptation'] = childConfig['pirAdaptation'];
        }

        this.clearEmptiesAndNull(queueEntryData);
        return queueEntryData;
    }
    this.traverseAndUpdateConfig = function (objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port-qos-egress.queue" && mappedKey !== "port-qos-egress.forwardingClass") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, parsedDeviceConfig) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = parsedDeviceConfig[nfmpKey];
        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue, parsedDeviceConfig);

    }

    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue && deviceValue !== null) {
            switch (mappedKey) {
                case"port-qos-egress.remarking-policy":
                    deviceValue = this.convertToRemarkingPolicy(deviceValue);
                    break;
            }
            return deviceValue;
        }
    }

    this.convertToRemarkingPolicy = function(value) {
        let arr = value.split(":");
        return arr[1];
    }

    this.convertToDot1p = function(value) {
        if(value == "default") {
            return "default";
        }
        let arr = value.split("_");
        return arr[1];
    }

    this.convertToQueueMgmtPolicy = function(value) {
        let arr = value.split(":");
        return arr[1];
    }


    this.constructSearchString = function (fullClassName, objectFullName) {
        let jsonPayLoad = {
            "fullClassName": fullClassName,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        return jsonPayLoad;
    }

    this.clearEmptiesAndNull = function (o) {
        for (let k in o) {
            if (o[k] === null) {
                delete o[k];
            }
            if (!o[k] || typeof o[k] !== "object") {
                continue
            }

            this.clearEmptiesAndNull(o[k]);
            if (Object.keys(o[k]).length === 0) {
                delete o[k];
            }
        }
    }
}
