function MdSuggest() {
    this.getPolicyName = function (neId, policyId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-state:/state/qos/sap-ingress?fields=oper-policy-id";
        return this.getData(neId, url, "sap-ingress-policy-name", policyId);
    }
    this.getPolicyId = function (neId, policyName) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-state:/state/qos/sap-ingress?fields=oper-policy-id";
        if (policyName)
        {
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-state:/state/qos/sap-ingress=" + policyName + "?fields=oper-policy-id";
        }
        return this.getData(neId, url, "oper-policy-id");
    }

    this.getIngressClassificationPolicy = function (neId) {
        var url =  "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/ingress-classification-policy";
        return this.getIngressClassificationPolicyData(neId, url, "ingress-classification-policy-name");
    }

    this.getIngressClassificationPolicyData = function (neId, url, type) {
        var mdcFwk = new MdcFwk();
        logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info("MDC resultFetch =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"]["nokia-conf:ingress-classification-policy"];
        logger.info("finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse))
        {
            for (var index in finalResponse)
            {

                logger.info("Device Ingress Classification Policy Name = {}", finalResponse[index]["ingress-classification-policy-name"]);
                ret.push(finalResponse[index][type]);
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info("ret = \n" + JSON.stringify(ret));
        return ret;
    }

    this.getData = function (neId, url, type, policyId) {
        var mdcFwk = new MdcFwk();
        logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info("MDC resultFetch =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"]["nokia-state:sap-ingress"];
        logger.info("finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse))
        {
            for (var index in finalResponse)
            {
                if (policyId)
                {
                    logger.info("PolicyId Selected = {}", policyId);
                    logger.info("Device policy ID = {}", finalResponse[index]["oper-policy-id"]);
                    if (finalResponse[index]["oper-policy-id"] == policyId)
                    {
                        ret.push(finalResponse[index][type]);
                        break;
                    }
                }
                else
                {
                    ret.push(finalResponse[index][type]);
                }
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info("ret = \n" + JSON.stringify(ret));
        return ret;
    }
}
