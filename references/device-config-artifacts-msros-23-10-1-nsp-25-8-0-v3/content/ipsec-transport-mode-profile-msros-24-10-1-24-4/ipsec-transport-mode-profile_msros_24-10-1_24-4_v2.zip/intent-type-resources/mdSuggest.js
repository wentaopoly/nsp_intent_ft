function MdSuggest() {
    this.getprofileName = function (neId) {
       const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/ipsec/ipsec-transport-mode-profile?fields=name`;
       return this.getSuggestData(neId, url, "nokia-conf:ipsec-transport-mode-profile", "name");
    }

    this.getIpsecTransform = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/ipsec/ipsec-transform?fields=id`;
    return this.getSuggestData(neId, url, "nokia-conf:ipsec-transform", "id");
   }

    this.getCertProfile = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/ipsec/cert-profile?fields=name`;
    return this.getSuggestData(neId, url, "nokia-conf:cert-profile", "name");
   }

    this.getTrustAnchorProfile = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/ipsec/trust-anchor-profile?fields=name`;
    return this.getSuggestData(neId, url, "nokia-conf:trust-anchor-profile", "name");
   }
   this.getPpkId = function(neId, listData) {
     const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/ipsec/ppk-list=${listData}/ppk?fields=ppk-id`;
   return this.getSuggestData(neId, url, "nokia-conf:ppk", "ppk-id");
   }

   this.getPpkList = function(neId) {
     const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/ipsec/ppk-list?fields=name`;
   return this.getSuggestData(neId, url, "nokia-conf:ppk-list", "name");
   }

   this.getIkePolicy = function(neId) {
     const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/ipsec/ike-policy?fields=id`;
   return this.getSuggestData(neId, url, "nokia-conf:ike-policy", "id");
   }

   this.getSuggestData = function(neId, url, initialProperty, propertyName) {
      const mdcFwk = new MdcFwk();
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg[initialProperty];
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data[propertyName]).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }
}