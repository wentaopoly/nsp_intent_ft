var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};


load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource('nsp-restconf-fwk.js'), name: 'nsp-restconf-fwk'});
var nspRestconfFwk = new NspRestconfFwk();

load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
var util = new utilities();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('mdSuggest.js'), name: 'mdSuggest'});

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})

load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
var mdtFwk =  new MdtFwk();

var intentTypeName = 'mc-peer-lag-endpoint_gsros_23-10-1_23-11';

// example port, sap-ingress etc..
var initialPropertyName = 'peer';


// unique identifier
var uniqueIdentifier = 'source-address';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/redundancy/multi-chassis';

var topologyMap = {};

function synchronize(input) {
    logger.info('Intent Synchronisation started')
    var endpointAInterfaceAddress = input.getTarget().split("#")[3];
    var endpointBInterfaceAddress = input.getTarget().split("#")[5];

    if (util.compareIpAddress(endpointAInterfaceAddress, endpointBInterfaceAddress) > 0)
    {
        throw new RuntimeException("Endpoint-A Interface Address must be lower than Endpoint-B Interface Address");
    }

    return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, topologyMap);
}

function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started')
    var endpointAInterfaceAddress = target.split("#")[3];
    var endpointBInterfaceAddress = target.split("#")[5];

    if (util.compareIpAddress(endpointAInterfaceAddress, endpointBInterfaceAddress) > 0)
    {
        throw new RuntimeException("Endpoint-A Interface Address must be lower than Endpoint-B Interface Address");
    }
    return NspIntentHelper.audit(target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier);
}

function suggestLagIds(context) {
    try
    {
        var endPointSiteId;
        var endPointLag = context.getInputValues()["arguments"]["__attribute"];
        var templateName = context.getInputValues()["target"]["templatename"];
        if (endPointLag == "lag-name")
        {
            endPointSiteId = context.getInputValues()["arguments"]["__parent"]["target_firstSiteId"];
            if (!endPointSiteId)
            {
                endPointSiteId = context.getInputValues()["target"]["target"][templateName]["target_firstSiteId"];
            }
        }
        else if (endPointLag == "remote-lag")
        {
            endPointSiteId = context.getInputValues()["arguments"]["__parent"]["target_secondSiteId"];
            if (!endPointSiteId)
            {
                endPointSiteId = context.getInputValues()["target"]["target"][templateName]["target_secondSiteId"];
            }
        }
        logger.info("listing LAGS for NeId : " + endPointSiteId);

        ret = nspRestconfFwk.getLagNames(endPointSiteId);
    } catch (e)
    {
        logger.error(" " + e.message);
    }
    return ret;
}

function suggestNeIds(context) {
    var endPointTarget = context.getInputValues()["arguments"]["__attribute"];
    var targetIdentifier = context.getInputValues()["target"]["objectidentifier"];
    var neId;
    if (targetIdentifier)
    {
        if (String(targetIdentifier).indexOf("ne-id") !== -1)
        {
            neId = targetIdentifier.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = targetIdentifier;
        }
    }
    logger.info("Selected target = " + neId);
    if (endPointTarget == "target_firstSiteId")
    {
        return [neId];
    }
    var endpointASiteId = context.getInputValues()["arguments"]["target_firstSiteId"];
    if (!endpointASiteId)
    {
        endpointASiteId = context.getInputValues()["target"]["firstSiteId"];
    }
    if (endPointTarget == "target_secondSiteId" && endpointASiteId)
    {
        return nspRestconfFwk.getNeId(endpointASiteId);
    }
}

function suggestInterfaceAddr(context) {
    var endPointInterfaceTarget = context.getInputValues()["arguments"]["__attribute"];
    var endpointSiteId;
    if (endPointInterfaceTarget == "target_firstSiteSourceIpAddress")
    {
        endpointSiteId = context.getInputValues()["arguments"]["target_firstSiteId"];
        if (!endpointSiteId)
        {
            endpointSiteId = context.getInputValues()["target"]["firstSiteId"];
        }
    }
    else if (endPointInterfaceTarget == "target_secondSiteSourceIpAddress")
    {
        endpointSiteId = context.getInputValues()["arguments"]["target_secondSiteId"];
        if (!endpointSiteId)
        {
            endpointSiteId = context.getInputValues()["target"]["secondSiteId"];
        }
    }
    if (endpointSiteId)
    {
        return nspRestconfFwk.getNeInterfaceAddress(endpointSiteId);
    }
}

function getTargetData(input) {
    logger.info(input);
    var target = input.target;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}

function getNeId(context) {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    logger.info("target : {}", target)
    if (!target) {
        target = context.getInputValues()["arguments"]["__root"]["target_objectidentifier"];
    }
    if (target) {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        } else {
            neId = target;
        }
    }
    logger.info("NeId identified " + " : {}", neId);
    return neId;
}

function navigateInstance(neId) {
    var managerName = mdtFwk.getManagerName(neId);
    logger.info('Device: ' + neId + ' is managed by: ' + managerName);
    switch (managerName)
    {
        case 'NFM-P':
            logger.info('Device is managed by NFMP')
            return new NfmpSuggest();
            break;
        case 'MDC':
            logger.info('Device is managed by MDM')
            return new MdSuggest();
            break;
        default:
            logger.info('Device is not managed')
            throw new RuntimeException('Device is not Managed')
    }
    return ''
}


function suggestDomainA(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_firstSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_firstSiteId"];
    }
    return navigateInstance(neId).getDomain(neId);
}

function suggestDomainB(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_secondSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_secondSiteId"];
    }
    return navigateInstance(neId).getDomain(neId);
}

function suggestTunnelGrpA(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_firstSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_firstSiteId"];
    }

    return navigateInstance(neId).getTunnelGrp(neId);
}

function suggestTunnelGrpB(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_secondSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_secondSiteId"];
    }
    return navigateInstance(neId).getTunnelGrp(neId);
}

function suggestFirstSiteSdpId(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_firstSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_firstSiteId"];
    }
    return navigateInstance(neId).getSdpData(neId);
}

function suggestSecondSiteSdpId(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_secondSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_secondSiteId"];
    }
    return navigateInstance(neId).getSdpData(neId);
}

function suggestFirstSitePortName(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_firstSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_firstSiteId"];
    }
    return navigateInstance(neId).getPorts(neId);
}

function suggestSecondSitePortName(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_secondSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_secondSiteId"];
    }
    return navigateInstance(neId).getPorts(neId);
}

function suggestIsaNatGroupIdA(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_firstSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_firstSiteId"];
    }
    return navigateInstance(neId).getIsaNatGroupId(neId);
}

function suggestIsaNatGroupIdB(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_secondSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_secondSiteId"];
    }
    return navigateInstance(neId).getIsaNatGroupId(neId);
}

function suggestKeychainsKeychainNameA(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_firstSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_firstSiteId"];
    }
    return navigateInstance(neId).getKeychainsKeychainName(neId);
}

function suggestKeychainsKeychainNameB(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_secondSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_secondSiteId"];
    }
    return navigateInstance(neId).getKeychainsKeychainName(neId);
}

function suggestConfigurePortIdA(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_firstSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_firstSiteId"];
    }
    return navigateInstance(neId).getConfigurePortId(neId);
}

function suggestConfigurePortIdB(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_secondSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_secondSiteId"];
    }
    return navigateInstance(neId).getConfigurePortId(neId);
}

function suggestConfigureLagNameA(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_firstSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_firstSiteId"];
    }
    return navigateInstance(neId).getConfigureLagName(neId);
}

function suggestConfigureLagNameB(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_secondSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_secondSiteId"];
    }
    return navigateInstance(neId).getConfigureLagName(neId);
}

function suggestConfigurePwPortPwPortIdA(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_firstSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_firstSiteId"];
    }
    return navigateInstance(neId).getConfigurePwPortPwPortId(neId);
}

function suggestConfigurePwPortPwPortIdB(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_secondSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_secondSiteId"];
    }
    return navigateInstance(neId).getConfigurePwPortPwPortId(neId);
}

function suggestDiameterNodeOriginHostA(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_firstSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_firstSiteId"];
    }
    return navigateInstance(neId).getDiameterNodeOriginHost(neId);
}

function suggestDiameterNodeOriginHostB(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_secondSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_secondSiteId"];
    }
    return navigateInstance(neId).getDiameterNodeOriginHost(neId);
}

function suggestRingName(context) {
    logger.info("context = {}",context);
    var ringNames= [];
    var target = context.getInputValues()["arguments"]["__parent"]["peer"]["sync"]["syncGroup"];
    if (target == undefined && context.getInputValues()["arguments"]["peer"]["sync"]["syncGroup"])
    {
        target = context.getInputValues()["arguments"]["peer"]["sync"]["syncGroup"];
    }
    for(var i=0;i<target.length;i++){
        ringNames.push(target[i]["tag"]);
    }
    return ringNames;
}

function suggestL3AccessInterfaceA(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_firstSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_firstSiteId"];
    }
    return navigateInstance(neId).getInterface(neId);
}

function suggestL3AccessInterfaceB(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_secondSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_secondSiteId"];
    }
    return navigateInstance(neId).getInterface(neId);
}

function suggestRncvServiceIdA(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_firstSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_firstSiteId"];
    }
    return navigateInstance(neId).getRncvServiceId(neId);
}

function suggestRncvServiceIdB(context) {
    var templateName = context.getInputValues()["target"]["templatename"];
    var neId = context.getInputValues()["arguments"]["__parent"]["target_secondSiteId"];
    if (!neId)
    {
        neId = context.getInputValues()["target"]["target"][templateName]["target_secondSiteId"];
    }
    return navigateInstance(neId).getRncvServiceId(neId);
}

function suggestMcKeyChainName(context) {
    return new NfmpSuggest().getMcKeyChainName();
}