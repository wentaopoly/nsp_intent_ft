var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});

function NfmpDiscoveryHelper() {

    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let schedulerPolicyName = target.split("#")[2];
        let searchPayLoad = this.constructSearchString(neId, schedulerPolicyName);
        let searchResponse = nfmpFwk.post("search", searchPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find Scheduler Policy  : " + schedulerPolicyName + " on NE " + neId);
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse[0];
    }

    this.constructSearchString = function (neId, schedulerPolicyName) {
        let fullName = "fullName = 'network:" + neId + ":Scheduler:" + schedulerPolicyName + "'";
        if (neId && String(neId).indexOf(':') !== -1) {
            fullName = util.modifyNeIdForIpV6(fullName, neId);
        }
        let jsonPayLoad = {
            "filter": {
                "filterExpression": fullName
            },
            "fullClassName": "vs.Policy"
        };
        return jsonPayLoad;
    }

    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        logger.info("***********************************deviceConfig***********************************************");
        logger.info(JSON.stringify(deviceConfig));
        logger.info("************************************parsedDefaultTargetData***********************************");
        logger.info(JSON.stringify(parsedDefaultTargetData));
        logger.info("**************************************************END******************************************");

        if (null !== deviceConfig)
        {
            this.extractSchPolicyProperties(parsedDefaultTargetData, deviceConfig);
            if(deviceConfig['children'])
            {
                let tierData = this.extractTierProperties(parsedDefaultTargetData['scheduler-policy']['tier'], deviceConfig);
                parsedDefaultTargetData['scheduler-policy']['tier'] = tierData;
            }
            else
            {
                parsedDefaultTargetData['scheduler-policy']['tier'] = [];
            }
        }
        this.clearEmpties(parsedDefaultTargetData);
        logger.info("Intent data after updating from NFMP :\n" + JSON.stringify(parsedDefaultTargetData));
        return parsedDefaultTargetData;
    }

    this.extractSchPolicyProperties = function (defaultTargetData, deviceConfig) {
        let keys = Object.keys(defaultTargetData);
        //logger.info("keys = " + keys)
        for (let i = 0; i < keys.length; i++)
        {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj))
            if (targetObj !== null && typeof targetObj === 'object')
            {
                this.traverseAndUpdateConfig(targetKey, targetObj, deviceConfig);
            }
        }
        return defaultTargetData;
    }

    this.extractTierProperties = function (tierTargetData, deviceConfig) {
        //take copy of tire Data, for iteration of keys
        let defaultTierData = JSON.parse(JSON.stringify(tierTargetData[0]));
        //clear scheduler,to handle nested list addition.
        tierTargetData = [];
        let deviceTierData = deviceConfig['children'];
        for (let i = 0; i < deviceTierData.length; i++)
        {
            let deviceTierConfig = deviceTierData[i]['properties'];
            let deviceTierId = deviceTierConfig['tier'];
            deviceTierId = deviceTierId.charAt(deviceTierId.length - 1);
            this.extractTierSchedulerProperties(defaultTierData, tierTargetData, deviceTierId, deviceTierConfig, deviceConfig['properties']['tier1ParentLoc']);
        }
        return tierTargetData;
    }

    this.extractTierSchedulerProperties = function (defaultTierData, tierTargetData, tierId, deviceTierConfig, tier1ParentLocation) {
        let tierData;
        for (let tierDataNum = 0; tierDataNum < tierTargetData.length; tierDataNum++)
        {
            if (tierTargetData[tierDataNum]['tier-id'] == tierId)
            {
                tierData = tierTargetData[tierDataNum];
            }
        }
        if (!tierData)
        {
            tierData = JSON.parse(JSON.stringify(defaultTierData));
            //clear scheduler,to handle nested list addition.
            tierData['scheduler'] = [];
            tierTargetData.push(tierData);
        }

        let keys = Object.keys(defaultTierData);
        logger.info("keys = " + keys);
        for (let j = 0; j < keys.length; j++)
        {
            let targetKey = keys[j];
            let targetObj = tierData[targetKey];
            let mappedKey = "scheduler-policy.tier." + targetKey;
            //logger.info("targetKey = " + targetKey + "\ntargetObj = " + JSON.stringify(targetObj) + "\nmappedKey = " + mappedKey);
            if (targetObj !== null && typeof targetObj === 'object')
            {
                let schedulerData = JSON.parse(JSON.stringify(defaultTierData['scheduler'][0]));
                this.traverseAndUpdateSchedulerConfig(mappedKey, schedulerData, deviceTierConfig);
                tierData['scheduler'].push(JSON.parse(JSON.stringify(schedulerData)));
            }
            else
            {
                let mappings = modelDeviceMapping.getTierMapping();
                if (mappedKey === 'scheduler-policy.tier.parent-location')
                {
                    if (tierData['tier-id'] == 1)
                    {
                        tierData[targetKey] = this.convertToIntentParentLocation(tier1ParentLocation);
                    }
                    else
                    {
                        tierData[targetKey] = undefined;
                    }
                }
                else
                {
                        this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetKey, tierData, deviceTierConfig);
                }
            }
        }
    }


    this.traverseAndUpdateConfig = function (objKey, obj, deviceConfig) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            let deviceConfigData;
            let mappings;

            //logger.info("**********mappedKey = " + mappedKey);
            mappings = modelDeviceMapping.getSchPolicyMapping();
            deviceConfigData = deviceConfig['properties'];

            if (value != null && typeof value === 'object')
            {
                continue;
            }
            else
            {
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, deviceConfigData);
            }

        }
        return obj;
    }

    this.traverseAndUpdateSchedulerConfig = function (objKey, obj, deviceConfig) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            let deviceConfigData;
            let mappings;
            //logger.info("**********mappedKey = " + mappedKey);
            mappings = modelDeviceMapping.getSchedulerMapping();
            deviceConfigData = deviceConfig;

            if (value != null && typeof value === 'object')
            {
                this.traverseAndUpdateSchedulerConfig(mappedKey, value, deviceConfig);
            }
            else
            {
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, deviceConfigData);
            }
        }
        return obj;
    }

    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetKey, targetObj, deviceConfigData) {
        let nfmpKey = mappings[mappedKey];
        let deviceValue = deviceConfigData[nfmpKey];

        if (deviceConfigData['rateType'] == "kbps")
        {
            if (mappedKey == "scheduler-policy.tier.scheduler.percent-rate.pir" ||
                mappedKey == "scheduler-policy.tier.scheduler.percent-rate.cir" ||
                mappedKey == "scheduler-policy.tier.scheduler.percent-rate.reference-rate")
            {
                deviceValue = undefined;
            }
            if (deviceConfigData['summedCir'] == "true" && mappedKey == "scheduler-policy.tier.scheduler.rate.cir")
            {
                deviceValue = -3;
            }
        }
        else
        {
            if (mappedKey == "scheduler-policy.tier.scheduler.rate.pir" ||
                mappedKey == "scheduler-policy.tier.scheduler.rate.cir")
            {
                deviceValue = undefined;
            }
            if (deviceConfigData['summedCir'] == "true" && mappedKey == "scheduler-policy.tier.scheduler.percent-rate.cir")
            {
                deviceValue = -3;
            }
        }

        if (deviceConfigData['portParent'] == "false")
        {
            if (mappedKey == "scheduler-policy.tier.scheduler.port-parent.level" ||
                mappedKey == "scheduler-policy.tier.scheduler.port-parent.weight" ||
                mappedKey == "scheduler-policy.tier.scheduler.port-parent.cir-level" ||
                mappedKey == "scheduler-policy.tier.scheduler.port-parent.cir-weight")
            {
                deviceValue = undefined;
            }
        }
        else
        {
            if (mappedKey == "scheduler-policy.tier.scheduler.scheduler-parent.scheduler-name" ||
                mappedKey == "scheduler-policy.tier.scheduler.scheduler-parent.level" ||
                mappedKey == "scheduler-policy.tier.scheduler.scheduler-parent.weight" ||
                mappedKey == "scheduler-policy.tier.scheduler.scheduler-parent.cir-level" ||
                mappedKey == "scheduler-policy.tier.scheduler.scheduler-parent.cir-weight")
            {
                deviceValue = undefined;
            }
        }

        if (deviceConfigData['nextSchedulerName'])
        {
            if (mappedKey == "scheduler-policy.tier.scheduler.port-parent.level" ||
                mappedKey == "scheduler-policy.tier.scheduler.port-parent.weight" ||
                mappedKey == "scheduler-policy.tier.scheduler.port-parent.cir-level" ||
                mappedKey == "scheduler-policy.tier.scheduler.port-parent.cir-weight")
            {
                deviceValue = undefined;
            }
        }
        else
        {
            if (mappedKey == "scheduler-policy.tier.scheduler.scheduler-parent.scheduler-name" ||
                mappedKey == "scheduler-policy.tier.scheduler.scheduler-parent.level" ||
                mappedKey == "scheduler-policy.tier.scheduler.scheduler-parent.weight" ||
                mappedKey == "scheduler-policy.tier.scheduler.scheduler-parent.cir-level" ||
                mappedKey == "scheduler-policy.tier.scheduler.scheduler-parent.cir-weight")
            {
                deviceValue = undefined;
            }
        }
        logger.info("nfmpKey = " + nfmpKey + ", deviceValue = " + deviceValue);
        targetObj[targetKey] = (deviceValue) ? this.transformDeviceValue(mappedKey, deviceValue) : deviceValue;
    }

    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue !== null)
        {
            switch (mappedKey)
            {
                case "scheduler-policy.tier.tier-id":
                    deviceValue = this.convertToIntentTierId(deviceValue);
                    break;
                case "scheduler-policy.tier.parent-location":
                    deviceValue = this.convertToIntentParentLocation(deviceValue);
                    break;
                case "scheduler-policy.tier.scheduler.percent-rate.pir":
                case "scheduler-policy.tier.scheduler.percent-rate.cir":
                    deviceValue = this.convertToIntentPercentRate(deviceValue);
                    break;
                case "scheduler-policy.tier.scheduler.rate.pir":
                case "scheduler-policy.tier.scheduler.rate.cir":
                    deviceValue = this.convertToIntentRate(deviceValue);
                    break;
                case "scheduler-policy.tier.scheduler.port-parent.level":
                case "scheduler-policy.tier.scheduler.port-parent.weight":
                case "scheduler-policy.tier.scheduler.port-parent.cir-level":
                case "scheduler-policy.tier.scheduler.port-parent.cir-weight":
                case "scheduler-policy.tier.scheduler.scheduler-parent.level":
                case "scheduler-policy.tier.scheduler.scheduler-parent.weight":
                case "scheduler-policy.tier.scheduler.scheduler-parent.cir-level":
                case "scheduler-policy.tier.scheduler.scheduler-parent.cir-weight":
                    deviceValue = this.convertToIntentLevelWeight(deviceValue);
                    break;
                case "scheduler-policy.frame-based-accounting":
                case "scheduler-policy.tier.scheduler.limit-unused-bandwidth":
                    deviceValue = this.convertToBoolean(deviceValue);
                    break;
                case "scheduler-policy.tier.scheduler.percent-rate.reference-rate":
                    deviceValue = this.convertToIntentRateType(deviceValue);
                    break;
            }
            return deviceValue;
        }
    }

    this.convertToBoolean = function (deviceValue) {
        if (JSON.parse(deviceValue))
        {
            return true;
        }
        return undefined;
    }

    this.convertToIntentTierId = function (deviceValue) {
        if (deviceValue === 'tier1')
        {
            deviceValue = '1';
        }
        else if (deviceValue === 'tier2')
        {
            deviceValue = '2';
        }
        else if (deviceValue === 'tier3')
        {
            deviceValue = '3';
        }
        return deviceValue;
    }

    this.convertToIntentParentLocation = function (deviceValue) {
        if (deviceValue === 'none')
        {
            deviceValue = "auto";
        }
        return deviceValue;
    }

    this.convertToIntentLevelWeight = function (deviceValue) {
        if (deviceValue === 'defaultLevel')
        {
            deviceValue = 0;
        }
        else
        {
            deviceValue = deviceValue.replace('weight', '');
            deviceValue = deviceValue.replace('level', '');
        }
        return parseInt(deviceValue);
    }

    this.convertToIntentPercentRate = function (deviceValue) {
        return parseFloat(deviceValue);
    }

    this.convertToIntentRate = function (deviceValue) {
        return parseInt(deviceValue);
    }

    this.convertToIntentRateType = function (deviceValue) {
        if (deviceValue === 'percentLocalLimit')
        {
            return 'local-limit'
        }
        else if (deviceValue === 'percentReferencePortLimit')
        {
            return 'reference-port-limit'
        }
        return deviceValue;
    }

    this.clearEmpties = function (o) {
        for (let k in o)
        {
            if (!o[k] || typeof o[k] !== "object")
            {
                continue
            }

            this.clearEmpties(o[k]);
            if (Object.keys(o[k]).length === 0)
            {
                delete o[k];
            }
        }
    }
}
