<#ftl output_format="JSON">
<#setting number_format="computer">
{
    "lsp-name": "${target}",
    "to": "${destination}",
    "from": "${device}",
    <#if config["admin-state"] == "tunnel-admin-state-down">
        "admin-state" : "disable",
    <#else>
        "admin-state" : "enable",
    </#if>

    <#if config["path-profile"]?has_content>
        "path-profile":{
        <#if config["path-group"]?has_content>
            "path-group": "${config["path-group"]?long?c}",
        </#if>
        "profile-id": "${config["path-profile"]?long?c}"
        },
    </#if>

     <#if config["color"]?has_content>
        "admin-tag":{        
        "name": "${config["color"]}"
        },
    </#if>

    <#if config["signaling-type"] == "path-setup-rsvp">
        <#if config["protection"]["enable"] == true>
            "fast-reroute" : {
                <#if config["protection"]["protection-type"] == "lsp-protection-1-for-1">
                    "frr-method" : "one-to-one"
                <#elseif config["protection"]["protection-type"] == "lsp-protection-1-for-n">
                    "frr-method" : "facility"
                </#if>
            },
        </#if>
    </#if>

    <#if config["signaling-type"] == "path-setup-sr">
        "type": "p2p-sr-te",
    <#else>
        "type": "p2p-rsvp",
    </#if>
    "primary": [
        <#list extraParams.primary?values as value>
            {
                "path-name": "${value.name}",
                <#if value.hop != 0>
                    "hop-limit" : ${value.hop},
                </#if>
                "bandwidth": ${value.bandwidth},
                <#if  value.includeAdminGroup.length != 0 >
                    "include-admin-group" :{
                      "group" : [
                        <#list value.includeAdminGroup?values as includeVal>
                            "${includeVal}"<#if includeVal?has_next>,</#if>
                        </#list>
                    ]},
                </#if>
                <#if  value.excludeAdminGroup.length != 0 >
                    "exclude-admin-group" :{
                    "group" : [
                    <#list value.excludeAdminGroup?values as excludeVal>
                        "${excludeVal}"<#if excludeVal?has_next>,</#if>
                    </#list>
                    ]},
                </#if>
                "priority" : {
                    "setup-priority" : ${value.setupPriority},
                    "hold-priority" : ${value.holdPriorioty}
                }
            }<#if value?has_next>,</#if>
        </#list>
        <#list extraParams.hopless?values as value>
            {
            "path-name": "${value.name}",
            <#if value.hop != 0>
                "hop-limit" : ${value.hop},
            </#if>
            "bandwidth": ${value.bandwidth},
            <#if  value.includeAdminGroup.length != 0 >
                "include-admin-group" :{
                "group" : [
                <#list value.includeAdminGroup?values as includeVal>
                    "${includeVal}"<#if includeVal?has_next>,</#if>
                </#list>
                ]},
            </#if>
            <#if  value.excludeAdminGroup.length != 0 >
                "exclude-admin-group" :{
                "group" : [
                <#list value.excludeAdminGroup?values as excludeVal>
                    "${excludeVal}"<#if excludeVal?has_next>,</#if>
                </#list>
                ]},
            </#if>
            "priority" : {
                "setup-priority" : ${value.setupPriority},
                "hold-priority" : ${value.holdPriorioty}
            }
            }<#if value?has_next>,</#if>
        </#list>
    ],
    "secondary": [
    <#list extraParams.secondary?values as value>
        {
        "path-name": "${value.name}",
        <#if value.hop != 0>
            "hop-limit" : ${value.hop},
        </#if>
        "bandwidth": ${value.bandwidth},
        <#if  value.includeAdminGroup.length != 0 >
            "include-admin-group" :{
            "group" : [
            <#list value.includeAdminGroup?values as includeVal>
                "${includeVal}"<#if includeVal?has_next>,</#if>
            </#list>
            ]},
        </#if>
        <#if  value.excludeAdminGroup.length != 0 >
            "exclude-admin-group" :{
            "group" : [
            <#list value.excludeAdminGroup?values as excludeVal>
                "${excludeVal}"<#if excludeVal?has_next>,</#if>
            </#list>
            ]},
        </#if>
        "priority" : {
            "setup-priority" : ${value.setupPriority},
            "hold-priority" : ${value.holdPriorioty}
        },
        "standby" : ${value.isStandby?c},
        "srlg" : ${value.isSrlg?c}
        }<#if value?has_next>,</#if>
    </#list>
    ],
    <#if extraParams.primary?size != 0>
        <#list extraParams.primary?values as value>
            <#if value["conf"]["use-path-computation"] == true>
                "path-computation-method": "pce",
                "pce-report" : "true",
                "pce-control" : true
            <#else>
                "path-computation-method": "local-cspf"
             </#if>
        </#list>
    <#else>
        "path-computation-method": "local-cspf"
    </#if>
}
