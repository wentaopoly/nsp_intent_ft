var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpNetworkInterface()
{

    var util = new utilities();
    var mapFwk = new MapFwk();
    let nfmpFwk = new NfmpFwk();
    var parseTarget =  new ParseTarget();
    var interfaceIndex = 0;
    var savedObjects;
    var currentObjects;
    var isAudit = false;
    var savedTopology;
    var intentIpAddresses = {};
    var ipAddMap = {};
    var ipIndicesMap = {};
    var ipAddressIndex = 1;

    this.synchronize = function(input, result,intentTypeName,parentXpath, initialPropertyName,uniqueIdentifier)
    {
        isAudit = false;
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        var uniqueId = parseTarget.getUniqueIdentifier(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName];
        // code to handle delete
        if (input.getNetworkState().name() == "delete")
        {
            return this.syncDelete(input, intentConfig, result);
        }

        savedTopology = input.getCurrentTopology();
        savedObjects = {};
        currentObjects = {};
        ipAddMap = {};
        ipIndicesMap = {};
        intentIpAddresses = {};

        var interfaceConfig = intentConfig['interface'];
        if(interfaceConfig !== undefined)
        {
            if (interfaceConfig["ipv4"] && interfaceConfig["ipv4"]["secondary"])
            {
                if (!Array.isArray(interfaceConfig["ipv4"]["secondary"])) {
                    interfaceConfig["ipv4"]["secondary"] = [interfaceConfig["ipv4"]["secondary"]];
                }

                for (var index in interfaceConfig["ipv4"]["secondary"])
                {
                    var secondaryipv4AddConfig = interfaceConfig["ipv4"]["secondary"][index];
                    var ipAdd = secondaryipv4AddConfig["address"];
                    var ipPrefix = secondaryipv4AddConfig["prefix-length"];
                    intentIpAddresses[ipAdd+"/"+ipPrefix] = "ipv4"
                }
            }

            if (interfaceConfig["ipv6"] && interfaceConfig["ipv6"]["address"])
            {
                if (!Array.isArray(interfaceConfig["ipv6"]["address"])) {
                    interfaceConfig["ipv6"]["address"] = [interfaceConfig["ipv6"]["address"]];
                }
                for (var index in interfaceConfig["ipv6"]["address"])
                {
                    var ipv6AddConfig = interfaceConfig["ipv6"]["address"][index];
                    var ipAdd = ipv6AddConfig["ipv6-address"];
                    var ipPrefix = ipv6AddConfig["prefix-length"];
                    intentIpAddresses[util.expandIPv6Address(ipAdd)+"/"+ipPrefix] = "ipv6"
                }
            }
        }
        var searchPayLoad = this.constructSearchString(target, uniqueId);
        var searchResponse = nfmpFwk.find(target, searchPayLoad);

        logger.info(JSON.stringify(searchResponse));
        var objectFullName = "";
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            logger.info("There is no Network Interface with name :"+ uniqueId+ " exists on NE: " + target );
        }
        else
        {
            var finalResponse = JSON.parse(searchResponse['response']);
            objectFullName = finalResponse[0]['properties']['objectFullName'];
            if (target && String(target).indexOf(':') !== -1) {
                objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
            }
            interfaceIndex = finalResponse[0]['properties']['id'];
            var children = finalResponse[0]['children']

            for (var i = 0; i < children.length; i++) {
                var childConfig = children[i];
                var childClass = childConfig['fullClassName'];
                if (childClass !== null && childClass === 'rtr.VirtualRouterIpAddress') {
                    var ipAddressFullName = childConfig['properties']['objectFullName'];
                    if (target && String(target).indexOf(':') !== -1) {
                        ipAddressFullName = util.modifyNeIdForIpV6(ipAddressFullName, target);
                    }
                    var addressId = childConfig['properties']['index'];
                    var ipAddress = childConfig['properties']['ipAddress'];
                    var prefixLength = childConfig['properties']['prefixLength'];
                    if(intentIpAddresses[ipAddress+"/"+prefixLength] === undefined)
                    {
                        if(addressId !== "1")
                        {
                            logger.info("[NFMP-NETWORK-INTERFACE-FWK] syncDelete(): Deleting " + ipAddressFullName);
                            var deleteResult = nfmpFwk.deployDelete(ipAddressFullName, "application/json");

                            if (!deleteResult.success) {
                                logger.info("[NFMP-NETWORK-INTERFACE-FWK] syncDelete(): Unable to Delete: " + deleteResult.msg);
                                throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
                            }
                        }
                    }
                    else
                    {
                        ipAddMap[ipAddress+"/"+prefixLength] =  addressId;
                        ipIndicesMap[addressId] =  ipAddressFullName;
                        intentIpAddresses[ipAddress+"/"+prefixLength] = addressId;
                    }
                }
            }
        }

        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target Interface Name = " + uniqueId);

        this.createOrModify(target, uniqueId,objectFullName, intentConfig);
        result.setTopology(savedTopology);
        if (savedTopology)
        {
            result.getTopology().setXtraInfo(savedTopology.getXtraInfo());
        }

        return util.setSuccessResult(result, savedTopology);
    }

    this.createOrModify = function (target, uniqueIdentifier, objectFullName, intentConfig)
    {
        var networkInterfacePayLoad = this.createNetworkInterfacePayLoad(target, uniqueIdentifier, objectFullName, intentConfig["interface"]);

        var result = this.modifyRequest(target, networkInterfacePayLoad);

        if(result.success)
        {
            objectFullName = JSON.parse(result.response)[0]['properties']['objectFullName'];
            if (target && String(target).indexOf(':') !== -1) {
                objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
            }
            interfaceIndex = objectFullName.substring(objectFullName.lastIndexOf("-") + 1, objectFullName.length);

            var mplsInterfacePayload = this.createMplsInterfacePayload(target, intentConfig['mpls']);
            if(mplsInterfacePayload != undefined)
            {
                this.modifyRequest(target, mplsInterfacePayload);
            }

            var ospfInterfacePayload = this.createOspfInterfacePayload(target, intentConfig['ospf']);
            if(ospfInterfacePayload != undefined)
            {
                this.modifyRequest(target, ospfInterfacePayload);
            }

            var ospf3InterfacePayload = this.createOspf3InterfacePayload(target, intentConfig['ospf3']);
            if(ospf3InterfacePayload != undefined)
            {
                this.modifyRequest(target, ospf3InterfacePayload);
            }

            var ldpInterfacePayload = this.createLdpInterfacePayload(target, intentConfig['ldp']);
            if(ldpInterfacePayload != undefined)
            {
                this.modifyRequest(target, ldpInterfacePayload);
            }

            var isisInterfacePayload = this.createIsisInterfacePayload(target, intentConfig['isis']);
            if(isisInterfacePayload != undefined)
            {
                this.modifyRequest(target, isisInterfacePayload);
            }

            if(intentConfig['rsvp'])
            {
                var rsvpInterfacePayload = this.createRsvpInterfacePayload(target, intentConfig['rsvp']);
                if(rsvpInterfacePayload != undefined)
                {
                    this.modifyRequest(target, rsvpInterfacePayload);
                }
            }
        }
        return result;
    }

    this.modifyRequest = function (target, payload)
    {

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;

    }

    this.createNetworkInterfacePayLoad = function (target, uniqueIdentifier, objectFullName, intentConfig)
    {
        if (savedTopology == null)
        {
            logger.info("Creating topology to save interface details");
            savedTopology = topologyFactory.createServiceTopology();
        }
        var fullClassName = "rtr.NetworkInterface";

        var fdn = "network:" + target + ":router-1";
        if (target && String(target).indexOf(':') !== -1) {
            fdn = util.modifyNeIdForIpV6(fdn, target);
        }
        // objectFullName is same as fdn for port level
        if(objectFullName == "")
        {
            objectFullName = "network:" + target + ":router-1:ip-interface-" + uniqueIdentifier;
            if (target && String(target).indexOf(':') !== -1) {
                objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
            }
        }

        var properties = {};
        properties['displayedName'] = uniqueIdentifier;
        if(intentConfig)
        {
            properties['description'] = intentConfig['description'];
            if(intentConfig['ldp-sync-timer'])
            {
                if(intentConfig['ldp-sync-timer']['seconds'])
                {
                    properties['ldpSyncTimer'] = intentConfig['ldp-sync-timer']['seconds'];
                }
                else
                {
                    properties['ldpSyncTimer'] = 0;
                }
            }
            else
            {
                properties['ldpSyncTimer'] = 0;
            }
            if(intentConfig['admin-state'])
            {
                if(intentConfig['admin-state'] == 'enable')
                {
                    properties['administrativeState'] = 'vRtrIfUp';
                }
                if(intentConfig['admin-state'] == 'disable')
                {
                    properties['administrativeState'] = 'vRtrIfDown';
                }
            }
            if(intentConfig['cpu-protection'])
            {
                properties["dosProtection"] = "NE DoS Protection:"+intentConfig['cpu-protection'];
            }
            else
            {
                properties["dosProtection"] =  "NE DoS Protection:255";
            }

            if(intentConfig['port-binding'] == "loopback")
            {
                properties['loopbackEnabled'] = true;
            }
            else
            {
                properties['loopbackEnabled'] = false;

            }

            if(intentConfig['port-binding'] == "port" && intentConfig["port"])
            {
                var portOrLag = intentConfig["port"];
                if(portOrLag === parseInt(portOrLag, 10))
                {
                    properties['portPointer'] = util.getBaseFdnForLag(target, intentConfig["port"]);
                }
                else
                {
                    properties['portPointer'] = util.getBaseFdnForPort(target, intentConfig["port"]);
                }
                properties["innerEncapValue"] = intentConfig["inner-tag"];
                properties["outerEncapValue"] = intentConfig["outer-tag"];
            }
            else
            {
                properties['portPointer'] = "";
            }
        }

        var childProperties = [];

        if(intentConfig["ipv4"] && intentConfig["ipv4"]["primary"] && intentConfig["ipv4"]["primary"]["address"])
        {
            var primaryAddPayload = this.createIpAddressPayLoad(target, intentConfig);
            childProperties.push(primaryAddPayload);
        }

        if (intentConfig["ipv4"] && intentConfig["ipv4"]["secondary"])
        {
            if (!Array.isArray(intentConfig["ipv4"]["secondary"])) {
                intentConfig["ipv4"]["secondary"] = [intentConfig["ipv4"]["secondary"]];
            }

            for (var index in intentConfig["ipv4"]["secondary"])
            {
                var secondaryipv4AddConfig = intentConfig["ipv4"]["secondary"][index];
                var secondaryIpAddPayload = this.createSecondaryIpAddPayLoad(target, secondaryipv4AddConfig);
                childProperties.push(secondaryIpAddPayload);
            }
        }

        if (intentConfig["ipv6"] && intentConfig["ipv6"]["address"])
        {
            properties['ipv6Allowed'] = true;
            if (!Array.isArray(intentConfig["ipv6"]["address"])) {
                intentConfig["ipv6"]["address"] = [intentConfig["ipv6"]["address"]];
            }
            for (var index in intentConfig["ipv6"]["address"])
            {
                var ipv6AddConfig = intentConfig["ipv6"]["address"][index];
                var ipv6AddPayload = this.createIpv6AddressPayLoad(target, ipv6AddConfig);
                childProperties.push(ipv6AddPayload);
            }
        }

        if(intentConfig['egress'] && intentConfig['egress']["qos"])
        {
            if(intentConfig['egress']["qos"]["vlan-qos-policy"] && intentConfig['egress']["qos"]["vlan-qos-policy"]["policy-name"])
            {
                properties["egressVlanQosPolicyObjectPointer"] = "VlanQosPolicy7250SROS:" + intentConfig['egress']["qos"]["vlan-qos-policy"]["policy-name"];
            }
            else
            {
                properties["egressVlanQosPolicyObjectPointer"] = "VlanQosPolicy7250SROS:default";
            }

            if(intentConfig['egress']["qos"]["egress-remark-policy"] && intentConfig['egress']["qos"]["egress-remark-policy"]["policy-name"])
            {
                properties["egressRemarkPolicyObjectPointer"] = "EgressRemarkPolicy7250SROS:" + intentConfig['egress']["qos"]["egress-remark-policy"]["policy-name"];
            }
            else
            {
                properties["egressRemarkPolicyObjectPointer"] = "EgressRemarkPolicy7250SROS:default";
            }
        }

        if(intentConfig['ingress'] && intentConfig['ingress']["qos"])
        {
            if(intentConfig['ingress']["qos"]["network-ingress"] && intentConfig['ingress']["qos"]["network-ingress"]["policy-name"])
            {
                properties["networkIngressPolicyObjectPointer"] = "NetworkIngressPolicy7250SROS:" + intentConfig['ingress']["qos"]["network-ingress"]["policy-name"];
            }
            else
            {
                properties["networkIngressPolicyObjectPointer"] = "NetworkIngressPolicy7250SROS:default";
            }
        }

        if(intentConfig["qos"] && intentConfig["qos"]["network-policy"])
        {
            properties["networkPolicyObjectPointer"] = "Network:"+ intentConfig["qos"]["network-policy"];
        }
        else
        {
            properties["networkPolicyObjectPointer"] = "Network:1";
        }


        var bfdPaylod = this.createBfdPayLoad(target, intentConfig);
        if(bfdPaylod != undefined)
        {
            childProperties.push(bfdPaylod);
        }

        var bfdV6Paylod = this.createBfdV6PayLoad(target, intentConfig);

        if(bfdV6Paylod != undefined)
        {
            childProperties.push(bfdV6Paylod);
        }

        var networkInterfacePayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
        return networkInterfacePayload;
    }

    this.createOspfInterfacePayload = function (target, ospfConfig)
    {

        if(ospfConfig && ospfConfig['area'] && ospfConfig['area']['interface'])
        {
            var fullClassName = "ospf.Interface";

            var fdn = "network:" + target + ":router-1:ospf-v2";
            if (target && String(target).indexOf(':') !== -1) {
                fdn = util.modifyNeIdForIpV6(fdn, target);
            }
            if(ospfConfig['ospf-instance'] == 0)
            {
                fdn = fdn + ":areaSite-"+ospfConfig['area']['area-id'];
            }
            else
            {
                fdn = fdn + "-instance-"+ospfConfig['ospf-instance'] + ":areaSite-"+ospfConfig['area']['area-id'];
            }

            // objectFullName is same as fdn for port level

            var objectFullName = fdn+":interface-"+interfaceIndex;
            var properties = {};
            var childProperties = [];
            properties['interfaceId'] = interfaceIndex;

            if(ospfConfig['area']['interface']['admin-state'] == "enable")
            {
                properties['administrativeState'] = "ospfInterfaceEnabled";
            }
            else
            {
                properties['administrativeState'] = "ospfInterfaceDisabled";
            }
            properties['metric'] = ospfConfig['area']['interface']['metric'];
            properties['mtu'] = ospfConfig['area']['interface']['mtu'];
            properties['helloInterval'] = ospfConfig['area']['interface']['hello-interval'];
            properties['routerDeadInterval'] = ospfConfig['area']['interface']['dead-interval'];

            if(interfaceIndex == 1 && isAudit === false)
            {
                properties['isPassive'] = true;
            }

            var interfaceType = ospfConfig['area']['interface']['interface-type']
            if(interfaceType == "point-to-point")
            {
                properties['interfaceType'] =  "pointToPoint";
            }
            else if(interfaceType == "non-broadcast")
            {
                properties['interfaceType'] =  "nbma";
            }
            else
            {
                properties['interfaceType'] =  interfaceType;
            }
            this.removeInterfaceObjectIfModified("ospfInterface", objectFullName)
            savedTopology.addXtraInfo(topologyFactory.createTopologyXtraInfoFrom("ospfInterface", objectFullName));

            var ospfInterfacePayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
            return ospfInterfacePayload;
        }
        else
        {
            if(isAudit === false)
            {
                this.removeInterfaceObject("ospfInterface");
            }
            return undefined;
        }


    }

    this.createOspf3InterfacePayload = function (target, ospf3Config)
    {
        if(ospf3Config && ospf3Config['area'] && ospf3Config['area']['interface'])
        {
            var fullClassName = "ospf.Interface";

            var fdn = "network:" + target + ":router-1:ospf-v3";
            if (target && String(target).indexOf(':') !== -1) {
                fdn = util.modifyNeIdForIpV6(fdn, target);
            }
            if(ospf3Config['ospf-instance'] == 0)
            {
                fdn = fdn + ":areaSite-"+ospf3Config['area']['area-id'];
            }
            else
            {
                fdn = fdn + "-instance-"+ospf3Config['ospf-instance'] + ":areaSite-"+ospf3Config['area']['area-id'];
            }

            // objectFullName is same as fdn for port level

            var objectFullName = fdn+":interface-"+interfaceIndex;

            var properties = {};
            var childProperties = [];
            properties['interfaceId'] = interfaceIndex;

            if(ospf3Config['area']['interface']['admin-state'] == "enable")
            {
                properties['administrativeState'] = "ospfInterfaceEnabled";
            }
            else
            {
                properties['administrativeState'] = "ospfInterfaceDisabled";
            }

            properties['metric'] = ospf3Config['area']['interface']['metric'];
            properties['mtu'] = ospf3Config['area']['interface']['mtu'];
            properties['helloInterval'] = ospf3Config['area']['interface']['hello-interval'];
            properties['routerDeadInterval'] = ospf3Config['area']['interface']['dead-interval'];
            var interfaceType = ospf3Config['area']['interface']['interface-type']
            if(interfaceIndex == 1 && isAudit === false)
            {
                properties['isPassive'] = true;
            }

            if(interfaceType == "point-to-point")
            {
                properties['interfaceType'] =  "pointToPoint";
            }
            else if(interfaceType == "non-broadcast")
            {
                properties['interfaceType'] =  "nbma";
            }
            else
            {
                properties['interfaceType'] =  interfaceType;
            }

            this.removeInterfaceObjectIfModified("ospf3Interface", objectFullName);
            savedTopology.addXtraInfo(topologyFactory.createTopologyXtraInfoFrom("ospf3Interface", objectFullName));

            var ospf3InterfacePayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
            return ospf3InterfacePayload;
        }
        else
        {
            if(isAudit === false)
            {
                this.removeInterfaceObject("ospf3Interface");
            }
            return undefined;
        }

    }

    this.createLdpInterfacePayload = function (target, ldpConfig)
    {
        if(ldpConfig && ldpConfig['interface-parameters'] && ldpConfig['interface-parameters']['interface'])
        {
            var fullClassName = "ldp.Interface";

            var fdn = "network:" + target + ":router-1:ldp";
            if (target && String(target).indexOf(':') !== -1) {
                fdn = util.modifyNeIdForIpV6(fdn, target);
            }
            var objectFullName = fdn+":Interface-"+interfaceIndex;
            var properties = {};
            properties['interfaceId'] = interfaceIndex;

            if(ldpConfig['interface-parameters']['interface']['admin-state'] == "enable")
            {
                properties['administrativeState'] = "tmnxInService";
            }
            else
            {
                properties['administrativeState'] = "tmnxOutOfService";
            }

            savedTopology.addXtraInfo(topologyFactory.createTopologyXtraInfoFrom("ldpInterface", objectFullName));
            var ldpInterfacePayload = util.editPayload(fdn, properties, undefined, fullClassName, objectFullName);
            return ldpInterfacePayload;

        }

        else
        {
            if(isAudit === false)
            {
                this.removeInterfaceObject("ldpInterface");
            }
            return undefined;
        }
    }

    this.createMplsInterfacePayload = function (target, mplsConfig)
    {
        if(mplsConfig && mplsConfig['interface'])
        {
            var fullClassName = "mpls.Interface";

            var fdn = "network:" + target + ":router-1:mpls";
            if (target && String(target).indexOf(':') !== -1) {
                fdn = util.modifyNeIdForIpV6(fdn, target);
            }
            var objectFullName = fdn+":interface-"+interfaceIndex;
            var properties = {};
            properties['interfaceId'] = interfaceIndex;

            if(mplsConfig['interface']['admin-state'] == "enable")
            {
                properties['administrativeState'] = "mplsUp";
            }
            else
            {
                properties['administrativeState'] = "mplsDown";
            }

            savedTopology.addXtraInfo(topologyFactory.createTopologyXtraInfoFrom("mplsInterface", objectFullName));
            var mplsInterfacePayload = util.editPayload(fdn, properties, undefined, fullClassName, objectFullName);
            return mplsInterfacePayload;
        }
        else
        {
            if(isAudit === false)
            {
                this.removeInterfaceObject("mplsInterface")
            }
            return undefined;
        }
    }

    this.createRsvpInterfacePayload = function (target, rsvpConfig)
    {
        if(rsvpConfig && rsvpConfig["interface"])
        {
            var fullClassName = "rsvp.Interface";

            var fdn = "network:" + target + ":router-1:rsvp";
            if (target && String(target).indexOf(':') !== -1) {
                fdn = util.modifyNeIdForIpV6(fdn, target);
            }
            var objectFullName = fdn+":interface-"+interfaceIndex;
            var properties = {};
            properties['interfaceId'] = interfaceIndex;
            if(rsvpConfig != undefined)
            {
                if(rsvpConfig['interface']['admin-state'] == "enable")
                {
                    properties['administrativeState'] = "rsvpIfUp";
                }
                else
                {
                    properties['administrativeState'] = "rsvpIfDown";
                }

                if(rsvpConfig['interface']['bfd-liveness'])
                {
                    properties['bfdEnabled'] = true;
                }
                else
                {
                    properties['bfdEnabled'] = false;
                }

                if(rsvpConfig['interface']['hello-interval'])
                {
                    properties['helloInterval'] = rsvpConfig['interface']['hello-interval']+"000";
                }

                if(rsvpConfig['interface']['refresh-reduction'])
                {
                    properties['enableRefreshReduction'] = true;
                    if(rsvpConfig['interface']['refresh-reduction']['reliable-delivery'])
                    {
                        properties['enableReliableDelivery'] = true;
                    }
                    else
                    {
                        properties['enableReliableDelivery'] = false;
                    }
                }
                else
                {
                    properties['enableRefreshReduction'] = false;
                    properties['enableReliableDelivery'] = false;
                }
            }
            else
            {
                return undefined;
            }

            var rsvpInterfacePayload = util.editPayload(fdn, properties, undefined, fullClassName, objectFullName);
            return rsvpInterfacePayload;
        }
        else
        {
            return undefined;
        }
    }

    this.createIsisInterfacePayload = function (target, isisConfig)
    {
        if(isisConfig && isisConfig['interface'])
        {
            var fullClassName = "isis.Interface";

            var fdn = "network:" + target + ":router-1:isis";
            if (target && String(target).indexOf(':') !== -1) {
                fdn = util.modifyNeIdForIpV6(fdn, target);
            }
            if(isisConfig['isis-instance'] != 0)
            {
                fdn = fdn+ "-" +isisConfig['isis-instance'];
            }

            var objectFullName = fdn+":interface-"+interfaceIndex;
            var properties = {};
            var childProperties = [];
            properties['interfaceId'] = interfaceIndex;

            if(isisConfig['interface']['admin-state'] == "enable")
            {
                properties['administrativeState'] = "isisUp";
            }
            else
            {
                properties['administrativeState'] = "isisDown";
            }

            if(isisConfig['interface']['level-capability'] == "1")
            {
                properties['levelCapability'] = "level_1";
            }
            else if(isisConfig['interface']['level-capability'] == "2")
            {
                properties['levelCapability'] = "level_2";
            }
            else if(isisConfig['interface']['level-capability'] == "1/2")
            {
                properties['levelCapability'] = "level_1_and_2";
            }

            if(isisConfig['interface']['interface-type'] == "point-to-point")
            {
                properties['interfaceType'] = "point_to_point";
            }
            else if(isisConfig['interface']['interface-type'] == "broadcast")
            {
                properties['interfaceType'] = "broadcast";
            }

            if(isisConfig['interface']['csnp-interval'])
            {
                properties['csnpInterval'] = isisConfig['interface']['csnp-interval'];
            }

            if(isisConfig['interface']['bfd-liveness'])
            {
                if(isisConfig['interface']['bfd-liveness']['ipv4'])
                {
                    properties['bfdEnabled'] = true;
                    if(isisConfig['interface']['bfd-liveness']['ipv4']['include-bfd-tlv'])
                    {
                        properties['ipv4IncludeBfdTlv'] = true;
                    }
                    else
                    {
                        properties['ipv4IncludeBfdTlv'] = false;
                    }
                }
                else
                {
                    properties['bfdEnabled'] = false;
                    properties['ipv4IncludeBfdTlv'] = false;
                }

                if(isisConfig['interface']['bfd-liveness']['ipv6'])
                {
                    properties['ipv6BfdEnabled'] = true;
                    if(isisConfig['interface']['bfd-liveness']['ipv6']['include-bfd-tlv'])
                    {
                        properties['ipv6IncludeBfdTlv'] = true;
                    }
                    else
                    {
                        properties['ipv6IncludeBfdTlv'] = false;
                    }
                }
                else
                {
                    properties['ipv6BfdEnabled'] = false;
                    properties['ipv6IncludeBfdTlv'] = false;
                }
            }
            else
            {
                properties['bfdEnabled'] = false;
                properties['ipv4IncludeBfdTlv'] = false;
                properties['ipv6BfdEnabled'] = false;
                properties['ipv6IncludeBfdTlv'] = false;
            }

            var authenticationPayLoad = this.createAuthenticationPayLoad(target, isisConfig['interface']);
            if(authenticationPayLoad != undefined && isAudit == false)
            {
                childProperties.push(authenticationPayLoad);
            }
            var level1PayLoad = this.createLevel1PayLoad(target, isisConfig['interface']['level']);
            if(level1PayLoad != undefined)
            {
                childProperties.push(level1PayLoad);
            }
            var level2PayLoad = this.createLevel2PayLoad(target, isisConfig['interface']['level']);
            if(level2PayLoad != undefined)
            {
                childProperties.push(level2PayLoad);
            }

            this.removeInterfaceObjectIfModified("isisInterface", objectFullName)
            savedTopology.addXtraInfo(topologyFactory.createTopologyXtraInfoFrom("isisInterface", objectFullName));

            var isisInterfacePayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
            return isisInterfacePayload;
        }
        else
        {
            if(isAudit === false)
            {
                this.removeInterfaceObject("isisInterface");
            }
            return undefined;
        }
    }

    this.createAuthenticationPayLoad = function (target, intentConfig) {

        var fullClassName = "isis.AuthenticationKey";
        var properties = {};
        if (intentConfig["hello-authentication-type"] == "password")
        {
            properties["type"] = 'password';
        }
        else if(intentConfig["hello-authentication-type"] == "message-digest")
        {
            properties["type"] = 'md5';
        }
        else
        {
            properties["type"] = 'none';
        }

        if(intentConfig["hello-authentication-key"])
        {
            properties["key"] = intentConfig["hello-authentication-key"];
        }
        return this.createChildObjectPayload(fullClassName, properties);
    }

    this.createLevel1PayLoad = function (target, levelConfig) {

        var fullClassName = "isis.InterfaceLevelOneConfig";
        var properties = {};

        if (levelConfig)
        {
            if(!Array.isArray(levelConfig))
            {
                levelConfig = [levelConfig];
            }
            for(var index in levelConfig)
            {
                var level1Config = levelConfig[index];
                if(level1Config['level-number'] == "1")
                {
                    properties['adminMetric'] = level1Config['metric'];
                }
            }
        }
        if(properties['adminMetric'] == null)
        {
            properties['adminMetric'] = 0;
            if(isAudit == true)
            {
                return undefined;
            }
        }
        return this.createChildObjectPayload(fullClassName, properties);
    }

    this.createLevel2PayLoad = function (target, levelConfig) {

        var fullClassName = "isis.InterfaceLevelTwoConfig";
        var properties = {};

        if (levelConfig)
        {
            if(!Array.isArray(levelConfig))
            {
                levelConfig = [levelConfig];
            }
            for(var index in levelConfig)
            {
                var level2Config = levelConfig[index];
                if(level2Config['level-number'] == "2")
                {
                    properties['adminMetric'] = level2Config['metric'];
                }
            }
        }
        if(properties['adminMetric'] == null)
        {
            properties['adminMetric'] = 0;
            if(isAudit == true)
            {
                return undefined;
            }
        }

        return this.createChildObjectPayload(fullClassName, properties);
    }


    this.createIpAddressPayLoad = function (target, intentConfig) {

        var fullClassName = "rtr.VirtualRouterIpAddress";
        var properties = {};
        if (intentConfig["ipv4"] && intentConfig["ipv4"]["primary"])
        {
            properties["ipAddress"] = intentConfig["ipv4"]["primary"]["address"];
            properties["prefixLength"] = intentConfig["ipv4"]["primary"]["prefix-length"];
            properties["ipAddressType"] = "ipv4";
            properties["index"] = 1;
        }
        return this.createChildObjectPayload(fullClassName, properties);
    }

    this.createSecondaryIpAddPayLoad = function (target, secondaryipv4AddConfig) {

        var fullClassName = "rtr.VirtualRouterIpAddress";
        var properties = {};
        if (secondaryipv4AddConfig)
        {
            properties["ipAddress"] = secondaryipv4AddConfig["address"];
            properties["prefixLength"] = secondaryipv4AddConfig["prefix-length"];
            properties["ipAddressType"] = "ipv4";
            ipAddressIndex = ipAddressIndex+1;
            if(ipAddMap[properties["ipAddress"] + "/" + properties["prefixLength"]] === undefined)
            {
                while(ipIndicesMap[ipAddressIndex.toString()])
                {
                    ipAddressIndex = ipAddressIndex + 1;
                }
                properties["index"] = ipAddressIndex;
            }
            else
            {
                properties["index"] = ipAddMap[properties["ipAddress"] + "/" + properties["prefixLength"]];
            }

        }
        return this.createChildObjectPayload(fullClassName, properties);
    }

    this.createIpv6AddressPayLoad = function (target, ipv6AddrConfig) {

        var fullClassName = "rtr.VirtualRouterIpAddress";
        var properties = {};
        if (ipv6AddrConfig)
        {
            properties["ipAddress"] = util.expandIPv6Address(ipv6AddrConfig["ipv6-address"]);
            properties["ipAddressType"] = "ipv6";
            properties["prefixLength"] = ipv6AddrConfig["prefix-length"];
            ipAddressIndex = ipAddressIndex+1;
            if(ipAddMap[properties["ipAddress"] + "/" + properties["prefixLength"]] === undefined)
            {
                while(ipIndicesMap[ipAddressIndex.toString()])
                {
                    ipAddressIndex = ipAddressIndex + 1;
                }
                properties["index"] = ipAddressIndex;
            }
            else
            {
                properties["index"] = ipAddMap[properties["ipAddress"] + "/" + properties["prefixLength"]];
            }
        }
        return this.createChildObjectPayload(fullClassName, properties);
    }

    this.createBfdPayLoad = function (target, intentConfig)
    {
        var fullClassName = "bfd.BfdConfig";
        var properties = {};
        if (intentConfig["ipv4"] && intentConfig["ipv4"]["bfd"])
        {
            properties["bfdRxInterval"] = intentConfig["ipv4"]["bfd"]["receive"];
            properties["bfdTxInterval"] = intentConfig["ipv4"]["bfd"]["transmit-interval"];
            if(intentConfig["ipv4"]["bfd"]["admin-state"] == "enable")
            {
                properties["adminStatus"] = "up";
            }
            else
            {
                properties["adminStatus"] = "down";
            }
            properties["bfdMultiplier"] = intentConfig["ipv4"]["bfd"]["multiplier"];

            if(intentConfig["ipv4"]["bfd"]["type"] == "cpm-np")
            {
                properties["bfdTermType"] = "cpmNP";
            }
            else
            {
                properties["bfdTermType"] = intentConfig["ipv4"]["bfd"]["type"];
            }
            properties["ipAddressType"] = "ipv4";
            properties["creationOrigin"] = "manual";
        }
        else
        {
            if(isAudit == true)
            {
                return undefined;
            }
        }

        return this.createChildObjectPayload(fullClassName, properties);

    }

    this.createBfdV6PayLoad = function (target, intentConfig)
    {
        var fullClassName = "bfd.BfdV6Config";
        var properties = {};
        if (intentConfig["ipv6"] && intentConfig["ipv6"]["bfd"])
        {
            properties["bfdRxInterval"] = intentConfig["ipv6"]["bfd"]["receive"];
            properties["bfdTxInterval"] = intentConfig["ipv6"]["bfd"]["transmit-interval"];
            if(intentConfig["ipv6"]["bfd"]["admin-state"] == "enable")
            {
                properties["adminStatus"] = "up";
            }
            else
            {
                properties["adminStatus"] = "down";
            }
            properties["bfdMultiplier"] = intentConfig["ipv6"]["bfd"]["multiplier"];

            if(intentConfig["ipv6"]["bfd"]["type"] == "cpm-np")
            {
                properties["bfdTermType"] = "cpmNP";
            }
            else
            {
                properties["bfdTermType"] = intentConfig["ipv6"]["bfd"]["type"];
            }
            properties["ipAddressType"] = "ipv6";
            properties["creationOrigin"] = "manual";
        }
        else
        {
            if(isAudit == true)
            {
                return undefined;
            }
        }

        return this.createChildObjectPayload(fullClassName, properties);

    }

    this.createChildObjectPayload = function (fullClassName, properties) {

        var childObjectPayLoad = {};
        childObjectPayLoad['objectClassName'] = fullClassName;
        childObjectPayLoad['containedClassProperties'] = properties;
        return childObjectPayLoad;

    }

    this.audit = function(target, config, svcTopo, adminState, auditReport,intentTypeName,parentXpath, initialPropertyName,uniqueIdentifier)
    {
        // code to handle audit
        var savedTopology = svcTopo;
        savedObjects = {};
        currentObjects = {};
        isAudit = true;
        ipAddMap = {};
        ipIndicesMap = {};
        intentIpAddresses = {};
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName];
        // Ethernet Segment Name is part of the target-component
        var uniqueId = parseTarget.getUniqueIdentifier(target);
        var target = parseTarget.getNeIdFromTarget(target);

        var interfaceConfig = intentConfig['interface'];
        if(interfaceConfig !== undefined)
        {
            if (interfaceConfig["ipv4"] && interfaceConfig["ipv4"]["secondary"])
            {
                if (!Array.isArray(interfaceConfig["ipv4"]["secondary"])) {
                    interfaceConfig["ipv4"]["secondary"] = [interfaceConfig["ipv4"]["secondary"]];
                }

                for (var index in interfaceConfig["ipv4"]["secondary"])
                {
                    var secondaryipv4AddConfig = interfaceConfig["ipv4"]["secondary"][index];
                    var ipAdd = secondaryipv4AddConfig["address"];
                    var ipPrefix = secondaryipv4AddConfig["prefix-length"];
                    intentIpAddresses[ipAdd+"/"+ipPrefix] = "ipv4"
                }
            }

            if (interfaceConfig["ipv6"] && interfaceConfig["ipv6"]["address"])
            {
                if (!Array.isArray(interfaceConfig["ipv6"]["address"])) {
                    interfaceConfig["ipv6"]["address"] = [interfaceConfig["ipv6"]["address"]];
                }
                for (var index in interfaceConfig["ipv6"]["address"])
                {
                    var ipv6AddConfig = interfaceConfig["ipv6"]["address"][index];
                    var ipAdd = ipv6AddConfig["ipv6-address"];
                    var ipPrefix = ipv6AddConfig["prefix-length"];
                    intentIpAddresses[util.expandIPv6Address(ipAdd)+"/"+ipPrefix] = "ipv6"
                }
            }
        }

        var searchPayLoad = this.constructSearchString(target, uniqueId);
        var searchResponse = nfmpFwk.find(target, searchPayLoad);

        logger.info(JSON.stringify(searchResponse));
        var objectFullName = "";
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            logger.info("There is no Network Interface with name :"+ uniqueId+ " exists on NE: " + target );
            throw "configuration not available in the NE";
        }
        else
        {
            var finalResponse = JSON.parse(searchResponse['response']);
            objectFullName = finalResponse[0]['properties']['objectFullName'];
            if (target && String(target).indexOf(':') !== -1) {
                objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
            }
            interfaceIndex = finalResponse[0]['properties']['id'];
            var children = finalResponse[0]['children']

            for (var i = 0; i < children.length; i++) {
                var childConfig = children[i];
                var childClass = childConfig['fullClassName'];
                if (childClass !== null && childClass === 'rtr.VirtualRouterIpAddress') {
                    var ipAddressFullName = childConfig['properties']['objectFullName'];
                    if (target && String(target).indexOf(':') !== -1) {
                        ipAddressFullName = util.modifyNeIdForIpV6(ipAddressFullName, target);
                    }
                    var addressId = childConfig['properties']['index'];
                    var ipAddress = childConfig['properties']['ipAddress'];
                    var prefixLength = childConfig['properties']['prefixLength'];
                    if(intentIpAddresses[ipAddress+"/"+prefixLength] !== undefined)
                    {
                        ipAddMap[ipAddress+"/"+prefixLength] =  addressId;
                        ipIndicesMap[addressId] =  ipAddressFullName;
                        intentIpAddresses[ipAddress+"/"+prefixLength] = addressId;
                    }
                }
            }
        }

        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target network interface name = " + uniqueId);


        if (intentConfig)
        {
            this.auditAndCompare(target, uniqueId, intentConfig, objectFullName,  auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }

        return auditReport
    }

    this.auditAndCompare = function (target, uniqueIdentifier, intentConfig, objectFullName,  auditReport)
    {
        var networkInterfacePayLoad = this.createNetworkInterfacePayLoad(target, uniqueIdentifier, objectFullName, intentConfig["interface"]);
        var result = this.auditRequest(target, networkInterfacePayLoad);
        auditReport = util.reportMisaligned(target, result, auditReport);

        if(intentConfig["ospf"])
        {
            var ospfInterfacePayLoad = this.createOspfInterfacePayload(target, intentConfig["ospf"]);
            if(ospfInterfacePayLoad !== undefined)
            {
                var ospfInterfaceFullName = ospfInterfacePayLoad['objectFullName'];
                if (target && String(target).indexOf(':') !== -1) {
                    ospfInterfaceFullName = util.modifyNeIdForIpV6(ospfInterfaceFullName, target);
                }
                var ospfSearchPayload = this.constructInterfaceSearchString(ospfInterfaceFullName, "ospf.Interface")
                var searchResponse = nfmpFwk.find(target, ospfSearchPayload);

                if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
                {
                    logger.info("There is no OSPF Interface with name :"+ ospfInterfaceFullName+ " exists on NE: " + target );
                    var misalignedObject = auditFactory.createMisAlignedObject(ospfInterfaceFullName, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    var ospfresult = this.auditRequest(target, ospfInterfacePayLoad);
                    auditReport = util.reportMisaligned(target, ospfresult, auditReport);
                }
            }
        }

        if(intentConfig["ospf3"])
        {
            var ospf3InterfacePayLoad = this.createOspf3InterfacePayload(target, intentConfig["ospf3"]);
            if(ospf3InterfacePayLoad !== undefined)
            {
                var ospf3InterfaceFullName = ospf3InterfacePayLoad['objectFullName'];
                if (target && String(target).indexOf(':') !== -1) {
                    ospf3InterfaceFullName = util.modifyNeIdForIpV6(ospf3InterfaceFullName, target);
                }
                var ospf3SearchPayload = this.constructInterfaceSearchString(ospf3InterfaceFullName, "ospf.Interface")
                var searchResponse = nfmpFwk.find(target, ospf3SearchPayload);

                if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
                {
                    logger.info("There is no OSPF3 Interface with name :"+ ospf3InterfaceFullName+ " exists on NE: " + target );
                    var misalignedObject = auditFactory.createMisAlignedObject(ospf3InterfaceFullName, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    var ospf3Result = this.auditRequest(target, ospf3InterfacePayLoad);
                    auditReport = util.reportMisaligned(target, ospf3Result, auditReport);
                }
            }
        }

        var ldpInterfacePayLoad = this.createLdpInterfacePayload(target, intentConfig['ldp']);
        if(ldpInterfacePayLoad !== undefined)
        {
            var ldpInterfaceFullName = ldpInterfacePayLoad['objectFullName'];
            if (target && String(target).indexOf(':') !== -1) {
                ldpInterfaceFullName = util.modifyNeIdForIpV6(ldpInterfaceFullName, target);
            }
            var ldpSearchPayload = this.constructInterfaceSearchString(ldpInterfaceFullName, "ldp.Interface")
            var searchResponse = nfmpFwk.find(target, ldpSearchPayload);

            if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
            {
                logger.info("There is no LDP Interface with name :"+ ldpInterfaceFullName+ " exists on NE: " + target );
                var misalignedObject = auditFactory.createMisAlignedObject(ldpInterfaceFullName, false);
                auditReport.addMisAlignedObject(misalignedObject);
            }
            else
            {
                var ldpResult = this.auditRequest(target, ldpInterfacePayLoad);
                auditReport = util.reportMisaligned(target, ldpResult, auditReport);
            }
        }

        var mplsInterfacePayLoad = this.createMplsInterfacePayload(target, intentConfig['mpls']);

        if(mplsInterfacePayLoad !== undefined)
        {
            var mplsInterfaceFullName = mplsInterfacePayLoad['objectFullName'];
            if (target && String(target).indexOf(':') !== -1) {
                mplsInterfaceFullName = util.modifyNeIdForIpV6(mplsInterfaceFullName, target);
            }
            var mplsSearchPayload = this.constructInterfaceSearchString(mplsInterfaceFullName, "mpls.Interface")
            var searchResponse = nfmpFwk.find(target, mplsSearchPayload);

            if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
            {
                logger.info("There is no MPLS Interface with name :"+ mplsInterfaceFullName+ " exists on NE: " + target );
                var misalignedObject = auditFactory.createMisAlignedObject(mplsInterfaceFullName, false);
                auditReport.addMisAlignedObject(misalignedObject);
            }
            else
            {
                var mplsResult = this.auditRequest(target, mplsInterfacePayLoad);
                auditReport = util.reportMisaligned(target, mplsResult, auditReport);
            }
        }

        var rsvpInterfacePayLoad = this.createRsvpInterfacePayload(target, intentConfig['rsvp']);

        if(rsvpInterfacePayLoad !== undefined)
        {
            var rsvpInterfaceFullName = rsvpInterfacePayLoad['objectFullName'];
            if (target && String(target).indexOf(':') !== -1) {
                rsvpInterfaceFullName = util.modifyNeIdForIpV6(rsvpInterfaceFullName, target);
            }
            var rsvpSearchPayload = this.constructInterfaceSearchString(rsvpInterfaceFullName, "rsvp.Interface")
            var searchResponse = nfmpFwk.find(target, rsvpSearchPayload);

            if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
            {
                logger.info("There is no RSVP Interface with name :"+ rsvpInterfaceFullName+ " exists on NE: " + target );
                var misalignedObject = auditFactory.createMisAlignedObject(rsvpInterfaceFullName, false);
                auditReport.addMisAlignedObject(misalignedObject);
            }
            else
            {
                var ldpResult = this.auditRequest(target, rsvpInterfacePayLoad);
                auditReport = util.reportMisaligned(target, ldpResult, auditReport);
            }
        }

        var isisInterfacePayload = this.createIsisInterfacePayload(target, intentConfig['isis']);

        if(isisInterfacePayload !== undefined)
        {
            var isisInterfaceFullName = isisInterfacePayload['objectFullName'];
            if (target && String(target).indexOf(':') !== -1) {
                isisInterfaceFullName = util.modifyNeIdForIpV6(isisInterfaceFullName, target);
            }
            var isisSearchPayload = this.constructInterfaceSearchString(isisInterfaceFullName, "isis.Interface")
            var searchResponse = nfmpFwk.find(target, isisSearchPayload);

            if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
            {
                logger.info("There is no ISIS Interface with name :"+ isisInterfaceFullName+ " exists on NE: " + target );
                var misalignedObject = auditFactory.createMisAlignedObject(isisInterfaceFullName, false);
                auditReport.addMisAlignedObject(misalignedObject);
            }
            else
            {
                var isisResult = this.auditRequest(target, isisInterfacePayload);
                auditReport = util.reportMisaligned(target, isisResult, auditReport);
            }
        }


        return auditReport;
    }

    this.auditRequest = function (target, payload)
    {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.syncDelete = function (input, intentConfig,  result)
    {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var uniqueId = parseTarget.getUniqueIdentifier(input.getTarget());
        var searchPayLoad = this.constructSearchString(neId, uniqueId);
        var searchResponse = nfmpFwk.find(neId, searchPayLoad);

        logger.info(JSON.stringify(searchResponse));
        var objectFullName = "";
        var interfaceIndex = 0;
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            logger.info("There is no Network Interface with name :"+ uniqueId+ " exists on NE: " + target );
            throw "configuration not available in the NE";
        }
        else
        {
            var finalResponse = JSON.parse(searchResponse['response']);
            objectFullName = finalResponse[0]['properties']['objectFullName'];
            if (neId && String(neId).indexOf(':') !== -1) {
                objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
            }
            interfaceIndex = finalResponse[0]['properties']['id'];
        }

        logger.info("Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
        return result;
    }

    this.xml2object = function (xmlElement)
    {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }

    this.loadSavedObjectsFromTopology = function (savedTopology)
    {
        if (savedTopology)
        {
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0)
            {
                topoObjects.forEach(function (topoObject)
                {
                    mapFwk.set(savedObjects, topoObject.getObjectType(), topoObject.getObjectRelativeObjectID());
                });
            }
        }
    }

    this.deleteRemovedObjects = function (target)
    {
        if (Object.keys(savedObjects).length > 0)
        {
            for (var key in savedObjects)
            {
                var value = mapFwk.get(currentObjects, key);
                if (value == undefined || value == "undefined" || value == null)
                {
                    logger.info("To be Deleted " + key);
                    var objectFullName = key;
                    if (target && String(target).indexOf(':') !== -1) {
                        objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
                    }
                    var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

                    if (!deleteResult.success) {
                        throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
                    }
                }
            }
        }
    }

    this.loadCurrentObjectsToTopology = function (target)
    {
        var currentTopo = topologyFactory.createServiceTopology();
        if (Object.keys(currentObjects).length)
        {
            for (var key in currentObjects)
            {
                objectId = mapFwk.get(currentObjects, key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key, objectId, "INFRASTRUCTURE", target, ""));
            }
        }
        return currentTopo;
    }

    this.removeEmptyContainers = function (prop, intentJson, path, target)
    {
        if (Array.isArray(intentJson))
        {
            var object = [];
            for (var prop in intentJson)
            {
                var value = this.removeEmptyContainers(prop, intentJson[prop], path, target);
                if (value)
                {
                    object.push(value);
                }

            }
            if (Object.keys(object).length !== 0)
            {
                return object;
            }
        }
        else if (typeof intentJson == 'object')
        {
            var object = {};
            for (var prop in intentJson)
            {
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop, intentJson[prop], pPath, target);
                if ((value && value !== null) || value == 0)
                {
                    object[prop] = value;
                }
            }
            if (Object.keys(object).length !== 0)
            {
                return object;
            }
        }
        else
        {
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if (intentJson !== undefined && intentJson !== "")
            {
                return intentJson;
            }
            return null;
        }
    }

    this.constructSearchString = function(neId, interfaceName)
    {
        var filterExpression = "nodeId='" + neId + "' AND routerId=1 AND displayedName='" +interfaceName+ "'";
        var jsonPayLoad = {
            "fullClassName": "rtr.NetworkInterface",
            "filter": {
                "filterExpression": filterExpression
            }
        };

        return jsonPayLoad;
    }

    this.constructInterfaceSearchString = function(interfaceFullName, interfaceClass)
    {
        var filterExpression = "routerId=1 AND fullName='" +interfaceFullName+ "'";
        var jsonPayLoad = {
            "fullClassName": interfaceClass,
            "filter": {
                "filterExpression": filterExpression
            }
        };

        return jsonPayLoad;
    }

    this.removeInterfaceObjectIfModified = function (key, value) {
        savedTopology.getXtraInfo().forEach(function (xtraInfo, index) {
            if (xtraInfo.getKey() === key && xtraInfo.getValue() !== value)
            {
                var deleteResult = nfmpFwk.deployDelete(xtraInfo.getValue(), "application/json");

                if (!deleteResult.success) {
                    logger.info("[NFMP-NETWORK-INTERFACE-FWK] removeInterfaceObject(): Unable to Delete: " + deleteResult.msg);
                    throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
                }
            }
        });
        this.removetoplogyXtraInfo(key);
    }

    this.removeInterfaceObject = function (key) {
        savedTopology.getXtraInfo().forEach(function (xtraInfo, index) {
            if (xtraInfo.getKey() === key)
            {
                var deleteResult = nfmpFwk.deployDelete(xtraInfo.getValue(), "application/json");

                if (!deleteResult.success) {
                    logger.info("[NFMP-NETWORK-INTERFACE-FWK] removeInterfaceObject(): Unable to Delete: " + deleteResult.msg);
                    throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
                }
            }
        });
        this.removetoplogyXtraInfo(key);
    }
    this.removetoplogyXtraInfo = function (key) {
        if (savedTopology && savedTopology.getXtraInfo() !== null && !savedTopology.getXtraInfo().isEmpty())
        {
            var xtraInfos = savedTopology.getXtraInfo();
            for (var i = 0; i < xtraInfos.size(); i++)
            {
                if (xtraInfos.get(i).getKey() == key)
                {
                    xtraInfos.remove(i);
                    break;
                }
            }
        }
    }
}
