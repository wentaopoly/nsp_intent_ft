function MdSuggest() {

  this.getServerCipherListName = function(neId) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/system/security/tls/server-cipher-list?fields=server-cipher-list-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}", neId, url);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:server-cipher-list'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['server-cipher-list-name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
 }
}
