function MdSuggest() {

    this.getAsPathGroup = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/policy-options/as-path-group?fields=name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:as-path-group'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }
}