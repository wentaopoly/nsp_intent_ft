function MdSuggest() {
   this.getVlanQosPolicyName = function (neId) {
      const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/qos/vlan-qos-policy?fields=vlan-qos-policy-name`;
      return this.getSuggestData(neId, url, "nokia-conf:vlan-qos-policy", "vlan-qos-policy-name");
   }
   this.getQueueMgmtData = function (neId) {
      const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/qos/queue-mgmt-policy?fields=queue-mgmt-policy-name`;
      return this.getSuggestData(neId, url, "nokia-conf:queue-mgmt-policy", "queue-mgmt-policy-name");
   }
   this.getSuggestData = function(neId, url, initialProperty, propertyName) {
      const mdcFwk = new MdcFwk();
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg[initialProperty];
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data[propertyName]).filter(value => value != null):[];
      return ret;
   }
}