var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});

function FileAccountingPolicy() {

    var util = new utilities();
    let nfmpFwk = new NfmpFwk();
    var mapFwk = new MapFwk();
    var mdtFwk = new MdtFwk();
    var parseTarget =  new ParseTarget();
    var isAudit = false;
    var isLocalFilePolicyExists = false;
    var isGlobalFilePolicyExists = false;
    var isLocalAccPolicyExists = false;
    var isGlobalAccPolicyExists = false;
    var distribute_url = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true";

    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        if (input.getNetworkState().name() === "delete")
        {
            return this.syncDelete(input, result);
        }

        var savedTopology = input.getCurrentTopology();
        logger.info("Saved Topology = "+savedTopology);
        savedObjects = {};
        currentObjects = {};
        //loading the saved objects from topology
        this.loadSavedObjectsFromTopology(savedTopology);
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        var accountingPolicyId = util.getAccountingPolicyId(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        if (!intentConfig) {
            intentConfig = Object.create({});
        }
        intentConfig["accounting-policy"]["accounting-policy-id"] = accountingPolicyId;
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + target);

        this.createOrModify(target,intentConfig);
        var currentTopo = this.loadCurrentObjectsToTopology(target);

        return util.setSuccessResult(result,currentTopo);
    }


    this.audit = function (target, config, svcTopo, adminState, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        var savedTopology = svcTopo;
        savedObjects = {};
        currentObjects = {};
        isAudit = true;
        var accountingPolicyId = util.getAccountingPolicyId(target);
        var target = parseTarget.getNeIdFromTarget(target);
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        logger.info("auditing configuration = "+JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        intentConfig["accounting-policy"]["accounting-policy-id"] = parseInt(accountingPolicyId);
        if(intentConfig){
            this.auditAndCompare(target,intentConfig,auditReport);
        }else{
            throw "configuration not available in the intent";
        }

        return auditReport
    }

    this.auditAndCompare = function(target,intentConfig,auditReport){
        var filePolicyPayload = this.createFilePolicyLevelPayLoad(target,intentConfig,true,null);
        var result = this.auditRequest(target, filePolicyPayload);
        auditReport = util.reportMisaligned(target, result,auditReport);

        var accPolicyPayload = this.createAccountingPolicyLevelPayLoad(target,intentConfig,true,null);
        var result = this.auditRequest(target, accPolicyPayload);
        auditReport = util.reportMisaligned(target, result,auditReport);

        return auditReport;
    }

    this.syncDelete = function (input,result) {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var accountingPolicyId = util.getAccountingPolicyId(input.getTarget());

        //Removing Accounting Policy
        var searchPayLoad = this.constructSearchStringWithPolicyID(neId, accountingPolicyId, "accounting.Policy");
        var searchResponse = nfmpFwk.post("/v3/search", searchPayLoad);
        logger.info("searchResponse = {}",JSON.stringify(searchResponse));
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                logger.info("syncDelete(): Unable to get Policy info from nfm-p for policy with Id:"+accountingPolicyId+ " on "+ neId);
            if(JSON.parse(searchResponse["response"]).length === 0)
                logger.info("syncDelete(): There is no accounting policy with Id:"+accountingPolicyId+ " on "+ neId);
            result.setSuccess(false);
            return;
        }

        var objectFullName = "network:"+neId+":Accounting:" + accountingPolicyId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        logger.info("syncDelete(): Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success) {
            logger.info("syncDelete(): Unable to Delete: " + deleteResult.msg);
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }

        //Removing File Policy
        var fileId = JSON.parse(searchResponse["response"])['accounting.Policy']['fileId'];
        searchPayLoad = this.constructSearchStringWithPolicyID(neId, fileId, "file.Policy");
        var searchResponse = nfmpFwk.post("/v3/search", searchPayLoad);
        logger.info("searchResponse = {}",JSON.stringify(searchResponse));
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                logger.info("syncDelete(): Unable to get Policy info from nfm-p for policy with Id:"+fileId+ " on "+ neId);
            if(JSON.parse(searchResponse["response"]).length === 0)
                logger.info("syncDelete(): There is no file policy with Id:"+fileId+ " on "+ neId);
            result.setSuccess(false);
            return;
        }

        var objectFullName = "network:"+neId+":File:" + fileId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        logger.info("syncDelete(): Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success) {
            logger.info("syncDelete(): Unable to Delete: " + deleteResult.msg);
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);

    }

    this.createOrModify= function(target, intentConfig) {
        //File Policy
        var fullClassName = "file.Policy";
        var policyFdn = "File";
        var objectFullName = "File:" + intentConfig["file"]["file-id"];
        var localPolicyFullName = "network:"+target+":File:" + intentConfig["file"]["file-id"];
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, target);
        var localPolicy = util.getIfObjectExists(fullClassName, localPolicyFullName);
        var distributePayload;
        var distributeResult;

        if(localPolicy != null)
        {
            isLocalFilePolicyExists = true;
            isGlobalFilePolicyExists = true;
            var filePolicyPayload = this.createFilePolicyLevelPayLoad(target,intentConfig,isLocalFilePolicyExists,localPolicy);
            result = this.modifyRequest(target, filePolicyPayload);
        }
        else{
            var globalPolicy = util.getIfObjectExists(fullClassName, objectFullName);
            if (globalPolicy != null) {
                isGlobalFilePolicyExists = true;
                distributePayload = util.distribute(target, objectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(target, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                logger.info("Checking distribution of existing global file policy was successful...");
                //Adding 2 sec delay so that file-policy gets distributed in Nfmp
                util.delay(2000);
                if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                    throw new RuntimeException("Unable to Distribute existing Global File Policy: " + objectFullName +
                        " . Kindly check the Global File Policy configuration");
                }
                logger.info("Distribution of existing global file policy was successful, updating the local file policy...");
                var filePolicyPayload = this.createFilePolicyLevelPayLoad(target,intentConfig,true,globalPolicy);
                result = this.modifyRequest(target, filePolicyPayload);
                if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                    throw new RuntimeException('Unable to update policy: ' + localPolicyFullName +
                        " . Kindly check the intent configuration");
                }
            }
            else{
                //distributing empty policy
                var filePolicyPayload = this.createFilePolicyLevelPayLoad(target, intentConfig, false, null);
                result = this.modifyRequest(target, filePolicyPayload);
                distributePayload = util.distribute(target, objectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(target, objectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                logger.info("Checking distribution of existing global file policy was successful...");
                //Adding 2 sec delay so that file-policy gets distributed in Nfmp
                util.delay(2000);
                if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                    throw new RuntimeException("Unable to Distribute existing Global File Policy: " + objectFullName +
                        " . Kindly check the Global File Policy configuration");
                }
                logger.info("Distribution of existing global file policy was successful, updating the local file policy...");
                //updating the local policy with intent configuration
                filePolicyPayload = this.createFilePolicyLevelPayLoad(target,intentConfig,true,null);
                result = this.modifyRequest(target, filePolicyPayload);
                if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                    throw new RuntimeException('Unable to update policy: ' + localPolicyFullName +
                        " . Kindly check the intent configuration");
                }
            }
        }
        //Adding 2 sec delay so that file-policy object gets created in Nfmp
        util.delay(2000);

        //Accounting Policy
        var accFullClassName = "accounting.Policy";
        var accPolicyFdn = "Accounting";
        var accObjectFullName = "Accounting:" + intentConfig["accounting-policy"]["accounting-policy-id"];
        var accLocalPolicyFullName = "network:"+target+":Accounting:" + intentConfig["accounting-policy"]["accounting-policy-id"];
        accLocalPolicyFullName = util.modifyNeIdForIpV6(accLocalPolicyFullName, target);
        var accLocalPolicy = util.getIfObjectExists(accFullClassName, accLocalPolicyFullName);

        if(accLocalPolicy != null)
        {
            isLocalAccPolicyExists = true;
            isGlobalAccPolicyExists = true;
            var accPolicyPayload = this.createAccountingPolicyLevelPayLoad(target,intentConfig,isLocalFilePolicyExists,localPolicy);
            result = this.modifyRequest(target, accPolicyPayload);
        }
        else{
            var accGlobalPolicy = util.getIfObjectExists(accFullClassName, accObjectFullName);
            if (accGlobalPolicy != null) {
                isGlobalAccPolicyExists = true;
                distributePayload = util.distribute(target, accObjectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(target, accObjectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                logger.info("Checking distribution of existing global accounting policy was successful...");
                //Adding 2 sec delay so that accounting-policy gets distributed in Nfmp
                util.delay(2000);
                if (!util.isObjectExists(accFullClassName, accLocalPolicyFullName)) {
                    throw new RuntimeException("Unable to Distribute existing Global Accounting Policy: " + accObjectFullName +
                        " . Kindly check the Global Accounting Policy Configuration");
                }
                logger.info("Distribution of existing global accounting policy was successful, updating the local file policy...");
                var accPolicyPayload = this.createAccountingPolicyLevelPayLoad(target,intentConfig,true,globalPolicy);
                result = this.modifyRequest(target, accPolicyPayload);
                if (!util.isObjectExists(accFullClassName, accLocalPolicyFullName)) {
                    throw new RuntimeException('Unable to update policy: ' + accLocalPolicyFullName +
                        " . Kindly check the intent configuration");
                }
            }
            else{
                //distributing empty policy
                var accPolicyPayload = this.createAccountingPolicyLevelPayLoad(target, intentConfig, false, null);
                result = this.modifyRequest(target, accPolicyPayload);
                distributePayload = util.distribute(target, accObjectFullName, false);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                // Changing SyncWithGlobal To Local Edit Only
                distributePayload = util.distribute(target, accObjectFullName, true);
                distributeResult = nfmpFwk.post(distribute_url, distributePayload);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                logger.info("Checking distribution of existing global accounting policy was successful...");
                //Adding 2 sec delay so that accounting-policy gets distributed in Nfmp
                util.delay(2000);
                if (!util.isObjectExists(accFullClassName, accLocalPolicyFullName)) {
                    throw new RuntimeException("Unable to Distribute existing Global Accounting Policy: " + accObjectFullName +
                        " . Kindly check the Global Accounting Policy configuration");
                }
                logger.info("Distribution of existing global accounting policy was successful, updating the local file policy...");
                //updating the local policy with intent configuration
                accPolicyPayload = this.createAccountingPolicyLevelPayLoad(target,intentConfig,true,null);
                result = this.modifyRequest(target, accPolicyPayload);
                if (!util.isObjectExists(accFullClassName, accLocalPolicyFullName)) {
                    throw new RuntimeException('Unable to update policy: ' + accLocalPolicyFullName +
                        " . Kindly check the intent configuration");
                }
            }
        }

        return result;
    }

    this.createFilePolicyLevelPayLoad = function(target,intentConfig, isLocalExists, policyObject) {
        var fullClassName = "file.Policy";
        var policyFdn = "File";
        var objectFullName = "File:" + intentConfig["file"]["file-id"];
        var localPolicyFullName = "network:"+target+":File:" + intentConfig["file"]["file-id"];
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, target);
        if(isAudit==true || isLocalExists)
        {
            objectFullName = localPolicyFullName;
        }
        var properties = {};

        properties["id"] = intentConfig["file"]["file-id"];
        properties["displayedName"] = String(intentConfig["file"]["file-policy-name"]);
        properties["description"] = intentConfig["file"]["description"];
        properties["collectionInterval"] = intentConfig["file"]["rollover"];
        properties["retentionInterval"] = intentConfig["file"]["retention"];
        properties["drive"] = util.transformNfmpCFLocation(intentConfig["file"]["compact-flash-location"]["primary"]);
        properties["backupPath"] = util.transformNfmpCFLocation(intentConfig["file"]["compact-flash-location"]["backup"]);
        var childProperties = {};

        var filePolicyPayload = util.editPayload(policyFdn,properties,childProperties,fullClassName,objectFullName);
        return filePolicyPayload;
    }

    this.createAccountingPolicyLevelPayLoad = function(target,intentConfig, isLocalExists, policyObject) {
        var nodeType = mdtFwk.getTypeAndVersion(target);
        var deviceType = this.getDeviceType(target);
        var fullClassName = "accounting.Policy";
        var policyFdn = "Accounting";
        var objectFullName = "Accounting:" + intentConfig["accounting-policy"]["accounting-policy-id"];
        var localPolicyFullName = "network:"+target+":Accounting:" + intentConfig["accounting-policy"]["accounting-policy-id"];
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, target);
        if(isAudit==true || isLocalExists)
        {
            objectFullName = localPolicyFullName;
        }
        var properties = {};

        properties["id"] = intentConfig["accounting-policy"]["accounting-policy-id"];
        properties["displayedName"] = String(intentConfig["accounting-policy"]["accounting-policy-name"]);
        properties["administrativeState"] = util.transformNfmpAdminState(intentConfig["accounting-policy"]["admin-state"]);
        properties["description"] = intentConfig["accounting-policy"]["description"];
        properties["collectionInterval"] = intentConfig["accounting-policy"]["collection-interval"];
        properties["isDefault"] = intentConfig["accounting-policy"]["default"];
        properties["recordType"] = util.transformNfmpRecordType(intentConfig["accounting-policy"]["record"]);
        if (isAudit == false)
        {
          properties["fileId"] = intentConfig["file"]["file-id"];
        }
        properties["fileObjectPointer"] = "File:"+ intentConfig["file"]["file-id"];
        if (!(nodeType["type"].startsWith("7210")|| nodeType["type"].startsWith("7705")) ){
            properties["includeSystemInfo"] = intentConfig["accounting-policy"]["include-system-info"];
            properties["align"] = intentConfig["accounting-policy"]["align"];
        }
        if (isAudit == false && ( nodeType["type"].startsWith("7210")|| nodeType["type"].startsWith("7705"))){
            properties["useDefaultInterval"] = "false";
        }
        if (nodeType["type"].startsWith("7210")){
            properties["logMemory"] = intentConfig["accounting-policy"]["logMemory"];
        }

        var childProperties = {};
        if (!(nodeType["type"].startsWith("7210")||nodeType["type"].startsWith("7250")||nodeType["type"].startsWith("7705")))
        {
            if (intentConfig["accounting-policy"]["custom-record"]) {
                var customRecordPayload = this.createCustomRecordPayLoad(intentConfig["accounting-policy"]["custom-record"], intentConfig["accounting-policy"]["accounting-policy-id"],nodeType,deviceType);
                childProperties["accounting.CustomRecord"] = customRecordPayload;
            }

            //queue
            let customRecordQueues = [];
            let customRecordQueuesConfig = intentConfig["accounting-policy"]["custom-record"]["queue"];
            if (customRecordQueuesConfig) {
                if (!Array.isArray(customRecordQueuesConfig)) {
                    customRecordQueuesConfig = [customRecordQueuesConfig];
                }
                for (var index in customRecordQueuesConfig) {
                    var customRecordQueueConfig = customRecordQueuesConfig[index];
                    var customRecordQueuePayload = this.createCustomRecordQueuePayLoad(customRecordQueueConfig);
                    customRecordQueues.push(customRecordQueuePayload);
                }
                childProperties["accounting.CustomQueueConfig"] = customRecordQueues;
            }
            else{
                childProperties["accounting.CustomQueueConfig"] = [];
            }

            //aa-specific
            if (!(nodeType["type"].startsWith("7950") || deviceType["type"].startsWith("7750-SRa4") || deviceType["type"].startsWith("7750-SRa8")))
            {
                childProperties["accounting.CustomAAConfig"] = this.createCustomAAConfigPayLoad(intentConfig["accounting-policy"]["custom-record"]["aa-specific"]);
                if (Object.keys(childProperties["accounting.CustomAAConfig"]).length === 0 ){
                    delete childProperties["accounting.CustomAAConfig"];
                }
            }

            //policer
            let customRecordPolicer = [];
            let customRecordPolicersConfig = intentConfig["accounting-policy"]["custom-record"]["policer"];
            if (customRecordPolicersConfig) {
                if (!Array.isArray(customRecordPolicersConfig)) {
                    customRecordPolicersConfig = [customRecordPolicersConfig];
                }
                for (var index in customRecordPolicersConfig) {
                    var customRecordPolicerConfig = customRecordPolicersConfig[index];
                    var policerObjectFullName = localPolicyFullName + ":Policer-" + customRecordPolicerConfig["id"];
                    mapFwk.set(currentObjects, policerObjectFullName, policerObjectFullName);
                    var customRecordPolicerPayload = this.createCustomRecordPolicerPayLoad(customRecordPolicerConfig);
                    customRecordPolicer.push(customRecordPolicerPayload);
                }
                childProperties["accounting.Policer"] = customRecordPolicer;
            }
            else{
                childProperties["accounting.Policer"] = [];
            }
        }

        var accPolicyPayload = util.editPayload(policyFdn,properties,childProperties,fullClassName,objectFullName);
        return accPolicyPayload;
    }

    this.createCustomRecordPayLoad = function(customRecordConfig, accountingPolicyId,nodeType,deviceType){
        var properties = {};

        if (customRecordConfig) {
            properties["delta"] = customRecordConfig["significant-change"];
            if(!(nodeType["type"].startsWith("7950") || (nodeType["type"].startsWith("7750") && (deviceType["type"].startsWith("7750-SR1 Fixed CFM") ||
                deviceType["type"].startsWith("7750 SR-1-46S") || deviceType["type"].startsWith("7750-SRa4")|| deviceType["type"].startsWith("7750 SR-1-24D") ||
                deviceType["type"].startsWith("7750 SR-1x-92S") || deviceType["type"].startsWith("7750-SRa8") || deviceType["type"].startsWith("7750 SR-7s")))))
            {
                if(customRecordConfig["ref-aa-specific-counter"] !== undefined )
                {
                    if(customRecordConfig["ref-aa-specific-counter"]["any"])
                    {
                        properties["significantApplicationAssuranceCounter"] = ["any"];
                    }
                    else{
                        properties["significantApplicationAssuranceCounter"] = "";
                    }
                }
            }
            //ref-queue
            if(customRecordConfig["ref-queue"]["all"] !== undefined ){
                if(customRecordConfig["ref-queue"]["all"] == "")
                {
                    properties["allQueues"] = true;
                }
            }
            else{
                properties["allQueues"] = false;
            }
            if (customRecordConfig["ref-queue"]["id"] !== undefined)
            {
                properties["queuePointer"] = "Accounting:" + accountingPolicyId + ":QId-" + customRecordConfig["ref-queue"]["id"];
            }
            else{
                properties["queuePointer"] = "";
            }
            let refQueueICounters = util.transformNfmpQueueIngressCounter(customRecordConfig["ref-queue"]["i-counters"]);
            if (!(isAudit == true && refQueueICounters.length === 0))
            {
                properties["significantIngressQueueCounter"] = (isAudit) ? refQueueICounters : {"bit": refQueueICounters};
                if(refQueueICounters.length == 0){
                    properties["significantIngressQueueCounter"] = "";
                }
            }
            let refQueueECounters = util.transformNfmpQueueEgressCounter(customRecordConfig["ref-queue"]["e-counters"]);
            if (!(isAudit == true && refQueueECounters.length == 0))
            {
                properties["significantEgressQueueCounter"] = (isAudit)?refQueueECounters:{"bit": refQueueECounters};
                if(refQueueECounters.length == 0){
                    properties["significantEgressQueueCounter"] = "";
                }
            }

            //ref-policer
            if(customRecordConfig["ref-policer"]["all"] != undefined)
            {
                if(customRecordConfig["ref-policer"]["all"] == "")
                {
                    properties["allPolicers"] = true;
                }
            }
            else{
                properties["allPolicers"] = false;
            }
            if (customRecordConfig["ref-policer"]["id"] !== undefined)
            {
                properties["policerPointer"] = "Accounting:" + accountingPolicyId + ":Policer-" + customRecordConfig["ref-policer"]["id"];
            }
            else{
                properties["policerPointer"] = "";
            }
            let refPolicerICounters = util.transformNfmpPolicerIngressCounter(customRecordConfig["ref-policer"]["i-counters"]);
            if (!(isAudit == true && refPolicerICounters.length == 0))
            {
                properties["significantIngressPolicerCounter"] = (isAudit) ? refPolicerICounters : {"bit": refPolicerICounters};
                if(refPolicerICounters.length == 0){
                    properties["significantIngressPolicerCounter"] = "";
                }
            }
            let refPolicerECounters = util.transformNfmpPolicerEgressCounter(customRecordConfig["ref-policer"]["e-counters"]);
            if (!(isAudit == true && refPolicerECounters.length == 0))
            {
                properties["significantEgressPolicerCounter"] = (isAudit) ? refPolicerECounters : {"bit": refPolicerECounters};
                if(refPolicerECounters.length == 0){
                    properties["significantEgressPolicerCounter"] = "";
                }
            }
        }

        return properties;
    }

    this.createCustomRecordQueuePayLoad = function(customRecordQueueConfig){
        var properties = {};

        if(customRecordQueueConfig){
            properties["id"] = customRecordQueueConfig["id"];
            let queueIngressCounter = util.transformNfmpQueueIngressCounter(customRecordQueueConfig["i-counters"]);
            if (!(isAudit == true && queueIngressCounter.length == 0)){
                properties["ingressCounter"] = (isAudit) ? queueIngressCounter : {"bit": queueIngressCounter};
                if(queueIngressCounter.length == 0){
                    properties["ingressCounter"] = "";
                }
            }
            let queueEgressCounter = util.transformNfmpQueueEgressCounter(customRecordQueueConfig["e-counters"]);
            if (!(isAudit == true && queueEgressCounter.length == 0)){
                properties["egressCounter"] = (isAudit) ? queueEgressCounter : {"bit": queueEgressCounter};
                if(queueEgressCounter.length == 0){
                    properties["egressCounter"] = "";
                }
            }
        }
        return properties;
    }

    this.createCustomAAConfigPayLoad = function(customAAConfig){
        var properties = {};

        if(customAAConfig){
            let customAACounter = util.transformNfmpApplicationAssuranceCounter(customAAConfig["aa-sub-counters"]);
            if (!(isAudit == true && customAACounter.length == 0)){
                properties["applicationAssuranceCounter"] = (isAudit) ? customAACounter : {"bit": customAACounter};
                if(customAACounter.length == 0){
                    properties["applicationAssuranceCounter"] = "";
                }
            }
            let customAAFromSubCounter = util.transformNfmpAaFromSubCounter(customAAConfig["from-aa-sub-counters"]);
            if (!(isAudit == true && customAAFromSubCounter.length == 0)){
                properties["fromSubCounter"] = (isAudit) ? customAAFromSubCounter : {"bit": customAAFromSubCounter};
                if(customAAFromSubCounter.length == 0){
                    properties["fromSubCounter"] = "";
                }
            }
            let customAAOptionalAttributes = util.transformNfmpAAOptionalAttributes(customAAConfig["aa-sub-attributes"]);
            if (!(isAudit == true && customAAOptionalAttributes.length == 0)){
                properties["optionalAttributes"] = (isAudit) ? customAAOptionalAttributes : {"bit": customAAOptionalAttributes};
                if(customAAOptionalAttributes.length == 0){
                    properties["optionalAttributes"] = "";
                }
            }
            let customAAtoSubCounter = util.transformNfmpAAtoSubCounter(customAAConfig["to-aa-sub-counters"]);
            if (!(isAudit == true && customAAtoSubCounter.length == 0)){
                properties["toSubCounter"] = (isAudit) ? customAAtoSubCounter : {"bit": customAAtoSubCounter};
                if(customAAtoSubCounter.length == 0){
                    properties["toSubCounter"] = "";
                }
            }
        }
        return properties;
    }

    this.createCustomRecordPolicerPayLoad = function(customRecordPolicerConfig){
        var properties = {};

        if(customRecordPolicerConfig){
            properties["id"] = customRecordPolicerConfig["id"];
            let policerIngressCounter = util.transformNfmpPolicerIngressCounter(customRecordPolicerConfig["i-counters"]);
            if (!(isAudit == true && policerIngressCounter.length == 0)){
                properties["ingressCounter"] = (isAudit) ? policerIngressCounter : {"bit": policerIngressCounter};
                if(policerIngressCounter.length == 0){
                    properties["ingressCounter"] = "";
                }
            }
            let policerEgressCounter = util.transformNfmpPolicerEgressCounter(customRecordPolicerConfig["e-counters"]);
            if (!(isAudit == true && policerEgressCounter.length == 0)){
                properties["egressCounter"] = (isAudit) ? policerEgressCounter : {"bit": policerEgressCounter};
                if(policerEgressCounter.length == 0){
                    properties["egressCounter"] = "";
                }
            }
        }
        return properties;
    }

    this.modifyRequest = function (target, payload) {

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
               logger.error("Error result = {}",JSON.stringify(result));
               let errorMsg = result.msg;
               if(errorMsg.indexOf("object already exists") !== -1)
               {
                   logger.info("Global policy Object already exists, Re-checking the Policy existence ");
                   //util.delay(2000);
                   let configInfo = payload.configInfo;
                   let fullClassName;
                   for (let key in configInfo) {
                     if (configInfo.hasOwnProperty(key)) {
                       fullClassName = key;
                       break;
                     }
                   }
                   let objectFullName = payload.objectFullName;
                   objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
                   logger.info("fullClassName = {}",fullClassName);
                   logger.info("objectFullName = {}",objectFullName);
                   if (!util.isObjectExists(fullClassName, objectFullName))
                   {
                       throw new RuntimeException("Global Policy Object Not Found!!!");
                   }
               }
               else
               {
                   throw new RuntimeException(result.msg);
               }
        }
        return result;

    }

    this.auditRequest = function (target, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.xml2object = function (xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: ' + json)
        return JSON.parse(json);
    }

    this.loadCurrentObjectsToTopology = function (target) {
        var currentTopo = topologyFactory.createServiceTopology();
        if (Object.keys(currentObjects).length) {
            for (var key in currentObjects) {
                objectId = mapFwk.get(currentObjects, key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key, objectId, "INFRASTRUCTURE", target, ""));
            }
        }
        return currentTopo;
    }

    this.loadSavedObjectsFromTopology = function (savedTopology) {
        if (savedTopology) {
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0) {
                topoObjects.forEach(function (topoObject) {
                    mapFwk.set(savedObjects, topoObject.getObjectType(), topoObject.getObjectRelativeObjectID());
                });
            }
        }
    }

    this.constructSearchStringWithPolicyID = function(neId, policyId, fullClassName) {
        var jsonPayLoad = {
            "fullClassName": fullClassName,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        },
                        {
                            "name": "id",
                            "value": policyId
                        }
                    ]
                }
            }
        };
        return jsonPayLoad;
    }

    this.getDeviceType= function (target) {
        var deviceInfos = mds.getAllInfoFromDevices(target);
        if (null == deviceInfos || deviceInfos.size() === 0) {
            throw new RuntimeException("Device not found :" + target);
        }
        var deviceInfo = deviceInfos.get(0);
        var deviceType = deviceInfo.getFamilyTypeRelease();
        if (deviceType == null) {
            throw new RuntimeException("Device Family type and release not found for device: " + target);
        }
        var type= deviceType.split(':');
        log.info(null, "Device type:" + type);
        var deviceType;
        deviceType = {
            type: type[2]
        };
        return deviceType;
    }

}