function NfmpSuggest() {
    this.getAuthenticationKeychain = function (neId) {
        let className = "security.KeyChain";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObject, className, "displayedName");
    }

    this.getInterfaceName = function (neId) {
        let className = "rsvp.Interface";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "nodeId",
                            "value": neId
                        },
                        {
                            "name": "routerId",
                            "value": 1
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObject, className, "displayedName");
    }

    this.getInterfaceData = function (neId, interfaceData ,type, name) {
        let nfmpFwk = new NfmpFwk();
        let className = "rtr.NetworkInterface";
        let searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "nodeId",
                            "value": neId
                        },
                        {
                            "name": name,
                            "value": interfaceData
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    type
                ]
            }
        };
        let resultFetch = nfmpFwk.post("/v3/search", searchObject);
        let finalResponse = JSON.parse(resultFetch.response);
        let data = (finalResponse[className] && finalResponse[className][type]);
        return data;
    }

    this.getInheritTeThresholds = function (neId, interfaceId) {
            let nfmpFwk = new NfmpFwk();
            let className = "rsvp.Interface";
            let searchObject = {
                "fullClassName": className,
                "filter": {
                    "and": {
                        "equal": [
                            {
                                "name": "nodeId",
                                "value": neId
                            },
                            {
                                "name": "interfaceId",
                                "value": interfaceId
                            }
                        ]
                    }
                },
                "resultFilter": {
                    "attribute": [
                        "displayedName"
                    ],
                    "children": {
                        "resultFilter": {
                            "children": "",
                            "attribute": [
                                "inheritTeUpThresholds",
                                "inheritTeDownThresholds"
                            ],
                            "class": "rsvp.TeThresholds"
                        }
                    }
                }
            };
            let resultFetch = nfmpFwk.post("/v3/search", searchObject);
            let finalResponse = JSON.parse(resultFetch.response);
            let data = {};
            if(finalResponse[className] && finalResponse[className]["children-Set"] && finalResponse[className]["children-Set"]["rsvp.TeThresholds"])
            {
                data = finalResponse[className]["children-Set"]["rsvp.TeThresholds"];
            }
            return data;
        }

    this.getData = function (searchObjectJson, className, type) {
        let nfmpFwk = new NfmpFwk();
        let ret = [];
        let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        let finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    ret.push(value[type]);
                })
            }
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }
}
