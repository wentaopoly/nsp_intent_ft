var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
const icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
const gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})

let intentTypeName = "security-zone_csros_23-10-1_23-11";

// example port, sap-ingress etc..
let initialPropertyName = "securitypolicy-Zone";


// unique identifier
let uniqueIdentifier = "id";


/**
 * This function is starting point by IM for sync operation
 * @param input
 * @returns {*}
 */
function synchronize(input) {
    logger.info("-------------------- script-content.js -> synchronize() --------------------");
    logger.info("Intent Synchronisation started - input = {}", input)
    return NspIntentHelper.synchronize(input, intentTypeName, initialPropertyName, uniqueIdentifier);
}

/**
 * The function is starting point for audit operation in IM
 * @param input
 * @returns {*}
 */
function audit(input) {
    logger.info("-------------------- script-content.js -> audit() --------------------");
    logger.info("Intent Audit started - input = {}", input)
    return NspIntentHelper.audit(input, intentTypeName, initialPropertyName, uniqueIdentifier)
}

/**
 * This function returns NE-ID
 *
 * @param context
 * @returns {string}
 */
function getNeId(context) {
    logger.info("-------------------- script-content.js -> getNeId() --------------------");
    let neId;
    let target = context.getInputValues()["target"]["objectidentifier"];
    logger.info("target = {}", target)
    if (target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    logger.info("NeId : " + neId);
    return neId;
}

function suggestZone(context) {
    var nfmpSuggest = new NfmpSuggest();
    logger.info("suggestZone context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getZone(neId);
}

function suggestSourceNetworkInterface(context) {
    var nfmpSuggest = new NfmpSuggest();
    logger.info("getSourceNetworkInterface context = \n" + context);
    var neId = getNeId(context);
    var templateName = context.getInputValues()["target"]["templatename"];
    var zoneId = context.getInputValues()["target"]["target"][templateName]["target_id"];
    logger.info("zoneID context = \n" + zoneId);
    return nfmpSuggest.getSourceNetworkInterface(neId, zoneId);
}

function suggestSecurityPolicyPointer(context) {
    var nfmpSuggest = new NfmpSuggest();
    logger.info("suggestSecurityPolicyPointer context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getSecurityPolicyPointer(neId);
}

function suggestSecurityLog(context) {
    var nfmpSuggest = new NfmpSuggest();
    logger.info("suggestSecurityLog context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getSecurityLog(neId);
}

function suggestVPRNService(context) {
    var nfmpSuggest = new NfmpSuggest();
    logger.info("suggestSecurityLog context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getVPRNService(neId);
}

function suggestIESService(context) {
    var nfmpSuggest = new NfmpSuggest();
    logger.info("suggestSecurityLog context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getIESService(neId);
}

function suggestVPLSService(context) {
    var nfmpSuggest = new NfmpSuggest();
    logger.info("suggestSecurityLog context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getVPLSService(neId);
}

function suggestMVPLSService(context) {
    var nfmpSuggest = new NfmpSuggest();
    logger.info("suggestSecurityLog context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getMVPLSService(neId);
}

function suggestEPIPEService(context) {
    var nfmpSuggest = new NfmpSuggest();
    logger.info("suggestSecurityLog context = \n" + context);
    var neId = getNeId(context);
    return nfmpSuggest.getEPIPEService(neId);
}

function suggestSourceVPRNL3AccessInterface(context) {
    var nfmpSuggest = new NfmpSuggest();
    logger.info("suggestSourceVPRNL3AccessInterface context = \n" + context);
    var neId = getNeId(context);
    var templateName = context.getInputValues()["target"]["templatename"];
    var zoneId = context.getInputValues()["target"]["target"][templateName]["target_id"];
    logger.info("zoneID context = \n" + zoneId);
    return nfmpSuggest.getSourceVPRNL3AccessInterface(neId, zoneId);
}

function suggestSourceIESL3AccessInterface(context) {
    var nfmpSuggest = new NfmpSuggest();
    logger.info("suggestSourceVPRNL3AccessInterface context = \n" + context);
    var neId = getNeId(context);
    var templateName = context.getInputValues()["target"]["templatename"];
    var zoneId = context.getInputValues()["target"]["target"][templateName]["target_id"];
    logger.info("zoneID context = \n" + zoneId);
    return nfmpSuggest.getSourceIESL3AccessInterface(neId, zoneId);
}

/**
 * The function is used in Brownfield discovery by ICM Framework
 * It discover's the configuration from the target device
 * and manipulate as per Template's default-target-data
 *
 * @see ICMFwk for more details
 * @param {*} input - the config data of a deployment
 * @returns result - the result of the operation
 */
function getTargetData(input) {
    logger.info("-------------------- script-content.js -> getTargetData() --------------------");
    logger.info("getTargetData input for brownfield = \n" + input);
    let target = input.target;
    let config = null;
    logger.info("target=" + target);
    let deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info("deviceConfig = {} ", JSON.stringify(deviceConfig));
    let data = gtdFwk.gtdSend(deviceConfig);
    logger.info("data = {}", JSON.stringify(data));
    logger.info("returning result = {}", JSON.stringify(data.msg.result));
    return data.msg.result;
}

