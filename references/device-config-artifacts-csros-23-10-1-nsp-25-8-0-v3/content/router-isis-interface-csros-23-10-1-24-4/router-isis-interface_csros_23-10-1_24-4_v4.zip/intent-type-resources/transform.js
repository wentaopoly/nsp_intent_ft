function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
      if(/isis-0/.test(objectFullName)) {
        objectFullName = objectFullName.replace("isis-0", "isis");
      }
      let interfaceId = objectFullName.split("interface-")[1];
      let newid = this.convertInterfaceToName(neId, interfaceId);
      let objectFullName_1 = objectFullName.split("interface-")[0];
      objectFullName = objectFullName_1.concat("interface-" + newid);
      return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformLocalObjectFullNameDistribute = function (localObjectFullName, intentConfig, payload, neId) {
        return localObjectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
      if(/isis-0/.test(objectFullName)) {
        objectFullName = objectFullName.replace("isis-0", "isis");
      }
      let interfaceId = objectFullName.split("interface-")[1];
      let newid = this.convertInterfaceToName(neId, interfaceId);
      let objectFullName_1 = objectFullName.split("interface-")[0];
      objectFullName = objectFullName_1.concat("interface-" + newid);
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
      if(/isis-0/.test(fdn)) {
        fdn = fdn.replace("isis-0", "isis");
      }
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        if(targetKey == "interfaceId") {
          let val = this.convertInterfaceToName(neId, targetValue);
          return val;
        }
        if(targetKey == "authKeychain") {
          let x = "KeyChain:".concat(targetValue);
          return x;
        }
        if(targetValue && targetValue != "N/A" && xpath == "routeNextHopPointer")
        {
            return "rtrRouteNextHopTemp:rnhpt-".concat(targetValue);
        }
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig) {
        if(targetKey == "authKeychain") {
          return targetValue.split(":")[1];
        }
        if(xpath == "isisCircIndex"){
          return 4;
        }
        if(targetValue && targetValue != "N/A" && xpath == "routeNextHopPointer")
        {
            targetValue = targetValue.replace("rtrRouteNextHopTemp:rnhpt-", "");
            return targetValue;
        }
        return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }

    this.convertInterfaceToName = function(neId, interfaceId) {
      let List1 = this.getInterfaceName(neId, interfaceId);
      let result = interfaceId;
      for (let i = 0; i < List1.length; i++) {
        if(List1[i].displayedName === interfaceId) {
          result = List1[i].id;
          break;
        }
      }
      return result;
    }

    this.convertNameToInterface = function(neId, interfaceId) {
      let List1 = this.getInterfaceName(neId, interfaceId);
      let result = interfaceId;
      for (let i = 0; i < List1.length; i++) {
        if(List1[i].id === interfaceId) {
          result = List1[i].id;
          break;
        }
      }
      return result;
    }

    this.getInterfaceName = function (neId, areaId, actionConfig) {
    let type = "displayedName";
    let classNames1 = "rtr.NetworkInterface";
    let classNames2 = "isis.Interface";
    let searchObject1;
    let resultFetch1;
    let data1;
    let finalResult1;
    if (actionConfig === "associate" && !areaId) {
       return [];
    }
    let createSearchObject = function (className, nodeId) {
        let attributeList = [type];
        if (className === classNames1) {
            attributeList.push("id");
        } else if (className === classNames2) {
            attributeList.push("interfaceId");
        }
        let filter = {
            "and": {
                "equal": [
                    {
                        "name": "nodeId",
                        "value": nodeId
                    }
                ]
            }
        };
        if (actionConfig === "associate" && areaId) {
            filter.and.equal.push({
                "name": "isisSysInstance",
                "value": areaId
            });
        }
        return {
            "fullClassName": className,
            "filter": filter,
            "resultFilter": {
                "children": "",
                "attribute": attributeList
            }
        };
    };
    if(actionConfig === "edit" || actionConfig === undefined){
      searchObject1 = createSearchObject(classNames1, neId);
      resultFetch1 = nfmpFwk.post("/v3/search", searchObject1);
      data1 = JSON.parse(resultFetch1.response);
      finalResult1 = finalResponse(data1, classNames1, ["displayedName", "id"]);
    }
    let searchObject2 = createSearchObject(classNames2, neId);
    let resultFetch2 = nfmpFwk.post("/v3/search", searchObject2);
    let data2 = JSON.parse(resultFetch2.response);
    let finalResult2 = finalResponse(data2, classNames2, ["displayedName", "interfaceId"]);
    let result = [];
    if (actionConfig === "edit" || (actionConfig === undefined && finalResult2 !== undefined)) {
      return finalResult1;
    }else if (actionConfig === "associate" && finalResult2.length > 0) {
       return finalResult2;
    }
    let filteredNamesArray = result.filter(name => name !== '1280');
    return filteredNamesArray;
  };

  function finalResponse(responseData, className, attributes) {
    let result = [];
    if (responseData !== undefined && responseData[className] !== undefined) {
        let finalResponse = responseData[className];
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        finalResponse.forEach(function (value) {
            let obj = {};
            attributes.forEach(attr => {
                obj[attr] = value[attr];
            });
            result.push(obj);
        });
    }
    return result;
  }


  this.getData = function (searchObjectJson, className, type) {
        let nfmpFwk = new NfmpFwk();
        let ret = [];
        let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        let finalResponse = JSON.parse(resultFetch.response);

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    ret.push(value[type]);
                })
            }
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
  }
}
