var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
const icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
const gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})

let intentTypeName = "routing-policy-statement_csros_23-10-1_24-4";

// example port, sap-ingress etc..
let initialPropertyName = "rp-PolicyStatement";


// unique identifier
let uniqueIdentifier = "policyStatementName";


/**
 * This function is starting point by IM for sync operation
 * @param input
 * @returns {*}
 */
function synchronize(input) {
    logger.info("-------------------- script-content.js -> synchronize() --------------------");
    logger.info("Intent Synchronisation started - input = {}", input)
    return NspIntentHelper.synchronize(input, intentTypeName, initialPropertyName, uniqueIdentifier);
}

/**
 * The function is starting point for audit operation in IM
 * @param input
 * @returns {*}
 */
function audit(input) {
    logger.info("-------------------- script-content.js -> audit() --------------------");
    logger.info("Intent Audit started - input = {}", input)
    return NspIntentHelper.audit(input, intentTypeName, initialPropertyName, uniqueIdentifier)
}

/**
 * This function returns NE-ID
 *
 * @param context
 * @returns {string}
 */
function getNeId(context) {
    logger.info("-------------------- script-content.js -> getNeId() --------------------");
    let neId;
    let target = context.getInputValues()["target"]["objectidentifier"];
    logger.info("target = {}", target)
    if (target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'"))
        {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else
        {
            neId = target;
        }
    }
    logger.info("NeId : " + neId);
    return neId;
}

function suggestPolicyStatementName(context) {
    logger.info("SuggestPolicyStatementName ==> context = {}", context);
    return new NfmpSuggest().getPolicyStatementName(getNeId(context));
}

function suggestPrefixListName(context) {
    logger.info("SuggestPrefixListName ==> context = {}", context);
    return new NfmpSuggest().getPrefixListName(getNeId(context));
}

function suggestPrefixListNameCondExpr(context) {
    logger.info("suggestPrefixListNameCondExpr ==> context = {}", context);
    return new NfmpSuggest().getPrefixListNameCondExpr(getNeId(context));
}

function suggestCommunityListName(context) {
    logger.info("SuggestCommunityListName ==> context = {}", context);
    return new NfmpSuggest().getCommunityListName(getNeId(context));
}

function suggestAdminTagPolicy(context) {
    logger.info("SuggestAdminTagPolicy ==> context = {}", context);
    return new NfmpSuggest().getAdminTagPolicy(getNeId(context));
}

function suggestASPathName(context) {
    logger.info("suggestASPathName ==> context = {}", context);
    return new NfmpSuggest().getASPathName(getNeId(context));
}

function suggestDampingProfile(context) {
    logger.info("SuggestDampingProfile ==> context = {}", context);
    return new NfmpSuggest().getDampingProfile(getNeId(context));
}

function suggestSRv6Locator(context) {
    logger.info("SuggestSRv6Locator ==> context = {}", context);
    return new NfmpSuggest().getSRv6Locator(getNeId(context));
}

function suggestASPathGroupName(context) {
    logger.info("SuggestASPathGroupName ==> context = {}", context);
    return new NfmpSuggest().getASPathGroupName(getNeId(context));
}

function suggestRouteDistinguisher(context) {
    logger.info("SuggestRouteDistinguisher ==> context = {}", context);
    return new NfmpSuggest().getRouteDistinguisher(getNeId(context));
}

function suggestSRMaintPolicy(context) {
    logger.info("SuggestSRMaintPolicy ==> context = {}", context);
    return new NfmpSuggest().getSRMaintPolicy(getNeId(context));
}

function suggestGlobalPolicyVariable(context) {
    logger.info("suggestGlobalPolicyVariable ==> context = {}", context);
    let contextConfig = context.getInputValues()["arguments"];
    return new NfmpSuggest().getGlobalVariableName(getNeId(context), contextConfig);
}

function suggestPolicyVarValue(context)
{
    logger.info("suggestPolicyVarValue ==> context = {}", context);
    return new NfmpSuggest().getPolicyVarValue(getNeId(context));
}

function suggestMulticastRedirectionInterface(context)
{
    logger.info("suggestMulticastRedirectionInterface ==> context = {}", context);
    return new NfmpSuggest().getMulticastRedirectionInterface(getNeId(context));
}

function suggestInterfaceNames(context) {
    logger.info("suggestInterfaceNames ==> context = {}", context);
    let neId = getNeId(context);
    return new NfmpSuggest().getInterfaceNames(neId);
}

/**
 * The function is used in Brownfield discovery by ICM Framework
 * It discover's the configuration from the target device
 * and manipulate as per Template's default-target-data
 *
 * @see ICMFwk for more details
 * @param {*} input - the config data of a deployment
 * @returns result - the result of the operation
 */
function getTargetData(input) {
    logger.info("-------------------- script-content.js -> getTargetData() --------------------");
    logger.info("getTargetData input for brownfield = \n" + input);
    let target = input.target;
    let config = null;
    logger.info("target=" + target);
    let deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    logger.info("deviceConfig = {} ", JSON.stringify(deviceConfig));
    let data = gtdFwk.gtdSend(deviceConfig);
    logger.info("data = {}", JSON.stringify(data));
    logger.info("returning result = {}", JSON.stringify(data.msg.result));
    return data.msg.result;
}

