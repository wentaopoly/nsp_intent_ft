var RuntimeException = Java.type('java.lang.RuntimeException');

var prefixToNsMap = {
    "ibn": "http://www.nokia.com/management-solutions/ibn",
    "nc": "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders": "anv-device-holders"
};


load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();

load({script: resourceProvider.getResource("nsp-intent-helper.js"), name: "nsp-intent-helper"})
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource('nsp-restconf-fwk.js'), name: 'nsp-restconf-fwk'});
var nspRestconfFwk = new NspRestconfFwk();

var intentTypeName = 'icm-router-network-interface';

// example port, sap-ingress etc..
var initialPropertyName = 'interface';

// unique identifier
var uniqueIdentifier = 'interface-name';

// example "configure" , "configure/qos" etc..
var parentXpath = 'configure/router=Base';

var topologyInfo = {};

function synchronize(input) {
    logger.info('Intent Synchronisation started')

    return NspIntentHelper.synchronize(input, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, topologyInfo);
}

function onAudit(target, config, svcTopo, adminState) {
    logger.info('Intent Audit started')

    return NspIntentHelper.audit(target, config, svcTopo, adminState, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier, topologyInfo);
}

function getTargetData(input) {
    logger.info(input);
    var target = input.target;
    var config = null;
    logger.info("target=" + target);
    var deviceConfig = icmFwk.getDeviceConfiguration(target, initialPropertyName);
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}

function suggestInterfaceName(context) {
    var interfaceName = [];
    try {
        var interface_name = context['inputValues']['arguments']['__root']['target_interface-name'];
        if (interface_name == null || interface_name === undefined) {
            var templateName = context.getInputValues()["target"]['templatename'];
            interface_name = context.getInputValues()["target"]['target'][templateName]['target_interface-name'];
            logger.info("interface-name from ICM" + interface_name);
        }
        interfaceName.push(interface_name);
        logger.info("Interface Name : " + interfaceName);

    } catch (e) {
        logger.error("Unable to get Interface Name \n" + context);
    }
    return interfaceName;
};

function suggestPortIds(context) {
    try {
        var neId;
        var target = context.getInputValues()["target"]["objectidentifier"];
        if (target) {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        } else {
            neId = context.getInputValues()["arguments"]["__parent"]["target_objectidentifier"];
            if (neId.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
                neId = neId.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
            }
        }
        logger.info("listing ports for NeId : " + neId);

        ret = nspRestconfFwk.getPorts(neId);
    } catch (e) {
        logger.error(" " + e.message);
    }
    return ret;
}

function suggestOspfInstances(context) {

    logger.info("BEGIN suggestOspfInstances");
    var ret = undefined;
    try {
        var neId;
        var target = context.getInputValues()["target"]["objectidentifier"];
        if (target) {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        } else {
            neId = context.getInputValues()["arguments"]["__parent"]["target_objectidentifier"];
            if (neId.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
                neId = neId.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
            }
        }
        logger.info("listing ospf isntances for NeId : " + neId);

        ret = nspRestconfFwk.getOSPFInstances(neId, 1);
    } catch (e) {
        logger.error(" " + e.message);
    }
    logger.info("END suggestOspfInstances");
    return ret;
}

function suggestOspf3Instances(context) {
    logger.info("BEGIN suggestOspf3Instances");
    var ret = undefined;
    try {
        var neId;
        var target = context.getInputValues()["target"]["objectidentifier"];
        if (target) {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        } else {
            neId = context.getInputValues()["arguments"]["__parent"]["target_objectidentifier"];
            if (neId.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
                neId = neId.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
            }
        }
        logger.info("listing ospf3 isntances for NeId : " + neId);

        ret = nspRestconfFwk.getOSPFInstances(neId, 3);
    } catch (e) {
        logger.error(" " + e.message);
    }
    logger.info("END suggestOspf3Instances");
    return ret;
}

function suggestOspfAreaInstances(context) {
    logger.info("BEGIN suggestOspfAreaInstances");
    var ret = undefined;
    try {
        var neId;
        var target = context.getInputValues()["target"]["objectidentifier"];
        logger.info(context);
        if (target) {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        } else {
            neId = context.getInputValues()["arguments"]["__parent"]["__parent"]["target_objectidentifier"];
            if (neId.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
                neId = neId.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
            }
        }
        logger.info("listing ospf area isntances for NeId : " + neId);

        var ospfInstance = context.getInputValues()["arguments"]["__parent"]["ospf-instance"];

        ret = nspRestconfFwk.getOSPFAreaInstances(neId, 1, ospfInstance);
    } catch (e) {
        logger.error(" " + e.message);
    }
    logger.info("END suggestOspfAreaInstances");
    return ret;
}

function suggestOspf3AreaInstances(context) {
    logger.info("BEGIN suggestOspf3AreaInstances");
    var ret = undefined;
    try {
        var neId;
        var target = context.getInputValues()["target"]["objectidentifier"];
        logger.info(context);
        if (target) {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        } else {
            neId = context.getInputValues()["arguments"]["__parent"]["__parent"]["target_objectidentifier"];
            if (neId.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
                neId = neId.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
            }
        }
        logger.info("listing ospf3 area isntances for NeId : " + neId);

        var ospfInstance = context.getInputValues()["arguments"]["__parent"]["ospf-instance"];
        logger.info(context)

        ret = nspRestconfFwk.getOSPFAreaInstances(neId, 3, ospfInstance);
    } catch (e) {
        logger.error(" " + e.message);
    }
    logger.info("END suggestOspf3AreaInstances");
    return ret;
}

function suggestIsisInstances(context) {
    logger.info("BEGIN suggestIsisInstances");
    var ret = undefined;
    try {
        var neId;
        var target = context.getInputValues()["target"]["objectidentifier"];
        if (target) {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        } else {
            neId = context.getInputValues()["arguments"]["__parent"]["target_objectidentifier"];
            if (neId.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
                neId = neId.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
            }
        }
        logger.info("listing isis isntances for NeId : " + neId);

        ret = nspRestconfFwk.getISISInstances(neId);
    } catch (e) {
        logger.error(" " + e.message);
    }
    logger.info("END suggestIsisInstances");
    return ret;
}
