function ModelDeviceMapping() {

    this.getMapping = function(abc) {
        if(abc == 'sap-ingress.mac-criteria.entry') {
            return this.getMacMapping();
        }
        else if(abc== 'sap-ingress.ip-criteria.entry') {
            return this.getIpMapping();
        }
        else if(abc== 'sap-ingress.ipv6-criteria.entry') {
            return this.getIpv6Mapping();
        }
        else if(abc== 'sap-ingress.fc.fc') {
            return this.getFcMapping();
        }
        else if(abc== 'sap-ingress.meter.meter') {
            return this.getMeterMapping();
        }
        else if(abc== 'sap-ingress.queue.queue') {
            return this.getQueueMapping();
        }
    }

    this.getSasIngressMapping = function () {
        var mapping = {};
        mapping['sap-ingress.description'] = 'description';
        mapping['sap-ingress.default-fc'] = 'defaultFc';
        mapping['sap-ingress.num-qos-classifiers'] = 'numQosClassifiers';
        mapping['sap-ingress.scope'] = 'scope';
        mapping['sap-ingress.table-classification-criteria'] = 'tableClassificationCriteria';
        mapping['sap-ingress.profile'] = 'profile';
        mapping['sap-ingress.mac-match-criteria-type'] = 'macMatchCriteriaType';
        mapping['sap-ingress.ip-match-criteria-type'] = 'ipMatchCriteriaType';
        mapping['sap-ingress.ipv6-match-criteria-type'] = 'ipv6MatchCriteriaType';
        mapping['sap-ingress.enable-inner-dot1p-match-criteria'] = 'enableInnerDot1pMatch';
        mapping['sap-ingress.ip-mac-match'] = 'ipMacMatchClassificationType';
        mapping['sap-ingress.dscp-classification'] = 'dscpClassificationPointer';
        mapping['sap-ingress.dot1p-classification'] = 'dot1pClassificationPointer';

        return mapping;
    }

    this.getMeterMapping = function() {
        var mapping = {};
        mapping["sap-ingress.meter.meter.meter-id"] = 'id';
        mapping["sap-ingress.meter.meter.rate-mode"] = 'rateMode';
        mapping["sap-ingress.meter.meter.color-mode"] = 'colorMode';
        mapping["sap-ingress.meter.meter.rate.Cir"] = 'cir';
        mapping["sap-ingress.meter.meter.rate.Pir"] = 'pir';
        mapping["sap-ingress.meter.meter.adaptation-rule.cir"] = 'cirAdaptation';
        mapping["sap-ingress.meter.meter.adaptation-rule.pir"] = 'pirAdaptation';
        mapping["sap-ingress.meter.meter.Burst-Size.CBS-type"] = 'cbsType';
        mapping["sap-ingress.meter.meter.Burst-Size.MBS-type"] = 'mbsType';
        return mapping;
    }

    this.getQueueMapping = function() {
        var mapping = {};
        mapping["queue-id"] = 'id';
        mapping['name'] = 'displayedName';
        mapping['description'] = 'description';
        mapping['weight'] = 'weight';
        mapping['priority'] = 'priority';
        mapping['queue-management-policy'] = 'queuemgmtPolicyPointer';
        mapping['slope-policy'] = 'slopePolicyPointer';
        mapping['port-parent.port-parent'] = 'portParent';
        mapping['port-parent.weight'] = 'portParentWeight';
        mapping['port-parent.Cir-level'] = 'portParentCirLevel';
        mapping['rate.Cir'] = 'cir';
        mapping['rate.Pir'] = 'pir';
        mapping['adaptation-rule.cir'] = 'cirAdaptation';
        mapping['adaptation-rule.pir'] = 'pirAdaptation';
        mapping['Burst-Size.admin-CBS'] = 'committedBurstSize';
        mapping['Burst-Size.admin-MBS'] = 'maximumBurstSize';
        return mapping;
    }

    this.getFcMapping = function() {
        var mapping = {};

        mapping['sap-ingress.fc.fc.fc-name'] = 'forwardingClass';
        mapping['sap-ingress.fc.fc.meter-id'] = 'id';
        mapping['sap-ingress.fc.fc.multicast-queue-id'] = 'multicastQueueId';
        mapping['sap-ingress.fc.fc.broadcast-id'] = 'broadcastMeterId';
        mapping['sap-ingress.fc.fc.unknown-meter-id'] = 'unknownMeterId';
        mapping['sap-ingress.fc.fc.multicast-id'] = 'multicastMeterId';
        mapping['sap-ingress.fc.fc.queue-id'] = 'queueId';
        mapping['sap-ingress.fc.fc.use-Dei'] = 'useDei';

        return mapping;

    }

    this.getIpMapping = function() {
        var mapping = {};
        mapping["sap-ingress.ip-criteria.entry.entry-id"] = "id";
        mapping['sap-ingress.ip-criteria.entry.name'] = 'displayedName';
        mapping['sap-ingress.ip-criteria.entry.description'] = 'description';
        mapping['sap-ingress.ip-criteria.entry.match.protocol'] = 'protocol';
        mapping['sap-ingress.ip-criteria.entry.match.src-ip.address'] = 'sourceIpAddress';
        mapping['sap-ingress.ip-criteria.entry.match.src-ip.mask'] = 'sourceIpAddressMask';
        mapping['sap-ingress.ip-criteria.entry.match.dst-ip.address'] = 'destinationIpAddress';
        mapping['sap-ingress.ip-criteria.entry.match.dst-ip.mask'] = 'destinationIpAddressMask';
        mapping['sap-ingress.ip-criteria.entry.match.src-port.src-prt'] = 'sourceOperator';
        mapping['sap-ingress.ip-criteria.entry.match.src-port.port-src'] = 'sourcePort1';
        mapping['sap-ingress.ip-criteria.entry.match.dst-port.dst-prt'] = 'destinationOperator';
        mapping['sap-ingress.ip-criteria.entry.match.dst-port.port-dst'] = 'destinationPort1';
        mapping['sap-ingress.ip-criteria.entry.match.dscp.dscp-type'] = 'dscp';
        mapping['sap-ingress.ip-criteria.entry.match.dscp.dscp-value'] = 'dscpValue';
        mapping['sap-ingress.ip-criteria.entry.match.dscp.dscp-mask'] = 'dscpMask';
        mapping['sap-ingress.ip-criteria.entry.match.ip-precedence.ip-precedence-value'] = 'ipPrecedence';
        mapping['sap-ingress.ip-criteria.entry.match.ip-precedence.precedence-mask'] = 'ipPrecedenceMask';
        mapping['sap-ingress.ip-criteria.entry.action.fc'] = 'forwardingClass';

        return mapping;
    }

    this.getIpv6Mapping = function() {
        var mapping = {};
        mapping["sap-ingress.ipv6-criteria.entry.entry-id"] = "id";
        mapping['sap-ingress.ipv6-criteria.entry.name'] = 'displayedName';
        mapping['sap-ingress.ipv6-criteria.entry.description'] = 'description';
        mapping['sap-ingress.ipv6-criteria.entry.match.protocol'] = 'protocol';
        mapping['sap-ingress.ipv6-criteria.entry.match.src-ip.address'] = 'sourceIpAddress';
        mapping['sap-ingress.ipv6-criteria.entry.match.src-ip.mask'] = 'sourceIpAddressMask';
        mapping['sap-ingress.ipv6-criteria.entry.match.dst-ip.address'] = 'destinationIpAddress';
        mapping['sap-ingress.ipv6-criteria.entry.match.dst-ip.mask'] = 'destinationIpAddressMask';
        mapping['sap-ingress.ipv6-criteria.entry.match.src-port.src-prt'] = 'sourceOperator';
        mapping['sap-ingress.ipv6-criteria.entry.match.src-port.port-src'] = 'sourcePort1';
        mapping['sap-ingress.ipv6-criteria.entry.match.dst-port.dst-prt'] = 'destinationOperator';
        mapping['sap-ingress.ipv6-criteria.entry.match.dst-port.port-dst'] = 'destinationPort1';
        mapping['sap-ingress.ipv6-criteria.entry.match.dscp.dscp-type'] = 'dscp';
        mapping['sap-ingress.ipv6-criteria.entry.match.dscp.dscp-value'] = 'dscpValue';
        mapping['sap-ingress.ipv6-criteria.entry.match.dscp.dscp-mask'] = 'dscpMask';
        mapping['sap-ingress.ipv6-criteria.entry.match.ip-precedence.ip-precedence-value'] = 'ipPrecedence';
        mapping['sap-ingress.ipv6-criteria.entry.match.ip-precedence.precedence-mask'] = 'ipPrecedenceMask';
        mapping['sap-ingress.ipv6-criteria.entry.action.fc'] = 'forwardingClass';

        return mapping;
    }

    this.getMacMapping = function() {
        var mapping = {};
        mapping["sap-ingress.mac-criteria.entry.entry-id"] = "id";
        mapping['sap-ingress.mac-criteria.entry.name'] = 'displayedName';
        mapping['sap-ingress.mac-criteria.entry.description'] = 'description';
        mapping['sap-ingress.mac-criteria.entry.match.dot1p-value'] = 'dot1pValue';
        mapping['sap-ingress.mac-criteria.entry.match.dot1p-mask'] = 'dot1pMask';
        mapping['sap-ingress.mac-criteria.entry.match.inner-dot1p-value'] = 'innerDot1pValue';
        mapping['sap-ingress.mac-criteria.entry.match.inner-dot1p-mask'] = 'innerDot1pMask';
        mapping['sap-ingress.mac-criteria.entry.match.outer-dot1p-value'] = 'outerDot1pValue';
        mapping['sap-ingress.mac-criteria.entry.match.outer-dot1p-mask'] = 'outerDot1pMask';
        mapping['sap-ingress.mac-criteria.entry.match.e-type-value'] = 'ethernetType';
        mapping['sap-ingress.mac-criteria.entry.match.src-mac'] = 'sourceMacAddress';
        mapping['sap-ingress.mac-criteria.entry.match.src-mask'] = 'sourceMacAddressMask';
        mapping['sap-ingress.mac-criteria.entry.match.dst-mac'] = 'destinationMacAddress';
        mapping['sap-ingress.mac-criteria.entry.match.dst-mask'] = 'destinationMacAddressMask';
        mapping['sap-ingress.mac-criteria.entry.match.inner-tag-value'] = 'innerTagValue';
        mapping['sap-ingress.mac-criteria.entry.match.inner-tag-vid-mask'] = 'innerTagMask';
        mapping['sap-ingress.mac-criteria.entry.match.outer-tag-value'] = 'outerTagValue';
        mapping['sap-ingress.mac-criteria.entry.match.outer-tag-vid-mask'] = 'outerTagMask';
        mapping['sap-ingress.mac-criteria.entry.action.fc'] = 'forwardingClass';
        mapping["sap-ingress.mac-criteria.entry.action.profile"] = 'profile';
        mapping['sap-ingress.mac-criteria.entry.match.src'] = "";
        return mapping;
    }

}

this.transformColorMode = function(value) {
    if(value == 'colorAware') {
        return 'color-aware';
    }
    else {
        return 'color-blind';
    }
}

this.transformRateMode = function(value) {
    if(value == 'trtcm1') {
        return 'trTCM(RFC-2698)';
    }
    else if(value == 'trtcm2') {
        return 'trTCM(RFC-4115)';
    }
    else {
        return 'srTCM';
    }
}
