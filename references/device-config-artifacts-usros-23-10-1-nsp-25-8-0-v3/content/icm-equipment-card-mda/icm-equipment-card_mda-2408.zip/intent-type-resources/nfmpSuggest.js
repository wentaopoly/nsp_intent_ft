load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {
    this.getCardTypes = function (neId, slotId) {
        var className = "equipment.CardSlot";
        var searchObjectJson = {
            "fullClassName": className,
            "filter": {
                "filterExpression": "siteId='" + neId + "' AND slotId='" + slotId + "' AND oesShelfId='0'"
            }
        };
        return this.getData(searchObjectJson, "card-type")
    }
    this.getMdaTypes = function (neId, slotId, xiomSlotId, mdaSlotId) {
        if (!xiomSlotId)
        {
            xiomSlotId = 0;
        }
        var className = "equipment.DaughterCardSlot";
        var searchObjectJson = {
            "fullClassName": className,
            "filter": {
                "filterExpression": "siteId='" + neId + "' AND slotId='" + slotId + "' AND xiomCardSlotId='" + xiomSlotId + "' AND daughterCardSlotId='" + mdaSlotId + "' AND oesShelfId='0'"
            }
        };
        return this.getData(searchObjectJson, "mda-type")
    }
    this.getXiomTypes = function (neId, slotId, xiomSlotId) {
        var className = "equipment.XiomCardSlot";
        var searchObjectJson = {
            "fullClassName": className,
            "filter": {
                "filterExpression": "siteId='" + neId + "' AND slotId='" + slotId + "' AND xiomCardSlotId='" + xiomSlotId + "' AND oesShelfId='0'"
            }
        };
        return this.getData(searchObjectJson, "xiom-type")
    }
    this.getData = function (searchObjectJson, slot) {
        let nfmpFwk = new NfmpFwk();
        var result = [];
        var resultFetch = nfmpFwk.post("search", searchObjectJson);
        //logger.info(resultFetch.response);
        var finalResponse = JSON.parse(resultFetch.response);
        //logger.info(JSON.stringify(finalResponse));
        if (finalResponse[0])
        {
            var ret = finalResponse[0]["properties"]["supportedChildTypes"];
            if (!Array.isArray(ret))
            {
                ret = [ret];
            }
            //logger.info("ret = \n" + ret);
            //logger.info("ret = \n" + JSON.stringify(ret));
            var data = ret.map(function (slotType) {
                logger.info(slotType);
                var obj = {};
                obj[slot] = slotType;
                return obj;
            });
            logger.info("data = \n" + JSON.stringify(data));
            logger.info("Sorting the data");
            data.sort((a, b) => {
                if (a[slot] < b[slot]) {
                return -1;
                }
                if (a[slot] > b[slot]) {
                return 1;
                }
                return 0;
            });
            logger.info("data after sorting= \n" + JSON.stringify(data));
            result["data"] = JSON.stringify(data);
            logger.info("result = \n" + JSON.stringify(result));
        }
        return result;
    }
}