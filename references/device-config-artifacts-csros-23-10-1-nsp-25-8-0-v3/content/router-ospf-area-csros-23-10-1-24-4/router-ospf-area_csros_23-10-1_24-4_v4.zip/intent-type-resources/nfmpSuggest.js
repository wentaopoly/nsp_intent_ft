function NfmpSuggest() {
  this.getInstanceIndex = function (neId) {
        let className = "ospf.Site";
        let searchObject = {
        "fullClassName": className,
        "filter": {
            "and": {
                "equal": [
                    {
                        "name": "siteId",
                        "value": neId
                    },
                    {
                       "name": "version",
                       "value": "v2"
                    }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": [
                "instanceIndex"
             ]
           }
        };
        return this.getData(searchObject, className, "instanceIndex");
  }

  this.getAreaSite = function (neId ,instanceId) {
        let className = "ospf.AreaSite";
        let searchObject = {
        "fullClassName": className,
        "filter": {
            "and": {
                "equal": [
                    {
                        "name": "siteId",
                        "value": neId
                    },
                    {
                       "name": "instanceIndex",
                       "value": instanceId

                   },
                    {
                       "name": "version",
                       "value": "2"
                    }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": [
                "areaId"
            ]
          }
        };
        return this.getData(searchObject, className, "areaId");
  }

  this.getBIER = function(neId) {
    let className = "bier.BierTemplate";
        let searchObject = {
        "fullClassName": className,
        "filter": {
            "and": {
                "equal": [
                    {
                        "name": "siteId",
                        "value": neId
                    }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": [
                "templateName"
             ]
           }
        };
        return this.getData(searchObject, className, "templateName");
  }

  this.getPolicy1 = function(neId) {
    let className = "rp.PolicyStatement";
        let searchObject = {
        "fullClassName": className,
        "filter": {
            "and": {
                "equal": [
                    {
                        "name": "siteId",
                        "value": neId
                    }
                ]
            }
        },
        "resultFilter": {
            "children": "",
            "attribute": [
                "policyStatementName"
             ]
           }
        };
        return this.getData(searchObject, className, "policyStatementName");
  }

  this.getData = function (searchObjectJson, className, type) {
        let nfmpFwk = new NfmpFwk();
        let ret = [];
        let resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        let finalResponse = JSON.parse(resultFetch.response);
        logger.info("finalResponse = {}",JSON.stringify(finalResponse));

        finalResponse = finalResponse[className];
        logger.info("finalResponse[{}] = {}",className,JSON.stringify(finalResponse));

        if (finalResponse !== undefined)
        {
            if (!Array.isArray(finalResponse))
            {
                finalResponse = [finalResponse];
            }
            if (Object.keys(finalResponse).length !== 0)
            {
                finalResponse.forEach(function (value, index, array) {
                    ret.push(value[type]);
                })
            }
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
  }
}
