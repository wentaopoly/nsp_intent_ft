var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource('mediator-fwk.js'), name: 'mediator-fwk.js'});
nfmpMediator = new MediatorFramework("NFMP");
load({script: resourceProvider.getResource("color-mapping.js"),name: "color-mapping"});
colorAdminTagMapping = new ColorMapping().colorMapping();

function NfmpDiscoveryHelper() {

    this.getDeviceConfiguration = function (target, requestContext, neId) {
        var nfmpTunnelIds = requestContext.get("nfmpTunnelIds");
        var searchPayLoad = this.constructSearchString(neId, nfmpTunnelIds);
        var searchResponse = nfmpMediator.post("/v3/search", searchPayLoad);
        if (!searchResponse.success) {
            throw new RuntimeException("Failed to find LSP on NE " + neId);
        }
        searchResponse = searchResponse.response;
        logger.info("getDeviceConfiguration: searchResponse = {}", JSON.stringify(searchResponse));
        return searchResponse;
    }
  
    this.constructSearchString = function (neId, nfmpTunnelIds) {
        var jsonPayLoad = {
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": "lsp:from-" + neId + "-id-" + nfmpTunnelIds[neId]
                }
            },
            "fullClassName": "mpls.Lsp"
        };
        return jsonPayLoad;
    }

    /**
     * Retrieve DisplayedName for the given AdminGroup value and siteId
     * @param value AdminGroup value
     * @param siteId NE ID
     * @returns DisplayedName
     */
    this.getDisplayedNameForAdminGroup = function (value, siteId) {
        var payload = {
            "fullClassName": "rtr.AdminGroupPolicy",
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "value",
                            "value": value
                        },
                        {
                            "name": "siteId",
                            "value": siteId
                        }
                    ]
                }
            }, "resultFilter": {
                "attribute": [
                    "displayedName"
                ]
            }
        };
        var results = nfmpMediator.post("/v3/search", payload);
        if (results.success && results.response["rtr.AdminGroupPolicy"] && results.response["rtr.AdminGroupPolicy"]["displayedName"]) {
            return results.response["rtr.AdminGroupPolicy"]["displayedName"];
        } else {
            throw new RuntimeException("Error in getDisplayedNameForAdminGroup, reason: " + results.msg);
        }
    }

    this.prepareDeviceConfig = function (deviceConfig) {
        logger.debug("prepareDeviceConfig: deviceConfig = {}", JSON.stringify(deviceConfig));
        // Check for Classic BF - preparation
        if (deviceConfig["mpls.DynamicLsp"] || deviceConfig["mpls.SegmentRoutingTeLsp"]) {
            var childrenSet = deviceConfig["mpls.DynamicLsp"] ? deviceConfig["mpls.DynamicLsp"]["children-Set"]
                : deviceConfig["mpls.SegmentRoutingTeLsp"]["children-Set"];
            // Check and restructure containers
            if (!Array.isArray(childrenSet["mpls.LspPath"])) {
                childrenSet["mpls.LspPath"] = [childrenSet["mpls.LspPath"]]
                logger.debug("getTargetData: updated --> mpls.LspPath as a container in deviceConfig");
            }
            // Update path name and objectFullName
            childrenSet["mpls.LspPath"].forEach(function (lspPath) {
                var name = (lspPath["type"] == "primary") ? lspPath.resourceName.split(lspPath.lspName + "_")
                    : lspPath.resourceName.split(lspPath.lspName + "_secondary_")
                lspPath.objectFullName = lspPath.objectFullName.replace(lspPath.name, name);
                lspPath.name = name[name.length - 1];
            });

            if (childrenSet["mpls.PathProfile"] &&
                !Array.isArray(childrenSet["mpls.PathProfile"])) {
                childrenSet["mpls.PathProfile"] = [childrenSet["mpls.PathProfile"]]
                logger.debug("getTargetData: updated --> mpls.PathProfile as a container in deviceConfig");
            }
        }
    }

    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        this.prepareDeviceConfig(deviceConfig);
        var parsedDefaultTargetData = JSON.parse(defaultTargetData);
        deviceConfig = deviceConfig["mpls.DynamicLsp"] ? deviceConfig["mpls.DynamicLsp"] : deviceConfig["mpls.SegmentRoutingTeLsp"];

        if (null !== deviceConfig) {
            var mappings = resourceProvider.getResource("model-device-mapping.json");
            mappings = JSON.parse(mappings);
            var defaultTemplateDataMap = this.prepareDefaultTemplateDataMap(parsedDefaultTargetData);
            this.extractLSPProperties(defaultTemplateDataMap, deviceConfig, mappings);
        }

        parsedDefaultTargetData = JSON.parse(JSON.stringify(parsedDefaultTargetData));
        logger.debug("Intent data after updating from NFMP: \n{}", JSON.stringify(parsedDefaultTargetData))
        this.clearEmpties(parsedDefaultTargetData);
        logger.info("Intent data after clearing empties from NFMP: \n{}", JSON.stringify(parsedDefaultTargetData));
        return parsedDefaultTargetData;
    }

    this.extractLSPProperties = function (defaultTemplateDataMap, deviceConfig, mappings) {
        this.extractProperties(defaultTemplateDataMap["default-target-data"], deviceConfig, mappings);
        // separately extract Container data
        if (deviceConfig["children-Set"]["mpls.PathProfile"]) {
            var pathProfileArray = this.extractContainerProperties(defaultTemplateDataMap["association-object-extended"],
                deviceConfig["children-Set"]["mpls.PathProfile"], mappings["association-objects"]["association-object-extended"][0]);
            pathProfileArray.forEach(function (pathProfile) {
                pathProfile["extended-id"] = parseInt(pathProfile["extended-id"]).toString(16);
                if(pathProfile["extended-id"].length == 1)
                    pathProfile["extended-id"] = "0"+pathProfile["extended-id"]
            });
            defaultTemplateDataMap["default-target-data"]["association-objects"] = { "association-object-extended": pathProfileArray }
            logger.debug("extractLSPProperties: pathProfileArray = {}\n defaultTargetData = {}",
                JSON.stringify(pathProfileArray), JSON.stringify(defaultTemplateDataMap));
        }

        // Process Paths
        var primaryPathDeviceConfig;
        var secondaryPathsDeviceConfig = []
        var hopless = true;
        deviceConfig["children-Set"]["mpls.LspPath"].forEach(function (lspPath) {
            if (lspPath.type == "primary" && lspPath.name != "hopless") {
                primaryPathDeviceConfig = lspPath;
                hopless = false;
            } else if (lspPath.type == "secondary" || lspPath.type == "standby") {
                secondaryPathsDeviceConfig.push(lspPath);
            }
        });

        // Primary-path - start
        if (!hopless) {
            var primaryPathArray = this.extractContainerProperties(defaultTemplateDataMap["primary-paths"],
                [primaryPathDeviceConfig], mappings["primary-paths"]["primary-path"][0]);
            defaultTemplateDataMap["default-target-data"]["primary-paths"] = {"primary-path": primaryPathArray}
            logger.debug("extractLSPProperties: primaryPathArray = {}\n defaultTargetData = {}", JSON.stringify(primaryPathArray), JSON.stringify(defaultTemplateDataMap));
            this.populateGlobalPriorities(defaultTemplateDataMap, primaryPathArray[0]["setup-priority"], primaryPathArray[0]["hold-priority"])
            // Update path-computation
            this.populatePathComputationMethod(deviceConfig["children-Set"]["mpls.LspExtension"]["pathComputationMethod"], defaultTemplateDataMap);
        }else {
            this.populateGlobalPriorities(defaultTemplateDataMap, deviceConfig["children-Set"]["mpls.LspPath"][0]["setupPriority"], deviceConfig["children-Set"]["mpls.LspPath"][0]["holdPriority"])
        }
        // Primary-path - end

        // Secondary-path - start
        var secondaryPathArray = this.extractContainerProperties(defaultTemplateDataMap["secondary-paths"],
            secondaryPathsDeviceConfig, mappings["secondary-paths"]["secondary-path"][0]);
        defaultTemplateDataMap["default-target-data"]["secondary-paths"] = {"secondary-path": secondaryPathArray}
        logger.debug("extractLSPProperties: secondaryPathArray = {}\n defaultTargetData = {}", JSON.stringify(secondaryPathArray), JSON.stringify(defaultTemplateDataMap));
        // Secondary-path - end

        // Containers inside primary and secondary paths - start
        var secondaryPathIndex = 0;
        for (var index = 0; index < deviceConfig["children-Set"]["mpls.LspPath"].length; index++) {
            var lspPathConfig = deviceConfig["children-Set"]["mpls.LspPath"][index];

            var provisionedPathPayload = this.fetchProvisionedPath(lspPathConfig["fromNodeId"], lspPathConfig["resourceId"]);
            var provisionedPathResponse = nfmpMediator.post("/v3/search", provisionedPathPayload);
            if (!provisionedPathResponse.success) {
                throw new RuntimeException("Failed to find provisionedPath on NE " + neId);
            }
            var provisionedPathResponse = provisionedPathResponse.response;
            var provisionedPathConfig = null;
            if(provisionedPathResponse != null && provisionedPathResponse["mpls.ProvisionedPath"] && provisionedPathResponse["mpls.ProvisionedPath"]["children-Set"] && provisionedPathResponse["mpls.ProvisionedPath"]["children-Set"]["mpls.ProvisionedHop"]) {
                if(!Array.isArray(provisionedPathResponse["mpls.ProvisionedPath"]["children-Set"]["mpls.ProvisionedHop"])){
                    provisionedPathResponse["mpls.ProvisionedPath"]["children-Set"]["mpls.ProvisionedHop"] = [provisionedPathResponse["mpls.ProvisionedPath"]["children-Set"]["mpls.ProvisionedHop"]]
                }
                provisionedPathConfig = provisionedPathResponse["mpls.ProvisionedPath"]["children-Set"]["mpls.ProvisionedHop"];
            }
            logger.debug("extractLSPProperties: provisionedPathResponse = {}", JSON.stringify(provisionedPathResponse));
            logger.info("extractLSPProperties: lspPathConfig = {}", JSON.stringify(lspPathConfig));
            if (lspPathConfig["type"] == "primary" && lspPathConfig["name"] != "hopless") {
                // Add Admin-group (path-affinity-names) and HopLimit container properties
                logger.info("extractLSPProperties: lspPathConfig primary");
                this.extractAdminGroup(lspPathConfig, deviceConfig["sourceNodeId"], defaultTemplateDataMap, mappings);

                if (provisionedPathConfig != null) {
                    var routeObjectIncludeExcludeArray = this.extractProvisionedHopProperties(defaultTemplateDataMap["prim-route-object-include-exclude"],
                        provisionedPathConfig);
                    defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["explicit-route-objects-always"]["route-object-include-exclude"] = routeObjectIncludeExcludeArray;
                }
                logger.debug("extractLSPProperties: primary routeObjectIncludeExcludeArray = {}\n defaultTargetData = {}", JSON.stringify(routeObjectIncludeExcludeArray), JSON.stringify(defaultTemplateDataMap));
            } else if (lspPathConfig["type"] == "secondary" || lspPathConfig["type"] == "standby") {
                logger.info("extractLSPProperties: lspPathConfig standby");
                // Add Restoration property
                if(lspPathConfig["type"] == "standby") {
                    defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][secondaryPathIndex]["restoration"] = {
                        "enable": true,
                        "restoration-scheme": "restoration-scheme-presignaled"
                    }
                }

                if(lspPathConfig["enableSrlg"] == "true") {
                    defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][secondaryPathIndex]["disjointness"] = "srlg"
                }

                // Adding Restoration done

                // Add Admin-group (path-affinity-names) and HopLimit container properties
                this.extractAdminGroup(lspPathConfig, deviceConfig["sourceNodeId"], defaultTemplateDataMap, mappings, secondaryPathIndex);

                if(provisionedPathConfig != null) {
                    var routeObjectIncludeExcludeArray = this.extractProvisionedHopProperties(defaultTemplateDataMap["prim-route-object-include-exclude"],
                        provisionedPathConfig);
                    defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][secondaryPathIndex]["explicit-route-objects-always"]["route-object-include-exclude"] = routeObjectIncludeExcludeArray;
                }
                logger.debug("extractLSPProperties: secondary routeObjectIncludeExcludeArray = {}\n defaultTargetData = {}", JSON.stringify(routeObjectIncludeExcludeArray), JSON.stringify(defaultTemplateDataMap));
                secondaryPathIndex++;
            }
        }
        // Containers withing primary and secondary paths - end

        return defaultTemplateDataMap["default-target-data"];
    }

    this.populatePathComputationMethod = function (pathComputationMethod, defaultTemplateDataMap) {
        if (pathComputationMethod == "pce") {
            defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["use-path-computation"] = true;
        } else {
            defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["use-path-computation"] = false;
        }
    }

    this.fetchProvisionedPath = function (fromNodeId, resourceId) {
        var jsonPayLoad = {
            "fullClassName": "mpls.ProvisionedPath",
            "filter": {
                "and": {
                    "equal": [{
                        "name": "fromNodeId",
                        "value": fromNodeId
                    },
                        {
                            "name": "pathId",
                            "value": resourceId
                        }]
                }
            }
        };
        return jsonPayLoad;
    }

    // Populate global priorities with primary path priorities
    this.populateGlobalPriorities = function (defaultTemplateDataMap, setupPriority, holdPriority) {
        defaultTemplateDataMap["default-target-data"]["setup-priority"] = setupPriority;
        defaultTemplateDataMap["default-target-data"]["hold-priority"] = holdPriority;
    }

    /**
     * Fills ProvisionedHop attributes for the given lspPath.
     */
    this.extractProvisionedHopProperties = function (defaultTemplateDataMap, provisionedPathConfig) {
        logger.info("extractProvisionedHopProperties: defaultTemplateDataMap = {}, \nprovisionedPathConfig = {}",
            JSON.stringify(defaultTemplateDataMap), JSON.stringify(provisionedPathConfig));
        var resultArray = [];
        var targetData = defaultTemplateDataMap[0];
        for (var i = 0; i < provisionedPathConfig.length; i++) {
            var deviceConfig = provisionedPathConfig[i];
            targetData["index"] = deviceConfig["hopId"];
            if(targetData["numbered-node-hop"] != null && typeof targetData["numbered-node-hop"] === 'object') {
                targetData["numbered-node-hop"]["node-id"] = deviceConfig["ipAddress"];
                targetData["numbered-node-hop"]["hop-type"] = deviceConfig["type"];
            }
            resultArray.push(JSON.parse(JSON.stringify(targetData)));
        }
        return resultArray;
    }

    /**
     * Fills AdminGroup attributes for the given lspPath.
     */
    this.extractAdminGroup = function (lspPathConfig, neId, defaultTemplateDataMap, mappings, secondaryPathIndex) {
        logger.info("extractAdminGroup: neId = {}", neId);
        templateObj = lspPathConfig["type"] == "primary" ? defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0] : defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][secondaryPathIndex];
        var propertyInheritance = lspPathConfig["propertyInheritance"];

        if (propertyInheritance && propertyInheritance.length > 0) {
            var pathAffinityNames = {};

            for (var index = 0; index < propertyInheritance.length; index++) {
                var propertyKey = propertyInheritance[index];
                if(propertyKey == "hopLimit") {
                    this.extractHopLimit(lspPathConfig, defaultTemplateDataMap, mappings, secondaryPathIndex);
                } else {
                    var adminGroupInput = lspPathConfig[propertyKey];
                    var adminGroupMap = [];
                    for (var i = 0; i < 32; i++) {
                        if (((1 << i) & adminGroupInput) != 0) {
                            // Get displayName for value i and then push its value
                            var displayedName = this.getDisplayedNameForAdminGroup(i, neId)
                            if (displayedName) {
                                adminGroupMap.push(this.getDisplayedNameForAdminGroup(i, neId));
                            }
                        }
                    }
                    pathAffinityNames[propertyKey] = adminGroupMap;
                }
            }

            // Update path-affinity-names into templateObj
            var pathAffinityNameArray = [];
            if (pathAffinityNames["adminGroupInclude"]) {
                var affinityNameArray = [];
                pathAffinityNames["adminGroupInclude"].forEach(function (displayedName) {
                    affinityNameArray.push({"name": displayedName})
                })
                pathAffinityNameArray.push({
                    "usage": "resource-aff-include-any",
                    "affinity-name": affinityNameArray
                });
            }

            if (pathAffinityNames["adminGroupExclude"]) {
                var affinityNameArray = [];
                pathAffinityNames["adminGroupExclude"].forEach(function (displayedName) {
                    affinityNameArray.push({"name": displayedName})
                })
                pathAffinityNameArray.push({
                    "usage": "resource-aff-exclude-any",
                    "affinity-name": affinityNameArray
                });
            }

            if (pathAffinityNameArray.length > 0) {
                templateObj["path-affinity-names"] = {
                    "path-affinity-name": pathAffinityNameArray
                };
            }
            logger.info("extractAdminGroup: returning, templateObj = {}", JSON.stringify(templateObj))
        }
    }

    /**
     * Fills HopLimit attributes for the given lspPath.
     */
    this.extractHopLimit = function (lspPathConfig, defaultTemplateDataMap, mappings, secondaryPathIndex) {
        logger.info("extractHopLimit: lspPathConfig = {}", JSON.stringify(lspPathConfig));
        if(lspPathConfig["type"] == "primary") {
            var primPathMBArray = this.extractContainerProperties(
                defaultTemplateDataMap["prim-path-metric-bound"],
                [lspPathConfig],
                mappings["primary-paths"]["primary-path"][0]["path-metric-bounds"]["path-metric-bound"][0]);

            if (primPathMBArray.length > 0) {
                primPathMBArray[0]["metric-type"] = "path-metric-hop";
                defaultTemplateDataMap["default-target-data"]["primary-paths"]["primary-path"][0]["path-metric-bounds"] = {
                    "path-metric-bound": primPathMBArray
                }
            }
        }else {
            var secPathMBTemplate;
            var secondaryPathArray = defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"];
            if (secondaryPathArray.length > 1) {
                secPathMBTemplate = JSON.parse(JSON.stringify(defaultTemplateDataMap["sec-path-metric-bound"]));
            } else {
                secPathMBTemplate = defaultTemplateDataMap["sec-path-metric-bound"];
            }
            var secPathMBArray = this.extractContainerProperties(
                secPathMBTemplate,
                [lspPathConfig],
                mappings["secondary-paths"]["secondary-path"][0]["path-metric-bounds"]["path-metric-bound"][0]);

            if (secPathMBArray.length > 0) {
                secPathMBArray[0]["metric-type"] = "path-metric-hop";
                defaultTemplateDataMap["default-target-data"]["secondary-paths"]["secondary-path"][secondaryPathIndex]["path-metric-bounds"] = {
                    "path-metric-bound": secPathMBArray
                }
            }
        }
    }

    this.extractProperties = function (targetData, deviceConfig, mappings) {
        var keys = Object.keys(targetData);
        for (var i = 0; i < keys.length; i++) {
            var targetKey = keys[i];
            var targetObj = targetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object') {
                this.traverseAndUpdateConfig(targetKey, targetObj, mappings[targetKey], deviceConfig);
            } else {
                this.getAndUpdateFromDeviceConfig(mappings, targetKey, targetData, deviceConfig);
            }
        }
        logger.info("extractProperties: returning, targetData = {}", JSON.stringify(targetData))
    }

    /**
     * Constructs and returns the distinct mapping of Tunnel containers
     */
    this.prepareDefaultTemplateDataMap = function (defaultTargetData) {
        var primPathMBTemplate = JSON.parse(JSON.stringify(defaultTargetData["primary-paths"]["primary-path"][0]["path-metric-bound"]))
        var secPathMBTemplate = JSON.parse(JSON.stringify(primPathMBTemplate))

        var primPathROIETemplate = JSON.parse(JSON.stringify(defaultTargetData["primary-paths"]["primary-path"][0]["explicit-route-objects-always"]["route-object-include-exclude"] = [
                {
                    "index": null,
                    "explicit-route-usage": "route-include-object",
                    "numbered-node-hop": {
                        "node-id": null,
                        "hop-type": null
                    }
                }
            ]
        ))
        var secPathROIETemplate = JSON.parse(JSON.stringify(primPathROIETemplate))

        var associationDefaultTemplate;
        if (defaultTargetData["association-objects"] && defaultTargetData["association-objects"]["association-object-extended"])
        {
            associationDefaultTemplate = JSON.parse(JSON.stringify(defaultTargetData["association-objects"]["association-object-extended"]));
        }
        else {
            associationDefaultTemplate = [
                {
                    "association-key": "children-Set,mpls.PathProfile,profileId",
                    "type": null,
                    "id": "children-Set,mpls.PathProfile,profileId",
                    "source": {
                        "id": "children-Set,mpls.PathProfile,siteId",
                        "type": null
                    },
                    "global-source": null,
                    "extended-id": "children-Set,mpls.PathProfile,groupId"
                }
            ]
        }

        delete defaultTargetData["primary-paths"]["primary-path"][0]["path-metric-bound"]
        delete defaultTargetData["secondary-paths"]["secondary-path"][0]["path-metric-bound"]

        delete defaultTargetData["primary-paths"]["primary-path"][0]["path-affinity-name"]
        delete defaultTargetData["secondary-paths"]["secondary-path"][0]["path-affinity-name"]

        delete defaultTargetData["primary-paths"]["primary-path"][0]["route-object-include-exclude"]
        delete defaultTargetData["secondary-paths"]["secondary-path"][0]["route-object-include-exclude"]

        delete defaultTargetData["association-objects"];

        var primaryPathTemplate = JSON.parse(JSON.stringify(defaultTargetData["primary-paths"]["primary-path"]))
        var secondaryPathTemplate = JSON.parse(JSON.stringify(defaultTargetData["secondary-paths"]["secondary-path"]))
        delete defaultTargetData["primary-paths"];
        delete defaultTargetData["secondary-paths"];

        var defaultTemplateMap = {
            "prim-path-metric-bound": primPathMBTemplate,
            "sec-path-metric-bound": secPathMBTemplate,
            "prim-route-object-include-exclude": primPathROIETemplate,
            "sec-route-object-include-exclude": secPathROIETemplate,
            "primary-paths": primaryPathTemplate,
            "secondary-paths": secondaryPathTemplate,
            "association-object-extended": associationDefaultTemplate,
            "default-target-data": defaultTargetData
        }
        logger.debug("prepareDefaultTemplateDataMap: response = {}", JSON.stringify(defaultTemplateMap));
        return defaultTemplateMap;
    }

    /**
     * Extracts association-objects
     */
    this.extractContainerProperties = function (inputTargetData, inputDeviceConfig, mappings) {
        logger.info("extractContainerProperties: inputTargetData = {}, \ninputDeviceConfig = {}, \nmappings = {}\n",
            JSON.stringify(inputTargetData), JSON.stringify(inputDeviceConfig), JSON.stringify(mappings));
        var resultArray = [];
        var targetData = inputTargetData[0];

        for (var i = 0; i < inputDeviceConfig.length; i++) {
            var deviceConfig = inputDeviceConfig[i];
            var keys = Object.keys(targetData);
            //logger.debug("extractContainerProperties: keys = {}", JSON.stringify(keys));
            for (var j = 0; j < keys.length; j++) {
                var targetKey = keys[j];
                var targetObj = targetData[targetKey];
                var mappedKey = targetKey;
                //logger.debug("extractContainerProperties: --> targetKey = {}, mappedKey = {}", JSON.stringify(targetKey), mappedKey);

                if (targetObj !== null && typeof targetObj === 'object') {
                    var tempMappings = mappings[targetKey];
                    this.traverseAndUpdateConfig(mappedKey, targetObj, tempMappings, deviceConfig);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, targetData, deviceConfig);
                }
            }
            resultArray.push(JSON.parse(JSON.stringify(targetData)));
        }
        return resultArray;
    }

    this.traverseAndUpdateConfig = function (objKey, obj, mappings, deviceConfig) {
        var keys = Object.keys(obj);
        logger.info("traverseAndUpdateConfig: targetKey = {}, targetObj = {}, mappings = {}", objKey, JSON.stringify(obj), JSON.stringify(mappings))

        for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            var value = obj[key];
            var mappedKey = objKey + "." + key;

            logger.info("traverseAndUpdateConfig: key = {}, mappedKey = {}, value = {}", key, mappedKey, JSON.stringify(value))
            if (value !== null && typeof value === 'object') {
                var tempMappings = mappings[key];
                this.traverseAndUpdateConfig(mappedKey, value, tempMappings, deviceConfig);
            } else {
                // call for each key with string value
                this.getAndUpdateFromDeviceConfig(mappings, key, obj, deviceConfig);
            }
        }
        return obj;
    }

    this.getAndUpdateFromDeviceConfig = function (mappings, mappedKey, targetObj, deviceConfig) {
        var nfmpMappedKey = mappings[mappedKey];
        logger.debug("getAndUpdateFromDeviceConfig: mappedKey = {}, \ntargetObj = {}, \nnfmpMappedKey = {}, \nmappings = {}",
            mappedKey, JSON.stringify(targetObj), JSON.stringify(nfmpMappedKey), JSON.stringify(mappings))
        var deviceValue;
        var tempDeviceConfig = deviceConfig
        var nfmpKey = !nfmpMappedKey ? null : nfmpMappedKey.toString().split(",");

        logger.info("getAndUpdateFromDeviceConfig: nfmpKey = {}, \ntempDeviceConfig = {}", JSON.stringify(nfmpKey), JSON.stringify(tempDeviceConfig));
        for (var i = 0; nfmpKey !== null && i < nfmpKey.length; i++) {
            deviceValue = tempDeviceConfig[nfmpKey[i]];
            // Check and update tempDeviceConfig
            if (deviceValue) {
                tempDeviceConfig = deviceValue;
            }
            logger.info("getAndUpdateFromDeviceConfig: nfmpKey[{}] = {}, deviceValue = {}", i, JSON.stringify(nfmpKey[i]), JSON.stringify(deviceValue));
        }
        targetObj[mappedKey] = this.transformDeviceValue(mappedKey, deviceValue);
    }

    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue) {
            switch (mappedKey) {
                case "admin-state":
                    deviceValue = this.convertAdminStateBrownField(deviceValue);
                    break;
                case "signaling-type":
                    deviceValue = this.convertSignallingTypeBrownField(deviceValue);
                    break;
                case "color":
                    deviceValue = this.convertColorBrownField(deviceValue);
                    break;
                case "path-computation-method":
                    deviceValue = this.convertPathComputationMethodBrownField(deviceValue);
                    break;
                case "protection-type":
                    deviceValue = this.convertProtectionTypeBrownField(deviceValue);
                    break;
                case "generic":
                    deviceValue = (deviceValue *= 1000000).toString();
                    break;
            }
            return deviceValue;
        }
    }

    this.convertAdminStateBrownField = function (adminState) {
        if (adminState == "lspUp") {
            return "tunnel-admin-state-up";
        } else if (adminState == "lspDown") {
            return "tunnel-admin-state-down";
        }
    }

    this.convertProtectionTypeBrownField = function (protectionType) {
        if (protectionType == "oneToOne") {
            return "lsp-protection-1-for-1";
        } else if (protectionType == "manyToOne") {
            return "lsp-protection-1-for-n";
        }
    }

    this.convertSignallingTypeBrownField = function (signallingType) {
        if (signallingType == "dynamic") {
            return "path-setup-rsvp";
        } else if (signallingType == "segmentRouting") {
            return "path-setup-sr"
        }
    }

    this.convertPathComputationMethodBrownField = function (pathComputationMethod) {
        if (pathComputationMethod == "pce") {
            return "path-locally-computed";
        } else if (pathComputationMethod == "localCspf") {
            return "path-externally-queried";
        } else if (pathComputationMethod == "none") {
            return null;
        }
    }

    this.convertColorBrownField = function (color) {
        for(var colorValue in colorAdminTagMapping) {
            if(colorAdminTagMapping[colorValue] == color)
                return colorValue;
        }
    }

    this.clearEmpties = function (o) {
        for (var k in o) {
            if (!o[k] || typeof o[k] !== "object") {
                continue
            }
            this.clearEmpties(o[k]);
            if (Object.keys(o[k]).length === 0) {
                delete o[k];
            }
        }
    }
}
