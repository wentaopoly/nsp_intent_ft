var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("model-device-mapping.js"), name: "model-device-mapping"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});

var sap_egress_full_class_name = "sasqos.AccessEgress";
var sap_egress_fdn = "sasAccessEgress";

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let modelDeviceMapping = new ModelDeviceMapping();
    let util = new utilities();

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let sapEgressPolicyId = util.getSapEgressPolicyId(target);
        let searchPayLoad = this.constructSearchString(neId, sapEgressPolicyId);
        let searchResponse = nfmpFwk.post("/v3/search", searchPayLoad);
        if (!searchResponse.success)
        {
            throw new RuntimeException("Failed to find Sap Egress Policy  : " + sapEgressPolicyId + " on NE " + neId);
        }
        let finalResponse = JSON.parse(searchResponse.response);
        if (JSON.stringify(finalResponse) === JSON.stringify({})) {
            throw new RuntimeException("search results is empty for policy : " + sapEgressPolicyId + " finalResponse: " + JSON.stringify(finalResponse));
        }
        else if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse[sap_egress_full_class_name]];
            logger.info(LOG_PREFIX + "Search results: " + JSON.stringify(finalResponse));
        }
        return finalResponse[0];
    }

    this.constructSearchString = function (neId, sapEgressPolicyId) {
        let objectFullName = "network:" + neId + ":" + sap_egress_fdn + ":" + sapEgressPolicyId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        let jsonPayLoad = {
            "fullClassName": sap_egress_full_class_name,
            "filter": {
                "equal": {
                    "name": "objectFullName",
                    "value": objectFullName
                }
            }
        };
        return jsonPayLoad;
    }

    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedTargetData = JSON.parse(defaultTargetData)[initialPropertyName];
        let loadingTargetData = JSON.parse(JSON.stringify(parsedTargetData));
        this.extractNonChildProperties(parsedTargetData, deviceConfig);
        let sapEgressChildConfigs = deviceConfig["children-Set"];
        for (let childAttribute in sapEgressChildConfigs) {
            switch (childAttribute) {
                case "sasqos.QueueEntry":
                    {
                        let sapEgressQueueConfig = sapEgressChildConfigs[childAttribute];
                        parsedTargetData["queue"] = this.extractDeviceProperties(sapEgressQueueConfig, loadingTargetData["queue"][0], "queue");
                        break;
                    }
                case "sasqos.AccessEgressForwardingClass":
                    {
                        let sapEgressFc = sapEgressChildConfigs[childAttribute];
                        parsedTargetData["fc"] = this.extractDeviceProperties(sapEgressFc, loadingTargetData["fc"][0], "fc");
                        break;
                    }
            }
        }
        let finalTargetData = {};
        finalTargetData[initialPropertyName] = parsedTargetData;
        logger.info(LOG_PREFIX + "Intent data after updating from NFMP: \n" + JSON.stringify(finalTargetData));
        return finalTargetData;
    }

    this.extractNonChildProperties = function (parsedTargetData, deviceConfig) {
        let sapEgressMapping = modelDeviceMapping.getMapping("sap-egress");
        delete parsedTargetData["fc"];
        delete parsedTargetData["queue"];
        this.traverseAndUpdateConfig("sap-egress", parsedTargetData, deviceConfig, sapEgressMapping);
        logger.info(LOG_PREFIX + "Updated non child properties Sap Egress - " + JSON.stringify(parsedTargetData));
    }

    this.extractDeviceProperties = function (configData, defaultDataObj, keyPrefix) {
        let configDataArray = [];
        let mappings = modelDeviceMapping.getMapping(keyPrefix);
        if (!Array.isArray(configData)) {
            configData = [configData];
        }
        for (let idx in configData) {
            let configDataObj = configData[idx];
            let defData = JSON.parse(JSON.stringify(defaultDataObj));
            this.traverseAndUpdateConfig(keyPrefix, defData, configDataObj, mappings);
            configDataArray.push(defData);
        }
        logger.info(LOG_PREFIX + "parsedTargetData for: " + keyPrefix + ": " + JSON.stringify(configDataArray));
        return configDataArray;
    }

    this.traverseAndUpdateConfig = function (objKey, defDataObj, deviceConfig, mappings) {
        let keys = Object.keys(defDataObj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = defDataObj[key];
            let mappedKey = objKey + "." + key;
            if (value != null && typeof value === "object") {
                this.traverseAndUpdateConfig(mappedKey, value, deviceConfig, mappings)
            }
            else {
                let nfmpKey = mappings[mappedKey];
                if (mappedKey === "queue.rate.pir" && parseInt(deviceConfig[nfmpKey]) < 0) {
                    delete defDataObj[key]
                }
                else {
                    defDataObj[key] = this.transformDeviceValue(mappedKey, deviceConfig[nfmpKey]);
                }
            }
        }
        return defDataObj;
    }

    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue != null) {
            switch (mappedKey) {
                case "sap-egress.dot1p-classification":
                    deviceValue = deviceValue.split(":Dot1p-")[1];
                    break;
                case "sap-egress.dscp-classification":
                case "sap-egress.ip-prec-classification":
                    deviceValue = deviceValue.split(":Dscp-")[1];
                    break;
                case "sap-egress.remark":
                case "queue.queue-mgmt":
                case "queue.slope-policy":
                    deviceValue = deviceValue.split(":")[1];
                    break;
                case "queue.rate.pir":
                case "queue.rate.cir":
                    if (deviceValue === "-1") {
                        deviceValue = "max";
                    }
                    break;
            }
            return deviceValue;
        }
    }
}
