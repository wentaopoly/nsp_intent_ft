load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
load({script: resourceProvider.getResource("parse-target.js"), name: "ParseTarget"});

function CustomHooks() {
    /**
     * PreAudit Hook
     */
    const preAudit = (inputObj) => {
        /**
         * Write your custom preAudit logic here
         * inputObj by default contains the following keys:
         *          target, intentConfig, svcTopo, adminState,
         *          intentTypeName, rootXPath, intentContainer,
         *          uniqueIdentifier, deviceYangModuleName
         *
         */

        logger.info("[CUSTOM-HOOKS] preAudit call");
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
        var target = inputObj["target"];
        var isBreakoutPort = String(target.split("#")[2]).indexOf("/c") !== -1;
        var intentConfig = inputObj["intentConfig"];

        if(isBreakoutPort){
            if(intentConfig["ddm-events"] !== undefined){
                if(intentConfig["ddm-events"] == false)
                {
                    delete intentConfig["ddm-events"];
                }
            }
        }

        logger.info("preAudit call for Port MD intent config deviation");
        var intentDeviationObj = new IntentDeviceDeviation();
        var neId = parseTarget.getNeIdFromTarget(target);
        intentConfig = intentDeviationObj.removeIntentConfig(JSON.stringify(intentConfig), neId);
        logger.info("preAudit intent config after removing deviation attributes: " + JSON.stringify(intentConfig));
        return intentConfig;
    };

    /**
     * PostAudit Hook
     */
    const postAudit = (inputObj) => {
        /**
         * Write your custom postAudit logic here
         * inputObj by default contains the following keys:
         *          target, intentConfig, svcTopo, adminState,
         *          intentTypeName, rootXPath, intentContainer,
         *          uniqueIdentifier, deviceYangModuleName, auditReport
         *
         */

        logger.info("[CUSTOM-HOOKS] postAudit call");
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));


    };

    /**
     * PreSync Hook
     */
    const preSync = (inputObj) => {
        /**
         * Write your custom preSync logic here
         * inputObj by default contains the following keys:
         *          target, config, intentTypeName, rootXPath,
         *          intentContainer, uniqueIdentifier, deviceYangModuleName
         *          topology, state, syncResult
         */
        logger.info("[CUSTOM-HOOKS] preSync call");
        var config = JSON.parse(inputObj["config"]);
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

        var target = inputObj["target"];
        var isBreakoutPort = String(target.split("#")[2]).indexOf("/c") !== -1;
        var intentTypeName = inputObj["intentTypeName"];
        var intentContainer = inputObj["intentContainer"];
        var intentDeviationObj = new IntentDeviceDeviation();
        var neId = parseTarget.getNeIdFromTarget(target);
        if (!Array.isArray(config)) {
            config = [config];
        }
        let preSyncConf = [];
        for (var index in config) {
            var confObj= config[index][intentTypeName + ":" + intentTypeName][intentContainer];
            if(isBreakoutPort){
                if(confObj["ddm-events"] !== undefined){
                    if(confObj["ddm-events"] == false)
                    {
                        delete confObj["ddm-events"];
                    }
                }
            }
            if (confObj["ethernet"]["mode"] !== undefined ){
                let ethernetMode = confObj["ethernet"]["mode"];
                if (ethernetMode == 'access'){
                    delete confObj["ethernet"]["network"];
                }
                if (ethernetMode == 'network' ){
                    delete confObj["ethernet"]["access"];
                }
            }else {
                delete confObj["ethernet"]["access"];
            }
            let configObj = JSON.stringify(confObj);
            let deviatedObj = intentDeviationObj.removeIntentConfig(configObj, neId);
            let finalConfigObj = {};
            let intentKey = intentTypeName + ":" + intentTypeName
            finalConfigObj[intentKey] = {};
            finalConfigObj[intentKey][intentContainer] = deviatedObj;
            preSyncConf.push(finalConfigObj);
        }
        logger.info("intent config after removing deviation attributes: " + JSON.stringify(preSyncConf));
        return JSON.stringify(preSyncConf);
    };

    /**
     * PostSync Hook
     */
    const postSync = (inputObj) => {
        /**
         * Write your custom postSync logic here
         * inputObj by default contains the following keys:
         *          target, config, intentTypeName, rootXPath,
         *          intentContainer, uniqueIdentifier, deviceYangModuleName
         *          topology, state, syncResult
         */
        logger.info("[CUSTOM-HOOKS] postSync call");
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

    };

    /**
     *
     * PostDiscovery Hook
     */
    const postDiscovery = (inputObj) => {
        /**
         * Write your custom postDiscovery logic here
         * inputObj by default contains the following keys:
         *        deviceConfig, intentContainer, neId,
         *        targetDataStruct, templateName, deviceYangModuleName
         */

        logger.info("[CUSTOM-HOOKS] postDiscovery call");
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

    }

    this.preAudit = preAudit;
    this.postAudit = postAudit;
    this.preSync = preSync;
    this.postSync = postSync;
    this.postDiscovery = postDiscovery;

}