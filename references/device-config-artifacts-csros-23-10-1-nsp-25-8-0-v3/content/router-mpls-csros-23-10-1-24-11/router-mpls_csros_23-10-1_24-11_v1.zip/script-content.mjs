/********************************************************************************
 * DEVICE-SPECIFIC INTENT-TYPE USED FOR NSP DEVICE CONFIGURATION (ICM)
 *   Vendor: Nokia
 *   Device families: 7750 SR, 7450 ESS, 7950 XRS, 7705 SAR, 7250 IXR
 *   Device version: 23.10.R1
 *
 * (c) 2025 by Nokia
 ********************************************************************************/

import { IntentHandlerBase }  from 'common/IntentHandlerBase.mjs';
import { NSP }  from 'common/NSP.mjs';
const HashMap = Java.type("java.util.HashMap");

class IntentHandler extends (IntentHandlerBase) {
  constructor() {
    super();
    this.greenFieldObjectFullName = "network:$systemAddress:router-1:mpls";
    this.greenFieldFDN = "network:$systemAddress:router-1";
    this.brownFieldObjectFullName = "network:$systemAddress:router-1:mpls";
    this.isPolicyIntent = false;
    this.initialPropertyName = "mpls-Site";
    this.uniqueIdentifier = "mpls";
    NSP.checkRelease(24, 11);
    this.ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,5}(:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){6}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(\/(0|[1-9][0-9]?|1[0-1][0-9]?|12[0-8]))?$/;
  }

  // WebUI suggest/picker callouts:
 suggestMPLS(context) {
   return java.util.Map.of("mpls", "mpls");
 }

  suggestIngressAccountingPolicy(context) {
      logger.info("Suggest Ingress Accounting Policy ID Context = \n" + context);
      let className = "accounting.Policy",
          neId = this.getNeId(context),
          attribute = "id";
      let searchObject = {
          "fullClassName": className,
          "filter": {
              "and": {
                  "equal": [{
                          "name": "siteId",
                          "value": neId
                      },
                      {
                          "name": "recordType",
                          "value": "combinedMplsLspIngress"
                      },
                      {
                          "name": "isDefault",
                          "value": "false"
                      }
                  ]
              }
          },
          "resultFilter": {
              "children": "",
              "attribute": [
                  attribute
              ]
          }
      };
      return this.getData(neId, searchObject, className, attribute);
  }


  suggestSrlbReservedLabelBlockNameBrownfield(neId, objectFullName) {
      let className = "mpls.ReservedLabelBlock",
          attribute = "labelBlockName";
      let searchObject = {
          "fullClassName": className,
          "filter": {
              "and": {
                  "equal": [{
                          "name": "siteId",
                          "value": neId
                      },
                      {
                          "name": "objectFullName",
                          "value": objectFullName
                      }
                  ]
              }
          },
          "resultFilter": {
              "children": "",
              "attribute": [
                  attribute
              ]
          }
      };
      let resultMap = this.getData(neId, searchObject, className, attribute);
      let singleValue;
      for (let entry of resultMap.entrySet()) {
          singleValue = entry.getValue();
          break; // only need first
      }
      return singleValue;
  }

  suggestSrlbReservedLabelBlockName(context) {
      let className = "mpls.ReservedLabelBlock",
          neId = this.getNeId(context),
          attribute = "labelBlockName";
      let searchObject = {
          "fullClassName": className,
          "filter": {
              "and": {
                  "equal": [{
                      "name": "siteId",
                      "value": neId
                  }]
              }
          },
          "resultFilter": {
              "children": "",
              "attribute": [
                  attribute
              ]
          }
      };

      return this.getData(neId, searchObject, className, attribute);
  }


  //overwrite methods
  transformPayloadGreenField(payload, neId, isAudit) {
  	if (payload["configInfo"]["mpls.Site"]) {
        if(payload["configInfo"]["mpls.Site"]["mpls"]){
            delete payload["configInfo"]["mpls.Site"]["mpls"];
        }
  		var lspBsidBlkName = payload["configInfo"]["mpls.Site"]["lspBsidBlkName"];
  		if (lspBsidBlkName) {
              if (neId && String(neId).indexOf(':') !== -1) {
                  lspBsidBlkName = 'network:' + neId + ':router-1:rlb-' + lspBsidBlkName;
                  lspBsidBlkName = this.modifyNeIdForIpV6(lspBsidBlkName, neId);
              }else{
                  lspBsidBlkName = 'network:' + neId + ':router-1:rlb-' + lspBsidBlkName;
              }

  		} else {
  			lspBsidBlkName = '';
  		}
  		payload["configInfo"]["mpls.Site"]["lspBsidBlkName"] = lspBsidBlkName;
  	}
  	if (payload["configInfo"]["mpls.Site"]["children-Set"] && payload["configInfo"]["mpls.Site"]["children-Set"]["mpls.IngStatsPolicy"]) {
  		for (var index in payload["configInfo"]["mpls.Site"]["children-Set"]["mpls.IngStatsPolicy"]) {
  			var IngStatsPolicyConfig = payload["configInfo"]["mpls.Site"]["children-Set"]["mpls.IngStatsPolicy"][index];
  			if (!IngStatsPolicyConfig["ingAccountingPolicyObjectPointer"]) {
  				IngStatsPolicyConfig["ingAccountingPolicyObjectPointer"] = '';
  			}
  			if (IngStatsPolicyConfig["senderAddress"]) {
  				IngStatsPolicyConfig["ipAddressType"] = "ipv4";
  			}
  			payload["configInfo"]["mpls.Site"]["children-Set"]["mpls.IngStatsPolicy"][index] = IngStatsPolicyConfig;
  		}
  	}
  	if (payload["configInfo"]["mpls.Site"]["children-Set"] && payload["configInfo"]["mpls.Site"]["children-Set"]["mpls.LspTemplateIngStatsPolicy"]) {
  		for (var index in payload["configInfo"]["mpls.Site"]["children-Set"]["mpls.LspTemplateIngStatsPolicy"]) {
  			var lspTemplateIngStatsPolicyConfig = payload["configInfo"]["mpls.Site"]["children-Set"]["mpls.LspTemplateIngStatsPolicy"][index];
  			if (!lspTemplateIngStatsPolicyConfig["accountingPolicyObjectPointer"]) {
  				lspTemplateIngStatsPolicyConfig["accountingPolicyObjectPointer"] = '';
  			}
  			if (lspTemplateIngStatsPolicyConfig["senderAddress"]) {
  				lspTemplateIngStatsPolicyConfig["senderAddressType"] = "ipv4";
  			}
  			payload["configInfo"]["mpls.Site"]["children-Set"]["mpls.LspTemplateIngStatsPolicy"][index] = lspTemplateIngStatsPolicyConfig;
  		}
  	}
  	if (payload["configInfo"]["mpls.Site"] && payload["configInfo"]["mpls.Site"]["children-Set"] && payload["configInfo"]["mpls.Site"]["children-Set"]["mpls.ForwardingPolicyGeneral"]) {
  		var forwardingPolicyGeneralConfig = payload["configInfo"]["mpls.Site"]["children-Set"]["mpls.ForwardingPolicyGeneral"];
  		if (forwardingPolicyGeneralConfig["srlbReservedLabelBlock"]) {
             if (neId && String(neId).indexOf(':') !== -1) {
                 forwardingPolicyGeneralConfig["srlbReservedLabelBlock"] = 'network:' + neId + ':router-1:rlb-' + forwardingPolicyGeneralConfig["srlbReservedLabelBlock"];
                 forwardingPolicyGeneralConfig["srlbReservedLabelBlock"] = this.modifyNeIdForIpV6(forwardingPolicyGeneralConfig["srlbReservedLabelBlock"], neId);
             }else{
                 forwardingPolicyGeneralConfig["srlbReservedLabelBlock"] = 'network:' + neId + ':router-1:rlb-' + forwardingPolicyGeneralConfig["srlbReservedLabelBlock"];
             }
  		} else {
  			forwardingPolicyGeneralConfig["srlbReservedLabelBlock"] = '';
  		}
  		if (forwardingPolicyGeneralConfig["children-Set"] && forwardingPolicyGeneralConfig["children-Set"]["mpls.ForwardingPolicy"]) {
  			for (var i in forwardingPolicyGeneralConfig["children-Set"]["mpls.ForwardingPolicy"]) {
  				var mplsForwardingPolicyConfig = forwardingPolicyGeneralConfig["children-Set"]["mpls.ForwardingPolicy"][i];
  				if (mplsForwardingPolicyConfig["children-Set"] && mplsForwardingPolicyConfig["children-Set"]["mpls.NextHopGroup"]) {
  					for (var j in mplsForwardingPolicyConfig["children-Set"]["mpls.NextHopGroup"]) {
  						var mplsNextHopGroupConfig = mplsForwardingPolicyConfig["children-Set"]["mpls.NextHopGroup"][j];
                        if(mplsNextHopGroupConfig){
                             mplsNextHopGroupConfig["policyName"] = mplsForwardingPolicyConfig["policyName"];
                        }
                        if (mplsNextHopGroupConfig["children-Set"] && mplsNextHopGroupConfig["children-Set"]["mpls.NextHop"]) {
                            for (var k in mplsNextHopGroupConfig["children-Set"]["mpls.NextHop"]) {
                                var mplsNextHopConfig = mplsNextHopGroupConfig["children-Set"]["mpls.NextHop"][k];
                                if (mplsNextHopConfig["nextHopAddress"] && String(mplsNextHopConfig["nextHopAddress"]).indexOf(":") !== -1) {
                                    mplsNextHopConfig["nextHopAddressType"] = "ipv6";
                                    mplsNextHopConfig["groupId"] = mplsNextHopGroupConfig["groupId"];
                                    mplsNextHopConfig["policyName"] = mplsForwardingPolicyConfig["policyName"];
                                } else if (mplsNextHopConfig["nextHopAddress"] && String(mplsNextHopConfig["nextHopAddress"]).indexOf(":") === -1) {
                                    mplsNextHopConfig["nextHopAddressType"] = "ipv4";
                                    mplsNextHopConfig["policyName"] = mplsForwardingPolicyConfig["policyName"];
                                    mplsNextHopConfig["groupId"] = mplsNextHopGroupConfig["groupId"];
                                }
                                mplsNextHopGroupConfig["children-Set"]["mpls.NextHop"][k] = mplsNextHopConfig;
                            }
                        }else {
                            if(!mplsNextHopGroupConfig["children-Set"]){
                                mplsNextHopGroupConfig["children-Set"] = {};
                            }
                            mplsNextHopGroupConfig["children-Set"]["mpls.NextHop"] = [];
                        }
  						mplsForwardingPolicyConfig["children-Set"]["mpls.NextHopGroup"][j] = mplsNextHopGroupConfig;
  					}
  				}else{
                    if(!mplsForwardingPolicyConfig["children-Set"]){
                        mplsForwardingPolicyConfig["children-Set"] = {};
                    }
                    mplsForwardingPolicyConfig["children-Set"]["mpls.NextHopGroup"] = [];
                }
                if(mplsForwardingPolicyConfig["children-Set"] && !mplsForwardingPolicyConfig["children-Set"]["mpls.ForwardingPolicyStatsConfig"]){
                    mplsForwardingPolicyConfig["children-Set"]["mpls.ForwardingPolicyStatsConfig"] = [];
                }else if(!mplsForwardingPolicyConfig["children-Set"] && !mplsForwardingPolicyConfig["children-Set"]["mpls.ForwardingPolicyStatsConfig"]){
                    mplsForwardingPolicyConfig["children-Set"] = {};
                    mplsForwardingPolicyConfig["children-Set"]["mpls.ForwardingPolicyStatsConfig"] = [];
                }
  				forwardingPolicyGeneralConfig["children-Set"]["mpls.ForwardingPolicy"][i] = mplsForwardingPolicyConfig;
  			}
  		}else {
            if(!forwardingPolicyGeneralConfig["children-Set"]){
                forwardingPolicyGeneralConfig["children-Set"] = {};
            }
            forwardingPolicyGeneralConfig["children-Set"]["mpls.ForwardingPolicy"] = [];
        }
  		payload["configInfo"]["mpls.Site"]["children-Set"]["mpls.ForwardingPolicyGeneral"] = forwardingPolicyGeneralConfig;
  	}
  	if (payload["configInfo"]) {
  		payload = this.expandIPv6(payload);
  	}
  	return payload;
  }

  // Expand all IPv6 strings in intentJSON
  expandIPv6(intentJSON) {
    this.traverse(intentJSON);
    return intentJSON;
  }

  // Recursively scan and expand IPv6 strings in object
  traverse(obj) {
    for (var key in obj) {
      if (typeof obj[key] === 'object' && obj[key] !== null) this.traverse(obj[key]);
      else if (typeof obj[key] === 'string' && this.matchExact(this.ipv6Regex, obj[key]))
        obj[key] = this.expandIPv6AddressForClassic(obj[key]);
    }
  }

  // Strict string{str} match with regex{r}
  matchExact(r, str) {
    var match = str.match(r);
    return match && str === match[0];
  }

  // Convert compressed IPv6 (incl. IPv4-mapped) to full form
  expandIPv6AddressForClassic(address) {
    var fullAddress = "",
      validGroupCount = 8,
      ipv4 = "";
    var extractIpv4 = /([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})/;
    var validateIpv4 = /((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})/;

    if (validateIpv4.test(address)) {
      var groups = address.match(extractIpv4);
      for (var i = 1; i < groups.length; i++)
        ipv4 += ("0" + parseInt(groups[i], 10).toString(16)).slice(-2) + (i == 2 ? ":" : "");
      address = address.replace(extractIpv4, ipv4);
    }

    if (address.indexOf("::") == -1) fullAddress = address;
    else {
      var sides = address.split("::"),
        groupsPresent = 0;
      for (var i = 0; i < sides.length; i++) groupsPresent += sides[i].split(":").length;
      fullAddress += (sides[0] ? sides[0] : 0) + ":";
      for (var i = 0; i < validGroupCount - groupsPresent; i++) fullAddress += "0:";
      fullAddress += sides[1] ? (sides[1].split("/")[0] || "0") + (sides[1].split("/")[1] ? "/" + sides[1].split("/")[1] : "") : "0";
    }

    return this.removeLeadingZerosFromIPv6(fullAddress).toUpperCase();
  }

  // Strip leading zeros from each IPv6 segment
  removeLeadingZerosFromIPv6(ipv6Address) {
    var octets = ipv6Address.split(':'),
      modifiedOctets = [];
    for (var i = 0; i < octets.length; i++) {
      var segment = octets[i];
      if (segment === '') modifiedOctets.push('');
      else if (segment.indexOf("/") !== -1) {
        var parts = segment.split("/");
        modifiedOctets.push((parts[0] ? parseInt(parts[0], 16).toString(16) : "") + "/" + parts[1]);
      } else modifiedOctets.push(parseInt(segment, 16).toString(16));
    }
    return modifiedOctets.join(':');
  }

  transformTargetValueGreenField(xpath, targetValue, targetKey, neId, isAudit) {
      if (xpath === "mpls-IngStatsPolicy.ingAccountingPolicyObjectPointer" || xpath === "mpls-LspTemplateIngStatsPolicy.accountingPolicyObjectPointer") {
          targetValue = 'Accounting:' + targetValue;
      }
      return targetValue;
  }

  transformTargetValueBrownField(xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
      if (xpath === "mpls-IngStatsPolicy.ingAccountingPolicyObjectPointer" || xpath === "mpls-LspTemplateIngStatsPolicy.accountingPolicyObjectPointer") {
          targetValue = targetValue.replace('Accounting:', '');
      }
      if (xpath === "mpls-ForwardingPolicyGeneral.srlbReservedLabelBlock" || xpath === "lspBsidBlkName") {
          targetValue = this.suggestSrlbReservedLabelBlockNameBrownfield(fullDeviceConfig["siteId"], targetValue)
      }
      return targetValue;
  }

  reportMisaligned(target, result, auditReport) {
      let report = JSON.parse(result.response);
      if (!report.aligned) {
          report.misalignedAttributes.forEach(attributeData => {
              if ((attributeData.name).indexOf("pceReport") > -1) {
                  if (this.arraysAreEqual(attributeData.expected, attributeData.actual)) {
                      return; // skip this entry in forEach
                  }
              }
              let objectDn = attributeData.name,
                  isUndesired = attributeData.expected === "not present";
              if (attributeData.expected === "present" || isUndesired)
                  auditReport.addMisAlignedObject(auditFactory.createMisAlignedObject(objectDn, isUndesired));
              else
                  auditReport.addMisAlignedAttribute(auditFactory.createMisAlignedAttribute(objectDn, String(attributeData.expected), String(attributeData.actual), target));
          });
      }
    return auditReport;
  }
  arraysAreEqual(arr1, arr2) {
      if (!Array.isArray(arr1)) {
          arr1 = [arr1];
      }
      if (!Array.isArray(arr2)) {
          arr2 = [arr2];
      }
      // Check if the arrays have the same length
      if (arr1.length !== arr2.length) {
          return false;
      }

      // Sort the arrays
      var sortedArr1 = arr1.slice().sort();
      var sortedArr2 = arr2.slice().sort();

      // Compare the sorted arrays
      for (var i = 0; i < sortedArr1.length; i++) {
          if (sortedArr1[i] !== sortedArr2[i]) {
              return false; // Elements are different, arrays are not equal
          }
      }

      return true; // Arrays are equal
  }

  modifyNeIdForIpV6(objectFullName, neId){
    logger.info("modifying NeId For IpV6");
    objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
    return objectFullName;
  }
}
new IntentHandler();