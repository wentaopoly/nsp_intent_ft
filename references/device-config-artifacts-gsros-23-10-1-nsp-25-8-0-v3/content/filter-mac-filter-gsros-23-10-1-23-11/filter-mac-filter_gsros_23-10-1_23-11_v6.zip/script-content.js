var RuntimeException = Java.type("java.lang.RuntimeException");

var prefixToNsMap = {
    ibn: "http://www.nokia.com/management-solutions/ibn",
    nc: "urn:ietf:params:xml:ns:netconf:base:1.0",
    "device-manager": "http://www.nokia.com/management-solutions/anv",
};

var nsToModule = {
    "http://www.nokia.com/management-solutions/anv-device-holders":
        "anv-device-holders",
};

load({script: resourceProvider.getResource("nsp-intent-helper.js"),name: "nsp-intent-helper",});
var NspIntentHelper = new NspIntentHelper();

load({script: resourceProvider.getResource('mdt-fwk.js'), name: 'MdtFwk'});
var mdtFwk =  new MdtFwk();

load({script: resourceProvider.getResource("icm-fwk.js"), name: "icm-fwk"})
var icmFwk = new ICMFwk();

load({script: resourceProvider.getResource("gtd-fwk.js"), name: "gtd-fwk"})
var gtdFwk = new GtdFwk();


load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})
load({script: resourceProvider.getResource('mdSuggest.js'), name: 'MdSuggest'})

var LOG_PREFIX = "[MAC Filter]: "

var intentTypeName = 'filter-mac-filter_gsros_23-10-1_23-11';

var initialPropertyName = 'mac-filter';

var deviceYangModuleName = 'nokia-conf';

// unique identifier
var uniqueIdentifier = 'filterName';

var parentXpath = 'configure/filter';

function synchronize(input) {
    logger.info("Intent Synchronisation started");

    return NspIntentHelper.synchronize(input,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier,deviceYangModuleName);
}

function onAudit(target, config, svcTopo, adminState) {
    logger.info("Intent Audit started");

    return NspIntentHelper.audit(target,config,svcTopo,adminState,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier,deviceYangModuleName);
}

function getTargetData(input) {
    logger.info(input);
    var target = input.target;
    var config = null;
    logger.info("target=" + target);
    logger.info("initialPropertyName ="+ initialPropertyName)
    var deviceConfig = icmFwk.getDeviceConfiguration(target,initialPropertyName);
    logger.info(JSON.stringify(deviceConfig));
    var data = gtdFwk.gtdSend(deviceConfig);
    return data.msg.result;
}
function suggestMacFilterName(context) {
    logger.info("suggestPolicyName context = \n" + context);
    var filterId = context.getInputValues()["arguments"]["target_id"];
    logger.info("User  selected MAC filter ID : {}, searching MAC filter Name associaed to MAC filter-id - {}", filterId, filterId);
    var neId = getNeId(context);
    return navigateInstance(neId).getMacFilterName(neId, filterId);
}

function suggestMacFilterId(context) {
    logger.info("suggestPolicyId context = \n" + context);
    var filterName = context.getInputValues()["arguments"]["target_filterName"];
    logger.info("User  selected MAC filter Name : {}, searching MAC filter ID associaed to MAC filter Name - {}", filterName, filterName);
    var neId = getNeId(context);
    return navigateInstance(neId).getMacFilterId(neId, filterName);
}

function suggestFilterLog(context) {
    logger.info("suggest Filter Log Context = \n" + context);
    var neId = getNeId(context);
    return navigateInstance(neId).getFilterLog(neId);
}

function getNeId(context) {
    var neId;
    var target = context.getInputValues()["target"]["objectidentifier"];
    logger.info(LOG_PREFIX + "target : {}", target)
    if (!target)
    {
        target = context.getInputValues()["arguments"]["__root"]["target_objectidentifier"];
    }
    if(target)
    {
        if (target.match("ne-id='(\\d|\\.|\\w|\\:)+'")) {
            neId = target.match("ne-id='(\\d|\\.|\\w|\\:)+'")[0].replaceAll("'", "").split("=")[1];
        }
        else {
            neId = target;
        }
    }
    logger.info(LOG_PREFIX + "NeId identified " + " : {}", neId);
    return neId;
}

function navigateInstance(neId) {
    var managerName = mdtFwk.getManagerName(neId);
    logger.info('Device: ' + neId + ' is managed by: ' + managerName);
    switch (managerName)
    {
        case 'NFM-P':
            logger.info('Device is managed by NFMP')
            return new NfmpSuggest();
            break;
        case 'MDC':
            logger.info('Device is managed by MDM')
            return new MdSuggest();
            break;
        default:
            logger.info('Device is not managed')
            throw new RuntimeException('Device is not Managed')
    }
    return ''
}

