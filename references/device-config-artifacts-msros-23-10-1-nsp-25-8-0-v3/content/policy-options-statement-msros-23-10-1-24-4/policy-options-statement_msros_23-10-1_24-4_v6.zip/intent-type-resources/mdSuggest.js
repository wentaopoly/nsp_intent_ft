function MdSuggest() {
    this.getPolicyStatementName = function (neId) {
       const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/policy-options/policy-statement?fields=name`;
       return this.getSuggestData(neId, url, "nokia-conf:policy-statement", "name");
    }

    this.getService = function (neId) {
       const requests = [
        {
          url:`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/service/vprn?fields=service-name`,
          responseKey: "nokia-conf:vprn",
          property: "service-name"
        },
        {
          url:`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/service/ies?fields=service-name`,
          responseKey: "nokia-conf:ies",
          property: "service-name"
        },
        {
          url:`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base?fields=router-name`,
          responseKey: "nokia-conf:router",
          property: "router-name"
        }
      ];
       return this.getMergedData(neId, requests);
   }

    this.getIpIntData = function (neId, service) {
       const requests = [
        {
          url:`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/service/vprn=${service}/interface?fields=interface-name`,
          responseKey: "nokia-conf:interface",
          property: "interface-name"
        },
        {
          url:`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/service/ies=${service}/interface?fields=interface-name`,
          responseKey: "nokia-conf:interface",
          property: "interface-name"
        },
        {
          url:`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=${service}/interface?fields=interface-name`,
          responseKey: "nokia-conf:interface",
          property: "interface-name"
        }
      ];
       return this.getMergedData(neId, requests);
   }

   this.getMergedData = function (neId,requests) {
    const mdcFwk = new MdcFwk();
    let result = [];
    requests.forEach(function (request) {
      const url = request.url;
      const responseKey = request.responseKey;
      const property = request.property;
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg[responseKey];
      if (Array.isArray(finalResponse) && finalResponse.length > 0) {
         const names = finalResponse.map(function (Data) {
           return Data[property];
         }).filter(function (value) {
           return value != null;
         });
       result = result.concat(names);
      }
    });
    return result.length > 0 ? result : [];
   };

    this.getCommunityData = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/policy-options/community?fields=name`;
    return this.getSuggestData(neId, url, "nokia-conf:community", "name");
   }

    this.getDampingData = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/policy-options/damping?fields=name`;
    return this.getSuggestData(neId, url, "nokia-conf:damping", "name");
   }

    this.getNatPolicy = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/service/nat/nat-policy?fields=name`;
    return this.getSuggestData(neId, url, "nokia-conf:nat-policy", "name");
   }

    this.getSrMaintenancePolicy = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/segment-routing/maintenance-policy?fields=policy-name`;
    return this.getSuggestData(neId, url, "nokia-conf:maintenance-policy", "policy-name");
   }

    this.getAsPathData = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/policy-options/as-path?fields=name`;
    return this.getSuggestData(neId, url, "nokia-conf:as-path", "name");
   }

    this.getAsPathGroup = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/policy-options/as-path-group?fields=name`;
    return this.getSuggestData(neId, url, "nokia-conf:as-path-group", "name");
   }

    this.getSrv6Locator = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/segment-routing/segment-routing-v6/locator?fields=locator-name`;
    return this.getSuggestData(neId, url, "nokia-conf:locator", "locator-name");
   }

    this.getSrv6MSLocator = function(neId) {
      const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/segment-routing/segment-routing-v6/micro-segment-locator?fields=locator-name`;
    return this.getSuggestData(neId, url, "nokia-conf:micro-segment-locator", "locator-name");
   }

   this.getRouteAdminTagPolicy = function(neId) {
     const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/routing-options/admin-tags/route-admin-tag-policy?fields=policy-name`;
   return this.getSuggestData(neId, url, "nokia-conf:route-admin-tag-policy", "policy-name");
   }

   this.getPrefixList = function(neId) {
     const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/policy-options/prefix-list?fields=name`;
   return this.getSuggestData(neId, url, "nokia-conf:prefix-list", "name");
   }

   this.getInterface = function(neId) {
      const requests = [
        {
          url:`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/service/vprn=*/interface?fields=interface-name`,
          responseKey: "nokia-conf:interface",
          property: "interface-name"
        },
        {
          url:`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/service/ies=*/interface?fields=interface-name`,
          responseKey: "nokia-conf:interface",
          property: "interface-name"
        },
        {
          url:`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/router=Base/interface?fields=interface-name`,
          responseKey: "nokia-conf:interface",
          property: "interface-name"
        }
      ];
       return this.getMergedData(neId, requests);
   }

   this.getPLOPrefixList = function(neId) {
      const requests = [
        {
          url : `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/policy-options/prefix-list?fields=name`,
          responseKey: "nokia-conf:prefix-list",
          property: "name"
        },
        {
          url : `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/policy-options/global-variables/name?fields=variable-name`,
          responseKey: "nokia-conf:name",
          property: "variable-name"
        },
        {
          url:`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/policy-options/policy-statement=*/entry=*/from/policy-variables/name?fields=variable-name`,
          responseKey: "nokia-conf:name",
          property: "variable-name"
        },
        {
          url:`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/policy-options/policy-statement=*/named-entry=*/from/policy-variables/name?fields=variable-name`,
          responseKey: "nokia-conf:name",
          property: "variable-name"
        }
      ];
      return this.getMergedData(neId, requests);
   }

   this.getRouteDistinguisherList = function(neId) {
     const url = `/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/policy-options/route-distinguisher-list?fields=name`;
   return this.getSuggestData(neId, url, "nokia-conf:route-distinguisher-list", "name");
   }

   this.getSuggestData = function(neId, url, initialProperty, propertyName) {
      const mdcFwk = new MdcFwk();
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg[initialProperty];
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data[propertyName]).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }
}
