load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {
    this.getPolicyName = function (neId, policyId) {
        var className = "niegr.Policy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "policyName",
                    "id"
                ]
            }
        };
        if (policyId) {
            var policyFilter = {};
            policyFilter["name"] = "id";
            policyFilter["value"] = policyId;
            searchObject["filter"]["and"]["equal"].push(policyFilter);
        }
        logger.info(LOG_PREFIX + "final search object = {}", searchObject);
        return this.getData(neId, searchObject, "policyName", policyId);
    }

    this.getPolicyId = function (neId, policyName) {
        if (!isNaN(policyName) && policyName !== "N/A" && policyName !== "") {
            return [policyName]
        }
        var className = "niegr.Policy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "policyName",
                    "id"
                ]
            }
        };
        if (policyName) {
            var policyFilter = {};
            policyFilter["name"] = "policyName";
            policyFilter["value"] = policyName;
            searchObject["filter"]["and"]["equal"].push(policyFilter);
        }
        return this.getData(neId, searchObject, "id", policyName);
    }
    
    this.getSupportAttributeDataList = function (neId, className, dataType) {
        var searchObject = {
            "fullClassName": "",
            "filter": {
                "and": {
                    "equal":
                        [
                            {
                                "name": "isLocal",
                                "value": 0
                            },
                            {
                                "name": "isBackup",
                                "value": 0
                            }
                        ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id",
                    "displayedName",
                    "prefixListType"
                ]
            }
        };
        switch (className) {
            case "qosprefixlist.PrefixList":
            case "qosportlist.PortList":
                searchObject["fullClassName"] = className;
                return this.getGlobalData(neId, searchObject, className, dataType, "displayedName");
        }
    }
    
    this.getGlobalData = function (neId, searchObjectJson, className, dataType, type) {
        let nfmpFwk = new NfmpFwk();
        var result = [];
        var resultFetch = nfmpFwk.find(neId, searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response)[className];
        logger.info(LOG_PREFIX + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                switch (dataType) {
                    case "IPv4":
                        if (finalResponse[index]["prefixListType"] === "ipv4") {
                            result.push(finalResponse[index][type]);
                        }
                        break;
                    case "IPv6":
                        if (finalResponse[index]["prefixListType"] === "ipv6") {
                            result.push(finalResponse[index][type]);
                        }
                        break;
                    case "port_list":
                        result.push(finalResponse[index][type]);
                        break;
                }
            }
        }
        logger.info(LOG_PREFIX + "NFMP Global Data suggest result = \n" + JSON.stringify(result));
        return result;
    }

    this.getData = function (target, searchObjectJson, type, policyAttribute) {
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.find(target, searchObjectJson);
        logger.info(LOG_PREFIX + resultFetch.response);
        var finalResponse = JSON.parse(resultFetch.response)["niegr.Policy"];
        logger.info(LOG_PREFIX + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                if (policyAttribute) {
                    logger.info(LOG_PREFIX + "Policy Selected = {}", policyAttribute);
                    logger.info(LOG_PREFIX + "Device policy = {}", finalResponse[index][type]);
                    ret.push(finalResponse[index][type]);
                    break;
                }
                else {
                    ret.push(finalResponse[index][type]);
                }
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "result = \n" + JSON.stringify(ret));
        return ret;
    }
}