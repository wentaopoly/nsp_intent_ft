function MdSuggest() {
    this.getPortXCData = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/port-xc/pxc?fields=pxc-id";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:pxc'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['pxc-id']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

    this.getPortId = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/port";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:port'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse) ? finalResponse.filter(data =>data['ethernet'] && data['ethernet']['mode'] === 'hybrid' && data['ethernet']['encap-type'] === 'dot1q' && data['ethernet']['dot1x'] && data['ethernet']['dot1x']['tunneling'] === true).map(data => data['port-id']).filter(value => value != null) : [];
      logger.info("ret = " + JSON.stringify(ret));
      return ret;
   }
}
