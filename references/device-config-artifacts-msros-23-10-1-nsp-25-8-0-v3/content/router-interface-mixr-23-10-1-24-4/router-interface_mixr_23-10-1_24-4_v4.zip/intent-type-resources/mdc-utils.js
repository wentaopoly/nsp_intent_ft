
load({ script: resourceProvider.getResource("mdt-fwk.js"), name: "MdtFwk" });
var mdtFwk = new MdtFwk();

load({ script: resourceProvider.getResource("audit.js"), name: "AuditUtil" });
var auditUtil = new AuditUtil();

/**
 *
 */
function MdcUtils() {
  /**
   *
   * Synchronize function
   *
   * @param {*} target
   * @param {*} inputJson
   * @param {*} intentTypeName
   * @param {*} rootXPath
   * @param {*} intentContainer
   * @param {*} uniqueIdentifier
   * @param {*} deviceYangModuleName
   * @param {*} topology
   * @param {*} networkState
   * @param {*} syncResult
   * @returns
   */
  this.synchronize = function (
    target,
    inputJson,
    intentTypeName,
    rootXPath,
    intentContainer,
    uniqueIdentifier,
    deviceYangModule,
    topology,
    networkState,
    syncResult
  ) {
    logger.info("--------- MdcUtils -> Synchronise started ------");
    logger.info("target " + target);
    logger.info("inputJson " + inputJson);
    logger.info("intentTypeName " + intentTypeName);
    logger.info("rootXPath " + rootXPath);
    logger.info("intentContainer " + intentContainer);
    logger.info("uniqueIdentifier " + uniqueIdentifier);
    logger.info("deviceYangModule " + deviceYangModule);
    logger.info(" NetworkState " + networkState);
    logger.info(" syncResult " + syncResult);

    try {
      let neId = parsedTarget.getNeIdFromTarget(target);
      let uniqueIdentifierValue = parseTarget.getUniqueIdentifier(target);
      logger.info(" uniqueIdentifierValue " + uniqueIdentifierValue);
      let neTypeAndVersion = mdtFwk.getTypeAndVersion(neId);
      // get the actual config data to be pushed to device
      let configData = getConfigData(
        inputJson,
        intentTypeName,
        intentContainer,
        uniqueIdentifier,
        uniqueIdentifierValue,
        rootXPath,
        deviceYangModule,
        neTypeAndVersion
      );
      if (networkState == "delete") {
        syncResult = doDelete(
          neId,
          rootXPath,
          intentContainer,
          syncResult,
          uniqueIdentifierValue,
          deviceYangModule
        );
      } else {
        // create request
        syncResult = doSyncRequest(
          neId,
          rootXPath,
          intentContainer,
          configData,
          topology,
          syncResult,
          intentTypeName,
          uniqueIdentifierValue,
          deviceYangModule
        );
      }
    } catch (e) {
      logger.info("MdcUtils >> Error Occured while Synchronizing. Error: " + e);
      throw new RuntimeException("Error Synchronizing Intent: " + e);
    }
    logger.info("--------- MdcUtils -> Synchronise done ------");
    return syncResult;
  };

  /**
     *
     * @param {*} target
     * @param {*} intentConfig
     * @param {*} svcTopo
     * @param {*} adminState
     * @param {*} intentTypeName
     * @param {*} rootXPath
     * @param {*} intentContainer
     * @param {*} uniqueIdentifier
     * @param {*} deviceYangModuleName
     * @param {*} auditReport
     * @returns
     */
  this.audit = function (
    target,
    intentConfig,
    svcTopo,
    adminState,
    intentTypeName,
    rootXPath,
    intentContainer,
    uniqueIdentifier,
    deviceYangModule,
    auditReport
  ) {
    logger.info("--------- MdcUtils -> audit started ------");

    try {
      let neId = parseTarget.getNeIdFromTarget(target);
      let uniqueIdentifierValue = parsedTarget.getUniqueIdentifier(target);
      if (neId !== "0.0.0.0") {
        let deviceConfig = commonUtil.getDeviceConfig(
          neId,
          rootXPath,
          intentContainer,
          deviceYangModule,
          uniqueIdentifierValue
        );

        logger.info("rootXPath " + rootXPath);
        logger.info("intentContainer " + intentContainer);
        let intentConfigWithContainer = {};
        // This should be conditional
        let path = intentContainer;
        if (rootXPath != "") {
          if (rootXPath.endsWith(":")) {
            path = `${rootXPath}${intentContainer}`;
          } else {
            path = `${rootXPath}/${intentContainer}`;
          }
        }
        logger.info("path " + path);
        let keys = auditUtil.getKeysForList(path, deviceYangModule);
        logger.info("keys " + keys);
        let identifierAr = uniqueIdentifier.split(",");
        let targetAr = target.split("#");
        // include the identifier in the intentConfig
        for (var i = 0; i < identifierAr.length; i++) {
          let identifier = identifierAr[i];
          if (keys && _.includes(keys, identifier) || deviceConfig && deviceConfig[identifier] != undefined) {
            intentConfig[identifier] = targetAr[2 + i];
          }
        }
        logger.info(
          "intentConfig after ..." +
          JSON.stringify(intentConfig)
        );
        intentConfigWithContainer[intentContainer] = intentConfig;
        logger.info(
          "intentConfigWithContainer" +
          JSON.stringify(intentConfigWithContainer)
        );

        if(intentConfigWithContainer["interface"] && intentConfigWithContainer["interface"]["ipv4"] && intentConfigWithContainer["interface"]["ipv4"]["vrrp"]) {
          removeAuthenticationKey(intentConfigWithContainer);
        }

        let deviceConfigWithContainer = {};
        deviceConfigWithContainer[intentContainer] = deviceConfig;
        logger.info(
          "deviceConfigWithContainer" +
          JSON.stringify(deviceConfigWithContainer)
        );


        if(deviceConfigWithContainer["interface"] && deviceConfigWithContainer["interface"]["ipv4"] && deviceConfigWithContainer["interface"]["ipv4"]["vrrp"]) {
          removeAuthenticationKey(deviceConfigWithContainer);
        }

        if(intentConfigWithContainer["interface"] && (!intentConfigWithContainer["interface"]["loopback"])) {
          intentConfigWithContainer["interface"]["loopback"] = false;
        }

        if(deviceConfigWithContainer["interface"] && deviceConfigWithContainer["interface"]["loopback"]) {
           deviceConfigWithContainer["interface"]["loopback"] = true;
        }
        else {
          deviceConfigWithContainer["interface"]["loopback"] = false;
        }



        /*if (!deviceConfigWithContainer["interface"]["ipv4"]) {
          deviceConfigWithContainer["interface"]["ipv4"] = {};
        }*/


        /*if (!deviceConfigWithContainer["interface"]["ipv4"]["unnumbered"]) {
          deviceConfigWithContainer["interface"]["ipv4"]["unnumbered"] = {};
        }

        if(intentConfigWithContainer["interface"] && intentConfigWithContainer["interface"]["ipv4"] && intentConfigWithContainer["interface"]["ipv4"]["unnumbered"] && (!intentConfigWithContainer["interface"]["ipv4"]["unnumbered"]["system"])) {
          intentConfigWithContainer["interface"]["ipv4"]["unnumbered"]["system"] = false;
        }

        if(deviceConfigWithContainer["interface"] && deviceConfigWithContainer["interface"]["ipv4"] && deviceConfigWithContainer["interface"]["ipv4"]["unnumbered"] && deviceConfigWithContainer["interface"]["ipv4"]["unnumbered"]["system"]) {
          deviceConfigWithContainer["interface"]["ipv4"]["unnumbered"]["system"] = true;
        }
        else {
          deviceConfigWithContainer["interface"]["ipv4"]["unnumbered"]["system"] = false;
        }


        if (!deviceConfigWithContainer["interface"]["ipv4"]["dhcp"]) {
          deviceConfigWithContainer["interface"]["ipv4"]["dhcp"] = {};
        }

        if (!deviceConfigWithContainer["interface"]["ipv4"]["dhcp"]["option-82"]) {
          deviceConfigWithContainer["interface"]["ipv4"]["dhcp"]["option-82"] = {};
        }

        if (!deviceConfigWithContainer["interface"]["ipv4"]["dhcp"]["option-82"]["circuit-id"]) {
          deviceConfigWithContainer["interface"]["ipv4"]["dhcp"]["option-82"]["circuit-id"] = {};
        }*/

        // remove modeule ref for SRL
        let neTypeAndVersion = mdtFwk.getTypeAndVersion(neId);
        let isSRLinux = commonUtil.isSRLinux(neTypeAndVersion["type"]);
        if (isSRLinux) {
          logger.info("Device is SRL ");
          // remove module references from deviceConfig before audit
          commonUtil.removeModuleRef(deviceConfig);
          deviceConfigWithContainer[intentContainer] = deviceConfig;
          logger.info(
            "deviceConfigWithContainer after removing module references " +
            JSON.stringify(deviceConfigWithContainer)
          );
        }

        auditUtil.findDiff(
          intentConfigWithContainer,
          deviceConfigWithContainer,
          auditReport,
          rootXPath,
          deviceYangModule
        );
      }
    } catch (e) {
      logger.info("MdcUtils >> Error Occured while Auditing. Error: " + e);
      throw new RuntimeException("Error Auditing Intent: " + e);
    }
    logger.info("------auditReport------" + auditReport);
    logger.info("--------- MdcUtils -> audit done ------");
    return auditReport;
  };

  /**
   *
   * Send sync request to mdc
   * @param {*} neId
   * @param {*} rootXPath
   * @param {*} intentContainer
   * @param {*} configData
   * @param {*} topology
   * @param {*} syncResult
   * @param {*} uniqueIdentifierValue
   * @returns
   */
  const doSyncRequest = (
    neId,
    rootXPath,
    intentContainer,
    configData,
    topology,
    syncResult,
    intentTypeName,
    uniqueIdentifierValue,
    deviceYangModule,
    neTypeAndVersion
  ) => {
    logger.info("------- doSyncRequest -> sending sync request -----");
    logger.info("neId " + neId);
    logger.info("rootXPath " + rootXPath);
    logger.info("intentContainer " + intentContainer);
    logger.info("configData " + JSON.stringify(configData));

    if(configData["flavor"] == "unnumbered-mpls-tp") {
      delete configData["external-reference"];
      delete configData["lag"];
      delete configData["if-attribute"];
      delete configData["untrusted"];
    }
    if(configData["loopback"] == true) {
      configData["loopback"] = [null];
    }
    else {
      delete configData["loopback"];
    }

    /*if(configData["ipv4"]["unnumbered"]["system"] == true) {
      configData["ipv4"]["unnumbered"]["system"] = [null];
    }
    else {
      delete configData["ipv4"]["unnumbered"]["system"];
    }*/

    let payload = getNetconfPayloadForCreate(
      rootXPath,
      intentContainer,
      configData,
      uniqueIdentifierValue,
      neTypeAndVersion,
      deviceYangModule
    );
    let url = commonUtil.getDeviceUrl(neId);
    syncResult = doMdcDeployment(
      neId,
      url,
      payload,
      syncResult,
      topology,
      intentTypeName,
      uniqueIdentifierValue,
      configData
    );
    logger.info("-------doSyncRequest -> done -----");
    return syncResult;
  };

  /**
   *
   * Send delete request to mdc
   * @param {*} neId
   * @param {*} rootXPath
   * @param {*} intentContainer
   * @param {*} configData
   * @param {*} topology
   * @param {*} syncResult
   * @param {*} uniqueIdentifierValue
   * @returns
   */
  const doDelete = (
    neId,
    rootXPath,
    intentContainer,
    syncResult,
    uniqueIdentifierValue,
    deviceYangModule
  ) => {
    logger.info("------- doDelete -> sending delete request -----");
    logger.info("neId " + neId);
    logger.info("rootXPath " + rootXPath);
    logger.info("intentContainer " + intentContainer);
    let payload = getNetconfPayloadForDelete(
      rootXPath,
      intentContainer,
      uniqueIdentifierValue,
      deviceYangModule
    );
    let url = commonUtil.getDeviceUrl(neId);
    syncResult = doMdcDelete(neId, url, payload, syncResult);
    logger.info("-------doDelete -> done -----");
    return syncResult;
  };

  /**
   * Do mdc deployment
   * @param {*} neId
   * @param {*} url
   * @param {*} payload
   * @param {*} syncResult
   * @param {*} topology
   * @returns
   */
  const doMdcDeployment = (
    neId,
    url,
    payload,
    syncResult,
    topology,
    intentTypeName,
    uniqueIdentifierValue,
    configData
  ) => {
    logger.info("-------doMdcDeployment -> sending mdc deploy request -----");
    if (topology === null) {
      topology = topologyFactory.createServiceTopology();
    }
    let deployResult = mdcFwk.deploy(neId, url, payload);
    logger.info("deployResult : " + JSON.stringify(deployResult));
    if (!deployResult.success) {
      logger.error(
        "doMdcDeployment failed with error" + JSON.stringify(deployResult)
      );
      syncResult.setSuccess(false);
      syncResult.setTopology(topology);
      syncResult.setErrorCode(deployResult.httpStatus);
      syncResult.setErrorDetail(deployResult.msg);
      logger.info(JSON.stringify(syncResult));
      return syncResult;
    } else {
      logger.info("-------  doMdcDeployment success -----");
      let topologyObjects = [];
      let topologyObject = topologyFactory.createTopologyObjectFrom(
        intentTypeName,
        uniqueIdentifierValue,
        "INFRASTRUCTURE",
        neId
      );
      topologyObjects.push(topologyObject);
      let xtrainfo = topologyFactory.createTopologyXtraInfoFrom(
        "configData",
        JSON.stringify(configData)
      );
      topology.setTopologyObjects(topologyObjects);
      topology.setXtraInfo([xtrainfo]);
      syncResult.setTopology(topology);
      syncResult.setSuccess(true);
    }
    logger.info("-------doMdcDeployment -> done -----");
    return syncResult;
  };

  /**
   * Do mdc delete
   * @param {*} neId
   * @param {*} url
   * @param {*} syncResult
   * @returns
   */
  const doMdcDelete = (neId, url, payload, syncResult) => {
    logger.info("-------doMdcDelete -> sending mdc delete request -----");
    let deployResult = mdcFwk.deploy(neId, url, payload);
    logger.info("deleteResult : " + JSON.stringify(deployResult));
    if (!deployResult.success) {
      logger.error(
        "doMdcDelete failed with error" + JSON.stringify(deployResult)
      );
      syncResult.setSuccess(false);
      syncResult.setErrorCode(deployResult.httpStatus);
      syncResult.setErrorDetail(deployResult.msg);
      logger.info(JSON.stringify(syncResult));
      return syncResult;
    } else {
      logger.info("-------  doMdcDelete success -----");
      syncResult.setSuccess(true);
    }
    logger.info("-------doMdcDelete -> done -----");
    return syncResult;
  };

  /**
   * Get the config data from inputJson
   * @param {*} inputJson
   * @param {*} intentTypeName
   * @param {*} intentContainer
   * @param {*} uniqueIdentifier
   * @param {*} uniqueIdentifierValue
   * @returns
   */
  const getConfigData = (
    inputJson,
    intentTypeName,
    intentContainer,
    uniqueIdentifier,
    uniqueIdentifierValue,
    rootXPath,
    deviceYangModule,
    neTypeAndVersion
  ) => {
    logger.info("Getting config data from inputJson");
    let configData = {};
    let parseInputJson = JSON.parse(inputJson);
    for (let i = 0; i < parseInputJson.length; i++) {
      configData = parseInputJson[i];
    }
    let confData =
      configData[intentTypeName + ":" + intentTypeName][intentContainer];
    logger.info("Config data " + JSON.stringify(configData));
    let isSRLinux = commonUtil.isSRLinux(neTypeAndVersion["type"]);
    if (isSRLinux) {
      logger.info("Device is SRL ");
      let path;
      if (rootXPath && rootXPath.length > 0) {
        // module reference case in rootXPath at the end
        if (rootXPath.endsWith(":")) {
          logger.info("rootXPath has module reference");
          path = `${deviceYangModule}:/${rootXPath}${intentContainer}`;
        } else {
          path = `${deviceYangModule}:/${rootXPath}/${intentContainer}`;
        }
      } else {
        path = `${deviceYangModule}:/${intentContainer}`;
      }
      logger.info("path "+path);
      // append module
      appendModuleName(confData, path);
      logger.info(
        "Config data after refModuleName " + JSON.stringify(configData)
      );
    }

    let keyObject = getKeyObject(
      uniqueIdentifier,
      uniqueIdentifierValue,
      intentContainer,
      rootXPath,
      deviceYangModule
    );
    logger.info("keyObject " + JSON.stringify(keyObject));
    configData = _.isEmpty(keyObject) ? confData : _.merge(keyObject, confData);
    logger.info("Merged Config data " + JSON.stringify(configData));
    return configData;
  };

  /**
   * append the moduleName in the confData attribute if it has refModuleName in the metadata
   * @param {*} confData
   * @param {*} path
   */
  const appendModuleName = (confData, path) => {
    let confDataKeys = Object.keys(confData);
    confDataKeys.map((key) => {
      let attributePath = `${path}/${key}`;
      let value = confData[key];
      if (_.isArray(value)) {
        appendModuleNameForArray(attributePath, value);
      } else if (_.isObject(value)) {
        appendModuleForObject(attributePath, value);
      } else {
        replaceKey(key, attributePath, confData);
      }
      // This is to append module name at the top level
      replaceKey(key, attributePath, confData);
    });
  };

  /**
   * append module for array
   * @param {*} arr
   */
  const appendModuleNameForArray = (path, arr) => {
    logger.debug("appendModuleNameForArray " + path);
    logger.debug("appendModuleNameForArray arr " + JSON.stringify(arr));
    // loop over array
    _.forEach(arr, (value) => {
      if (_.isArray(value)) {
        appendModuleNameForArray(path, value);
      } else if (_.isObject(value)) {
        appendModuleForObject(path, value);
      } else {
        // TODO
      }
    });
  };

  /**
   * append moduleName only for the object
   */
  const appendModuleForObject = (path, confData) => {
    logger.debug("appendModuleForObject " + path);
    logger.info("appendModuleForObject confData " + JSON.stringify(confData));
    let confDataKeys = Object.keys(confData);
    _.forEach(confDataKeys, (key) => {
      let attributePath = `${path}/${key}`;
      let value = confData[key];
      if (_.isArray(value)) {
        appendModuleNameForArray(attributePath, value);
      } else if (_.isObject(value)) {
        logger.info("key " + key);
        logger.info("value " + JSON.stringify(value));
        logger.info("attributePath " + attributePath);
        replaceKey(key, attributePath, confData);
        appendModuleForObject(attributePath, value);
      }
    });
  };

  /**
   * Replace the configData value with newKey(appended with Module) for the given key
   * @param {*} key - the given in the configData
   * @param {*} attributePath - path to get the moduleRef from object
   * @param {*} confData
   */
  const replaceKey = (key, attributePath, confData) => {
    attributePath = getMetaDataPath(attributePath);
    logger.info("MDCUtils >> attributePath: "+ attributePath)
    let refModuleName = metadata[attributePath]["refModuleName"];
    if (refModuleName != null) {
      let newKey = `${refModuleName}:${key}`;
      const descriptor = Object.getOwnPropertyDescriptor(confData, key);
      if (descriptor) {
        Object.defineProperty(confData, newKey, descriptor);
        delete confData[key];
        return true;
      }
    }
    return false;
  };

  /**
   *
   * Get the key object, reading key from meta-data.json
   *
   * @param {*} uniqueIdentifier
   * @param {*} uniqueIdentifierValue
   * @param {*} rootXPath
   * @param {*} deviceYangModule
   */
  const getKeyObject = (
    uniqueIdentifier,
    uniqueIdentifierValue,
    intentContainer,
    rootXPath,
    deviceYangModule
  ) => {
    let keyObject = {};
    let keys = getKeys(deviceYangModule, rootXPath, intentContainer);
    if(keys){
      for (let i = 0; i < keys.length; i++) {
        keyObject[keys[i]] = uniqueIdentifierValue[i];
      }
    }
    return keyObject;
  };

  /**
   *
   * @param {*} rootXPath
   * @param {*} intentContainer
   * @param {*} configData
   * @param {*} uniqueIdentifierValue
   * @param {*} neTypeAndVersion
   * @returns
   */
  const getNetconfPayloadForCreate = (
    rootXPath,
    intentContainer,
    configData,
    uniqueIdentifierValue,
    neTypeAndVersion,
    deviceYangModule
  ) => {
    logger.info("Getting the payload with ftl");
    // TODO, parameterize ftl name for sr, srl and other
    let rootXPathWithModuleValue = `${deviceYangModule}:`;
    if (rootXPath != undefined && rootXPath != null && rootXPath != "") {
      rootXPathWithModuleValue = `${rootXPathWithModuleValue}/${rootXPath}`;
    }
    logger.info("rootXPathWithModuleValue " + rootXPathWithModuleValue);

    // if rootXPath contains module reference, then intentContainer should have that module reference else top module reference
    let intentContainerWithModuleValue;
    if(rootXPath.endsWith(":")){
      let moduleRef = getModuleRef(rootXPath);
      if(moduleRef){
        intentContainerWithModuleValue = `${moduleRef}:${intentContainer}`;
      }else{
        intentContainerWithModuleValue = `${deviceYangModule}:${intentContainer}`;
      }
    }else {
      intentContainerWithModuleValue = `${deviceYangModule}:${intentContainer}`;
    }

    logger.info(
      "intentContainerWithModuleValue " + intentContainerWithModuleValue
    );
    let target;
    if (rootXPath.endsWith(":")) {
      target = `${rootXPathWithModuleValue}${intentContainer}=${commonUtil.encodeString(
        uniqueIdentifierValue
      )}`;
    } else {
      target = `${rootXPathWithModuleValue}/${intentContainer}=${commonUtil.encodeString(
        uniqueIdentifierValue
      )}`;
    }

    let payload = utilityService.processTemplate(
      resourceProvider.getResource("create.ftl"),
      {
        timestamp: JSON.stringify(Date.now()),
        target: target,
        intentContainerWithModule: intentContainerWithModuleValue,
        configData: JSON.stringify(configData),
      }
    );
    logger.info("Got payload for create " + payload);
    return payload;
  };

  /**
   *
   * @param {*} rootXPath
   * @param {*} intentContainer
   * @param {*} configData
   * @param {*} uniqueIdentifierValue
   * @param {*} neTypeAndVersion
   * @returns
   */
  const getNetconfPayloadForDelete = (
    rootXPath,
    intentContainer,
    uniqueIdentifierValue,
    deviceYangModule
  ) => {
    logger.info("Getting the payload with ftl for delete");
    // TODO, parameterize ftl name for sr, srl and other
    let rootXPathWithModuleValue = `${deviceYangModule}:${rootXPath ? `/${rootXPath}` : ''}`
    logger.info("rootXPathWithModuleValue " + rootXPathWithModuleValue);

    let target;
    if (rootXPath.endsWith(":")) {
      target = `${rootXPathWithModuleValue}${intentContainer}=${commonUtil.encodeString(
        uniqueIdentifierValue
      )}`;
    } else {
      target = `${rootXPathWithModuleValue}/${intentContainer}=${commonUtil.encodeString(
        uniqueIdentifierValue
      )}`;
    }

    // "target": "${rootXPathWithModule}/${intentContainer}=${uniqueIdentifierValue}"
    let payload = utilityService.processTemplate(
      resourceProvider.getResource("delete.ftl"),
      {
        timestamp: JSON.stringify(Date.now()),
        target: target
      }
    );
    logger.info("Got payload for delete " + payload);
    return payload;
  };

  /**
   * get the keys from meta-data.json file for list
   * @param {*} xPath
   * @returns
   */
  const getKeys = (deviceYangModule, rootXPath, intentContainer) => {
    if (_.isUndefined(deviceYangModule)) {
      throw new Error("deviceYangModuleName is null");
    }
    let path = rootXPath;
    if (!_.includes(rootXPath, deviceYangModule)) {
      // module reference case
      if (rootXPath.endsWith(":")) {
        path = `${deviceYangModule}:/${rootXPath}${intentContainer}`;
      } else {
        path = `${deviceYangModule}:/${rootXPath}/${intentContainer}`;
      }
    }
    path = getMetaDataPath(path);
    logger.info("path " + path);
    let keys = metadata && metadata[path] && metadata[path]["keys"];
    if (keys && typeof keys === "string") {
      keys = keys.split(",");
    }
    logger.info("keys " + keys);
    return keys;
  };

  /**
   *
   *
   * @param {*} path
   * @returns
   */
  const getMetaDataPath = (path) => {
    const pattern = /=[^/]+/g;
    return path.replace(pattern, "");
  };

  /**
   * Get the module reference from rootXPath
   * @param {*} rootXPath
   * @returns
   */
  const getModuleRef = (rootXPath) => {
    let lastIndexOfColon = rootXPath.lastIndexOf(":");
    let lastIndexOfSlash = rootXPath.lastIndexOf("/");
    let moduleRef = rootXPath.substring(lastIndexOfSlash + 1, lastIndexOfColon);
    logger.info("moduleRef " + moduleRef);
    return moduleRef;
  }
  const removeAuthenticationKey = (obj) => {
    for (const key in obj) {
      if (key === 'authentication-key') {
        delete obj[key];
      } else if (typeof obj[key] === 'object' && obj[key] !== null) {
        removeAuthenticationKey(obj[key]);
      }
    }
  }
}


