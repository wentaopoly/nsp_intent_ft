var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource('mdc-fwk.js'), name: 'MdcFwk' });
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});

function NfmpDiscoveryHelper(){
    let nfmpFwk = new NfmpFwk();
    let mdcFwk = new MdcFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function (target, initialPropertyName) {
        let neId = parseTarget.getNeIdFromTarget(target);
        let policyName = parseTarget.getUniqueIdentifier(target);
        let policyId = parseTarget.getNetworkQosPolicyID(target);
        let fullClassName = "niegr.Policy";
        let policyFdn = "Network";
        let objectFullName = policyFdn + ":" + policyId;
        let localPolicyFullName = "network:" + neId + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, neId);
        logger.info(LOG_PREFIX + "localPolicyFullName: " + localPolicyFullName);

        let resultFetch = nfmpFwk.post("/v3/search", this.constructSearchString(fullClassName, localPolicyFullName));
        if (!resultFetch.success) {
            throw new RuntimeException("Failed to find policy ID: " + policyId + ", Policy-Name : " + policyName + " on NE " + neId);
        }
        let finalResponse = JSON.parse(resultFetch.response);
        if (JSON.stringify(finalResponse) === JSON.stringify({})) {
            throw new RuntimeException("search results is empty for policy ID: " + policyId + " finalResponse: " + JSON.stringify(finalResponse));
        }
        else if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse["niegr.Policy"]];
            logger.info(LOG_PREFIX + "Search results: " + JSON.stringify(finalResponse));
        }
        return finalResponse[0];
    }

    this.constructSearchString = function (className, objectFullName) {
        let searchJson = {
            "fullClassName": className,
            "filter":{
                "equal":{
                    "name":"objectFullName",
                    "value": objectFullName
                }
            }
        };
        return searchJson;
    }

    this.extractDeviceConfig = function (defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedTargetData = JSON.parse(defaultTargetData)[initialPropertyName];
        let loadingTargetData = JSON.parse(JSON.stringify(parsedTargetData));
        logger.info(LOG_PREFIX + "defaultTargetData: ");
        logger.info(defaultTargetData);
        this.extractNonChildProperties(parsedTargetData, deviceConfig);
        let qosNetworkChildConfigs = deviceConfig["children-Set"];
        for (let childAttribute in qosNetworkChildConfigs) {
            switch (childAttribute) {
                case "niegr.Dot1p":
                    {
                        //DOT1P config array
                        let ingressDot1pConfig = qosNetworkChildConfigs[childAttribute];
                        parsedTargetData["ingress"]["dot1p"] = this.extractDeviceProperties(ingressDot1pConfig, loadingTargetData["ingress"]["dot1p"][0], "ingress.dot1p");
                        break;
                    }
                case "niegr.IngressForwardingClass":
                    {
                        //Ingress FC array
                        let ingressFcConfig = qosNetworkChildConfigs[childAttribute];
                        parsedTargetData["ingress"]["fc"] = this.extractDeviceProperties(ingressFcConfig, loadingTargetData["ingress"]["fc"][0], "ingress.fc");
                        break;
                    }
                case "niegr.Dscp":
                   {
                       //Ingress DSCP array
                        let ingressDscpConfig = qosNetworkChildConfigs[childAttribute];
                        parsedTargetData["ingress"]["dscp"] = this.extractDeviceProperties(ingressDscpConfig, loadingTargetData["ingress"]["dscp"][0], "ingress.dscp");
                        break;
                    }
                case "niegr.LspExp":
                    {
                        //Ingress LSP-EXP array
                        let ingressLspExpConfig = qosNetworkChildConfigs[childAttribute];
                        parsedTargetData["ingress"]["lsp-exp"] = this.extractDeviceProperties(ingressLspExpConfig, loadingTargetData["ingress"]["lsp-exp"][0], "ingress.lsp-exp")
                        break;
                    }
                case "niegr.IpMatch":
                    {
                        //Ingress IP-CRITERIA array
                        let ingressIpCriteriaConfig = qosNetworkChildConfigs[childAttribute];
                        parsedTargetData["ingress"]["ip-criteria"] = {};
                        parsedTargetData["ingress"]["ip-criteria"]["entry"] = [];
                        parsedTargetData["ingress"]["ip-criteria"]["entry"] = this.extractIpCriteriaProperties(ingressIpCriteriaConfig, loadingTargetData["ingress"]["ip-criteria"]["entry"][0], "ingress.ip-criteria");
                        break;
                    }
                case "niegr.Ipv6Match":
                    {
                        //Ingress IPv6-CRITERIA array
                        let ingressIpV6CriteriaConfig = qosNetworkChildConfigs[childAttribute];
                        parsedTargetData["ingress"]["ipv6-criteria"] = {};
                        parsedTargetData["ingress"]["ipv6-criteria"]["entry"] = [];
                        parsedTargetData["ingress"]["ipv6-criteria"]["entry"] = this.extractIpV6CriteriaProperties(ingressIpV6CriteriaConfig, loadingTargetData["ingress"]["ipv6-criteria"]["entry"][0], "ingress.ipv6-criteria");
                        break;
                    }
                case "niegr.DscpEgress":
                    {
                        //Egress DSCP array
                        let egressDscpConfig = qosNetworkChildConfigs[childAttribute];
                        parsedTargetData["egress"]["dscp"] = this.extractDeviceProperties(egressDscpConfig, loadingTargetData["egress"]["dscp"][0], "egress.dscp");
                        break;
                    }
                case "niegr.Precedence":
                    {
                        //Egress PREC array
                        let egressPrecConfig = qosNetworkChildConfigs[childAttribute];
                        parsedTargetData["egress"]["prec"] = this.extractDeviceProperties(egressPrecConfig, loadingTargetData["egress"]["prec"][0], "egress.prec");
                        break;
                    }
                case "niegr.ForwardingClass":
                    {
                        //Egress FC array
                        let egressFcConfig = qosNetworkChildConfigs[childAttribute];
                        parsedTargetData["egress"]["fc"] = this.extractEgressFcDeviceProperties(egressFcConfig, loadingTargetData["egress"]["fc"][0], "egress.fc");
                        break;
                    }
                case "niegr.EgressIpMatch":
                    {
                        //Egress IP-CRITERIA array
                        let egressIpCriteriaConfig = qosNetworkChildConfigs[childAttribute];
                        parsedTargetData["egress"]["ip-criteria"] = {};
                        parsedTargetData["egress"]["ip-criteria"]["entry"] = [];
                        parsedTargetData["egress"]["ip-criteria"]["entry"] = this.extractIpCriteriaProperties(egressIpCriteriaConfig, loadingTargetData["egress"]["ip-criteria"]["entry"][0], "egress.ip-criteria");
                        break;
                    }
                case "niegr.EgressIpv6Match":
                    {
                        //Egress IPv6-CRITERIA array
                        let egressIpV6CriteriaConfig = qosNetworkChildConfigs[childAttribute];
                        parsedTargetData["egress"]["ipv6-criteria"] = {};
                        parsedTargetData["egress"]["ipv6-criteria"]["entry"] = [];
                        parsedTargetData["egress"]["ipv6-criteria"]["entry"] = this.extractIpV6CriteriaProperties(egressIpV6CriteriaConfig, loadingTargetData["egress"]["ipv6-criteria"]["entry"][0], "egress.ipv6-criteria");
                        break;
                    }
                case "niegr.RingDot1p":
                   {
                       //Ring Dot1p
                        let ringDot1pConfig = qosNetworkChildConfigs[childAttribute];
                        parsedTargetData["ring"]["dot1p"] = this.extractDeviceProperties(ringDot1pConfig, loadingTargetData["ring"]["dot1p"][0], "ring.dot1p");
                        break;
                    }
            }
        }
        let finalTargetData = {};
        finalTargetData[initialPropertyName] = parsedTargetData;
        logger.info(LOG_PREFIX + "Intent data after updating from NFMP: \n" + JSON.stringify(finalTargetData));
        return finalTargetData;
    }

    this.extractNonChildProperties = function (parsedTargetData, deviceConfig) {
        let networkMapping = modelDeviceMapping.getNonChildNetworkQosMapping();
        this.traverseAndUpdateConfig("network", parsedTargetData, deviceConfig, networkMapping);
        if ("network-policy-type" in parsedTargetData) {
            if (deviceConfig["networkPolicyType"] === "ipInterface") {
                parsedTargetData["network-policy-type"] = "ip-interface";
            }
            else {
                parsedTargetData["network-policy-type"] = deviceConfig["networkPolicyType"];
            }
        }
        let ingressObj = parsedTargetData["ingress"];
        let ingressNonChildMapping = modelDeviceMapping.getNonChildIngressMapping();
        delete ingressObj["dot1p"];
        delete ingressObj["dscp"];
        delete ingressObj["lsp-exp"];
        delete ingressObj["fc"];
        delete ingressObj["ip-criteria"];
        delete ingressObj["ipv6-criteria"];
        this.traverseAndUpdateConfig("ingress", ingressObj, deviceConfig, ingressNonChildMapping);
        parsedTargetData["ingress"] = ingressObj;

        let egressObj = parsedTargetData["egress"];
        delete egressObj["dscp"];
        delete egressObj["prec"];
        delete egressObj["fc"];
        delete egressObj["ip-criteria"];
        delete egressObj["ipv6-criteria"];
        if (deviceConfig["egressRemark"] === "true") {
            egressObj["remark-trusted"]["force-egress-marking"] = Boolean(deviceConfig["forceRemark"]);
        }
        else {
            delete egressObj["remark-trusted"];
        }
        parsedTargetData["egress"] = egressObj;

        if ("ring" in parsedTargetData) {
            let ringObj = parsedTargetData["ring"];
            delete ringObj["dot1p"];
            ringObj["default-action"]["profile"] = deviceConfig["defaultProfile"];
            ringObj["default-action"]["queue"] = deviceConfig["defaultQueue"];
            parsedTargetData["ring"] = ringObj;
        }

        logger.info(LOG_PREFIX + "Updated non child properties - " + JSON.stringify(parsedTargetData));
    }
    
    this.extractIpV6CriteriaProperties = function (ipV6CriteriaConfig, ipV6CriteriaDefObj, keyPrefix) {
        let ipV6CriteriaArray = [];
        if (!Array.isArray(ipV6CriteriaConfig)) {
            ipV6CriteriaConfig = [ipV6CriteriaConfig];
        }
        for (let idx in ipV6CriteriaConfig) {
            let ipV6Config = ipV6CriteriaConfig[idx];
            let ipV6DefObj = JSON.parse(JSON.stringify(ipV6CriteriaDefObj));
            for (let ipV6Attrib in ipV6DefObj) {
                switch (ipV6Attrib) {
                    case "entry-id":
                        ipV6DefObj[ipV6Attrib] = ipV6Config["id"];
                        break;
                    case "description":
                        ipV6DefObj[ipV6Attrib] = ipV6Config["description"];
                        break;
                    case "match":
                        ipV6DefObj[ipV6Attrib]["next-header"] = util.transformProtocolBrownField(ipV6Config["protocol"]);
                        if (ipV6DefObj[ipV6Attrib]["next-header"] === "ipv6-icmp" && keyPrefix === "egress.ipv6-criteria" && ipV6Config["icmpType"] !== "-1") {
                            ipV6DefObj[ipV6Attrib]["icmp-type"] = ipV6Config["icmpType"];
                        }
                        else {
                            delete ipV6DefObj[ipV6Attrib]["icmp-type"];
                        }
                        if (ipV6Config["dscp"] !== "default") {
                            ipV6DefObj[ipV6Attrib]["dscp"] = ipV6Config["dscp"];
                        }
                        else {
                            delete ipV6DefObj[ipV6Attrib]["dscp"];
                        }
                        if (ipV6Config["fragment"] === "off") {
                            delete ipV6DefObj[ipV6Attrib]["fragment"];
                        }
                        else {
                            ipV6DefObj[ipV6Attrib]["fragment"] = ipV6Config["fragment"];
                        }
                        //SRC-IP
                        if (keyPrefix === "egress.ipv6-criteria" || keyPrefix === "ingress.ipv6-criteria") {

                            if (ipV6Config["sourceIpAddress"] === "0:0:0:0:0:0:0:0" && ipV6Config["sourceIpAddressMask"] === "0" && ipV6Config["srcIpPrefixListPointer"] === "") {
                                ipV6DefObj[ipV6Attrib]["src-ip"] = undefined;
                            }
                            else {
                                ipV6DefObj[ipV6Attrib]["src-ip"] = {};
                                let srcIpPrefixListPointer = ipV6Config["srcIpPrefixListPointer"];
                                if (srcIpPrefixListPointer !== "") {
                                    ipV6DefObj[ipV6Attrib]["src-ip"]["ipv6-prefix-list"] = srcIpPrefixListPointer.split("#")[0].replace("qosPrefixList:", "");
                                }
                                else {
                                    if (ipV6Config["sourceIpAddress"] && ipV6Config["sourceIpAddressMask"] && ipV6Config["sourceIpAddress"] !== "0:0:0:0:0:0:0:0" && ipV6Config["sourceIpAddressMask"] !== "0") {
                                        ipV6DefObj[ipV6Attrib]["src-ip"]["address"] = ipV6Config["sourceIpAddress"] + "/" + ipV6Config["sourceIpAddressMask"];
                                    }
                                    else {
                                        ipV6DefObj[ipV6Attrib]["src-ip"]["address"] = ipV6Config["sourceIpAddress"];
                                    }
                                    if (ipV6Config["sourceIpAddressFullMask"] && ipV6Config["sourceIpAddressFullMask"] !== "0:0:0:0:0:0:0:0" && ipV6Config["sourceIpAddressMask"] === "0") {
                                        ipV6DefObj[ipV6Attrib]["src-ip"]["mask"] = ipV6Config["sourceIpAddressFullMask"];
                                    }
                                }
                            }
                        }
                        //DST-IP
                        if (keyPrefix === "egress.ipv6-criteria" || keyPrefix === "ingress.ipv6-criteria") {

                            if (ipV6Config["destinationIpAddress"] === "0:0:0:0:0:0:0:0" && ipV6Config["destinationIpAddressMask"] === "0" && ipV6Config["dstIpPrefixListPointer"] === "") {
                                ipV6DefObj[ipV6Attrib]["dst-ip"] = undefined;
                            }
                            else {
                                ipV6DefObj[ipV6Attrib]["dst-ip"] = {};
                                let dstIpPrefixListPointer = ipV6Config["dstIpPrefixListPointer"];
                                if (dstIpPrefixListPointer !== "") {
                                    ipV6DefObj[ipV6Attrib]["dst-ip"]["ipv6-prefix-list"] = dstIpPrefixListPointer.split("#")[0].replace("qosPrefixList:", "");
                                }
                                else {
                                    if (ipV6Config["destinationIpAddress"] && ipV6Config["destinationIpAddressMask"] && ipV6Config["destinationIpAddress"] !== "0:0:0:0:0:0:0:0" && ipV6Config["destinationIpAddressMask"] !== "0") {
                                        ipV6DefObj[ipV6Attrib]["dst-ip"]["address"] = ipV6Config["destinationIpAddress"] + "/" + ipV6Config["destinationIpAddressMask"];
                                    }
                                    else {
                                        ipV6DefObj[ipV6Attrib]["dst-ip"]["address"] = ipV6Config["destinationIpAddress"];
                                    }
                                    if (ipV6Config["destinationIpAddressFullMask"] && ipV6Config["destinationIpAddressFullMask"] !== "0:0:0:0:0:0:0:0" && ipV6Config["destinationIpAddressMask"] === "0") {
                                        ipV6DefObj[ipV6Attrib]["dst-ip"]["mask"] = ipV6Config["destinationIpAddressFullMask"];
                                    }
                                }
                            }
                        }
                        //SRC-PORT
                        if (ipV6Config["sourceOperator"] !== "NONE") {
                            ipV6DefObj[ipV6Attrib]["src-port"] = {};
                            if (keyPrefix === "egress.ipv6-criteria" && ipV6Config["sourcePortListPointer"]) {
                                let sourcePortListPointer = ipV6Config["sourcePortListPointer"];
                                ipV6DefObj[ipV6Attrib]["src-port"]["port-list"] = sourcePortListPointer.replace("qosPortList:", "");
                            }
                            if (keyPrefix === "ingress.ipv6-criteria" && ipV6Config["ingSourcePortListPointer"]) {
                                let ingSourcePortListPointer = ipV6Config["ingSourcePortListPointer"];
                                ipV6DefObj[ipV6Attrib]["src-port"]["port-list"] = ingSourcePortListPointer.replace("qosPortList:", "");
                            }
                            else if (ipV6Config["sourceOperator"] === "EQUAL") {
                                ipV6DefObj[ipV6Attrib]["src-port"]["eq"] = ipV6Config["sourcePort1"];
                            }
                            else if (ipV6Config["sourceOperator"] === "LESS_THAN") {
                                ipV6DefObj[ipV6Attrib]["src-port"]["lt"] = ipV6Config["sourcePort1"];
                            }
                            else if (ipV6Config["sourceOperator"] === "GREATER_THAN") {
                                ipV6DefObj[ipV6Attrib]["src-port"]["gt"] = ipV6Config["sourcePort1"];
                            }
                            else if (ipV6Config["sourceOperator"] === "RANGE") {
                                ipV6DefObj[ipV6Attrib]["src-port"]["range"] = {};
                                ipV6DefObj[ipV6Attrib]["src-port"]["range"]["start"] = ipV6Config["sourcePort1"];
                                ipV6DefObj[ipV6Attrib]["src-port"]["range"]["end"] = ipV6Config["sourcePort2"];
                            }
                        }
                        else {
                            ipV6DefObj[ipV6Attrib]["src-port"] = undefined;
                        }
                        //DST-PORT
                        if (ipV6Config["destinationOperator"] !== "NONE") {
                            ipV6DefObj[ipV6Attrib]["dst-port"] = {};
                            if (keyPrefix === "egress.ipv6-criteria" && ipV6Config["destinationPortListPointer"]) {
                                let destinationPortListPointer = ipV6Config["destinationPortListPointer"];
                                ipV6DefObj[ipV6Attrib]["dst-port"]["port-list"] = destinationPortListPointer.replace("qosPortList:", "");
                            }
                            if (keyPrefix === "ingress.ipv6-criteria" && ipV6Config["ingDestinationPortListPointer"]) {
                                let ingDestinationPortListPointer = ipV6Config["ingDestinationPortListPointer"];
                                ipV6DefObj[ipV6Attrib]["dst-port"]["port-list"] = ingDestinationPortListPointer.replace("qosPortList:", "");
                            }
                            else if (ipV6Config["destinationOperator"] === "EQUAL") {
                                ipV6DefObj[ipV6Attrib]["dst-port"]["eq"] = ipV6Config["destinationPort1"];
                            }
                            else if (ipV6Config["destinationOperator"] === "LESS_THAN") {
                                ipV6DefObj[ipV6Attrib]["dst-port"]["lt"] = ipV6Config["destinationPort1"];
                            }
                            else if (ipV6Config["destinationOperator"] === "GREATER_THAN") {
                                ipV6DefObj[ipV6Attrib]["dst-port"]["gt"] = ipV6Config["destinationPort1"];
                            }
                            else if (ipV6Config["destinationOperator"] === "RANGE") {
                                ipV6DefObj[ipV6Attrib]["dst-port"]["range"] = {};
                                ipV6DefObj[ipV6Attrib]["dst-port"]["range"]["start"] = ipV6Config["destinationPort1"];
                                ipV6DefObj[ipV6Attrib]["dst-port"]["range"]["end"] = ipV6Config["destinationPort2"];
                            }
                        }
                        else {
                            ipV6DefObj[ipV6Attrib]["dst-port"] = undefined;
                        }
                        break;
                    case "action":
                        ipV6DefObj[ipV6Attrib] = {};
                        if (ipV6Config["forwardingClass"] !== "") {
                            ipV6DefObj[ipV6Attrib]["fc"] = ipV6Config["forwardingClass"];
                        }
                        if (ipV6Config["profile"] !== "none") {
                            ipV6DefObj[ipV6Attrib]["profile"] = ipV6Config["profile"];
                        }
                        if (keyPrefix === "egress.ipv6-criteria") {
                            ipV6DefObj[ipV6Attrib]["port-redirect-group"] = {};
                            ipV6DefObj[ipV6Attrib]["port-redirect-group"]["policer"] = ipV6Config["groupPolicer"];
                            ipV6DefObj[ipV6Attrib]["port-redirect-group"]["queue"] = ipV6Config["groupQueue"];
                        }
                        break;
                    default:
                        logger.info(LOG_PREFIX + "Unknown attribute identified/not-defined: " + ipV6Attrib);
                        break;
                }
            }
            ipV6CriteriaArray.push(ipV6DefObj);
        }
        logger.info(LOG_PREFIX + "parsedTargetData for: " + keyPrefix + ": " + JSON.stringify(ipV6CriteriaArray));
        return ipV6CriteriaArray;
    }
    
    this.extractIpCriteriaProperties = function (ipCriteriaConfig, ipCriteriaDefObj, keyPrefix) {
        let ipCriteriaArray = [];
        if (!Array.isArray(ipCriteriaConfig)) {
            ipCriteriaConfig = [ipCriteriaConfig];
        }
        for (let idx in ipCriteriaConfig) {
            let ipcConfig = ipCriteriaConfig[idx];
            let ipcDefObj = JSON.parse(JSON.stringify(ipCriteriaDefObj));
            for (let ipcAttrib in ipcDefObj) {
                switch (ipcAttrib) {
                    case "entry-id":
                        ipcDefObj[ipcAttrib] = ipcConfig["id"];
                        break;
                    case "description":
                        ipcDefObj[ipcAttrib] = ipcConfig["description"];
                        break;
                    case "match":
                        ipcDefObj[ipcAttrib]["protocol"] = util.transformProtocolBrownField(ipcConfig["protocol"]);
                        if (ipcDefObj[ipcAttrib]["protocol"] === "icmp" && keyPrefix === "egress.ip-criteria" && ipcConfig["icmpType"] !== "-1") {
                            ipcDefObj[ipcAttrib]["icmp-type"] = ipcConfig["icmpType"];
                        }
                        else {
                            delete ipcDefObj[ipcAttrib]["icmp-type"];
                        }
                        if (ipcConfig["dscp"] !== "default") {
                            ipcDefObj[ipcAttrib]["dscp"] = ipcConfig["dscp"];
                        }
                        else {
                            delete ipcDefObj[ipcAttrib]["dscp"];
                        }
                        if (ipcConfig["fragment"] === "off") {
                            delete ipcDefObj[ipcAttrib]["fragment"];
                        }
                        else {
                            ipcDefObj[ipcAttrib]["fragment"] = ipcConfig["fragment"];
                        }
                        //SRC-IP
                        if (keyPrefix === "egress.ip-criteria"|| keyPrefix === "ingress.ip-criteria") {

                                if (ipcConfig["sourceIpAddress"] === "0.0.0.0" && ipcConfig["sourceIpAddressMask"] === "0" && ipcConfig["srcIpPrefixListPointer"] === "") {
                                ipcDefObj[ipcAttrib]["src-ip"] = undefined;
                            }
                            else {
                                ipcDefObj[ipcAttrib]["src-ip"] = {};
                                let srcIpPrefixListPointer = ipcConfig["srcIpPrefixListPointer"];
                                if (srcIpPrefixListPointer !== "") {
                                    ipcDefObj[ipcAttrib]["src-ip"]["ip-prefix-list"] = srcIpPrefixListPointer.split("#")[0].replace("qosPrefixList:", "");
                                }
                                else {
                                    if (ipcConfig["sourceIpAddress"] && ipcConfig["sourceIpAddressMask"] && ipcConfig["sourceIpAddress"] !== "0.0.0.0" && ipcConfig["sourceIpAddressMask"] !== "0") {
                                        ipcDefObj[ipcAttrib]["src-ip"]["address"] = ipcConfig["sourceIpAddress"] + "/" + ipcConfig["sourceIpAddressMask"];
                                    }
                                    else {
                                        ipcDefObj[ipcAttrib]["src-ip"]["address"] = ipcConfig["sourceIpAddress"];
                                    }
                                    if (ipcConfig["sourceIpAddressFullMask"] && ipcConfig["sourceIpAddressFullMask"] !== "0.0.0.0" && ipcConfig["sourceIpAddressMask"] === "0") {
                                        ipcDefObj[ipcAttrib]["src-ip"]["mask"] = ipcConfig["sourceIpAddressFullMask"];
                                    }
                                }
                            }
                        }
                        //DST-IP
                        if (keyPrefix === "egress.ip-criteria" || keyPrefix === "ingress.ip-criteria") {

                            if (ipcConfig["destinationIpAddress"] === "0.0.0.0" && ipcConfig["destinationIpAddressMask"] && ipcConfig["dstIpPrefixListPointer"] === "") {
                                ipcDefObj[ipcAttrib]["dst-ip"] = undefined;
                            }
                            else {
                                ipcDefObj[ipcAttrib]["dst-ip"] = {};
                                let dstIpPrefixListPointer = ipcConfig["dstIpPrefixListPointer"];
                                if (dstIpPrefixListPointer !== "") {
                                    ipcDefObj[ipcAttrib]["dst-ip"]["ip-prefix-list"] = dstIpPrefixListPointer.split("#")[0].replace("qosPrefixList:", "");
                                }
                                else {
                                    if (ipcConfig["destinationIpAddress"] && ipcConfig["destinationIpAddressMask"] && ipcConfig["destinationIpAddress"] !== "0.0.0.0" && ipcConfig["destinationIpAddressMask"] !== "0") {
                                        ipcDefObj[ipcAttrib]["dst-ip"]["address"] = ipcConfig["destinationIpAddress"] + "/" + ipcConfig["destinationIpAddressMask"];
                                    }
                                    else {
                                        ipcDefObj[ipcAttrib]["dst-ip"]["address"] = ipcConfig["destinationIpAddress"];
                                    }
                                    if (ipcConfig["destinationIpAddressFullMask"] && ipcConfig["destinationIpAddressFullMask"] !== "0.0.0.0" && ipcConfig["destinationIpAddressMask"] === "0") {
                                        ipcDefObj[ipcAttrib]["dst-ip"]["mask"] = ipcConfig["destinationIpAddressFullMask"];
                                    }
                                }
                            }
                        }
                        //SRC-PORT
                        if (ipcConfig["sourceOperator"] !== "NONE") {
                            ipcDefObj[ipcAttrib]["src-port"] = {};
                            if (keyPrefix === "egress.ip-criteria" && ipcConfig["sourcePortListPointer"]) {
                                let sourcePortListPointer = ipcConfig["sourcePortListPointer"];
                                ipcDefObj[ipcAttrib]["src-port"]["port-list"] = sourcePortListPointer.replace("qosPortList:", "");
                            }
                            if (keyPrefix === "ingress.ip-criteria" && ipcConfig["ingSourcePortListPointer"]) {
                                let ingSourcePortListPointer = ipcConfig["ingSourcePortListPointer"];
                                ipcDefObj[ipcAttrib]["src-port"]["port-list"] = ingSourcePortListPointer.replace("qosPortList:", "");
                            }
                            else if (ipcConfig["sourceOperator"] === "EQUAL") {
                                ipcDefObj[ipcAttrib]["src-port"]["eq"] = ipcConfig["sourcePort1"];
                            }
                            else if (ipcConfig["sourceOperator"] === "LESS_THAN") {
                                ipcDefObj[ipcAttrib]["src-port"]["lt"] = ipcConfig["sourcePort1"];
                            }
                            else if (ipcConfig["sourceOperator"] === "GREATER_THAN") {
                                ipcDefObj[ipcAttrib]["src-port"]["gt"] = ipcConfig["sourcePort1"];
                            }
                            else if (ipcConfig["sourceOperator"] === "RANGE") {
                                ipcDefObj[ipcAttrib]["src-port"]["range"] = {};
                                ipcDefObj[ipcAttrib]["src-port"]["range"]["start"] = ipcConfig["sourcePort1"];
                                ipcDefObj[ipcAttrib]["src-port"]["range"]["end"] = ipcConfig["sourcePort2"];
                            }
                        }
                        else {
                            ipcDefObj[ipcAttrib]["src-port"] = undefined;
                        }
                        //DST-PORT
                        if (ipcConfig["destinationOperator"] !== "NONE") {
                            ipcDefObj[ipcAttrib]["dst-port"] = {};
                            if (keyPrefix === "egress.ip-criteria" && ipcConfig["destinationPortListPointer"]) {
                                let destinationPortListPointer = ipcConfig["destinationPortListPointer"];
                                ipcDefObj[ipcAttrib]["dst-port"]["port-list"] = destinationPortListPointer.replace("qosPortList:", "");
                            }
                            if (keyPrefix === "ingress.ip-criteria" && ipcConfig["ingDestinationPortListPointer"]) {
                                let ingDestinationPortListPointer = ipcConfig["ingDestinationPortListPointer"];
                                ipcDefObj[ipcAttrib]["dst-port"]["port-list"] = ingDestinationPortListPointer.replace("qosPortList:", "");
                            }
                            else if (ipcConfig["destinationOperator"] === "EQUAL") {
                                ipcDefObj[ipcAttrib]["dst-port"]["eq"] = ipcConfig["destinationPort1"];
                            }
                            else if (ipcConfig["destinationOperator"] === "LESS_THAN") {
                                ipcDefObj[ipcAttrib]["dst-port"]["lt"] = ipcConfig["destinationPort1"];
                            }
                            else if (ipcConfig["destinationOperator"] === "GREATER_THAN") {
                                ipcDefObj[ipcAttrib]["dst-port"]["gt"] = ipcConfig["destinationPort1"];
                            }
                            else if (ipcConfig["destinationOperator"] === "RANGE") {
                                ipcDefObj[ipcAttrib]["dst-port"]["range"] = {};
                                ipcDefObj[ipcAttrib]["dst-port"]["range"]["start"] = ipcConfig["destinationPort1"];
                                ipcDefObj[ipcAttrib]["dst-port"]["range"]["end"] = ipcConfig["destinationPort2"];
                            }
                        }
                        else {
                            ipcDefObj[ipcAttrib]["dst-port"] = undefined;
                        }
                        break;
                    case "action":
                        ipcDefObj[ipcAttrib] = {};
                        if (ipcConfig["forwardingClass"] !== "") {
                            ipcDefObj[ipcAttrib]["fc"] = ipcConfig["forwardingClass"];
                        }
                        if (ipcConfig["profile"] !== "none") {
                            ipcDefObj[ipcAttrib]["profile"] = ipcConfig["profile"];
                        }
                        if (keyPrefix === "egress.ip-criteria") {
                            ipcDefObj[ipcAttrib]["port-redirect-group"] = {};
                            ipcDefObj[ipcAttrib]["port-redirect-group"]["policer"] = ipcConfig["groupPolicer"];
                            ipcDefObj[ipcAttrib]["port-redirect-group"]["queue"] = ipcConfig["groupQueue"];
                        }
                        break;
                    default:
                        logger.info(LOG_PREFIX + "Unknown attribute identified/not-defined: " + ipcAttrib);
                        break;
                }
            }
            ipCriteriaArray.push(ipcDefObj);
        }
        logger.info(LOG_PREFIX + "parsedTargetData for: " + keyPrefix + ": " + JSON.stringify(ipCriteriaArray));
        return ipCriteriaArray;
    }

    this.extractEgressFcDeviceProperties = function (fcConfigData, fcDefaultObj, keyPrefix) {
        let egressFcDataArray = [];
        let mappings = modelDeviceMapping.getMapping(keyPrefix);
        if (!Array.isArray(fcConfigData)) {
            fcConfigData = [fcConfigData];
        }
        for (let idx in fcConfigData) {
            let fcDataObj = fcConfigData[idx];
            let fcDefObj = JSON.parse(JSON.stringify(fcDefaultObj));
            this.traverseAndUpdateConfig(keyPrefix, fcDefObj, fcDataObj, mappings);
            if (fcDataObj["deMark"] === "false") {
                delete fcDefObj["de-mark"];
            }
            else {
                fcDefObj["de-mark"]["force"] = fcDataObj["forceDeValue"];
            }
            egressFcDataArray.push(fcDefObj);
        }
        logger.info(LOG_PREFIX + "parsedTargetData for: " + keyPrefix + ": " + JSON.stringify(egressFcDataArray));
        return egressFcDataArray;
    }

    this.extractDeviceProperties = function (configData, defaultDataObj, keyPrefix) {
        let configDataArray = [];
        let mappings = modelDeviceMapping.getMapping(keyPrefix);
        if (!Array.isArray(configData)) {
            configData = [configData];
        }

        for (let idx in configData) {
            let configDataObj = configData[idx];
            let defData = JSON.parse(JSON.stringify(defaultDataObj));
            this.traverseAndUpdateConfig(keyPrefix, defData, configDataObj, mappings);
            configDataArray.push(defData);
        }
        logger.info(LOG_PREFIX + "parsedTargetData for: " + keyPrefix + ": " + JSON.stringify(configDataArray));
        return configDataArray;
    }

    this.traverseAndUpdateConfig = function (objKey, defDataObj, deviceConfig, mappings) {
        let keys = Object.keys(defDataObj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = defDataObj[key];

            let mappedKey = objKey + "." + key;
            if ((mappedKey !== "network.ingress") && (mappedKey !== "network.egress") && (mappedKey !== "ingress.dot1p")
            && (mappedKey !== "ingress.dscp") && (mappedKey !== "ingress.lsp-exp") && (mappedKey !== "ingress.fc") &&
                (mappedKey !== "ingress.ip-criteria") && (mappedKey !== "ingress.ipv6-criteria"))
            {
                if (value != null && typeof value === "object") {
                    this.traverseAndUpdateConfig(mappedKey, value, deviceConfig, mappings);
                }
                else {
                    let nfmpKey = mappings[mappedKey];
                    defDataObj[key] = this.transformDeviceValue(mappedKey, deviceConfig[nfmpKey]);
                }
            }
        }
        return defDataObj;
    }

    this.transformDeviceValue = function (mappedKey, deviceValue) {
        if (deviceValue !== null) {
            switch (mappedKey) {
                case "ingress.dot1p.dot1p-value":
                case "ingress.lsp-exp.lsp-exp-value":
                case "egress.prec.prec-value":
                case "egress.fc.dot1p-in-profile":
                case "egress.fc.dot1p-out-profile":
                case "egress.fc.lsp-exp-in-profile":
                case "egress.fc.lsp-exp-out-profile":
                case "ring.dot1p.dot1p-priority":
                    deviceValue = util.convertValToNumBrownField(deviceValue);
                    break;
            }
            return deviceValue;
        }
    }

    this.cipherSpecialCharacterInKey = function (key) {
        return key.replaceAll("/", "%2F").replaceAll(":", "%3A");
    }
}
