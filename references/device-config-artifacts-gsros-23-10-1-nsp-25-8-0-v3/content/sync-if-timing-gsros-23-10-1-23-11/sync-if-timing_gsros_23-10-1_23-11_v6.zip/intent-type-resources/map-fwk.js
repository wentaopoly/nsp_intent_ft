function MapFwk(){
  
     this.set = function(mapObject,key,value){
           mapObject[key] = value;
           return mapObject;
     }
  
  
     this.get = function(mapObject,key){   
            try {
                  return mapObject[key];
            }catch(err) {
                  logger.info("object not found for the key" + key);
                  return undefined;
            }            
     }
 
}
