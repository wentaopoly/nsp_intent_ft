/**************************************************************************
 * $RCSfile$
 * <p>
 * Author: afshandev
 * <p>
 * Description:
 * <edit this part>
 * <p>
 * **************************************************************************
 * <p>
 * Source Control System Information
 * <p>
 * $Revision$
 * $Id$
 * Last Changed by:$Author$
 * <p>
 * **************************************************************************
 * <p>
 * Copyright (c) 2022 Nokia,All Rights Reserved.
 * Please read the associated COPYRIGHTS file for more details.
 **************************************************************************/
package com.nokia.nsp.sf.app.srNode;


import com.nokia.nsp.md.common.IExecutionContext;
import com.nokia.nsp.md.db.yang.api.QueryParameters;
import com.nokia.nsp.sf.app.api.ISFPlugin;
import com.nokia.nsp.sf.app.util.ServiceUtil;
import com.nokia.nsp.md.common.IYangObject;
import com.nokia.nsp.svcstitch.app.api.NspYangDbInterface;
import com.nokia.nspos.persistence.yang.api.IYangDB;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import com.nokia.nsp.md.db.yang.api.ExecutionContext;

public class HcoNspPlugin implements ISFPlugin {
    public static final String MODEL_MDM_FDN = "fdn:model:mdm:";
    public static final String SPACE_URL_ENCODER = "%20";
    public static final Map<String, Map<String, List<String>>> predefinedDeviceServicePathMapToNspClass = initDeviceServicePathMapToNspClasses();
    public static final Map<String, String> predefinedDeviceSiteClass = initDeviceSiteClasses();
    public static final Map<String, String> predefinedDeviceEndPointClass = initDeviceEndPointClasses();

    private static Map<String, Map<String, List<String>>> initDeviceServicePathMapToNspClasses() {
        Map<String, Map<String, List<String>>> lListMap = new HashMap<>();
        Map<String, List<String>> lElineSite = new HashMap<>();
        List<String> lElineNspSiteClass = new ArrayList<>(1);
        lElineNspSiteClass.add("nsp-service:/services/service-layer/eline/site");
        lElineSite.put("nsp-service:/services/service-layer/eline/site", lElineNspSiteClass);
        lListMap.put(ServiceUtil.serviceType.eline.name() + "_site", lElineSite);

        Map<String, List<String>> lElineEp = new HashMap<>();
        List<String> lElineNspEpClass = new ArrayList<>(1);
        lElineNspEpClass.add("nsp-service:/services/service-layer/eline/endpoint");
        lElineEp.put("nsp-service:/services/service-layer/eline/endpoint", lElineNspEpClass);
        lListMap.put(ServiceUtil.serviceType.eline.name() + "_endpoint", lElineEp);

        Map<String, List<String>> lElanSite = new HashMap<>();
        List<String> lElanNspSiteClass = new ArrayList<>(1);
        lElanNspSiteClass.add("nsp-service:/services/service-layer/elan/site");
        lElanSite.put("nsp-service:/services/service-layer/elan/site", lElanNspSiteClass);
        lListMap.put(ServiceUtil.serviceType.elan.name() + "_site", lElanSite);

        Map<String, List<String>> lElanEp = new HashMap<>();
        List<String> lElanNspEpClass = new ArrayList<>(1);
        lElanNspEpClass.add("nsp-service:/services/service-layer/elan/endpoint");
        lElanEp.put("nsp-service:/services/service-layer/elan/endpoint", lElanNspEpClass);
        lListMap.put(ServiceUtil.serviceType.elan.name() + "_endpoint", lElanEp);

        Map<String, List<String>> lL3VpnSite = new HashMap<>();
        List<String> lL3VpnNspSiteClass = new ArrayList<>(1);
        lL3VpnNspSiteClass.add("nsp-service:/services/service-layer/l3vpn/site");
        lL3VpnSite.put("nsp-service:/services/service-layer/l3vpn/site", lL3VpnNspSiteClass);
        lListMap.put(ServiceUtil.serviceType.l3vpn.name() + "_site", lL3VpnSite);

        Map<String, List<String>> lL3VpnEp = new HashMap<>();
        List<String> lL3VpnNspEpClass = new ArrayList<>(1);
        lL3VpnNspEpClass.add("nsp-service:/services/service-layer/l3vpn/endpoint");
        lL3VpnEp.put("nsp-service:/services/service-layer/l3vpn/endpoint", lL3VpnNspEpClass);
        lListMap.put(ServiceUtil.serviceType.l3vpn.name() + "_endpoint", lL3VpnEp);


        return lListMap;
    }

    public static final Map<String, String> initDeviceSiteClasses() {
        Map<String, String> lDeviceClasses = new HashMap<>();
        lDeviceClasses.put(ServiceUtil.serviceType.eline.name(), "nsp-service:/services/service-layer/eline/site");
        lDeviceClasses.put(ServiceUtil.serviceType.elan.name(), "nsp-service:/services/service-layer/elan/site");
        lDeviceClasses.put(ServiceUtil.serviceType.l3vpn.name(), "nsp-service:/services/service-layer/l3vpn/site");
        lDeviceClasses.put(ServiceUtil.serviceType.ies.name(), "nsp-service:/services/service-layer/ies/site");
        return lDeviceClasses;

    }

    public static final Map<String, String> initDeviceEndPointClasses() {
        Map<String, String> lDeviceClasses = new HashMap<>();
        lDeviceClasses.put(ServiceUtil.serviceType.eline.name(), "nsp-service:/services/service-layer/eline/endpoint");
        lDeviceClasses.put(ServiceUtil.serviceType.elan.name(), "nsp-service:/services/service-layer/elan/endpoint");
        lDeviceClasses.put(ServiceUtil.serviceType.l3vpn.name(), "nsp-service:/services/service-layer/l3vpn/endpoint");
        lDeviceClasses.put(ServiceUtil.serviceType.ies.name(), "nsp-service:/services/service-layer/ies/endpoint");
        return lDeviceClasses;

    }

    public Map<String, List<String>> getNspClassToResync(Map<String, List<String>> aInMap, String aInServiceType, String aInNeId, boolean aInAfterStitchIng, String aInNodeType, String aInNodeVersion) {
        Map<String, List<String>> lRetMap = new HashMap<>();
        for (Map.Entry<String, List<String>> lMap : aInMap.entrySet()) {
            if (lMap.getKey().contains("site")) {
                lRetMap.putAll(predefinedDeviceServicePathMapToNspClass.get(aInServiceType + "_site"));
            } else if (lMap.getKey().contains("endpoint")) {
                lRetMap.putAll(predefinedDeviceServicePathMapToNspClass.get(aInServiceType + "_endpoint"));
            }
        }
        return lRetMap;
    }

    @Override
    public List<String> buildExtraSources(IYangObject aInSyncSiteYangObj, String aInObjectType, List<String> aInSources, String aInSvcType, String aInNeId, String aInNodeType, String aInNodeVersion) {
        List<String> lExtraSources = new ArrayList();

        return lExtraSources;
    }

    @Override
    public Map<String, List<String>> buildResyncRequest(List<String> aInSources, String aInSvcType, String aInNeId, boolean aInAfterStitchIng, String aInNodeType, String aInNodeVersion) {
        Map<String, List<String>> lListMap = new LinkedHashMap<>();

        for (String lSource : aInSources) {
            if (lSource.contains(MODEL_MDM_FDN)) {
                String lDeviceClassId = null;
                if (lSource.contains("site"))
                    lDeviceClassId = predefinedDeviceSiteClass.get(aInSvcType);
                else if (lSource.contains("endpoint"))
                    lDeviceClassId = predefinedDeviceEndPointClass.get(aInSvcType);
                if (null != lDeviceClassId) {
                    List<String> lList = lListMap.get(lDeviceClassId);
                    if (null == lList) {
                        lList = new LinkedList<>();
                        lListMap.put(lDeviceClassId, lList);
                    }
                    lList.add(lSource);
                }
            }
        }
        return lListMap;
    }


    public List<String> getSourceFdns(IYangObject aInSyncSiteYangObj, String serviceType, String aInNeId, String aInNodeType, String aInNodeVersion) {
        List<String> lSources = (List) aInSyncSiteYangObj.getExtraData("sources");
        List<String> sources = new LinkedList<>();
        String lExtSite = "service-extension:" + serviceType + "-site";
        for (String lSource : lSources) {
            if (lSource.contains(MODEL_MDM_FDN) && !lSource.contains(lExtSite) && !lSource.contains("ipservice-site-detail")) {
                sources.add(lSource);
            }
        }
        if (aInSyncSiteYangObj.hasProperty("endpoint-identifier") && null != aInSyncSiteYangObj.get("endpoint-identifier")) {
            List<String> lArr = (List) aInSyncSiteYangObj.get("endpoint-identifier");
            List<String> lModelFdnArr = new ArrayList<>();
            for (String lStr : lArr) {
                lModelFdnArr.add("fdn:model:mdm:" + aInNeId + ":" + lStr);
            }
            sources.addAll(lModelFdnArr);
        }


        return sources;
    }

    public List<String> getSourceFdnForSiteAndEps(String aInRestUrl, NspYangDbInterface aInNspYangDbInterface, IYangDB aInDb, IYangObject aInSiteYangObj, String serviceType, String aInNeId, String aInNodeType, String aInNodeVersion)
            throws  Exception{
        List<String> sources = new LinkedList<>();
        List<String> lSources = (List) aInSiteYangObj.getExtraData("sources");
        for (String lSource : lSources) {
            if (lSource.contains(MODEL_MDM_FDN)) {
                sources.add(lSource);

            }
        }

        List<String> lEndpointFromNsp = new ArrayList<>();
        List<String> lDeviceEpList = new ArrayList<>();
        List<String> lNeedToResync = new ArrayList<>();
        List<String> lNeedToDelete = new ArrayList<>();
        HashMap lFdnMap = new HashMap<>();
        if (aInSiteYangObj.hasProperty("endpoint")) {
            lEndpointFromNsp = (List) aInSiteYangObj.get("endpoint");
        }
        String lUrl = aInRestUrl.substring(0, aInRestUrl.indexOf("/operations/nsp-admin-resync:trigger-resync"));
        lUrl = lUrl + "/data/nsp-network:network/node=" + aInNeId + "/node-root/nsp-service:/services/service-layer/" + serviceType + "/site?queryAMI&nsp-sbi-obj-id=";
        lUrl = lUrl + getEncodedString(sources.get(0));
        ResponseEntity lResponseEntity = aInNspYangDbInterface.getQueryAmiDeviceData(lUrl);
        if (lResponseEntity.getStatusCodeValue() == HttpStatus.OK.value()) {
            Object lObject = lResponseEntity.getBody();
            if (lObject != null) {
                if (lObject instanceof HashMap) {
                    HashMap lDeviceMap = (HashMap) lObject;
                    if(lDeviceMap.containsKey("_fdn_"))
                        lFdnMap = (HashMap)lDeviceMap.get("_fdn_");
                    if (lDeviceMap.containsKey("endpoint")) {
                        lDeviceEpList = (ArrayList) lDeviceMap.get("endpoint");


                    }
                }
            }
        }
        if (lDeviceEpList.size() == 0 && lEndpointFromNsp.size() > 0) {
            lNeedToDelete.addAll(lEndpointFromNsp);
        } else if (lEndpointFromNsp.size() == 0 && lDeviceEpList.size() > 0) {
            lNeedToResync.addAll(lDeviceEpList);
        } else {
            lNeedToResync.addAll(lDeviceEpList);
            for (String lNspEndPoint : lEndpointFromNsp) {
                if (!lDeviceEpList.contains(lNspEndPoint)) {
                    //delete the endpoint
                    lNeedToDelete.add(lNspEndPoint);
                }
            }
        }
        if (lNeedToDelete.size() > 0) {
            deleteNspEndpoints(aInDb, lNeedToDelete, aInSiteYangObj);
        }
        if (lNeedToResync.size() > 0 && lFdnMap.containsKey("scheme") && lFdnMap.containsKey("namespace")) {
            for(String lDeviceEpStr: lNeedToResync){
                String lFdn = "fdn:" + lFdnMap.get("scheme") + ":" + lFdnMap.get("namespace") + ":" + aInNeId + ":" + lDeviceEpStr;
                sources.add(lFdn);
            }
        }
        return sources;
    }


    public  List<String> getSourceFdns( IYangDB aInDb, IYangObject aInSiteYangObj, String serviceType, String aInNeId, String aInNodeType,String aInNodeVersion)
    {
        //need to check this
        List<String> sources = new LinkedList<>();
        List<String> lSources = (List) aInSiteYangObj.getExtraData("sources");
        for (String lSource : lSources) {
            if (lSource.contains(MODEL_MDM_FDN)) {
                sources.add(lSource);

            }
        }
        return sources;
    }

    public  List<String> getSiteExtensionSources(List<String> aInSources, String serviceType, String aInNeId, String aInNodeType,String aInNodeVersion)
    {
        //need to check this
        List<String> lSources = new ArrayList();
        for(String lStr : aInSources){
            if(lStr.contains("service-extension"))
                lSources.add(lStr);
        }
        return lSources;
    }

    public boolean shouldCreateEndpoint(String aInServiceType,String aInNeId, String aInNodeType,String aInNodeVersion, boolean isServiceStitching) {
        return false;
    }
    private static String getEncodedString(String aInSvcName) throws Exception{
        return URLEncoder.encode(aInSvcName, StandardCharsets.UTF_8.toString()).replace("+", SPACE_URL_ENCODER );
    }
    private void deleteNspEndpoints(IYangDB aInDb, List<String> aInNspEpToDelete, IYangObject aInSiteYangObj){
        QueryParameters lQueryParams = new QueryParameters();
        IExecutionContext lExecutionContext= new ExecutionContext(null, null, false, false, false);
        lQueryParams.setIExecutionContext(lExecutionContext);
        for(String lEndPointStr : aInNspEpToDelete) {
            aInDb.delete(lEndPointStr,lQueryParams);
        }
    }
}
