load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function utilities() {

    this.setSuccessResult = function (result, savedTopology) {
        result.setSuccess(true);
        if (savedTopology !== undefined)
        {
            result.setTopology(savedTopology);
        }
        return result;
    }

    this.reportMisaligned = function (target, result, auditReport) {
        var report = JSON.parse(result.response);
        if (!report.aligned)
        {
            for (var i = 0; i < report.misalignedAttributes.length; i++)
            {
                var attributeData = report.misalignedAttributes[i];
                if (attributeData.expected == "present")
                {
                    //misaligned object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else if (attributeData.expected == "not present")
                {
                    //undesired object
                    var objectDn = attributeData.name;
                    var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
                    auditReport.addMisAlignedObject(misalignedObject);
                }
                else
                {
                    var misalignedAttribute = auditFactory.createMisAlignedAttribute(attributeData.name, attributeData.expected, attributeData.actual, target);
                    auditReport.addMisAlignedAttribute(misalignedAttribute);
                }

            }
        }
        return auditReport
    }

    this.editPayload = function (fdn, properties, childProperties, fullClassName, objectFullName) {

        var payload = {};
        var configInfo = {};
        configInfo["containedClassProperties"] = properties;
        configInfo["containmentInfo"] = childProperties;
        configInfo["objectClassName"] = fullClassName;
        payload["distinguishedName"] = fdn;
        payload["objectFullName"] = objectFullName;
        payload["configInfo"] = configInfo;
        return payload;
    }

    /*
        function: isObjectExists
        description: To Check the Object exists or not.
   */
    this.isObjectExists = function (className, objectFullName) {
        let nfmpFwk = new NfmpFwk();
        var ret = false;
        var searchObjectJson = {
            "fullClassName": className,
            "filter": {
                "filterExpression": "fullName='" + objectFullName + "'"
            }
        };
        var resultFetch = nfmpFwk.post("search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse))
        {
            ret = true;
        }
        return ret;
    }

    //convert Address to NFMP system-id, convert 00:00:00:00:00:00 to 00_00_00_00_00_00.
    this.convertAddressGreenField = function (address) {
        return address.toUpperCase().replaceAll(":", "_");
    }

    //convert Address to Intent system-id, convert  00_00_00_00_00_00 to 00:00:00:00:00:00.
    this.convertAddressBrownField = function (address) {
        return address.toLowerCase().replaceAll("_", ":");
    }

    //convert admin-sate to NFMP administrate State.
    this.convertAdminStateGreenField = function (adminState) {
        if (adminState == "enable")
        {
            return "inService";
        }
        else if (adminState == "disable")
        {
            return "outOfService";
        }
    }

    //convert administrate State to intent admin-state.
    this.convertAdminStateBrownField = function (adminState) {
        if (adminState == "inService")
        {
            return "enable";
        }
        else if (adminState == "outOfService")
        {
            return "disable";
        }
    }

    //convert cockType to NFMP administrate State.
    this.convertClockTypeGreeField = function (clockType) {
        if (clockType == "slave-only")
        {
            return "ordinarySlave";
        }
        else if (clockType == "master-only")
        {
            return "ordinaryMaster";
        }
        else if (clockType == "boundary")
        {
            return "boundary";
        }
    }

    //convert clockType to intent admin-state.
    this.convertClockTypeBrownField = function (clockType) {
        if (clockType == "ordinarySlave")
        {
            return "slave-only";
        }
        else if (clockType == "ordinaryMaster")
        {
            return "master-only";
        }
        else if (clockType == "boundary")
        {
            return "boundary";
        }
    }

    //convert Profile to NFMP administrate State.
    this.convertProfileGreeField = function (profile) {
        if (profile == "g8265dot1-2010")
        {
            return "ituTG8265";
        }
        else if (profile == "ieee1588-2008")
        {
            return "ieee15882008";
        }
        else if (profile == "g8275dot1-2014")
        {
            return "ituTG8275";
        }
        else if (profile == "g8275dot2-2016")
        {
            return "g8275dot2_2016";
        }
    }

    //convert Profile to intent admin-state.
    this.convertProfileBrownField = function (profile) {
        if (profile == "ituTG8265")
        {
            return "g8265dot1-2010";
        }
        else if (profile == "ieee15882008")
        {
            return "ieee1588-2008";
        }
        else if (profile == "ituTG8275")
        {
            return "g8275dot1-2014";
        }
        else if (profile == "g8275dot2_2016")
        {
            return "g8275dot2-2016";
        }
    }


    //convert Inverval to NFMP Inverval.
    this.convertInvervalGreeField = function (inverval) {
        if (inverval == -6)
        {
            return "negSix";
        }
        else if (inverval == -5)
        {
            return "negFive";
        }
        else if (inverval == -4)
        {
            return "negFour";
        }
        else if (inverval == -3)
        {
            return "negThree";
        }
        else if (inverval == -2)
        {
            return "negTwo";
        }
        else if (inverval == -1)
        {
            return "negOne";
        }
        else if (inverval == 0)
        {
            return "zero";
        }
    }

    //convert Inverval to intent Inverval.
    this.convertIntervalBrownField = function (inverval) {
        if (inverval == "negSix")
        {
            return -6;
        }
        else if (inverval == "negFive")
        {
            return -5;
        }
        else if (inverval == "negFour")
        {
            return -4;
        }
        else if (inverval == "negThree")
        {
            return -3;
        }
        else if (inverval == "negTwo")
        {
            return -2;
        }
        else if (inverval == "negOne")
        {
            return -1;
        }
        else if (inverval == "zero")
        {
            return 0;
        }
    }


    this.getBaseFdnForPort = function (target, portId) {
        if (portId.startsWith("esat"))
        {
            return this.getBaseFdnForSatellitePort(target, portId);
        }
        var portIds = portId.split("/");
        var cardSlot;
        var xiomSlot;
        var mdaSlot;
        var connector;
        var portNumber

        portIds.forEach(function (item, index) {
            // logger.info("*********************item, index = " + item + "-----" + index);
            switch (index)
            {
                case 0:
                    cardSlot = item;
                    break;
                case 1:
                    //xiom
                    if (isNaN(item))
                    {
                        xiomSlot = item;
                    }
                    else
                    {
                        mdaSlot = item;
                    }
                    break;
                case 2:
                    //connector
                    if (isNaN(item))
                    {
                        connector = item;
                    }
                    else if (mdaSlot)
                    {
                        portNumber = item;
                    }
                    else
                    {
                        mdaSlot = item;
                    }
                    break;
                case 3:
                    //connector
                    if (isNaN(item))
                    {
                        connector = item;
                    }
                    else
                    {
                        portNumber = item;
                    }
                    break;
                case 4:
                    portNumber = item;
                    break;


            }
        });

        // logger.info("************ cardSlot =" + cardSlot + ",xiomSlot=" + xiomSlot + ",mdaSlot=" + mdaSlot + ",connector=" + connector + ",portNumber=" + portNumber);
        //"network:92.168.96.22:shelf-1:cardSlot-1:card:xioSlot-1:xiomCard:daughterCardSlot-1:daughterCard:conn-1:port-1"

        var portDn = "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card";
        if (xiomSlot)
        {
            portDn += ":xioSlot-" + xiomSlot.substring(1) + ":xiomCard";
        }
        if (mdaSlot)
        {
            portDn += ":daughterCardSlot-" + mdaSlot + ":daughterCard";
        }
        if (connector)
        {
            portDn += ":conn-" + connector.substring(1);
        }
        if (portNumber)
        {
            portDn += ":port-" + portNumber;
        }
        if (target && String(target).indexOf(':') !== -1) {
            portDn = this.modifyNeIdForIpV6(portDn, target);
        }
        logger.info("*********************portDn = " + portDn);
        return portDn;
        //return "network:" + target + ":shelf-1:cardSlot-" + cardSlot + ":card:daughterCardSlot-" + mdaSlot + ":daughterCard:port-" + portNumber;
    }

    this.getBaseFdnForSatellitePort = function (target, portId) {

        var portIds = (portId.split("-")[1]).split("/");
        var shelf = "shelf-1-5-";
        shelf += portIds[0];
        var satId = portIds[0];
        var cardSlot = "cardSlot-1:card";
        var mdaSlot = "daughterCardSlot-1:daughterCard";
        var portNumber = portIds[2];
        var snmpPortId = this.getSatellitePortSnmpId(satId, 1, portNumber, false, 5)
        //logger.info("******satellite port = shelf = "+shelf+", portnumber = "+portNumber +"\n portid = "+ portId+"\n portids = "+ portIds);
        var portDn = "network:" + target + ":" + shelf + ":" + cardSlot + ":" + mdaSlot + ":port-" + snmpPortId;
        if (target && String(target).indexOf(':') !== -1) {
            portDn = this.modifyNeIdForIpV6(portDn, target);
        }
        logger.info("SatPortDN = " + portDn);
        return portDn;
    }

    this.getSatellitePortSnmpId = function (aInSatId, aInSlotId, aInPortId, aInUplink, aInPhyShelfClass) {
        var aInSnmpIndex = aInPortId;
        var lUplinkBit = 0;
        if (aInUplink)
        {
            lUplinkBit = 1;
        }
        var lSatId = aInSatId << 16;
        var lSlotId = aInSlotId << 11;
        var lUplink = lUplinkBit << 10;
        var lSat = 136 << 23;
        aInSnmpIndex = lSat | lSatId | lSlotId | lUplink | aInSnmpIndex;
        return aInSnmpIndex;
    }

    this.modifyNeIdForIpV6 = function (objectFullName, neId) {
        logger.info("modifying NeId For IpV6");
        objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
        return objectFullName;
    }
}
