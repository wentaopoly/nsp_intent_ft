load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {
    this.getPolicyName = function (neId) {
        var className = "ixrqos.NetworkIngressPolicy";
        var searchObject = {
            "fullClassName": className,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "displayedName"
                ]
            }
        };
        logger.info(LOG_PREFIX + "final search object = {}", searchObject);
        return this.getData(neId, searchObject, "displayedName");
    }
    
    this.getSupportedAttributeDataList = function (neId, className) {
        var searchObject = {
            "fullClassName": "",
            "filter": {
                "and": {
                    "equal":
                        [
                            {
                                "name": "isLocal",
                                "value": 0
                            },
                            {
                                "name": "isBackup",
                                "value": 0
                            }
                        ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id",
                    "displayedName"
                ]
            }
        };
        switch (className) {
            case "ixrqos.IngressClassification":
                searchObject["fullClassName"] = className;
                return this.getGlobalData(neId, searchObject, className, "displayedName");
        }
    }
    
    this.getGlobalData = function (neId, searchObjectJson, className, attribute) {
        let nfmpFwk = new NfmpFwk();
        var result = [];
        var resultFetch = nfmpFwk.find(neId, searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response)[className];
        logger.info(LOG_PREFIX + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                result.push(finalResponse[index][attribute]);
            }
        }
        logger.info(LOG_PREFIX + "NFMP Global Data suggest result = \n" + JSON.stringify(result));
        return result;
    }

    this.getData = function (target, searchObjectJson, type, policyAttribute) {
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.find(target, searchObjectJson);
        logger.info(LOG_PREFIX + resultFetch.response);
        var finalResponse = JSON.parse(resultFetch.response)["ixrqos.NetworkIngressPolicy"];
        logger.info(LOG_PREFIX + "finalResponse = " + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                ret.push(finalResponse[index][type]);
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "NFMP suggest result = \n" + JSON.stringify(ret));
        return ret;
    }
}