function MdSuggest() {
    
    this.getPrefixListName = function(neId) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/policy-options/prefix-list?fields=name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}", neId, url);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:prefix-list'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }
}
