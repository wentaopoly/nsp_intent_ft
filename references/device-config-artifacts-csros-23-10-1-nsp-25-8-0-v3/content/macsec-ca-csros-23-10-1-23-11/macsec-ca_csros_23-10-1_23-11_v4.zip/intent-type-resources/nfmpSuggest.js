load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {
    let nfmpFwk = new NfmpFwk();
    this.getCaName = function () {
        var searchObjectJson = {
            "fullClassName": "macsec.ConnectivityAssociation",
            "resultFilter": {
                "attribute": [
                    "caName"
                ]
            }
        };
        return this.getData(searchObjectJson)
    }
    this.getData = function (searchObjectJson) {
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        finalResponse = finalResponse["macsec.ConnectivityAssociation"];
        logger.info(JSON.stringify(finalResponse));

        if (Object.keys(finalResponse).length !== 0)
        {
            finalResponse.forEach(function (value, index, array) {
                ret.push(value["caName"]);
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }

    this.getSites = function () {
        var searchObjectJson = {
            "fullClassName": "netw.NetworkElement",
            "resultFilter": {
                "children": "",
                "attribute": [
                    "ipAddress",
                    "chassisType",
                    "version",
                    "siteId",
                    "siteName"
                ]
            }
        };
        var result = {};
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        finalResponse = finalResponse["netw.NetworkElement"];
        logger.info(JSON.stringify(finalResponse));
        var data = finalResponse.map(function (ne) {
            var obj = {};
            obj["site-id"] = ne["siteId"];
            obj["ip-address"] = ne["ipAddress"];
            obj["site-name"] = ne["siteName"];
            obj["chassis-type"] = ne["chassisType"];
            obj["version"] = ne["version"];
            return obj;
        });
        result["data"] = JSON.stringify(data);
        logger.info("result = {}", JSON.stringify(result));
        return result;
    }

    this.getHsmId = function () {
        var searchObjectJson = {
            "fullClassName": "hsm.HSMConfig",
            "resultFilter": {
                "children": "",
                "attribute": [
                    "id",
                    "configPath",
                    "description"
                ]
            }
        };
        var result = {};
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        finalResponse = finalResponse["hsm.HSMConfig"];
        logger.info(JSON.stringify(finalResponse));
        var data = finalResponse.map(function (ne) {
            var obj = {};
            obj["hsm-id"] = ne["id"];
            obj["description"] = ne["description"];
            obj["config-file"] = ne["configPath"];
            return obj;
        });
        result["data"] = JSON.stringify(data);
        logger.info("result = {}", JSON.stringify(result));
        return result;
    }
}