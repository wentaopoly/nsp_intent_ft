var RuntimeException = Java.type('java.lang.RuntimeException');

load({
    script: resourceProvider.getResource("nfmp-fwk.js"),
    name: "NfmpFwk"
});
load({
    script: resourceProvider.getResource('parse-target.js'),
    name: 'ParseTarget'
});
load({
    script: resourceProvider.getResource("util-fwk.js"),
    name: "utilities"
});

function NfmpDiscoveryHelper() {
    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function(target, initialPropertyName) {

        let neId = parseTarget.getNeIdFromTarget(target);
        let filterId = util.getIpFilterId(target);
        let filterName = parseTarget.getUniqueIdentifier(target);
        let searchPayLoad = this.constructSearchString(neId, filterId, filterName);
        let searchResponse = nfmpFwk.find(neId, searchPayLoad);
        logger.info(JSON.stringify(searchResponse));
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                throw new RuntimeException("Failed to get IP filter info from nfm-p for Ne " + neId + " and IP filter Id: " + filterId );
            if(JSON.parse(searchResponse["response"]).length === 0)
                throw new RuntimeException("There is no IP filter with Name:" + filterName + " and Id:"+filterId );
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse[0];

    }

    this.extractDeviceConfig = function(defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        let ipFilterConfig = deviceConfig['properties'];
        if (null !== ipFilterConfig) {
            this.extractIPFilterProperties(parsedDefaultTargetData, ipFilterConfig);
        }
        let childrenConfig = deviceConfig["children"];
        if (undefined !== childrenConfig && null !== childrenConfig && childrenConfig.length !== 0) {

            let ipFilterEntryData = parsedDefaultTargetData['ip-filter']['entry'];
            if (ipFilterEntryData !== null && Array.isArray(ipFilterEntryData) && ipFilterEntryData.length !== 0)
            {
                let ipFilterEntryArray = this.extractIPFilterEntryData(ipFilterEntryData, childrenConfig);
                parsedDefaultTargetData['ip-filter']['entry'] = ipFilterEntryArray;
            }
        }
        else
        {
            delete parsedDefaultTargetData['ip-filter']['entry'];
        }

        //this.clearEmptiesAndNull(parsedDefaultTargetData);
        return parsedDefaultTargetData;
    }

    this.extractIPFilterEntryData = function(defaultIPFilterEntryData, childrenConfig)
    {
        let ipFilterEntryArray = [];
        let ipFilterEntryDefaults = defaultIPFilterEntryData[0];
        for (let i = 0; i < childrenConfig.length; i++)
        {
            let childConfig = childrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass === 'aclfilter.IpFilterEntry')
            {
                let ipFilterEntryData = JSON.parse(JSON.stringify(ipFilterEntryDefaults));
                ipFilterEntryData['entry-id'] = childConfig['properties']['id'];
                ipFilterEntryData['description'] = childConfig['properties']['description'];

                let filterProtocolList = childConfig['properties']['protocolListPointer'];
                if(filterProtocolList !== "")
                {
                    ipFilterEntryData['match']['protocol-list'] = filterProtocolList.replace("filterProtocolList:", "");
                }
                else{
                    ipFilterEntryData["match"]['protocol'] = util.transformIntentProtocol(childConfig['properties']['protocol']);
                }

                if (childConfig['properties']['ipAddress'] === '0.0.0.0' && childConfig['properties']['ipAddressMask'] ==='ipAddrMask0' && childConfig['properties']['ipPrefixListPointer'] === ""){
                    ipFilterEntryData['match']['ip'] = undefined;
                }
                else{
                    ipFilterEntryData['match']['ip'] = new Object();
                    let ipFilterPrefixList = childConfig['properties']['ipPrefixListPointer'];
                    if(ipFilterPrefixList !== "")
                    {
                        ipFilterEntryData['match']['ip']['match-address-choice'] = "ip-prefix-list";
                        ipFilterEntryData['match']['ip']['ip-prefix-list'] = ipFilterPrefixList.replace("filterPrefixList:", "");
                    }
                    else
                    {
                        ipFilterEntryData['match']['ip']['match-address-choice'] = "address-and-prefix-or-mask";
                        ipFilterEntryData['match']['ip']['address'] = childConfig['properties']['ipAddress'];
                        ipFilterEntryData['match']['ip']['mask'] = childConfig['properties']['ipAddressMask'].replace("ipAddrMask", "");
                    }
                }
                if (!this.isObjectExists(ipFilterEntryData['match']['ip']))
                {
                    if (childConfig['properties']['sourceIpAddress'] === '0.0.0.0' && childConfig['properties']['sourceIpAddressMask'] ==='ipAddrMask0' && childConfig['properties']['srcIpPrefixListPointer'] === ""){
                        ipFilterEntryData['match']['src-ip'] = undefined;
                    }
                    else{
                        ipFilterEntryData['match']['src-ip'] = new Object();
                        let srcIpFilterPrefixList = childConfig['properties']['srcIpPrefixListPointer'];
                        if(srcIpFilterPrefixList !== "")
                        {
                            ipFilterEntryData['match']['src-ip']['match-address-choice'] = "ip-prefix-list";
                            ipFilterEntryData['match']['src-ip']['ip-prefix-list'] = srcIpFilterPrefixList.replace("filterPrefixList:", "");
                        }
                        else
                        {
                            ipFilterEntryData['match']['src-ip']['match-address-choice'] = "address-and-prefix-or-mask";
                            ipFilterEntryData['match']['src-ip']['address'] = childConfig['properties']['sourceIpAddress'];
                            ipFilterEntryData['match']['src-ip']['mask'] = childConfig['properties']['sourceIpAddressMask'].replace("ipAddrMask", "");
                        }
                    }

                    if (childConfig['properties']['destinationIpAddress'] === '0.0.0.0' && childConfig['properties']['destinationIpAddressMask'] ==='ipAddrMask0' && childConfig['properties']['dstIpPrefixListPointer'] === ""){
                        ipFilterEntryData['match']['dst-ip'] = undefined;
                    }
                    else{
                        ipFilterEntryData['match']['dst-ip'] = new Object();
                        let dstIpFilterPrefixList = childConfig['properties']['dstIpPrefixListPointer'];
                        if(dstIpFilterPrefixList !== "")
                        {
                            ipFilterEntryData['match']['dst-ip']['match-address-choice'] = "ip-prefix-list";
                            ipFilterEntryData['match']['dst-ip']['ip-prefix-list'] = dstIpFilterPrefixList.replace("filterPrefixList:", "");
                        }
                        else
                        {
                            ipFilterEntryData['match']['dst-ip']['match-address-choice'] = "address-and-prefix-or-mask";
                            ipFilterEntryData['match']['dst-ip']['address'] = childConfig['properties']['destinationIpAddress'];
                            ipFilterEntryData['match']['dst-ip']['mask'] = childConfig['properties']['destinationIpAddressMask'].replace("ipAddrMask", "");
                        }
                    }
                }

                if((ipFilterEntryData['match']['protocol'] == "tcp" || ipFilterEntryData['match']['protocol'] == "udp" || ipFilterEntryData['match']['protocol'] == "tcp-udp" || ipFilterEntryData['match']['protocol'] == "sctp" || ipFilterEntryData['match']['protocol-list'] != null)
                    && childConfig['properties']['portSelector'])
                {
                    if(childConfig['properties']['portSelector'] == "AND_PORT")
                    {
                        ipFilterEntryData['match']['src-port'] = new Object();
                        if(childConfig['properties']['sourcePortListPointer'])
                        {
                            ipFilterEntryData["match"]["src-port"]["port"] = "port-list"
                            ipFilterEntryData['match']['src-port']['port-list'] = childConfig['properties']['sourcePortListPointer'].replace("filterPortList:", "")
                        }
                        else if(childConfig['properties']['sourceOperator'] == "EQUAL")
                        {
                            ipFilterEntryData["match"]["src-port"]["port"] = "eq"
                            ipFilterEntryData['match']['src-port']["eq"] = childConfig['properties']['sourcePort1'];
                        }
                        else if(childConfig['properties']['sourceOperator'] == "LESS_THAN")
                        {
                            ipFilterEntryData["match"]["src-port"]["port"] = "lt"
                            ipFilterEntryData['match']['src-port']["lt"] = childConfig['properties']['sourcePort1'];
                        }
                        else if(childConfig['properties']['sourceOperator'] == "GREATER_THAN")
                        {
                            ipFilterEntryData["match"]["src-port"]["port"] = "gt"
                            ipFilterEntryData['match']['src-port']["gt"] = childConfig['properties']['sourcePort1'];
                        }
                        else if(childConfig['properties']['sourceOperator'] == "RANGE")
                        {
                            ipFilterEntryData["match"]["src-port"]["port"] = "range"
                            ipFilterEntryData['match']['src-port']["range"] = new Object();
                            ipFilterEntryData['match']['src-port']["range"]["start"] = childConfig['properties']['sourcePort1'];
                            ipFilterEntryData['match']['src-port']["range"]["end"] = childConfig['properties']['sourcePort2'];
                        }

                        ipFilterEntryData['match']['dst-port'] = new Object();
                        if(childConfig['properties']['destinationPortListPointer'])
                        {
                            ipFilterEntryData["match"]["dst-port"]["port"] = "port-list"
                            ipFilterEntryData['match']['dst-port']['port-list'] = childConfig['properties']['destinationPortListPointer'].replace("filterPortList:", "")
                        }
                        else if(childConfig['properties']['destinationOperator'] == "EQUAL")
                        {
                            ipFilterEntryData["match"]["dst-port"]["port"] = "eq"
                            ipFilterEntryData['match']['dst-port']["eq"] = childConfig['properties']['destinationPort1'];
                        }
                        else if(childConfig['properties']['destinationOperator'] == "LESS_THAN")
                        {
                            ipFilterEntryData["match"]["dst-port"]["port"] = "lt"
                            ipFilterEntryData['match']['dst-port']["lt"] = childConfig['properties']['destinationPort1'];
                        }
                        else if(childConfig['properties']['destinationOperator'] == "GREATER_THAN")
                        {
                            ipFilterEntryData["match"]["dst-port"]["port"] = "gt"
                            ipFilterEntryData['match']['dst-port']["gt"] = childConfig['properties']['destinationPort1'];
                        }
                        else if(childConfig['properties']['destinationOperator'] == "RANGE")
                        {
                            ipFilterEntryData["match"]["dst-port"]["port"] = "range"
                            ipFilterEntryData['match']['dst-port']["range"] = new Object();
                            ipFilterEntryData['match']['dst-port']["range"]["start"] = childConfig['properties']['destinationPort1'];
                            ipFilterEntryData['match']['dst-port']["range"]["end"] = childConfig['properties']['destinationPort2'];
                        }
                        ipFilterEntryData['match']['port'] = undefined;
                    }
                    else if(childConfig['properties']['portSelector'] == "OR_PORT")
                    {
                        ipFilterEntryData['match']['port'] = new Object();
                        if(childConfig['properties']['portListPointer'])
                        {
                            ipFilterEntryData["match"]["port"]["port"] = "port-list"
                            ipFilterEntryData['match']['port']['port-list'] = childConfig['properties']['portListPointer'].replace("filterPortList:", "")
                        }
                        else if(childConfig['properties']['portOperator'] == "EQUAL")
                        {
                            ipFilterEntryData["match"]["port"]["port"] = "eq"
                            ipFilterEntryData['match']['port']["eq"] = childConfig['properties']['port1'];
                        }
                        else if(childConfig['properties']['portOperator'] == "LESS_THAN")
                        {
                            ipFilterEntryData["match"]["port"]["port"] = "lt"
                            ipFilterEntryData['match']['port']["lt"] = childConfig['properties']['port1'];
                        }
                        else if(childConfig['properties']['portOperator'] == "GREATER_THAN")
                        {
                            ipFilterEntryData["match"]["port"]["port"] = "gt"
                            ipFilterEntryData['match']['port']["gt"] = childConfig['properties']['port1'];
                        }
                        else if(childConfig['properties']['portOperator'] == "RANGE")
                        {
                            ipFilterEntryData["match"]["port"]["port"] = "range"
                            ipFilterEntryData['match']['port']["range"] = new Object();
                            ipFilterEntryData['match']['port']["range"]["start"] = childConfig['properties']['port1'];
                            ipFilterEntryData['match']['port']["range"]["end"] = childConfig['properties']['port2'];
                        }
                        ipFilterEntryData["match"]["src-port"] = undefined;
                        ipFilterEntryData["match"]["dst-port"] = undefined;
                    }
                    else
                    {
                        ipFilterEntryData['match']['src-port'] = new Object();
                        if(childConfig['properties']['sourceOperator'] == "EQUAL")
                        {
                            ipFilterEntryData["match"]["src-port"]["port"] = "eq"
                            ipFilterEntryData['match']['src-port']["eq"] = childConfig['properties']['sourcePort1'];
                        }
                        else if(childConfig['properties']['sourceOperator'] == "LESS_THAN")
                        {
                            ipFilterEntryData["match"]["src-port"]["port"] = "lt"
                            ipFilterEntryData['match']['src-port']["lt"] = childConfig['properties']['sourcePort1'];
                        }
                        else if(childConfig['properties']['sourceOperator'] == "GREATER_THAN")
                        {
                            ipFilterEntryData["match"]["src-port"]["port"] = "gt"
                            ipFilterEntryData['match']['src-port']["gt"] = childConfig['properties']['sourcePort1'];
                        }
                        else if(childConfig['properties']['sourceOperator'] == "RANGE")
                        {
                            ipFilterEntryData["match"]["src-port"]["port"] = "range"
                            ipFilterEntryData['match']['src-port']["range"] = new Object();
                            ipFilterEntryData['match']['src-port']["range"]["start"] = childConfig['properties']['sourcePort1'];
                            ipFilterEntryData['match']['src-port']["range"]["end"] = childConfig['properties']['sourcePort2'];
                        }

                        ipFilterEntryData['match']['dst-port'] = new Object();
                        if(childConfig['properties']['destinationOperator'] == "EQUAL")
                        {
                            ipFilterEntryData["match"]["dst-port"]["port"] = "eq"
                            ipFilterEntryData['match']['dst-port']["eq"] = childConfig['properties']['destinationPort1'];
                        }
                        else if(childConfig['properties']['destinationOperator'] == "LESS_THAN")
                        {
                            ipFilterEntryData["match"]["dst-port"]["port"] = "lt"
                            ipFilterEntryData['match']['dst-port']["lt"] = childConfig['properties']['destinationPort1'];
                        }
                        else if(childConfig['properties']['destinationOperator'] == "GREATER_THAN")
                        {
                            ipFilterEntryData["match"]["dst-port"]["port"] = "gt"
                            ipFilterEntryData['match']['dst-port']["gt"] = childConfig['properties']['destinationPort1'];
                        }
                        else if(childConfig['properties']['destinationOperator'] == "RANGE")
                        {
                            ipFilterEntryData["match"]["dst-port"]["port"] = "range"
                            ipFilterEntryData['match']['dst-port']["range"] = new Object();
                            ipFilterEntryData['match']['dst-port']["range"]["start"] = childConfig['properties']['destinationPort1'];
                            ipFilterEntryData['match']['dst-port']["range"]["end"] = childConfig['properties']['destinationPort2'];
                        }
                        ipFilterEntryData['match']['port'] = undefined;
                    }
                }
                else
                {
                    ipFilterEntryData['match']['src-port'] = undefined;
                    ipFilterEntryData['match']['dst-port'] = undefined;
                    ipFilterEntryData['match']['port'] = undefined;
                }
                this.clearEmptiesAndNull(ipFilterEntryData);

                ipFilterEntryData['action'] = new Object();
                if(childConfig['properties']['action'] == "forward")
                {
                    ipFilterEntryData['action']['accept'] = [null]
                }
                if(childConfig['properties']['action'] == "drop")
                {
                    ipFilterEntryData['action']['drop'] =  [null]
                }

                ipFilterEntryArray.push(ipFilterEntryData);
            }
        }
        return ipFilterEntryArray;

    }

    this.extractIPFilterProperties = function(defaultTargetData, ipFilterConfig)
    {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++) {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object') {
                let mappings = modelDeviceMapping.getMapping("IPfilter");
                this.traverseAndUpdateConfig(targetKey, targetObj, ipFilterConfig, mappings);
            }
        }
    }

    this.traverseAndUpdateConfig = function(objKey, obj, parsedDeviceConfig, mappings)
    {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++)
        {
            let key = keys[i];
            let value = obj[key];

            let mappedKey = objKey + "." + key;
            if (mappedKey !== "ip-filter.entry")
            {
                if (value != null && typeof value === 'object')
                {
                    this.traverseAndUpdateConfig(mappedKey, value, parsedDeviceConfig, mappings);
                }
                else
                {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }


    this.getAndUpdateFromDeviceConfig = function(mappings, mappedKey, targetKey, targetObj, parsedDeviceConfig) {
        // Get the key from mapping against targetKey
        // If the mapping key is not undefined, Get the value from deviceKey
        // if the value from deviceConfig against that mapping key is not n
        let nfmpKey = mappings[mappedKey];
        let deviceValue = parsedDeviceConfig[nfmpKey];

        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue, parsedDeviceConfig);

    }

    this.transformDeviceValue = function(mappedKey, deviceValue, parsedDeviceConfig) {
        if (deviceValue !== null) {
            switch (mappedKey)
            {
                case "ip-filter.default-action":
                    deviceValue = util.transformIntentDefaultAction(deviceValue);
                    break;
                default:
            }
            return deviceValue;
        }
    }



    this.constructSearchString = function(neId, filterId, filterName) {
        let filterExpression = "siteId='" + neId + "' AND id='" + filterId + "' AND filterName='" + filterName + "'";
        let jsonPayLoad = {
            "fullClassName": "aclfilter.IpFilter",
            "filter": {
                "filterExpression": filterExpression
            }
        };

        return jsonPayLoad;
    }

    this.clearEmptiesAndNull = function (o)
    {
        for (let k in o)
        {
            if(o[k] === null)
            {
                delete o[k];
            }
            if (!o[k] || typeof o[k] !== "object")
            {
                continue
            }

            this.clearEmptiesAndNull(o[k]);
            if (Object.keys(o[k]).length === 0)
            {
                delete o[k];
            }
        }
    }

    this.isObjectExists = function (obj) {
        return obj !== undefined && obj !== null;
    }
}
