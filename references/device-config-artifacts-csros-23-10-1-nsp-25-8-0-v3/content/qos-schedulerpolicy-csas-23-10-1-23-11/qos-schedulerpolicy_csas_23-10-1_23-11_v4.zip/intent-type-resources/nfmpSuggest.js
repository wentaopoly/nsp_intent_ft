load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {
    this.getPolicyName = function (neId) {
        var searchObjectJson = {
            "fullClassName": "sasqos.PortScheduler",
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObjectJson)
    }

    this.getData = function (searchObjectJson) {
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        finalResponse = finalResponse["sasqos.PortScheduler"];
        logger.info(JSON.stringify(finalResponse));

        if (Object.keys(finalResponse).length !== 0)
        {
            finalResponse.forEach(function (value, index, array) {
                ret.push(value["displayedName"]);
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }
}