var RuntimeException = Java.type('java.lang.RuntimeException');
load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});

function NfmpMacsecCA() {

    var util = new utilities();
    var parseTarget = new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var savedTopology;
    var isAudit = false;
    let savePreSharedKeyMap = new Map();
    const nfmpFwkPostRequest = "/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true"
    this.synchronize = function (input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        if (input.getNetworkState().name() == "delete")
        {
            logger.info("Calling syncDelete");
            return this.syncDelete(input, result);
        }
        savedTopology = input.getCurrentTopology();
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        var intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        //set the policy name from target
        intentConfig["ca-name"] = input.getTarget().split("#")[2];
        logger.info("Configuration to be pushed = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        this.createOrModify(neId, intentConfig);
        logger.info("savedTopology = {}", savedTopology)
        result.setTopology(savedTopology);
        result.getTopology().setXtraInfo(savedTopology.getXtraInfo());
        return util.setSuccessResult(result, savedTopology);
    }
    this.syncDelete = function (input, result) {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var caName = input.getTarget().split("#")[2];
        var objectFullName = "macsmgr:ca-" + caName;
        logger.info("Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success)
        {
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }
    this.createOrModify = function (neId, intentConfig) {
        var macSecCAPayload = this.createMacSecCAPayLoad(neId, intentConfig);
        this.modifyRequest(neId, macSecCAPayload);
        let caName = intentConfig["ca-name"];
        //create-or-delete pre-shared keys
        if (savedTopology == null)
        {
            logger.info("Creating topology to save pre-shared-keys");
            savedTopology = topologyFactory.createServiceTopology();
        }
        logger.info("Populate savePreSharedKeyMap");
        logger.info("savedTopology = {}", savedTopology);
        logger.info("savedTopology.getXtraInfo() = {}", savedTopology.getXtraInfo());

        for (let index in savedTopology.getXtraInfo())
        {
            let key = savedTopology.getXtraInfo()[index].getKey();
            let value = savedTopology.getXtraInfo()[index].getValue();
            savePreSharedKeyMap.set(key, value);
        }
        logger.info("************savePreSharedKeyMap-start*********************")
        savePreSharedKeyMap.forEach((values, keys) => {
            logger.info("key = {}, value = {}", keys, values);
        });
        logger.info("************savePreSharedKeyMap-end*********************")
        savedTopology.setXtraInfo([]);

        let nfmpPreSharedKeysMap = new Map();
        let findPreSharedKeys = {
            "fullClassName": "macsec.PreSharedKey",
            "filter": {
                "equal": {
                    "name": "caName",
                    "value": caName
                }
            }
        };
        logger.info("Find Preshared keys payload = {}", JSON.stringify(findPreSharedKeys));
        let resultFindPreSharedKeys = nfmpFwk.post("/v3/search", findPreSharedKeys);
        if (!resultFindPreSharedKeys.success)
        {
            throw new RuntimeException(resultFindPreSharedKeys.msg);
        }
        let finalResponse = JSON.parse(resultFindPreSharedKeys.response);
        logger.info("Final response of search = {}", JSON.stringify(finalResponse));
        if (finalResponse["macsec.PreSharedKey"])
        {
            let preSharedKeys = finalResponse["macsec.PreSharedKey"];
            if (!Array.isArray(preSharedKeys))
            {
                preSharedKeys = [preSharedKeys];
            }
            for (let index in preSharedKeys)
            {
                let preSharedKey = preSharedKeys[index];
                let pskId = preSharedKey["pskId"];
                let encryptType = preSharedKey["encryptType"];
                nfmpPreSharedKeysMap.set(pskId, encryptType);
            }
        }
        logger.info("************nfmpPreSharedKeysMap-start*********************")
        nfmpPreSharedKeysMap.forEach((values, keys) => {
            logger.info("key = {}, value = {}", keys, values);
        });
        logger.info("************nfmpPreSharedKeysMap-end*********************")
        util.delay(2000);

        if (intentConfig["static-cak"]["pre-shared-key"])
        {
            var preSharedKeysConfig = intentConfig["static-cak"]["pre-shared-key"];
            if (!Array.isArray(preSharedKeysConfig))
            {
                preSharedKeysConfig = [preSharedKeysConfig];
            }
            for (var index in preSharedKeysConfig)
            {
                var preSharedKeyConfig = preSharedKeysConfig[index];
                logger.info("preSharedKeyConfig = {}", JSON.stringify(preSharedKeyConfig))
                let pskId = preSharedKeyConfig["psk-id"];
                let encryptType = preSharedKeyConfig["encryption-type"];
                logger.info("savePreSharedKeyMap.has(pskId) = {}", savePreSharedKeyMap.has(pskId));
                logger.info("nfmpPreSharedKeysMap.has(pskId) = {}", nfmpPreSharedKeysMap.has(pskId));
                if (savePreSharedKeyMap.has(pskId) && nfmpPreSharedKeysMap.has(pskId))
                {
                    logger.info("savePreSharedKeyMap.get(pskId) = {}", savePreSharedKeyMap.get(pskId));
                    logger.info("nfmpPreSharedKeysMap.get(pskId) = {}", nfmpPreSharedKeysMap.get(pskId));
                    if (savePreSharedKeyMap.get(pskId) !== nfmpPreSharedKeysMap.get(pskId))
                    {
                        this.createPsk(caName, pskId, encryptType)
                    }
                }
                else
                {
                    this.createPsk(caName, pskId, encryptType);
                }
            }
            if (preSharedKeysConfig.length === 1)
            {
                var pskId = preSharedKeysConfig[0]["psk-id"];
                var pskIdtoBeDeleted;
                switch (pskId)
                {
                    case "1":
                        pskIdtoBeDeleted = "2"
                        break;
                    case "2":
                        pskIdtoBeDeleted = "1"
                        break;
                }
                this.deletePsk(caName, pskIdtoBeDeleted);
            }
        }
        else
        {
            for (let i = 1; i <= 2; i++)
            {
                this.deletePsk(caName, i.toString());
            }
        }
        logger.info("************savePreSharedKeyMap-start*********************")
        savePreSharedKeyMap.forEach((values, keys) => {
            logger.info("key = {}, value = {}", keys, values);
        });
        logger.info("************savePreSharedKeyMap-end*********************")
        savePreSharedKeyMap.forEach((values, keys) => {
            let xtraInfo = topologyFactory.createTopologyXtraInfoFrom(keys, values);
            savedTopology.addXtraInfo(xtraInfo);
        });

        //distribute PSK to sites
        if (intentConfig["sites"])
        {
            var sitesConfig = intentConfig["sites"];
            if (!Array.isArray(sitesConfig))
            {
                sitesConfig = [sitesConfig];
            }
            var siteArray = [];
            for (var index in sitesConfig)
            {
                var siteConfig = sitesConfig[index];
                var siteId = siteConfig["site-id"];
                siteArray.push(siteId);

            }
            var distributePsk = {
                "macsec.StaticCAK.distributePSKs": {
                    "deployer": "immediate",
                    "instanceFullName": "macsmgr:ca-" + caName + ":scak",
                    "aInSiteIdList": {
                        "string": siteArray
                    }
                }
            }
            logger.info("distributePsk payload = {}", JSON.stringify(distributePsk));
            var result = nfmpFwk.post(nfmpFwkPostRequest, distributePsk);
            logger.info(JSON.stringify(result));
            if (!result.success)
            {
                throw new RuntimeException(result.msg);
            }
            var failureReason = (JSON.parse(result.response))["macsec.StaticCAK.distributePSKsException"];
            if (failureReason)
            {
                logger.error(JSON.stringify(failureReason));
            }
        }
    }
    this.createPsk = function (caName, pskId, encryptType) {
        let createPsk = {
            "macsec.StaticCAK.createPsk": {
                "deployer": "immediate",
                "instanceFullName": "macsmgr:ca-" + caName + ":scak",
                "aInPskIndex": pskId,
                "aInEncryptionType": encryptType,
            }
        }
        logger.info("createPsk payload = {}", JSON.stringify(createPsk));
        var result = nfmpFwk.post(nfmpFwkPostRequest, createPsk);
        logger.info(JSON.stringify(result));
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        var failureReason = (JSON.parse(result.response))["macsec.StaticCAK.createPskException"];
        if (failureReason)
        {
            logger.error(JSON.stringify(failureReason));
        }
        savePreSharedKeyMap.set(pskId, encryptType);
        util.delay(2000);
    }
    this.deletePsk = function (caName, pskId) {
        var deletePsk = {
            "macsec.StaticCAK.deletePsk": {
                "deployer": "immediate",
                "instanceFullName": "macsmgr:ca-" + caName + ":scak",
                "aInPskIndex": pskId,
            }
        }
        logger.info("pskId = {}", pskId);
        logger.info("deletePsk payload = {}", JSON.stringify(deletePsk));
        var result = nfmpFwk.post(nfmpFwkPostRequest, deletePsk);
        logger.info(JSON.stringify(result));
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        var failureReason = (JSON.parse(result.response))["macsec.StaticCAK.deletePskException"];
        if (failureReason)
        {
            logger.error(JSON.stringify(failureReason));
        }
        logger.info("************befor delete savePreSharedKeyMap-start*********************")
        savePreSharedKeyMap.forEach((values, keys) => {
            logger.info("key = {}, value = {}", keys, values);
        });
        logger.info("************befor delete savePreSharedKeyMap-end*********************")
        savePreSharedKeyMap.delete(pskId);
        logger.info("************after delete savePreSharedKeyMap-start*********************")
        savePreSharedKeyMap.forEach((values, keys) => {
            logger.info("key = {}, value = {}", keys, values);
        });
        logger.info("************after delete savePreSharedKeyMap-end*********************")
        util.delay(2000);
    }
    this.createMacSecCAPayLoad = function (neId, intentConfig) {
        var fullClassName = "macsec.ConnectivityAssociation";
        var fdn = "macsmgr";
        var objectFullName = "macsmgr:ca-" + intentConfig["ca-name"];
        var properties = {};
        properties["caName"] = intentConfig["ca-name"];
        properties["administrativeState"] = util.convertAdminStateGreenField(intentConfig["admin-state"]);
        properties["description"] = intentConfig["description"];
        properties["replayWindowSize"] = intentConfig["replay-window-size"];
        properties["replayProtect"] = intentConfig["replay-protection"];
        properties["macsecEncrypt"] = intentConfig["macsec-encrypt"];
        properties["clearTagMode"] = intentConfig["clear-tag-mode"];
        properties["encryptOffset"] = intentConfig["encryption-offset"];
        properties["cipherSuite"] = intentConfig["cipher-suite"];
        properties["anySecReserved"] = intentConfig["anysec-reserved"];
        properties["skipOfflineNodes"] = intentConfig["keying-parameters"]["skip-offline-nodes"];
        properties["hsmMode"] = intentConfig["keying-parameters"]["key-source"];
        if (properties["hsmMode"] === "useHSMOnly")
        {
            properties["hsmConfigPointer"] = "hsmMgr:hsm-" + intentConfig["keying-parameters"]["hsm-id"];
        }
        var childProperties = {};
        if (intentConfig["static-cak"])
        {
            var staticCakProperties = {};
            staticCakProperties["activePskIndex"] = intentConfig["static-cak"]["active-psk"];
            staticCakProperties["helloInterval"] = util.convertHelloIntervalGreenField(intentConfig["static-cak"]["mka-hello-interval"]);
            staticCakProperties["keyServerPriority"] = intentConfig["static-cak"]["mka-key-server-priority"];
            if (isAudit)
            {
                if (intentConfig["static-cak"]["pre-shared-key"])
                {
                    staticCakProperties["children-Set"] = {};
                    staticCakProperties["children-Set"]["macsec.PreSharedKey"] = [];
                    var preSharedKeysConfig = intentConfig["static-cak"]["pre-shared-key"];
                    if (!Array.isArray(preSharedKeysConfig))
                    {
                        preSharedKeysConfig = [preSharedKeysConfig];
                    }
                    for (var index in preSharedKeysConfig)
                    {
                        var preSharedKeyConfig = preSharedKeysConfig[index];
                        var preSharedKeyProperties = {};
                        preSharedKeyProperties["pskId"] = preSharedKeyConfig["psk-id"];
                        preSharedKeyProperties["encryptType"] = preSharedKeyConfig["encryption-type"];
                        (staticCakProperties["children-Set"]["macsec.PreSharedKey"]).push(preSharedKeyProperties);
                    }
                }
            }
            childProperties["macsec.StaticCAK"] = staticCakProperties;
        }
        if (intentConfig["sites"])
        {
            var sitesConfig = intentConfig["sites"];
            if (!Array.isArray(sitesConfig))
            {
                sitesConfig = [sitesConfig];
            }
            var siteConfigArray = [];
            for (var index in sitesConfig)
            {
                var siteConfig = sitesConfig[index];
                var siteProperties = {};

                siteProperties["siteId"] = siteConfig["site-id"];
                const siteId = siteConfig["site-id"];
                if(siteId.indexOf(":") !== -1)
                {
                   siteProperties["ipAddressType"] = "ipv6"
                }

                siteProperties["delayProtection"] = siteConfig["delay-protection"];
                //required properties on nfmp
                siteProperties["macsecEncrypt"] = intentConfig["macsec-encrypt"];
                siteProperties["clearTagMode"] = intentConfig["clear-tag-mode"];
                siteProperties["encryptOffset"] = intentConfig["encryption-offset"];
                siteProperties["cipherSuite"] = intentConfig["cipher-suite"];
                //inherit properties on nfmp
                siteProperties["administrativeState"] = util.convertAdminStateGreenField(intentConfig["admin-state"]);
                siteProperties["description"] = intentConfig["description"];
                siteProperties["replayWindowSize"] = intentConfig["replay-window-size"];
                siteProperties["replayProtect"] = intentConfig["replay-protection"];

                if (siteConfig["inherit-global-parameters"]["edit-admin-state"] === true)
                {
                    siteProperties["administrativeState"] = util.convertAdminStateGreenField(siteConfig["inherit-global-parameters"]["admin-state"]);
                }
                if (siteConfig["inherit-global-parameters"]["edit-description"] === true)
                {
                    siteProperties["description"] = siteConfig["inherit-global-parameters"]["description"];
                }
                if (siteConfig["inherit-global-parameters"]["edit-replay-window-size"] === true)
                {
                    siteProperties["replayWindowSize"] = siteConfig["inherit-global-parameters"]["replay-window-size"];
                }
                if (siteConfig["inherit-global-parameters"]["edit-replay-protection"] === true)
                {
                    siteProperties["replayProtect"] = siteConfig["inherit-global-parameters"]["replay-protection"];
                }
                var siteStaticCakProperties = {};
                siteStaticCakProperties["activePskIndex"] = intentConfig["static-cak"]["active-psk"];
                siteStaticCakProperties["helloInterval"] = util.convertHelloIntervalGreenField(intentConfig["static-cak"]["mka-hello-interval"]);
                siteStaticCakProperties["keyServerPriority"] = intentConfig["static-cak"]["mka-key-server-priority"];

                if (siteConfig["inherit-global-parameters"]["edit-mka-hello-interval"] === true)
                {
                    siteStaticCakProperties["helloInterval"] = util.convertHelloIntervalGreenField(siteConfig["inherit-global-parameters"]["mka-hello-interval"]);
                }
                if (siteConfig["inherit-global-parameters"]["edit-mka-key-server-priority"] === true)
                {
                    siteStaticCakProperties["keyServerPriority"] = siteConfig["inherit-global-parameters"]["mka-key-server-priority"];
                }

                siteProperties["children-Set"] = {};
                siteProperties["children-Set"]["macsec.StaticCAK"] = siteStaticCakProperties;

                siteConfigArray.push(siteProperties);
            }
            childProperties["macsec.CASite"] = siteConfigArray;
        }
        else
        {
            childProperties["macsec.CASite"] = [];
        }
        var macSecPayload = util.editPayload(fdn, properties, childProperties, fullClassName, objectFullName);
        return macSecPayload;
    }
    this.modifyRequest = function (neId, payload) {
        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }
    this.audit = function (input, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        isAudit = true;
        var lConfig = JSON.parse(input.getJsonIntentConfiguration())[0];
        var intentConfig = lConfig[Object.keys(lConfig)[0]][initialPropertyName];
        logger.info("intentConfig = {} ", JSON.stringify(intentConfig));
        intentConfig["ca-name"] = input.getTarget().split("#")[2];
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        logger.info("auditing configuration = " + JSON.stringify(intentConfig));
        logger.info("Target device = " + neId);
        if (intentConfig)
        {
            this.auditAndCompare(neId, intentConfig, auditReport);
        }
        else
        {
            throw "configuration not available in the intent";
        }
        return auditReport
    }
    this.auditAndCompare = function (neId, intentConfig, auditReport) {
        var macSecCAPayload = this.createMacSecCAPayLoad(neId, intentConfig);
        var result = this.auditRequest(neId, macSecCAPayload);
        auditReport = util.reportMisaligned(neId, result, auditReport);
        return auditReport;
    }
    this.auditRequest = function (neId, payload) {
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
            throw new RuntimeException(result.msg);
        }
        return result;
    }
}
