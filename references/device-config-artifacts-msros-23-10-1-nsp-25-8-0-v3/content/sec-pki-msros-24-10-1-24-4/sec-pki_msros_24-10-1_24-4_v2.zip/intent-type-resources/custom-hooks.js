load({script: resourceProvider.getResource("parse-target.js"), name: "ParseTarget"});
load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
function CustomHooks() {
var ipv6AddressUtil = new IPv6AddressUtil();
var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,5}(:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){6}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(\/(0|[1-9][0-9]?|1[0-1][0-9]?|12[0-8]))?$/;
    /**
   * PreAudit Hook
   */
  const preAudit = (inputObj) => {
     /**
     * Write your custom preAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName
     *
     */

    logger.info("[CUSTOM-HOOKS] preAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

    var target = inputObj["target"];
    var intentConfig = inputObj["intentConfig"];
    var neId = parseTarget.getNeIdFromTarget(target);
    intentConfig = this.removeEmptyContainers("", intentConfig, "", target);

    inputObj["intentConfig"] = intentConfig;

    if(inputObj["intentConfig"] && inputObj["intentConfig"]["ca-profile"]) {

      for(let i=0;i<inputObj["intentConfig"]["ca-profile"].length;i++) {

        if(inputObj["intentConfig"]["ca-profile"][i] && inputObj["intentConfig"]["ca-profile"][i]["cmpv2"] && inputObj["intentConfig"]["ca-profile"][i]["cmpv2"]["key-list"] && inputObj["intentConfig"]["ca-profile"][i]["cmpv2"]["key-list"]["key"] && inputObj["intentConfig"]["ca-profile"][i]["cmpv2"]["key-list"]["key"]) {

          for(let j=0;j<inputObj["intentConfig"]["ca-profile"][i]["cmpv2"]["key-list"]["key"].length;j++) {

            if(inputObj["intentConfig"]["ca-profile"][i] && inputObj["intentConfig"]["ca-profile"][i]["cmpv2"] && inputObj["intentConfig"]["ca-profile"][i]["cmpv2"]["key-list"] && inputObj["intentConfig"]["ca-profile"][i]["cmpv2"]["key-list"]["key"] && inputObj["intentConfig"]["ca-profile"][i]["cmpv2"]["key-list"]["key"] && inputObj["intentConfig"]["ca-profile"][i]["cmpv2"]["key-list"]["key"][j] && inputObj["intentConfig"]["ca-profile"][i]["cmpv2"]["key-list"]["key"][j]["password"]) {

              delete inputObj["intentConfig"]["ca-profile"][i]["cmpv2"]["key-list"]["key"][j]["password"];
            }
          }
        }
      }
    }
    if(inputObj["intentConfig"] && inputObj["intentConfig"]["est-profile"]) {
      for(let i=0;i<inputObj["intentConfig"]["est-profile"].length;i++) {
        if(inputObj["intentConfig"]["est-profile"][i] && inputObj["intentConfig"]["est-profile"][i]["http-authentication"] && inputObj["intentConfig"]["est-profile"][i]["http-authentication"]["password"]) {
          delete inputObj["intentConfig"]["est-profile"][i]["http-authentication"]["password"];
        }
      }
    }
  if(inputObj["intentConfig"]["est-profile"]) {
      for(let i=0;i<inputObj["intentConfig"]["est-profile"].length;i++) {
      if(inputObj["intentConfig"]["est-profile"][i] && inputObj["intentConfig"]["est-profile"][i]["server"] && inputObj["intentConfig"]["est-profile"][i]["server"]["ipv6"]) {
         inputObj["intentConfig"]["est-profile"][i]["server"]["ipv6"] = ipv6AddressUtil.expandIPv6Address(inputObj["intentConfig"]["est-profile"][i]["server"]["ipv6"]);
      }
    }
  }


    if(inputObj["intentConfig"] && inputObj["intentConfig"]["certificate-update-profile"]) {
      for(let i=0; i<inputObj["intentConfig"]["certificate-update-profile"].length; i++) {
        if(inputObj["intentConfig"]["certificate-update-profile"][i] && inputObj["intentConfig"]["certificate-update-profile"][i]["same-as-existing-key"] == true) {
          inputObj["intentConfig"]["certificate-update-profile"][i]["same-as-existing-key"] = [null];
        }
        else if(inputObj["intentConfig"]["certificate-update-profile"][i] && inputObj["intentConfig"]["certificate-update-profile"][i]["same-as-existing-key"] == false) {
          delete inputObj["intentConfig"]["certificate-update-profile"][i]["same-as-existing-key"];
        }
      }
    }

    if(inputObj["intentConfig"] && inputObj["intentConfig"]["ca-profile"]) {
      for(let i=0; i<inputObj["intentConfig"]["ca-profile"].length; i++) {
        if(inputObj["intentConfig"]["ca-profile"] && inputObj["intentConfig"]["ca-profile"][i] && inputObj["intentConfig"]["ca-profile"][i]["cmpv2"] && inputObj["intentConfig"]["ca-profile"][i]["cmpv2"]["response-signing-use-extracert"] == true) {

          inputObj["intentConfig"]["ca-profile"][i]["cmpv2"]["response-signing-use-extracert"] = [null];
        }
        else if(inputObj["intentConfig"]["ca-profile"] && inputObj["intentConfig"]["ca-profile"][i] && inputObj["intentConfig"]["ca-profile"][i]["cmpv2"] && inputObj["intentConfig"]["ca-profile"][i]["cmpv2"]["response-signing-use-extracert"] == false) {
          delete inputObj["intentConfig"]["ca-profile"][i]["cmpv2"]["response-signing-use-extracert"];
        }
      }
    }

  };

  /**
   * PostAudit Hook
   */
  const postAudit = (inputObj) => {
    /**
     * Write your custom postAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName, auditReport
     *
     */

    logger.info("[CUSTOM-HOOKS] postAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));


  };

  /**
   * PreSync Hook
   */
  const preSync = (inputObj) => {
    /**
     * Write your custom preSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] preSync call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

    var config = JSON.parse(inputObj["config"]);


    var target = inputObj["target"];
    config = this.removeEmptyContainers("", config, "", target);
    config = this.expandIPv6(config);

    if(config && config[0] && config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"] && config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"] && config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"]["certificate-update-profile"]) {

      for(let i=0; i<config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"]["certificate-update-profile"].length; i++) {

        if(config && config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"]["certificate-update-profile"][i]["same-as-existing-key"] == true) {

          config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"]["certificate-update-profile"][i]["same-as-existing-key"] = [null];
        }
        else if(config && config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"]["certificate-update-profile"][i]["same-as-existing-key"] == false) {
          delete config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"]["certificate-update-profile"][i]["same-as-existing-key"];
        }
      }
    }

    if(config && config[0] && config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"] && config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"] && config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"]["ca-profile"]) {

      for(let i=0; i<config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"]["ca-profile"].length; i++) {

        if(config && config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"]["ca-profile"][i] && config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"]["ca-profile"][i]["cmpv2"] && config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"]["ca-profile"][i]["cmpv2"]["response-signing-use-extracert"] == true) {

          config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"]["ca-profile"][i]["cmpv2"]["response-signing-use-extracert"] = [null];
        }
        else if(config && config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"]["ca-profile"][i] && config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"]["ca-profile"][i]["cmpv2"] && config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"]["ca-profile"][i]["cmpv2"]["response-signing-use-extracert"] == false) {
          delete config[0]["sec-pki_msros_24-10-1_24-4:sec-pki_msros_24-10-1_24-4"]["pki"]["ca-profile"][i]["cmpv2"]["response-signing-use-extracert"];
        }
      }
    }

    inputObj["config"] = JSON.stringify(config);


  };

  /**
   * PostSync Hook
   */
  const postSync = (inputObj) => {
    /**
     * Write your custom postSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] postSync call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

  };

  /**
   *
   * PostDiscovery Hook
   */
  const postDiscovery = (inputObj) => {
    /**
     * Write your custom postDiscovery logic here
     * inputObj by default contains the following keys:
     *        deviceConfig, intentContainer, neId,
     *        targetDataStruct, templateName, deviceYangModuleName
     */

    logger.info("[CUSTOM-HOOKS] postDiscovery call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

    if(inputObj && inputObj["deviceConfig"] && inputObj["deviceConfig"]["certificate-update-profile"]) {

      for(let i=0; i<inputObj["deviceConfig"]["certificate-update-profile"].length; i++) {

        if(inputObj["deviceConfig"]["certificate-update-profile"][i] && inputObj["deviceConfig"]["certificate-update-profile"][i] && (JSON.stringify(inputObj["deviceConfig"]["certificate-update-profile"][i]["same-as-existing-key"]) === [null] || JSON.stringify(inputObj["deviceConfig"]["certificate-update-profile"][i]["same-as-existing-key"]) === "[null]")) {
          inputObj["deviceConfig"]["certificate-update-profile"][i]["same-as-existing-key"] = true;
        }
        else if(inputObj["deviceConfig"]["certificate-update-profile"][i] && inputObj["deviceConfig"]["certificate-update-profile"][i] && (inputObj["deviceConfig"]["certificate-update-profile"][i]["ecdsa"] === undefined && inputObj["deviceConfig"]["certificate-update-profile"][i]["dsa"] === undefined && inputObj["deviceConfig"]["certificate-update-profile"][i]["rsa"]) == undefined ) {
          inputObj["deviceConfig"]["certificate-update-profile"][i]["same-as-existing-key"] = false;
        }
      }
    }

    if(inputObj && inputObj["deviceConfig"] && inputObj["deviceConfig"]["ca-profile"]) {

      for(let i=0; i<inputObj["deviceConfig"]["ca-profile"].length; i++) {

        if(inputObj["deviceConfig"]["ca-profile"][i] && inputObj["deviceConfig"]["ca-profile"][i]["cmpv2"] && (JSON.stringify(inputObj["deviceConfig"]["ca-profile"][i]["cmpv2"]["response-signing-use-extracert"]) === [null] || JSON.stringify(inputObj["deviceConfig"]["ca-profile"][i]["cmpv2"]["response-signing-use-extracert"]) === "[null]")) {

          inputObj["deviceConfig"]["ca-profile"][i]["cmpv2"]["response-signing-use-extracert"] = true;
        }
        else {
          if(inputObj["deviceConfig"]["ca-profile"][i] && inputObj["deviceConfig"]["ca-profile"][i]["cmpv2"]) {
            if(inputObj["deviceConfig"]["ca-profile"][i] && inputObj["deviceConfig"]["ca-profile"][i]["cmpv2"]["response-signing-cert"] === undefined) {
              inputObj["deviceConfig"]["ca-profile"][i]["cmpv2"]["response-signing-use-extracert"] = false;
            }
          }
          else {
            inputObj["deviceConfig"]["ca-profile"][i]["cmpv2"] = {};
          }
        }
      }
    }
  }

  this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }

  this.expandIPv6 = function (obj) {
        for (var key in obj) {
            if (typeof obj[key] === 'object' && obj[key] !== null) {
                this.expandIPv6(obj[key]);
            } else if (typeof obj[key] === 'string' && this.matchExact(ipv6Regex, obj[key])) {
                obj[key] = this.expandIPv6AddressForMd(obj[key]);
        }
      }
      return obj
    }
    this.matchExact = function(r, str) {
       var match = str.match(r);
       return match && str === match[0];
    }

    this.expandIPv6AddressForMd = function (input) {
       var expanded = ipv6AddressUtil.expandIPv6Address(input);
       expanded = ipv6AddressUtil.MdIpv6ValidAddresssMaskSupport(expanded);
       return expanded;
    };

  this.preAudit = preAudit;
  this.postAudit = postAudit;
  this.preSync = preSync;
  this.postSync = postSync;
  this.postDiscovery = postDiscovery;

}
