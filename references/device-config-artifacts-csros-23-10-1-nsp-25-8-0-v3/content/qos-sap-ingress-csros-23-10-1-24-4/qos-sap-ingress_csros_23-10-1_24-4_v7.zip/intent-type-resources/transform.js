function transformData() {
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
        return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
    this.transformPayloadGreenField = function (payload, neId, isAudit) {
        let neFamily = util.getNeFamilyRelease(neId);
        let neType = util.getNeType(neFamily);
        if((!isAudit) && (payload["configInfo"] && payload["configInfo"]["aingr.Policy"] &&
                            payload["configInfo"]["aingr.Policy"]["children-Set"] &&
                            payload["configInfo"]["aingr.Policy"]["children-Set"]["aingr.DynamicPolicer"])){
            payload["configInfo"]["aingr.Policy"]["children-Set"]["aingr.DynamicPolicer"]["policyId"] = payload["configInfo"]["aingr.Policy"]["id"];
        }
        if (payload["objectFullName"].startsWith("Access Ingress")  && neType.startsWith("7705")) {
            if (payload["configInfo"] && payload["configInfo"]["aingr.Policy"] &&
                payload["configInfo"]["aingr.Policy"]["children-Set"] &&
                payload["configInfo"]["aingr.Policy"]["children-Set"]["aingr.Queue"]) {
                var queues = payload["configInfo"]["aingr.Policy"]["children-Set"]["aingr.Queue"];
                var exists = false;
                for (var index in queues) {
                    if (queues[index]["id"] === 11) {
                        exists = true;
                        break;
                    }
                }
                if (!exists) {
                    queues.push({ "id": 11 });
                }
            }
        }else if (!payload["objectFullName"].startsWith("Access Ingress") && neType.startsWith("7705")) {
             if (payload["configInfo"] && payload["configInfo"]["aingr.Policy"] &&
                 payload["configInfo"]["aingr.Policy"]["children-Set"] &&
                 payload["configInfo"]["aingr.Policy"]["children-Set"]["aingr.Queue"]) {

                 var queues = payload["configInfo"]["aingr.Policy"]["children-Set"]["aingr.Queue"];

                 for (var index in queues) {
                     var queue = queues[index];
                     if (queue["id"] === 11 && Object.keys(queue).length === 1) {
                         queues.splice(index, 1);
                         break;
                     }
                 }
             }
         }
        return payload;
    }
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        if(xpath == "aingr-Policer.advancedConfigPolicyPointer")
        {
            targetValue = 'advancedConfigPolicy:'+ targetValue;
        }
        if(xpath == "aingr-IpMatch.dstIpPrefixListPointer")
        {
            targetValue = 'qosPrefixList:' + targetValue + '#type-IPv4';
        }
        if(xpath == "aingr-IpMatch.srcIpPrefixListPointer")
        {
            targetValue = 'qosPrefixList:' + targetValue + '#type-IPv4';
        }
        if(xpath == "aingr-Ipv6Match.srcIpPrefixListPointer")
        {
            targetValue = 'qosPrefixList:' + targetValue + '#type-IPv6';
        }
        if(xpath == "aingr-Ipv6Match.dstIpPrefixListPointer")
        {
            targetValue = 'qosPrefixList:' + targetValue + '#type-IPv6';
        }
        if(xpath == "aingr-Queue.slopePolicyPointer")
        {
            if(targetValue)
            {
                targetValue = 'Slope:' + targetValue;
            }
            else
            {
                targetValue = 'Slope:default';
            }
        }
        if(xpath == "aingr-Queue.cirPercent" ||
            xpath == "aingr-Queue.pirPercent" ||
            xpath == "aingr-Queue.firPercent" ||
            xpath == "aingr-Policer.cirPercent" ||
            xpath == "aingr-Policer.pirPercent")
        {
            if(targetValue && !isNaN(targetValue) && !targetValue.contains("."))
            {
                targetValue = Number(targetValue);
                targetValue = targetValue.toFixed(1);
            }
        }
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey) {
        if(xpath == "aingr-Policer.advancedConfigPolicyPointer")
        {
            targetValue = targetValue.replace('advancedConfigPolicy:', '');
        }
        if(xpath == "aingr-IpMatch.dstIpPrefixListPointer")
        {
            targetValue = (targetValue.replace('qosPrefixList:', '')).replace("#type-IPv4", "");
        }
        if(xpath == "aingr-IpMatch.srcIpPrefixListPointer")
        {
            targetValue = (targetValue.replace('qosPrefixList:', '')).replace("#type-IPv4", "");
        }
        if(xpath == "aingr-Ipv6Match.srcIpPrefixListPointer")
        {
            targetValue = (targetValue.replace('qosPrefixList:', '')).replace("#type-IPv6", "");
        }
        if(xpath == "aingr-Ipv6Match.dstIpPrefixListPointer")
        {
            targetValue = (targetValue.replace('qosPrefixList:', '')).replace("#type-IPv6", "");
        }
        if(xpath == "aingr-Queue.slopePolicyPointer")
        {
            targetValue = (targetValue.replace('Slope:', ''))
        }
        return targetValue;
    }

    this.transformLocalObjectFullNameDistribute = function(localObjectFullName,
        intentConfig,
        payload,
        neId) {
        return localObjectFullName;
    }
}