/********************************************************************************
 * DEVICE-SPECIFIC INTENT-TYPE USED FOR NSP DEVICE CONFIGURATION (ICM)
 *   Vendor: Nokia
 *   Device families: 7750 SR, 7450 ESS, 7950 XRS, 7705 SAR, 7250 IXR
 *   Device version: 23.10.R1
 *
 * (c) 2025 by Nokia
 ********************************************************************************/

import { IntentHandlerBase }  from 'common/IntentHandlerBase.mjs';
import { NSP }  from 'common/NSP.mjs';

const HashMap = Java.type("java.util.HashMap");
class IntentHandler extends (IntentHandlerBase) {
  constructor() {
    super();
    this.greenFieldObjectFullName = "Subscriber Profile:$displayedName";
	this.greenFieldFDN = "Subscriber Profile";
	this.brownFieldObjectFullName = "network:$systemAddress:Subscriber Profile:$displayedName";
	this.isPolicyIntent = true;
	this.initialPropertyName = "subscrprofile-Policy";
	this.uniqueIdentifier = "displayedName";
    NSP.checkRelease(24, 11);
  }

  // WebUI suggest/picker callouts:
    suggestSubProfile(context) {
      logger.info("suggestSubProfile context = \n" + context);
      let className = "subscrprofile.Policy", neId = this.getNeId(context), attribute = "displayedName";
      let searchObject = {
        "fullClassName": className,
        "filter": {
          "and": {
            "equal": {
              "name": "siteId",
              "value": neId
            }
          }
        },
        "resultFilter": {
          "children": "",
          "attribute": [
            attribute
          ]
        }
      };
      return this.getData(neId, searchObject, className, attribute);
    }

    suggestIngressQosPolicy(context) {
		logger.info("suggestIngressQosPolicy context = \n" + context);
		let className = "aingr.Policy", neId = this.getNeId(context), attribute = "id";
		let searchObject = {
		  "fullClassName": className,
		  "filter": {
			"and": {
			  "equal": {
				"name": "siteId",
				"value": neId
			  }
			}
		  },
		  "resultFilter": {
			"children": "",
			"attribute": [
			  attribute
			]
		  }
		};
		return this.getData(neId, searchObject, className, attribute);
	  }

  suggestScheduler(context) {
	  logger.info("suggestScheduler context = \n" + context);
	  let className = "vs.Policy", neId = this.getNeId(context), attribute = "displayedName";
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": {
			  "name": "siteId",
			  "value": neId
			}
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}

    suggestIngSchedulerEntry(context) {
	  logger.info("suggestIngSchedulerEntry context = \n" + context);
	  let className = "vs.Entry", neId = this.getNeId(context), attribute = "displayedName";
	  let schedulerPolicy = context.getInputValues()["arguments"]["__parent"]["subscrprofile-Policy"]["ingressQosSchedObjPointer"];
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": [{
				  "name": "siteId",
				  "value": neId
				},
				{
				  "name": "containingPolicyDisplayedName",
				  "value": schedulerPolicy
				}
			]
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}

    suggestEgSchedulerEntry(context) {
	  logger.info("suggestEgSchedulerEntry context = \n" + context);
	  let className = "vs.Entry", neId = this.getNeId(context), attribute = "displayedName";
	  let schedulerPolicy = context.getInputValues()["arguments"]["__parent"]["subscrprofile-Policy"]["egressQosSchedObjPointer"];
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": [{
				  "name": "siteId",
				  "value": neId
				},
				{
				  "name": "containingPolicyDisplayedName",
				  "value": schedulerPolicy
				}
			]
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}
	suggestEgressQosPolicy(context) {
	logger.info("suggestEgressQosPolicy context = \n" + context);
	let className = "aengr.Policy", neId = this.getNeId(context), attribute = "id";
	let searchObject = {
	  "fullClassName": className,
	  "filter": {
		"and": {
		  "equal": {
			"name": "siteId",
			"value": neId
		  }
		}
	  },
	  "resultFilter": {
		"children": "",
		"attribute": [
		  attribute
		]
	  }
	};
	return this.getData(neId, searchObject, className, attribute);
  }
  suggestPolicerControlPolicy(context) {
	  logger.info("suggestPolicerControlPolicy context = \n" + context);
	  let className = "policing.PolicerControl", neId = this.getNeId(context), attribute = "displayedName";
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": {
			  "name": "siteId",
			  "value": neId
			}
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}

    suggestIngressPolicerControlPolicy(context) {
	  let ret = new HashMap();
	  logger.info("suggestIngressPolicerControlPolicy context = \n" + context);
	  let ingPolicerPolicyObjPointer = context.getInputValues()["arguments"]["__parent"]["subscrprofile-Policy"]["ingPolicerPolicyObjPointer"];
	  ret.set("1", ingPolicerPolicyObjPointer)
	  return ret;
	}

	suggestEgressPolicerControlPolicy(context) {
	  let ret = new HashMap();
	  logger.info("suggestEgressPolicerControlPolicy context = \n" + context);
	  let egrPolicerPolicyObjPointer = context.getInputValues()["arguments"]["__parent"]["subscrprofile-Policy"]["egrPolicerPolicyObjPointer"];
	  ret.set("1", egrPolicerPolicyObjPointer)
	  return ret;
	}
	suggestNatPolicy(context) {
	  logger.info("suggestNatPolicy context = \n" + context);
	  let className = "nat.NatPolicy", neId = this.getNeId(context), attribute = "displayedName";
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": {
			  "name": "siteId",
			  "value": neId
			}
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}
    suggestIgmpPolicy(context) {
	  logger.info("suggestIgmpPolicy context = \n" + context);
	  let className = "ressubscr.IgmpPolicy", neId = this.getNeId(context), attribute = "displayedName";
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": {
			  "name": "siteId",
			  "value": neId
			}
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}
	suggestMldPolicy(context) {
	  logger.info("suggestMldPolicy context = \n" + context);
	  let className = "ressubscr.MldPolicy", neId = this.getNeId(context), attribute = "displayedName";
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": {
			  "name": "siteId",
			  "value": neId
			}
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}
	suggestMCastCacPolicy(context) {
	  logger.info("suggestMCastCacPolicy context = \n" + context);
	  let className = "ressubscr.SubMcastCacPolicy", neId = this.getNeId(context), attribute = "displayedName";
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": {
			  "name": "siteId",
			  "value": neId
			}
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}
	suggestPimPolicy(context) {
	  logger.info("suggestPimPolicy context = \n" + context);
	  let className = "ressubscr.PimPolicy", neId = this.getNeId(context), attribute = "displayedName";
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": {
			  "name": "siteId",
			  "value": neId
			}
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}
	suggestUpnpPolicy(context) {
	  logger.info("suggestUpnpPolicy context = \n" + context);
	  let className = "nat.UpnpPolicy", neId = this.getNeId(context), attribute = "displayedName";
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": {
			  "name": "siteId",
			  "value": neId
			}
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}
	suggestNatPrefixPolicy(context) {
	  logger.info("suggestNatPrefixPolicy context = \n" + context);
	  let className = "nat.NatPrefixList", neId = this.getNeId(context), attribute = "displayedName";
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": {
			  "name": "siteId",
			  "value": neId
			}
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}
	suggestFirewallPolicy(context) {
	  logger.info("suggestFirewallPolicy context = \n" + context);
	  let className = "nat.FirewallPolicy", neId = this.getNeId(context), attribute = "displayedName";
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": {
			  "name": "siteId",
			  "value": neId
			}
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}
	suggestRadiusAccountingPolicy(context) {
	  logger.info("suggestRadiusAccountingPolicy context = \n" + context);
	  let className = "radiusaccounting.Policy", neId = this.getNeId(context), attribute = "displayedName";
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": {
			  "name": "siteId",
			  "value": neId
			}
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}
    suggestAccountingPolicy(context) {
	  logger.info("suggestAccountingPolicy context = \n" + context);
	  let className = "accounting.Policy", neId = this.getNeId(context), attribute = "id";
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": {
			  "name": "siteId",
			  "value": neId
			}
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}
	suggestAncpPolicy(context) {
	  logger.info("suggestAncpPolicy context = \n" + context);
	  let className = "ancp.Policy", neId = this.getNeId(context), attribute = "displayedName";
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": {
			  "name": "siteId",
			  "value": neId
			}
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}
    suggestHostTrackingPolicy(context) {
	  logger.info("suggestHostTrackingPolicy context = \n" + context);
	  let className = "ressubscr.HostTrackingPolicy", neId = this.getNeId(context), attribute = "displayedName";
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": {
			  "name": "siteId",
			  "value": neId
			}
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}
	suggestWrrPolicy(context) {
	  logger.info("suggestWrrPolicy context = \n" + context);
	  let className = "portscheduler.HsmdaWrrPolicy", neId = this.getNeId(context), attribute = "displayedName";
	  let searchObject = {
		"fullClassName": className,
		"filter": {
		  "and": {
			"equal": {
			  "name": "siteId",
			  "value": neId
			}
		  }
		},
		"resultFilter": {
		  "children": "",
		  "attribute": [
			attribute
		  ]
		}
	  };
	  return this.getData(neId, searchObject, className, attribute);
	}

    transformPayloadGreenField(payload, neId, isAudit) {
		if (!isAudit) {
		  if (!payload["configInfo"]["subscrprofile.Policy"]["subMcastCacPolicyObjPointer"]) {
			payload["configInfo"]["subscrprofile.Policy"]["subMcastCacPolicyObjPointer"] = '';
		  }
		  if (!payload["configInfo"]["subscrprofile.Policy"]["natPolicyObjPointer"]) {
			payload["configInfo"]["subscrprofile.Policy"]["natPolicyObjPointer"] = '';
		  }
		  if (!payload["configInfo"]["subscrprofile.Policy"]["mldPolicyObjPointer"]) {
			payload["configInfo"]["subscrprofile.Policy"]["mldPolicyObjPointer"] = '';
		  }
		  if (!payload["configInfo"]["subscrprofile.Policy"]["egressQosSchedObjPointer"]) {
			payload["configInfo"]["subscrprofile.Policy"]["egressQosSchedObjPointer"] = '';
		  }
		  if (!payload["configInfo"]["subscrprofile.Policy"]["firewallPolicyPointer"]) {
			payload["configInfo"]["subscrprofile.Policy"]["firewallPolicyPointer"] = '';
		  }
		  if (!payload["configInfo"]["subscrprofile.Policy"]["accountingPolicyObjectPointer"]) {
			payload["configInfo"]["subscrprofile.Policy"]["accountingPolicyObjectPointer"] = '';
		  }
		  if (!payload["configInfo"]["subscrprofile.Policy"]["ancpPolicy"]) {
			payload["configInfo"]["subscrprofile.Policy"]["ancpPolicy"] = '';
		  }
		  if (!payload["configInfo"]["subscrprofile.Policy"]["egrPolicerPolicyObjPointer"]) {
			payload["configInfo"]["subscrprofile.Policy"]["egrPolicerPolicyObjPointer"] = '';
		  }
		  if (!payload["configInfo"]["subscrprofile.Policy"]["upnpPolicyPointer"]) {
			payload["configInfo"]["subscrprofile.Policy"]["upnpPolicyPointer"] = '';
		  }
		  if (!payload["configInfo"]["subscrprofile.Policy"]["natPrefixListPointer"]) {
			payload["configInfo"]["subscrprofile.Policy"]["natPrefixListPointer"] = '';
		  }
		  if (!payload["configInfo"]["subscrprofile.Policy"]["igmpPolicyObjPointer"]){
			payload["configInfo"]["subscrprofile.Policy"]["igmpPolicyObjPointer"] = '';
		  }
		  if (!payload["configInfo"]["subscrprofile.Policy"]["thirdRadiusAccountingPolicyObjectPointer"]){
			payload["configInfo"]["subscrprofile.Policy"]["thirdRadiusAccountingPolicyObjectPointer"] = '';
		  }
	      if (!payload["configInfo"]["subscrprofile.Policy"]["ingPolicerPolicyObjPointer"]) {
			payload["configInfo"]["subscrprofile.Policy"]["ingPolicerPolicyObjPointer"] = '';
		  }
		  if (!payload["configInfo"]["subscrprofile.Policy"]["pimPolicyObjPointer"]) {
			payload["configInfo"]["subscrprofile.Policy"]["pimPolicyObjPointer"] = '';
		  }
		  if (!payload["configInfo"]["subscrprofile.Policy"]["radiusAccountingPolicyObjectPointer"]) {
			payload["configInfo"]["subscrprofile.Policy"]["radiusAccountingPolicyObjectPointer"] = '';
		  }
		  if (!payload["configInfo"]["subscrprofile.Policy"]["ingressQosSchedObjPointer"]) {
			payload["configInfo"]["subscrprofile.Policy"]["ingressQosSchedObjPointer"] = '';
		  }
		  if (!payload["configInfo"]["subscrprofile.Policy"]["hostTrackingPolicyPointer"]) {
			payload["configInfo"]["subscrprofile.Policy"]["hostTrackingPolicyPointer"] = '';
		  }
		  if (!payload["configInfo"]["subscrprofile.Policy"]["duplicateRadiusAccountingPolicyObjectPointer"]) {
			payload["configInfo"]["subscrprofile.Policy"]["duplicateRadiusAccountingPolicyObjectPointer"] = '';
		  }
		}

		return payload;
	  }
    transformTargetValueGreenField(xpath, targetValue, targetKey, neId, isAudit) {
        if (xpath == "subMcastCacPolicyObjPointer") {
          targetValue = 'subMcastCacPolicy:' + targetValue;
        }
        if (xpath == "natPolicyObjPointer") {
          targetValue = 'natPolicy:nat-' + targetValue;
        }
        if (xpath == "mldPolicyObjPointer") {
          targetValue = 'mldPolicy:' + targetValue;
        }
        if (xpath == "ingressQosSchedObjPointer" ||
			xpath == "egressQosSchedObjPointer") {
          targetValue = 'Scheduler:' + targetValue;
        }
        if (xpath == "radiusAccountingPolicyObjectPointer" ||
            xpath == "duplicateRadiusAccountingPolicyObjectPointer" ||
            xpath == "thirdRadiusAccountingPolicyObjectPointer") {
          targetValue = 'RADIUS Based Accounting:' + targetValue;
        }
        if (xpath == "firewallPolicyPointer") {
          targetValue = 'firewallPolicy:' + targetValue;
        }
        if (xpath == "accountingPolicyObjectPointer") {
          targetValue = 'Slope:' + targetValue;
        }
        if (xpath == "egressQosPolicyObjPointer") {
          targetValue = 'Access Egress:' + targetValue;
        }
		if (xpath == "ingressQosPolicyObjPointer") {
		  targetValue = 'Access Ingress:' + targetValue;
		}
        if (xpath == "ancpPolicy") {
          targetValue = 'ANCP Policy:' + targetValue;
        }
        if (xpath == "ingPolicerPolicyObjPointer" ||
        	xpath == "egrPolicerPolicyObjPointer"){
          targetValue = 'hPolicing:' + targetValue;
        }
        if (xpath == "upnpPolicyPointer") {
          targetValue = 'upnpPolicy:' + targetValue;
        }
        if (xpath == "natPrefixListPointer") {
          targetValue = 'natPrefixList:' + targetValue;
        }
        if (xpath == "igmpPolicyObjPointer") {
          targetValue = 'igmpPolicy:' + targetValue;
        }
        if (xpath == "pimPolicyObjPointer") {
          targetValue = 'pimPolicy:' + targetValue;
        }
        if (xpath == "hostTrackingPolicyPointer") {
          targetValue = 'hostTrackingPolicy:' + targetValue;
        }
        if (xpath == "hsmdaEgrQosWrrPlcyOvrd") {
          targetValue = 'HsmdaWrrPolicy:' + targetValue;
        }

        return targetValue;
      }

      transformTargetValueBrownField(xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
        if (xpath == "subMcastCacPolicyObjPointer") {
          targetValue = targetValue.replace('subMcastCacPolicy:', '');
        }
        if (xpath == "natPolicyObjPointer") {
          targetValue = targetValue.replace('natPolicy:nat-', '');
        }
        if (xpath == "mldPolicyObjPointer") {
          targetValue = targetValue.replace('mldPolicy:', '');
        }
        if (xpath == "ingressQosSchedObjPointer" ||
            xpath == "egressQosSchedObjPointer") {
          targetValue = targetValue.replace('Scheduler:', '');
        }
        if (xpath == "radiusAccountingPolicyObjectPointer" ||
            xpath == "duplicateRadiusAccountingPolicyObjectPointer" ||
            xpath == "thirdRadiusAccountingPolicyObjectPointer") {
          targetValue = targetValue.replace('RADIUS Based Accounting:', '');
        }
        if (xpath == "firewallPolicyPointer") {
          targetValue = targetValue.replace('firewallPolicy:', '');
        }
        if (xpath == "accountingPolicyObjectPointer") {
          targetValue = targetValue.replace('Slope:', '');
        }
        if (xpath == "egressQosPolicyObjPointer") {
          targetValue = targetValue.replace('Access Egress:', '');
        }
        if (xpath == "ingressQosPolicyObjPointer") {
          targetValue = targetValue.replace('Access Ingress:', '');
        }
        if (xpath == "ancpPolicy") {
          targetValue = targetValue.replace('ANCP Policy:', '');
        }
        if (xpath == "ingPolicerPolicyObjPointer" ||
            xpath == "egrPolicerPolicyObjPointer"){
          targetValue = targetValue.replace('hPolicing:', '');
        }
        if (xpath == "upnpPolicyPointer") {
          targetValue = targetValue.replace('upnpPolicy:', '');
        }
        if (xpath == "natPrefixListPointer") {
          targetValue = targetValue.replace('natPrefixList:', '');
        }
        if (xpath == "igmpPolicyObjPointer") {
          targetValue = targetValue.replace('igmpPolicy:', '');
        }
        if (xpath == "pimPolicyObjPointer") {
          targetValue = targetValue.replace('pimPolicy:', '');
        }
        if (xpath == "hostTrackingPolicyPointer") {
          targetValue = targetValue.replace('hostTrackingPolicy:', '');
        }
        if (xpath == "hsmdaEgrQosWrrPlcyOvrd") {
          targetValue = targetValue.replace('HsmdaWrrPolicy:', '');
        }
        return targetValue;
      }

}

new IntentHandler();