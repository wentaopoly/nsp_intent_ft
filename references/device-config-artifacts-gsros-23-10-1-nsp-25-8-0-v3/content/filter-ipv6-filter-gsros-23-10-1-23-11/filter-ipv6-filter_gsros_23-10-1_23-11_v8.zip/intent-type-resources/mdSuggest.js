function MdSuggest() {
    this.getFilterName = function (neId, filterId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/filter/ipv6-filter?fields=filter-id";
        return this.getData(neId, url, "filter-name", filterId);
    }

    this.getFilterId = function (neId, filterName) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/filter/ipv6-filter?fields=filter-id";
        if (filterName) {
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/filter/ipv6-filter=" + filterName + "?fields=filter-id";
        }
        return this.getData(neId, url, "filter-id");
    }

    this.getOfSwitch = function(neId) {
      var url =  "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/openflow/of-switch";
      return this.getSuggestData(neId, url, "nokia-conf:of-switch", "name");
    }

    /*this.getEmbedFilter = function(neId) {
      var url =  "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/filter/ipv6-filter";
      return this.getSuggestData(neId, url, "nokia-conf:ipv6-filter", "filter-name");
    }*/

    this.getEmbedFilter = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/filter/ipv6-filter";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:ipv6-filter'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse) ? finalResponse.filter(data =>data['scope'] === 'embedded').map(data => data['filter-name']).filter(value => value != null) : [];
      logger.info("ret = " + JSON.stringify(ret));
      return ret;
   }

    this.getData = function (neId, url, type, filterId) {
        var mdcFwk = new MdcFwk();
        logger.info(LOG_PREFIX + "MdSuggest IPv6 Filter --getData---neId={}, url={}, type={}", neId, url, type);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info(LOG_PREFIX + "MDC resultFetch IPv6 Filter =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"]["nokia-conf:ipv6-filter"];
        logger.info(LOG_PREFIX + "finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                if (filterId) {
                    logger.info(LOG_PREFIX + "FilterId Selected = {}", filterId);
                    logger.info(LOG_PREFIX + "Device Filter ID = {}", finalResponse[index]["filter-id"]);
                    if (finalResponse[index]["filter-id"] == filterId) {
                        ret.push(finalResponse[index][type]);
                        break
                    }
                }
                else {
                    ret.push(finalResponse[index][type]);
                }
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "ret = \n" + JSON.stringify(ret));
        return ret;
    }
    this.getFilterLog = function (neId) {
        var url =  "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-state:/state/filter/log";
        return this.getSuggestData(neId, url, "nokia-state:log","log-id");
    }

    this.getSampleProfile = function (neId) {
        var url =  "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/cflowd/sample-profile";
        return this.getSuggestData(neId, url, "nokia-conf:sample-profile","profile-id");
    }

    this.getPrefixList = function (neId) {
        var url =  "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/filter/match-list/ipv6-prefix-list";
        return this.getSuggestData(neId, url, "nokia-conf:ipv6-prefix-list", "prefix-list-name");
    }

    this.getPortList = function (neId) {
        var url =  "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/filter/match-list/port-list";
        return this.getSuggestData(neId, url, "nokia-conf:port-list", "port-list-name");
    }

    this.getGreTunnel = function (neId) {
        var url =  "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/filter/gre-tunnel-template";
        return this.getSuggestData(neId, url, "nokia-conf:gre-tunnel-template", "gre-tunnel-template-name");
    }

    this.getRoutingInstances = function (neId) {
        var url =  "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/service/vprn";
        var routingInstances = this.getSuggestData(neId, url, "nokia-conf:vprn", "service-name");
        routingInstances.push("Base");
        return routingInstances;
    }

    this.getVPRNServices = function (neId) {
        var url =  "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/service/vprn";
        return this.getSuggestData(neId, url, "nokia-conf:vprn", "service-name");
    }

    this.getVPLSServices = function (neId) {
        var url =  "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/service/vpls";
        return this.getSuggestData(neId, url, "nokia-conf:vpls", "service-name");
    }

    this.getLSPs = function (neId) {
        var url =  "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base/mpls/lsp";
        return this.getSuggestData(neId, url, "nokia-conf:lsp", "lsp-name");
    }

    this.getSuggestData = function (neId, url, initialProperty, propertyName) {
        var mdcFwk = new MdcFwk();
        logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, propertyName);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info("MDC resultFetch =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"][initialProperty];
        logger.info("finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse))
        {
            for (var index in finalResponse)
            {
                logger.info("Device "+propertyName+" Data = {}", finalResponse[index][propertyName]);
                ret.push(finalResponse[index][propertyName]);
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info("ret = \n" + JSON.stringify(ret));
        return ret;
    }
}
