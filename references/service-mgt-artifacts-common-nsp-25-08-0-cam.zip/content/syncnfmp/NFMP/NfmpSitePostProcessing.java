package com.nokia.nsp.mdt.intents.ibsf.resync.nfmp;

import com.nokia.nsp.md.common.IExecutionContext;
import com.nokia.nsp.md.common.IYangObject;
import com.nokia.nsp.md.common.YangObject;
import com.nokia.nsp.md.db.yang.api.ExecutionContext;
import com.nokia.nsp.md.db.yang.api.QueryParameters;
import com.nokia.nsp.md.db.yang.util.XPathUtil;
import com.nokia.nsp.md.ifg.yang.api.Fields;
import com.nokia.nsp.md.resync.api.IMdResyncFw;
import com.nokia.nsp.md.resync.api.IResyncClassHandler;
import com.nokia.nsp.md.resync.api.NotificationType;
import com.nokia.nspos.persistence.impl.db.transaction.Transactor;
import com.nokia.nspos.persistence.impl.db.transaction.TxPhase;
import com.nokia.nspos.persistence.yang.api.IYangDB;

import java.util.HashMap;
import java.util.Map;


public class NfmpSitePostProcessing implements IResyncClassHandler {
    private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(NfmpSitePostProcessing.class.getName() + ".postProcessObject");
    static ThreadLocal<Map<String, String>> neNameCache = new ThreadLocal<>();
    IMdResyncFw iMdResyncFw;
    IYangDB yangDB;

    @Override
    public void postProcessObject(Map<String, Object> aInData, IYangObject aInIYangObject, String aInNeId, NotificationType aInNotificationType, IMdResyncFw aInMdResyncFw) {
        if(!aInNotificationType.equals(NotificationType.CREATE)){
            return;
        }
        iMdResyncFw = aInMdResyncFw;
        yangDB = iMdResyncFw.getIYangDB();
        if (logger.isDebugEnabled()) {
            logger.debug("Starting post-processing site object (" + aInNotificationType + "): " + aInIYangObject.getIdentifier());
        }


        YangObject lNewYang = new YangObject();
        boolean lUpdateDbSource = false;

        QueryParameters lQueryParamsCreateDelete = new QueryParameters();
        IExecutionContext lExecutionContext = new ExecutionContext(null, null, false, false, false);
        lQueryParamsCreateDelete.setIExecutionContext(lExecutionContext);

        QueryParameters lQpNeName = new QueryParameters();
        lQpNeName.setIExecutionContext(lExecutionContext);
        lQpNeName.setFields(Fields.parse("ne-name"));
        lQpNeName.setDepth(2);
        String lNeName = getNeNameByIdFromCache(aInNeId, lQpNeName, yangDB);

        if (lNeName != null) {
            lNewYang.setProperty("ne-name", lNeName);
        }


        if (!lNewYang.getProperties().isEmpty() || lUpdateDbSource == true) {
            updateInDb(lNewYang, aInIYangObject, false);
        }
    }


    private void updateInDb(IYangObject aInYangObject, IYangObject existingObject, boolean aInDelete) {
        final QueryParameters qp = new QueryParameters();
        qp.setSuperUser(true);

        IExecutionContext lExecutionContext = new ExecutionContext(null, null, false, false, false);
        qp.setIExecutionContext(lExecutionContext);

        String lCurrentXpath = XPathUtil.getText(XPathUtil.parse(existingObject.getIdentifier()));
        qp.getIExecutionContext().addIYangObject(lCurrentXpath, existingObject);

        if (aInDelete) {
            yangDB.delete(existingObject.getIdentifier(), qp);
        } else {
            yangDB.update(existingObject.getIdentifier(), aInYangObject, qp);
        }
    }


    private String getNeNameByIdFromCache(String aInNeId, QueryParameters aInQueryParameters, IYangDB aInYangDb) {
        Map<String, String> lNeNameCache = neNameCache.get();
        if (null == lNeNameCache) {
            lNeNameCache = new HashMap<>();
            neNameCache.set(lNeNameCache);
            Transactor.getContext().addEventHandler(TxPhase.FINAL, (p, c) -> {
                neNameCache.remove();
            });
        }

        String lFoundNeName = lNeNameCache.get(aInNeId);
        if (null == lFoundNeName) {
            if (logger.isDebugEnabled()) {
                logger.debug("Querying db for ne-name for ne {}", aInNeId);
            }
            String lportFdn = "/nsp-equipment:network/network-element[ne-id='" + aInNeId + "']";
            IYangObject lNeYangObj = aInYangDb.getSingle(lportFdn, aInQueryParameters);
            if (lNeYangObj != null && lNeYangObj.hasProperty("ne-name")) {
                lFoundNeName = (String) lNeYangObj.getProperty("ne-name");
            } else {
                lFoundNeName = "";
            }
            lNeNameCache.put(aInNeId, lFoundNeName);
        } else {
            if (logger.isDebugEnabled()) {
                logger.debug("Found ne-name for ne {} in cache", aInNeId);
            }
        }
        return lFoundNeName;
    }
}