var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});

var network_policy_name = "policyName";
var network_policy_id = "id";
var full_class_name = "niegr.Policy";
var policy_fdn = "Network";

function NfmpNetworkFwk() {
  
    var util = new utilities();
    var mapFwk = new MapFwk();
    var parseTarget =  new ParseTarget();
    let nfmpFwk = new NfmpFwk();
    var savedObjects;
    var currentObjects;
    var isAudit = false;
    var isLocalExists = false;
    var isGlobalExists = false;
    var isEdit = false;
    var intentDeviationObj = new IntentDeviceDeviation();
  
    this.synchronize = function(input, result, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {

        // code to handle delete
         if (input.getNetworkState().name() == "delete") {
            logger.info(LOG_PREFIX + "Calling syncDelete");
            return this.syncDelete(input, result);
        }

        var savedTopology = input.getCurrentTopology();
        logger.info(LOG_PREFIX + "Saved Topology = "+savedTopology);
        savedObjects = {};
        currentObjects = {};
        //loading the saved objects from topology
        this.loadSavedObjectsFromTopology(savedTopology);
        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        var neFamily = intentDeviationObj.getNeFamilyRelease(target);
        logger.info(LOG_PREFIX + "neFamily: " + neFamily);
        var policyId = util.getQosNetworkPolicyId(input.getTarget());
        var policyName = util.getQosNetworkPolicyName(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        if (!neFamily.startsWith("7705")) {
            intentConfig["policyName"] = policyName;
        }
        intentConfig["id"] = parseInt(policyId);
        logger.info(LOG_PREFIX + "Configuration to be pushed = "+JSON.stringify(intentConfig));
        logger.info(LOG_PREFIX + "Target device = " + target);
        logger.info(LOG_PREFIX + "Target Qos Network = " + policyName);
        this.createOrModify(target, intentConfig);
        var currentTopo = this.loadCurrentObjectsToTopology(target);
        // code to handle sync
        return util.setSuccessResult(result, currentTopo);
    }
    
    this.createOrModify = function (target, intentConfig) {
        var fullClassName = "niegr.Policy";
        var policyFdn = "Network";
        var objectFullName = policyFdn + ":" + intentConfig["id"];
        var localPolicyFullName = "network:" + target + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, target);
        var localPolicy = util.getIfObjectExists("niegr.Policy", localPolicyFullName);
        logger.info(LOG_PREFIX + "Searching if any local policy exists on NE: " + target);
        logger.info(LOG_PREFIX + "localPolicy: " + JSON.stringify(localPolicy));
        var result;
        var qosNetworkPayload;
        var distributeResult;

        if (localPolicy != null) {
            isLocalExists = true;
            isGlobalExists = true;
            if(localPolicy[0]["policyName"] !== intentConfig["policyName"] && localPolicy[0]["policyName"] !== "N/A") {
                throw new RuntimeException("Already there exists a policy on " + target +
                    " with policy name " + localPolicy[0]["policyName"]+
                    " with policy ID " + intentConfig["id"]);
            }
            qosNetworkPayload = this.createQosNetworkPolicyPayload(target, intentConfig, isLocalExists, null);
            result = this.modifyRequest(target, qosNetworkPayload);
            if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                throw new RuntimeException('Unable to Create/Distribute Policy: ' + intentConfig[network_policy_name] +
                    ", Kindly check the intent configuration");
            }
        }
        else {
            logger.info(LOG_PREFIX + "Unable to find the local policy, Trying to fetch global policy if available");
            var globalPolicy = util.getIfObjectExists(fullClassName, objectFullName);
            if (globalPolicy != null) {
                isGlobalExists = true;
                if (globalPolicy[0]["policyName"] !== intentConfig[network_policy_name]) {
                    logger.info(LOG_PREFIX + "createOrModify(): There exists a Network QoS global policy in NFMP with policy name " +
                        globalPolicy[0]["policyName"] + " with same policy ID " + intentConfig[network_policy_id] + " on " + target);
                    logger.info(LOG_PREFIX + "createOrModify(): Updating Network QoS global policy name to " +
                        intentConfig[network_policy_name] + "on " + target + " for policy ID: " + intentConfig[network_policy_id]);
                    this.updateNetworkQosPolicyName(target, objectFullName, intentConfig[network_policy_name]);
                }
                logger.info(LOG_PREFIX + "Distributing the existing global policy: " + objectFullName);
                distributeResult = this.distributePolicy(target, objectFullName, false);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributeResult = this.distributePolicy(target, objectFullName, true);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                logger.info(LOG_PREFIX + "checking distribution of existing global policy");
                if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                    throw new RuntimeException("Unable to Distribute existing Global Policy: " + intentConfig[network_policy_name] +
                        ", Kindly check the Global Policy configuration");
                }
                logger.info(LOG_PREFIX + "distribution of existing global policy was successful, updating with intent configuration");
                qosNetworkPayload = this.createQosNetworkPolicyPayload(target, intentConfig, true, null);
                result = this.modifyRequest(target, qosNetworkPayload);
                if (!util.isObjectExists(fullClassName, localPolicyFullName)) {
                    throw new RuntimeException('Unable to Create/Distribute Policy: ' + intentConfig[network_policy_name] +
                        ", Kindly check the intent configuration");
                }
            }
            else {
                //distributing empty policy
                logger.info(LOG_PREFIX + "Unable to find the Global Policy, distributing empty policy and updating");
                qosNetworkPayload = this.createQosNetworkPolicyPayload(target, intentConfig, false, null);
                result = this.modifyRequest(target, qosNetworkPayload);
                distributeResult = this.distributePolicy(target, objectFullName, false);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                util.delay(2000);
                // Changing SyncWithGlobal To Local Edit Only
                distributeResult = this.distributePolicy(target, objectFullName, true);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Policy: ' + distributeResult.msg)
                }
                //updating the local policy with intent configuration
                qosNetworkPayload = this.createQosNetworkPolicyPayload(target, intentConfig, true, null);
                result = this.modifyRequest(target, qosNetworkPayload);
            }
        }
        return result;
    }

    this.updateNetworkQosPolicyName = function (neId, objectFullName, policyName) {
        var payload = {};
        var configInfo = {};
        var properties = {};
        properties["policyName"] = policyName;

        configInfo[full_class_name] = properties;
        payload["distinguishedName"] = policy_fdn;
        payload["objectFullName"] = objectFullName;
        payload["clearOnDeployFailure"] = true;
        payload["configInfo"] = configInfo;
        logger.info(LOG_PREFIX + "Payload for updating Global Policy name : " + JSON.stringify(payload));
        return this.modifyRequest(neId, payload);
    }
    
    this.createQosNetworkPolicyPayload = function (target, intentConfig, isLocalExists, policyObject) {
        var fullClassName = full_class_name;
        var policyFdn = policy_fdn;
        var objectFullName = policyFdn + ":" + intentConfig["id"];
        var localPolicyFullName = "network:" + target + ":" + objectFullName;
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, target);
        if (isAudit || isLocalExists) {
            objectFullName = localPolicyFullName;
        }

        var properties = {};
        properties["id"] = intentConfig["id"];
        if (!isAudit) {
            properties["policyName"] = intentConfig[network_policy_name];
        }
        if (intentConfig["description"]) {
            properties["description"] = intentConfig["description"];
        }
        if (intentConfig["scope"]) {
            properties["scope"] = intentConfig["scope"];
        }
        var childProperties = {};
        if ("network-policy-type" in intentConfig) {
            if (intentConfig["network-policy-type"] === "ip-interface") {
                properties["networkPolicyType"] = "ipInterface";
            }
            else {
                properties["networkPolicyType"] = intentConfig["network-policy-type"];
            }
        }

        if (isLocalExists) {
            if (intentConfig) {
                this.createIngressPayload(target, intentConfig, properties, childProperties);
                this.createEgressPayload(target, intentConfig, properties, childProperties);
            }
            if (intentConfig["ring"]) {
                this.createRingPayload(target, intentConfig["ring"], properties, childProperties);
            }
        }

        return util.editPayload(policyFdn, properties, childProperties, fullClassName, objectFullName);
    }

    this.createRingPayload = function (target, ringConfig, properties, childProperties) {
        if ("default-action" in ringConfig) {
            var defAction = ringConfig["default-action"];
            if (defAction["profile"]) {
                properties["defaultProfile"] = defAction["profile"];
            }
            if (defAction["queue"]) {
                properties["defaultQueue"] = defAction["queue"];
            }
        }
        if ("dot1p" in ringConfig) {
            this.setRingDot1pConfig(ringConfig, childProperties);
        }
        else {
            childProperties["niegr.RingDot1p"] = [];
        }
    }

    this.setRingDot1pConfig = function (ringConfig, childProperties) {
        var ringDot1pArray = [];
        var ringDot1pClassName = "niegr.RingDot1p";
        if (!Array.isArray(ringConfig["dot1p"])) {
            ringConfig["dot1p"] = [ringConfig["dot1p"]];
        }
        for (var idx in ringConfig["dot1p"]) {
            var ringDot1pConfig = ringConfig["dot1p"][idx];
            var ringDot1pPayload = this.createRingDot1pPayload(ringDot1pConfig);
            ringDot1pArray.push(ringDot1pPayload)
        }
        childProperties[ringDot1pClassName] = ringDot1pArray;
    }

    this.createRingDot1pPayload = function (ringDot1pConfig) {
        var properties = {};
        for (var dot1pData in ringDot1pConfig) {
            switch (dot1pData) {
                case "dot1p-priority":
                    properties["ringdot1p"] = "value_" + ringDot1pConfig[dot1pData];
                    break;
                case "profile":
                    properties["ringprofile"] = ringDot1pConfig[dot1pData];
                    break;
                case "queue":
                    properties["queueId"] = ringDot1pConfig[dot1pData];
                    break;
            }
        }
        return properties;
    }

    this.createIngressPayload = function (target, intentConfig, properties, childProperties) {
        //LER use DSCP
        if ("ler-use-dscp" in intentConfig["ingress"]) {
            properties["lerUseDscp"] = Boolean(intentConfig["ingress"]["ler-use-dscp"]);
        }
        //Default Action
        if ("default-action" in intentConfig["ingress"]) {
            var defActionObj = intentConfig["ingress"]["default-action"];
            if (defActionObj["fc"]) {
                properties["defaultFc"] = defActionObj["fc"];
            }
            if (defActionObj["profile"]) {
                properties["defaultProfile"] = defActionObj["profile"];
            }
        }
        //DSCP
        if (intentConfig["ingress"] && intentConfig["ingress"]["dscp"]) {
            this.setDscpConfig(target, intentConfig, childProperties);
        }
        else {
            childProperties["niegr.Dscp"] = [];
        }
        //DOT1P
        if (intentConfig["ingress"] && intentConfig["ingress"]["dot1p"]) {
            this.setDot1pConfig(target, intentConfig, childProperties);
        }
        else {
            childProperties["niegr.Dot1p"] = [];
        }
        //LSP-EXP
        if (intentConfig["ingress"] && intentConfig["ingress"]["lsp-exp"]) {
            this.setLspExpConfig(target, intentConfig, childProperties);
        }
        else {
            childProperties["niegr.LspExp"] = [];
        }
        //FC
        if (intentConfig["ingress"] && intentConfig["ingress"]["fc"]) {
            this.setFcConfig(target, intentConfig, childProperties);
        }
        else {
            childProperties["niegr.IngressForwardingClass"] = [];
        }
        //IP-CRITERIA
        if (intentConfig["ingress"] && intentConfig["ingress"]["ip-criteria"]) {
            this.setIpCriteria(target, intentConfig, childProperties);
        }
        else {
           childProperties["niegr.IpMatch"] = [];
        }
        //IPv6-CRITERIA
        if (intentConfig["ingress"] && intentConfig["ingress"]["ipv6-criteria"]) {
            this.setIpV6Criteria(target, intentConfig, childProperties);
        }
        else {
            childProperties["niegr.Ipv6Match"] = [];
        }
    }

    this.createEgressPayload = function (target, intentConfig, properties, childProperties) {
        if (!isEdit) {
            properties["egressRemark"] = false;
            properties["forceRemark"] = false;
        }
        //Remark Trusted
        if ("remark-trusted" in intentConfig["egress"]) {
            properties["egressRemark"] = true;
            properties["forceRemark"] = Boolean(intentConfig["egress"]["remark-trusted"]["force-egress-marking"]);
        }
        //DSCP
        if (intentConfig["egress"] && intentConfig["egress"]["dscp"]) {
            this.setEgressDscpConfig(target, intentConfig, childProperties);
        }
        else {
            childProperties["niegr.DscpEgress"] = [];
        }
        //PREC
        if (intentConfig["egress"] && intentConfig["egress"]["prec"]) {
            this.setEgressPrecConfig(target, intentConfig, childProperties);
        }
        else {
            childProperties["niegr.Precedence"] = [];
        }
        //FC
        if (intentConfig["egress"] && intentConfig["egress"]["fc"]) {
            this.setEgressFcConfig(target, intentConfig, childProperties);
        }
        else {
            childProperties["niegr.ForwardingClass"] = [];
        }
        //IP-CRITERIA
        if (intentConfig["egress"] && intentConfig["egress"]["ip-criteria"]) {
            this.setEgressIpConfig(target, intentConfig, childProperties);
        }
        else {
            childProperties["niegr.EgressIpMatch"] = [];
        }
        //IPv6-CRITERIA
        if (intentConfig["egress"] && intentConfig["egress"]["ipv6-criteria"]) {
            this.setEgressIpV6Config(target, intentConfig, childProperties);
        }
        else {
            childProperties["niegr.EgressIpv6Match"] = [];
        }
    }

    this.setEgressIpV6Config = function (target, intentConfig, childProperties) {
        var egressIpV6CriteriaArray = [];
        var egressIpV6CriteriaClassName = "niegr.EgressIpv6Match";
        if (!Array.isArray(intentConfig["egress"]["ipv6-criteria"]["entry"])) {
            intentConfig["egress"]["ipv6-criteria"]["entry"] = [intentConfig["egress"]["ipv6-criteria"]["entry"]];
        }
        for (var ipv6Idx in intentConfig["egress"]["ipv6-criteria"]["entry"]) {
            var egressIpV6CriteriaConfig = intentConfig["egress"]["ipv6-criteria"]["entry"][ipv6Idx];
            var egressIpV6CriteriaPayload = this.createEgressIpV6CriteriaPayload(target, egressIpV6CriteriaConfig);
            egressIpV6CriteriaArray.push(egressIpV6CriteriaPayload);
        }
        childProperties[egressIpV6CriteriaClassName] = egressIpV6CriteriaArray;
    }

    this.setEgressIpConfig = function (target, intentConfig, childProperties) {
        var egressIpCriteriaArray = [];
        var egressIpCriteriaClassName = "niegr.EgressIpMatch";
        if (!Array.isArray(intentConfig["egress"]["ip-criteria"]["entry"])) {
            intentConfig["egress"]["ip-criteria"]["entry"] = [intentConfig["egress"]["ip-criteria"]["entry"]];
        }
        for (var ipcIdx in intentConfig["egress"]["ip-criteria"]["entry"]) {
            var egressIpCriteriaConfig = intentConfig["egress"]["ip-criteria"]["entry"][ipcIdx];
            var egressIpCriteriaPayload = this.createEgressIpCriteriaPayload(target, egressIpCriteriaConfig);
            egressIpCriteriaArray.push(egressIpCriteriaPayload);
        }
        childProperties[egressIpCriteriaClassName] = egressIpCriteriaArray;
    }

    this.setEgressPrecConfig = function (target, intentConfig, childProperties) {
        var egressPrecArray = [];
        var egressPrecClassName = "niegr.Precedence";
        if (!Array.isArray(intentConfig["egress"]["prec"])) {
            intentConfig["egress"]["prec"] = [intentConfig["egress"]["prec"]];
        }
        for (var index in intentConfig["egress"]["prec"]) {
            var egressPrecConfig = intentConfig["egress"]["prec"][index];
            var egressPrecPayload = this.createEgressPrecPayload(target, egressPrecConfig);
            egressPrecArray.push(egressPrecPayload);
        }
        childProperties[egressPrecClassName] = egressPrecArray;
    }

    this.setEgressDscpConfig = function (target, intentConfig, childProperties) {
        var egressDscpArray = [];
        var egressDscpClassName = "niegr.DscpEgress";
        if (!Array.isArray(intentConfig["egress"]["dscp"])) {
            intentConfig["egress"]["dscp"] = [intentConfig["egress"]["dscp"]];
        }
        for (var index in intentConfig["egress"]["dscp"]) {
            var egressDscpConfig = intentConfig["egress"]["dscp"][index];
            var egressDscpPayload = this.createEgressDscpPayload(target, egressDscpConfig);
            egressDscpArray.push(egressDscpPayload);
        }
        childProperties[egressDscpClassName] = egressDscpArray;
    }

    this.setEgressFcConfig = function (target, intentConfig, childProperties) {
        var egressFcArray = [];
        var egressFcClassName = "niegr.ForwardingClass";
        if (!Array.isArray(intentConfig["egress"]["fc"])) {
            intentConfig["egress"]["fc"] = [intentConfig["egress"]["fc"]];
        }
        for (var index in intentConfig["egress"]["fc"]) {
            var egressFcConfig = intentConfig["egress"]["fc"][index];
            var egressFcPayload = this.createEgressFcPayload(target, egressFcConfig);
            egressFcArray.push(egressFcPayload);
        }
        childProperties[egressFcClassName] = egressFcArray;
    }

    this.setDscpConfig = function (target, intentConfig, childProperties ) {
        var ingressDscpArray = []
        var dscpClassName = "niegr.Dscp";
        if (!Array.isArray(intentConfig["ingress"]["dscp"])) {
            intentConfig["ingress"]["dscp"] = [intentConfig["ingress"]["dscp"]];
        }
        for (var index in intentConfig["ingress"]["dscp"]) {
            var ingressDscpConfig = intentConfig["ingress"]["dscp"][index];
            var ingressDscpPayLoad = this.createIngressDscpPayLoad(target, ingressDscpConfig);
            ingressDscpArray.push(ingressDscpPayLoad);
        }
        childProperties[dscpClassName] = ingressDscpArray;
    }

    this.setDot1pConfig = function (target, intentConfig, childProperties) {
        var ingressDot1pArray = [];
        var dot1pClassName = "niegr.Dot1p";
        if (!Array.isArray(intentConfig["ingress"]["dot1p"])) {
            intentConfig["ingress"]["dot1p"] = [intentConfig["ingress"]["dot1p"]];
        }
        for (var dot1pIdx in intentConfig["ingress"]["dot1p"]) {
            var ingressDot1pConfig = intentConfig["ingress"]["dot1p"][dot1pIdx];
            var ingressDot1pPayload = this.createIngressDot1pPayLoad(target, ingressDot1pConfig);
            ingressDot1pArray.push(ingressDot1pPayload);
        }
        childProperties[dot1pClassName] = ingressDot1pArray;
    }

    this.setLspExpConfig = function (target, intentConfig, childProperties) {
        var ingressLspExpArray = [];
        var lspExpClassName = "niegr.LspExp";
        if (!Array.isArray(intentConfig["ingress"]["lsp-exp"])) {
            intentConfig["ingress"]["lsp-exp"] = [intentConfig["ingress"]["lsp-exp"]];
        }
        for (var lspExpIdx in intentConfig["ingress"]["lsp-exp"]) {
            var ingressLspExpConfig = intentConfig["ingress"]["lsp-exp"][lspExpIdx];
            var ingressLspExpPayload = this.createIngressLspExpPayLoad(target, ingressLspExpConfig);
            ingressLspExpArray.push(ingressLspExpPayload);
        }
        childProperties[lspExpClassName] = ingressLspExpArray;
    }

    this.setFcConfig = function (target, intentConfig, childProperties) {
        var ingressFcArray = [];
        var fcClassName = "niegr.IngressForwardingClass";
        if (!Array.isArray(intentConfig["ingress"]["fc"])) {
            intentConfig["ingress"]["fc"] = [intentConfig["ingress"]["fc"]];
        }
        for (var fcIdx in intentConfig["ingress"]["fc"]) {
            var ingressFcConfig = intentConfig["ingress"]["fc"][fcIdx];
            var ingressFcPayload = this.createIngressFcPayLoad(target, ingressFcConfig);
            ingressFcArray.push(ingressFcPayload);
        }
        childProperties[fcClassName] = ingressFcArray;
    }

    this.setIpCriteria = function (target, intentConfig, childProperties) {
        var ipCriteriaArray = [];
        var ipCriteriaClassName = "niegr.IpMatch";
        if (!Array.isArray(intentConfig["ingress"]["ip-criteria"]["entry"])) {
            intentConfig["ingress"]["ip-criteria"]["entry"] = [intentConfig["ingress"]["ip-criteria"]["entry"]];
        }
        for (var ipcIdx in intentConfig["ingress"]["ip-criteria"]["entry"]) {
            var ipCriteriaConfig = intentConfig["ingress"]["ip-criteria"]["entry"][ipcIdx];
            var ipCriteriaPayload = this.createIngressIpCriteriaPayload(target, ipCriteriaConfig);
            ipCriteriaArray.push(ipCriteriaPayload);
        }
        childProperties[ipCriteriaClassName] = ipCriteriaArray;
    }

    this.setIpV6Criteria = function (target, intentConfig, childProperties) {
        var ingressIpV6CriteriaArray = [];
        var ipV6CriteriaClassName = "niegr.Ipv6Match";
        if (!Array.isArray(intentConfig["ingress"]["ipv6-criteria"]["entry"])) {
            intentConfig["ingress"]["ipv6-criteria"]["entry"] = [intentConfig["ingress"]["ipv6-criteria"]["entry"]];
        }
        for (var ipv6Idx in intentConfig["ingress"]["ipv6-criteria"]["entry"]) {
            var ipv6CriteriaConfig = intentConfig["ingress"]["ipv6-criteria"]["entry"][ipv6Idx];
            var ipv6CriteriaPayload = this.createIngressIpV6CriteriaPayload(target, ipv6CriteriaConfig);
            ingressIpV6CriteriaArray.push(ipv6CriteriaPayload);
        }
        childProperties[ipV6CriteriaClassName] = ingressIpV6CriteriaArray;
    }

    /*
     function: distributePolicy
     description: Distribute Policy to local NE Level.
     */
    this.distributePolicy = function(nodeIp, objectFullName, localEdit) {
        logger.info(LOG_PREFIX + "localEdit: " + localEdit);
        var payload = {};
        if (localEdit === false) {
            payload["policy.PolicyDefinition.distributeV2"] = {};
            payload["policy.PolicyDefinition.distributeV2"]["clearOnDeployFailure"] = true;
            payload["policy.PolicyDefinition.distributeV2"]["deployer"] = "immediate";
            payload["policy.PolicyDefinition.distributeV2"]["instanceFullName"] = objectFullName;
            payload["policy.PolicyDefinition.distributeV2"]["siteIds"] = {};
            payload["policy.PolicyDefinition.distributeV2"]["siteIds"]["string"] = nodeIp;
            logger.info(LOG_PREFIX + objectFullName + ": policy distribute Payload: " + JSON.stringify(payload));
        }
        else {
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"] = {};
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["clearOnDeployFailure"] = true;
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["deployer"] = "immediate";
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["instanceFullName"] = objectFullName;
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["siteIds"] = {};
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["siteIds"]["string"] = nodeIp;
            logger.info(LOG_PREFIX + objectFullName + ": policy switch to local edit only Payload for " + nodeIp+ " : " + JSON.stringify(payload));
        }

        return nfmpFwk.post("/rest/api/v3/request?synchronousDeploy=true&clearOnDeployFailure=true", payload);
    }

    this.createEgressIpV6CriteriaPayload = function (neId, egressIpV6CriteriaConfig) {
        var egressIpV6CriteriaClassName = "niegr.EgressIpv6Match";
        var properties = {};
        if (egressIpV6CriteriaConfig) {
            for (var ipv6Data in egressIpV6CriteriaConfig) {
                switch (ipv6Data) {
                    case "entry-id":
                        properties["id"] = egressIpV6CriteriaConfig[ipv6Data];
                        break;
                    case "description":
                        properties["description"] = egressIpV6CriteriaConfig[ipv6Data];
                        break;
                    case "action":
                        properties["profile"] = egressIpV6CriteriaConfig[ipv6Data]["profile"];
                        properties["forwardingClass"] = egressIpV6CriteriaConfig[ipv6Data]["fc"];
                        var actionPrg = egressIpV6CriteriaConfig[ipv6Data]["port-redirect-group"];
                        if (actionPrg) {
                            if (actionPrg["policer"]) {
                                properties["groupPolicer"] = actionPrg["policer"];
                            }
                            if (actionPrg["queue"]) {
                                properties["groupQueue"] = actionPrg["queue"];
                            }
                        }
                        break;
                    case "match":
                        if (egressIpV6CriteriaConfig[ipv6Data]["next-header"]) {
                            properties["protocol"] = util.transformNfmpProtocol(egressIpV6CriteriaConfig[ipv6Data]["next-header"]);
                        }
                        if (egressIpV6CriteriaConfig[ipv6Data]["icmp-type"]) {
                            properties["icmpType"] = egressIpV6CriteriaConfig[ipv6Data]["icmp-type"];
                        }
                        if (egressIpV6CriteriaConfig[ipv6Data]["dscp"]) {
                            properties["dscp"] = egressIpV6CriteriaConfig[ipv6Data]["dscp"];
                        }
                        if (egressIpV6CriteriaConfig[ipv6Data]["fragment"] || egressIpV6CriteriaConfig[ipv6Data]["fragment"] === false) {
                            properties["fragment"] = util.transformFragmentGreenField(egressIpV6CriteriaConfig[ipv6Data]["fragment"]);
                        }
                        if (egressIpV6CriteriaConfig[ipv6Data]["src-ip"]) {
                            if (egressIpV6CriteriaConfig[ipv6Data]["src-ip"]["address"] || egressIpV6CriteriaConfig[ipv6Data]["src-ip"]["mask"]) {
                                if (egressIpV6CriteriaConfig[ipv6Data]["src-ip"]["address"]) {
                                    if ((egressIpV6CriteriaConfig[ipv6Data]["src-ip"]["address"]).split("/")[1] !== undefined) {
                                        properties["sourceIpAddress"] = util.expandIPv6Address((egressIpV6CriteriaConfig[ipv6Data]["src-ip"]["address"]).split("/")[0]);
                                        properties["sourceIpAddressMask"] = (egressIpV6CriteriaConfig[ipv6Data]["src-ip"]["address"]).split("/")[1];
                                    }
                                    else {
                                        properties["sourceIpAddress"] = util.expandIPv6Address(egressIpV6CriteriaConfig[ipv6Data]["src-ip"]["address"]);
                                    }
                                }
                                if (egressIpV6CriteriaConfig[ipv6Data]["src-ip"]["mask"]) {
                                    properties["sourceIpAddressFullMask"] = util.expandIPv6Address(egressIpV6CriteriaConfig[ipv6Data]["src-ip"]["mask"]);
                                }
                                properties["srcIpPrefixListPointer"] = '';
                            }
                            if (egressIpV6CriteriaConfig[ipv6Data]["src-ip"]["ipv6-prefix-list"]) {
                                properties["sourceIpAddress"] = '0:0:0:0:0:0:0:0';
                                properties["sourceIpAddressMask"] = "0";
                                properties["sourceIpAddressFullMask"] = '0:0:0:0:0:0:0:0';
                                properties["srcIpPrefixListPointer"] = "qosPrefixList:" + egressIpV6CriteriaConfig[ipv6Data]["src-ip"]["ipv6-prefix-list"]
                                                                        + "#type-IPv6";
                            }
                        }
                        if (egressIpV6CriteriaConfig[ipv6Data]["dst-ip"]) {
                            if (egressIpV6CriteriaConfig[ipv6Data]["dst-ip"]["address"] || egressIpV6CriteriaConfig[ipv6Data]["dst-ip"]["mask"]) {
                                if (egressIpV6CriteriaConfig[ipv6Data]["dst-ip"]["address"]) {
                                    if ((egressIpV6CriteriaConfig[ipv6Data]["dst-ip"]["address"]).split("/")[1] !== undefined) {
                                        properties["destinationIpAddress"] = util.expandIPv6Address((egressIpV6CriteriaConfig[ipv6Data]["dst-ip"]["address"]).split("/")[0]);
                                        properties["destinationIpAddressMask"] = (egressIpV6CriteriaConfig[ipv6Data]["dst-ip"]["address"]).split("/")[1];
                                    }
                                    else {
                                        properties["destinationIpAddress"] = util.expandIPv6Address(egressIpV6CriteriaConfig[ipv6Data]["dst-ip"]["address"]);
                                    }
                                }
                                if (egressIpV6CriteriaConfig[ipv6Data]["dst-ip"]["mask"]) {
                                    properties["destinationIpAddressFullMask"] = util.expandIPv6Address(egressIpV6CriteriaConfig[ipv6Data]["dst-ip"]["mask"]);
                                }
                                properties["dstIpPrefixListPointer"] = '';
                            }
                            if (egressIpV6CriteriaConfig[ipv6Data]["dst-ip"]["ipv6-prefix-list"]) {
                                properties["destinationIpAddress"] = '0:0:0:0:0:0:0:0';
                                properties["destinationIpAddressMask"] = "0";
                                properties["destinationIpAddressFullMask"] = "0:0:0:0:0:0:0:0";
                                properties["dstIpPrefixListPointer"] = "qosPrefixList:" + egressIpV6CriteriaConfig[ipv6Data]["dst-ip"]["ipv6-prefix-list"]
                                                                        + "#type-IPv6";
                            }
                        }
                        if (egressIpV6CriteriaConfig[ipv6Data]["src-port"]) {
                            if (egressIpV6CriteriaConfig[ipv6Data]["src-port"]["eq"]) {
                                properties["sourceOperator"] = "EQUAL";
                                properties["sourcePort1"] = egressIpV6CriteriaConfig[ipv6Data]["src-port"]["eq"];
                            }
                            else if (egressIpV6CriteriaConfig[ipv6Data]["src-port"]["lt"]) {
                                properties["sourceOperator"] = "LESS_THAN";
                                properties["sourcePort1"] = egressIpV6CriteriaConfig[ipv6Data]["src-port"]["lt"];
                            }
                            else if (egressIpV6CriteriaConfig[ipv6Data]["src-port"]["gt"]) {
                                properties["sourceOperator"] = "GREATER_THAN";
                                properties["sourcePort1"] = egressIpV6CriteriaConfig[ipv6Data]["src-port"]["gt"];
                            }
                            else if (egressIpV6CriteriaConfig[ipv6Data]["src-port"]["range"]) {
                                properties["sourceOperator"] = "RANGE";
                                properties["destinationPort1"] = egressIpV6CriteriaConfig[ipv6Data]["src-port"]["range"]["start"];
                                properties["destinationPort2"] = egressIpV6CriteriaConfig[ipv6Data]["src-port"]["range"]["end"];
                            }
                            else if (egressIpV6CriteriaConfig[ipv6Data]["src-port"]["port-list"]) {
                                properties["sourcePortListPointer"] = "qosPortList:" + egressIpV6CriteriaConfig[ipv6Data]["src-port"]["port-list"];
                            }
                        }
                        if (egressIpV6CriteriaConfig[ipv6Data]["dst-port"]) {
                            if (egressIpV6CriteriaConfig[ipv6Data]["dst-port"]["eq"]) {
                                properties["destinationOperator"] = "EQUAL";
                                properties["destinationPort1"] = egressIpV6CriteriaConfig[ipv6Data]["dst-port"]["eq"];
                            }
                            else if (egressIpV6CriteriaConfig[ipv6Data]["dst-port"]["lt"]) {
                                properties["destinationOperator"] = "LESS_THAN";
                                properties["destinationPort1"] = egressIpV6CriteriaConfig[ipv6Data]["dst-port"]["lt"];
                            }
                            else if (egressIpV6CriteriaConfig[ipv6Data]["dst-port"]["gt"]) {
                                properties["destinationOperator"] = "GREATER_THAN";
                                properties["destinationPort1"] = egressIpV6CriteriaConfig[ipv6Data]["dst-port"]["gt"];
                            }
                            else if (egressIpV6CriteriaConfig[ipv6Data]["dst-port"]["range"]) {
                                properties["destinationOperator"] = "RANGE";
                                properties["destinationPort1"] = egressIpV6CriteriaConfig[ipv6Data]["dst-port"]["range"]["start"];
                                properties["destinationPort2"] = egressIpV6CriteriaConfig[ipv6Data]["dst-port"]["range"]["end"];
                            }
                            else if (egressIpV6CriteriaConfig[ipv6Data]["dst-port"]["port-list"]) {
                                properties["destinationPortListPointer"] = "qosPortList:" + egressIpV6CriteriaConfig[ipv6Data]["dst-port"]["port-list"];
                            }
                        }
                    break;
                }
            }
        }
        return properties;
    }

    this.createEgressIpCriteriaPayload = function (neId, egressIpCriteriaConfig) {
        var egressIpCriteriaClassName = "niegr.EgressIpMatch";
        var properties = {};
        if (egressIpCriteriaConfig) {
            for (var ipcIdx in egressIpCriteriaConfig) {
                switch (ipcIdx) {
                    case "entry-id":
                        properties["id"] = egressIpCriteriaConfig[ipcIdx];
                        break;
                    case "description":
                        properties["description"] = egressIpCriteriaConfig[ipcIdx];
                        break;
                    case "action":
                        properties["profile"] = egressIpCriteriaConfig[ipcIdx]["profile"];
                        properties["forwardingClass"] = egressIpCriteriaConfig[ipcIdx]["fc"];
                        var actionPrg = egressIpCriteriaConfig[ipcIdx]["port-redirect-group"];
                        if (actionPrg) {
                            if (actionPrg["policer"]) {
                                properties["groupPolicer"] = actionPrg["policer"];
                            }
                            if (actionPrg["queue"]) {
                                properties["groupQueue"] = actionPrg["queue"];
                            }
                        }
                        break;
                    case "match":
                        if (egressIpCriteriaConfig[ipcIdx]["protocol"]) {
                            properties["protocol"] = util.transformNfmpProtocol(egressIpCriteriaConfig[ipcIdx]["protocol"]);
                        }
                        if ( properties["protocol"] === "ICMP" && egressIpCriteriaConfig[ipcIdx]["icmp-type"]) {
                            properties["icmpType"] = egressIpCriteriaConfig[ipcIdx]["icmp-type"];
                        }
                        if (egressIpCriteriaConfig[ipcIdx]["dscp"]) {
                            properties["dscp"] = egressIpCriteriaConfig[ipcIdx]["dscp"];
                        }
                        if (egressIpCriteriaConfig[ipcIdx]["fragment"]) {
                            properties["fragment"] = Boolean(egressIpCriteriaConfig[ipcIdx]["fragment"]);
                        }
                        if (egressIpCriteriaConfig[ipcIdx]["src-ip"]) {
                            if (egressIpCriteriaConfig[ipcIdx]["src-ip"]["address"] || egressIpCriteriaConfig[ipcIdx]["src-ip"]["mask"]) {
                                if (egressIpCriteriaConfig[ipcIdx]["src-ip"]["address"]) {
                                    if ((egressIpCriteriaConfig[ipcIdx]["src-ip"]["address"]).split("/")[1] !== undefined) {
                                        properties["sourceIpAddress"] = (egressIpCriteriaConfig[ipcIdx]["src-ip"]["address"]).split("/")[0];
                                        properties["sourceIpAddressMask"] = (egressIpCriteriaConfig[ipcIdx]["src-ip"]["address"]).split("/")[1];
                                    }
                                    else {
                                        properties["sourceIpAddress"] = egressIpCriteriaConfig[ipcIdx]["src-ip"]["address"];
                                    }
                                }
                                if (egressIpCriteriaConfig[ipcIdx]["src-ip"]["mask"]) {
                                    properties["sourceIpAddressFullMask"] = egressIpCriteriaConfig[ipcIdx]["src-ip"]["mask"];
                                }
                                 properties["srcIpPrefixListPointer"] = '';
                            }
                            if (egressIpCriteriaConfig[ipcIdx]["src-ip"]["ip-prefix-list"]) {
                                properties["sourceIpAddress"] = '0.0.0.0';
                                properties["sourceIpAddressMask"] = "0";
                                properties["sourceIpAddressFullMask"] = '0.0.0.0';
                                properties["srcIpPrefixListPointer"] = "qosPrefixList:" + egressIpCriteriaConfig[ipcIdx]["src-ip"]["ip-prefix-list"] + "#type-IPv4";
                            }
                        }
                        if (egressIpCriteriaConfig[ipcIdx]["dst-ip"]) {
                            if (egressIpCriteriaConfig[ipcIdx]["dst-ip"]["address"] || egressIpCriteriaConfig[ipcIdx]["dst-ip"]["mask"]) {
                                if (egressIpCriteriaConfig[ipcIdx]["dst-ip"]["address"]) {
                                    if ((egressIpCriteriaConfig[ipcIdx]["dst-ip"]["address"]).split("/")[1] !== undefined) {
                                        properties["destinationIpAddress"] = (egressIpCriteriaConfig[ipcIdx]["dst-ip"]["address"]).split("/")[0];
                                        properties["destinationIpAddressMask"] = (egressIpCriteriaConfig[ipcIdx]["dst-ip"]["address"]).split("/")[1];
                                    }
                                    else {
                                        properties["destinationIpAddress"] = egressIpCriteriaConfig[ipcIdx]["dst-ip"]["address"];
                                    }
                                }
                                if (egressIpCriteriaConfig[ipcIdx]["dst-ip"]["mask"]) {
                                    properties["destinationIpAddressFullMask"] = egressIpCriteriaConfig[ipcIdx]["dst-ip"]["mask"];
                                }
                                 properties["dstIpPrefixListPointer"] = '';
                            }
                            if (egressIpCriteriaConfig[ipcIdx]["dst-ip"]["ip-prefix-list"]) {
                                properties["destinationIpAddress"] = '0.0.0.0';
                                properties["destinationIpAddressMask"] = '0';
                                properties["destinationIpAddressFullMask"] = '0.0.0.0';
                                properties["dstIpPrefixListPointer"] = "qosPrefixList:" + egressIpCriteriaConfig[ipcIdx]["dst-ip"]["ip-prefix-list"] + "#type-IPv4";
                            }

                        }
                        if (egressIpCriteriaConfig[ipcIdx]["src-port"]) {
                            if (egressIpCriteriaConfig[ipcIdx]["src-port"]["eq"]) {
                                properties["sourceOperator"] = "EQUAL";
                                properties["sourcePort1"] = egressIpCriteriaConfig[ipcIdx]["src-port"]["eq"];
                            }
                            else if (egressIpCriteriaConfig[ipcIdx]["src-port"]["lt"]) {
                                properties["sourceOperator"] = "LESS_THAN";
                                properties["sourcePort1"] = egressIpCriteriaConfig[ipcIdx]["src-port"]["lt"];
                            }
                            else if (egressIpCriteriaConfig[ipcIdx]["src-port"]["gt"]) {
                                properties["sourceOperator"] = "GREATER_THAN";
                                properties["sourcePort1"] = egressIpCriteriaConfig[ipcIdx]["src-port"]["gt"];
                            }
                            else if (egressIpCriteriaConfig[ipcIdx]["src-port"]["range"]) {
                                properties["sourceOperator"] = "RANGE";
                                properties["destinationPort1"] = egressIpCriteriaConfig[ipcIdx]["src-port"]["range"]["start"];
                                properties["destinationPort2"] = egressIpCriteriaConfig[ipcIdx]["src-port"]["range"]["end"];
                            }
                            else if (egressIpCriteriaConfig[ipcIdx]["src-port"]["port-list"]) {
                                properties["sourcePortListPointer"] = "qosPortList:" + egressIpCriteriaConfig[ipcIdx]["src-port"]["port-list"];
                            }
                        }
                        if (egressIpCriteriaConfig[ipcIdx]["dst-port"]) {
                            if (egressIpCriteriaConfig[ipcIdx]["dst-port"]["eq"]) {
                                properties["destinationOperator"] = "EQUAL";
                                properties["destinationPort1"] = egressIpCriteriaConfig[ipcIdx]["dst-port"]["eq"];
                            }
                            else if (egressIpCriteriaConfig[ipcIdx]["dst-port"]["lt"]) {
                                properties["destinationOperator"] = "LESS_THAN";
                                properties["destinationPort1"] = egressIpCriteriaConfig[ipcIdx]["dst-port"]["lt"];
                            }
                            else if (egressIpCriteriaConfig[ipcIdx]["dst-port"]["gt"]) {
                                properties["destinationOperator"] = "GREATER_THAN";
                                properties["destinationPort1"] = egressIpCriteriaConfig[ipcIdx]["dst-port"]["gt"];
                            }
                            else if (egressIpCriteriaConfig[ipcIdx]["dst-port"]["range"]) {
                                properties["destinationOperator"] = "RANGE";
                                properties["destinationPort1"] = egressIpCriteriaConfig[ipcIdx]["dst-port"]["range"]["start"];
                                properties["destinationPort2"] = egressIpCriteriaConfig[ipcIdx]["dst-port"]["range"]["end"];
                            }
                            else if (egressIpCriteriaConfig[ipcIdx]["dst-port"]["port-list"]) {
                                properties["destinationPortListPointer"] = "qosPortList:" + egressIpCriteriaConfig[ipcIdx]["dst-port"]["port-list"];
                            }
                        }
                        break;
                }
            }
        }
        return properties;
    }

    this.createEgressPrecPayload = function (neId, egressPrecConfig) {
        var egressPrecClassName = "niegr.Precedence";
        var properties = {};
        if (egressPrecConfig) {
            for (var precData in egressPrecConfig) {
                switch (precData) {
                    case "prec-value":
                        properties["prec"] = "value_" + egressPrecConfig[precData];
                        break;
                    case "fc":
                        properties["forwardingClass"] = egressPrecConfig[precData];
                        break;
                    case "profile":
                        properties["profile"] = egressPrecConfig[precData];
                        break;
                    default:
                        logger.info(LOG_PREFIX + "Unknown attribute identified/not-defined: " + precData);
                        break;
                }
            }
        }
        return properties;
    }

    this.createEgressDscpPayload = function (neId, egressDscpConfig) {
        var egressDscpClassName = "niegr.DscpEgress";
        var properties = {};
        if (egressDscpConfig) {
            for (var dscpData in egressDscpConfig) {
                switch (dscpData) {
                    case "dscp-name":
                        properties["dscp"] = egressDscpConfig[dscpData];
                        break;
                    case "fc":
                        properties["forwardingClass"] = egressDscpConfig[dscpData];
                        break;
                    case "profile":
                        properties["profile"] = egressDscpConfig[dscpData];
                        break;
                    default:
                        logger.info(LOG_PREFIX + "Unknown attribute identified/not-defined: " + dscpData);
                        break;
                }
            }
        }
        return properties;
    }
    this.createEgressFcPayload = function (neId, egressFcConfig) {
        var egressFcClassName = "niegr.ForwardingClass";
        var properties = {};
        if (egressFcConfig) {
            properties["forwardingClass"] = egressFcConfig["fc-name"]
            properties["deMark"] = false;
            for (var fcData in egressFcConfig) {
                switch (fcData) {
                    case "dot1p-in-profile":
                        properties["dot1pInProfile"] = "priority_" + egressFcConfig[fcData];
                        break;
                    case "dot1p-out-profile":
                        properties["dot1pOutProfile"] = "priority_" + egressFcConfig[fcData];
                        break;
                    case "dscp-in-profile":
                        properties["dscpInProfile"] = egressFcConfig[fcData];
                        break;
                    case "dscp-out-profile":
                        properties["dscpOutProfile"] = egressFcConfig[fcData];
                        break;
                    case "lsp-exp-in-profile":
                        properties["lspExpInProfile"] = "lspExp_" + egressFcConfig[fcData];
                        break;
                    case "lsp-exp-out-profile":
                        properties["lspExpOutProfile"] = "lspExp_" + egressFcConfig[fcData];
                        break;
                    case "de-mark":
                        properties["deMark"] = true;
                        properties["forceDeValue"] = egressFcConfig[fcData]["force"]
                        break;
                    case "port-redirect-group":
                        if (egressFcConfig[fcData]["queue"]) {
                            properties["redirectQGrpQid"] = egressFcConfig[fcData]["queue"];
                        }
                        if (egressFcConfig[fcData]["policer"]) {
                            properties["redirectQGrpPolicerId"] = egressFcConfig[fcData]["policer"];
                        }
                        break;
                    default:
                        logger.info(LOG_PREFIX + "Unknown attribute identified/not-defined: " + fcData);
                        break;
                }
            }
        }
        return properties;
    }

    this.createIngressIpCriteriaPayload = function (neId, ipCriteriaConfig) {
        var ipCriteriaClassName = "niegr.IpMatch";
        var properties = {};
        if (ipCriteriaConfig) {
            for (var ipcData in ipCriteriaConfig) {
                switch (ipcData) {
                    case "entry-id":
                        properties["id"] = ipCriteriaConfig[ipcData];
                        break;
                    case "description":
                        properties["description"] = ipCriteriaConfig[ipcData];
                        break;
                    case "match":
                        if (ipCriteriaConfig[ipcData]["protocol"]) {
                            properties["protocol"] = util.transformNfmpProtocol(ipCriteriaConfig[ipcData]["protocol"]);
                        }
                        if (ipCriteriaConfig[ipcData]["dscp"]) {
                            properties["dscp"] = ipCriteriaConfig[ipcData]["dscp"];
                        }
                        if (ipCriteriaConfig[ipcData]["fragment"]) {
                            properties["fragment"] = Boolean(ipCriteriaConfig[ipcData]["fragment"]);
                        }
                        if (ipCriteriaConfig[ipcData]["src-ip"]) {
                            if (ipCriteriaConfig[ipcData]["src-ip"]["address"] || ipCriteriaConfig[ipcData]["src-ip"]["mask"]) {
                                if (ipCriteriaConfig[ipcData]["src-ip"]["address"]) {
                                    if ((ipCriteriaConfig[ipcData]["src-ip"]["address"]).split("/")[1] !== undefined) {
                                        properties["sourceIpAddress"] = (ipCriteriaConfig[ipcData]["src-ip"]["address"]).split("/")[0];
                                        properties["sourceIpAddressMask"] = (ipCriteriaConfig[ipcData]["src-ip"]["address"]).split("/")[1];
                                    }
                                    else {
                                        properties["sourceIpAddress"] = ipCriteriaConfig[ipcData]["src-ip"]["address"];
                                    }
                                }
                                if (ipCriteriaConfig[ipcData]["src-ip"]["mask"]) {
                                    //<d.d.d.d> for classic mask full mask configuration
                                    properties["sourceIpAddressFullMask"] = ipCriteriaConfig[ipcData]["src-ip"]["mask"];
                                }
                                properties["srcIpPrefixListPointer"] = '';
                            }
                            if (ipCriteriaConfig[ipcData]["src-ip"]["ip-prefix-list"]) {
                                properties["sourceIpAddress"] = '0.0.0.0';
                                properties["sourceIpAddressMask"] = "0";
                                properties["sourceIpAddressFullMask"] = '0.0.0.0';
                                properties["srcIpPrefixListPointer"] = "qosPrefixList:" + ipCriteriaConfig[ipcData]["src-ip"]["ip-prefix-list"] + "#type-IPv4";
                            }
                        }
                        if (ipCriteriaConfig[ipcData]["dst-ip"]) {
                            if (ipCriteriaConfig[ipcData]["dst-ip"]["address"] || ipCriteriaConfig[ipcData]["dst-ip"]["mask"]) {
                                if (ipCriteriaConfig[ipcData]["dst-ip"]["address"]) {
                                    if ((ipCriteriaConfig[ipcData]["dst-ip"]["address"]).split("/")[1] !== undefined) {
                                        properties["destinationIpAddress"] = (ipCriteriaConfig[ipcData]["dst-ip"]["address"]).split("/")[0];
                                        properties["destinationIpAddressMask"] = (ipCriteriaConfig[ipcData]["dst-ip"]["address"]).split("/")[1];
                                    }
                                    else {
                                        properties["destinationIpAddress"] = ipCriteriaConfig[ipcData]["dst-ip"]["address"];
                                    }
                                }
                                if (ipCriteriaConfig[ipcData]["dst-ip"]["mask"]) {
                                    //<d.d.d.d> for classic full mask configuration
                                    properties["destinationIpAddressFullMask"] = ipCriteriaConfig[ipcData]["dst-ip"]["mask"];
                                }
                                properties["dstIpPrefixListPointer"] = '';
                            }
                            if (ipCriteriaConfig[ipcData]["dst-ip"]["ip-prefix-list"]) {
                                properties["destinationIpAddress"] = '0.0.0.0';
                                properties["destinationIpAddressMask"] = '0';
                                properties["destinationIpAddressFullMask"] = '0.0.0.0';
                                properties["dstIpPrefixListPointer"] = "qosPrefixList:" + ipCriteriaConfig[ipcData]["dst-ip"]["ip-prefix-list"] + "#type-IPv4";
                            }
                        }
                        if (ipCriteriaConfig[ipcData]["src-port"]) {
                            if (ipCriteriaConfig[ipcData]["src-port"]["eq"]) {
                                properties["sourceOperator"] = "EQUAL";
                                properties["sourcePort1"] = ipCriteriaConfig[ipcData]["src-port"]["eq"];
                            }
                            else if (ipCriteriaConfig[ipcData]["src-port"]["lt"]) {
                                properties["sourceOperator"] = "LESS_THAN";
                                properties["sourcePort1"] = ipCriteriaConfig[ipcData]["src-port"]["lt"];
                            }
                            else if (ipCriteriaConfig[ipcData]["src-port"]["gt"]) {
                                properties["sourceOperator"] = "GREATER_THAN";
                                properties["sourcePort1"] = ipCriteriaConfig[ipcData]["src-port"]["gt"];
                            }
                            else if(ipCriteriaConfig[ipcData]["src-port"]["range"]) {
                                properties["sourceOperator"] = "RANGE";
                                properties["sourcePort1"] = ipCriteriaConfig[ipcData]["src-port"]["range"]["start"];
                                properties["sourcePort2"] = ipCriteriaConfig[ipcData]["src-port"]["range"]["end"];
                            }
                            else if (ipCriteriaConfig[ipcData]["src-port"]["port-list"]) {
                                properties["ingSourcePortListPointer"] = "qosPortList:" + ipCriteriaConfig[ipcData]["src-port"]["port-list"];
                            }
                        }
                        if (ipCriteriaConfig[ipcData]["dst-port"]) {
                            if (ipCriteriaConfig[ipcData]["dst-port"]["eq"]) {
                                properties["destinationOperator"] = "EQUAL";
                                properties["destinationPort1"] = ipCriteriaConfig[ipcData]["dst-port"]["eq"];
                            }
                            else if (ipCriteriaConfig[ipcData]["dst-port"]["lt"]) {
                                properties["destinationOperator"] = "LESS_THAN";
                                properties["destinationPort1"] = ipCriteriaConfig[ipcData]["dst-port"]["lt"];
                            }
                            else if (ipCriteriaConfig[ipcData]["dst-port"]["gt"]) {
                                properties["destinationOperator"] = "GREATER_THAN";
                                properties["destinationPort1"] = ipCriteriaConfig[ipcData]["dst-port"]["gt"];
                            }
                            else if (ipCriteriaConfig[ipcData]["dst-port"]["range"]) {
                                properties["destinationOperator"] = "RANGE";
                                properties["destinationPort1"] = ipCriteriaConfig[ipcData]["dst-port"]["range"]["start"];
                                properties["destinationPort2"] = ipCriteriaConfig[ipcData]["dst-port"]["range"]["end"];
                            }
                            else if (ipCriteriaConfig[ipcData]["dst-port"]["port-list"]) {
                                properties["ingDestinationPortListPointer"] = "qosPortList:" + ipCriteriaConfig[ipcData]["dst-port"]["port-list"]
                            }
                        }
                        break;
                    case "action":
                        properties["profile"] = ipCriteriaConfig[ipcData]["profile"];
                        properties["forwardingClass"] = ipCriteriaConfig[ipcData]["fc"];
                        break;
                    default:
                        logger.info(LOG_PREFIX + "Unknown attribute identified/not-defined: " + ipcData);
                        break;
                }
            }
        }
        return properties;
    }
    this.createIngressIpV6CriteriaPayload = function (neId, ipv6CriteriaConfig) {
        var ipV6CriteriaClassName = "niegr.Ipv6Match";
        var properties = {};
        if (ipv6CriteriaConfig) {
            for (var ipv6Data in ipv6CriteriaConfig) {
                switch (ipv6Data) {
                    case "entry-id":
                        properties["id"] = ipv6CriteriaConfig[ipv6Data];
                        break;
                    case "description":
                        properties["description"] = ipv6CriteriaConfig[ipv6Data];
                        break;
                    case "match":
                        if (ipv6CriteriaConfig[ipv6Data]["next-header"]) {
                            properties["protocol"] = util.transformNfmpProtocol(ipv6CriteriaConfig[ipv6Data]["next-header"]);
                        }
                        if (ipv6CriteriaConfig[ipv6Data]["dscp"]) {
                            properties["dscp"] = ipv6CriteriaConfig[ipv6Data]["dscp"];
                        }
                        if (ipv6CriteriaConfig[ipv6Data]["fragment"]) {
                            properties["fragment"] = Boolean(ipv6CriteriaConfig[ipv6Data]["fragment"]);
                        }
                        else if (ipv6CriteriaConfig[ipv6Data]["fragment"] === false) {
                            properties["fragment"] = Boolean(ipv6CriteriaConfig[ipv6Data]["fragment"]);
                        }
                        if (ipv6CriteriaConfig[ipv6Data]["src-ip"]) {
                            if (ipv6CriteriaConfig[ipv6Data]["src-ip"]["address"] || ipv6CriteriaConfig[ipv6Data]["src-ip"]["mask"]) {
                                if (ipv6CriteriaConfig[ipv6Data]["src-ip"]["address"]) {
                                    if ((ipv6CriteriaConfig[ipv6Data]["src-ip"]["address"]).split("/")[1] !== undefined) {
                                        properties["sourceIpAddress"] = util.expandIPv6Address((ipv6CriteriaConfig[ipv6Data]["src-ip"]["address"]).split("/")[0]);
                                        properties["sourceIpAddressMask"] = (ipv6CriteriaConfig[ipv6Data]["src-ip"]["address"]).split("/")[1];
                                    }
                                    else {
                                        properties["sourceIpAddress"] = util.expandIPv6Address(ipv6CriteriaConfig[ipv6Data]["src-ip"]["address"]);
                                    }
                                }
                                if (ipv6CriteriaConfig[ipv6Data]["src-ip"]["mask"]) {
                                    properties["sourceIpAddressFullMask"] = util.expandIPv6Address(ipv6CriteriaConfig[ipv6Data]["src-ip"]["mask"]);
                                }
                                properties["srcIpPrefixListPointer"] = '';
                            }
                            if (ipv6CriteriaConfig[ipv6Data]["src-ip"]["ipv6-prefix-list"]) {
                                properties["sourceIpAddress"] = '0:0:0:0:0:0:0:0';
                                properties["sourceIpAddressMask"] = "0";
                                properties["sourceIpAddressFullMask"] = '0:0:0:0:0:0:0:0';
                                properties["srcIpPrefixListPointer"] = "qosPrefixList:" + ipv6CriteriaConfig[ipv6Data]["src-ip"]["ipv6-prefix-list"]
                                                                        + "#type-IPv6";
                            }
                        }
                        if (ipv6CriteriaConfig[ipv6Data]["dst-ip"]) {
                            if (ipv6CriteriaConfig[ipv6Data]["dst-ip"]["address"] || ipv6CriteriaConfig[ipv6Data]["dst-ip"]["mask"]) {
                                if (ipv6CriteriaConfig[ipv6Data]["dst-ip"]["address"]) {
                                    if ((ipv6CriteriaConfig[ipv6Data]["dst-ip"]["address"]).split("/")[1] !== undefined) {
                                        properties["destinationIpAddress"] = util.expandIPv6Address((ipv6CriteriaConfig[ipv6Data]["dst-ip"]["address"]).split("/")[0]);
                                        properties["destinationIpAddressMask"] = (ipv6CriteriaConfig[ipv6Data]["dst-ip"]["address"]).split("/")[1];
                                    }
                                    else {
                                        properties["destinationIpAddress"] = util.expandIPv6Address(ipv6CriteriaConfig[ipv6Data]["dst-ip"]["address"]);
                                    }
                                }
                                if (ipv6CriteriaConfig[ipv6Data]["dst-ip"]["mask"]) {
                                    properties["destinationIpAddressFullMask"] = util.expandIPv6Address(ipv6CriteriaConfig[ipv6Data]["dst-ip"]["mask"]);
                                }
                                properties["dstIpPrefixListPointer"] = '';
                            }
                            if (ipv6CriteriaConfig[ipv6Data]["dst-ip"]["ipv6-prefix-list"]) {
                                properties["destinationIpAddress"] = '0:0:0:0:0:0:0:0';
                                properties["destinationIpAddressMask"] = "0";
                                properties["destinationIpAddressFullMask"] = "0:0:0:0:0:0:0:0";
                                properties["dstIpPrefixListPointer"] = "qosPrefixList:" + ipv6CriteriaConfig[ipv6Data]["dst-ip"]["ipv6-prefix-list"]
                                                                        + "#type-IPv6";
                            }
                        }
                        if (ipv6CriteriaConfig[ipv6Data]["src-port"]) {
                            if (ipv6CriteriaConfig[ipv6Data]["src-port"]["eq"]) {
                                properties["sourceOperator"] = "EQUAL";
                                properties["sourcePort1"] = ipv6CriteriaConfig[ipv6Data]["src-port"]["eq"];
                            }
                            else if (ipv6CriteriaConfig[ipv6Data]["src-port"]["lt"]) {
                                properties["sourceOperator"] = "LESS_THAN";
                                properties["sourcePort1"] = ipv6CriteriaConfig[ipv6Data]["src-port"]["lt"];
                            }
                            else if (ipv6CriteriaConfig[ipv6Data]["src-port"]["gt"]) {
                                properties["sourceOperator"] = "GREATER_THAN";
                                properties["sourcePort1"] = ipv6CriteriaConfig[ipv6Data]["src-port"]["gt"];
                            }
                            else if (ipv6CriteriaConfig[ipv6Data]["src-port"]["range"]) {
                                properties["sourceOperator"] = "RANGE";
                                properties["destinationPort1"] = ipv6CriteriaConfig[ipv6Data]["src-port"]["range"]["start"];
                                properties["destinationPort2"] = ipv6CriteriaConfig[ipv6Data]["src-port"]["range"]["end"];
                            }
                            else if (ipv6CriteriaConfig[ipv6Data]["src-port"]["port-list"]) {
                                properties["ingSourcePortListPointer"] = "qosPortList:" + ipv6CriteriaConfig[ipv6Data]["src-port"]["port-list"];
                            }
                        }
                        if (ipv6CriteriaConfig[ipv6Data]["dst-port"]) {
                            if (ipv6CriteriaConfig[ipv6Data]["dst-port"]["eq"]) {
                                properties["destinationOperator"] = "EQUAL";
                                properties["destinationPort1"] = ipv6CriteriaConfig[ipv6Data]["dst-port"]["eq"];
                            }
                            else if (ipv6CriteriaConfig[ipv6Data]["dst-port"]["lt"]) {
                                properties["destinationOperator"] = "LESS_THAN";
                                properties["destinationPort1"] = ipv6CriteriaConfig[ipv6Data]["dst-port"]["lt"];
                            }
                            else if (ipv6CriteriaConfig[ipv6Data]["dst-port"]["gt"]) {
                                properties["destinationOperator"] = "GREATER_THAN";
                                properties["destinationPort1"] = ipv6CriteriaConfig[ipv6Data]["dst-port"]["gt"];
                            }
                            else if (ipv6CriteriaConfig[ipv6Data]["dst-port"]["range"]) {
                                properties["destinationOperator"] = "RANGE";
                                properties["destinationPort1"] = ipv6CriteriaConfig[ipv6Data]["dst-port"]["range"]["start"];
                                properties["destinationPort2"] = ipv6CriteriaConfig[ipv6Data]["dst-port"]["range"]["end"];
                            }
                            else if (ipv6CriteriaConfig[ipv6Data]["dst-port"]["port-list"]) {
                                properties["ingDestinationPortListPointer"] = "qosPortList:" + ipv6CriteriaConfig[ipv6Data]["dst-port"]["port-list"];
                            }
                        }
                        break;
                    case "action":
                        properties["profile"] = ipv6CriteriaConfig[ipv6Data]["profile"];
                        properties["forwardingClass"] = ipv6CriteriaConfig[ipv6Data]["fc"];
                        break;
                    default:
                        logger.info(LOG_PREFIX + "Unknown attribute identified/not-defined: " + ipv6Data);
                        break;
                }
            }
        }
        return properties;
    }

    this.createIngressFcPayLoad = function (neId, ingressFcConfig) {
        var fcClassName = "niegr.IngressForwardingClass";
        var properties = {};
        properties["forwardingClass"] = ingressFcConfig["fc-name"];
        if (ingressFcConfig["fp-redirect-group"]) {
            for (var fcData in ingressFcConfig["fp-redirect-group"]) {
                switch (fcData) {
                    case "multicast-policer":
                        properties["fpMulticastPolicerId"] = ingressFcConfig["fp-redirect-group"][fcData];
                        break;
                    case "policer":
                        properties["fpPolicerId"] = ingressFcConfig["fp-redirect-group"][fcData];
                        break;
                    case "broadcast-policer":
                        properties["fpBroadcastPolicerId"] = ingressFcConfig["fp-redirect-group"][fcData];
                        break;
                    case "unknown-policer":
                        properties["fpUnknownPolicerId"] = ingressFcConfig["fp-redirect-group"][fcData];
                        break;
                    default:
                        logger.info(LOG_PREFIX + "Unknown attribute identified/not-defined" + fcData);
                        break;
                }
            }
        }
        return properties;
    }

    this.createIngressLspExpPayLoad = function (neId, ingressLspExpConfig) {
        var lspExpClassName = "niegr.LspExp";
        var properties = {};
        if (ingressLspExpConfig) {
            for (var lspExpData in ingressLspExpConfig) {
                switch (lspExpData) {
                    case "lsp-exp-value":
                        properties["lspExp"] = "lspExp_" + ingressLspExpConfig[lspExpData];
                        break;
                    case "fc":
                        properties["forwardingClass"] = ingressLspExpConfig[lspExpData];
                        break;
                    case "profile":
                        properties["profile"] = ingressLspExpConfig[lspExpData];
                        break;
                    default:
                        logger.info(LOG_PREFIX + "Unknown attribute identified/not-defined" + lspExpData);
                        break;
                }
            }
        }
        return properties;
    }

    this.createIngressDot1pPayLoad = function (neId, ingressDot1pConfig) {
        var dot1pClassName = "niegr.Dot1p";
        var properties = {};
        if (ingressDot1pConfig) {
            for (var dot1pData in ingressDot1pConfig) {
                switch (dot1pData) {
                    case "dot1p-value":
                        properties["dot1p"] = "value_" + ingressDot1pConfig[dot1pData];
                        break;
                    case "fc":
                        properties["forwardingClass"] = ingressDot1pConfig[dot1pData];
                        break;
                    case "profile":
                        properties["profile"] = ingressDot1pConfig[dot1pData];
                        break;
                    default:
                        logger.info(LOG_PREFIX + "Unknown attribute identified/not-defined" + dot1pData);
                        break;
                }
            }
        }

        return properties;
    }

    this.createIngressDscpPayLoad = function (neId, ingressDscpConfig) {
        var dscpClassName = "niegr.Dscp";
        var properties = {};
        if (ingressDscpConfig) {
            properties["dscp"] = ingressDscpConfig["dscp-name"];
            properties["forwardingClass"] = ingressDscpConfig["fc"];
            properties["profile"] = ingressDscpConfig["profile"];
        }
        return properties;
    }

    this.createChildObjectPayload = function (fullClassName, properties) {
        var childObjectPayLoad = {};
        properties["actionMask"] = {
            "bit": [
                "create",
                "modify"
            ]
        };
        childObjectPayLoad[fullClassName] = properties;
        return childObjectPayLoad;
    }

    this.modifyRequest = function (neId, payload) {
        logger.info(LOG_PREFIX + "Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.deploy(neId, JSON.stringify(payload), "application/json");
        if (!result.success)
        {
           logger.error("Error result = {}",JSON.stringify(result));
           let errorMsg = result.msg;
           if(errorMsg.indexOf("object already exists") !== -1)
           {
               logger.info("Global policy Object already exists, Re-checking the Policy existence ");
               //util.delay(2000);
               let configInfo = payload.configInfo;
               let fullClassName;
               for (let key in configInfo) {
                 if (configInfo.hasOwnProperty(key)) {
                   fullClassName = key;
                   break;
                 }
               }
               let objectFullName = payload.objectFullName;
               objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
               logger.info("fullClassName = {}",fullClassName);
               logger.info("objectFullName = {}",objectFullName);
               if (!util.isObjectExists(fullClassName, objectFullName))
               {
                   throw new RuntimeException("Global Policy Object Not Found!!!");
               }
           }
           else
           {
               throw new RuntimeException(result.msg);
           }
        }
        return result;
    }

    this.constructSearchString = function(neId, policyName, policyId) {
        logger.info(LOG_PREFIX + "Creating search payload for NE ID : " + neId + " with Policy Name : " + policyName);
        var jsonPayLoad = {
            "fullClassName": full_class_name,
            "filter": {
                "and": {
                    "equal": [
                        {
                            "name": "siteId",
                            "value": neId
                        }
                    ]
                }
            },
            "resultFilter": {
                "children": "",
                "attribute": [
                    "policyName",
                    "id"
                ]
            }
        };
        var nameSearchObj = {
            "name": "policyName",
            "value": policyName
        };
        var idSearchObj = {
            "name": "id",
            "value": policyId
        };
        if (policyName !== undefined) {
            jsonPayLoad["filter"]["and"]["equal"].push(nameSearchObj);
        }
        else {
            jsonPayLoad["filter"]["and"]["equal"].push(idSearchObj);
        }
        return jsonPayLoad;
    }

    this.audit = function(target, config, svcTopo, adminState, auditReport, intentTypeName, parentXpath, initialPropertyName, uniqueIdentifier) {
        var savedTopology = svcTopo;
        savedObjects = {};
        currentObjects = {};
        isAudit = true;
        var policyName = util.getQosNetworkPolicyName(target);
        var policyId = util.getQosNetworkPolicyId(target);
        var target = parseTarget.getNeIdFromTarget(target);
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        logger.info(LOG_PREFIX + "auditing configuration = "+JSON.stringify(intentConfig));
        logger.info(LOG_PREFIX + "Target device = " + target);
        logger.info(LOG_PREFIX + "Target Network QoS = " + policyName);
        intentConfig[network_policy_name] = policyName;
        intentConfig["id"] = parseInt(policyId);
        if (intentConfig) {
            this.auditAndCompare(target, intentConfig, auditReport);
        }
        else {
            throw "configuration not available in the intent";
        }
        return auditReport;
    }

    this.auditAndCompare = function (target, intentConfig, auditReport){
        var networkQosPayload = this.createQosNetworkPolicyPayload(target, intentConfig, true, null);
        var result = this.auditRequest(target, networkQosPayload);
        auditReport = util.reportMisaligned(target, result, auditReport);
        return auditReport;
    }

    this.auditRequest = function (target, payLoad) {
        logger.info(LOG_PREFIX + "Sending the audit request for mdt");
        logger.info(JSON.stringify(payLoad));
        var result = nfmpFwk.compare(target, JSON.stringify(payLoad), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;
    }

    this.syncDelete = function (input, result) {
        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var policyId = util.getQosNetworkPolicyId(input.getTarget());
        var neFamily = intentDeviationObj.getNeFamilyRelease(neId);
        var policyName;
        if (!neFamily.startsWith("7705")) {
            policyName = util.getQosNetworkPolicyName(input.getTarget());
        }
        var searchPayload = this.constructSearchString(neId, policyName, policyId);
        var searchResponse = nfmpFwk.find(neId, searchPayload);
        logger.info(LOG_PREFIX + "Deleting payload : " + JSON.stringify(searchPayload));
        if (!(searchResponse.success && JSON.stringify(JSON.parse(searchResponse.response)) !== JSON.stringify({}))) {
            if(!(searchResponse.success)) {
                logger.info( LOG_PREFIX + "syncDelete(): Unable to get Policy info from nfm-p for policy with Name:" +
                    policyName + " and Id: " + policyId + " on " + neId);
            }
            if(JSON.parse(searchResponse.response) === JSON.stringify({})) {
                logger.info(LOG_PREFIX + "syncDelete(): There is no Network QoS policy with Name:" +
                    policyName + " and Id: " + policyId + " on " + neId);
            }
            result.setSuccess(false);
            return;
        }

        var objectFullName = "network:" + neId + ":" + policy_fdn + ":" + policyId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        logger.info(LOG_PREFIX + "syncDelete(): Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");
        if (!deleteResult.success) {
            logger.info(LOG_PREFIX + "syncDelete(): Unable to Delete: " + deleteResult.msg);
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }

    this.xml2object = function(xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: '+ json)
        return JSON.parse(json);
    }

    this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop,intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop,intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }

    this.loadCurrentObjectsToTopology = function(target) {
        var currentTopo = topologyFactory.createServiceTopology();
        if(Object.keys(currentObjects).length){
            for(var key in currentObjects){
                objectId = mapFwk.get(currentObjects,key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key,objectId,"INFRASTRUCTURE",target,""));
            }
        }
        return currentTopo;
    }

    this.loadSavedObjectsFromTopology = function(savedTopology) {
        if(savedTopology){
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0){
                topoObjects.forEach(function(topoObject){
                    mapFwk.set(savedObjects,topoObject.getObjectType(),topoObject.getObjectRelativeObjectID());
                });
            }
        }
    }

    this.constructSearchStringWithPolicyID = function(neId, policyId, name) {
        var filterExpression = "siteId='" + neId + "' AND id='" + policyId + "' AND policyName='" + name + "'";
        var jsonPayLoad = {
            "fullClassName": full_class_name,
            "filter": {
                "filterExpression": filterExpression
            }
        };
        return jsonPayLoad;
    }
}
