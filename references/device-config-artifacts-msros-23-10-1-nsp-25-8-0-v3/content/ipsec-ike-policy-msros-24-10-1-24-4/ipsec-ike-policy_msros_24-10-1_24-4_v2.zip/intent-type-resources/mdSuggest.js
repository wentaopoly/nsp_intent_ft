function MdSuggest() {

  this.getID = function(neId) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/ipsec/ike-policy?fields=id";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}", neId, url);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:ike-policy'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['id']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
 }

 this.getIkeTransform = function(neId) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/ipsec/ike-transform?fields=id";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}", neId, url);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:ike-transform'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['id']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
 }
}
