function MdSuggest() {
   this.getSharedPolicerName = function (neId) {
      const url =`/restconf/data/network-device-mgr:network-devices/network-device=${neId}/root/nokia-conf:/configure/qos/shared-policers/policer?fields=shared-policer-name`;
      return this.getSuggestData(neId, url, "nokia-conf:policer", "shared-policer-name");
   }
   this.getSuggestData = function(neId, url, initialProperty, propertyName) {
      const mdcFwk = new MdcFwk();
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg[initialProperty];
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data[propertyName]).filter(value => value != null):[];
      return ret;
   }
}