function MdSuggest() {
    this.getIsisInstance = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base/isis?fields=isis-instance";
        return this.getSuggestData(neId, url, "nokia-conf:isis", "isis-instance");
    }

    this.getIsisInterface = function (neId, action, instance) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base/isis="+instance+"/interface?fields=interface-name";
        if(action != "associate")
        {
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base/interface?fields=interface-name";
        }
        return this.getSuggestData(neId, url, "nokia-conf:interface", "interface-name");
    }

    this.getRouteNHTemplate = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/routing-options/route-next-hop-policy/template?fields=template-name";
        return this.getSuggestData(neId, url, "nokia-conf:template", "template-name");
    }

    this.getAdjacencySet = function (neId, instance) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base/isis="+instance+"/segment-routing/adjacency-set?fields=id";
        return this.getSuggestData(neId, url, "nokia-conf:adjacency-set", "id");
    }

    this.getKeychains = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/system/security/keychains/keychain?fields=keychain-name";
        return this.getSuggestData(neId, url, "nokia-conf:keychain", "keychain-name");
    }

    this.getSuggestData = function (neId, url, initialProperty, propertyName) {
        var mdcFwk = new MdcFwk();
        logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, propertyName);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info("MDC resultFetch =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"][initialProperty];
        logger.info("finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                logger.info("Device " + propertyName + " Data = {}", finalResponse[index][propertyName]);
                ret.push(finalResponse[index][propertyName]);
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info("ret = \n" + JSON.stringify(ret));
        return ret;
    }
}
