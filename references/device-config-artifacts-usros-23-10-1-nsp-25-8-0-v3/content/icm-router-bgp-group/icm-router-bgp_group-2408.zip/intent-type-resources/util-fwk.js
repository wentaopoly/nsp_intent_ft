load({script: resourceProvider.getResource('ipv6-address-util.js'), name: 'IPv6AddressUtil'});
function utilities()
{
  this.setErrorResult = function (result)
  {
    result.setSuccess(false);
    result.setErrorCode(100);
    result.setErrorDetail("failed To set Topology.");
    return result;
  };

  this.setSuccessResult = function (result, savedTopology)
  {
    result.setSuccess(true);
    if (savedTopology !== undefined)
    {
      result.setTopology(savedTopology);
    }
    return result;
  };

  this.xml2object = function (xmlElement)
  {
    var lXml = Java.type("org.json.XML");
    var lsImpl = xmlElement
        .getOwnerDocument()
        .getImplementation()
        .getFeature("LS", "3.0");
    var serializer = lsImpl.createLSSerializer();
    serializer.getDomConfig().setParameter("xml-declaration", false);
    var str = serializer.writeToString(xmlElement);
    var json = lXml.toJSONObject(str).toString();
    return JSON.parse(json);
  };

  this.extractInfo = function (topology, key, i)
  {
    var values;
    if (topology != null && topology.getXtraInfo() != null)
    {
      topology.getXtraInfo().forEach(function (extraInfo)
      {
        if (extraInfo.getKey() == key)
        {
          var value = extraInfo.getValue();
          values = value.split(",");
        }
      });
    }

    if (values === undefined) return values;
    else return values[i];
  };

  this.reportMisaligned = function (target, result, auditReport, objectPropMap)
  {
    var report = JSON.parse(result.response);
    if (!report.aligned)
    {
      var inheritedPropertiesHandled = [];
      var inheritedPropertiesNotHandled = [];
      for (var i = 0; i < report.misalignedAttributes.length; i++)
      {
        var attributeData = report.misalignedAttributes[i];
        if (attributeData.expected == "present")
        {
          //misaligned object
          var objectDn = attributeData.name;
          var misalignedObject = auditFactory.createMisAlignedObject(objectDn, false);
          auditReport.addMisAlignedObject(misalignedObject);
        } else if (attributeData.expected == "not present")
        {
          //undesired object
          var objectDn = attributeData.name;
          var misalignedObject = auditFactory.createMisAlignedObject(objectDn, true);
          auditReport.addMisAlignedObject(misalignedObject);
        } else
        {
          if((attributeData.name).contains("inheritanceMask"))
          {
            var expectedData = (attributeData.expected).toString();
            var inheritanceBits = expectedData.split(",")
            var actualData = (attributeData.actual).toString();
            var objectName = attributeData.name.replace("|inheritanceMask", "");

            var objectData = objectPropMap[objectName];
            for(var index in inheritanceBits)
            {
              if(!actualData.contains(inheritanceBits[index]) && inheritanceBits[index] != "family" && inheritanceBits[index] != "administrativeState")
              {
                var misalignedAttribute
                if(inheritanceBits[index] == "disableClientReflect" || inheritanceBits[index] == "disable4ByteASN" || inheritanceBits[index] == "disableCapabilityNegotiation")
                {
                  misalignedAttribute = auditFactory.createMisAlignedAttribute(objectName+"|"+inheritanceBits[index], (objectData[inheritanceBits[index]] == false), objectData[inheritanceBits[index]] == true? true:false, target);
                }
                else
                {
                  misalignedAttribute = auditFactory.createMisAlignedAttribute(objectName+"|"+inheritanceBits[index], objectData[inheritanceBits[index]], objectData[inheritanceBits[index]] == true? false:"", target);
                }
                auditReport.addMisAlignedAttribute(misalignedAttribute);
                inheritedPropertiesHandled.push(objectName+"|"+inheritanceBits[index]);
              }
              else if(!actualData.contains(inheritanceBits[index]) && inheritanceBits[index] == "family")
              {
                var misalignedAttribute = auditFactory.createMisAlignedAttribute(objectName+"|"+inheritanceBits[index], objectData[inheritanceBits[index]], [], target);
                auditReport.addMisAlignedAttribute(misalignedAttribute);
                inheritedPropertiesHandled.push(objectName+"|"+inheritanceBits[index])
              }
            }
            if(expectedData.contains("administrativeState") && !actualData.contains("administrativeState"))
            {
              var misalignedAttribute = auditFactory.createMisAlignedAttribute(objectName+"|administrativeState", "disable", "enable");
              auditReport.addMisAlignedAttribute(misalignedAttribute);
              inheritedPropertiesHandled.push(objectName+"|administrativeState");
            }
            else if(!expectedData.contains("administrativeState") && actualData.contains("administrativeState"))
            {
              var misalignedAttribute = auditFactory.createMisAlignedAttribute(objectName+"|administrativeState", "enable", "disable");
              auditReport.addMisAlignedAttribute(misalignedAttribute);
              inheritedPropertiesHandled.push(objectName+"|administrativeState");
            }
            inheritedPropertiesHandled.push(attributeData.name);
          }
          else
          {
            inheritedPropertiesNotHandled.push(attributeData);
          }
        }
      }
      for (var index in inheritedPropertiesNotHandled)
      {
        var handledInheritanceProperties = inheritedPropertiesHandled.toString()
        if(!handledInheritanceProperties.contains(inheritedPropertiesNotHandled[index].name))
        {
          var attributeFields = (inheritedPropertiesNotHandled[index].name).split("|");
          if (attributeFields.length == 3 && attributeFields[2] == "type")
          {
            inheritedPropertiesNotHandled[index].expected = this.transformIntentFilterType(inheritedPropertiesNotHandled[index].expected);
            inheritedPropertiesNotHandled[index].actual = this.transformIntentFilterType(inheritedPropertiesNotHandled[index].actual);
          }

          if((inheritedPropertiesNotHandled[index].name).endsWith("|family"))
          {
            if(this.arraysAreEqual(inheritedPropertiesNotHandled[index].expected, inheritedPropertiesNotHandled[index].actual))
            {
              continue;
            }
          }
          var misalignedAttribute = auditFactory.createMisAlignedAttribute(inheritedPropertiesNotHandled[index].name, inheritedPropertiesNotHandled[index].expected, inheritedPropertiesNotHandled[index].actual, target);
          auditReport.addMisAlignedAttribute(misalignedAttribute);
        }
      }
    }
    return auditReport
  }
  this.editPayload = function (fdn, properties, childProperties, fullClassName, objectFullName) {
    var payload = {};
    var configInfo = {};
    configInfo[fullClassName] = properties;
    configInfo[fullClassName]["children-Set"] = childProperties;
    payload["distinguishedName"] = fdn;
    payload["objectFullName"] = objectFullName;
    payload["clearOnDeployFailure"] = true;
    payload["configInfo"] = configInfo;
    return payload;
  }
  this.transformBGPAdminState = function(adminState){
    var nfmpAdminState="";
    switch (adminState)
    {
      case "enable":nfmpAdminState="bgpUp";
        break;

      default:nfmpAdminState="bgpDown";
    }
    return nfmpAdminState;
  }

  this.transformIntentBGPAdminState = function(adminState){
    var intentAdminState="";
    switch (adminState)
    {
      case "bgpUp":intentAdminState="enable";
        break;
      case "bgpDown":intentAdminState="disable";
        break;
      default:intentAdminState=undefined;
    }
    return intentAdminState;
  }

  this.transformLoopDetect = function(loopDetect){
    var nfmpLoopDetect="";
    switch (loopDetect)
    {
      case "drop-peer":nfmpLoopDetect="drop";
        break;
      case "discard-route":nfmpLoopDetect="discardRoute";
        break;
      case "off":nfmpLoopDetect="off";
        break;
      default:nfmpLoopDetect="ignore";
    }
    return nfmpLoopDetect;
  }

  this.transformIntentLoopDetect = function(loopDetect){
    var intentLoopDetect="";
    switch (loopDetect)
    {
      case "drop":intentLoopDetect="drop-peer";
        break;
      case "discardRoute":intentLoopDetect="discard-route";
        break;
      case "off":intentLoopDetect="off";
        break;
      case "ignore":intentLoopDetect="ignore-loop";
        break;
      default:intentLoopDetect=undefined;
    }
    return intentLoopDetect;
  }

  this.getNfmpFamilyName = function(intentFamilyName){
    var nfmpFamilyName="";
    switch (intentFamilyName)
    {
      case "ipv4":nfmpFamilyName="ipv4";
        break;
      case "ipv6":nfmpFamilyName="ipv6";
        break;
      case "vpn-ipv4":nfmpFamilyName="vpnIpv4";
        break;
      case "mcast-ipv4":nfmpFamilyName="mcastIpv4";
        break;
      case "vpn-ipv6":nfmpFamilyName="vpnIpv6";
        break;
      case "l2-vpn":nfmpFamilyName="l2Vpn";
        break;
      case "mvpn-ipv4":nfmpFamilyName="mvpnIpv4";
        break;
      case "mdt-safi":nfmpFamilyName="mdtSafi";
        break;
      case "ms-pw":nfmpFamilyName="mspw";
        break;
      case "flow-ipv4":nfmpFamilyName="flowIpv4";
        break;
      case "route-target":nfmpFamilyName="routeTarget";
        break;
      case "mcast-vpn-ipv4":nfmpFamilyName="mcastVpnIpv4";
        break;
      case "mvpn-ipv6":nfmpFamilyName="mvpnIpv6";
        break;
      case "flow-ipv6":nfmpFamilyName="flowIpv6";
        break;
      case "evpn":nfmpFamilyName="evpn";
        break;
      case "mcast-ipv6":nfmpFamilyName="mcastIpv6";
        break;
      case "label-ipv4":nfmpFamilyName="labelIpv4";
        break;
      case "label-ipv6":nfmpFamilyName="labelIpv6";
        break;
      case "bgp-ls":nfmpFamilyName="bgpLs";
        break;
      case "mcast-vpn-ipv6":nfmpFamilyName="mcastVpnIpv6";
        break;
      case "sr-policy-ipv4":nfmpFamilyName="srplcyIpv4";
        break;
      case "sr-policy-ipv6":nfmpFamilyName="srplcyIpv6";
        break;
      case "flow-vpn-ipv4":nfmpFamilyName = "flowVpnIpv4";
        break;
      case "flow-vpn-ipv6":nfmpFamilyName = "flowVpnIpv6";
        break;

      default:nfmpFamilyName=intentFamilyName;
    }
    return nfmpFamilyName;
  }

  this.getIntentFamilyName = function(nfmpFamilyName){
    var intentFamilyName="";
    switch (nfmpFamilyName)
    {
      case "ipv4":intentFamilyName="ipv4";
        break;
      case "ipv6":intentFamilyName="ipv6";
        break;
      case "vpnIpv4":intentFamilyName="vpn-ipv4";
        break;
      case "mcastIpv4":intentFamilyName="mcast-ipv4";
        break;
      case "vpnIpv6":intentFamilyName="vpn-ipv6";
        break;
      case "l2Vpn":intentFamilyName="l2-vpn";
        break;
      case "mvpnIpv4":intentFamilyName="mvpn-ipv4";
        break;
      case "mdtSafi":intentFamilyName="mdt-safi";
        break;
      case "mspw":intentFamilyName="ms-pw";
        break;
      case "flowIpv4":intentFamilyName="flow-ipv4";
        break;
      case "routeTarget":intentFamilyName="route-target";
        break;
      case "mcastVpnIpv4":intentFamilyName="mcast-vpn-ipv4";
        break;
      case "mvpnIpv6":intentFamilyName="mvpn-ipv6";
        break;
      case "flowIpv6":intentFamilyName="flow-ipv6";
        break;
      case "evpn":intentFamilyName="evpn";
        break;
      case "mcastIpv6":intentFamilyName="mcast-ipv6";
        break;
      case "labelIpv4":intentFamilyName="label-ipv4";
        break;
      case "labelIpv6":intentFamilyName="label-ipv6";
        break;
      case "bgpLs":intentFamilyName="bgp-ls";
        break;
      case "mcastVpnIpv6":intentFamilyName="mcast-vpn-ipv6";
        break;
      case "srplcyIpv4":intentFamilyName="sr-policy-ipv4";
        break;
      case "srplcyIpv6":intentFamilyName="sr-policy-ipv6";
        break;
      case "flowVpnIpv4":intentFamilyName = "flow-vpn-ipv4";
        break;
      case "flowVpnIpv6":intentFamilyName = "flow-vpn-ipv6";
        break;
      default:intentFamilyName=nfmpFamilyName;
    }
    return intentFamilyName;
  }

  this.getIntentPrefixFamilyName = function (nfmpPrefixFamilyName)
  {
    var intentPrefixFamilyName = "";
    switch (nfmpPrefixFamilyName)
    {
      case "ipv4":
        intentPrefixFamilyName = "ipv4";
        break;
      case "ipv6":
        intentPrefixFamilyName = "ipv6";
        break;
      case "vpnIpv4":
        intentPrefixFamilyName = "vpn-ipv4";
        break;
      case "mcastIpv4":
        intentPrefixFamilyName = "mcast-ipv4";
        break;
      case "vpnIpv6":
        intentPrefixFamilyName = "vpn-ipv6";
        break;
      case "l2vpn":
        intentPrefixFamilyName = "l2-vpn";
        break;
      case "mvpnIpv4":
        intentPrefixFamilyName = "mvpn-ipv4";
        break;
      case "mdtSafi":
        intentPrefixFamilyName = "mdt-safi";
        break;
      case "mspw":
        intentPrefixFamilyName = "ms-pw";
        break;
      case "flowIpv4":
        intentPrefixFamilyName = "flow-ipv4";
        break;
      case "routeTarget":
        intentPrefixFamilyName = "route-target";
        break;
      case "mcastVpnIpv4":
        intentPrefixFamilyName = "mcast-vpn-ipv4";
        break;
      case "mvpnIpv6":
        intentPrefixFamilyName = "mvpn-ipv6";
        break;
      case "flowIpv6":
        intentPrefixFamilyName = "flow-ipv6";
        break;
      case "evpn":
        intentPrefixFamilyName = "evpn";
        break;
      case "mcastIpv6":
        intentPrefixFamilyName = "mcast-ipv6";
        break;
      case "labelIpv4":
        intentPrefixFamilyName = "label-ipv4";
        break;
      case "labelIpv6":
        intentPrefixFamilyName = "label-ipv6";
        break;
      case "bgpLs":
        intentPrefixFamilyName = "bgp-ls";
        break;
      case "mcastVpnIpv6":
        intentPrefixFamilyName = "mcast-vpn-ipv6";
        break;
      case "srplcyIpv4":
        intentPrefixFamilyName = "sr-policy-ipv4";
        break;
      case "srplcyIpv6":
        intentPrefixFamilyName = "sr-policy-ipv6";
        break;
      case "flowVpnIpv4":
        intentPrefixFamilyName = "flow-vpn-ipv4";
        break;
      case "flowVpnIpv6":
        intentPrefixFamilyName = "flow-vpn-ipv6";
        break;
      default:
        intentPrefixFamilyName = nfmpPrefixFamilyName;
    }
    return intentPrefixFamilyName;
  }

  this.getNfmpPrefixFamilyName = function (intentFamilyName)
  {
    var nfmpPrefixFamilyName = "";
    switch (intentFamilyName)
    {
      case "ipv4":
        nfmpPrefixFamilyName = "ipv4";
        break;
      case "ipv6":
        nfmpPrefixFamilyName = "ipv6";
        break;
      case "vpn-ipv4":
        nfmpPrefixFamilyName = "vpnIpv4";
        break;
      case "mcast-ipv4":
        nfmpPrefixFamilyName = "mcastIpv4";
        break;
      case "vpn-ipv6":
        nfmpPrefixFamilyName = "vpnIpv6";
        break;
      case "l2-vpn":
        nfmpPrefixFamilyName = "l2vpn";
        break;
      case "mvpn-ipv4":
        nfmpPrefixFamilyName = "mvpnIpv4";
        break;
      case "mdt-safi":
        nfmpPrefixFamilyName = "mdtSafi";
        break;
      case "ms-pw":
        nfmpPrefixFamilyName = "mspw";
        break;
      case "flow-ipv4":
        nfmpPrefixFamilyName = "flowIpv4";
        break;
      case "route-target":
        nfmpPrefixFamilyName = "routeTarget";
        break;
      case "mcast-vpn-ipv4":
        nfmpPrefixFamilyName = "mcastVpnIpv4";
        break;
      case "mvpn-ipv6":
        nfmpPrefixFamilyName = "mvpnIpv6";
        break;
      case "flow-ipv6":
        nfmpPrefixFamilyName = "flowIpv6";
        break;
      case "evpn":
        nfmpPrefixFamilyName = "evpn";
        break;
      case "mcast-ipv6":
        nfmpPrefixFamilyName = "mcastIpv6";
        break;
      case "label-ipv4":
        nfmpPrefixFamilyName = "labelIpv4";
        break;
      case "label-ipv6":
        nfmpPrefixFamilyName = "labelIpv6";
        break;
      case "bgp-ls":
        nfmpPrefixFamilyName = "bgpLs";
        break;
      case "mcast-vpn-ipv6":
        nfmpPrefixFamilyName = "mcastVpnIpv6";
        break;
      case "sr-policy-ipv4":
        nfmpPrefixFamilyName = "srplcyIpv4";
        break;
      case "sr-policy-ipv6":
        nfmpPrefixFamilyName = "srplcyIpv6";
        break;
      case "flow-vpn-ipv4":
        nfmpPrefixFamilyName = "flowVpnIpv4";
        break;
      case "flow-vpn-ipv6":
        nfmpPrefixFamilyName = "flowVpnIpv6";
        break;
      default:
        nfmpPrefixFamilyName = intentFamilyName;
    }
    return nfmpPrefixFamilyName;
  }

  this.expandIPv6Address =  function (address)
  {
    var ipv6AddressUtil = new IPv6AddressUtil();
     return ipv6AddressUtil.expandIPv6AddressForClassic(address);
  }

  this.arraysAreEqual = function(arr1, arr2) {
    if(!Array.isArray(arr1))
    {
      arr1 = [arr1];
    }
    if(!Array.isArray(arr2))
    {
      arr2 = [arr2];
    }
    // Check if the arrays have the same length
    if (arr1.length !== arr2.length) {
      return false;
    }

    // Sort the arrays
    var sortedArr1 = arr1.slice().sort();
    var sortedArr2 = arr2.slice().sort();

    // Compare the sorted arrays
    for (var i = 0; i < sortedArr1.length; i++) {
      if (sortedArr1[i] !== sortedArr2[i]) {
        return false; // Elements are different, arrays are not equal
      }
    }

    return true; // Arrays are equal
  }

  this.modifyNeIdForIpV6 = function (objectFullName, neId) {
     logger.info("modifying NeId For IpV6");
     objectFullName = objectFullName.replace(neId, neId.replaceAll(":","_"));
     return objectFullName;
  }

    this.MdIpv6ValidAddresssMaskSupport = function(input) {
        if (input === undefined) {
            return undefined;
        }
        if (input.endsWith(':') || input.endsWith('::0')) {
            input += ":";
        }
        let hex = removeLeadingTrailingZeros(input)
        if(hex.indexOf('::')!==-1){
            hex=hex.replace(/(::)0+/g, '$1').replace(/:::/g, "::")
            return hex;
        }
        const hextets = hex.split(':').filter(part => part !== ''); // Remove empty parts
        let maxZeroLength = 0;
        let longestZeroIndex = -1;
        let currentZeroLength = 0;
        for (let i = 0; i < hextets.length; i++) {
            if (hextets[i] === '0') {
                currentZeroLength++;
                if (currentZeroLength > maxZeroLength) {
                    maxZeroLength = currentZeroLength;
                    longestZeroIndex = i - maxZeroLength + 1;
                }
            } else {
                currentZeroLength = 0;
            }
        }
        if (maxZeroLength > 1) {
            hextets.splice(longestZeroIndex, maxZeroLength, '::');
        }
        if (maxZeroLength === 1) {
            const zeroIndex = hextets.indexOf('0');
            const zeroCount = hextets.filter(part => part === '0').length;
            if (zeroIndex !== -1 && zeroCount === 1 && hextets.length !== 8) {
                hextets.splice(zeroIndex, 1, '::');
            }
        }

        let result = hextets.join(':').replace(/::+/g, '::');
        return result;
    }

    function removeLeadingTrailingZeros(input) {
        const parts = input.split(':');
        for (let i = 0; i < parts.length; i++) {
            if(parts[i] == ''){
                continue
            }else{
                parts[i] = removeLeadingZeros(parts[i]);
            }

        }
        return parts.join(':');
    }

    function removeLeadingZeros(part) {
        let result = '';
        let nonZeroEncountered = false;
        for (let i = 0; i < part.length; i++) {
            if (part[i] !== '0') {
                nonZeroEncountered = true;
            }
            if (nonZeroEncountered) {
                result += part[i];
            }
        }
        return result || '0';
    }

    function ipv6ToMappedIpv4WithSuffix(address){
        // Preserve CIDR suffix if present
        let cidrSuffix = '';
        if (address.indexOf('/') !== -1) {
            var splitParts = address.split('/');
            address = splitParts[0];
            cidrSuffix = '/' + splitParts[1];
        }
        address = ipv6ToMappedIpv4(address);
        return address+cidrSuffix;
    }

    function ipv6ToMappedIpv4(ipv6)
    {
        // Extract the hex part after "::ffff:"
        let hexPart = ipv6.replace("::ffff:", "");
        hexPart = hexPart.replace("::FFFF:", "");

        // Split the remaining part into two 16-bit sections
        const parts = hexPart.split(":");
        if (parts.length !== 2) {
            return ipv6;
        }

        // Convert each 16-bit hex value into two 8-bit decimal values
        const firstTwoOctets = parseInt(parts[0], 16); // Convert first 16 bits
        const lastTwoOctets = parseInt(parts[1], 16);  // Convert last 16 bits

        // Extract individual octets
        const octet1 = (firstTwoOctets >> 8) & 0xFF;
        const octet2 = firstTwoOctets & 0xFF;
        const octet3 = (lastTwoOctets >> 8) & 0xFF;
        const octet4 = lastTwoOctets & 0xFF;

        // Construct the final "::ffff:<IPv4>" format
        return "::ffff:" + octet1 + "." + octet2 + "." + octet3 + "." + octet4;
    }

    this.expandIPv6ForMd = function(address) {
        var fullAddress = "";
        var validGroupCount = 8;

        var ipv4 = "";
        var extractIpv4 = /([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})/;
        var validateIpv4 = /((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})/;
        // look for embedded ipv4
        if (validateIpv4.test(address)) {
            var groups = address.match(extractIpv4);
            for (var i = 1; i < groups.length; i++) {
                ipv4 += ("0" + (parseInt(groups[i], 10).toString(16))).slice(-2) + (i == 2 ? ":" : "");
            }
            if(!address.startsWith("::ffff") && !address.startsWith("::FFFF"))
			{
				address = address.replace(extractIpv4, ipv4);
			}
        }
        else
        {
            if(address.startsWith("::ffff") || address.startsWith("::FFFF"))
            {
                address = ipv6ToMappedIpv4WithSuffix(address)
            }
        }

        if (address.indexOf("::") == -1) // All eight groups are present.
            fullAddress = address;
        else // Consecutive groups of zeroes have been collapsed with "::".
        {
            var sides = address.split("::");
            var groupsPresent = 0;
            for (var i = 0; i < sides.length; i++) {
                groupsPresent += sides[i].split(":").length;
            }
            fullAddress += (sides[0] ? sides[0] : 0) + ":";
            for (var i = 0; i < validGroupCount - groupsPresent; i++) {
                fullAddress += "0:";
            }
            if (sides[1]) {
                fullAddress += (sides[1].split("/")[0] ? sides[1].split("/")[0] : "0") +
                    (sides[1].split("/")[1] ? "/" + sides[1].split("/")[1] : "");
            } else {
                fullAddress += "0";
            }

        }
        fullAddress = removeLeadingZeros(fullAddress);
        return fullAddress.toLowerCase();
    }
}