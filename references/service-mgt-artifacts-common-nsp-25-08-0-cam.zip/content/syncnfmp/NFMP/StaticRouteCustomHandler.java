package com.nokia.nsp.mdt.intents.ibsf.resync.nfmp;

import com.alu.nms.common.util.StringUtil;
import com.alu.nms.common.util.mo.FDN;
import com.alu.nms.common.util.model.ModelFdn;
import com.nokia.nsp.md.resync.plugin.nfmp.NFMPPluginMdResyncProvider;
import com.nokia.nsp.md.resync.plugin.nfmp.common.NfmpUtil;
import com.nokia.nsp.md.resync.plugin.nfmp.parser.NfmpClass;
import com.nokia.nsp.md.resync.plugin.nfmp.parser.ResyncClass;
import com.nokia.nsp.md.common.IExecutionContext;
import com.nokia.nsp.md.common.IYangObject;
import com.nokia.nsp.md.common.YangObject;
import com.nokia.nsp.md.db.yang.api.ExecutionContext;
import com.nokia.nsp.md.db.yang.api.QueryParameters;
import com.nokia.nsp.md.db.yang.api.meta.IYangPath;
import com.alu.nms.common.util.event.ObjectCreationEvent;
import com.alu.nms.common.util.event.ObjectDeletionEvent;
import com.alu.nms.common.util.event.ObjectUpdateEvent;
import com.alu.nms.common.util.Pair;
import com.alu.nms.common.util.mo.MoInfo;
import com.nokia.nsp.md.resync.plugin.nfmp.common.ICustomHandler;
import com.nokia.nspos.model.domain.common.types.SourceType;
import com.nokia.nspos.persistence.yang.api.IYangDB;
import com.nokia.nspos.persistence.yang.api.SourceData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StaticRouteCustomHandler implements ICustomHandler
{
    private static final org.slf4j.Logger handleNfmpResyncLogger = org.slf4j.LoggerFactory.getLogger(StaticRouteCustomHandler.class.getName() + ".handleNfmpResync");
    private static final org.slf4j.Logger handleCreateEventLogger = org.slf4j.LoggerFactory.getLogger(StaticRouteCustomHandler.class.getName() + ".handleCreateEvent");
    private static final org.slf4j.Logger handleUpdateEventLogger = org.slf4j.LoggerFactory.getLogger(StaticRouteCustomHandler.class.getName() + ".handleUpdateEvent");
    private static final org.slf4j.Logger handleDeleteEventLogger = org.slf4j.LoggerFactory.getLogger(StaticRouteCustomHandler.class.getName() + ".handleDeleteEvent");


    public void handleNfmpResync(NfmpClass aInNfmpClass, ResyncClass aInResyncClass, Map<Pair<String, String>, MoInfo> aInProperties,
                                 String aInKeyId, NFMPPluginMdResyncProvider aInNFMPPluginMdResyncProvider)
    {
        handleNfmpResyncLogger.info("handleNfmpResync call for aInNfmpClass:{}, aInResyncClass:{}, aInKeyId: {}", aInNfmpClass.getNfmpClassName(), aInResyncClass.getClassPath(), aInKeyId);

        handleCreate(aInNFMPPluginMdResyncProvider, aInNfmpClass, aInResyncClass, aInProperties.entrySet().iterator().next().getValue().getProperties());
    }


    public void handleCreateEvent(NfmpClass aInNfmpClass, ResyncClass aInResyncClass, ObjectCreationEvent aInEvent,
                                  FDN aInFDN, NFMPPluginMdResyncProvider aInNFMPPluginMdResyncProvider)

    {
        handleCreateEventLogger.info("handleCreateEvent call for aInNfmpClass:{}, aInResyncClass:{}, aInFDN: {}", aInNfmpClass, aInResyncClass, aInFDN);
        Map<String, Object> lProps = aInEvent.getObject();
        lProps.put("fdn", aInFDN);
        if(isBaseRoutingInstance(lProps, aInFDN.getLocalPart())) {
            return;
        }
        handleCreate(aInNFMPPluginMdResyncProvider, aInNfmpClass, aInResyncClass, lProps);
    }

    public void handleUpdateEvent(NfmpClass aInNfmpClass, ResyncClass aInResyncClass, ObjectUpdateEvent aInEvent,
                                  FDN aInFDN, NFMPPluginMdResyncProvider aInNFMPPluginMdResyncProvider)

    {
        handleUpdateEventLogger.info("handleUpdateEvent call for aInNfmpClass:{}, aInResyncClass:{}, aInFDN: {}", aInNfmpClass, aInResyncClass, aInFDN);

        IYangDB yangDb = aInNFMPPluginMdResyncProvider.getiMdResyncFw().getIYangDB();
        handleNfmpResyncLogger.debug("Got these props for static route:\n{}", NfmpUtil.prettyPrintPropertyMap(aInEvent.getObject()));
        Map<String, Object> lProps = aInEvent.getObject();
        lProps.put("fdn", aInFDN);
        if(isBaseRoutingInstance(lProps, aInFDN.getLocalPart())) {
            return;
        }

        QueryParameters lQp = new QueryParameters();
        IExecutionContext lExecutionContext = new ExecutionContext(null, null, false, false, false);
        lQp.setIExecutionContext(lExecutionContext);
        lQp.setDepth(2);
        ArrayList<String> lModelFdnSources = new ArrayList<>();
        lModelFdnSources.add(NfmpUtil.getModelFdn(aInFDN));
        IYangPath lRouteTypePath = NfmpUtil.getYangPath("nsp-service:/services/nsp-service:service-layer/nsp-service:l3vpn/nsp-service:site/service-extension:l3vpn-site/static-route/route/next-hop");
        List<IYangObject> lExistingStaticRoute = NfmpUtil.findObjectsBySources(aInNFMPPluginMdResyncProvider.getiMdResyncFw().getIYangDB(), lRouteTypePath, lRouteTypePath.asString(), lModelFdnSources, lQp);

        if (lExistingStaticRoute != null && !lExistingStaticRoute.isEmpty())
        {
            handleNfmpResyncLogger.info("Found existing next-hop static-route {}", lExistingStaticRoute.get(0).getIdentifier());

            updateStaticRouteType(yangDb, lExistingStaticRoute.get(0).getIdentifier(), lProps, "nextHop");
            return;
        }

        lRouteTypePath = NfmpUtil.getYangPath("nsp-service:/services/nsp-service:service-layer/nsp-service:l3vpn/nsp-service:site/service-extension:l3vpn-site/static-route/route/indirect");
        lExistingStaticRoute = NfmpUtil.findObjectsBySources(aInNFMPPluginMdResyncProvider.getiMdResyncFw().getIYangDB(), lRouteTypePath, lRouteTypePath.asString(), lModelFdnSources, lQp);

        if (lExistingStaticRoute != null && !lExistingStaticRoute.isEmpty())
        {
            handleNfmpResyncLogger.info("Found existing indirect static-route {}", lExistingStaticRoute.get(0).getIdentifier());

            updateStaticRouteType(yangDb, lExistingStaticRoute.get(0).getIdentifier(), lProps, "indirect");
            return;
        }

        lRouteTypePath = NfmpUtil.getYangPath("nsp-service:/services/nsp-service:service-layer/nsp-service:l3vpn/nsp-service:site/service-extension:l3vpn-site/static-route/route/blackhole");
        lExistingStaticRoute = NfmpUtil.findObjectsBySources(aInNFMPPluginMdResyncProvider.getiMdResyncFw().getIYangDB(), lRouteTypePath, lRouteTypePath.asString(), lModelFdnSources, lQp);

        if (lExistingStaticRoute != null && !lExistingStaticRoute.isEmpty())
        {
            handleNfmpResyncLogger.info("Found existing blackhole static-route {}", lExistingStaticRoute.get(0).getIdentifier());

            updateStaticRouteType(yangDb, lExistingStaticRoute.get(0).getIdentifier(), lProps, "blackHole");
            return;
        }

        handleNfmpResyncLogger.error("No existing static-route found for {}...", NfmpUtil.prettyPrintPropertyMap(lProps));

    }

    public void handleDeleteEvent(NfmpClass aInNfmpClass, ResyncClass aInResyncClass, ObjectDeletionEvent aInEvent,
                                  FDN aInFDN, NFMPPluginMdResyncProvider aInNFMPPluginMdResyncProvider)

    {
        handleDeleteEventLogger.info("handleDeleteEvent call for aInNfmpClass:{}, aInResyncClass:{}, aInFDN: {}", aInNfmpClass, aInResyncClass, aInFDN);
        IYangDB yangDb = aInNFMPPluginMdResyncProvider.getiMdResyncFw().getIYangDB();
        Map<String, Object> lProps = aInEvent.getObject();
        lProps.put("fdn", aInFDN);
        if(isBaseRoutingInstance(lProps, aInFDN.getLocalPart())) {
            return;
        }

        QueryParameters lQp = new QueryParameters();
        IExecutionContext lExecutionContext = new ExecutionContext(null, null, false, false, false);
        lQp.setIExecutionContext(lExecutionContext);
        lQp.setDepth(2);
        ArrayList<String> lModelFdnSources = new ArrayList<>();
        lModelFdnSources.add(NfmpUtil.getModelFdn(aInFDN));

        IYangObject lExistingStaticRoute = null;
        IYangPath lRouteTypePath = NfmpUtil.getYangPath("nsp-service:/services/nsp-service:service-layer/nsp-service:l3vpn/nsp-service:site/service-extension:l3vpn-site/static-route/route/next-hop");
        List<IYangObject> lExistingStaticRouteList = NfmpUtil.findObjectsBySources(aInNFMPPluginMdResyncProvider.getiMdResyncFw().getIYangDB(), lRouteTypePath, lRouteTypePath.asString(), lModelFdnSources, lQp);

        if (lExistingStaticRouteList != null && !lExistingStaticRouteList.isEmpty())
        {
            lExistingStaticRoute = lExistingStaticRouteList.get(0);
        }
        else
        {

            lRouteTypePath = NfmpUtil.getYangPath("nsp-service:/services/nsp-service:service-layer/nsp-service:l3vpn/nsp-service:site/service-extension:l3vpn-site/static-route/route/indirect");
            lExistingStaticRouteList = NfmpUtil.findObjectsBySources(aInNFMPPluginMdResyncProvider.getiMdResyncFw().getIYangDB(), lRouteTypePath, lRouteTypePath.asString(), lModelFdnSources, lQp);

            if (lExistingStaticRouteList != null && !lExistingStaticRouteList.isEmpty())
            {
                lExistingStaticRoute = lExistingStaticRouteList.get(0);
            }
            else
            {

                lRouteTypePath = NfmpUtil.getYangPath("nsp-service:/services/nsp-service:service-layer/nsp-service:l3vpn/nsp-service:site/service-extension:l3vpn-site/static-route/route/blackhole");
                lExistingStaticRouteList = NfmpUtil.findObjectsBySources(aInNFMPPluginMdResyncProvider.getiMdResyncFw().getIYangDB(), lRouteTypePath, lRouteTypePath.asString(), lModelFdnSources, lQp);
                if (lExistingStaticRouteList != null && !lExistingStaticRouteList.isEmpty())
                {
                    lExistingStaticRoute = lExistingStaticRouteList.get(0);
                }
                else
                {
                    handleNfmpResyncLogger.error("No existing static-route found for {}...", NfmpUtil.prettyPrintPropertyMap(lProps));
                    return;
                }
            }
        }

        String lExistingStaticRouteId = lExistingStaticRoute.getIdentifier();
        handleNfmpResyncLogger.info("Found existing static-route {}", lExistingStaticRoute);

        QueryParameters lDeleteQp = new QueryParameters();
        ExecutionContext lDeleteExecutionContext = new ExecutionContext(null, null, false, false);
        lDeleteQp.setIExecutionContext(lDeleteExecutionContext);

        yangDb.delete(lExistingStaticRoute.getIdentifier(), lDeleteQp);
        handleNfmpResyncLogger.info("Deleted static route {}", lExistingStaticRoute.getIdentifier());

        String lParentIdenfier = lExistingStaticRouteId.substring(0, lExistingStaticRouteId.lastIndexOf('/'));
        IYangObject lParentObj = yangDb.getSingle(lParentIdenfier);
        if (!lParentObj.hasProperty((String) lParentObj.get("route-type"))) // No more routes under this parent for the route-type... delete it
        {
            yangDb.delete(lParentIdenfier, lQp);
            handleNfmpResyncLogger.info("Deleted static route {}", lParentIdenfier);
        }

    }

    private void handleCreate(NFMPPluginMdResyncProvider aInNFMPPluginMdResyncProvider, NfmpClass aInNfmpClass, ResyncClass aInResyncClass, Map<String, Object> aInProperties)
    {
        IYangDB yangDb = aInNFMPPluginMdResyncProvider.getiMdResyncFw().getIYangDB();
        handleNfmpResyncLogger.debug("Got these props for static route:\n{}", NfmpUtil.prettyPrintPropertyMap(aInProperties));

        String ll3VpnXPath = getL3VpnSite(aInResyncClass, aInProperties);
        String lExistingStaticRouteXPath = getStaticRouteXPath(aInNFMPPluginMdResyncProvider, ll3VpnXPath, aInProperties);
        IYangObject lExistingStaticRoute = getObjectFromIdentifier(aInNFMPPluginMdResyncProvider, lExistingStaticRouteXPath);

        if (lExistingStaticRoute != null)
        {
            handleNfmpResyncLogger.info("Found existing static-route {}", lExistingStaticRoute.getIdentifier());
            String lStaticRouteType = getStaticRouteRouteTypeXPath(aInNFMPPluginMdResyncProvider, lExistingStaticRouteXPath, aInProperties);
            if (getObjectFromIdentifier(aInNFMPPluginMdResyncProvider, lStaticRouteType) == null)
            {
                createStaticRouteType(yangDb, lExistingStaticRouteXPath, aInProperties);
            }
            else
            {
                handleNfmpResyncLogger.info("Found existing route type object for static-route {}", lStaticRouteType);
            }
        }
        else
        {
            handleNfmpResyncLogger.info("No existing static-route found for event");
            createEntireStaticRoute(yangDb, ll3VpnXPath, aInProperties);
        }

    }

    private String getL3VpnSite(ResyncClass aInResyncClass, Map<String, Object> aInProperties)
    {
        IYangPath lYangPath = NfmpUtil.getYangPath(aInResyncClass.getClassPath());
        IYangPath lParentYangPath = lYangPath.getLastStep().getParent().getPath();
        Map<String, IYangObject> lParentObj = new HashMap<>();
        FDN lFdn = (FDN) aInProperties.get("fdn");
        FDN lParentFdn = new FDN(lFdn.getRealm(), lFdn.getLocalPart().substring(0, lFdn.getLocalPart().lastIndexOf(":")));

        String lParentSourceFdn = NfmpUtil.getModelFdn(lParentFdn)+":routing";
        String lParentXPath = NfmpUtil.findXpathParentBySource(lParentSourceFdn, lParentYangPath, lFdn, lParentObj);
        if (StringUtil.isNullOrNotSet(lParentXPath))
        {
            handleNfmpResyncLogger.error("Failed to find parentXPath for static route {}", lFdn);
        }
        return lParentXPath;
    }

    private String getStaticRouteRouteTypeXPath(NFMPPluginMdResyncProvider aInNFMPPluginMdResyncProvider, String aInStaticRouteXPath, Map<String, Object> aInProperties)
    {
        String lNfmpRouteType = (String)aInProperties.get("type");
        if (lNfmpRouteType.equals("blackHole"))
        {
            return aInStaticRouteXPath+"/" + convertRouteTypePathEnum(lNfmpRouteType);
        }
        return aInStaticRouteXPath+"/"+convertRouteTypePathEnum(lNfmpRouteType)+"[ip-address='"+aInProperties.get("targetIpAddress")+"']";
    }

    private String getStaticRouteXPath(NFMPPluginMdResyncProvider aInNFMPPluginMdResyncProvider, String aInL3VpnSiteXPath, Map<String, Object> aInProperties)
    {
        Integer lPrefixLength = (Integer) aInProperties.get("prefixLength");
        String lIpPrefix = aInProperties.get("destination")+"/"+lPrefixLength;
        String lRoutingType = "unicast";
        return aInL3VpnSiteXPath+"/static-route/route[ip-prefix='"+lIpPrefix+"'][routing-type='"+lRoutingType+"']";
    }


    private IYangObject getObjectFromIdentifier(NFMPPluginMdResyncProvider aInNFMPPluginMdResyncProvider, String aInStaticRouteXPath)
    {
        QueryParameters lQp = new QueryParameters();
        IExecutionContext lExecutionContext = new ExecutionContext(null, null, false, false, false);
        lQp.setIExecutionContext(lExecutionContext);
        lQp.setDepth(2);
        return aInNFMPPluginMdResyncProvider.getiMdResyncFw().getIYangDB().getSingle(aInStaticRouteXPath);
    }

    private void createEntireStaticRoute(IYangDB aInYangDb, String aInParentXPath, Map<String, Object> aInProperties)
    {
        String lRouteType = (String) aInProperties.get("type");
        Integer lPrefixLength = (Integer) aInProperties.get("prefixLength");
        String lIpPrefix = aInProperties.get("destination")+"/"+lPrefixLength;
        String lRoutingType = "unicast";
        String lSiteId = (String) aInProperties.get("siteId");

        Map<String, Object> lStaticRouteProps = new HashMap<>();
        lStaticRouteProps.put("site-id", lSiteId);
        List<Map<String, Object>> lRouteList = new LinkedList<>();
        Map<String, Object> lStaticRouteRouteProps = new HashMap<>();
        lRouteList.add(lStaticRouteRouteProps);
        lStaticRouteProps.put("route", lRouteList);
        lStaticRouteProps.put("ip-prefix", lIpPrefix);
        lStaticRouteProps.put("routing-type", lRoutingType);

        addSources(lStaticRouteRouteProps, NfmpUtil.getModelFdn((FDN) aInProperties.get("fdn")));
        lStaticRouteRouteProps.put("site-id", lSiteId);
        lStaticRouteRouteProps.put("ip-prefix", lIpPrefix);
        lStaticRouteRouteProps.put("routing-type", lRoutingType);
        lStaticRouteRouteProps.put("route-type", convertRouteTypeEnum(lRouteType));

        if(convertRouteTypePathEnum(lRouteType).equals("blackhole")) {
            //blackhole is container not list
            lStaticRouteRouteProps.put(convertRouteTypePathEnum(lRouteType), populateRouteData(lRouteType, aInProperties));
        }
        else {
            List<Map<String, Object>> lStaticRoutesType = new LinkedList<>();
            lStaticRoutesType.add(populateRouteData(lRouteType, aInProperties));
            lStaticRouteRouteProps.put(convertRouteTypePathEnum(lRouteType), lStaticRoutesType);
        }

        final SourceData lSourceData = new SourceData(SourceType.other, ModelFdn.decode("fdn:app:resync"));
        QueryParameters lQp = new QueryParameters();
        ExecutionContext lExecutionContext = new ExecutionContext(null, null, false, false);
        lQp.setIExecutionContext(lExecutionContext);
        handleNfmpResyncLogger.debug("About to send to parent: {}, child {}, payload:\n {}",
                                    aInParentXPath, "static-route", NfmpUtil.prettyPrintPropertyMap(lStaticRouteProps));
        IYangObject lStaticRouteObj = aInYangDb.createChild(aInParentXPath, "static-route", new YangObject(lStaticRouteProps), lSourceData, lQp);
        handleNfmpResyncLogger.info("Created static route {}", lStaticRouteObj.getIdentifier());
    }

    private void createStaticRouteType(IYangDB aInYangDb, String aInParentXPath, Map<String, Object> aInProperties)
    {
        Map<String, Object> lStaticRouteRouteProps = new HashMap<>();
        addSources(lStaticRouteRouteProps, NfmpUtil.getModelFdn((FDN) aInProperties.get("fdn")));
        lStaticRouteRouteProps.put("site-id", aInProperties.get("siteId"));
        String lRouteType = convertRouteTypeEnum((String) aInProperties.get("type"));
        Integer lPrefixLength = (Integer) aInProperties.get("prefixLength");
        String lIpPrefix = aInProperties.get("destination")+"/"+lPrefixLength;
        lStaticRouteRouteProps.put("ip-prefix", lIpPrefix);
        lStaticRouteRouteProps.put("routing-type", "unicast");
        lStaticRouteRouteProps.put("route-type", lRouteType);

        if(convertRouteTypePathEnum(lRouteType).equals("blackhole")) {
            //blackhole is container not list
            lStaticRouteRouteProps.put(convertRouteTypePathEnum(lRouteType), populateRouteData(lRouteType, aInProperties));
        }
        else {
            List<Map<String, Object>> lStaticRoutesType = new LinkedList<>();
            lStaticRoutesType.add(populateRouteData(lRouteType, aInProperties));
            lStaticRouteRouteProps.put(convertRouteTypePathEnum(lRouteType), lStaticRoutesType);
        }

        final SourceData lSourceData = new SourceData(SourceType.other, ModelFdn.decode("fdn:app:resync"));
        QueryParameters lQp = new QueryParameters();
        ExecutionContext lExecutionContext = new ExecutionContext(null, null, false, false);
        lQp.setIExecutionContext(lExecutionContext);

        handleNfmpResyncLogger.debug("About to send to parent: {}, child {}, payload:\n {}",
                                    aInParentXPath, convertRouteTypePathEnum(lRouteType), NfmpUtil.prettyPrintPropertyMap(populateRouteData(aInProperties)));
        IYangObject lStaticRouteObj = aInYangDb.createChild(aInParentXPath, convertRouteTypePathEnum(lRouteType), new YangObject(populateRouteData(aInProperties)), lSourceData, lQp);
        handleNfmpResyncLogger.info("Created static route {}", lStaticRouteObj.getIdentifier());
    }

    private void updateStaticRouteType(IYangDB aInYangDb, String aInIdentifier, Map<String, Object> aInProperties, String aInRouteType)
    {
        Map<String, Object> lRouteTypeProps = populateRouteData(aInRouteType, aInProperties);

        final SourceData lSourceData = new SourceData(SourceType.other, ModelFdn.decode("fdn:app:resync"));
        QueryParameters lQp = new QueryParameters();
        ExecutionContext lExecutionContext = new ExecutionContext(null, null, false, false);
        lQp.setIExecutionContext(lExecutionContext);

        handleNfmpResyncLogger.debug("About to send to {}, payload:\n {}", aInIdentifier, NfmpUtil.prettyPrintPropertyMap(lRouteTypeProps));
        aInYangDb.update(aInIdentifier, new YangObject(lRouteTypeProps), lSourceData, lQp);
        handleNfmpResyncLogger.info("Updated static route {}", aInIdentifier);
    }

    private Map<String, Object> populateRouteData(Map<String, Object> aInProperties)
    {
        return populateRouteData((String)aInProperties.get("type"), aInProperties);
    }

    private Map<String, Object> populateRouteData(String aInRouteType, Map<String, Object> aInProperties)
    {
        Map<String, Object> lRouteTypeProps = new HashMap<>();
        addSources(lRouteTypeProps, NfmpUtil.getModelFdn((FDN) aInProperties.get("fdn")));
        switch (aInRouteType)
        {
            case "nextHop":
            case "indirect":
            {
                if (aInProperties.containsKey("siteId"))
                {
                    lRouteTypeProps.put("site-id", aInProperties.get("siteId"));
                }
                if (aInProperties.containsKey("targetIpAddress"))
                {
                    lRouteTypeProps.put("ip-address", aInProperties.get("targetIpAddress"));
                }
                if (aInProperties.containsKey("preference"))
                {
                    lRouteTypeProps.put("preference",  aInProperties.get("preference"));
                }
                if (aInProperties.containsKey("metric"))
                {
                    lRouteTypeProps.put("metric", aInProperties.get("metric"));
                }
                if (aInProperties.containsKey("administrativeState"))
                {
                    lRouteTypeProps.put("admin-state", convertAdminState((String) aInProperties.get("administrativeState")));
                }
                break;
            }
            case "blackHole":
            {
                if (aInProperties.containsKey("siteId"))
                {
                    lRouteTypeProps.put("site-id", aInProperties.get("siteId"));
                }
                if (aInProperties.containsKey("description"))
                {
                    lRouteTypeProps.put("description", aInProperties.get("description"));
                }
                if (aInProperties.containsKey("preference"))
                {
                    lRouteTypeProps.put("preference",  aInProperties.get("preference"));
                }
                if (aInProperties.containsKey("metric"))
                {
                    lRouteTypeProps.put("metric", aInProperties.get("metric"));
                }
                if (aInProperties.containsKey("community"))
                {
                    lRouteTypeProps.put("community", aInProperties.get("community"));
                }
                break;
            }
            default:
            {
                handleNfmpResyncLogger.warn("Static route type of {} is not supported...", aInRouteType);
            }
        }
        return lRouteTypeProps;
    }

    private String convertAdminState(String aInNfmpAdminState)
    {
        if (aInNfmpAdminState.equals("tmnxInService"))
        {
            return "unlocked";
        }
        else if (aInNfmpAdminState.equals("tmnxOutOfService"))
        {
            return "locked";
        }
        return "unknown";
    }

    private String convertRouteTypeEnum(String aInNfmpRouteType)
    {
        if (aInNfmpRouteType.equals("nextHop"))
        {
            return "next-hop";
        }
        else if (aInNfmpRouteType.equals("blackHole"))
        {
            return "black-hole";
        }
        else if (aInNfmpRouteType.equals("indirect"))
        {
            return "indirect";
        }
        return aInNfmpRouteType;
    }
    private String convertRouteTypePathEnum(String aInNfmpRouteType)
    {
        return convertRouteTypeEnum(aInNfmpRouteType).replace("black-hole","blackhole");
    }

    public static void addSources(Map<String,Object> aOutObjectMap, String aInSource)
    {
        Map<String,Object> lMetaData= (Map<String, Object>) aOutObjectMap.get("@");
        if(null == lMetaData)
        {
            lMetaData=new HashMap<>();
            aOutObjectMap.put("@",lMetaData);
        }
        List<String> lSources= (List<String>) lMetaData.get("nsp-model:sources");
        if(null == lSources)
        {
            lSources=new ArrayList<>();
            lMetaData.put("nsp-model:sources",lSources);
        }

        if (!lSources.contains(aInSource))
        {
            lSources.add(aInSource);
        }
    }

    public static List<String> extractKeysFromIdentifier(String aInIdentifier)
    {
        List<String> lMatchList = new LinkedList<>();
        Matcher regexMatcher = Pattern.compile("\\[(.*?)\\]").matcher(aInIdentifier);

        while (regexMatcher.find()) {//Finds Matching Pattern in String
            lMatchList.add(regexMatcher.group(1));//Fetching Group from String
        }
        return lMatchList;
    }

    public static Map<String, String> extractKeysFromIdentifierAsMap(String aInIdentifier)
    {
        Map<String, String> lResult = new HashMap<>();
        List<String> lMatchList = extractKeysFromIdentifier(aInIdentifier);

        for (String lKey : lMatchList)
        {
            String[] lSplit = lKey.split("=",2);
            lResult.put(lSplit[0], lSplit[1].substring(1, lSplit[1].length()-1));
        }
        return lResult;
    }

    private boolean isBaseRoutingInstance(Map<String, Object> aInProperties, String aInFdn) {
        boolean lResult = false;
        if (aInProperties.containsKey("routingInstance") && aInProperties.get("routingInstance") != null) {
            Object lRtrInstance = aInProperties.get("routingInstance");
            Long lRtrInstanceLong;
            if (lRtrInstance instanceof Integer) {
                lRtrInstanceLong = Long.valueOf((Integer) lRtrInstance);
            } else {
                lRtrInstanceLong = (Long) lRtrInstance;
            }
            if (lRtrInstanceLong.equals(1L) || lRtrInstanceLong.equals(4095L)) {
                lResult = true;
            }
        } else if (aInFdn != null) {
            Matcher regexMatcher = Pattern.compile("^network:.*:router-1:").matcher(aInFdn);
            if (regexMatcher.find()) {
                lResult = true;
            }
        }

        if (lResult) {
            handleNfmpResyncLogger.debug("Got static route on base routing instance fdn: {}", aInFdn);
        }
        return lResult;
    }
}