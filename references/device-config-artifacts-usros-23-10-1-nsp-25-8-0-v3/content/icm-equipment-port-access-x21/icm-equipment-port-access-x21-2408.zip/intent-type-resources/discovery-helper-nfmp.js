var RuntimeException = Java.type('java.lang.RuntimeException');

load({script: resourceProvider.getResource("nfmp-fwk.js"),name: "NfmpFwk"});
load({script: resourceProvider.getResource('parse-target.js'),name: 'ParseTarget'});
load({script: resourceProvider.getResource("util-fwk.js"),name: "utilities"});


function NfmpDiscoveryHelper() {

    let nfmpFwk = new NfmpFwk();
    let parseTarget = new ParseTarget();
    let util = new utilities();

    this.getDeviceConfiguration = function(target, initialPropertyName) {

        let neId = parseTarget.getNeIdFromTarget(target);
        let portId = parseTarget.getUniqueIdentifier(target);
        let searchPayLoad = this.constructSearchString(neId, portId);
        let searchResponse = nfmpFwk.find(neId, searchPayLoad);
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                throw new RuntimeException("Failed to get Port info from nfm-p for Ne " + neId + " and Port Id: " + portId);
            if(JSON.parse(searchResponse["response"]).length === 0)
                throw new RuntimeException("There is no port with Port Id:"+portId);
        }
        searchResponse = JSON.parse(searchResponse["response"]);
        return searchResponse[0];

    }

    this.extractDeviceConfig = function(defaultTargetData, deviceConfig, initialPropertyName) {
        let parsedDefaultTargetData = JSON.parse(defaultTargetData);
        let portconfig = deviceConfig['properties'];
        if (null !== portconfig) {
            this.extractPortProperties(parsedDefaultTargetData, portconfig);
        }
        let childrenConfig = deviceConfig["children"];
        if (null !== childrenConfig && childrenConfig.length !== 0) {

            let defaultSerialChannelData = parsedDefaultTargetData['port']['serialChannel'];
            if (defaultSerialChannelData !== null && defaultSerialChannelData.length !== 0) {
                let serialChannelExtractedConfig = this.extractSerialChannelProperties(defaultSerialChannelData, childrenConfig);
                parsedDefaultTargetData['port']['serialChannel']=serialChannelExtractedConfig;
            }
        }
        return parsedDefaultTargetData;
    }

    this.extractSerialChannelProperties = function(defaultSerialChannelData, childrenConfig) {
        let mappings = modelDeviceMapping.getMapping("serialChannel");
        let isSerialChannelInConfig = false;
        for (let i = 0; i < childrenConfig.length; i++) {
            let childConfig = childrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass ==='tdmequipment.SerialChannel') {
                isSerialChannelInConfig = true;
                this.traverseAndUpdateSerialChannelConfig('port.serialChannel', defaultSerialChannelData, childConfig['properties'], mappings);
                this.extractSerialChannelSpecificsProperties(defaultSerialChannelData,childConfig["children"]);
                let ds0ChannelGroupData = defaultSerialChannelData['ds0Channel-group'];
                if(ds0ChannelGroupData !== null && ds0ChannelGroupData.length !== 0) {
                    let ds0ChannelGroupArray = this.extractDs0ChannelGroupProperties(ds0ChannelGroupData,childConfig["children"]);
                    defaultSerialChannelData['ds0Channel-group'] = ds0ChannelGroupArray;
                }
            }
        }
        if(!isSerialChannelInConfig){
            return undefined;
        }

        return defaultSerialChannelData;

    }

    this.extractSerialChannelSpecificsProperties = function(defaultSerialChannelSpecificsData, serialChannelChildrenConfig) {
        let mappings = modelDeviceMapping.getMapping("serialChannelSpecifics");
        for (let i = 0; i < serialChannelChildrenConfig.length; i++) {
            let childConfig = serialChannelChildrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass ==='tdmequipment.SerialChannelSpecifics') {
                this.traverseAndUpdateSerialChannelSpecificsConfig('port.serialChannel', defaultSerialChannelSpecificsData, childConfig['properties'], mappings);
            }
        }
        return defaultSerialChannelSpecificsData;
    }

    this.extractDs0ChannelGroupProperties = function(defaultDs0ChannelGroupData,serialChannelChildrenConfig) {
        let ds0ChannelGroupArray =[];
        let ds0ChannelGroupDefaults = defaultDs0ChannelGroupData[0];
        let mappings = modelDeviceMapping.getMapping("ds0Channel-group");

        for (let i = 0; i < serialChannelChildrenConfig.length; i++) {
            let childConfig = serialChannelChildrenConfig[i];
            let childClass = childConfig['fullClassName'];
            if (childClass !== null && childClass ==='tdmequipment.DS0ChannelGroup') {
                let ds0ChannelGroupData = JSON.parse(JSON.stringify(ds0ChannelGroupDefaults));
                this.traverseAndUpdateDS0ChannelGroupConfig('port.serialChannel.ds0Channel-group', ds0ChannelGroupData, childConfig['properties'], mappings);
                ds0ChannelGroupArray.push(ds0ChannelGroupData)
            }
        }

        return ds0ChannelGroupArray;
    }

    this.extractPortProperties = function(defaultTargetData, portConfig) {
        let keys = Object.keys(defaultTargetData);
        for (let i = 0; i < keys.length; i++) {
            let targetKey = keys[i];
            let targetObj = defaultTargetData[targetKey];
            if (targetObj !== null && typeof targetObj === 'object') {
                let mappings = modelDeviceMapping.getMapping("port");
                this.traverseAndUpdatePortConfig(targetKey, targetObj, portConfig, mappings);
            }
        }
        return defaultTargetData;
    }

    this.traverseAndUpdatePortConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.serialChannel") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdatePortConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.traverseAndUpdateSerialChannelConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.serialChannel.speed" && mappedKey !== "port.serialChannel.ds0Channel-group") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateSerialChannelConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.traverseAndUpdateSerialChannelSpecificsConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];

            let mappedKey = objKey + "." + key;
            if (mappedKey !== "port.serialChannel.admin-state" && mappedKey !== "port.serialChannel.ds0Channel-group") {
                if (value != null && typeof value === 'object') {
                    this.traverseAndUpdateSerialChannelSpecificsConfig(mappedKey, value, parsedDeviceConfig, mappings);
                } else {
                    this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
                }
            }
        }
        return obj;
    }

    this.traverseAndUpdateDS0ChannelGroupConfig = function(objKey, obj, parsedDeviceConfig, mappings) {
        let keys = Object.keys(obj);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            let value = obj[key];
            let mappedKey = objKey + "." + key;
            if (value != null && typeof value === 'object') {
                this.traverseAndUpdateDS0ChannelGroupConfig(mappedKey, value, parsedDeviceConfig, mappings);
            } else {
                this.getAndUpdateFromDeviceConfig(mappings, mappedKey, key, obj, parsedDeviceConfig);
            }
        }
        return obj;
    }

    this.getAndUpdateFromDeviceConfig = function(mappings, mappedKey, targetKey, targetObj, parsedDeviceConfig) {
        // Get the key from mapping against targetKey
        // If the mapping key is not undefined, Get the value from deviceKey
        // if the value from deviceConfig against that mapping key is not n
        let nfmpKey = mappings[mappedKey];
        let deviceValue = parsedDeviceConfig[nfmpKey];

        targetObj[targetKey] = this.transformDeviceValue(mappedKey, deviceValue);
    }

    this.transformDeviceValue = function(mappedKey, deviceValue) {
        if (deviceValue !== null) {
            switch (mappedKey) {
                case "port.admin-state":
                case "port.serialChannel.admin-state":
                case "port.serialChannel.ds0Channel-group.admin-state":
                    deviceValue = this.transformAdminStateValue(deviceValue);
                    break;
                case "port.serialChannel.ds0Channel-group.encapType":
                    deviceValue = this.transformEncapTypeValue(deviceValue);
            }
            return deviceValue;
        }
    }

    this.constructSearchString = function(neId, portId) {
        let portFullName =  util.getBaseFdnForPort(neId, portId);
        let filterExpression = "siteId='" + neId + "' AND fullName='" + portFullName + "'";
        let jsonPayLoad = {
            "fullClassName": "equipment.PhysicalPort",
            "filter": {
                "filterExpression": filterExpression
            }
        };

        return jsonPayLoad;
    }

    this.transformAdminStateValue = function(deviceValue) {
        switch (deviceValue) {
            case "portInService":
                return "Up";
            case "portOutOfService":
                return 'Down';
        }
    }

    this.transformEncapTypeValue = function(deviceValue) {
        switch (deviceValue) {
            case "ipcpEncap":
                return "IPCP";
            case "frEncap":
                return 'FR';
            case "hdlcEncap":
                return 'Cisco HDLC';
            case "cemEncap":
                return 'CEM';
            case "rhdlcEncap":
                return 'HDLC';
        }
    }

}
