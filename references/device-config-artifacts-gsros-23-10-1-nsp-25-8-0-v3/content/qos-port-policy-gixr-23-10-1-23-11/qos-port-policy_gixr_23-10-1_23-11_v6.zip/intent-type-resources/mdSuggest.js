function MdSuggest() {

    this.getPolicyName = function (neId) {
        var url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/port-qos-policy";
        return this.getData(neId, url, "port-qos-policy-name", "port-qos-policy");
    }
    
    this.getSupportedAttributeDataList = function (neId, dataType) {
        var url = "";
        if (dataType === "queue_mgmt_policy") {
            url = "/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/queue-mgmt-policy";
            return this.getGlobalData(neId, url, "queue-mgmt-policy", "queue-mgmt-policy-name");
        }
    }
    
    this.getGlobalData = function (neId, url, classType, attribute) {
        var mdcFwk = new MdcFwk();
        logger.info(LOG_PREFIX + "MdSuggest QOS Port Policy --getData---neId={}, url={}, type={}, configName{}", neId, url, classType, attribute);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info(LOG_PREFIX + "MDC resultFetch QOS Port Policy =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"]["nokia-conf:" + classType];
        logger.info(LOG_PREFIX + "finalResponse = " + JSON.stringify(finalResponse));
        if (!Array.isArray(finalResponse)) {
            finalResponse = [finalResponse];
        }
        for (var index in finalResponse) {
            ret.push(finalResponse[index][attribute]);
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "ret = \n" + JSON.stringify(ret));
        return ret;
    }

    this.getData = function (neId, url, type, configName) {
        var mdcFwk = new MdcFwk();
        logger.info(LOG_PREFIX + "MdSuggest QOS Port Policy --getData---neId={}, url={}, type={}, configName{}", neId, url, type, configName);
        var ret = [];
        var resultFetch = mdcFwk.fetch(neId, url);
        logger.info("_____________________________________________________________________");
        logger.info(LOG_PREFIX + "MDC resultFetch QOS Port Policy =\n" + JSON.stringify(resultFetch));
        logger.info("_____________________________________________________________________");
        var finalResponse = resultFetch["msg"]["nokia-conf:" + configName];
        logger.info(LOG_PREFIX + "finalResponse = " + JSON.stringify(finalResponse));
        if (Array.isArray(finalResponse)) {
            for (var index in finalResponse) {
                ret.push(finalResponse[index][type]);
            }
        }
        var ret = ret.filter(function (value) {
            return value != null;
        });
        logger.info(LOG_PREFIX + "ret = \n" + JSON.stringify(ret));
        return ret;
    }
}