load({script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
function NfmpSuggest() {
    this.getPolicyName = function (neId) {
        var searchObjectJson = {
            "fullClassName": "sasqos.NQueue",
            "filter": {
                "equal": {
                    "name": "siteId",
                    "value": neId
                }
            },
            "resultFilter": {
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObjectJson, "sasqos.NQueue")
    }
    this.getData = function (searchObjectJson, className) {
        let nfmpFwk = new NfmpFwk();
        var ret = [];
        var resultFetch = nfmpFwk.post("/v3/search", searchObjectJson);
        var finalResponse = JSON.parse(resultFetch.response);
        logger.info(JSON.stringify(finalResponse));
        finalResponse = finalResponse[className];
        logger.info(JSON.stringify(finalResponse));

        if (Object.keys(finalResponse).length !== 0)
        {
            finalResponse.forEach(function (value, index, array) {
                ret.push(value["displayedName"]);
            })
        }
        logger.info("result = {}", JSON.stringify(ret));
        return ret;
    }
    this.getQueueMgmtPolicyName = function () {
        var searchObjectJson = {
            "fullClassName": "sasqos.QueueMgmtPolicy",
            "filter": {
                "and": {
                    "equal":
                        [
                            {
                                "name": "isLocal",
                                "value": 0
                            },
                            {
                                "name": "isBackup",
                                "value": 0
                            }
                        ]
                }
            },
            "resultFilter": {
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObjectJson, "sasqos.QueueMgmtPolicy")
    }
    this.getSlopePolicyName = function () {
        var searchObjectJson = {
            "fullClassName": "sasqos.SlopePolicy",
            "filter": {
                "and": {
                    "equal":
                        [
                            {
                                "name": "isLocal",
                                "value": 0
                            },
                            {
                                "name": "isBackup",
                                "value": 0
                            }
                        ]
                }
            },
            "resultFilter": {
                "attribute": [
                    "displayedName"
                ]
            }
        };
        return this.getData(searchObjectJson, "sasqos.SlopePolicy")
    }
}