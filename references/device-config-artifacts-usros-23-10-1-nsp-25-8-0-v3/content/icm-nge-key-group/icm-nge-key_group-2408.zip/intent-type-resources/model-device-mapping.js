function ModelDeviceMapping() {
    this.getKeyGroupMapping = function () {
        var mapping = {};
        mapping['key-group.key-group-name'] = 'keyGroupName';
        mapping['key-group.description'] = 'description';
        mapping['key-group.encryption-algorithm'] = 'encrypAlgorithm';
        mapping['key-group.authentication-algorithm'] = 'authAlgorithm';
        return mapping;
    }

    this.getSdpMapping = function () {
        var mapping = {};
        mapping['network-group-encryption.sdp.name'] = 'sdpFdn';
        mapping['network-group-encryption.sdp.source-id'] = 'sourceNodeId';
        mapping['network-group-encryption.sdp.destination-id'] = 'destinationNodeId';
        mapping['network-group-encryption.sdp.path-id'] = 'pathId';
        mapping['network-group-encryption.sdp.encrypt'] = 'adminEncryptionStatus';
        return mapping;
    }
}
