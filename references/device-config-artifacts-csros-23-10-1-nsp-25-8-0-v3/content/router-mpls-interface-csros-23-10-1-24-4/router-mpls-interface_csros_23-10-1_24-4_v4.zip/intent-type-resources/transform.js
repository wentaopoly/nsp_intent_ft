load({ script: resourceProvider.getResource("nfmpSuggest.js"), name: "NfmpSuggest" });
function transformData() {
   const nfmpSuggest = new NfmpSuggest();
    this.transformObjectFullNameGreenField = function (objectFullName, intentConfig, neId, isAudit, isDelete) {
      let interfaceData;
      if(intentConfig.interfaceId){
        interfaceData = nfmpSuggest.getInterfaceData(neId, intentConfig.interfaceId, "id", "displayedName");
                  objectFullName = objectFullName.replace(/interface-[^:]+/, "interface-"+interfaceData);
             }
      return objectFullName;
    }
    this.transformObjectFullNameDistribute = function (objectFullName, intentConfig, payload, neId) {
        return objectFullName;
    }
    this.transformObjectFullNameBrownField = function (objectFullName, uniqueIdentifierValues, neId) {
       let interfaceData;
     let interfaceName = uniqueIdentifierValues;
    if(interfaceName){
        interfaceData = nfmpSuggest.getInterfaceData(neId, interfaceName, "id", "displayedName");
           objectFullName = objectFullName.replace(/interface-[^:]+/, "interface-"+interfaceData);
      }
        return objectFullName;
    }
    this.transformFdnGreenField = function (fdn, intentConfig, neId, isAudit) {
        return fdn;
    }
    this.transformLocalPolicyObjectFullNameGreenField = function (localPolicyFullName, objectFullName, neId, isAudit) {
        return localPolicyFullName;
    }
this.transformPayloadGreenField = function (payload, neId, isAudit) {
    if (payload && payload.configInfo) {
        if (payload.configInfo["mpls.Interface"]) {
            let mplsSRLGPointers = payload.configInfo["mpls.Interface"]["sharedRiskLinkGroupPointers"];
            let mplsInterfaceId =  payload.configInfo["mpls.Interface"]
            //convert interfaceName to Id
             if (mplsInterfaceId) {
               let interfaceId = nfmpSuggest.getInterfaceData(neId, mplsInterfaceId.interfaceId, "id", "displayedName");
               mplsInterfaceId.interfaceId = interfaceId;
             }
            // SRLG pointers
            if (mplsSRLGPointers && Array.isArray(mplsSRLGPointers.pointer)) {
                let nfmpNameExtension = "rtrSrlgGroup:srlg-";
                
                for (let i = 0; i < mplsSRLGPointers.pointer.length; i++) {
                    if (mplsSRLGPointers.pointer[i]) {
                        let srlgPointerData = nfmpNameExtension + mplsSRLGPointers.pointer[i];
                        mplsSRLGPointers.pointer[i] = srlgPointerData;
                    }
                }
            }
        }
    }
}
    this.transformTargetValueGreenField = function (xpath, targetValue, targetKey, neId, isAudit) {
        return targetValue;
    }
    this.transformTargetValueBrownField = function (xpath, targetValue, targetKey, fullDeviceConfig, targetWithTemplate) {
	  //remove the prefix value from sharedRiskLinkGroupPointers
      if(targetKey === "sharedRiskLinkGroupPointers"){
        for (let item of targetValue) {
            // Split the pointer string by ':''
            let splitByColon = item["pointer"].split(':').pop();
            // Split the resulting string by '-' and take the last part'
            item["pointer"] = splitByColon.split('-').pop();
        }
      }
      if(xpath === "adminGroupInclude")
      {
          let neId = parseTarget.getNeIdFromTarget(targetWithTemplate);
          let result = [];
          for (let i = 0; i < 32; i++) {
              if ((targetValue & (1 << i)) !== 0) {
                  result.push(i.toString());
              }
          }
          targetValue = nfmpSuggest.getFormattedAdminGroupData(result,neId);
      }
      return targetValue;
    }
    this.transformSetListKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformMapKeyTypeGreenfield = function (xpath, keyType) {
        return keyType;
    }
    this.transformSetListKeyTypeBrownfield = function (xpath, keyType) {
        return keyType;
    }

    this.transformIntentConfig = function (intentConfig) {
            function handleAdminGroupValue(value) {
                let binary = 0;
                value.forEach(item => {
                    const match = item.match(/\((\d+)\)/);
                    if (match) {
                        const bitPosition = Number(match[1]);
                        binary |= (1 << bitPosition);
                    }
                });
                return binary.toString();
            };
            if(intentConfig && intentConfig["adminGroupInclude"]) {
                intentConfig["adminGroupInclude"] = handleAdminGroupValue(intentConfig["adminGroupInclude"]);
            }
    }
}
