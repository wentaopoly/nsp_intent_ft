function MdSuggest() {
    this.getInterfaceName = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base/interface?fields=interface-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:interface'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['interface-name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getDistCPUPortection = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/system/security/dist-cpu-protection/policy?fields=policy-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:policy'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['policy-name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getCPUPortection = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/system/security/cpu-protection/policy?fields=policy-id";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:policy'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['policy-id']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getFilterIP = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/filter/ip-filter?fields=filter-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:ip-filter'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['filter-name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getFilterIPv6 = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/filter/ipv6-filter?fields=filter-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:ipv6-filter'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['filter-name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getPolicyAccounting = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/routing-options/policy-accounting/policy-acct-template?fields=name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:policy-acct-template'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getIfAttributeAdminGroup = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/routing-options/if-attribute/admin-group?fields=group-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:admin-group'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['group-name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getIfAttributeSRLGGroup = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/routing-options/if-attribute/srlg-group?fields=name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:srlg-group'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getMeasurementTemplate = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/test-oam/link-measurement/measurement-template?fields=template-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:measurement-template'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['template-name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getPythonPolicy = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/python/python-policy?fields=name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:python-policy'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getMDAdminName = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/eth-cfm/domain?fields=md-admin-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:domain'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['md-admin-name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getMAAdminName = function(neId,mdAdminName,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/eth-cfm/domain=" + mdAdminName + "/association?fields=ma-admin-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:association'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['ma-admin-name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getLocalDHCPServer = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base/dhcp-server/dhcpv4?fields=name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:dhcpv4'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getLocalDHCP6Server = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base/dhcp-server/dhcpv6?fields=name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:dhcpv6'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getProxyNDPolicy = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/policy-options/policy-statement?fields=name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:policy-statement'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getVRRPPolicy = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/vrrp/policy?fields=policy-id";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:policy'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['policy-id']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getNetworkDomain = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/router=Base/network-domains/network-domain?fields=domain-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:network-domain'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['domain-name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getNetworkPolicy = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/network?fields=network-policy-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:network'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['network-policy-name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getOperGroup = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/service/oper-group?fields=name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:oper-group'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getEgressPortRedirectGroup = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/queue-group-templates/egress/queue-group?fields=egress-queue-group-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:queue-group'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['egress-queue-group-name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getIngressFpRedirectGroup = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/qos/queue-group-templates/ingress/queue-group?fields=ingress-queue-group-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:queue-group'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['ingress-queue-group-name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getProxyARPPolicy = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/policy-options/policy-statement?fields=name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:policy-statement'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }

   this.getLagIpMeasurementTemplate = function(neId,type) {
      const url ="/restconf/data/network-device-mgr:network-devices/network-device=" + neId + "/root/nokia-conf:/configure/test-oam/lag-ip-measurement/lag-ip-measurement-template?fields=template-name";
      const mdcFwk = new MdcFwk();
      logger.info("MdSuggest--getData---neId={}, url={}, type={}", neId, url, type);
      const resultFetch = mdcFwk.fetch(neId, url);
      const finalResponse = resultFetch.msg['nokia-conf:lag-ip-measurement-template'];
      logger.info("finalResponse = " + JSON.stringify(finalResponse));
      const ret = Array.isArray(finalResponse)? finalResponse.map(Data => Data['template-name']).filter(value => value != null):[];
      logger.info("ret =", JSON.stringify(ret));
      return ret;
   }
}
