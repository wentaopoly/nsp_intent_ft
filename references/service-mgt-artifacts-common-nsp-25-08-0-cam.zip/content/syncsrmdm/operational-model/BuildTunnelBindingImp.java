package com.nokia.nsp.mdt.intents.ibsf.resync.mdc;

//needed to get data from site object. site name and ne-service-id. Sets service-name,site-name, second node source, and cmodel source, ....

import com.alu.nms.common.util.model.ModelFdn;
import com.nokia.nsp.md.common.IExecutionContext;
import com.nokia.nsp.md.common.IYangObject;
import com.nokia.nsp.md.common.YangObject;
import com.nokia.nsp.md.db.yang.api.ExecutionContext;
import com.nokia.nsp.md.db.yang.api.QueryParameters;
import com.nokia.nsp.md.ifg.yang.api.Fields;
import com.nokia.nsp.md.resync.api.IMdResyncFw;
import com.nokia.nsp.md.resync.plugin.common.IBuildObjectFromAssociatedObject;
import com.nokia.nspos.model.domain.common.types.SourceType;
import com.nokia.nspos.persistence.impl.db.transaction.Transactor;
import com.nokia.nspos.persistence.impl.db.transaction.TxPhase;
import com.nokia.nspos.persistence.yang.api.SourceData;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.FlushModeType;

public class BuildTunnelBindingImp implements IBuildObjectFromAssociatedObject {
    private static final Logger logger = LoggerFactory.getLogger(BuildTunnelBindingImp.class.getName() + ".buildChild");
    static ThreadLocal<Map<String, Map<String, String>>> tunnelDetailsCache = new ThreadLocal<>();

    public IYangObject buildChild(Map<String, Object> aInDeviceObject, String aInNspClassId, QueryParameters aInQueryParameters, IYangObject aInParentObject, Map<String, Object> aInConvertedNspObjectFromDevice, IYangObject aInAssociatedObject, String aInNeId, IMdResyncFw aInMdResyncFw, String aInNodeType, String aInNodeVersion) {
        if (logger.isDebugEnabled()) {
            logger.debug("Service object : aInQueryParameters=" + aInQueryParameters
                    + ", aInNspClassId=" + aInNspClassId
                    + ", aInParentObject=" + aInParentObject
                    + ", aInDeviceObject=" + aInDeviceObject
                    + ", aInConvertedNspObjectFromDevice=" + aInConvertedNspObjectFromDevice
                    + ", aInAssociatedObject=" + aInAssociatedObject
                    + ", aInNeId=" + aInNeId);
        }

        IYangObject lYoCreated = createTunnelBinding(aInParentObject, aInDeviceObject, aInConvertedNspObjectFromDevice, aInAssociatedObject, aInNeId, aInMdResyncFw, aInQueryParameters);
        updateTunnelBindingsInSite(lYoCreated, aInAssociatedObject, aInMdResyncFw, aInQueryParameters);
        return lYoCreated;
    }

    private static void addSources(Object aInSources, String aInNeServiceId, String aInNeId, String aInNspIdentifer, Map<String, Object> aInTunnelBindDetails) {
        if (aInSources != null && aInSources instanceof ArrayList) {
            ArrayList lSources = (ArrayList) aInSources;
            String lFdn = null;
            for (Object lSource : lSources) { //loop sources to find one with service-name and sdp-bind-id
                if (lSource.toString().contains("service-name") && lSource.toString().contains("sdp-bind-id")) { //need to change for multi-vendor
                    lFdn = lSource.toString();
                    break;
                }
            }

            List<String> fdnsToAdd = new ArrayList<>();
            if (aInNeServiceId != null) {

                String lSvcKeyAndId = "service-id='" + aInNeServiceId + "'";
                {
                    //TODO: xpath parser
                    final String lSdpName = lFdn.substring(lFdn.lastIndexOf("[") + 1, lFdn.lastIndexOf("]"));
                    final String lBindType = (aInTunnelBindDetails != null && aInTunnelBindDetails.containsKey("tunnel-binding-type") && aInTunnelBindDetails.get("tunnel-binding-type").toString().equals("mesh")) ? "mesh" : "spoke";
                    //TODO: Verify if cmodel fdn should be mesh for mesh sdps?
                    String lMdmAmiModelObj = "fdn:app:mdm-ami-cmodel:" + aInNeId + ":service:ServiceResourceBinding:/service[" + lSvcKeyAndId + "]/" + "spoke" + "-sdp[" + lSdpName + "]";
                    fdnsToAdd.add(lMdmAmiModelObj);
                }
            }

            if (lFdn != null && lFdn.contains("state")) {
                fdnsToAdd.add(lFdn.replace("state", "configure"));
            } else if (lFdn != null && lFdn.contains("configure")) {
                fdnsToAdd.add(lFdn.replace("configure", "state"));
            } else {
                logger.error("fdn from nsp-model:sources should include state/configure. fdn=" + lFdn);
            }

            for (String fdnToAdd : fdnsToAdd) {
                if (!lSources.contains(fdnToAdd)) {
                    lSources.add(fdnToAdd);
                }
            }
        } else {
            logger.error("aInNspObject doesn't include nsp-model:sources. aInNspObject=" + aInNspIdentifer);
        }
    }


    private IYangObject createTunnelBinding(IYangObject aInParentObject, Map<String, Object> aInDeviceObject, Map<String, Object> aInNspObject, IYangObject aInAssociatedObject, String aInNeId, IMdResyncFw aInMdResyncFw, QueryParameters aInQueryParameters) {

        Map<String, Map<String, String>> lTunnelDetailsCache = tunnelDetailsCache.get();
        if (null == lTunnelDetailsCache) {
            lTunnelDetailsCache = new HashMap<>();
            tunnelDetailsCache.set(lTunnelDetailsCache);
            Transactor.getContext().addEventHandler(TxPhase.FINAL, (p, c) -> {
                tunnelDetailsCache.remove();
            });
        }

        YangObject lTunnelBindingYo = new YangObject(aInNspObject);
        String lClassId = (aInParentObject != null) ? aInParentObject.getClassId() + "/nsp-service:tunnel-binding" : null;
        lTunnelBindingYo.setClassId(lClassId);

        Map<String, Object> lTunnelBindingDetailsIn = null;
        if (aInNspObject.containsKey("tunnel-binding-details") && aInNspObject.get("tunnel-binding-details") != null &&
                ((List<Map>) aInNspObject.get("tunnel-binding-details")).size() > 0 && ((List<Map>) aInNspObject.get("tunnel-binding-details")).get(0).containsKey("tunnel-binding-type")) {
            lTunnelBindingDetailsIn = ((List<Map>) aInNspObject.get("tunnel-binding-details")).get(0);
        }

        Object lSources = lTunnelBindingYo.getExtraData("sources");
        String lNeServiceId = null;
        if (aInAssociatedObject.hasProperty("ipservice-site-detail") &&
                aInAssociatedObject.get("ipservice-site-detail") != null) {

            if (aInAssociatedObject.get("ipservice-site-detail") instanceof HashMap &&
                    !((HashMap) aInAssociatedObject.get("ipservice-site-detail")).isEmpty()) {
                HashMap lIpSvcSiteDetailObj = (HashMap) aInAssociatedObject.get("ipservice-site-detail");
                if (lIpSvcSiteDetailObj.containsKey("ne-service-id") && lIpSvcSiteDetailObj.get("ne-service-id") != null)
                    lNeServiceId = (String) lIpSvcSiteDetailObj.get("ne-service-id");
            } else if (aInAssociatedObject.get("ipservice-site-detail") instanceof IYangObject) {
                IYangObject lIpSvcSiteYangObj = (IYangObject) aInAssociatedObject.get("ipservice-site-detail");
                if (lIpSvcSiteYangObj.hasProperty("ne-service-id") && lIpSvcSiteYangObj.get("ne-service-id") != null)
                    lNeServiceId = (String) lIpSvcSiteYangObj.get("ne-service-id");
            }
        }
        if (lNeServiceId == null && aInParentObject != null && aInParentObject.hasProperty("ne-service-id")) {
            lNeServiceId = (String) aInParentObject.get("ne-service-id");
        }

        addSources(lSources, lNeServiceId, aInNeId, aInNspObject.toString(), lTunnelBindingDetailsIn);

        lTunnelBindingYo.setProperty("site", aInAssociatedObject.getIdentifier());
        lTunnelBindingYo.setProperty("site-name", aInAssociatedObject.getProperty("name"));

        //Build imp runs once on create
        //delete admin-state will set to unlocked in postprocessing
        if (aInDeviceObject.containsKey("_classId_") && aInDeviceObject.get("_classId_") != null && ((String) aInDeviceObject.get("_classId_")).startsWith("nokia-conf")) {
            //explicit admin-state gets set by json on conf. If not set default
            if (!(aInDeviceObject.containsKey("admin-state") && aInDeviceObject.get("admin-state") != null)) {
                lTunnelBindingYo.setProperty("admin-state", "unlocked");
            }
            //Setting oper-state will mean create kafka event doesn't need to update tunnel binding
            lTunnelBindingYo.setProperty("oper-state", "unknown");
        } else {
            //on state set admin-state to unknown
            lTunnelBindingYo.setProperty("admin-state", "unknown");
        }

        /* removing vc-type and vc-id when state event comes first (this was only need when no grpc)
        //Postprocessing not run on create without grpc and destination values empty
        if(lTunnelBindingDetailsIn==null) {
            lTunnelBindingDetailsIn=new HashMap<>();
        }

        Map<String, String> lFoundTunnelDetails;
        if (lTunnelBindingYo.hasProperty("resource") && lTunnelBindingYo.get("resource") != null) {
            final String lTunnelFdn = lTunnelBindingYo.get("resource").toString();
            final String lTunnelKey = lTunnelFdn.replaceAll(".*\\/(gre|mpls)-tunnel", "");
            lFoundTunnelDetails = lTunnelDetailsCache.get(lTunnelKey);
            if (null == lFoundTunnelDetails) {
                if (logger.isDebugEnabled()) {
                    logger.debug("cache miss tunnel details: {}", lTunnelKey);
                }

                lFoundTunnelDetails = new HashMap<>();

                QueryParameters lQueryParameters = new QueryParameters();
                lQueryParameters.setDepth(2);

                IExecutionContext executionContextSvc = new ExecutionContext(null, null, false, false, false);
                lQueryParameters.setIExecutionContext(executionContextSvc);

                lQueryParameters.setFields(Fields.parse("source-ne-id;source-ne-name;destination-ne-id;destination-ne-name"));
                IYangObject lTunnelRes = null;
                if (Transactor.isInTransaction()) {
                    FlushModeType lPreFlushModeType = Transactor.getContext().getEntityManager().getFlushMode();
                    Transactor.getContext().getEntityManager().setFlushMode(FlushModeType.COMMIT);
                    lTunnelRes = aInMdResyncFw.getIYangDB().getSingle(lTunnelFdn, lQueryParameters);
                    if (lPreFlushModeType.equals(FlushModeType.AUTO)) {
                        Transactor.getContext().getEntityManager().setFlushMode(FlushModeType.AUTO);
                    }
                } else {
                    lTunnelRes = aInMdResyncFw.getIYangDB().getSingle(lTunnelFdn, lQueryParameters);
                }
                if (lTunnelRes != null) {
                    if (lTunnelRes.hasProperty("source-ne-id") && lTunnelRes.get("source-ne-id") != null) {
                        lFoundTunnelDetails.put("source-ne-id", lTunnelRes.get("source-ne-id").toString());
                    }
                    if (lTunnelRes.hasProperty("source-ne-name") && lTunnelRes.get("source-ne-name") != null) {
                        lFoundTunnelDetails.put("source-ne-name", lTunnelRes.get("source-ne-name").toString());
                    }
                    if (lTunnelRes.hasProperty("destination-ne-id") && lTunnelRes.get("destination-ne-id") != null) {
                        lFoundTunnelDetails.put("destination-ne-id", lTunnelRes.get("destination-ne-id").toString());
                    }
                    if (lTunnelRes.hasProperty("destination-ne-name") && lTunnelRes.get("destination-ne-name") != null) {
                        lFoundTunnelDetails.put("destination-ne-name", lTunnelRes.get("destination-ne-name").toString());
                    }
                    lTunnelDetailsCache.put(lTunnelKey, lFoundTunnelDetails);
                }
            } else {
                if (logger.isDebugEnabled()) {
                    logger.debug("cache hit tunnel details: {}", lTunnelKey);
                }
            }
        } else {
            lFoundTunnelDetails = new HashMap<>();
        }

        if (lFoundTunnelDetails.containsKey("source-ne-id") && lFoundTunnelDetails.get("source-ne-id") != null) {
            lTunnelBindingDetailsIn.put("source-ne-id", lFoundTunnelDetails.get("source-ne-id").toString());
        }
        else {
            lTunnelBindingDetailsIn.put("source-ne-id", aInNeId);
        }
        if (lFoundTunnelDetails.containsKey("source-ne-name") && lFoundTunnelDetails.get("source-ne-name") != null) {
            lTunnelBindingDetailsIn.put("source-ne-name", lFoundTunnelDetails.get("source-ne-name").toString());
        }
        if (lFoundTunnelDetails.containsKey("destination-ne-id") && lFoundTunnelDetails.get("destination-ne-id") != null) {
            lTunnelBindingDetailsIn.put("destination-ne-id", lFoundTunnelDetails.get("destination-ne-id").toString());
        }
        if (lFoundTunnelDetails.containsKey("destination-ne-name") && lFoundTunnelDetails.get("destination-ne-name") != null) {
            lTunnelBindingDetailsIn.put("destination-ne-name", lFoundTunnelDetails.get("destination-ne-name").toString());
        }
        ArrayList lTunnelBindingDetailsArr = new ArrayList();
        lTunnelBindingDetailsArr.add(lTunnelBindingDetailsIn);
        lTunnelBindingYo.setProperty("tunnel-binding-details", lTunnelBindingDetailsArr);*/


        if (aInParentObject != null) {
            lTunnelBindingYo.setProperty("service", aInParentObject.getIdentifier());
            lTunnelBindingYo.setProperty("service-name", aInParentObject.getProperty("name"));

            final SourceData sourceData = new SourceData(SourceType.other, ModelFdn.decode("fdn:app:resync"));

            String lServiceExtensionTnlBind = getSvcExtensionTunnelBinding(lTunnelBindingYo.getClassId());
            if(lServiceExtensionTnlBind != null){
                HashMap lTnlBindExtensionMap = (lTunnelBindingYo.hasProperty(lServiceExtensionTnlBind)) ? lTunnelBindingYo.getProperty(lServiceExtensionTnlBind) : new HashMap();
                lTunnelBindingYo.setProperty(lServiceExtensionTnlBind,lTnlBindExtensionMap );
            }

            aInQueryParameters.setParentId(((YangObject) aInParentObject).getExtraData());
            aInQueryParameters.getIExecutionContext().addExtraParameter("return-light-data", true);
            aInQueryParameters.getIExecutionContext().addExtraParameter("db-id:" + aInParentObject.getIdentifier(), ((YangObject) aInParentObject).getExtraData());
            aInQueryParameters.getIExecutionContext().addExtraParameter("db-id:" + aInAssociatedObject.getIdentifier(), ((YangObject) aInAssociatedObject).getExtraData());
            IYangObject lYoCreated = aInMdResyncFw.getIYangDB().createChild(aInParentObject.getIdentifier(), "tunnel-binding", lTunnelBindingYo, sourceData, aInQueryParameters);
            aInQueryParameters.setParentId(null);
            aInQueryParameters.getIExecutionContext().extraFlags().remove("return-light-data");
            return lYoCreated;
        }
        return null;
    }

    private String getSvcExtensionTunnelBinding(String aInClassId){
        if(aInClassId.contains("eline"))
            return "service-extension:eline-tunnel-binding";
        else if (aInClassId.contains("elan"))
            return "service-extension:elan-tunnel-binding";
        else if (aInClassId.contains("l3vpn"))
            return "service-extension:l3vpn-tunnel-binding";
        else if (aInClassId.contains("ies"))
            return "service-extension:ies-tunnel-binding";
        return null;
    }

    private void updateTunnelBindingsInSite(IYangObject aInTunnelBinding, IYangObject aInAssociatedObject, IMdResyncFw aInMdResyncFw, QueryParameters aInQueryParameters) {
        ArrayList lTunnelBindings = new ArrayList<>();
        lTunnelBindings.add(aInTunnelBinding.getIdentifier());
        Object lEndpointObj = aInAssociatedObject.getProperty("tunnel-binding");
        if (lEndpointObj != null && lEndpointObj instanceof ArrayList) {
            lTunnelBindings.addAll(((ArrayList) lEndpointObj));
        }
        IYangObject lSiteUpdateYo = new YangObject();
        lSiteUpdateYo.setProperty("tunnel-binding", lTunnelBindings);
        aInMdResyncFw.getIYangDB().update(aInAssociatedObject.getIdentifier(), lSiteUpdateYo, aInQueryParameters);
    }
}