var RuntimeException = Java.type('java.lang.RuntimeException');
load({ script: resourceProvider.getResource("nfmp-fwk.js"), name: "NfmpFwk"});
load({ script: resourceProvider.getResource("util-fwk.js"), name: "utilities"});
load({ script: resourceProvider.getResource('map-fwk.js'), name: 'MapFwk'});
load({ script: resourceProvider.getResource('parse-target.js'), name: 'ParseTarget'});
load({script: resourceProvider.getResource('nfmpSuggest.js'), name: 'NfmpSuggest'})

function NfmpIPv6Filter() {

    var util = new utilities();
    var parseTarget =  new ParseTarget();
    var mapFwk = new MapFwk();
    let nfmpFwk = new NfmpFwk();
    var nfmpSuggest = new NfmpSuggest();
    var savedObjects;
    var currentObjects;
    var isAudit = false;
    var isLocalExists = false;
    var isGlobalExists = false;

    this.synchronize = function(input, result,intentTypeName,parentXpath,initialPropertyName,uniqueIdentifier)
    {
        // code to handle delete
        if (input.getNetworkState().name() === "delete")
        {
            return this.syncDelete(input,result);
        }

        var savedTopology = input.getCurrentTopology();
        logger.info(savedTopology);
        savedObjects = {};
        currentObjects = {};
        isAudit = false;
        //loading the saved objects from topology
        this.loadSavedObjectsFromTopology(savedTopology);

        var target = parseTarget.getNeIdFromTarget(input.getTarget());
        var filterId = util.getIpFilterId(input.getTarget());
        var intentConfig = this.xml2object(input.getIntentConfiguration())['configuration'][intentTypeName][initialPropertyName];
        //intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        if(!intentConfig)
        {
            intentConfig = Object.create({});
        }
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(input.getTarget());
        intentConfig["id"] = parseInt(filterId);

        logger.info("Configuration to be pushed = "+JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target IPv6-Filter = " + intentConfig[uniqueIdentifier]);

        this.createOrModify(target,intentConfig);
        var currentTopo = this.loadCurrentObjectsToTopology(target);

        result = util.setSuccessResult(result,currentTopo);
        return result;
    }

    this.audit = function (target, config, svcTopo, adminState, auditReport,intentTypeName,xpath,initialPropertyName,uniqueIdentifier) {

        var savedTopology = svcTopo;
        savedObjects = {};
        currentObjects = {};
        isAudit = true;
        var filterId = util.getIpFilterId(target);
        var intentConfig = this.xml2object(config)['configuration'][intentTypeName][initialPropertyName];
        //intentConfig = this.removeEmptyContainers("",intentConfig,"",target);
        if(!intentConfig)
        {
            intentConfig = Object.create({});
        }
        intentConfig[uniqueIdentifier] = parseTarget.getUniqueIdentifier(target);
        intentConfig["id"] = parseInt(filterId);
        var neId = parseTarget.getNeIdFromTarget(target);
        logger.info("auditing configuration = "+JSON.stringify(intentConfig));
        logger.info("Target device = " + target);
        logger.info("Target ipv6-filter = " + intentConfig[uniqueIdentifier]);

        if(intentConfig){
            this.auditAndCompare(neId,intentConfig,auditReport);
        }else{
            throw "configuration not available in the intent";
        }

        return auditReport
    }

    this.auditAndCompare = function(target,intentConfig,auditReport){

        var ipv6FilterPayload = this.createFilterLevelPayLoad(target,intentConfig, true);
        var result = this.auditRequest(target, ipv6FilterPayload);
        auditReport = util.reportMisaligned(target, result,auditReport);
        return auditReport;
    }

    this.createOrModify= function(target,intentConfig)
    {
        var fullClassName = "aclfilter.Ipv6Filter";
        var filterFdn = "IPv6 Filter";
        var objectFullName = filterFdn+":" + intentConfig["id"];
        var localFilterFullName = "network:"+target+":"+objectFullName;
        localFilterFullName = util.modifyNeIdForIpV6(localFilterFullName, target);
        var localFilter = util.getIfObjectExists(fullClassName, localFilterFullName);
        var result;
        var ipFilterPayload;
        var distributeResult

        if(localFilter != null)
        {
            isLocalExists = true;
            isGlobalExists = true;
            if(localFilter[0]["filterName"] !== intentConfig[uniqueIdentifier])
            {
                throw new RuntimeException("Already there exists a filter on "+target+" with filter name "+localFilter[0]["filterName"]+ " with filter ID "+intentConfig["id"]);
            }
            ipFilterPayload = this.createFilterLevelPayLoad(target,intentConfig,isLocalExists);

            result = this.modifyRequest(target, ipFilterPayload);
        }
        else
        {
            var globalFilter = util.getIfObjectExists("aclfilter.Ipv6Filter", objectFullName);
            if(globalFilter != null)
            {
                isGlobalExists = true;
                if(globalFilter[0]["filterName"] !== intentConfig[uniqueIdentifier])
                {
                    logger.info("[NFMP-IPV6FILTER-FWK] createOrModify(): There exists a IPv6 Filter global filter in NFMP with filter name "+globalFilter[0]["filterName"]+
                        " with same filter ID "+intentConfig["id"]+" on "+target);
                    logger.info("[NFMP-IPV6FILTER-FWK] createOrModify(): Updating IPv6 Filter global filter name to "+intentConfig[uniqueIdentifier] + "on "+target + " for filter "+ intentConfig["id"]);
                    this.updateIpFilterName(target, objectFullName, intentConfig[uniqueIdentifier]);
                }

                distributeResult = this.distributeFilter(target, intentConfig, false);

                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Filter: ' + distributeResult.msg)
                }

                // Changing SyncWithGlobal To Local Edit Only
                distributeResult = this.distributeFilter(target, intentConfig, true);

                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Filter: ' + distributeResult.msg)
                }

                ipFilterPayload = this.createFilterLevelPayLoad(target,intentConfig,true);

                result = this.modifyRequest(target, ipFilterPayload);
            }
            else
            {
                //distributing empty filter
                ipFilterPayload = this.createFilterLevelPayLoad(target,intentConfig, false);
                result = this.modifyRequest(target, ipFilterPayload);

                distributeResult = this.distributeFilter(target, intentConfig, false);
                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Filter Policy: ' + distributeResult.msg)
                }
                // Changing SyncWithGlobal To Local Edit Only
                distributeResult = this.distributeFilter(target, intentConfig, true);

                if (!distributeResult.success) {
                    throw new RuntimeException('Unable to Distribute Filter Policy: ' + distributeResult.msg)
                }

                //updating the local filter with intent configuration
                ipFilterPayload = this.createFilterLevelPayLoad(target,intentConfig,true);
                result = this.modifyRequest(target, ipFilterPayload);
            }
        }
        return result;
    }

    this.updateIpFilterName = function (target, objectFullName, filterName)
    {
        var fullClassName = "aclfilter.Ipv6Filter";
        var filterFdn = "IPv6 Filter";
        var properties = {};

        properties["filterName"] = filterName;

        var payload  = {};
        var configInfo = {};
        configInfo[fullClassName] = properties;
        payload["distinguishedName"] = filterFdn;
        payload["objectFullName"] = objectFullName;
        payload["clearOnDeployFailure"] = true;
        payload["configInfo"] = configInfo;

        var result = this.modifyRequest(target, payload);
        return result;
    }

    this.createFilterLevelPayLoad = function(target,intentConfig, isLocalExists) {

        var fullClassName = "aclfilter.Ipv6Filter";
        var filterFdn = "IPv6 Filter";
        var objectFullName = "IPv6 Filter:" + intentConfig["id"];
        var localPolicyFullName = "network:"+target+":IPv6 Filter:" + intentConfig["id"];
        localPolicyFullName = util.modifyNeIdForIpV6(localPolicyFullName, target);
        if(isLocalExists)
        {
            objectFullName = localPolicyFullName;
        }
        var properties = {};

        properties["id"] = intentConfig["id"];
        properties["filterName"] = intentConfig["filterName"];
        properties["description"] = intentConfig["description"];
        properties["defaultAction"] = util.transformNfmpDefaultAction(intentConfig["default-action"]);
        properties["scope"] = intentConfig["scope"];
        properties["type"] = util.transformNfmpFilterType(intentConfig["type"]);
        properties["chainToSystemFilter"] = intentConfig["chain-to-system-filter"];
        properties["sharedPolicer"] = intentConfig["shared-policer"];

        var childProperties = {};
        if(isLocalExists)
        {
            childProperties["aclfilter.Ipv6FilterEntry"] = [];
            if (intentConfig["entry"]){
                if(!Array.isArray(intentConfig["entry"])){
                    intentConfig["entry"] = [intentConfig["entry"]];
                }
                var Ipv6FilterEntriesPayload = [];
                for(var index in intentConfig["entry"]){
                    var intentIPFilterEntryConfig = intentConfig["entry"][index];
                    var entryObjectFullName = objectFullName+":"+"entry-"+intentIPFilterEntryConfig["entry-id"];
                    //keeping key and value same as object full name of the queue
                    mapFwk.set(currentObjects,entryObjectFullName,entryObjectFullName);
                    var entryPayload = this.createIpv6FilterEntryPayLoad(target,intentIPFilterEntryConfig);
                    logger.info("ENTRY PAYLOAD : " + JSON.stringify(entryPayload));
                    Ipv6FilterEntriesPayload.push(entryPayload);
                }
                childProperties["aclfilter.Ipv6FilterEntry"] = Ipv6FilterEntriesPayload;
            }
            childProperties["aclfilter.Ipv6FilterEmbeddedRefTable"] = [];
            childProperties["aclfilter.FlowSpecEmbeddedFilter"] = [];
            if(intentConfig["embed"])
            {
                if(intentConfig["embed"]["filter"])
                {
                    if(!Array.isArray(intentConfig["embed"]["filter"])){
                        intentConfig["embed"]["filter"] = [intentConfig["embed"]["filter"]];
                    }
                    var Ipv6FilterEmbededFilterPayload = [];
                    for(var index in intentConfig["embed"]["filter"]){
                        var intentIPv6FilterEmbededFilterConfig = intentConfig["embed"]["filter"][index];
                        var embededFilterPayload = this.createIpv6FilterEmbededFilterPayLoad(target,intentIPv6FilterEmbededFilterConfig);
                        Ipv6FilterEmbededFilterPayload.push(embededFilterPayload);
                    }
                    childProperties["aclfilter.Ipv6FilterEmbeddedRefTable"] = Ipv6FilterEmbededFilterPayload;

                }
                if(intentConfig["embed"]["flowspec"])
                {
                    if(!Array.isArray(intentConfig["embed"]["flowspec"])){
                        intentConfig["embed"]["flowspec"] = [intentConfig["embed"]["flowspec"]];
                    }
                    var Ipv6FilterEmbededFlowSpecPayload = [];
                    for(var index in intentConfig["embed"]["flowspec"]){
                        var intentIPv6FilterEmbededFlowspecConfig = intentConfig["embed"]["flowspec"][index];
                        var embededFlowspecPayload = this.createIpv6FilterEmbededFlowSpecPayLoad(target,intentIPv6FilterEmbededFlowspecConfig);
                        Ipv6FilterEmbededFlowSpecPayload.push(embededFlowspecPayload);
                    }
                    childProperties["aclfilter.FlowSpecEmbeddedFilter"] = Ipv6FilterEmbededFlowSpecPayload;
                }
                if(intentConfig["embed"]["openflow"])
                {
                    if(!Array.isArray(intentConfig["embed"]["openflow"])){
                        intentConfig["embed"]["openflow"] = [intentConfig["embed"]["openflow"]];
                    }
                    var Ipv6FilterEmbededOpenFlowPayload = [];
                    for(var index in ["embed"]["openflow"]){
                        var intentIPv6FilterEmbededOpenFlowConfig = intentConfig["embed"]["openflow"][index];
                        var embededOpenFlowPayload = this.createIpv6FilterEmbededOpenFlowPayLoad(target,intentIPv6FilterEmbededOpenFlowConfig);;
                        Ipv6FilterEmbededOpenFlowPayload.push(embededOpenFlowPayload);
                    }
                    childProperties["aclfilter.FlowSpecEmbeddedFilter"] = Ipv6FilterEmbededOpenFlowPayload;
                }
            }
        }
        var filterLevelPayload = util.editPayload(filterFdn,properties,childProperties,fullClassName,objectFullName);
        return filterLevelPayload;
    }

    this.createIpv6FilterEntryPayLoad = function(target, intentIPv6FilterEntryConfig){

        var properties = {};

        properties["id"] = intentIPv6FilterEntryConfig["entry-id"];
        properties["description"] = intentIPv6FilterEntryConfig["description"];
        properties["pbrDownActionOvr"] = util.transformNfmpPbrDownAction(intentIPv6FilterEntryConfig["pbr-down-action-override"])
        if(intentIPv6FilterEntryConfig["sticky-dest"])
        {
            if(intentIPv6FilterEntryConfig["sticky-dest"] == "no-hold-time-up")
            {
                properties["stickyDestHoldTimeUp"] = -1;
            }
            else
            {
                properties["stickyDestHoldTimeUp"] = intentIPv6FilterEntryConfig["sticky-dest"];
            }
        }
        if(intentIPv6FilterEntryConfig["log"])
        {
            properties["logId"] = parseInt(intentIPv6FilterEntryConfig["log"]);
        }
        else
        {
            properties["logId"] = 0;
        }

        if(intentIPv6FilterEntryConfig["collect-stats"])
        {
            properties["collectStats"] = intentIPv6FilterEntryConfig["collect-stats"];
        }

        if(intentIPv6FilterEntryConfig["egress-pbr"])
        {
            if(intentIPv6FilterEntryConfig["egress-pbr"] == "true")
            {
                properties["egrPBR"] = "enable";
            }
            else if(intentIPv6FilterEntryConfig["egress-pbr"] == "true-with-l4lb")
            {
                properties["egrPBR"] = "enableWithL4LB";
            }
        }
        else
        {
            properties["egrPBR"] = "disable";
        }

        if(intentIPv6FilterEntryConfig["filter-sample"])
        {
            properties["cflowdSample"] = true;
        }

        if(intentIPv6FilterEntryConfig["interface-sample"])
        {
            properties["cflowdIfSample"] = true;
        }

        if(intentIPv6FilterEntryConfig["sample-profile"])
        {
            properties["sampleProfile"] = intentIPv6FilterEntryConfig["sample-profile"];
        }

        if(intentIPv6FilterEntryConfig["match"])
        {
            if(intentIPv6FilterEntryConfig["match"]["tcp-established"])
            {
                properties["tcpEstablished"] = true;
            }

            if(intentIPv6FilterEntryConfig["match"]["tcp-flags"])
            {
                if(intentIPv6FilterEntryConfig["match"]["tcp-flags"]["ack"] != undefined)
                {
                    properties["tcpAck"] = intentIPv6FilterEntryConfig["match"]["tcp-flags"]["ack"];
                }
                if(intentIPv6FilterEntryConfig["match"]["tcp-flags"]["syn"] != undefined)
                {
                    properties["tcpSyn"] = intentIPv6FilterEntryConfig["match"]["tcp-flags"]["syn"];
                }
                if(intentIPv6FilterEntryConfig["match"]["tcp-flags"]["fin"] != undefined)
                {
                    properties["tcpFin"] = intentIPv6FilterEntryConfig["match"]["tcp-flags"]["fin"];
                }
                if(intentIPv6FilterEntryConfig["match"]["tcp-flags"]["rst"])
                {
                    properties["tcpRst"] = intentIPv6FilterEntryConfig["match"]["tcp-flags"]["rst"];
                }
                if(intentIPv6FilterEntryConfig["match"]["tcp-flags"]["psh"])
                {
                    properties["tcpPsh"] = intentIPv6FilterEntryConfig["match"]["tcp-flags"]["psh"];
                }
                if(intentIPv6FilterEntryConfig["match"]["tcp-flags"]["urg"])
                {
                    properties["tcpUrg"] = intentIPv6FilterEntryConfig["match"]["tcp-flags"]["urg"];
                }
                if(intentIPv6FilterEntryConfig["match"]["tcp-flags"]["ece"])
                {
                    properties["tcpEce"] = intentIPv6FilterEntryConfig["match"]["tcp-flags"]["ece"];
                }
                if(intentIPv6FilterEntryConfig["match"]["tcp-flags"]["cwr"])
                {
                    properties["tcpCwr"] = intentIPv6FilterEntryConfig["match"]["tcp-flags"]["cwr"];
                }
                if(intentIPv6FilterEntryConfig["match"]["tcp-flags"]["ns"])
                {
                    properties["tcpNs"] = intentIPv6FilterEntryConfig["match"]["tcp-flags"]["ns"];
                }
            }

            if(intentIPv6FilterEntryConfig["match"]["next-header"])
            {
                properties["protocol"] = util.transformNfmpProtocol(intentIPv6FilterEntryConfig["match"]["next-header"]);
                properties["protocolListPointer"] = '';
            }
            if(intentIPv6FilterEntryConfig["match"]["next-header-list"])
            {
                properties["protocol"] = "ALL";
                properties["protocolListPointer"] = 'filterProtocolList:' + intentIPv6FilterEntryConfig["match"]["next-header-list"];
            }

            if(intentIPv6FilterEntryConfig["match"]["ip"])
            {
                if(intentIPv6FilterEntryConfig["match"]["ip"]["address"])
                {
                    properties["ipAddress"] = util.expandIPv6Address((intentIPv6FilterEntryConfig["match"]["ip"]["address"]).split("/")[0]);
                    properties["ipAddressMask"] = (intentIPv6FilterEntryConfig["match"]["ip"]["address"]).split("/")[1];
                }
                if(intentIPv6FilterEntryConfig["match"]["ip"]["mask"])
                {
                    properties["ipAddressFullMask"] = util.expandIPv6Address( intentIPv6FilterEntryConfig["match"]["ip"]["mask"]);
                }
                properties["ipPrefixListPointer"] = '';

                if( intentIPv6FilterEntryConfig["match"]["ip"]["ipv6-prefix-list"])
                {
                    properties["ipAddress"] = '0:0:0:0:0:0:0:0';
                    properties["ipAddressMask"] = '0';
                    properties["ipAddressFullMask"] = '0:0:0:0:0:0:0:0';
                    properties["ipPrefixListPointer"] = 'filterPrefixList:' + intentIPv6FilterEntryConfig["match"]["ip"]["ipv6-prefix-list"]+"#type-IPv6";
                }
            }

            if(intentIPv6FilterEntryConfig["match"]["src-ip"])
            {
                if(intentIPv6FilterEntryConfig["match"]["src-ip"]["address"] || intentIPv6FilterEntryConfig["match"]["src-ip"]["mask"])
                {
                    if(intentIPv6FilterEntryConfig["match"]["src-ip"]["address"])
                    {
                        properties["sourceIpAddress"] = util.expandIPv6Address((intentIPv6FilterEntryConfig["match"]["src-ip"]["address"]).split("/")[0]);
                        properties["sourceIpAddressMask"] = (intentIPv6FilterEntryConfig["match"]["src-ip"]["address"]).split("/")[1];
                    }
                    if(intentIPv6FilterEntryConfig["match"]["src-ip"]["mask"])
                    {
                        properties["sourceIpAddressFullMask"] = util.expandIPv6Address(intentIPv6FilterEntryConfig["match"]["src-ip"]["mask"]);
                    }
                    properties["srcIpPrefixListPointer"] = '';
                }
                if(intentIPv6FilterEntryConfig["match"]["src-ip"]["ipv6-prefix-list"])
                {
                    properties["sourceIpAddress"] = '0:0:0:0:0:0:0:0';
                    properties["sourceIpAddressMask"] = '0';
                    properties["sourceIpAddressFullMask"] = '0:0:0:0:0:0:0:0';
                    properties["srcIpPrefixListPointer"] = 'filterPrefixList:' + intentIPv6FilterEntryConfig["match"]["src-ip"]["ipv6-prefix-list"]+"#type-IPv6";
                }
            }

            if(intentIPv6FilterEntryConfig["match"]["dst-ip"])
            {
                if(intentIPv6FilterEntryConfig["match"]["dst-ip"]["address"] || intentIPv6FilterEntryConfig["match"]["dst-ip"]["mask"])
                {
                    if(intentIPv6FilterEntryConfig["match"]["dst-ip"]["address"])
                    {
                        properties["destinationIpAddress"] = util.expandIPv6Address((intentIPv6FilterEntryConfig["match"]["dst-ip"]["address"]).split("/")[0]);
                        properties["destinationIpAddressMask"] = (intentIPv6FilterEntryConfig["match"]["dst-ip"]["address"]).split("/")[1];
                    }
                    if(intentIPv6FilterEntryConfig["match"]["dst-ip"]["mask"])
                    {
                        properties["destinationIpAddressFullMask"] = util.expandIPv6Address(intentIPv6FilterEntryConfig["match"]["dst-ip"]["mask"]);
                    }
                    properties["dstIpPrefixListPointer"] = '';
                }
                if(intentIPv6FilterEntryConfig["match"]["dst-ip"]["ipv6-prefix-list"])
                {
                    properties["destinationIpAddress"] = "0:0:0:0:0:0:0:0";
                    properties["destinationIpAddressMask"] = '0';
                    properties["destinationIpAddressFullMask"] = '0:0:0:0:0:0:0:0';
                    properties["dstIpPrefixListPointer"] = 'filterPrefixList:' + intentIPv6FilterEntryConfig["match"]["dst-ip"]["ipv6-prefix-list"]+"#type-IPv6";
                }
            }

            if(intentIPv6FilterEntryConfig["match"]["port"])
            {
                properties["portSelector"] = "OR_PORT";
                if(intentIPv6FilterEntryConfig["match"]["port"]["eq"])
                {
                    properties["portOperator"] = "EQUAL";
                    properties["port1"] =  intentIPv6FilterEntryConfig["match"]["port"]["eq"];
                    if(!isAudit)
                    {
                        properties["sourceOperator"] = "EQUAL";
                        properties["destinationOperator"] = "EQUAL";
                        properties["sourcePort1"] =  intentIPv6FilterEntryConfig["match"]["port"]["eq"];
                        properties["destinationPort1"] =  intentIPv6FilterEntryConfig["match"]["port"]["eq"];
                    }
                }
                else if(intentIPv6FilterEntryConfig["match"]["port"]["lt"])
                {
                    properties["portOperator"] = "LESS_THAN";
                    properties["port1"] =  intentIPv6FilterEntryConfig["match"]["port"]["lt"];
                    if(!isAudit)
                    {
                        properties["sourceOperator"] = "LESS_THAN";
                        properties["destinationOperator"] = "LESS_THAN";
                        properties["sourcePort1"] = intentIPv6FilterEntryConfig["match"]["port"]["lt"];
                        properties["destinationPort1"] = intentIPv6FilterEntryConfig["match"]["port"]["lt"];
                    }
                }
                else if(intentIPv6FilterEntryConfig["match"]["port"]["gt"])
                {
                    properties["portOperator"] = "GREATER_THAN";
                    properties["port1"] =  intentIPv6FilterEntryConfig["match"]["port"]["gt"];
                    if(!isAudit)
                    {
                        properties["sourceOperator"] = "GREATER_THAN";
                        properties["destinationOperator"] = "GREATER_THAN";
                        properties["sourcePort1"] = intentIPv6FilterEntryConfig["match"]["port"]["gt"];
                        properties["destinationPort1"] = intentIPv6FilterEntryConfig["match"]["port"]["gt"];
                    }
                }
                else if(intentIPv6FilterEntryConfig["match"]["port"]["range"])
                {
                    properties["portOperator"] = "RANGE";
                    if(!isAudit)
                    {
                        properties["sourceOperator"] = "RANGE";
                        properties["destinationOperator"] = "RANGE";
                    }
                    if(intentIPv6FilterEntryConfig["match"]["port"]["range"])
                    {
                        properties["port1"] =  intentIPv6FilterEntryConfig["match"]["port"]["range"]["start"];
                        properties["port2"] =  intentIPv6FilterEntryConfig["match"]["port"]["range"]["end"];
                        if(!isAudit)
                        {
                            properties["sourcePort1"] = intentIPv6FilterEntryConfig["match"]["port"]["range"]["start"];
                            properties["destinationPort1"] = intentIPv6FilterEntryConfig["match"]["port"]["range"]["start"];
                            properties["sourcePort2"] = intentIPv6FilterEntryConfig["match"]["port"]["range"]["end"];
                            properties["destinationPort2"] = intentIPv6FilterEntryConfig["match"]["port"]["range"]["end"];
                        }
                    }
                }
                else if(intentIPv6FilterEntryConfig["match"]["port"]["port-list"])
                {
                    properties["portListPointer"] = 'filterPortList:' + intentIPv6FilterEntryConfig["match"]["port"]["port-list"];
                    if(!isAudit)
                    {
                        properties["sourcePortListPointer"] = 'filterPortList:' + intentIPv6FilterEntryConfig["match"]["port"]["port-list"];
                        properties["destinationPortListPointer"] = 'filterPortList:' + intentIPv6FilterEntryConfig["match"]["port"]["port-list"];
                    }
                }
            }

            if(intentIPv6FilterEntryConfig["match"]["src-port"])
            {
                properties["portSelector"] = "AND_PORT";

                if(intentIPv6FilterEntryConfig["match"]["src-port"]["eq"])
                {
                    properties["sourceOperator"] = "EQUAL";
                    properties["sourcePort1"] =  intentIPv6FilterEntryConfig["match"]["src-port"]["eq"];
                }
                if(intentIPv6FilterEntryConfig["match"]["src-port"]["lt"])
                {
                    properties["sourceOperator"] = "LESS_THAN";
                    properties["sourcePort1"] =  intentIPv6FilterEntryConfig["match"]["src-port"]["lt"];
                }
                if(intentIPv6FilterEntryConfig["match"]["src-port"]["gt"])
                {
                    properties["sourceOperator"] = "GREATER_THAN";
                    properties["sourcePort1"] =  intentIPv6FilterEntryConfig["match"]["src-port"]["gt"];
                }
                if(intentIPv6FilterEntryConfig["match"]["src-port"]["range"])
                {
                    properties["sourceOperator"] = "RANGE";
                    properties["sourcePort1"] =  intentIPv6FilterEntryConfig["match"]["src-port"]["range"]["start"];
                    properties["sourcePort2"] =  intentIPv6FilterEntryConfig["match"]["src-port"]["range"]["end"];
                }
                if(intentIPv6FilterEntryConfig["match"]["src-port"]["port-list"])
                {
                    properties["sourcePortListPointer"] = 'filterPortList:' + intentIPv6FilterEntryConfig["match"]["src-port"]["port-list"];
                }
                else
                {
                    properties["sourcePortListPointer"] = "";
                }
            }
            if(intentIPv6FilterEntryConfig["match"]["dst-port"])
            {
                properties["portSelector"] = "AND_PORT";
                if(intentIPv6FilterEntryConfig["match"]["dst-port"]["eq"])
                {
                    properties["destinationOperator"] = "EQUAL";
                    properties["destinationPort1"] =  intentIPv6FilterEntryConfig["match"]["dst-port"]["eq"];
                }
                if(intentIPv6FilterEntryConfig["match"]["dst-port"]["lt"])
                {
                    properties["destinationOperator"] = "LESS_THAN";
                    properties["destinationPort1"] =  intentIPv6FilterEntryConfig["match"]["dst-port"]["lt"];
                }
                if(intentIPv6FilterEntryConfig["match"]["dst-port"]["gt"])
                {
                    properties["destinationOperator"] = "GREATER_THAN";
                    properties["destinationPort1"] =  intentIPv6FilterEntryConfig["match"]["dst-port"]["gt"];
                }
                if(intentIPv6FilterEntryConfig["match"]["dst-port"]["range"])
                {
                    properties["destinationOperator"] = "RANGE";
                    properties["destinationPort1"] =  intentIPv6FilterEntryConfig["match"]["dst-port"]["range"]["start"];
                    properties["destinationPort2"] =  intentIPv6FilterEntryConfig["match"]["dst-port"]["range"]["end"];
                }
                if(intentIPv6FilterEntryConfig["match"]["dst-port"]["port-list"])
                {
                    properties["destinationPortListPointer"] = 'filterPortList:' + intentIPv6FilterEntryConfig["match"]["dst-port"]["port-list"];
                }
                else
                {
                    properties["destinationPortListPointer"] = "";
                }
            }

            if(intentIPv6FilterEntryConfig["match"]["dscp"])
            {
                properties["dscp"] = intentIPv6FilterEntryConfig["match"]["dscp"];
            }

            if(intentIPv6FilterEntryConfig["match"]["fragment"])
            {
                if(intentIPv6FilterEntryConfig["match"]["fragment"] == "first-only")
                {
                    properties["fragment"] = "firstOnly";
                }
                else if(intentIPv6FilterEntryConfig["match"]["fragment"] == "non-first-only")
                {
                    properties["fragment"] = "nonFirstOnly";
                }
                else
                {
                    properties["fragment"] = intentIPv6FilterEntryConfig["match"]["fragment"];
                }
            }

            if(intentIPv6FilterEntryConfig["match"]["destination-class"])
            {
                properties["destIpv6Class"] = intentIPv6FilterEntryConfig["match"]["destination-class"];
            }
            if(intentIPv6FilterEntryConfig["match"]["src-mac"])
            {
                properties["sourceMacAddress"] = intentIPv6FilterEntryConfig["match"]["src-mac"]["address"];
                properties["sourceMacAddressMask"] = intentIPv6FilterEntryConfig["match"]["src-mac"]["mask"];
            }

            if(intentIPv6FilterEntryConfig["match"]["extension-header"])
            {
                if(intentIPv6FilterEntryConfig["match"]["extension-header"]["ah"])
                {
                    properties["authHeadExtHeader"] = intentIPv6FilterEntryConfig["match"]["extension-header"]["ah"];
                }
                if(intentIPv6FilterEntryConfig["match"]["extension-header"]["esp"])
                {
                    properties["encSecPayloadExtHeader"] = intentIPv6FilterEntryConfig["match"]["extension-header"]["esp"];
                }
                if(intentIPv6FilterEntryConfig["match"]["extension-header"]["hop-by-hop"])
                {
                    properties["hopByHopOpt"] = intentIPv6FilterEntryConfig["match"]["extension-header"]["hop-by-hop"];
                }
                if(intentIPv6FilterEntryConfig["match"]["extension-header"]["routing-type0"])
                {
                    properties["routingType0"] = intentIPv6FilterEntryConfig["match"]["extension-header"]["routing-type0"];
                }
            }
            if(intentIPv6FilterEntryConfig["match"]["flow-label"])
            {
                properties["flowLabel"] = intentIPv6FilterEntryConfig["match"]["flow-label"]["value"];
                properties["flowLabelMask"] = intentIPv6FilterEntryConfig["match"]["flow-label"]["mask"];
            }
            if(intentIPv6FilterEntryConfig["match"]["icmp"])
            {
                properties["icmpType"] = intentIPv6FilterEntryConfig["match"]["icmp"]["type"];
                properties["icmpCode"] = intentIPv6FilterEntryConfig["match"]["icmp"]["code"];
            }

            if(intentIPv6FilterEntryConfig["match"]["packet-length"])
            {
                if(intentIPv6FilterEntryConfig["match"]["packet-length"]["eq"])
                {
                    properties["matchPktLenOper"] = "EQUAL";
                    properties["matchPktLenVal1"] = intentIPv6FilterEntryConfig["match"]["packet-length"]["eq"];
                    properties["matchPktLenVal2"] = 0;
                }
                else if(intentIPv6FilterEntryConfig["match"]["packet-length"]["lt"])
                {
                    properties["matchPktLenOper"] = "LESS_THAN";
                    properties["matchPktLenVal1"] = intentIPv6FilterEntryConfig["match"]["packet-length"]["lt"];
                    properties["matchPktLenVal2"] = 0;
                }
                else if(intentIPv6FilterEntryConfig["match"]["packet-length"]["gt"])
                {
                    properties["matchPktLenOper"] = "GREATER_THAN";
                    properties["matchPktLenVal1"] = intentIPv6FilterEntryConfig["match"]["packet-length"]["gt"];
                    properties["matchPktLenVal2"] = 0;
                }
                else if(intentIPv6FilterEntryConfig["match"]["packet-length"]["range"])
                {
                    properties["matchPktLenOper"] = "RANGE";
                    properties["matchPktLenVal1"] = intentIPv6FilterEntryConfig["match"]["packet-length"]["range"]["start"];
                    properties["matchPktLenVal2"] = intentIPv6FilterEntryConfig["match"]["packet-length"]["range"]["end"];
                }
            }

            if(intentIPv6FilterEntryConfig["match"]["hop-limit"])
            {
                if(intentIPv6FilterEntryConfig["match"]["hop-limit"]["eq"])
                {
                    properties["matchHoplimitOper"] = "EQUAL";
                    properties["matchHoplimitVal1"] = intentIPv6FilterEntryConfig["match"]["hop-limit"]["eq"];
                    properties["matchHoplimitVal2"] = 0;
                }
                else if(intentIPv6FilterEntryConfig["match"]["hop-limit"]["lt"])
                {
                    properties["matchHoplimitOper"] = "LESS_THAN";
                    properties["matchHoplimitVal1"] = intentIPv6FilterEntryConfig["match"]["hop-limit"]["lt"];
                    properties["matchHoplimitVal2"] = 0;
                }
                else if(intentIPv6FilterEntryConfig["match"]["hop-limit"]["gt"])
                {
                    properties["matchHoplimitOper"] = "GREATER_THAN";
                    properties["matchHoplimitVal1"] = intentIPv6FilterEntryConfig["match"]["hop-limit"]["gt"];
                    properties["matchHoplimitVal2"] = 0;
                }
                else if(intentIPv6FilterEntryConfig["match"]["hop-limit"]["range"])
                {
                    properties["matchHoplimitOper"] = "RANGE";
                    properties["matchHoplimitVal1"] = intentIPv6FilterEntryConfig["match"]["hop-limit"]["range"]["start"];
                    properties["matchHoplimitVal2"] = intentIPv6FilterEntryConfig["match"]["hop-limit"]["range"]["end"];
                }
            }
        }

        if(intentIPv6FilterEntryConfig["action"])
        {
            if(intentIPv6FilterEntryConfig["action"]["fc"] !== undefined)
            {
                properties["forwardFcType"] = intentIPv6FilterEntryConfig["action"]["fc"];
                properties["forwardFC"] = true;
            }
            if(intentIPv6FilterEntryConfig["action"]["ignore-match"] !== undefined)
            {
                properties["action"] = "ignoreMatch";
            }
            if(intentIPv6FilterEntryConfig["action"]["drop"] !== undefined)
            {
                properties["action"] = "drop";
            }
            if(intentIPv6FilterEntryConfig["action"]["forward"] !== undefined)
            {
                if(intentIPv6FilterEntryConfig["action"]["forward"]["bonding-connection"])
                {
                    properties["action"] = "forwardBondingConnection";
                    properties["fwdBondingConnectionId"] = intentIPv6FilterEntryConfig["action"]["forward"]["bonding-connection"];
                }
                else if(intentIPv6FilterEntryConfig["action"]["forward"]["esi-l2"])
                {
                    properties["action"] = "forwardEsi";
                    properties["fwdEsiValue"] = intentIPv6FilterEntryConfig["action"]["forward"]["esi-l2"]["esi-value"];
                    if(intentIPv6FilterEntryConfig["action"]["forward"]["esi-l2"]["vpls"])
                    {
                        properties["fwdEsiVplsServicePointer"] = nfmpSuggest.getVPLSServicesFullName(target, intentIPv6FilterEntryConfig["action"]["forward"]["esi-l2"]["vpls"]);
                        properties["fwdEsiVprnServicePointer"] = "";
                    }
                    else {
                        properties["fwdEsiVplsServicePointer"] = "";
                    }

                }
                else if(intentIPv6FilterEntryConfig["action"]["forward"]["esi-l3"])
                {
                    properties["action"] = "forwardEsi";
                    properties["fwdEsiSfIpV6"] = util.expandIPv6Address(intentIPv6FilterEntryConfig["action"]["forward"]["esi-l3"]["sf-ip"]);
                    properties["fwdEsiValue"] = intentIPv6FilterEntryConfig["action"]["forward"]["esi-l3"]["esi-value"];
                    properties["fwdesiVasInterfaceName"] = intentIPv6FilterEntryConfig["action"]["forward"]["esi-l3"]["vas-interface"];
                    if(intentIPv6FilterEntryConfig["action"]["forward"]["esi-l3"]["vprn"])
                    {
                        properties["fwdEsiVprnServicePointer"] = nfmpSuggest.getVPRNServiceFullName(target, intentIPv6FilterEntryConfig["action"]["forward"]["esi-l3"]["vprn"]);
                        properties["fwdEsiVplsServicePointer"] = "";
                    }
                    else
                    {
                        properties["fwdEsiVprnServicePointer"] = "";
                    }
                }
                else if(intentIPv6FilterEntryConfig["action"]["forward"]["router-instance"])
                {
                    properties["action"] = "forwardRouter";
                    if(intentIPv6FilterEntryConfig["action"]["forward"]["router-instance"] == "Base")
                    {
                        properties["routerType"] = "base";
                    }
                    else
                    {
                        properties["routerType"] = "vprn";
                        properties["fwdVprnPointer"] = nfmpSuggest.getVPRNServiceFullName(target, intentIPv6FilterEntryConfig["action"]["forward"]["router-instance"]);
                    }
                }
                else if(intentIPv6FilterEntryConfig["action"]["forward"]["next-hop"] &&
                    intentIPv6FilterEntryConfig["action"]["forward"]["next-hop"]["nh-ip"])
                {
                    properties["action"] = "forward";
                    properties["nextHopIndirectlyReachable"] = intentIPv6FilterEntryConfig["action"]["forward"]["next-hop"]["nh-ip"]["indirect"];
                    properties["nextHop"] = util.expandIPv6Address(intentIPv6FilterEntryConfig["action"]["forward"]["next-hop"]["nh-ip"]["address"]);
                }
                else if(intentIPv6FilterEntryConfig["action"]["forward"]["next-hop"] &&
                    intentIPv6FilterEntryConfig["action"]["forward"]["next-hop"]["nh-ip-vrf"])
                {
                    properties["action"] = "forwardNextHopRouter";
                    properties["nextHopIndirectlyReachable"] = intentIPv6FilterEntryConfig["action"]["forward"]["next-hop"]["nh-ip-vrf"]["indirect"];
                    properties["nextHop"] = util.expandIPv6Address(intentIPv6FilterEntryConfig["action"]["forward"]["next-hop"]["nh-ip-vrf"]["address"]);
                    if(intentIPv6FilterEntryConfig["action"]["forward"]["next-hop"]["nh-ip-vrf"]["router-instance"])
                    {
                        if(intentIPv6FilterEntryConfig["action"]["forward"]["next-hop"]["nh-ip-vrf"]["router-instance"] == 'Base')
                        {
                            properties["routerType"] = "base";
                        }
                        else
                        {
                            properties["routerType"] = "vprn";
                            properties["fwdVprnPointer"] = nfmpSuggest.getVPRNServiceFullName(target, intentIPv6FilterEntryConfig["action"]["forward"]["next-hop"]["nh-ip-vrf"]["router-instance"]);
                        }
                    }

                }
                else if(intentIPv6FilterEntryConfig["action"]["forward"]["lsp"])
                {
                    properties["action"] = "forwardLsp";
                    properties["fwdLspPointer"] = nfmpSuggest.getLSPFullName(target, intentIPv6FilterEntryConfig["action"]["forward"]["lsp"]);
                }
                else if(intentIPv6FilterEntryConfig["action"]["forward"]["sdp"])
                {
                    if(intentIPv6FilterEntryConfig["action"]["forward"]["sdp"]["sdp-bind-id"])
                    {
                        properties["action"] = "forwardSdp";
                        properties["fwdSdpBindPathId"] = (intentIPv6FilterEntryConfig["action"]["forward"]["sdp"]["sdp-bind-id"]).split(":")[0];
                        properties["fwdSdpBindVcId"] = (intentIPv6FilterEntryConfig["action"]["forward"]["sdp"]["sdp-bind-id"]).split(":")[1];
                    }
                }
                else if(intentIPv6FilterEntryConfig["action"]["forward"]["sap"])
                {
                    if(intentIPv6FilterEntryConfig["action"]["forward"]["sap"]["sap-id"])
                    {
                        properties["action"] = "forwardSap";
                        var sapInfo  = (intentIPv6FilterEntryConfig["action"]["forward"]["sap"]["sap-id"]).split(":");
                        if(!Array.isArray(sapInfo))
                        {
                            sapInfo = [sapInfo];
                        }
                        properties["fwdSapPortName"] = sapInfo[0];
                        if(sapInfo.length == 2)
                        {
                            var encapValues = sapInfo[1].split(".");
                            if(!Array.isArray(encapValues))
                            {
                                encapValues = [encapValues];
                            }
                            if(encapValues.length >= 1)
                            {
                                if(encapValues[0] == "*")
                                {
                                    properties["fwdSapOuterEncapValue"] = 4095;
                                }
                                else
                                {
                                    properties["fwdSapOuterEncapValue"] = encapValues[0];
                                }
                                if(encapValues.length == 2)
                                {
                                    if(encapValues[1] == "*")
                                    {
                                        properties["fwdSapInnerEncapValue"] = 4095;
                                    }
                                    else
                                    {
                                        properties["fwdSapInnerEncapValue"] = encapValues[1];
                                    }
                                }
                            }
                        }
                    }
                }
                else if(intentIPv6FilterEntryConfig["action"]["forward"]["redirect-policy"])
                {
                    properties["action"] = "forwardRedirectFilter";
                    properties["fwdRedPlcyPointer"] = "filterRedirect:"+intentIPv6FilterEntryConfig["action"]["forward"]["redirect-policy"];
                }
                else if(intentIPv6FilterEntryConfig["action"]["forward"]["vprn-target"])
                {
                    properties["action"] = "forwardVprnTarget";
                    if(this.isValidIPv6Address(intentIPv6FilterEntryConfig["action"]["forward"]["vprn-target"]["bgp-nh"]))
                    {
                        properties["fwdVprnTgtBgpNHAddr"] = util.expandIPv6Address(intentIPv6FilterEntryConfig["action"]["forward"]["vprn-target"]["bgp-nh"]);
                    }
                    else
                    {
                        properties["fwdVprnTgtBgpNHAddr"] = intentIPv6FilterEntryConfig["action"]["forward"]["vprn-target"]["bgp-nh"];
                    }
                    if(intentIPv6FilterEntryConfig["action"]["forward"]["vprn-target"]["vprn"])
                    {
                        properties["fwdVprnRouterPointer"] = nfmpSuggest.getVPRNServiceFullName(target, intentIPv6FilterEntryConfig["action"]["forward"]["vprn-target"]["vprn"]);
                    }
                    else
                    {
                        properties["fwdVprnRouterPointer"] = "";
                    }

                    if(intentIPv6FilterEntryConfig["action"]["forward"]["vprn-target"]["lsp"])
                    {
                        properties["fwdVprnTgtLspPointer"] = nfmpSuggest.getLSPFullName(target, intentIPv6FilterEntryConfig["action"]["forward"]["vprn-target"]["lsp"]);
                    }
                    else
                    {
                        properties["fwdVprnTgtLspPointer"] = "";
                    }
                    if(intentIPv6FilterEntryConfig["action"]["forward"]["vprn-target"]["adv-prefix"])
                    {
                        properties["fwdVprnTgtAdvPrefix"] = util.expandIPv6Address((intentIPv6FilterEntryConfig["action"]["forward"]["vprn-target"]["adv-prefix"]).split("/")[0]);
                        properties["fwdVprnTgtAdvPrefixLength"] = (intentIPv6FilterEntryConfig["action"]["forward"]["vprn-target"]["adv-prefix"]).split("/")[1];
                    }
                }
                else if(intentIPv6FilterEntryConfig["action"]["forward"]["gre-tunnel"])
                {
                    properties["action"] = "forwardGre";
                    properties["fwdGreTunnelPointer"] = "GreTunnelTemplate:"+intentIPv6FilterEntryConfig["action"]["forward"]["gre-tunnel"];
                }
                else if(intentIPv6FilterEntryConfig["action"]["forward"]["mpls-policy"])
                {
                    if(intentIPv6FilterEntryConfig["action"]["forward"]["mpls-policy"]["endpoint"])
                    {
                        properties["action"] = "forwardMplsPlcyEndPoint";
                        properties["fwdMPLSPolicyEndPointAddress"] = util.expandIPv6Address(intentIPv6FilterEntryConfig["action"]["forward"]["mpls-policy"]["endpoint"]);
                    }
                }
                else if(intentIPv6FilterEntryConfig["action"]["forward"]["srte-policy"])
                {
                    properties["action"] = "forwardSrtePlcyColor";
                    properties["fwdSrtePlcyEndPointAddress"] = util.expandIPv6Address(intentIPv6FilterEntryConfig["action"]["forward"]["srte-policy"]["endpoint"]);
                    properties["fwdSRTEPolicyColor"] = intentIPv6FilterEntryConfig["action"]["forward"]["srte-policy"]["color"];
                }
                else if(intentIPv6FilterEntryConfig["action"]["forward"]["srv6-policy"])
                {
                    properties["action"] = "forwardSrv6Plcy";
                    properties["fwdSrv6PlcyEndptAddr"] = util.expandIPv6Address(intentIPv6FilterEntryConfig["action"]["forward"]["srv6-policy"]["endpoint"]);
                    properties["fwdSrv6PlcyColor"] = intentIPv6FilterEntryConfig["action"]["forward"]["srv6-policy"]["color"];
                    properties["fwdSrv6PlcySvcSid"] = util.expandIPv6Address(intentIPv6FilterEntryConfig["action"]["forward"]["srv6-policy"]["service-sid"]);
                }
                else
                {
                    //Do Nothing
                }
            }
            if(intentIPv6FilterEntryConfig["action"]["http-redirect"] !== undefined)
            {
                if(intentIPv6FilterEntryConfig["action"]["http-redirect"]["url"] ||
                    intentIPv6FilterEntryConfig["action"]["http-redirect"]["allow-override"])
                {
                    properties["action"] = "httpredirect";
                    properties["redirectURL"] = intentIPv6FilterEntryConfig["action"]["http-redirect"]["url"];
                    properties["allowRadiusOverride"] = intentIPv6FilterEntryConfig["action"]["http-redirect"]["allow-override"];
                }
            }
            if(intentIPv6FilterEntryConfig["action"]["nat"] !== undefined)
            {
                if (intentIPv6FilterEntryConfig["action"]["nat"]["nat-policy"] ||
                    intentIPv6FilterEntryConfig["action"]["nat"]["nat-type"])
                {
                    properties["action"] = "NAT";
                    if (intentIPv6FilterEntryConfig["action"]["nat"]["nat-policy"])
                    {
                        properties["natPolicyPointer"] = "natPolicy:nat-" + intentIPv6FilterEntryConfig["action"]["nat"]["nat-policy"];
                    }
                    if (intentIPv6FilterEntryConfig["action"]["nat"]["nat-type"] == "dslite")
                    {
                        properties["natType"] = "dsLite";
                    } else if (intentIPv6FilterEntryConfig["action"]["nat"]["nat-type"] == "nat64")
                    {
                        properties["natType"] = "nat64Lsn";
                    }
                }
            }
            if(intentIPv6FilterEntryConfig["action"]["tcp-mss-adjust"] !== undefined)
            {
                properties["action"] = "tcpMssAdjust";
            }
            if(intentIPv6FilterEntryConfig["action"]["accept"] !== undefined)
            {
                properties["action"] = "forward";
            }
            if(intentIPv6FilterEntryConfig["action"]["remark"] !== undefined)
            {
                properties["extendedAction"] = "remarkDscp"
                properties["actionRemarkDscp"] = intentIPv6FilterEntryConfig["action"]["remark"]["dscp"];
            }
            if(intentIPv6FilterEntryConfig["action"]["rate-limit"] !== undefined)
            {
                if(intentIPv6FilterEntryConfig["action"]["rate-limit"]["mbs"] !== undefined) {
                    properties["action"] = "ratelimit";
                    if(intentIPv6FilterEntryConfig["action"]["rate-limit"]["mbs"] == "auto") {properties["rateLimitMbs"] = "-1"; }
                    else {
                    properties["rateLimitMbs"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["mbs"];}
                }

                if(intentIPv6FilterEntryConfig["action"]["rate-limit"] && intentIPv6FilterEntryConfig["action"]["rate-limit"]["pir"]) {
                    properties["action"] = "ratelimit";
                    if(intentIPv6FilterEntryConfig["action"]["rate-limit"]["pir"] == "max")
                    {  properties["rateLimit"] = "-1";
                    }
                    else{
                      properties["rateLimit"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["pir"];
                    }
                    properties["rateLimitUnit"] = "kbps";
                }
                else if(intentIPv6FilterEntryConfig["action"]["rate-limit"] && intentIPv6FilterEntryConfig["action"]["rate-limit"]["pps-pir"]) {
                    properties["action"] = "ratelimit";
                    if(intentIPv6FilterEntryConfig["action"]["rate-limit"]["pps-pir"] == "max") {properties["rateLimitPps"] = "-1";}
                    else{
                    properties["rateLimitPps"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["pps-pir"];}
                    properties["rateLimitUnit"] = "pps";
                }

                if (intentIPv6FilterEntryConfig["action"]["rate-limit"]["hop-limit"] !== undefined)
                {
                    properties["action"] = "ratelimit";
                    if (intentIPv6FilterEntryConfig["action"]["rate-limit"]["hop-limit"]["eq"])
                    {
                        properties["hoplimitOper"] = "EQUAL";
                        properties["hoplimitVal1"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["hop-limit"]["eq"];
                        properties["hoplimitVal2"] = 0;
                    } else if (intentIPv6FilterEntryConfig["action"]["rate-limit"]["hop-limit"]["lt"])
                    {
                        properties["hoplimitOper"] = "LESS_THAN";
                        properties["hoplimitVal1"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["hop-limit"]["lt"];
                        properties["hoplimitVal2"] = 0;
                    } else if (intentIPv6FilterEntryConfig["action"]["rate-limit"]["hop-limit"]["gt"])
                    {
                        properties["hoplimitOper"] = "GREATER_THAN";
                        properties["hoplimitVal1"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["hop-limit"]["gt"];
                        properties["hoplimitVal2"] = 0;
                    } else if (intentIPv6FilterEntryConfig["action"]["rate-limit"]["hop-limit"]["range"])
                    {
                        properties["hoplimitOper"] = "RANGE";
                        properties["hoplimitVal1"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["hop-limit"]["range"]["start"];
                        properties["hoplimitVal2"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["hop-limit"]["range"]["end"];
                    }
                }
                if (intentIPv6FilterEntryConfig["action"]["rate-limit"]["payload-length"] !== undefined)
                {
                    properties["action"] = "ratelimit";
                    if (intentIPv6FilterEntryConfig["action"]["rate-limit"]["payload-length"]["eq"])
                    {
                        properties["pktLenOper"] = "EQUAL";
                        properties["pktLenVal1"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["payload-length"]["eq"];
                        properties["pktLenVal2"] = 0;
                    } else if (intentIPv6FilterEntryConfig["action"]["rate-limit"]["payload-length"]["lt"])
                    {
                        properties["pktLenOper"] = "LESS_THAN";
                        properties["pktLenVal1"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["payload-length"]["lt"];
                        properties["pktLenVal2"] = 0;
                    } else if (intentIPv6FilterEntryConfig["action"]["rate-limit"]["payload-length"]["gt"])
                    {
                        properties["pktLenOper"] = "GREATER_THAN";
                        properties["pktLenVal1"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["payload-length"]["gt"];
                        properties["pktLenVal2"] = 0;
                    } else if (intentIPv6FilterEntryConfig["action"]["rate-limit"]["payload-length"]["range"])
                    {
                        properties["pktLenOper"] = "RANGE";
                        properties["pktLenVal1"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["payload-length"]["range"]["start"];
                        properties["pktLenVal2"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["payload-length"]["range"]["end"];
                    }
                }
                if(intentIPv6FilterEntryConfig["action"]["rate-limit"]["extracted-traffic-case"] !== undefined)
                {
                    properties["action"] = "ratelimit";
                    properties["rateLimitExtractedTraffic"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["extracted-traffic-case"];
                }
                if (intentIPv6FilterEntryConfig["action"]["rate-limit"]["pattern"] !== undefined)
                {
                    properties["action"] = "ratelimit";
                    properties["patternExp"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["pattern"]["expression"];
                    properties["patternMask"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["pattern"]["mask"];
                    properties["patternOffsetType"] =
                        util.transformNfmpPatternOffSetType(intentIPv6FilterEntryConfig["action"]["rate-limit"]["pattern"]["expression"]);
                    properties["patternOffsetValue"] = intentIPv6FilterEntryConfig["action"]["rate-limit"]["pattern"]["offset-value"];
                }
            }
            if(intentIPv6FilterEntryConfig["action"]["accept-when"] !== undefined
                && intentIPv6FilterEntryConfig["action"]["accept-when"]["pattern"] !== undefined)
            {
                properties["action"] = "forwardWhen";
                properties["patternExp"] = intentIPv6FilterEntryConfig["action"]["accept-when"]["pattern"]["expression"];
                properties["patternMask"] = intentIPv6FilterEntryConfig["action"]["accept-when"]["pattern"]["mask"];
                properties["patternOffsetType"] =
                    util.transformNfmpPatternOffSetType(intentIPv6FilterEntryConfig["action"]["accept-when"]["pattern"]["offset-type"]);
                properties["patternOffsetValue"] = intentIPv6FilterEntryConfig["action"]["accept-when"]["pattern"]["offset-value"];
            }
            if(intentIPv6FilterEntryConfig["action"]["drop-when"] !== undefined)
            {
                if(intentIPv6FilterEntryConfig["action"]["drop-when"]["hop-limit"] !== undefined)
                {
                    properties["action"] = "drop";
                    if(intentIPv6FilterEntryConfig["action"]["drop-when"]["hop-limit"]["eq"])
                    {
                        properties["hoplimitOper"] = "EQUAL";
                        properties["hoplimitVal1"] = intentIPv6FilterEntryConfig["action"]["drop-when"]["hop-limit"]["eq"];
                        properties["hoplimitVal2"] = 0;
                    }
                    else if(intentIPv6FilterEntryConfig["action"]["drop-when"]["hop-limit"]["lt"])
                    {
                        properties["hoplimitOper"] = "LESS_THAN";
                        properties["hoplimitVal1"] = intentIPv6FilterEntryConfig["action"]["drop-when"]["hop-limit"]["lt"];
                        properties["hoplimitVal2"] = 0;
                    }
                    else if(intentIPv6FilterEntryConfig["action"]["drop-when"]["hop-limit"]["gt"])
                    {
                        properties["hoplimitOper"] = "GREATER_THAN";
                        properties["hoplimitVal1"] = intentIPv6FilterEntryConfig["action"]["drop-when"]["hop-limit"]["gt"];
                        properties["hoplimitVal2"] = 0;
                    }
                    else if(intentIPv6FilterEntryConfig["action"]["drop-when"]["hop-limit"]["range"])
                    {
                        properties["hoplimitOper"] = "RANGE";
                        properties["hoplimitVal1"] = intentIPv6FilterEntryConfig["action"]["drop-when"]["hop-limit"]["range"]["start"];
                        properties["hoplimitVal2"] = intentIPv6FilterEntryConfig["action"]["drop-when"]["hop-limit"]["range"]["end"];
                    }
                }
                if(intentIPv6FilterEntryConfig["action"]["drop-when"]["payload-length"] !== undefined)
                {
                    properties["action"] = "drop";
                    if(intentIPv6FilterEntryConfig["action"]["drop-when"]["payload-length"]["eq"])
                    {
                        properties["pktLenOper"] = "EQUAL";
                        properties["pktLenVal1"] = intentIPv6FilterEntryConfig["action"]["drop-when"]["payload-length"]["eq"];
                        properties["pktLenVal2"] = 0;
                    }
                    else if(intentIPv6FilterEntryConfig["action"]["drop-when"]["payload-length"]["lt"])
                    {
                        properties["pktLenOper"] = "LESS_THAN";
                        properties["pktLenVal1"] = intentIPv6FilterEntryConfig["action"]["drop-when"]["payload-length"]["lt"];
                        properties["pktLenVal2"] = 0;
                    }
                    else if(intentIPv6FilterEntryConfig["action"]["drop-when"]["payload-length"]["gt"])
                    {
                        properties["pktLenOper"] = "GREATER_THAN";
                        properties["pktLenVal1"] = intentIPv6FilterEntryConfig["action"]["drop-when"]["payload-length"]["gt"];
                        properties["pktLenVal2"] = 0;
                    }
                    else if(intentIPv6FilterEntryConfig["action"]["drop-when"]["payload-length"]["range"])
                    {
                        properties["pktLenOper"] = "RANGE";
                        properties["pktLenVal1"] = intentIPv6FilterEntryConfig["action"]["drop-when"]["payload-length"]["range"]["start"];
                        properties["pktLenVal2"] = intentIPv6FilterEntryConfig["action"]["drop-when"]["payload-length"]["range"]["end"];
                    }
                }
                if(intentIPv6FilterEntryConfig["action"]["drop-when"]["pattern"] !== undefined)
                {
                    //properties["action"] = "drop";
                    properties["patternExp"] = intentIPv6FilterEntryConfig["action"]["drop-when"]["pattern"]["expression"];
                    properties["patternMask"] = intentIPv6FilterEntryConfig["action"]["drop-when"]["pattern"]["mask"];
                    properties["patternOffsetType"] =
                        util.transformNfmpPatternOffSetType(intentIPv6FilterEntryConfig["action"]["drop-when"]["pattern"]["offset-type"]);
                    properties["patternOffsetValue"] = intentIPv6FilterEntryConfig["action"]["drop-when"]["pattern"]["offset-value"];
                }
            }
            if(intentIPv6FilterEntryConfig["action"]["secondary"] !== undefined)
            {
                if(intentIPv6FilterEntryConfig["action"]["secondary"]["forward"] !== undefined)
                {
                    if(intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["next-hop"] !== undefined)
                    {
                        if(intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["next-hop"]["nh-ip-vrf"] !== undefined)
                        {
                            properties["secondaryAction"] = "forwardNextHopRouter";
                            properties["secondaryNextHop"] =
                                util.expandIPv6Address(intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["next-hop"]["nh-ip-vrf"]["address"]);
                            properties["secondaryNextHopIndirect"] =
                                intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["next-hop"]["nh-ip-vrf"]["indirect"];
                            if(intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["next-hop"]["nh-ip-vrf"]["router-instance"])
                            {
                                if(intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["next-hop"]["nh-ip-vrf"]["router-instance"] == "Base")
                                {
                                    properties["secondaryRouterType"] = "base";
                                }
                                else
                                {
                                    properties["secondaryRouterType"] = "vprn";
                                    properties["secondaryFwdVprnPointer"] = nfmpSuggest.getVPRNServiceFullName(target, intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["next-hop"]["nh-ip-vrf"]["router-instance"])
                                }
                            }
                        }
                    }
                    if(intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["sdp"] !== undefined)
                    {
                        properties["secondaryAction"] = "forwardSdp";
                        if(intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["sdp"]["sdp-bind-id"])
                        {
                            properties["secondaryFwdSdpBindPathId"] = (intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["sdp"]["sdp-bind-id"]).split(":")[0];
                            properties["secondaryFwdSdpBindVcId"] = (intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["sdp"]["sdp-bind-id"]).split(":")[1];
                        }
                    }
                    if(intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["sap"] !== undefined)
                    {
                        properties["secondaryAction"] = "forwardSap";
                        if(intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["sap"]["sap-id"])
                        {
                            var sapInfo  = (intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["sap"]["sap-id"]).split(":");
                            if(!Array.isArray(sapInfo))
                            {
                                sapInfo = [sapInfo];
                            }
                            properties["secondaryFwdSapPortName"] = sapInfo[0];
                            if(sapInfo.length == 2)
                            {
                                var encapValues = sapInfo[1].split(".");
                                if(!Array.isArray(encapValues))
                                {
                                    encapValues = [encapValues];
                                }
                                if(encapValues.length >= 1)
                                {
                                    if(encapValues[0] == "*")
                                    {
                                        properties["secondaryFwdSapOuterEncapValue"] = 4095;
                                    }
                                    else
                                    {
                                        properties["secondaryFwdSapOuterEncapValue"] = encapValues[0];
                                    }
                                    if(encapValues.length == 2)
                                    {
                                        if(encapValues[1] == "*")
                                        {
                                            properties["secondaryFwdSapInnerEncapValue"] = 4095;
                                        }
                                        else
                                        {
                                            properties["secondaryFwdSapInnerEncapValue"] = encapValues[1];
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if(intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["vprn-target"] !== undefined)
                    {
                        properties["secondaryAction"] = "forwardVprnTarget";
                        properties["secondaryFwdVprnTgtBgpNHAddr"] = intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["vprn-target"]["bgp-nh"];
                        if(intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["vprn-target"]["vprn"])
                        {
                            properties["secondaryFwdVprnRouterPointer"] = nfmpSuggest.getVPRNServiceFullName(target,intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["vprn-target"]["vprn"]);
                        }
                        else
                        {
                            properties["secondaryFwdVprnRouterPointer"] = "";
                        }
                        if(intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["vprn-target"]["lsp"])
                        {
                            properties["secondaryVprnTgtLspPointer"] = nfmpSuggest.getLSPFullName(target,intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["vprn-target"]["lsp"]);
                        }
                        else
                        {
                            properties["secondaryVprnTgtLspPointer"] = "";
                        }
                        properties["secondaryVprnTgtLspPointer"] = undefined;
                        if(intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["vprn-target"]["adv-prefix"])
                        {
                            properties["secondaryVprnTgtAdvPrefix"] = util.expandIPv6Address((intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["vprn-target"]["adv-prefix"]).split("/")[0]);
                            properties["secondaryVprnTgtAdvPrefixLength"] = (intentIPv6FilterEntryConfig["action"]["secondary"]["forward"]["vprn-target"]["adv-prefix"]).split("/")[1];
                        }
                    }
                }
                if(intentIPv6FilterEntryConfig["action"]["secondary"]["remark"] !== undefined)
                {
                    properties["secondaryExtendedAction"] = "remarkDscp"
                    properties["secondaryActionRemarkDscp"] = intentIPv6FilterEntryConfig["action"]["secondary"]["remark"]["dscp"];
                }
            }
        }
        return properties;
    }

    this.createIpv6FilterEmbededFilterPayLoad = function(target, intentIPv6FilterEmbededFilterConfig)
    {
        var properties = {};
        if(intentIPv6FilterEmbededFilterConfig["name"])
        {
            var filterId = nfmpSuggest.getFilterId(target, intentIPv6FilterEmbededFilterConfig["name"]);
            if(filterId && filterId[0])
            {
                properties["embeddedFilterId"] = filterId[0];
                properties["embeddedFilterIdPointer"] = "IPv6 Filter:" + filterId[0];
            }
        }

        properties["offset"] = intentIPv6FilterEmbededFilterConfig["offset"];
        if(intentIPv6FilterEmbededFilterConfig["admin-state"] == "enable")
        {
            properties["adminState"] = "active"
        }
        else
        {
            properties["adminState"] = "inactive"
        }
        return properties;

    }

    this.createIpv6FilterEmbededFlowSpecPayLoad = function(target, intentIPv6FilterEmbededFlowSpecConfig)
    {
        var properties = {};
        properties["groupId"] = intentIPv6FilterEmbededFlowSpecConfig["group"];
        properties["offset"] = intentIPv6FilterEmbededFlowSpecConfig["offset"];
        if(intentIPv6FilterEmbededFlowSpecConfig["admin-state"] == "enable")
        {
            properties["adminState"] = "active"
        }
        else
        {
            properties["adminState"] = "inactive"
        }

        if(intentIPv6FilterEmbededFlowSpecConfig["router-instance"])
        {
            if(intentIPv6FilterEmbededFlowSpecConfig["router-instance"] == "Base")
            {
                properties["routerType"] = "base";
            }
            else
            {
                properties["routerType"] = "vprn";
                properties["vprnPointer"] = nfmpSuggest.getVPRNServiceFullName(target, intentIPv6FilterEmbededFlowSpecConfig["router-instance"])
            }
        }

        return properties;
    }

    this.createIpv6FilterEmbededOpenFlowPayLoad = function(target, intentIPv6FilterEmbededFlowSpecConfig)
    {
        var properties = {};
        properties["groupId"] = intentIPv6FilterEmbededFlowSpecConfig["group"];
        properties["offset"] = intentIPv6FilterEmbededFlowSpecConfig["offset"];
        if(intentIPv6FilterEmbededFlowSpecConfig["admin-state"] == "enable")
        {
            properties["adminState"] = "active"
        }
        else
        {
            properties["adminState"] = "inactive"
        }

        if(intentIPv6FilterEmbededFlowSpecConfig["router-instance"] == "Base")
        {
            properties["routerType"] = "base";
        }
        else
        {
            properties["routerType"] = "vprn";
        }
        return properties;
    }

    /*
     function: distributePolicy
     description: Distribute Policy to local NE Level.
     */
    this.distributeFilter = function(nodeIp, intentConfig, localEdit) {
        logger.info(LOG_PREFIX + "localEdit: " + localEdit);
        var objectFullName = "IPv6 Filter:" + intentConfig["id"];
        var payload = {};
        if (localEdit === false) {
            payload["policy.PolicyDefinition.distributeV2"] = {};
            payload["policy.PolicyDefinition.distributeV2"]["clearOnDeployFailure"] = true;
            payload["policy.PolicyDefinition.distributeV2"]["deployer"] = "immediate";
            payload["policy.PolicyDefinition.distributeV2"]["instanceFullName"] = objectFullName;
            payload["policy.PolicyDefinition.distributeV2"]["siteIds"] = {};
            payload["policy.PolicyDefinition.distributeV2"]["siteIds"]["string"] = nodeIp;
            logger.info(LOG_PREFIX + objectFullName + ": policy distribute Payload: " + JSON.stringify(payload));
        }
        else {
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"] = {};
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["clearOnDeployFailure"] = true;
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["deployer"] = "immediate";
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["instanceFullName"] = objectFullName;
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["siteIds"] = {};
            payload["policy.PolicyDefinition.setDistributionModeToLocalEditOnly"]["siteIds"]["string"] = nodeIp;
            logger.info(LOG_PREFIX + objectFullName + ": policy switch to local edit only Payload for " + nodeIp+ " : " + JSON.stringify(payload));
        }

        return nfmpFwk.post("/rest/api/v3/request", payload);
    }

    this.syncDelete = function (input,result) {

        var neId = parseTarget.getNeIdFromTarget(input.getTarget());
        var filterId = util.getIpFilterId(input.getTarget());

        var searchPayLoad = this.constructSearchStringWithFilterID(neId, filterId);
        var searchResponse = nfmpFwk.find(neId, searchPayLoad);
        if (!(searchResponse.success && JSON.parse(searchResponse["response"]).length !== 0))
        {
            if(!(searchResponse.success))
                logger.info("[NFMP-IPV6FILTER-FWK] syncDelete(): Unable to get Filter info from nfm-p for filter with Id:"+filterId+ " on "+ neId);
            if(JSON.parse(searchResponse["response"]).length === 0)
                logger.info("[NFMP-IPV6FILTER-FWK] syncDelete(): There is no IPv6 Filter with Id:"+filterId+ " on "+ neId);
            result.setSuccess(false);
            return;
        }
        var objectFullName = "network:"+neId+":IPv6 Filter:" + filterId;
        objectFullName = util.modifyNeIdForIpV6(objectFullName, neId);
        logger.info("[NFMP-IPV6FILTER-FWK] syncDelete(): Deleting " + objectFullName);
        var deleteResult = nfmpFwk.deployDelete(objectFullName, "application/json");

        if (!deleteResult.success) {
            logger.info("[NFMP-IPV6FILTER-FWK] syncDelete(): Unable to Delete: " + deleteResult.msg);
            throw new RuntimeException('Unable to Delete: ' + deleteResult.msg);
        }
        result.setSuccess(true);
    }

    this.modifyRequest = function(target,payload){

        logger.info("Sending the modify request for mdt");
        logger.info(JSON.stringify(payload));

        var result = nfmpFwk.deploy(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
           logger.error("Error result = {}",JSON.stringify(result));
           let errorMsg = result.msg;
           if(errorMsg.indexOf("object already exists") !== -1)
           {
               logger.info("Global policy Object already exists, Re-checking the Policy existence ");
               //util.delay(2000);
               let configInfo = payload.configInfo;
               let fullClassName;
               for (let key in configInfo) {
                 if (configInfo.hasOwnProperty(key)) {
                   fullClassName = key;
                   break;
                 }
               }
               let objectFullName = payload.objectFullName;
               objectFullName = util.modifyNeIdForIpV6(objectFullName, target);
               logger.info("fullClassName = {}",fullClassName);
               logger.info("objectFullName = {}",objectFullName);
               if (!util.isObjectExists(fullClassName, objectFullName))
               {
                   throw new RuntimeException("Global Policy Object Not Found!!!");
               }
           }
           else
           {
               throw new RuntimeException(result.msg);
           }
        }
        return result;
    }

    this.xml2object = function(xmlElement) {
        var lXml = Java.type("org.json.XML");
        var lsImpl = xmlElement.getOwnerDocument().getImplementation().getFeature("LS", "3.0");
        var serializer = lsImpl.createLSSerializer();
        serializer.getDomConfig().setParameter("xml-declaration", false);
        var str = serializer.writeToString(xmlElement);
        var json = lXml.toJSONObject(str).toString();
        logger.info('inp json: '+ json)
        return JSON.parse(json);
    }

    this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            //if(intentJson && intentJson!=="" && this.validateElements(path,target)){
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }

    this.loadSavedObjectsFromTopology = function(savedTopology) {

        if(savedTopology){
            var topoObjects = savedTopology.getTopologyObjects();
            if (topoObjects.length > 0){
                topoObjects.forEach(function(topoObject){
                    mapFwk.set(savedObjects,topoObject.getObjectType(),topoObject.getObjectRelativeObjectID());
                });
            }
        }

    }

    this.loadCurrentObjectsToTopology = function(target) {

        var currentTopo = topologyFactory.createServiceTopology();
        if(Object.keys(currentObjects).length){
            for(var key in currentObjects){
                objectId = mapFwk.get(currentObjects,key);
                currentTopo.addTopologyObject(topologyFactory.createTopologyObjectWithVertex(key,objectId,"INFRASTRUCTURE",target,""));
            }
        }
        return currentTopo;

    }

    this.auditRequest = function(target,payload){
        logger.info("Sending the audit request for mdt");
        logger.info(JSON.stringify(payload));
        var result = nfmpFwk.compare(target, JSON.stringify(payload), "application/json");
        if (!result.success) {
            throw new RuntimeException(result.msg);
        }
        return result;

    }

    this.constructSearchStringWithFilterID = function(neId, filterId) {
        var jsonPayLoad = {
            "fullClassName": "aclfilter.Ipv6Filter",
            "filter": {
                "equal":
                    {
                        "name": "id",
                        "value": filterId
                    }
            }
        };
        return jsonPayLoad;
    }
    this.isValidIPv6Address = function(ipAddress)
    {
        if (/^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$|^::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})$|^([0-9a-fA-F]{1,4}:){1,7}:$|^fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}$|^::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})%[0-9a-zA-Z]{1,}$|^:((:[0-9a-fA-F]{1,4}){1,7}|:)$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,5}|:)$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,4}|:)$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,3}|:)$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,2}|:)$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1}|:)$|^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,2})$|^(([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,2})$|^([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])$|^:((:[0-9a-fA-F]{1,4}){1,7}|:)$/.test(ipAddress))
        {
            return (true);
        }
        return (false);
    }
}
