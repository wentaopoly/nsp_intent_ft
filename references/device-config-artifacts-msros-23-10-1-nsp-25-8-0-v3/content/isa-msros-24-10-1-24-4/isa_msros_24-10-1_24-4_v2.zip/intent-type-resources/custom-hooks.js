load({script: resourceProvider.getResource("parse-target.js"), name: "ParseTarget"});
load({script: resourceProvider.getResource('intentDeviceDeviation.js'), name: 'IntentDeviceDeviation'});
function CustomHooks() {
    /**
   * PreAudit Hook
   */
  const preAudit = (inputObj) => {
     /**
     * Write your custom preAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName
     *
     */

    logger.info("[CUSTOM-HOOKS] preAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
    var intentDeviationObj = new IntentDeviceDeviation();
    var target = inputObj["target"];
    var intentConfig = inputObj["intentConfig"];
    var neId = parseTarget.getNeIdFromTarget(target);
    intentConfig = this.removeEmptyContainers("", intentConfig, "", target);
    intentConfig = intentDeviationObj.removeIntentConfig(JSON.stringify(intentConfig), neId);
    logger.info("preAudit intent config after removing deviation attributes: " + JSON.stringify(intentConfig));
    return intentConfig;
  };

  /**
   * PostAudit Hook
   */
  const postAudit = (inputObj) => {
    /**
     * Write your custom postAudit logic here
     * inputObj by default contains the following keys:
     *          target, intentConfig, svcTopo, adminState,
     *          intentTypeName, rootXPath, intentContainer,
     *          uniqueIdentifier, deviceYangModuleName, auditReport
     *
     */

    logger.info("[CUSTOM-HOOKS] postAudit call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));


  };

  /**
   * PreSync Hook
   */
    /**
     * PreSync Hook
     */
    const preSync = (inputObj) => {
        /**
         * Write your custom preSync logic here
         * inputObj by default contains the following keys:
         *          target, config, intentTypeName, rootXPath,
         *          intentContainer, uniqueIdentifier, deviceYangModuleName
         *          topology, state, syncResult
         */
        logger.info("[CUSTOM-HOOKS] preSync call");
        var config = JSON.parse(inputObj["config"]);
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));
        logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(config));
        var target = inputObj["target"];
        config = this.removeEmptyContainers("", config, "", target);
        var intentTypeName = inputObj["intentTypeName"];
        var intentContainer = inputObj["intentContainer"];
        var intentDeviationObj = new IntentDeviceDeviation();
        var neId = parseTarget.getNeIdFromTarget(target);
        if (!Array.isArray(config)) {
            config = [config];
        }
        let preSyncConf = [];
        for (var index in config) {
            var confObj= config[index][intentTypeName + ":" + intentTypeName][intentContainer];
            let configObj = JSON.stringify(confObj);
            let deviatedObj = intentDeviationObj.removeIntentConfig(configObj, neId);
            let finalConfigObj = {};
            let intentKey = intentTypeName + ":" + intentTypeName
            finalConfigObj[intentKey] = {};
            finalConfigObj[intentKey][intentContainer] = deviatedObj;
            preSyncConf.push(finalConfigObj);
        }
        logger.info("intent config after removing deviation attributes: " + JSON.stringify(preSyncConf));
        return JSON.stringify(preSyncConf);
    };

  /**
   * PostSync Hook
   */
  const postSync = (inputObj) => {
    /**
     * Write your custom postSync logic here
     * inputObj by default contains the following keys:
     *          target, config, intentTypeName, rootXPath,
     *          intentContainer, uniqueIdentifier, deviceYangModuleName
     *          topology, state, syncResult
     */
    logger.info("[CUSTOM-HOOKS] postSync call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

  };

  /**
   *
   * PostDiscovery Hook
   */
  const postDiscovery = (inputObj) => {
    /**
     * Write your custom postDiscovery logic here
     * inputObj by default contains the following keys:
     *        deviceConfig, intentContainer, neId,
     *        targetDataStruct, templateName, deviceYangModuleName
     */

    logger.info("[CUSTOM-HOOKS] postDiscovery call");
    logger.info("[CUSTOM-HOOKS] inputObj "+ JSON.stringify(inputObj));

  }
    this.removeEmptyContainers= function(prop,intentJson,path,target){

        if(Array.isArray(intentJson)){
            var object = [];
            for(var prop in intentJson){
                var value = this.removeEmptyContainers(prop , intentJson[prop],path,target);
                if(value){
                    object.push(value);
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else if( typeof intentJson == 'object' ){
            var object = {};
            for(var prop in intentJson){
                var pPath = path + "/" + prop;
                var value = this.removeEmptyContainers(prop , intentJson[prop],pPath,target);
                if (prop === "multi-active" && typeof intentJson[prop] === "object" && Object.keys(intentJson[prop]).length === 0) {
                  object[prop] = {};
                }
                else if((value && value!==null) || value == 0 ){
                    object[prop] = value;
                }

            }
            if(Object.keys(object).length !== 0){
                return object;
            }
        }else{
            if(intentJson!==undefined && intentJson!==""){
                return intentJson;
            }

            return null;
        }
    }


  this.preAudit = preAudit;
  this.postAudit = postAudit;
  this.preSync = preSync;
  this.postSync = postSync;
  this.postDiscovery = postDiscovery;

}